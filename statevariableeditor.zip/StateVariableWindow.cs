﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using DHKANG.SEA.Model.EventObjects;
using System.Text.RegularExpressions;
using DHKANG.SEA.Model.Entities;

namespace DHKANG.SEA.UI.ETTEditor
{
    public partial class StateVariableWindow : DockContent
    {
        #region Member Variables
        private EventObjectModelEditor _Parent;
        private StateVariableGridNameChangedEvent nameChangedController;
        private StateVariableGridValueTypeChangedEvent typeChangedController;

        private List<string> _BasicTypes = 
            new List<string>() { "bool", "int", "float", "double", "string", "EntityQueue", "Queue", "ParameterVariable", "RandomVariate", "Resource" };
        #endregion

        #region Events
        public event ChangedEventHandler Changed;
        #endregion

        #region Properties
        public List<OOEGStateVariable> StateVariables
        {
            get
            {
                List<OOEGStateVariable> rslt = new List<OOEGStateVariable>();
                for (int k = 1; k < gridVariable.RowsCount; k++)
                {
                    OOEGStateVariable var = getStateVariable(k);
                    if (var != null)
                        rslt.Add(var);
                }

                return rslt;
            }
        }

        private OOEGStateVariable getStateVariable(int rowIndex)
        {
            SourceGrid.Cells.ICellVirtual[] cells = gridVariable.GetCellsAtRow(rowIndex);
            int nullCount = 0;
            for (int p = 0; p < 6; p++)
            {
                if (gridVariable[rowIndex, p] == null || gridVariable[rowIndex, p].Value == null)
                    nullCount++;
            }
            if (nullCount < 6)
            {
                OOEGStateVariable variable = new OOEGStateVariable();
                variable.Name = (string)gridVariable[rowIndex, 0].Value;

                int row = 1;
                int col = 1;
                string valueType = "int";

                if (gridVariable[rowIndex, 1].Value != null)
                    row = int.Parse(gridVariable[rowIndex, 1].Value.ToString());
                if (gridVariable[rowIndex, 2].Value != null)
                    col = int.Parse(gridVariable[rowIndex, 2].Value.ToString());

                if (!string.IsNullOrEmpty(gridVariable[rowIndex, 3].DisplayText))//!= null)
                    valueType = (string)gridVariable[rowIndex, 3].Value;

                variable.Row = row;
                variable.Col = col;
                variable.ValueType = valueType;

                SourceGrid.Cells.Button btnCell = (SourceGrid.Cells.Button)gridVariable[rowIndex, 4];
                if (btnCell.Tag == null)
                    variable.InitialValue = string.Empty;
                else if (row == 1 && col == 1)
                {
                    string svValue = (string)btnCell.Tag;
                    if (svValue.StartsWith("{"))
                        variable.InitialValue = svValue.Substring(1, svValue.Length - 2);
                    else
                        variable.InitialValue = svValue;
                }
                else
                    variable.InitialValue = (string)btnCell.Tag;
                variable.Description = (string)gridVariable[rowIndex, 5].Value;
                return variable;
            }

            return null;
        }
        #endregion

        public StateVariableWindow(EventObjectModelEditor parent)
        {
            _Parent = parent;

            InitializeComponent();

            drawHeaders();

            nameChangedController = new StateVariableGridNameChangedEvent();
            nameChangedController.ValueChanged += new StateVariableGridNameChangedEventHandler(valueChangedController_ValueChanged); 

            typeChangedController = new StateVariableGridValueTypeChangedEvent();
            typeChangedController.ValueChanged += new StateVariableGridValueTypeChangedEventHandler(typeChangedController_ValueChanged); 
        }

        private void valueChangedController_ValueChanged(int row, string oldName, string newName)
        {
            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            {
                OOEGStateVariable oldSV = getStateVariable(row);
                oldSV.Name = oldName;
                OOEGStateVariable newSV = getStateVariable(row);
                newSV.Name = newName;

                Changed(ChangedTarget.StateVariable, ChangedType.Modified, oldSV, newSV);
            }
        }

        private void typeChangedController_ValueChanged(int row, string oldType, string newType)
        {
            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            {
                OOEGStateVariable oldSV = getStateVariable(row);
                oldSV.ValueType = oldType;
                OOEGStateVariable newSV = getStateVariable(row);
                newSV.ValueType = newType;

                Changed(ChangedTarget.StateVariable, ChangedType.Modified, oldSV, newSV);
            }
        }

        /*
        private void valueChangedController_ValueChanged(OOEGStateVariable oldStateVariable, OOEGStateVariable newStateVariable)
        {
            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            {
                Changed(ChangedTarget.StateVariable, ChangedType.Modified, oldStateVariable, newStateVariable);
            }
        }
        */

        private void StateVariableWindow_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            base.OnFormClosing(e);
        }

        private bool Exist(string targetName)
        {
            bool isExist = false; ;
            if (string.IsNullOrEmpty(targetName))
                return isExist;
            for (int i = 1; i < gridVariable.RowsCount; i++)
            {
                string name = (string)gridVariable[i, 0].Value;
                if (name.Equals(targetName))
                {
                    isExist = true;
                    break;
                }
            }
            return isExist;
        }

        public void OnEGDChanged(
                    ChangedTarget target, 
                    ChangedType action, 
                    string targetName, 
                    string propertyName, 
                    object before, 
                    object after)
        {
            if (target == ChangedTarget.EntityQueue)
            {
                if (action == ChangedType.Added)
                {
                    bool isExist = Exist((string)after);
                    if (!isExist)
                    {
                        OOEGStateVariable sv = new OOEGStateVariable((string)after, 1, 1, "EntityQueue", "", "");
                        InsertStateVariable(sv);
                    }

                    /*
                    if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
                    {
                        Changed(ChangedTarget.StateVariable, ChangedType.Added, null, sv);
                    }
                    */
                }
                else if (action == ChangedType.Deleted)
                {
                    bool isExist = Exist((string)after);
                    if (!isExist)
                        return;

                    OOEGStateVariable var = null;
                    int sRow = 1;
                    for (; sRow < gridVariable.Rows.Count; sRow++)
                    {
                        string name = (string)gridVariable[sRow, 0].Value;
                        if (name.Equals((string)before))
                        {
                            var = getStateVariable(sRow);
                            break;
                        }

                        if (var != null)
                        {
                            gridVariable.Rows.Remove(sRow);

                            /*
                            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
                            {
                                Changed(ChangedTarget.StateVariable, ChangedType.Deleted, var, null);
                            }
                            */
                        }
                    }
                }
                else if (action == ChangedType.Modified)
                {
                    for (int i = 1; i < gridVariable.Rows.Count; i++)
                    {
                        string name = (string)gridVariable[i, 0].Value;
                        if (name.Equals((string)before))
                        {
                            OOEGStateVariable oldVar = getStateVariable(i);
                            gridVariable[i, 0].Value = (string)after;
                            OOEGStateVariable newVar = getStateVariable(i);
                            /*
                            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
                            {
                                Changed(ChangedTarget.StateVariable, ChangedType.Modified, oldVar, newVar);
                            }
                            */

                            break;
                        }
                    }
                }
            }
        }

        private void drawHeaders()
        {
            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Snow;
            backHeader.Border = DevAge.Drawing.RectangleBorder.NoBorder;
            titleModel.Background = backHeader;
            //titleModel.BackColor = Color.SteelBlue;
            //titleModel.ForeColor = Color.White;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            gridVariable.BorderStyle = BorderStyle.FixedSingle;
            gridVariable.Redim(1, 6);
            gridVariable.FixedRows = 1;
            gridVariable.Font = new Font("Calibe", 10);
            //1st Header Row
            gridVariable.Rows.Insert(0);
            SourceGrid.Cells.ColumnHeader nameHeader = new SourceGrid.Cells.ColumnHeader("Name");
            nameHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.ColumnHeader rowsHeader = new SourceGrid.Cells.ColumnHeader("Rows");
            rowsHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.ColumnHeader colsHeader = new SourceGrid.Cells.ColumnHeader("Columns");
            colsHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.ColumnHeader typeHeader = new SourceGrid.Cells.ColumnHeader("Type");
            typeHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.ColumnHeader initialValueHeader = new SourceGrid.Cells.ColumnHeader("Initial Value");
            initialValueHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.ColumnHeader descHeader = new SourceGrid.Cells.ColumnHeader("Description");
            descHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            nameHeader.AutomaticSortEnabled = false;
            typeHeader.AutomaticSortEnabled = false;
            initialValueHeader.AutomaticSortEnabled = false;
            descHeader.AutomaticSortEnabled = false;

            gridVariable[0, 0] = nameHeader;
            gridVariable[0, 1] = rowsHeader;
            gridVariable[0, 2] = colsHeader;
            gridVariable[0, 3] = typeHeader;
            gridVariable[0, 4] = initialValueHeader;
            gridVariable[0, 5] = descHeader;

            gridVariable.Columns[0].MinimalWidth = 100;
            gridVariable.Columns[3].MinimalWidth = 150;
            gridVariable.Columns[5].MinimalWidth = 200;
        }

        private bool IsUpdating = false;
        public void Update(OOEGEventObjectModel eoModel)
        {
            IsUpdating = true;
            //Sorting Order
            List<string> stateVariables = new List<string>(); 
            foreach (OOEGStateVariable sv in eoModel.StateVariables)
                stateVariables.Add(sv.Name);
            stateVariables.Sort();

            foreach (string name in stateVariables)
            {
                InsertStateVariable(eoModel.GetStateVariable(name));
            }

            gridVariable.AutoStretchColumnsToFitWidth = false;
            gridVariable.AutoStretchRowsToFitHeight = false;
            gridVariable.AutoSizeCells();

            IsUpdating = false;
        }

        public void InsertStateVariable(OOEGStateVariable variable)
        {
            int rowIndex = gridVariable.RowsCount - 1;
            gridVariable.Rows.Insert(rowIndex);

            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(variable.Name, typeof(string));
            nameCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            nameCell.AddController(nameChangedController);

            SourceGrid.Cells.Cell rowCell = new SourceGrid.Cells.Cell(variable.Row, typeof(int));
            rowCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.Cell colCell = new SourceGrid.Cells.Cell(variable.Col, typeof(int));
            colCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;


            SourceGrid.Cells.Editors.ComboBox cbEditor = getAvailableTypes();
                
            SourceGrid.Cells.Cell typeCell = new SourceGrid.Cells.Cell(variable.ValueType, cbEditor);
            typeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            typeCell.View = SourceGrid.Cells.Views.ComboBox.Default;
            typeCell.AddController(typeChangedController);

            SourceGrid.Cells.Button valueCell = new SourceGrid.Cells.Button(variable.Row.ToString() + " rows");
            SourceGrid.Cells.Controllers.Button buttonClickEvent = new SourceGrid.Cells.Controllers.Button();
            buttonClickEvent.Executed += new EventHandler(CellButton_Click);
            valueCell.Tag = variable.InitialValue;
            valueCell.Controller.AddController(buttonClickEvent);
            valueCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            //SourceGrid.Cells.Cell valueCell = new SourceGrid.Cells.Cell(variable.InitialValue, typeof(string));
            //valueCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.Cell descCell = new SourceGrid.Cells.Cell(variable.Description, typeof(string));
            descCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            gridVariable[rowIndex, 0] = nameCell;
            gridVariable[rowIndex, 1] = rowCell;
            gridVariable[rowIndex, 2] = colCell;
            gridVariable[rowIndex, 3] = typeCell;
            gridVariable[rowIndex, 4] = valueCell;
            gridVariable[rowIndex, 5] = descCell;
        }


        private SourceGrid.Cells.Editors.ComboBox getAvailableTypes()
        {
            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));

            List<string> types = new List<string>();

            //Entities
            Guid projectID = MainUI.App.ModelExplorer.CurrentProject;
            List<OOMMEntity> entities = MainUI.App.ModelExplorer.GetEntities(projectID);
            //List<OOEGEntity> entities = MainForm.App.getCurrentEditor().CurrentEntities;
            foreach(OOMMEntity entity in entities)
            {
                types.Add(entity.Name); 
            }
            types.Sort();

            types.AddRange(_BasicTypes);

            cbEditor.StandardValues = types.ToArray<string>();
            //cbEditor.StandardValues = new string[] { "int", "float", "double", "string", "RandomVariate" };
            //cbEditor.StandardValues = new string[] { "int", "float", "double", "string", "Queue<int>", "Queue<float>", "Queue<double>", "Queue<string>", "List<int>","List<float>", "List<double>", "List<string>" };
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;

            return cbEditor;
        }

        private string getNextVariableName()
        {
            string rslt = "Variable 1";

            string expr = @"Variable[\s]*([0-9\-]*)";

            int nextNumber = 0;
            foreach(OOEGStateVariable sv in this.StateVariables)
            {
                if (sv == null)
                    continue;
                int number = 0;
                if (Regex.IsMatch(sv.Name, expr))
                {
                    Match m = Regex.Match(sv.Name, @"\d+");
                    if (int.TryParse(m.Value, out number))
                    {
                        if (number > nextNumber)
                            nextNumber = number;
                    }
                }
            }

            nextNumber++;
            rslt = "Variable " + nextNumber;

            return rslt;
        }

        public void InsertEmptyStateVariable()
        {
            OOEGStateVariable newVariable = new OOEGStateVariable(getNextVariableName(), 1, 1, "int", "0", "");
            InsertStateVariable(newVariable);
            /*
            int rowIndex = gridVariable.RowsCount - 1;
            gridVariable.Rows.Insert(rowIndex);

            gridVariable[rowIndex, 0] = new SourceGrid.Cells.Cell(getNextVariableName(), typeof(string));
            gridVariable[rowIndex, 1] = new SourceGrid.Cells.Cell("1", typeof(int));
            gridVariable[rowIndex, 2] = new SourceGrid.Cells.Cell("1", typeof(int));

            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            cbEditor.StandardValues = new string[] { "int", "float", "double", "string", "RandomVariate" };
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;
            gridVariable[rowIndex, 3] = new SourceGrid.Cells.Cell("int", cbEditor);
            gridVariable[rowIndex, 3].View = SourceGrid.Cells.Views.ComboBox.Default;

            //gridVariable[rowIndex, 4] = new SourceGrid.Cells.Cell("", typeof(string));
            gridVariable[rowIndex, 4] = new SourceGrid.Cells.Button("0 rows");
            SourceGrid.Cells.Controllers.Button buttonClickEvent = new SourceGrid.Cells.Controllers.Button();
            buttonClickEvent.Executed += new EventHandler(CellButton_Click);
            gridVariable[rowIndex, 4].Controller.AddController(buttonClickEvent);

            gridVariable[rowIndex, 5] = new SourceGrid.Cells.Cell("", typeof(string));
            */
            
            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            {
                Changed(ChangedTarget.StateVariable, ChangedType.Added, null, newVariable);
            }

        }

        private void CellButton_Click(object sender, EventArgs e)
        {
            SourceGrid.CellContext context = (SourceGrid.CellContext)sender;
            SourceGrid.Cells.Button btnCell = (SourceGrid.Cells.Button)context.Cell;

            int row = 1;
            int col = 1;
            string valueType = "int";

            if (gridVariable[btnCell.Row.Index, 1].Value != null)
                row = int.Parse(gridVariable[btnCell.Row.Index, 1].Value.ToString());
            if (gridVariable[btnCell.Row.Index, 2].Value != null)
                col = int.Parse(gridVariable[btnCell.Row.Index, 2].Value.ToString());

            if (!string.IsNullOrEmpty(gridVariable[btnCell.Row.Index, 3].DisplayText))//!= null)
                valueType = (string)gridVariable[btnCell.Row.Index, 3].Value;

            string initialValues = "";
            if (btnCell.Tag != null && !string.IsNullOrEmpty(btnCell.Tag.ToString()))//!= null)
                initialValues = (string)btnCell.Tag;

            D_VariableValue dialog = null;
            if (string.IsNullOrEmpty(initialValues))
                dialog = new D_VariableValue(row, col, valueType);
            else
                dialog = new D_VariableValue(row, col, valueType, initialValues);

            dialog.ShowDialog();

            if (!btnCell.Tag.Equals(dialog.InitialValues))
            {
                OOEGStateVariable oldVar = getStateVariable(btnCell.Row.Index);
                btnCell.Tag = dialog.InitialValues;
                btnCell.Value = row + " rows";

                OOEGStateVariable newVar = getStateVariable(btnCell.Row.Index);
                if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
                {
                    Changed(ChangedTarget.StateVariable, ChangedType.Modified, oldVar, newVar);
                }
            }
        }

        private void grid_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            SourceGrid.Position p = gridVariable.PositionAtPoint(e.Location);
            if (p.IsEmpty())
            {
                InsertEmptyStateVariable();
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            InsertEmptyStateVariable();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            //Remove State Variable
            int sRow = gridVariable.Selection.ActivePosition.Row;
            if (sRow < 0 || gridVariable[sRow, 0] == null)
                return;

            OOEGStateVariable var = getStateVariable(sRow);

            if (var != null)
            {
                gridVariable.Rows.Remove(sRow);

                if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
                {
                    Changed(ChangedTarget.StateVariable, ChangedType.Deleted, var, null); 
                }
            }
            //추후 아래를 반영할 것: 2015.01.13 - done in 24/08/2017
            //if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            //{
            //    Changed(ChangedTarget.StateVariable, ChangedType.Deleted, sv, null);
            //}
        }
    }

    public delegate void StateVariableGridNameChangedEventHandler(int row, string oldName, string newName);

    public class StateVariableGridNameChangedEvent : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event StateVariableGridNameChangedEventHandler ValueChanged;

        public StateVariableGridNameChangedEvent()
        {
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);
            if (ValueChanged != null && ValueChanged.GetInvocationList().Length > 0)
                ValueChanged(sender.Position.Row, (string)e.OldValue, (string)e.NewValue);
        }

    }

    public delegate void StateVariableGridValueTypeChangedEventHandler(int row, string oldType, string newType);

    public class StateVariableGridValueTypeChangedEvent : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event StateVariableGridValueTypeChangedEventHandler ValueChanged;

        public StateVariableGridValueTypeChangedEvent()
        {
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            if (ValueChanged != null && ValueChanged.GetInvocationList().Length > 0)
                ValueChanged(sender.Position.Row, (string)e.OldValue, (string)e.NewValue);
        }

    }
}
