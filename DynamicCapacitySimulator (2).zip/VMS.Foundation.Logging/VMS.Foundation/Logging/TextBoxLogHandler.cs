﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Text;

namespace VMS.Foundation.Logging
{
    public class TextBoxLogHandler : LogHandler
    {
        private System.Windows.Forms.TextBox _writer = null;
        //Infragistics.Win.UltraWinEditors.UltraTextEditor 
        public TextBoxLogHandler(TextBox txtbox, LogFormatter fmt)
            : base(fmt)
        {
            TextBoxWriter = txtbox;
        }

        public virtual TextBox TextBoxWriter
        {
            set
            {
                lock (this)
                {
                    ResetWriter();
                    _writer = value;
                    WriteHeader();
                }
            }
        }

        protected override void DoPublish(LogRecord record)
        {
            Write(Formatter.Format(record));
        }

        protected virtual void Write(string text)
        {
            //_writer.Text += text;
            _writer.AppendText(text);
            //if (_immediateFlush)
            //    _writer.Flush();
        }

        protected void WriteFooter()
        {
            if (Formatter != null && _writer != null)
            {
                _writer.Text += Formatter.GetFooter(this);
                //_writer.Flush();
            }
        }

        protected virtual void ResetWriter()
        {
            WriteFooter();
            CloseWriter();
            _writer = null;
        }

        protected void CloseWriter()
        {
            if (_writer != null)
            {
                try
                {
                    _writer = null;
                }
                catch (Exception e)
                {
                    throw new InvalidOperationException("Could not close writer [" + _writer + "]", e);
                    // do need to invoke an error handler
                    // at this late stage
                }
            }
        }

        protected void WriteHeader()
        {
            if (Formatter != null && _writer != null)
            {
                _writer.Text += (Formatter.GetHeader(this));
            }
        }
    }

    public class TextBoxLogHandler2 : LogHandler
    {
        private System.Windows.Forms.TextBox _writer = null;
        private StringBuilder _SB;
        public TextBoxLogHandler2(TextBox txtbox, LogFormatter fmt)
            : base(fmt)
        {
            TextBoxWriter = txtbox;
            if (_SB == null)
                _SB = new StringBuilder();
        }

        public virtual TextBox TextBoxWriter
        {
            set
            {
                lock (this)
                {
                    ResetWriter();
                    _writer = value;
                    WriteHeader();
                }
            }
        }

        protected override void DoPublish(LogRecord record)
        {
            Write(Formatter.Format(record));
        }

        protected virtual void Write(string text)
        {
            //_writer.Text += text;
            _SB.Append(text);
            //_writer.AppendText(text);
            //if (_immediateFlush)
            //    _writer.Flush();
        }

        protected void WriteFooter()
        {
            if (Formatter != null && _writer != null)
            {
                _SB.Append(Formatter.GetFooter(this));
                //_writer.Text += Formatter.GetFooter(this);

                //_writer.Flush();
            }
        }

        protected virtual void ResetWriter()
        {
            WriteFooter();
            CloseWriter();
            _writer = null;
        }

        protected void CloseWriter()
        {
            if (_writer != null)
            {
                try
                {
                    _writer.Text = _SB.ToString();
                    _writer = null;
                }
                catch (Exception e)
                {
                    throw new InvalidOperationException("Could not close writer [" + _writer + "]", e);
                    // do need to invoke an error handler
                    // at this late stage
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            this.CloseWriter();
        }

        protected void WriteHeader()
        {
            if (Formatter != null && _writer != null)
            {
                if (_SB == null)
                    _SB = new StringBuilder();

                _SB.Append(Formatter.GetHeader(this));

                ///_writer.Text += (Formatter.GetHeader(this));
            }
        }
    }
}
