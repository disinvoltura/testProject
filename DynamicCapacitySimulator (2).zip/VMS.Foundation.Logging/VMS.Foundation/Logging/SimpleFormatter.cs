﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VMS.Foundation.Logging
{
    public class SimpleFormatter : LogFormatter
    {
        private bool _ignoresException = false;
        private bool _writeTimeStamp = true;
        private bool _writeLoggerInfo = true;

        // Flag indicating if this formatter handle exceptions
        public bool IgnoresException
        {
            get { return _ignoresException; }
            set { _ignoresException = value; }
        }

        public bool WriteTimeStamp
        {
            get { return _writeTimeStamp; }
            set { _writeTimeStamp = value; }
        }

        public bool WriteLoggerInfo
        {
            get { return _writeLoggerInfo; }
            set { _writeLoggerInfo = value; }
        }

        // Return the tail string for a set of formatted records.
        public override string GetFooter(LogHandler h)
        {
            StringBuilder buf = new StringBuilder();

            buf.AppendLine("================================================");
            buf.AppendLine("ended logging at " + DateTime.Now);
            buf.AppendLine("================================================");

            return buf.ToString();
        }

        /// <summary>
        /// Produces a formatted string.
        /// </summary>
        public override string Format(LogRecord record)
        {
            if (record == null)
                throw new ArgumentNullException("record");

            StringBuilder buf = new StringBuilder(256);
            if (_writeTimeStamp)
            {
                buf.Append("[");
                buf.Append(record.TimeStamp);
                buf.Append("]");
                buf.Append(" ");
            }


            if (_writeLoggerInfo)
            {
                buf.Append(record.LoggerName).Append(":");
                buf.Append(record.Level);
                buf.Append(" - ");
            }

            buf.Append(record.Message);

            if (!_ignoresException && record.Exception != null)
            {
                buf.Append(Environment.NewLine);
                buf.Append("Exception : ");
                buf.Append(Environment.NewLine);
                buf.Append(record.Exception);

                if (record.Exception.InnerException != null)
                {
                    buf.Append(Environment.NewLine);
                    buf.Append("Inner Exception : ");
                    buf.Append(Environment.NewLine);
                    buf.Append(record.Exception.InnerException);
                }
            }
            buf.Append(Environment.NewLine);
            return buf.ToString();
        }
    }
}
