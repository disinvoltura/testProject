﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;

namespace VMS.Foundation.Logging
{
    public class Logger
    {
        object _myLevel = null;
        LogLevel _effectiveLevel;
        LogFilter _filter;
        string _name;
        Logger _parent;
        ArrayList _kids;
        ArrayList _handlers;
        bool _useParentHandlers;

        private static LogHandler[] emptyHandlers = new LogHandler[0];

        internal Logger(string name)
        {
            _name = name;
            _effectiveLevel = LogLevel.Informational;
            _useParentHandlers = true;
        }

        // Log name of this logger
        public string Name
        {
            get { return _name; }
        }

        /// filter to control output on this Logger.
        public LogFilter Filter
        {
            get { return _filter; }
            set { _filter = value; }
        }

        /// log Level that has been specified for this Logger
        public virtual LogLevel Level
        {
            get { return _effectiveLevel; }
            set
            {
                _myLevel = value;
                UpdateEffectiveLevel();
            }
        }
        /// Return the parent for this Logger.
        /// <p>
        /// This method returns the nearest extant parent in the namespace.
        /// Thus if a Logger is called "a.b.c.d", and a Logger called "a.b"
        ///  has been created but no logger "a.b.c" exists, then a call of
        ///  getParent on the Logger "a.b.c.d" will return the Logger "a.b".
        ///  <p>
        ///  The result will be null if it is called on the root Logger
        ///  in the namespace.
        public Logger Parent
        {
            get { return _parent; }
        }

        // Discover whether or not this logger is sending its output to its parent logger.
        public bool UseParentHandlers
        {
            get { return _useParentHandlers; }
            set { _useParentHandlers = value; }
        }

        public bool IsLoggable(LogLevel level)
        {
            return level <= _effectiveLevel;
        }

        public void Clear()
        {
            // Post the LogRecord to all our Handlers
            Logger logger = this;
            while (logger != null)
            {
                LogHandler[] targets = logger.GetHandlers();
                if (targets != null)
                {
                    for (int i = 0; i < targets.Length; i++)
                        targets[i].Clear();
                }

                if (!logger.UseParentHandlers)
                    break;
                logger = logger.Parent;
            }
        }

        void DoLog(LogRecord record)
        {
            lock (this)
            {
                if (_filter != null && !_filter.IsLoggable(record))
                    return;
            }

            // Post the LogRecord to all our Handlers
            Logger logger = this;
            while (logger != null)
            {
                LogHandler[] targets = logger.GetHandlers();
                if (targets != null)
                {
                    for (int i = 0; i < targets.Length; i++)
                        targets[i].Publish(record);
                }

                if (!logger.UseParentHandlers)
                    break;
                logger = logger.Parent;
            }
        }
        void DoLog(LogLevel level, string msg, Exception ex)
        {
            LogRecord lr = new LogRecord(level, msg, ex);
            lr.LoggerName = _name;
            DoLog(lr);
        }

        /// <summary>
        /// Logs the given Log recrod. 
        /// </summary>
        public void Log(LogRecord record)
        {
            if (_effectiveLevel < record.Level) return;
            DoLog(record);
        }

        public void Log(LogLevel level, string msg)
        {
            if (_effectiveLevel < level) return;
            DoLog(level, msg, null);
        }
        public void Log(LogLevel level, string msg, Exception ex)
        {
            if (_effectiveLevel < level) return;
            DoLog(level, msg, ex);
        }
        // Log a ERROR message.
        public void Error(string msg)
        {
            if (_effectiveLevel < LogLevel.Error) return;
            DoLog(LogLevel.Error, msg, null);
        }
        public void Error(string msg, Exception ex)
        {
            if (_effectiveLevel < LogLevel.Error) return;
            DoLog(LogLevel.Error, msg, ex);
        }

        // Log a WARNING message.
        public void Warning(string msg)
        {
            if (_effectiveLevel < LogLevel.Warning) return;
            DoLog(LogLevel.Warning, msg, null);
        }
        public void Warning(string msg, Exception ex)
        {
            if (_effectiveLevel < LogLevel.Warning) return;
            DoLog(LogLevel.Warning, msg, ex);
        }
        // Log a INFO message
        public void Info(string msg)
        {
            if (_effectiveLevel < LogLevel.Informational) return;
            DoLog(LogLevel.Informational, msg, null);
        }
        // Log a DEBUG message
        public void Debug(string msg)
        {
            if (_effectiveLevel < LogLevel.Debug) return;
            DoLog(LogLevel.Debug, msg, null);
        }

        /// <summary>
        /// Add a log Handler to receive logging messages.
        /// </summary>		
        public void AddHandler(LogHandler handler)
        {
            System.Diagnostics.Debug.Assert(handler != null);
            if (_handlers == null)
                _handlers = new ArrayList();
            _handlers.Add(handler);
        }

        /// <summary>
        /// Remove a log Handler.
        /// </summary>		
        public void RemoveHandler(LogHandler handler)
        {
            if (_handlers == null)
                return;
            //throw new ArgumentNullException("handler");
            _handlers.Remove(handler);
        }

        /// <summary>
        /// Close and Remove all log handlers
        /// </summary>
        public void Shutdown()
        {
            if (_handlers == null)
                return;

            lock (this)
            {
                for (int i = _handlers.Count - 1; i >= 0; i--)
                {
                    (_handlers[i] as LogHandler).Dispose();
                    _handlers.RemoveAt(i);
                }
            }
        }
        /// <summary>
        /// Get the Handlers associated with this logger.
        /// </summary>
        public LogHandler[] GetHandlers()
        {
            if (_handlers == null)
                return emptyHandlers;
            LogHandler[] result = new LogHandler[_handlers.Count];
            _handlers.CopyTo(result, 0);
            return result;
        }

        internal void SetParent(Logger logger)
        {
            System.Diagnostics.Debug.Assert(logger != null);
            if (_parent != null && _parent._kids != null)
                _parent._kids.Remove(this);

            _parent = logger;
            if (_parent._kids == null)
                _parent._kids = new ArrayList();
            _parent._kids.Add(this);

            UpdateEffectiveLevel();
        }

        // Recalculate the effective level for this node and
        // recursively for our children.
        private void UpdateEffectiveLevel()
        {
            LogLevel newLevel;
            if (_myLevel != null)
            {
                newLevel = (LogLevel)_myLevel;
            }
            else
            {
                if (_parent != null)
                {
                    newLevel = _parent._effectiveLevel;
                }
                else
                {
                    // This may happen during initialization.
                    newLevel = LogLevel.Informational;
                }
            }

            // If our effective value hasn't changed, we're done.
            if (_effectiveLevel == newLevel)
                return;

            _effectiveLevel = newLevel;
            // Recursively update the level on each of our kids.
            if (_kids != null)
            {
                for (int i = 0; i < _kids.Count; i++)
                {
                    Logger kid = _kids[i] as Logger;
                    if (kid != null) kid.UpdateEffectiveLevel();
                }
            }
        }
    }
}
