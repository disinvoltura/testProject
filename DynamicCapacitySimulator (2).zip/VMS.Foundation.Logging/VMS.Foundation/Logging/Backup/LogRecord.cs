﻿using System;
using System.Runtime.Serialization;
using System.Collections;
using System.Diagnostics;

using System.Reflection;
using System.Text;
using System.Security;

namespace VMS.Foundation.Logging
{
    public class LogRecord
    {
        // The application supplied message of logging event.
        string _message;

        // The logger name.
        string _loggerName;

        // Level of logging event
        LogLevel _level;

        // The name of thread in which this logging event was generated
        string _threadName;

        // The time the event was logged
        DateTime _timeStamp;

        // The exception that was thrown.
        Exception _exception;

        string _stackTraceString;


        public LogRecord(LogLevel level, string message) : this(level, message, null) { }
        public LogRecord(LogLevel level, string message, Exception throwable)
        {
            _message = message;
            _exception = throwable;
            _level = level;
            _timeStamp = DateTime.Now;
            _threadName = GetThreadName();
        }

        /// <summary>
        /// Gets the <see cref="LogLevel" /> of the logging event.
        /// </summary>
        public LogLevel Level
        {
            get { return _level; }
        }

        /// <summary>
        /// Gets the time of the logging event.
        /// </summary>
        public DateTime TimeStamp
        {
            get { return _timeStamp; }
        }

        /// <summary>
        /// Gets the name of the logger that logged the event.
        /// </summary>
        public string LoggerName
        {
            get { return _loggerName; }
            set { _loggerName = value; }
        }


        /// <summary>
        /// Gets the message.
        /// </summary>
        public string Message
        {
            get { return _message; }
        }

        /// <summary>
        /// Gets the name of the current thread.  
        /// </summary>
        public string ThreadName
        {
            get { return _threadName; }
        }

        // The exception that was thrown.
        public Exception Exception
        {
            get { return _exception; }
        }

        /// <summary>
        /// Stack-Frame
        /// Description:
        /// 0 = own method
        /// 1 = any of the public log methods
        /// 2 = caller of a public log method (thats what we need)
        /// </summary>
        private const int STACK_FRAME = 2;

        private string GetThreadName()
        {
            string threadName = System.Threading.Thread.CurrentThread.Name;
            if (threadName == null || threadName.Length == 0)
            {
                // The thread name is not available. Therefore we
                // go the the AppDomain to get the ID of the 
                // current thread. (Why don't Threads know their own ID?)
                threadName = AppDomain.GetCurrentThreadId().ToString(System.Globalization.NumberFormatInfo.InvariantInfo);
            }
            return threadName;
        }
        public string GetStackTraceWithSourceInfo(StackTrace stackTrace)
        {
            string result = "";
            try
            {
                if (_stackTraceString == null)
                {
                    StringBuilder buf = new StringBuilder(255);
                    for (int i = 0; i < stackTrace.FrameCount; i++)
                    {
                        StackFrame frame = stackTrace.GetFrame(i);
                        buf.Append(" at ");
                        MethodBase method = frame.GetMethod();
                        Type type = method.DeclaringType;
                        if (type != null)
                        {
                            if (type.Namespace != null)
                            {
                                buf.Append(type.Namespace);
                                buf.Append(".");
                            }
                            buf.Append(type.Name);
                            buf.Append(".");
                        }

                        buf.Append(method.Name);
                        buf.Append("(");

                        ParameterInfo[] parameters = method.GetParameters();
                        for (int j = 0; j < parameters.Length; j++)
                        {
                            string typeName = "<unknownType>";
                            if (parameters[j].ParameterType != null)
                                typeName = parameters[j].ParameterType.Name;
                            buf.Append(j != 0 ? ", " : "");
                            buf.Append(typeName + " " + parameters[j].Name);
                        }
                        buf.Append(")");

                        if (frame.GetILOffset() != -1)
                        {
                            string fileName = frame.GetFileName();
                            if (fileName != null)
                                buf.Append(string.Format(" in {0}: line {1}", fileName, frame.GetFileLineNumber()));
                        }
                        if (i != stackTrace.FrameCount - 1)
                            buf.Append(Environment.NewLine);
                    }
                    _stackTraceString = buf.ToString();

                }
                result = _stackTraceString;

            }
            catch (SecurityException)
            {
                result = "Insufficient privilege to generate stack trace.";

            }
            catch (Exception)
            {
                result = "Unable to process stack trace.";
            }
            return result;
        }
    }
}
