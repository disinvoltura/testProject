﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VMS.Foundation.Logging
{
    public abstract class LogFormatter
    {
        // Format the given log record and return the formatted string. 
        public abstract string Format(LogRecord record);


        // Return the header string for a set of formatted records.
        public virtual string GetHeader(LogHandler h)
        {
            return string.Empty;
        }
        // Return the tail string for a set of formatted records.
        public virtual string GetFooter(LogHandler h)
        {
            return string.Empty;
        }
    }
}
