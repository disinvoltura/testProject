﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VMS.Foundation.Logging
{
    public abstract class LogFilter
    {
        //Check if a given record should be published. 
        public abstract bool IsLoggable(LogRecord record);
    }

    public class InfoOnlyLogFilter:LogFilter
    {
        public override bool IsLoggable(LogRecord record)
        {
            if (record.Level == LogLevel.Informational)
                return true;
            else
                return false;
        }

    }
}
