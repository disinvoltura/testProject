﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.Models;

namespace VMS.IFS.OuputDataCollection
{
    /// <summary>
    /// Observer the processing history of equipments
    /// </summary>
    public class EquipmentObserver : EventObserver
    {
        #region Member Variables
        //Key: EQP ID
        private Dictionary<string, EquipmentHistory> _Data;
        //Key: EQP ID
        private Dictionary<string, TimeBucketTallyStatistics> _EQPOutData;
        private Dictionary<string, TimeBucketTallyStatistics> _EQPOutDataForHours;

        //Time Units per a shift (in hours)
        private int _TimeBucket;
        private int _Hours;

        //EQP 통계량 수정 위해 추가 - 김현식 / 2013.11.19
        private Dictionary<string, int> _Count;

        //EQP State merge - 김현식 / 2013.11.20
        private Dictionary<string, EquipmentState> _LastState;
        #endregion

        #region Properties
        public IEnumerable<string> Equipments
        {
            get { return _Data.Keys; }
        }

        public EquipmentHistory this[string eqpid]
        {
            get
            {
                EquipmentHistory rslt = null;
                if (_Data.ContainsKey(eqpid))
                    rslt = _Data[eqpid];

                return rslt;
            }
        }
        #endregion

        #region Constructors
        public EquipmentObserver(Dictionary<string, object> runOptions)
            : base("Equipment Observer")
        {
            _TimeBucket = (int)runOptions[SimulationArguments.UnitTime];
            _Hours = 1;

            _Data = new Dictionary<string, EquipmentHistory>();
            _EQPOutData = new Dictionary<string, TimeBucketTallyStatistics>();
            _EQPOutDataForHours = new Dictionary<string, TimeBucketTallyStatistics>();

            _Count = new Dictionary<string, int>();
            _LastState = new Dictionary<string, EquipmentState>();
        }
        #endregion

        #region Methods
        public override void Update(ObservedEvent e)
        {
            EventObservedEvent evt = (EventObservedEvent)e;

            EquipmentLog log = null;
            string eqpid = string.Empty;
            if (evt.EventObject.Name == "UniInlineCell" || 
                evt.EventObject.Name == "BiInlineCell" ||
                evt.EventObject.Name == "Oven")
            {
                if (evt.Event.Name.Equals("CD"))
                {
                    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                    eqpid = fle.EQPID;
                    log = new EquipmentLog(fle.Time, EquipmentState.Idle, fle.Cassette.ID);

                    AddTimebucketTally(evt.Time, eqpid, _EQPOutData, _TimeBucket);
                    AddTimebucketTally(evt.Time, eqpid, _EQPOutDataForHours, _Hours);

                    //EQP 통계량 수정 - 김현식 / 2013.11.19
                    _Count[eqpid]--;
                }
                else if (evt.Event.Name.Equals("FGL"))
                {
                    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                    eqpid = fle.EQPID;
                    log = new EquipmentLog(fle.Time, EquipmentState.Busy, fle.Cassette.ID);

                    //EQP 통계량 수정 - 김현식 / 2013.11.19
                    if (_Count.ContainsKey(eqpid))
                    {
                        _Count[eqpid]++;                        
                    }
                    else
                    {
                        _Count.Add(eqpid, 1);                        
                    }
                }
                else if (evt.Event.Name.Equals("SS"))
                {
                    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                    eqpid = fle.EQPID;
                    log = new EquipmentLog(fle.Time, EquipmentState.Setup, fle.Cassette.ID);                                        
                }

            }
            else if (evt.EventObject.Name == "Chamber")
            {
                if (evt.Event.Name.Equals("CD"))
                {
                    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                    eqpid = fle.EQPID;
                    log = new EquipmentLog(fle.Time, EquipmentState.Idle, fle.Cassette.ID);

                    AddTimebucketTally(evt.Time, eqpid, _EQPOutData, _TimeBucket);
                    AddTimebucketTally(evt.Time, eqpid, _EQPOutDataForHours, _Hours);

                    //EQP 통계량 수정 - 김현식 / 2013.11.19
                    _Count[eqpid]--;
                }
                else if (evt.Event.Name.Equals("GP"))
                {
                    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                    eqpid = fle.EQPID;
                    log = new EquipmentLog(fle.Time, EquipmentState.Busy, fle.Glass.CID);

                    //EQP 통계량 수정 - 김현식 / 2013.11.19
                    if (_Count.ContainsKey(eqpid))
                    {
                        _Count[eqpid]++;
                    }
                    else
                    {
                        _Count.Add(eqpid, 1);
                    }
                }
                else if (evt.Event.Name.Equals("SS"))
                {
                    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                    eqpid = fle.EQPID;
                    log = new EquipmentLog(fle.Time, EquipmentState.Setup, fle.Glass.CID);
                }
            }
            else
            {
                System.Diagnostics.Trace.WriteLine("error.");
            }

            if (string.IsNullOrEmpty(eqpid))
                return;

            //AddEquipmentLog(eqpid, log);

            //EQP 통계량 수정 - 김현식 / 2013.11.19 
            // + EQP state merge - 김현식 / 2013.11.20
            if (!_LastState.ContainsKey(eqpid))
            {
                _LastState.Add(eqpid, EquipmentState.Idle);
            }

            if (log != null && _LastState[eqpid] != log.State)
            {                
                if (log.State != EquipmentState.Idle)
                {
                    AddEquipmentLog(eqpid, log);
                    _LastState[eqpid] = log.State;
                }
                else if (log.State == EquipmentState.Idle && _Count[eqpid] == 0)
                {
                    AddEquipmentLog(eqpid, log);
                    _LastState[eqpid] = log.State;
                }
                else
                {

                }
            }
        }

        private void AddEquipmentLog(string eqpid, EquipmentLog log)
        {
            if (_Data.ContainsKey(eqpid))
            {
                EquipmentHistory history = _Data[eqpid];
                history.Add(log);
                _Data[eqpid] = history;
            }
            else
            {
                EquipmentHistory history = new EquipmentHistory(eqpid);
                history.Add(log);
                _Data.Add(eqpid, history);
            }
        }

        private void AddTimebucketTally(double time, string eqpid, Dictionary<string, TimeBucketTallyStatistics> eqpdata, int timebucket)
        {
            if (eqpdata.ContainsKey(eqpid))
            {
                TimeBucketTallyStatistics stat = eqpdata[eqpid];
                stat.Add(time);
                eqpdata[eqpid] = stat;
            }
            else
            {
                TimeBucketTallyStatistics stat = new TimeBucketTallyStatistics(eqpid + ".TimeBucketOutput", timebucket);
                stat.Add(time);
                eqpdata.Add(eqpid, stat);
            }
        }

        public override void Finalize(double eosTime)
        {
            foreach (string eqpid in _Data.Keys)
            {
                EquipmentHistory history = _Data[eqpid];
                history.Finalize(eosTime);
            }
        }

        public TimeBucketTallyStatistics GetTimeBucketOutData(string eqpid)
        {
            TimeBucketTallyStatistics rslt = null;
            if (_EQPOutData.ContainsKey(eqpid))
            {
                rslt = _EQPOutData[eqpid];
            }

            return rslt;
        }

        public TimeBucketTallyStatistics GetHourOutData(string eqpid)
        {
            TimeBucketTallyStatistics rslt = null;
            if (_EQPOutDataForHours.ContainsKey(eqpid))
            {
                rslt = _EQPOutDataForHours[eqpid];
            }

            return rslt;
        }

        public EquipmentHistory GetEQPHistoryData(string eqpid)
        {
            EquipmentHistory rslt = null;
            if (_Data.ContainsKey(eqpid))
            {
                rslt = _Data[eqpid];
            }

            return rslt;
        }
        #endregion
    }
}
