﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.Models;

namespace VMS.IFS.OuputDataCollection
{
    public class EQPWipObserver : EventObserver
    {
        #region Member Variables
        private Dictionary<string, TimeDependentStatistics> _Stat;
        private Dictionary<string, TimeBucketDependentStatistics> _EQPWIPData;
        private Dictionary<string, TimeBucketDependentStatistics> _EQPWIPHoursData;
        private Dictionary<string, int> _WIP;

        //Time Units per a shift (in hours)
        private int _ShiftTime;
        private int _Hours;
        #endregion

        #region Properties
        
        public IEnumerable<string> Equipments
        {
            get { return _Stat.Keys; }
        }

        public TimeDependentStatistics EQPWIP(string eqpid)
        {
            return _Stat[eqpid];
        }

        public double ShiftEQPWIP(string eqpid, int shift)
        {
            return _EQPWIPData[eqpid][shift];
        }

        public double HoursEQPWIP(string eqpid, int hours)
        {
            return _EQPWIPHoursData[eqpid][hours];
        }

        #endregion

        #region Constructors

        public EQPWipObserver(Dictionary<string, object> runOptions)
            : base ("EQPWIPObserver")
        {
            _ShiftTime = (int)runOptions[SimulationArguments.UnitTime];
            _Hours = 1;

            _Stat = new Dictionary<string, TimeDependentStatistics>();
            _EQPWIPData = new Dictionary<string, TimeBucketDependentStatistics>();
            _EQPWIPHoursData = new Dictionary<string, TimeBucketDependentStatistics>();

            _WIP = new Dictionary<string, int>();
        }

        #endregion

        #region Mehotds

        public override void Update(ObservedEvent e)
        {
            EventObservedEvent evt = (EventObservedEvent)e;

            string eqpid = string.Empty;
            if (evt.Event.Name == "CA")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                eqpid = fle.EQPID;

                if (_WIP.ContainsKey(eqpid))
                {
                    _WIP[eqpid]++;
                    _Stat[eqpid].Add(evt.Time, _WIP[eqpid]);
                    _EQPWIPData[eqpid].Add(evt.Time, _WIP[eqpid]);
                    _EQPWIPHoursData[eqpid].Add(evt.Time, _WIP[eqpid]);
                }
                else
                {
                    _WIP.Add(eqpid, 1);
                    _Stat.Add(eqpid, new TimeDependentStatistics("EQPWIP"));
                    _Stat[eqpid].Add(evt.Time, _WIP[eqpid]);
                    _EQPWIPData.Add(eqpid, new TimeBucketDependentStatistics("ShiftEQPWIP", _ShiftTime));
                    _EQPWIPData[eqpid].Add(evt.Time, _WIP[eqpid]);
                    _EQPWIPHoursData.Add(eqpid, new TimeBucketDependentStatistics("ShiftEQPWIP", _Hours));
                    _EQPWIPHoursData[eqpid].Add(evt.Time, _WIP[eqpid]);
                }                
            }
            else if (evt.Event.Name.Contains("CD"))
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                eqpid = fle.EQPID;

                if (_WIP.ContainsKey(eqpid))
                {
                    _WIP[eqpid]--;
                    _Stat[eqpid].Add(evt.Time, _WIP[eqpid]);
                    _EQPWIPData[eqpid].Add(evt.Time, _WIP[eqpid]);
                    _EQPWIPHoursData[eqpid].Add(evt.Time, _WIP[eqpid]);
                }
                else
                {

                }
            }
        }

        public void Initialize(Dictionary<string, int> eqp_Count)
        {
            foreach (string eqpid in eqp_Count.Keys)
            {
                _WIP.Add(eqpid, eqp_Count[eqpid]);
                _Stat.Add(eqpid, new TimeDependentStatistics("EQPWIP"));
                _Stat[eqpid].Add(0, _WIP[eqpid]);
                _EQPWIPData.Add(eqpid, new TimeBucketDependentStatistics("ShiftEQPWIP", _ShiftTime));
                _EQPWIPData[eqpid].Add(0, _WIP[eqpid]);
                _EQPWIPData[eqpid].AddInitial(_WIP[eqpid]);
                _EQPWIPHoursData.Add(eqpid, new TimeBucketDependentStatistics("HoursEQPWIP", _Hours));
                _EQPWIPHoursData[eqpid].Add(0, _WIP[eqpid]);
            }
        }

        public override void Finalize(double eosTime)
        {
            foreach (string eqpid in _Stat.Keys)
            {
                _Stat[eqpid].Add(eosTime, _WIP[eqpid]);
            }
            foreach (string eqpid in _EQPWIPData.Keys)
            {
                _EQPWIPData[eqpid].Add(eosTime, _WIP[eqpid]);
            }
            foreach (string eqpid in _EQPWIPHoursData.Keys)
            {
                _EQPWIPHoursData[eqpid].Add(eosTime, _WIP[eqpid]);
            }
        }

        #endregion
    }
}
