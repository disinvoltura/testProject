﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.OuputDataCollection
{
    public class EquipmentLog: IComparable<EquipmentLog>
    {
        #region Member Variables
        private double _Time;
        private EquipmentState _State;
        private int _CID;
        #endregion

        #region Properties
        public double Time { get { return _Time; } }
        public EquipmentState State { get { return _State; } }
        public int CassetteID { get { return _CID; } }
        #endregion

        #region Constructors
        public EquipmentLog(double time, EquipmentState state)
        {
            _Time = time;
            _State = state;
            _CID = -1;
        }

        public EquipmentLog(double time, EquipmentState state, int cid)
            : this (time, state)
        {
            _CID = cid;
        }
        #endregion

        #region Methods
        public int CompareTo(EquipmentLog other)
        {
            return this.Time.CompareTo(other.Time);
        }

        #endregion
    }
}
