﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.OuputDataCollection
{
    public class EquipmentHistory
    {
        #region Member Variables
        private string _EQPID;
        private EquipmentLog _Current;
        private List<EquipmentLog> _Logs;
        private double _IdleTimes;
        private double _RunTimes;
        private double _SetupTimes;
        private double _EOSTime;
        #endregion

        #region Properties
        public string EQPID
        {
            get { return _EQPID; }
        }

        public EquipmentLog Current
        {
            get { return _Current; }
        }

        public IEnumerable<EquipmentLog> Logs
        {
            get { return _Logs; }
        }

        public double Idle
        {
            get
            {
                return Math.Round(_IdleTimes / _EOSTime * 100, 2);
            }
        }

        public double Setup
        {
            get
            {
                return Math.Round(_SetupTimes / _EOSTime * 100, 2);
            }
        }

        public double Run
        {
            get
            {
                return Math.Round(_RunTimes / _EOSTime * 100, 2);
            }
        }
        #endregion

        #region Constructors
        /// <summary>
        /// Maanges the history of an equipment
        /// </summary>
        /// <param name="eqpid">Equipment ID</param>
        public EquipmentHistory(string eqpid)
        {
            _EQPID = eqpid;
            _Logs = new List<EquipmentLog>();

            _SetupTimes = 0;
            _IdleTimes = 0;
            _RunTimes = 0;
            _Current = new EquipmentLog(0, EquipmentState.Idle);
        }

        #endregion

        #region Methods
        private EquipmentState _LastState = EquipmentState.Idle;
        private double _LastTime = 0;
        public void Add(EquipmentLog log)
        {
            if (_Current != null)
            {
                //Utilization
                if (_Current.State  == EquipmentState.Setup)
                {
                    _SetupTimes += log.Time - _Current.Time;
                }
                else if (_Current.State == EquipmentState.Idle)
                {
                    _IdleTimes += log.Time - _Current.Time;
                }
                else if (_Current.State == EquipmentState.Busy)
                {
                    _RunTimes += log.Time - _Current.Time;
                }
            }
            _Logs.Add(log);
            _Current = log;
            _LastState = log.State;
            _LastTime = log.Time;
        }

        public void Add(double time, EquipmentState state)
        {
            EquipmentLog log = new EquipmentLog(time, state);
            this.Add(log);
        }

        public void Add(double time, EquipmentState state, int cid)
        {
            EquipmentLog log = new EquipmentLog(time, state, cid);
            this.Add(log);
        }

        /// <summary>
        /// Compute the utilization of an equipment with a given simulation time
        /// </summary>
        /// <param name="eosTime"></param>
        public void Finalize(double eosTime)
            //추후 finalize 를 abstrac method 로 정의될 수 있도록 할 것!!!
        {
            _EOSTime = eosTime;
            if (_Current == null)
                return;

            if (_LastState == EquipmentState.Setup)
            {
                _SetupTimes += _EOSTime - _LastTime;
            }
            else if (_Current.State == EquipmentState.Idle)
            {
                _IdleTimes += _EOSTime - _LastTime;
            }
            else if (_Current.State == EquipmentState.Busy)
            {
                _RunTimes += _EOSTime - _LastTime;
            }
        }
        #endregion
    }
}
