﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.OuputDataCollection
{
    public class Statistics
    {
        #region Member Variables
        protected string _Name;
        protected List<ValueChange> _ValueChanges;
        protected double _MinValue;
        protected double _MaxValue;
        #endregion

        #region Properties
        public string Name
        {
            get { return _Name; }
        }

        public List<ValueChange> ValueChanges
        {
            get { return _ValueChanges; }
        }

        public double Minimum
        {
            get { return _MinValue; }
        }

        public double Maximum
        {
            get { return _MaxValue; }
        }

        public int Count
        {
            get { return _ValueChanges.Count; }
        }
        #endregion

        #region Constructors
        public Statistics(string name)
        {
            _Name = name;
            _ValueChanges = new List<ValueChange>();
            _MinValue = double.MaxValue;
            _MaxValue = double.MinValue;
        }
        #endregion

        #region Methods
        public virtual void Add(double time, double val)
        {
            ValueChange record = new ValueChange();
            record.Time = time;
            record.Value = val;

            _ValueChanges.Add(record);

            if (val < _MinValue)
                _MinValue = val;

            if (val > _MaxValue)
                _MaxValue = val;
        }
        #endregion
    }
}
