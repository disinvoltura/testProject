﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.OuputDataCollection
{
    public class SampleStatistics : Statistics
    {
        #region Member Variables
        private double _Mean;
        private double _Variance;
        private double _SD;
        private double _Diff;
        private double _LastTime;
        private double _StartTime;
        #endregion

        #region Properties
        public double Mean
        {
            get { return _Mean; }
        }

        public double Variance
        {
            get { return _Variance; }
        }

        public double StandarDeviation
        {
            get { return _SD;}
        }
        #endregion

        #region Constructors
        public SampleStatistics(string name)
            : base(name)
        {
            _Mean = 0;
            _Variance = 0;

            _Diff = 0;
            _StartTime = 0;
            _LastTime = 0;
        }
        #endregion

        #region Methods
        public void Add(double time, double val)
        {
            base.Add(time, val);        
        }

        public void Finalize(double eosTime)
        {
            CalculateMean();
            CalculateVariance();
            _SD = Math.Sqrt(this.Variance); 
        }

        private void CalculateMean()
        {
            double sum = 0;
            foreach (ValueChange vc in _ValueChanges)
            {
                sum += vc.Value;
            }

            _Mean = sum / this.Count;
        }

        private void CalculateVariance()
        {
            double sum = 0;
            foreach (ValueChange vc in _ValueChanges)
            {
                double diff = (vc.Value - _Mean);
                sum += diff * diff;
            }

            _Variance = sum / this.Count;
        }
        
        #endregion
    }
}
