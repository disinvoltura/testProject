﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.OuputDataCollection
{
    public class CassetteHistory
    {
        #region Member Variables
        private int _CID;
        private CassetteLog _Current;
        private List<CassetteLog> _Logs;
        #endregion

        #region Properties
        public int CassetteID
        {
            get { return _CID; }
        }

        public CassetteLog Current
        {
            get { return _Current; }
        }

        public IEnumerable<CassetteLog> Logs
        {
            get { return _Logs; }
        }
        #endregion

        #region Constructors
        /// <summary>
        /// Maanges the history of a cassette
        /// </summary>
        /// <param name="cid">Cassette ID</param>
        public CassetteHistory(int cid)
        {
            _CID = cid;
            _Logs = new List<CassetteLog>();
        }

        #endregion

        #region Methods
        public void Add(CassetteLog log)
        {
            _Logs.Add(log);
            _Current = log;
        }
        #endregion
    }
}
