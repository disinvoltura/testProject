﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.Models;

namespace VMS.IFS.OuputDataCollection
{
    /// <summary>
    /// Observe the processing histroy of cassettes
    /// </summary>
    public class CassetteObserver : EventObserver
    {
        #region Member Variables
        private Dictionary<int, CassetteHistory> _Data;

        //Key: ProductID.StepID, Value: TAT
        private Dictionary<string, SampleStatistics> _ProdStepTATData;

        //Key: ProductID.StepID, Value: Count
        private Dictionary<string, TimeBucketTallyStatistics> _ProdStepOutData;
        private Dictionary<string, TimeBucketTallyStatistics> _ProdStepOutHoursData;

        private Dictionary<string, TimeBucketDependentStatistics> _TBProdStepWipData;
        private Dictionary<string, TimeBucketDependentStatistics> _TBProdStepWipHoursData;

        //WIp....
        private Dictionary<string, int> _ProdStepWipData;

        //Time Units per a shift (in hours)
        private int _TimeBucket;
        private int _Hours;
        #endregion

        #region Properties
        /// <summary>
        /// List of Cassette IDs
        /// </summary>
        public IEnumerator<int> Cassettes
        {
            get { return _Data.Keys.GetEnumerator(); }
        }

        public Dictionary<string, TimeBucketTallyStatistics> StepOut
        {
            get { return _ProdStepOutData; }
        }

        public Dictionary<string, TimeBucketTallyStatistics> StepOutHours
        {
            get { return _ProdStepOutHoursData; }
        }

        public Dictionary<string, SampleStatistics> StepTAT
        {
            get { return _ProdStepTATData; }
        }

        public Dictionary<string, TimeBucketDependentStatistics> StepWIP
        {
            get { return _TBProdStepWipData; }
        }

        public Dictionary<string, TimeBucketDependentStatistics> StepWIPHours
        {
            get { return _TBProdStepWipHoursData; }
        }

        public SampleStatistics this[string productid, string stepid]
        {
            get
            {
                SampleStatistics rslt = null;
                string key = string.Format("{0}.{1}", productid, stepid);
                if (_ProdStepTATData.ContainsKey(key))
                    rslt = _ProdStepTATData[key];

                return rslt;
            }
        }

        public CassetteHistory this[int cid]
        {
            get
            {
                CassetteHistory rslt = null;
                if (_Data.ContainsKey(cid))
                    rslt = _Data[cid];

                return rslt;
            }
        }
        #endregion

        #region Constructors
        public CassetteObserver(Dictionary<string, object> runOptions)
            : base("CassetteObserver")
        {
            _TimeBucket = (int)runOptions[SimulationArguments.UnitTime];
            _Hours = 1;

            _Data = new Dictionary<int, CassetteHistory>();
            _ProdStepTATData = new Dictionary<string, SampleStatistics>();
            _ProdStepOutData = new Dictionary<string, TimeBucketTallyStatistics>();
            _ProdStepOutHoursData = new Dictionary<string, TimeBucketTallyStatistics>();
            _ProdStepWipData = new Dictionary<string, int>();
            _TBProdStepWipData = new Dictionary<string, TimeBucketDependentStatistics>();
            _TBProdStepWipHoursData = new Dictionary<string, TimeBucketDependentStatistics>();
        }
        #endregion

        #region Methods
        public override void Update(ObservedEvent e)
        {
            EventObservedEvent evt = (EventObservedEvent)e;

            CassetteLog log = null;
            int cid = 0;
            
            if (evt.Event.Name.Equals("CD"))
            {
                //Log Unloaded Cassette
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                cid = fle.Cassette.ID;
                log = new CassetteLog(fle.Time, fle.Cassette.RBID, fle.Cassette.J, fle.Cassette.ID, CassetteState.Unloaded, fle.EQPID, fle.Cassette.P, fle.Cassette.D);
                
                string key = string.Format("{0}.{1}", _Data[cid].Current.ProductID, _Data[cid].Current.ProcessingStep);
                
                //ProductStep TAT
                double stepTAT = e.Time - _Data[cid].Current.Time;
                addProdStepTAT(key, e.Time, stepTAT);

                //ProductStep Output
                addProdStepOut(key, e.Time, _ProdStepOutData, _TimeBucket);
                addProdStepOut(key, e.Time, _ProdStepOutHoursData, _Hours);

                //ProductStep WIP
                deQueue(key);
                addProdStepWip(key, e.Time, _ProdStepWipData[key], _TBProdStepWipData, _TimeBucket);
                addProdStepWip(key, e.Time, _ProdStepWipData[key], _TBProdStepWipHoursData, _Hours);

                addCassetteLog(cid, log);

            }
            else if (evt.Event.Name.Equals("CA"))
            {
                //Arrive Cassette to the queue of next equipment
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                cid = fle.Cassette.ID;
                log = new CassetteLog(fle.Time, fle.Cassette.RBID, fle.Cassette.J, fle.Cassette.ID, CassetteState.Arrived, fle.EQPID, fle.Cassette.P, fle.Cassette.D);
                addCassetteLog(cid, log);
                
                //ProductStep WIP
                string key = string.Format("{0}.{1}", _Data[cid].Current.ProductID, _Data[cid].Current.ProcessingStep);
                enQueue(key);
                addProdStepWip(key, e.Time, _ProdStepWipData[key], _TBProdStepWipData, _TimeBucket);
                addProdStepWip(key, e.Time, _ProdStepWipData[key], _TBProdStepWipHoursData, _Hours);
            }

            
        }

        public void enQueue(string key)
        {
            if (_ProdStepWipData.ContainsKey(key))
            {
                _ProdStepWipData[key] = _ProdStepWipData[key] + 1;
            }
            else
            {
                _ProdStepWipData.Add(key, 1);
            }
        }

        private void deQueue(string key)
        {
            if (_ProdStepWipData.ContainsKey(key))
            {
                _ProdStepWipData[key] = _ProdStepWipData[key] - 1;
            }
        }

        private void addProdStepOut(string key, double time, Dictionary<string, TimeBucketTallyStatistics> dic, int timebucket)
        {
            if (dic.ContainsKey(key))
            {
                TimeBucketTallyStatistics stat = dic[key];
                stat.Add(time);
                dic[key] = stat;
            }
            else
            {
                TimeBucketTallyStatistics stat = new TimeBucketTallyStatistics(key+".Tally", timebucket);
                stat.Add(time);
                dic.Add(key, stat);
            }
        }

        private void addProdStepWip(string key, double time, int val, Dictionary<string, TimeBucketDependentStatistics> dic, int timebucket)
        {
            if (dic.ContainsKey(key))
            {
                TimeBucketDependentStatistics stat = dic[key];
                stat.Add(time, val);
                
                dic[key] = stat;
            }
            else
            {
                TimeBucketDependentStatistics stat = 
                    new TimeBucketDependentStatistics(key + ".WIP", timebucket);
                stat.Add(time, val);
                dic.Add(key, stat);
            }
        }        

        private void addProdStepTAT(string key, double time, double stepTAT)
        {
            if (_ProdStepTATData.ContainsKey(key))
            {
                SampleStatistics stat = _ProdStepTATData[key];
                stat.Add(time, stepTAT);
                _ProdStepTATData[key] = stat;
            }
            else
            {
                SampleStatistics stat = new SampleStatistics("ProductStepTAT");
                stat.Add(time, stepTAT);
                _ProdStepTATData.Add(key, stat);
            }
        }

        public void addCassetteLog(int cid, CassetteLog log)
        {
            if (_Data.ContainsKey(cid))
            {
                CassetteHistory history = _Data[cid];
                history.Add(log);
                _Data[cid] = history;
            }
            else
            {
                CassetteHistory history = new CassetteHistory(cid);
                history.Add(log);
                _Data.Add(cid, history);
            }
        }

        public void InitializeProductStepWIP()
        {
            foreach (string key in _ProdStepWipData.Keys)
            {
                TimeBucketDependentStatistics stat =
                    new TimeBucketDependentStatistics(key + ".WIP", _TimeBucket);
                stat.AddInitial(_ProdStepWipData[key]);
                _TBProdStepWipData.Add(key, stat);
            }
        }

        public override void Finalize(double eosTime)
        {
            foreach (string key in _ProdStepTATData.Keys)
            {
                SampleStatistics stat = _ProdStepTATData[key];
                stat.Finalize(eosTime);
            }
        }

        public TimeBucketTallyStatistics GetStepOut(string productid, string stepid)
        {
            TimeBucketTallyStatistics rslt = null;
            string key = string.Format("{0}.{1}", productid, stepid);
            if (_ProdStepOutData.ContainsKey(key))
                rslt = _ProdStepOutData[key];

            return rslt;
        }

        public TimeBucketDependentStatistics GetStepWIP(string productid, string stepid)
        {
            TimeBucketDependentStatistics rslt = null;
            string key = string.Format("{0}.{1}", productid, stepid);
            if (_TBProdStepWipData.ContainsKey(key))
                rslt = _TBProdStepWipData[key];

            return rslt;
        }

        public SampleStatistics GetStepTAT(string productid, string stepid)
        {
            SampleStatistics rslt = null;
            string key = string.Format("{0}.{1}", productid, stepid);
            if (_ProdStepTATData.ContainsKey(key))
                rslt = _ProdStepTATData[key];

            return rslt;
        }
        #endregion
    }
}
