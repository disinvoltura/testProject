﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.Models;

namespace VMS.IFS.OuputDataCollection
{
    public class CassetteTATObserver : EventObserver
    {
        #region Member Variables
        //Key: cassette id, value: pair of fabin and fabout time
        private Dictionary<int, double[]> _Data;

        //Key: product id, value: sample stat for a product
        private Dictionary<string, SampleStatistics> _Stats;

        private string _FabInObjectName = "FabIn";
        private string _FabInEventName = "Move";
        private string _FabOutObjectName = "FabOut";
        private string _FabOutEventname = "CFO";
        #endregion

        #region Properties
        public SampleStatistics this[string productid]
        {
            get
            {
                SampleStatistics rslt = null;
                if (_Stats.ContainsKey(productid))
                    rslt = _Stats[productid];
                return rslt;
            }
        }
        #endregion

        #region Constructors
        public CassetteTATObserver(Dictionary<string, object> runOptions)
            : base("TATObserver")
        {
            _Data = new Dictionary<int, double[]>();
            _Stats = new Dictionary<string, SampleStatistics>();
        }
        #endregion

        #region Methods
        public override void Update(ObservedEvent e)
        {
            EventObservedEvent evt = (EventObservedEvent)e;
            
            if (evt.EventObject.Name == _FabInObjectName &&
                evt.Event.Name == _FabInEventName)
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                double[] times = new double[] { e.Time, 0 };

                _Data.Add(fle.Cassette.ID, times);
            }
            else if (evt.EventObject.Name == _FabOutObjectName &&
                     evt.Event.Name == _FabOutEventname)
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                if (_Data.ContainsKey(fle.Cassette.ID))
                {
                    double[] times = _Data[fle.Cassette.ID];
                    times[1] = fle.Time;

                    if (_Stats.ContainsKey(fle.Cassette.J))
                    {
                        SampleStatistics stat = _Stats[fle.Cassette.J];
                        stat.Add(fle.Time, times[1] - times[0]); //seconds
                        _Stats[fle.Cassette.J] = stat;
                    }
                    else
                    {
                        SampleStatistics stat = new SampleStatistics("Product TAT: " + fle.Cassette.J);
                        stat.Add(fle.Time, times[1] - times[0]); //seconds
                        _Stats.Add(fle.Cassette.J, stat);
                    }
                }
            }
        }

        public override void Finalize(double eosTime)
        {
            foreach (string productid in _Stats.Keys)
            {
                SampleStatistics stat = _Stats[productid];
                stat.Finalize(eosTime);
            }
        }
        #endregion
    }
}
