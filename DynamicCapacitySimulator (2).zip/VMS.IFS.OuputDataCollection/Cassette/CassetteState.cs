﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.OuputDataCollection
{
    public enum CassetteState
    {
        FabIn, Loaded, Unloaded, Arrived, FabOut
    };
}
