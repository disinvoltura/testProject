﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.Models;

namespace VMS.IFS.OuputDataCollection
{
    public class FabWipObserver : EventObserver
    {
        #region Member Variables
        private TimeDependentStatistics _Stat;
        private TimeBucketDependentStatistics _ShiftWIPData;
        private int _WIP;

        private string _FabInObjectName = "FabIn";
        private string _FabInEventName = "Move";
        private string _FabOutObjectName = "FabOut";
        private string _FabOutEventname = "CFO";

        //Time Units per a shift (in hours)
        private int _ShiftTime;
        #endregion

        #region Properties
        public TimeDependentStatistics FabWIP
        {
            get { return _Stat; }
        }

        public TimeBucketDependentStatistics ShiftFabWIP
        {
            get { return _ShiftWIPData; }
        }
        #endregion

        #region Constructors
        public FabWipObserver(Dictionary<string, object> runOptions)
            : base ("FabWIPObserver")
        {
            _ShiftTime = (int)runOptions[SimulationArguments.UnitTime]; 

            _Stat = new TimeDependentStatistics("FabWIP");
            _ShiftWIPData = new TimeBucketDependentStatistics("ShiftFabWIP", _ShiftTime);

            _WIP = 0;
        }

        #endregion

        #region Methods
        public override void Update(ObservedEvent e)
        {
            EventObservedEvent evt = (EventObservedEvent)e;

            if (evt.EventObject.Name == _FabInObjectName &&
                evt.Event.Name == _FabInEventName)
            {
                _WIP++;
                _Stat.Add(evt.Time, _WIP);
                _ShiftWIPData.Add(evt.Time, _WIP);
            }
            else if (evt.EventObject.Name == _FabOutObjectName &&
                     evt.Event.Name == _FabOutEventname)
            {
                _WIP--;
                _Stat.Add(evt.Time, _WIP);
                _ShiftWIPData.Add(evt.Time, _WIP);
            }
        }

        public void Initialize(int wip)
        {
            _WIP = wip;
            _Stat.Add(0, _WIP);
            _ShiftWIPData.AddInitial(_WIP);
            _ShiftWIPData.Add(0, _WIP);
        }

        public override void Finalize(double eosTime)
        {
            _Stat.Add(eosTime, _WIP);
            _ShiftWIPData.Add(eosTime, _WIP);
        }
        #endregion
    }
}
