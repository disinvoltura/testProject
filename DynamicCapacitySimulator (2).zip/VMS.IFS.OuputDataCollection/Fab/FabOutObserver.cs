﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.Models;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.OuputDataCollection
{
    public class FabOutObserver : EventObserver
    {
        #region Member Variables
        private TimeBucketTallyStatistics _Tally;

        // Key: release batch id, value: number of glasses finished within due date
        private Dictionary<string, int> _DueDates;

        //Number of cassettes that exit the fab per shift
        private Dictionary<string, TimeBucketTallyStatistics> _ProductTally;
        
        //Time Units per a shift (in hours)
        private int _TimeBucket;

        private List<CassetteLog> _Logs;
        #endregion

        #region Properties
        public TimeBucketTallyStatistics Statistics
        {
            get { return _Tally; }
        }

        public IEnumerable<CassetteLog> Logs
        {
            get { return _Logs; }
        }

        public TimeBucketTallyStatistics this[string productid]
        {
            get
            {
                TimeBucketTallyStatistics rslt = null;
                if (_ProductTally.ContainsKey(productid))
                    rslt = _ProductTally[productid];
                return rslt;
            }
        }

        /// <summary>
        /// Number of cassettes that satisfy the due date
        /// </summary>
        public Dictionary<string, int> NumberOfSatisfiedCassettes
        {
            get
            {
                return _DueDates;
            }
        }
        #endregion

        #region Constructors
        public FabOutObserver(Dictionary<string, object> runOptions)
            : base("FabOutObserver")
        {
            _TimeBucket = (int)runOptions[SimulationArguments.UnitTime]; 

            _Tally = new TimeBucketTallyStatistics(
                            "Number of FabOut Cassettes",
                            _TimeBucket);

            _ProductTally = new Dictionary<string, TimeBucketTallyStatistics>();

            _Logs = new List<CassetteLog>();
            _DueDates = new Dictionary<string, int>();
        }
        #endregion

        #region Methods
        public override void Update(ObservedEvent e)
        {
            EventObservedEvent evt = (EventObservedEvent)e;
            if ((evt.EventObject.Name == "FabOut") && 
                (evt.Event.Name == "CFO"))
            {
                _Tally.Add(e.Time);

                if (evt.Event is FactoryLocalEvent)
                {
                    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                    CassetteLog log = new CassetteLog(e.Time, fle.Cassette.RBID, fle.Cassette.J, fle.Cassette.ID, CassetteState.FabOut, e.EventObject.Name, "", "");
                    _Logs.Add(log);

                    if (fle.Time <= fle.Cassette.DueDate)
                    {
                        if (_DueDates.ContainsKey(fle.Cassette.RBID))
                            _DueDates[fle.Cassette.RBID] = _DueDates[fle.Cassette.RBID] + fle.Cassette.N;
                        else
                            _DueDates.Add(fle.Cassette.RBID, fle.Cassette.N);
                    }

                    string prodid = fle.Cassette.J;
                    if (_ProductTally.ContainsKey(prodid))
                    {
                        TimeBucketTallyStatistics stat = _ProductTally[prodid];
                        stat.Add(e.Time);
                        _ProductTally[prodid] = stat;
                    }
                    else
                    {
                        TimeBucketTallyStatistics stat = new TimeBucketTallyStatistics(prodid + ".ShiftTally", _TimeBucket);
                        stat.Add(e.Time);
                        _ProductTally.Add(prodid, stat);
                    }
                }
            }
        }

        public override void Finalize(double eosTime)
        {
            
        }

        #endregion
    }
}
