﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.Models;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.OuputDataCollection
{
    public class FabInObserver : EventObserver
    {
        #region Member Variables
        //Name of an event that this observer will listen
        private TimeBucketTallyStatistics _Tally;
        //Number of cassettes that released into the fab per shift
        private Dictionary<string, TimeBucketTallyStatistics> _ProductTally;

        //Time Units per a shift (in hours)
        private int _ShiftTime;
        private List<CassetteLog> _Logs;
        #endregion

        #region Properties
        public TimeBucketTallyStatistics Statistics
        {
            get { return _Tally; }
        }
        public IEnumerable<CassetteLog> Logs
        {
            get { return _Logs; }
        }

        public TimeBucketTallyStatistics this[string productid]
        {
            get {
                TimeBucketTallyStatistics rslt = null;
                if (_ProductTally.ContainsKey(productid))
                    rslt = _ProductTally[productid];
                return rslt; 
            }
        }
        #endregion

        #region Constructors
        public FabInObserver(Dictionary<string, object> runOptions)
            : base("FabInObserver")
        {
            _ShiftTime =(int)runOptions[SimulationArguments.UnitTime]; 
            _Tally = new TimeBucketTallyStatistics(
                        "Number of FabIn Cassettes", _ShiftTime);

            _ProductTally = new Dictionary<string, TimeBucketTallyStatistics>();
            _Logs = new List<CassetteLog>();
        }

        #endregion

        #region Methods
        public override void Update(ObservedEvent e)
        {
            EventObservedEvent evt = (EventObservedEvent)e;
            if ((evt.EventObject.Name == "FabIn") && 
                (evt.Event.Name == "Move"))
            {
                _Tally.Add(e.Time);

                if (evt.Event is FactoryLocalEvent)
                {
                    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                    CassetteLog log = new CassetteLog(e.Time, fle.Cassette.RBID, fle.Cassette.J, fle.Cassette.ID, CassetteState.FabIn, e.EventObject.Name, fle.Cassette.P, fle.Cassette.D);
                    _Logs.Add(log);

                    string prodid = fle.Cassette.J;
                    if (_ProductTally.ContainsKey(prodid))
                    {
                        TimeBucketTallyStatistics stat = _ProductTally[prodid];
                        stat.Add(e.Time);
                        _ProductTally[prodid] = stat;
                    }
                    else
                    {
                        TimeBucketTallyStatistics stat = new TimeBucketTallyStatistics(prodid + ".ShiftTally", _ShiftTime);
                        stat.Add(e.Time);
                        _ProductTally.Add(prodid, stat);
                    }
                }
            }
        }

        public override void Finalize(double eosTime)
        {

        }
        #endregion
    }
}
