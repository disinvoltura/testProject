﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.Foundation.Logging;


namespace VMS.IFS.Engine
{    
    public class SimulationCoordinator
    {
        #region Member Variables
        private EventList<CoordinatorEvent> _FEL;
        private EventList<LocalEvent> _LEL;

        private Dictionary<string, EventObjectSimulator> _ObjectList;

        private EndOfSimulation _EOS;
        private double _Clock;

        private int _SC;
        private bool _RSV;

        private const string ScheduleLE = "ScheduleLE";
        private const string GetNextLE = "GetNextLE";
        private const string ExecuteLE = "ExecuteLE";
        private const string Terminate = "Terminate";

        Logger _Logger;
        #endregion

        #region Properties
        public double Clock
        {
            get { return _Clock; }
        }

        public double EOSClock
        {
            get { return _EOS.EOSTime; }
        }
        #endregion

        #region Constructors
        public SimulationCoordinator()
        {
            _Logger = LogManager.GetLogger("SimulationCoordinator");
            _ObjectList = new Dictionary<string, EventObjectSimulator>();
            Initialize();
        }
        #endregion

        #region Methods
        public void AddEventObjectSimulator(EventObjectSimulator eo)
        {
            if (!_ObjectList.ContainsKey(eo.Name))
            {
                _ObjectList.Add(eo.Name, eo);
            }
            else
            {
                _Logger.Error("Event Object Simulator <" + eo.Name + "> is already registerd.");
            }
        }

        public void Initialize()
        {
            _FEL = new EventList<CoordinatorEvent>();
            _LEL = new EventList<LocalEvent>();
            _EOS = new EndOfSimulation(this);
        }

        public bool Run()
        {
            _Logger.Debug("Coordinator runs");
            _Clock = 0;
            
            bool rslt = true;

            Execute_Initialize_Routine();

            while (!_EOS.StopCondition)
            {
                CoordinatorEvent nextEvent = RetrieveEvent();
                if (nextEvent == null)
                    break;//irregular abort.
                _Clock = nextEvent.Time;

                switch (nextEvent.Name)
                {
                    case ScheduleLE: {
                        Execute_ScheduleLE_Routine(nextEvent.e, _Clock);
                        break; }
                    case GetNextLE: {
                            Execute_GetNextLE_Routine(_Clock);
                            break; }
                    case ExecuteLE: {
                            Execute_ExecuteLE_Routine(nextEvent.e, _Clock);
                            break; }
                    case Terminate: {
                            Execute_Terminate_Routine(_Clock);
                            break; }
                }

                _Logger.Debug("Coordinator Event is executed : " + nextEvent.ToString());
            }

            _Logger.Debug("Coordinator ends");

            return rslt;
        }

        public void Abort()
        {
            _EOS.Abort();
        }

        #endregion

        #region Event Routines
        public void Execute_Initialize_Routine()
        {
            //Initialize State Variables
            _SC = 1;
            _RSV = false;
            _Clock = 0;

            foreach (string name in _ObjectList.Keys)
            {
                EventObjectSimulator objectSimulator = _ObjectList[name];
                objectSimulator.Run();
            }

            //ScheduleEvent()
        }

        public void Execute_ScheduleLE_Routine(LocalEvent e, double now)
        {
            _LEL.ScheduleEvent(e);
            if (_SC == 1)
            {
                _SC = -1;
                _RSV = true;
            }
            else
            {
                _RSV = false;
            }

            if (_RSV)
                ScheduleEvent(GetNextLE, now);
        }

        public void Execute_GetNextLE_Routine(double now)
        {
            _SC = 0;
            LocalEvent e = _LEL.RetrieveEvent();
            if (e != null)
            {
                if (_EOS.CanSchedule(e))
                    ScheduleEvent(ExecuteLE, e.Time, e);
                else
                    ScheduleEvent(Terminate, now);

            }
        }

        public void Execute_ExecuteLE_Routine(LocalEvent e, double now)
        {
            ExecuteLocalEvent(e);
            if (_LEL.Count > 0)
            {
                _SC = -1; _RSV = true;
            }
            else
            {
                _SC = 1; _RSV = false;
            }
            if (_RSV)
                ScheduleEvent(GetNextLE, now);
        }

        public void Execute_Terminate_Routine(double now)
        {

        }
        #endregion

        #region CoordinatorEvent List Methods
        private void CancelEvent(CoordinatorEvent e)
        {
            _FEL.CancelEvent(e);
        }

        private void CancelEvent(string eventName)
        {
            _FEL.CancelEvent(eventName);
        }
        
        private CoordinatorEvent RetrieveEvent()
        {
            CoordinatorEvent e= _FEL.RetrieveEvent();
            
            return e;
        }

        private void ScheduleEvent(string eventName, double time)
        {
            _FEL.ScheduleEvent(new CoordinatorEvent(eventName, time));
        }

        private void ScheduleEvent(string eventName, double time, LocalEvent e) 
        {
            _FEL.ScheduleEvent(new CoordinatorEvent(eventName, time, e));
        }

        #endregion

        #region LocalEvent List Methods

        public void ExecuteLocalEvent(LocalEvent e)
        {
            if (!string.IsNullOrEmpty(e.ObjectName))
            {
                if (_ObjectList.ContainsKey(e.ObjectName))
                {
                    EventObjectSimulator objectSimulator = _ObjectList[e.ObjectName];
                    objectSimulator.ExecuteLocalEvent(e);
                    
                    objectSimulator.NotifyEventObservers(
                        new EventObservedEvent(this.Clock, _ObjectList[e.ObjectName], e));

                }
            }
        }

        public void ScheduleLocalEvent(LocalEvent e)
        {
            ScheduleEvent(ScheduleLE, this.Clock, e);
        }
        #endregion

        #region EOS methods
        /// <summary>
        /// Declare that the simulation ends when the simulation clock rearches the EOS time.
        /// </summary>
        /// <param name="eosTime">End-of-simulation Time</param>
        public void StopAtTime(double time)
        {
            _EOS.StopAtTime(time);
        }

        /// <summary>
        /// Declare that the simulation ends when an coordinator's event occurs a certain number of times.
        /// </summary>
        /// <param name="eventName">Name of an event that belongs to Coordinator</param>
        /// <param name="frequency">Number of the event occurrence</param>
        public void StopOnEvent(string eventName, int frequency)
        {
            _EOS.StopOnEvent(eventName, frequency);
        }

        /// <summary>
        /// Declare that the simulation ends when an object's event occurs a certain number of times.
        /// </summary>
        /// <param name="objectName">Name of an object</param>
        /// <param name="eventName">Name of an event</param>
        /// <param name="frequency">Number of the event occurrence</param>
        public void StopOnEvent(string objectName, string eventName, int frequency)
        {
            _EOS.StopOnEvent(objectName, eventName, frequency);
        }
        
        #endregion
    }
}
