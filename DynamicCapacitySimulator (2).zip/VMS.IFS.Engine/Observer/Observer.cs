﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.Engine
{
    public abstract class Observer
    {
        #region Member Variables
        private string _Name;

        #endregion

        #region Properties
        public string Name
        {
            get { return _Name; }
        }
        #endregion

        #region Constructors
        public Observer(string name)
        {
            _Name = name;
        }
        #endregion

        #region Methods
        public abstract void Update(ObservedEvent e);

        public abstract void Finalize(double eosTime);

        public override bool Equals(object obj)
        {
            bool rslt = false;
            if (obj is Observer)
            {
                Observer obs = (Observer)obj;
                rslt = this.Name.Equals(obs.Name); 
            }

            return rslt;
        }


        #endregion
    }
}
