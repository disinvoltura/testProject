﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.Engine
{
    public class ObservedEvent
    {
        #region Member Variables
        //private string _Name;
        private double _Time;
        private EventObjectSimulator _EventObject;
        #endregion

        #region Properties
        //public string Name
        //{
        //    get { return _Name; }
        //}

        public double Time
        {
            get { return _Time; }
        }

        public EventObjectSimulator EventObject
        {
            get { return _EventObject; }
        }
        #endregion

        #region Constructors
        public ObservedEvent(double time, EventObjectSimulator eventobject)
        {
            _Time = time;
            _EventObject = eventobject;
        }

        //public ObservedEvent(string name, double time, EventObjectSimulator eventobject)
        //{
        //    _Name = name;
        //    _Time = time;
        //    _EventObject = eventobject;
        //}
        #endregion

        #region Methods

        #endregion
    }
}
