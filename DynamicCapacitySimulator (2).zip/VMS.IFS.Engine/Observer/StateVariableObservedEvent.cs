﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.Engine
{
    public class StateVariableObservedEvent: ObservedEvent
    {
        #region Member Variables
        private string _SVName;
        private object _SVValue;
        #endregion

        #region Properties
        public string StateVariableName
        {
            get { return _SVName; }
        }

        public object StateVariableValue
        {
            get { return _SVValue; }
        }
        #endregion

        #region Constructors
        public StateVariableObservedEvent(double time, EventObjectSimulator eventobject, string svName, object svValue)
            : base(time, eventobject)
        {
            _SVName = svName;
            _SVValue = svValue;
        }
        #endregion

        #region Methods

        #endregion
    }
}
