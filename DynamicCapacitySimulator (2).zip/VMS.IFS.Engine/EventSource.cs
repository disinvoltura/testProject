﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.Engine
{
    public class EventSource
    {
        #region Member Variables
        private Dictionary<string, EventObserver> _Observers;
        #endregion

        #region Properties

        #endregion

        #region Constructors
        public EventSource()
        {
            _Observers = new Dictionary<string,EventObserver>();
        }
        #endregion

        #region Methods
        public void AddEventObserver(EventObserver eo)
        {

        }

        public void RemoveEventObserver(EventObserver eo)
        {

        }

        public void NotifyEventObservers(EventObservedEvent e)
        {

        }
        #endregion
    }
}
