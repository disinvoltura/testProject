﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.Models;
using VMS.Foundation.Logging;

namespace VMS.IFS.DecisionLogics
{
    public class SimpleMachineSelectionRule : MachineSelectionRule
    {
        private Logger _Logger;

        public SimpleMachineSelectionRule(Factory factory)
            : base("Simple Machine Selection Rule", factory)
        {
            _Logger = LogManager.GetLogger("MachineSelectionRule");
        }

        public override string NextEQP(Foup cst)
        {
            //Min Queue

            string[] loadables = _Factory.MasterData.Loadable[cst.J, cst.P];

            if (loadables == null || loadables.Length == 0)
                return string.Empty;

            double nextPriority = double.MaxValue;
            string nextEQPID = string.Empty;

            foreach (string eqpid in loadables)
            {
                MachineInfo machine = _Factory.GetMachine(eqpid);
                double priority = machine.Q + machine.N;
                _Logger.Debug(" - " + machine.ID + " (Q = " + machine.Q + ", N = " + machine.N + ") = " + priority);

                if (priority <= nextPriority)
                {
                    nextPriority = priority;
                    nextEQPID = eqpid;
                }
            }

            return nextEQPID;
        }
    }
}
