﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.Models;

namespace VMS.IFS.DecisionLogics
{
    public class FIFOJobSelectionRule: JobSelectionRule
    {
        public FIFOJobSelectionRule(Factory factory) 
            : base("FIFO Job Selection Rule", factory)
        {
        }

        public override int NextCassette(string eqpid, FoupCollection cstlist)
        {
            //Arrival Time 기준
            List<Foup> cassettes = cstlist.Cassettes.ToList<Foup>();
            
            cassettes.Sort(new FIFOCassetteComparer());

            return cassettes[0].ID;
        }
    }

    public class FIFOCassetteComparer : IComparer<Foup>
    {
        public FIFOCassetteComparer()
        {
        }

        int IComparer<Foup>.Compare(Foup x, Foup y)
        {
            return x.ArrivalDate.CompareTo(y.ArrivalDate);
        }
    }
}
