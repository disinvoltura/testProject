﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Troschuetz.Random;

namespace VMS.Foundation.RandomVariate
{
    public static class RandomVariateFactory
    {
        private static int _Seed;

        private static Troschuetz.Random.Generator _Generator;

        public static void Initialize(int seed)
        {
            _Seed = seed;
        }

        public static void Start()
        {
            _Generator = new Troschuetz.Random.MT19937Generator(_Seed);
        }

        public static void Stop()
        {
            _Generator.Reset();
        }

        public static Troschuetz.Random.Distribution Create(string name, params double[] args)
        {
            Troschuetz.Random.Distribution dist = null;
            switch(name.ToLower()){
                case "uniform":
                    {
                        dist = new Troschuetz.Random.ContinuousUniformDistribution(_Generator);
                        break;
                    }
                case "normal":
                    {
                        Troschuetz.Random.NormalDistribution normal = new Troschuetz.Random.NormalDistribution(_Generator);

                        if (args == null || args.Length != 2)
                            throw new ArgumentException("Lack of arguments: Normal distribution needs two arguments");

                        normal.Mu = args[0];
                        normal.Sigma = args[1];

                        dist = normal;

                        break;
                    }
                case "gamma":
                    {
                        Troschuetz.Random.GammaDistribution gamma = new Troschuetz.Random.GammaDistribution(_Generator);

                        if (args == null || args.Length != 2)
                            throw new ArgumentException("Lack of arguments: gamma distribution needs two arguments");

                        gamma.Alpha= args[0];
                        gamma.Theta = args[1];

                        dist = gamma;

                        break;
                    }
                case "beta":
                    {
                        Troschuetz.Random.BetaDistribution beta = new Troschuetz.Random.BetaDistribution(_Generator);

                        if (args == null || args.Length != 2)
                            throw new ArgumentException("Lack of arguments: beta distribution needs two arguments");

                        beta.Alpha = args[0];
                        beta.Beta = args[1];

                        dist = beta;

                        break;
                    }
                case "exponential":
                    {
                        Troschuetz.Random.ExponentialDistribution expo = new Troschuetz.Random.ExponentialDistribution(_Generator);

                        if (args == null || args.Length != 1)
                            throw new ArgumentException("Lack of arguments: Exponential distribution needs one argument");

                        expo.Lambda = args[0];

                        dist = expo;

                        break;
                    }
                case "weibull":
                    {
                        Troschuetz.Random.WeibullDistribution weibull = new Troschuetz.Random.WeibullDistribution(_Generator);

                        if (args == null || args.Length != 2)
                            throw new ArgumentException("Lack of arguments: Weibull distribution needs two arguments");

                        weibull.Alpha = args[0];
                        weibull.Lambda = args[1];

                        dist = weibull;

                        break;
                    }
                case "erlang":
                    {
                        Troschuetz.Random.ErlangDistribution erlang = new Troschuetz.Random.ErlangDistribution(_Generator);

                        if (args == null || args.Length != 2)
                            throw new ArgumentException("Lack of arguments: Erlang distribution needs two arguments");

                        erlang.Alpha = (int)args[0];
                        erlang.Lambda = args[1];

                        dist = erlang;

                        break;
                    }
                case "studentst":
                    {
                        Troschuetz.Random.StudentsTDistribution student = new Troschuetz.Random.StudentsTDistribution(_Generator);

                        if (args == null || args.Length != 1)
                            throw new ArgumentException("Lack of arguments: Student's T distribution needs one argument");

                        student.Nu = (int)args[0];
                        
                        dist = student;

                        break;
                    }
                case "triangular":
                    {
                        Troschuetz.Random.TriangularDistribution tri = new Troschuetz.Random.TriangularDistribution(_Generator);

                        if (args == null || args.Length != 3)
                            throw new ArgumentException("Lack of arguments: Triangular distribution needs three arguments");

                        tri.Alpha = args[0];
                        tri.Beta = args[1];
                        tri.Gamma = args[2];

                        dist = tri;

                        break;
                    }
                case "poission":
                    {
                        Troschuetz.Random.PoissonDistribution poisson = new Troschuetz.Random.PoissonDistribution(_Generator);

                        if (args == null || args.Length != 1)
                            throw new ArgumentException("Lack of arguments: Poisson distribution needs one argument");

                        poisson.Lambda = args[0];

                        dist = poisson;

                        break;
                    }
            }

            return dist;
        }

        public static NormalDistribution CreateNormal(double mu, double sigma)
        {
            Troschuetz.Random.NormalDistribution normal = new Troschuetz.Random.NormalDistribution(_Generator);

            if (!normal.IsValidMu(mu) || !normal.IsValidSigma(sigma))
                throw new ArgumentException("Invalid arguments for normal distribution - mu and sigma.");

            normal.Mu = mu;
            normal.Sigma = sigma;

            return normal;
        }

        public static GammaDistribution CreateGamma(double alpha, double theta)
        {
            Troschuetz.Random.GammaDistribution gamma = new Troschuetz.Random.GammaDistribution(_Generator);

            if (!gamma.IsValidAlpha(alpha) || !gamma.IsValidTheta(theta))
                throw new ArgumentException("Invalid arguments for gamma distribution - alpha and theta.");

            gamma.Alpha = alpha;
            gamma.Theta = theta;

            return gamma;
        }

        public static BetaDistribution CreateBeta(double alpha, double beta)
        {
            Troschuetz.Random.BetaDistribution dist = new Troschuetz.Random.BetaDistribution(_Generator);

            if (!dist.IsValidAlpha(alpha) || !dist.IsValidBeta(beta))
                throw new ArgumentException("Invalid arguments for beta distribution - alpha and beta.");

            dist.Alpha = alpha;
            dist.Beta = beta;

            return dist;
        }

        public static ExponentialDistribution CreateExponential(double lambda)
        {
            Troschuetz.Random.ExponentialDistribution dist = new Troschuetz.Random.ExponentialDistribution(_Generator);

            if (!dist.IsValidLambda(lambda))
                throw new ArgumentException("Invalid arguments for exponential distribution - lambda.");

            dist.Lambda = lambda;

            return dist;
        }

        public static WeibullDistribution CreateWeibull(double alpha, double lambda)
        {
            Troschuetz.Random.WeibullDistribution dist = new Troschuetz.Random.WeibullDistribution(_Generator);

            if (!dist.IsValidAlpha(alpha) || !dist.IsValidLambda(lambda))
                throw new ArgumentException("Invalid arguments for weibull distribution - alpha and lambda.");

            dist.Alpha = alpha;
            dist.Lambda = lambda;

            return dist;
        }

        public static ErlangDistribution CreateErlang(int  alpha, double lambda)
        {
            Troschuetz.Random.ErlangDistribution dist = new Troschuetz.Random.ErlangDistribution(_Generator);

            if (!dist.IsValidAlpha(alpha) || !dist.IsValidLambda(lambda))
                throw new ArgumentException("Invalid arguments for erlang distribution - alpha and lambda.");

            dist.Alpha = alpha;
            dist.Lambda = lambda;

            return dist;
        }

        public static StudentsTDistribution CreateStudentsT(int nu)
        {
            Troschuetz.Random.StudentsTDistribution dist = new Troschuetz.Random.StudentsTDistribution(_Generator);

            if (!dist.IsValidNu(nu) )
                throw new ArgumentException("Invalid arguments for Student's T distribution - nu.");

            dist.Nu = nu;

            return dist;
        }

        public static TriangularDistribution CreateTriangular(double alpha, double beta, double gamma)
        {
            Troschuetz.Random.TriangularDistribution dist = new Troschuetz.Random.TriangularDistribution(_Generator);

            if (!dist.IsValidAlpha(alpha) || !dist.IsValidBeta(beta) || !dist.IsValidGamma(gamma))
                throw new ArgumentException("Invalid arguments for triangular distribution - alpha, beta, and gamma.");

            dist.Alpha = alpha;
            dist.Beta = beta;
            dist.Gamma = gamma;

            return dist;
        }

        public static PoissonDistribution CreatePoisson(double lambda)
        {
            Troschuetz.Random.PoissonDistribution dist = new Troschuetz.Random.PoissonDistribution(_Generator);

            if (!dist.IsValidLambda(lambda))
                throw new ArgumentException("Invalid arguments for Poisson distribution - lambda.");

            dist.Lambda = lambda;

            return dist;
        }
    }
}
