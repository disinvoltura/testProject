﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.DataModel
{
    public class WaferCollection
    {
        #region Member Variables
        private List<Wafer> _Glasses;

        #endregion

        #region Properties
        public IEnumerable<Wafer> Glasses
        {
            get { return _Glasses; }
        }

        public int Count
        {
            get { return _Glasses.Count; }
        }
        #endregion

        #region Constructors
        public WaferCollection()
        {
            _Glasses = new List<Wafer>();
        }
        #endregion

        #region Methods
        public void Clear()
        {
            _Glasses.Clear();
        }

        public void Enqueue(Wafer gls)
        {
            _Glasses.Add(gls);
        }

        public Wafer Dequeue()
        {
            Wafer rslt = null;

            if (_Glasses.Count > 0)
            {
                rslt = _Glasses[0];
                _Glasses.RemoveAt(0);
            }

            return rslt;
        }

        public Wafer Peek()
        {
            Wafer rslt = null;

            if (_Glasses.Count > 0)
            {
                rslt = _Glasses[0];
            }

            return rslt;
        }

        /// <summary>
        /// Remove a given glass from the collection
        /// </summary>
        /// <param name="gls">Glass </param>
        public void Remove(Wafer gls)
        {
            _Glasses.Remove(gls);
        }
        #endregion
    }
}
