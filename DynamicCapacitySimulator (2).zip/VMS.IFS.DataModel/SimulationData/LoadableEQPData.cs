﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.Foundation.Logging;

namespace VMS.IFS.DataModel.SimulationData
{
    public class LoadableEQPData : MasterDataObject
    {
        #region Member Variables
        /// <summary>
        /// Declare a dictionary, which will take a string value as key 
        /// of concatenation of productid + "." + stepid and 
        /// value are an array of strings that contains the equipment id
        /// </summary>
        private Dictionary<string, List<string>> _Data;

        private Logger _Logger;
        #endregion

        #region Properties
        /// <summary>
        /// returns an string-typed arrays that contains IDs of equipments that can process a cassette of a product id and a step id
        /// </summary>
        /// <param name="productid">Product ID</param>
        /// <param name="stepid">Step ID</param>
        /// <returns>EQP IDs</returns>
        public string[] this [string productid, string stepid] {
            get { return this.Query(productid, stepid);}
        }
        #endregion

        #region Constructors
        public LoadableEQPData()
        {
            _Data = new Dictionary<string, List<string>>();

            _Logger = LogManager.GetLogger("SimulationData");
        }
        #endregion

        #region Methods
        public string[] Query(string productid, string stepid)
        {
            string[] rslt = null;
            string key = string.Format("{0}.{1}", productid, stepid);
            if (_Data.ContainsKey(key))
                rslt = _Data[key].ToArray();

            return rslt;
        }

        public override void Build(InputDataSet ds, Dictionary<string, object> args)
        {
            _Logger.Info("Start of Building LoadableEQP Data");

            if (!args.ContainsKey(SimulationArguments.LoadableEQPVersionNo))
            {
                _Logger.Error("No key found on arguments: " + SimulationArguments.LoadableEQPVersionNo);

                throw new ArgumentException("No key found on arguments: " + SimulationArguments.LoadableEQPVersionNo);
            }

            string versionNo = (string)args[SimulationArguments.LoadableEQPVersionNo];
            for(int i = 0; i < ds.LoadableSetDataTable.Count; i++){
                InputDataSet.LoadableSetDataTableRow row = ds.LoadableSetDataTable[i];

                if (row.IsPROD_IDNull())
                {
                    _Logger.Warning("Invalid LoadableEQP Data Entry: PROD_ID is null at a row " + i);
                    continue;
                }
                if (row.IsSTEP_IDNull())
                {
                    _Logger.Warning("Invalid LoadableEQP Data Entry: STEP_ID is null at a row " + i);
                    continue;
                }
                if (row.IsEQP_IDNull())
                {
                    _Logger.Warning("Invalid LoadableEQP Data Entry: EQP_ID is null at a row " + i);
                    continue;
                }

                string key = string.Format("{0}.{1}", row.PROD_ID, row.STEP_ID);
                if (_Data.ContainsKey(key)){
                    List<string> eqps = _Data[key];
                    eqps.Add(row.EQP_ID);
                    _Data[key] = eqps;
                }else{
                    List<string> eqps = new List<string>();
                    eqps.Add(row.EQP_ID);
                    _Data.Add(key, eqps);
                }
            }

            _Logger.Info("End of Building LoadableEQP Data");
        }
        #endregion
    }
}
