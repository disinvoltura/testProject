﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.Foundation.Logging;

namespace VMS.IFS.DataModel.SimulationData
{
    public struct PortData
    {
        public string EQPID;
        public int INOUT;
        public int IN;
        public int OUT;
        public string INOUTSTKID;
        public string INSTKID;
        public string OUTSTKID;
    }

    public class EQPPortData : MasterDataObject
    {
        #region Member Variables
        /// <summary>
        /// Key: EQPID, Value: number of Port
        /// </summary>
        private Dictionary<string, PortData> _Data;
        private Logger _Logger;
        #endregion

        #region Properties
        public PortData this[string eqpid]
        {
            get { return _Data[eqpid]; }
        }
        #endregion

        #region Constructors
        public EQPPortData()
        {
            _Data = new Dictionary<string, PortData>();

            _Logger = LogManager.GetLogger("SimulationData");
        }
        #endregion

        #region Methods
        public PortData Query(string eqpid)
        {
            PortData rslt = new PortData();
            if (_Data.ContainsKey(eqpid))
                rslt = _Data[eqpid];

            return rslt;
        }
        #endregion

        public override void Build(InputDataSet ds, Dictionary<string, object> args)
        {
            _Logger.Info("Start of Building EQPORT Data");

            for(int i = 0; i < ds.EQP_PortDataTable.Rows.Count; i++){
                InputDataSet.EQP_PortDataTableRow row = ds.EQP_PortDataTable[i];

                if (row.IsEQP_IDNull() || row.IsPORT_CAPANull() || row.IsPORT_TYPENull()) //|| row.IsSTK_IDNull()
                {
                    _Logger.Warning("Invalid EQP_PORT Data Entry is found at a row " + i);
                    continue;
                }

                if (_Data.ContainsKey(row.EQP_ID))
                {
                    PortData port = _Data[row.EQP_ID];
                    string portType = row.PORT_TYPE.ToLower();
                    if (portType == "u" || portType == "c" || portType == "v")
                    {
                        port.INOUT = int.Parse(row.PORT_CAPA);
                    }
                    else if (portType == "i")
                    {
                        port.IN = int.Parse(row.PORT_CAPA);
                        port.INSTKID = row.STK_ID;
                    }
                    else if (portType == "o")
                    {
                        port.OUT = int.Parse(row.PORT_CAPA);
                        port.OUTSTKID = row.STK_ID;
                    }
                    _Data[row.EQP_ID] = port;
                }
                else
                {
                    PortData port = new PortData();
                    port.EQPID = row.EQP_ID;
                    
                    string portType = row.PORT_TYPE.ToLower();
                    if (portType == "u" || portType == "c" || portType == "v")
                    {
                        port.INOUT = int.Parse(row.PORT_CAPA);
                        port.INOUTSTKID = row.STK_ID;
                    }
                    else if (portType == "i")
                    {
                        port.IN = int.Parse(row.PORT_CAPA);
                        port.INSTKID = row.STK_ID;
                    }
                    else if (portType == "o")
                    {
                        port.OUT = int.Parse(row.PORT_CAPA);
                        port.OUTSTKID = row.STK_ID;
                    }
                    _Data.Add(row.EQP_ID, port);
                }             
            }

            _Logger.Info("End of Building EQPORT Data");
        }
    }
}
