﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.DataModel.SimulationData
{
    public class NextStep
    {
        #region Member Variables
        //private string _ProductID
        private string _StepID;
        private double _Yield;
        #endregion

        #region Properties
        //public string ProductID
        //{
        //    get
        //    {
        //        return _ProductID;
        //    }
        //}

        public string StepID { get { return _StepID; } }

        public double Yield { get { return _Yield; } }
        #endregion

        #region Constructors
        //public NextStep(string id, string stepid, int yield)
        //{
        //    _ProductID = id;
        //    _StepID = stepid;
        //    _Yield = yield;
        //}
        public NextStep(string stepid, double yield)
        {
            _StepID = stepid;
            _Yield = yield;
        }
        #endregion
    }
}
