﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.Foundation.Logging;

namespace VMS.IFS.DataModel.SimulationData
{
    public class ProductData : MasterDataObject
    {
        #region Member Variables
        /// <summary>
        /// Declear product data whose key is a product id and whose value is a product
        /// </summary>
        private Dictionary<string, Product> _Data;

        private Logger _Logger;
        #endregion

        #region Properties
        /// <summary>
        /// returns a product object that matches a product id
        /// </summary>
        /// <param name="productid">Product ID</param>
        /// <returns>Product</returns>
        public Product this[string productid]
        {
            get {
                return this.Query(productid);
            }
        }

        public IEnumerable<string> Products
        {
            get { return _Data.Keys.ToArray(); }
        }
        #endregion

        #region Constructors
        public ProductData()
        {
            _Data = new Dictionary<string, Product>();

            _Logger = LogManager.GetLogger("SimulationData");
        }
        #endregion

        #region Methods
        public Product Query(string productid)
        {
            Product rslt = null;
            if (_Data.ContainsKey(productid))
                rslt = _Data[productid];
            return rslt; 
        }
        
        public override void Build(InputDataSet ds, Dictionary<string, object> args)
        {
            _Logger.Info("Start of Building Product Data");
            
            for(int i = 0; i < ds.ProductDataTable.Count; i++)
            {
                InputDataSet.ProductDataTableRow row = ds.ProductDataTable[i];
                if (row.IsPROD_IDNull() || row.IsGLASS_QTYNull() || row.IsAVG_YIELDNull())
                {
                    _Logger.Error("Invalid Product Data Entry: at least one of fields is null at a row " + i);
                    continue;
                }
                Product prd = new Product(
                                    row.PROD_ID, 
                                    int.Parse(row.GLASS_QTY), 
                                    double.Parse(row.AVG_YIELD));

                _Data.Add(prd.ProductID, prd);
            }

            _Logger.Info("End of Building Product Data");
        }
        #endregion
    }
}
