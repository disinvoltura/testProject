﻿using System;
using System.Collections.Generic;
using System.Linq;
using VMS.IFS.DataModel.InputData;
using VMS.Foundation.Logging;

namespace VMS.IFS.DataModel.SimulationData
{
    public class MoveTimeData : MasterDataObject
    {
        #region Member Variables
        /// <summary>
        /// the key of Data is EQPID.EQPID and value is moving time from a eqp to another eqp.
        /// </summary>
        private Dictionary<string, double> _Data;
        private Logger _Logger;
        #endregion

        #region Properties
        public double this[string fromEQPID, string toEQPID]
        {
            get
            {
                return this.Query(fromEQPID, toEQPID);
            }
        }
        #endregion

        #region Constructors
        public MoveTimeData()
        {
            _Data = new Dictionary<string, double>();

            _Logger = LogManager.GetLogger("SimulationData");
        }
        #endregion

        #region Methods
        public double Query(string fromEQPID, string toEQPID)
        {
            double rslt = double.MinValue;

            string key = string.Format("{0}.{1}", fromEQPID, toEQPID);
            if (_Data.ContainsKey(key))
                rslt = _Data[key];
            else
            {
                rslt = 0;
                //ERROR
                _Logger.Error("Cannot find any move time data for " + key);
            }
            return rslt;
        }

        #endregion

        public override void Build(InputDataSet ds, Dictionary<string, object> args)
        {
            _Logger.Info("Start of Building MoveTime Data");

            for (int i = 0; i < ds.MovingTimeDataTable.Count; i++)
            {
                InputDataSet.MovingTimeDataTableRow row = ds.MovingTimeDataTable[i];

                if (row.IsFROM_STKNull() || row.IsTO_STKNull() || row.IsMOVE_TIMENull())
                {
                    _Logger.Error("Invalid MoveTime Data Entry: at least one of fields is null at a row " + i);
                    continue;
                }

                string key = string.Format("{0}.{1}", row.FROM_STK, row.TO_STK);
                if (!_Data.ContainsKey(key))
                {
                    _Data.Add(key, double.Parse(row.MOVE_TIME));
                }
            }
            _Logger.Info("End of Building MoveTime Data");
        }
    }
}
