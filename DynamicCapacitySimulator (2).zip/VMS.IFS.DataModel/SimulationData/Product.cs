﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.DataModel.SimulationData
{
    public class Product
    {
        #region Member Variables
        private string _ProductID;
        private int _GlassQuantity;
        private double _AverageYield;
        #endregion

        #region Properties
        public string ProductID
        {
            get { return _ProductID; }
        }
        
        public int GlassQuantity
        {
            get { return _GlassQuantity; }
        }

        public double AverageYield
        {
            get { return _AverageYield; }
        }

        #endregion

        #region Constructors
        public Product(string id, int quantity, double yield)
        {
            _ProductID = id;
            _GlassQuantity = quantity;
            _AverageYield = yield;
        }
        #endregion

        #region Object Methods
        public override bool Equals(object obj)
        {
            bool rslt = false;
            if (obj is Product)
            {
                Product product = (Product)obj;
                rslt = product.ProductID.Equals(_ProductID);
            }

            return rslt;
        }

        public override int GetHashCode()
        {
            return _ProductID.GetHashCode();
        }
        #endregion
    }
}
