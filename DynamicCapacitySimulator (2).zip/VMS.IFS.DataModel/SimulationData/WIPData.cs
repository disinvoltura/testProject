﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.Foundation.Logging;


namespace VMS.IFS.DataModel.SimulationData
{
    public class WIPData : MasterDataObject
    {
        #region Member Variables

        private Dictionary<string, List<Foup>> _QWIPData;
        private Dictionary<string, List<Foup>> _BWIPData;
        private List<Foup> _FOData;

        #endregion        

        #region Properties
        public Dictionary<string, List<Foup>> QueueWIP
        {
            get { return _QWIPData; }
        }

        public Dictionary<string, List<Foup>> BufferWIP
        {
            get { return _BWIPData; }
        }

        public List<Foup> FabOutWIP
        {
            get { return _FOData; }
        }

        public List<Foup> this[string eqpid, string queuename]
        {
            get
            {
                if (queuename == "Q")
                {
                    if (_QWIPData.ContainsKey(eqpid))
                    {
                        return _QWIPData[eqpid];
                    }
                    else
                    {
                        return new List<Foup>();
                    }
                }
                else if (queuename == "B")
                {
                    if (_BWIPData.ContainsKey(eqpid))
                    {
                        return _BWIPData[eqpid];
                    }
                    else
                    {
                        return new List<Foup>();
                    }                    
                }
                else
                {
                    return new List<Foup>();
                }
            }
        }

        #endregion

        #region Constructor

        public WIPData()
        {
            _QWIPData = new Dictionary<string, List<Foup>>();
            _BWIPData = new Dictionary<string, List<Foup>>();
            _FOData = new List<Foup>();
        }

        #endregion

        #region Method

        public override void Build(InputDataSet ds, Dictionary<string, object> args)
        {
            foreach (InputDataSet.WIPDataTableRow dr in ds.WIPDataTable.Rows)
            {
                string eqpID = dr.EQP_ID;
                _QWIPData.Add(eqpID, new List<Foup>());
                _BWIPData.Add(eqpID, new List<Foup>());

                if (eqpID != "FabOut")
                {
                    string[] cstQs = dr.Q.Split(',', '(', ')');

                    string pIDQ = "";
                    string sIDQ = "";
                    int qtyQ = -1;
                    foreach (string str in cstQs)
                    {
                        if (str == "")
                            continue;
                        else
                        {
                            if (pIDQ == "")
                            {
                                pIDQ = str;
                            }
                            else if (sIDQ == "")
                            {
                                sIDQ = str;
                            }
                            else if (qtyQ == -1)
                            {
                                qtyQ = int.Parse(str);
                                _QWIPData[eqpID].Add(new Foup(pIDQ, sIDQ, qtyQ, eqpID));
                                pIDQ = "";
                                sIDQ = "";
                                qtyQ = -1;
                            }
                        }
                    }

                    string[] cstBs = dr.B.Split(',', '(', ')');

                    string pIDB = "";
                    string sIDB = "";
                    int qtyB = -1;
                    foreach (string str in cstBs)
                    {
                        if (str == "")
                            continue;
                        else
                        {
                            if (pIDB == "")
                            {
                                pIDB = str;
                            }
                            else if (sIDB == "")
                            {
                                sIDB = str;
                            }
                            else if (qtyB == -1)
                            {
                                qtyB = int.Parse(str);
                                _BWIPData[eqpID].Add(new Foup(pIDB, sIDB, qtyB, eqpID));
                                pIDB = "";
                                sIDB = "";
                                qtyB = -1;
                            }
                        }
                    }
                }
                else
                {
                    string[] cstFOs = dr.Q.Split(',', '(', ')');

                    string pIDFO = "";
                    int qtyFO = -1;
                    foreach (string str in cstFOs)
                    {
                        if (str == "")
                            continue;
                        else
                        {
                            if (pIDFO == "")
                            {
                                pIDFO = str;
                            }
                            else if (qtyFO == -1)
                            {
                                qtyFO = int.Parse(str);
                                _FOData.Add(new Foup(pIDFO, "", qtyFO, ""));
                                pIDFO = "";
                                qtyFO = -1;
                            }
                        }
                    }
                }
            }
        }

        public bool hasQWIP(string eqpid)
        {
            if (_QWIPData.ContainsKey(eqpid))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool hasBWIP(string eqpid)
        {
            if (_BWIPData.ContainsKey(eqpid))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void Clear()
        {
            _QWIPData = new Dictionary<string, List<Foup>>();
            _BWIPData = new Dictionary<string, List<Foup>>();
            _FOData = new List<Foup>();
        }

        public void Save(Dictionary<string, List<Foup>> Q, Dictionary<string, List<Foup>> B, List<Foup> FO)
        {
            foreach (string key in Q.Keys)
            {
                _QWIPData.Add(key, new List<Foup>());
                foreach (Foup cst in Q[key])
                {
                    Foup input = new Foup(cst.J, cst.P, cst.N, key);
                    _QWIPData[key].Add(input);
                }
            }
            foreach (string key in B.Keys)
            {
                _BWIPData.Add(key, new List<Foup>());
                foreach (Foup cst in B[key])
                {
                    Foup input = new Foup(cst.J, cst.P, cst.N, key);
                    _BWIPData[key].Add(input);
                }
            }
            foreach (Foup cst in FO)
            {
                Foup input = new Foup(cst.J, "", cst.N, "FabOut");
                _FOData.Add(input);
            }
        }
        #endregion
    }
}
