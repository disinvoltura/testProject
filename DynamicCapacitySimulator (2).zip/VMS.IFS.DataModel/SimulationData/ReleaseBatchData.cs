﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.IFS.DataModel;
using VMS.Foundation.Logging;
using System.Globalization;


namespace VMS.IFS.DataModel.SimulationData
{
    public class ReleaseBatchData : MasterDataObject
    {
        #region Member Variables
        /// <summary>
        /// Declear product data whose key is a product id and whose value is a product
        /// </summary>
        private Dictionary<string, ReleaseBatch> _Data;

        private Logger _Logger;
        #endregion

        #region Properties
        public ReleaseBatch this[string rbid]
        {
            get {
                return this.Query(rbid);
            }
        }

        public IEnumerable<string> ReleaseBatches
        {
            get { return _Data.Keys.ToArray(); }
        }
        #endregion

        #region Constructors
        public ReleaseBatchData()
        {
            _Data = new Dictionary<string, ReleaseBatch>();

            _Logger = LogManager.GetLogger("SimulationData");
        }
        #endregion

        #region Methods
        public ReleaseBatch Query(string rbid)
        {
            ReleaseBatch rslt = null;
            if (_Data.ContainsKey(rbid))
                rslt = _Data[rbid];
            return rslt; 
        }
        
        public override void Build(InputDataSet ds, Dictionary<string, object> args)
        {
            //_Logger.Info("Start of Building Order Data");

            //CultureInfo provider = CultureInfo.InvariantCulture;

            //string format = "yyyyMMddHHmm";
            //for(int i = 0; i < ds.OrderDataTable.Count; i++)
            //{
            //    InputDataSet.OrderDataTableRow row = ds.OrderDataTable[i];
            //    if (row.IsDUE_DATENull() || row.IsPROD_IDNull() || row.IsQUANTITYNull() || row.IsRBATCH_IDNull() || row.IsRELEASE_ENDNull() || row.IsRELEASE_STARTNull())
            //    {
            //        _Logger.Error("Invalid Order Data Entry: at least one of fields is null at a row " + i);
            //        continue;
            //    }

            //    ReleaseBatch rb = new ReleaseBatch(
            //        row.RBATCH_ID, 
            //        row.PROD_ID, 
            //        int.Parse(row.QUANTITY),
            //        DateTime.ParseExact(row.RELEASE_START, format, provider), DateTime.ParseExact(row.RELEASE_END, format, provider),
            //        DateTime.ParseExact(row.DUE_DATE, format, provider));
            //    _Data.Add(rb.ReleaseBatchID, rb);
            //}

            //_Logger.Info("End of Building Order Data");
        }
        #endregion
    }
}
