﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.DataModel.SimulationData
{
    public class MasterData
    {
        #region Member Variables
        private Dictionary<string, MasterDataObject> _DataObjects;
        private DateTime _RefernceStartDate;
        #endregion

        #region Properties
        public DateTime ReferenceStartDate
        {
            get { return _RefernceStartDate; }
        }
        public LoadableEQPData Loadable
        {
            get { return (LoadableEQPData)_DataObjects["Loadable"]; }
        }
        public FlowTimeData FlowTime
        {
            get { return (FlowTimeData)_DataObjects["FlowTime"]; }
        }
        public MoveTimeData MoveTime
        {
            get { return (MoveTimeData)_DataObjects["MoveTime"]; }
        }
        public TactTimeData TactTime
        {
            get { return (TactTimeData)_DataObjects["TactTime"]; }
        }
        public SetupTimeData SetupTime
        {
            get { return (SetupTimeData)_DataObjects["SetupTime"]; }
        }
        public EquipmentData EQP
        {
            get { return (EquipmentData)_DataObjects["EQP"]; }
        }
        public ProductData Product
        {
            get { return (ProductData)_DataObjects["Product"]; }
        }
        public BOPData BOP
        {
            get { return (BOPData)_DataObjects["BOP"]; }
        }
        public ReleaseBatchData ReleaseBatch
        {
            get { return (ReleaseBatchData)_DataObjects["ReleaseBatch"]; }
        }
        public EQPPortData EQPPort
        {
            get { return (EQPPortData)_DataObjects["EQPPort"]; }
        }
        public WIPData WIP
        {
            get { return (WIPData)_DataObjects["WIP"]; }
        }

        public FabOutPlanData FabOutPlan
        {
            get { return (FabOutPlanData)_DataObjects["FabOutPlan"]; }
        }

        #endregion

        public MasterData()
        {
            _DataObjects = new Dictionary<string, MasterDataObject>();

            LoadableEQPData loadable = new LoadableEQPData();
            FlowTimeData flowTime = new FlowTimeData();
            SetupTimeData setupTime = new SetupTimeData();
            MoveTimeData moveTime = new MoveTimeData();
            TactTimeData tactTime = new TactTimeData();
            EquipmentData eqp = new EquipmentData();
            ProductData product = new ProductData();
            BOPData bop = new BOPData();
            ReleaseBatchData rb = new ReleaseBatchData();
            EQPPortData port = new EQPPortData();
            WIPData wip = new WIPData();
            FabOutPlanData fabOutPlan = new FabOutPlanData();

            _DataObjects.Add("Loadable", loadable);
            _DataObjects.Add("FlowTime", flowTime);
            _DataObjects.Add("SetupTime", setupTime);
            _DataObjects.Add("MoveTime", moveTime);
            _DataObjects.Add("TactTime", tactTime);
            _DataObjects.Add("EQP", eqp);
            _DataObjects.Add("Product", product);
            _DataObjects.Add("BOP", bop);
            _DataObjects.Add("ReleaseBatch", rb);
            _DataObjects.Add("EQPPort", port);
            _DataObjects.Add("WIP", wip);
            _DataObjects.Add("FabOutPlan", fabOutPlan);
        }


        private List<string> _StepKanbanEqpList;
        private string _StepKanbanStepID;
        public List<string> StepKanbanEqpList
        {
            get { return _StepKanbanEqpList; }
        }
        public void Initialize(InputData.InputDataSet ds, Dictionary<string, object> args)
        {
            _RefernceStartDate = (DateTime) args[SimulationArguments.ReferenceDateTime];

            foreach (string key in _DataObjects.Keys)
            {
                MasterDataObject obj = _DataObjects[key];
                obj.Build(ds, args);
            }

            //Kanban
            _StepKanbanStepID = (string)args[SimulationArguments.KanbanStepID];
            _StepKanbanEqpList = new List<string>();
            foreach (string productid in this.Product.Products)
            {
                foreach (string stepid in this.BOP.ProductSteps[productid])
                {
                    if (stepid == _StepKanbanStepID)
                    {
                        string[] eqplist = this.Loadable[productid, stepid];
                        foreach (string eqpid in eqplist)
                        {
                            if (!_StepKanbanEqpList.Contains(eqpid))
                                _StepKanbanEqpList.Add(eqpid);
                        }
                    }
                }
            }
        }
    }
}
