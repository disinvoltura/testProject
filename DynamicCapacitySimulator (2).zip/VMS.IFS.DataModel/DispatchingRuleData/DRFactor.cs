﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.DataModel.DispatchingRuleData
{
    public class DRFactor
    {
        public string Name;
        public string Description;

        public string Expression;

        public DRFactor(string name, string desc, string expr)
        {
            this.Name = name;
            this.Description = desc;
            this.Expression = expr;
        }
    }
}
