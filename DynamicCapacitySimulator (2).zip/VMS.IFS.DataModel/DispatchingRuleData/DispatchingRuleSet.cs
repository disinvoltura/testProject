﻿namespace VMS.IFS.DataModel.DispatchingRuleData
{   
    public partial class DispatchingRuleSet {
        partial class DispatchingRuleDataTable
        {
        }
    }
}
