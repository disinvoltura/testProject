﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.DataModel
{
    public class Foup: SimulationEntity
    {
        #region Member Variables
        private string _J;
        private string _P;
        private int _N;
        /// <summary>
        /// Current Equipment ID
        /// </summary>
        private string _C;
        /// <summary>
        /// Next Equipment ID
        /// </summary>
        private string _D;
        private string _RBID;

        private double _DoubleDueDate;
        private double _ReleaseDate;
        private double _ArrivalDate;
        private DateTime _DueDate;

        #endregion

        #region Properties
        /// <summary>
        /// Product ID (or job type) of a cassette
        /// </summary>
        public string J { get { return _J; } }
        /// <summary>
        /// Processing Step ID which the cassette will undergo
        /// </summary>
        public string P { get { return _P; } set { _P = value; } }
        /// <summary>
        /// Number of glasses in the cassette
        /// </summary>
        public int N { get { return _N; } }
        /// <summary>
        /// Equipment ID where the cassette stays 
        /// </summary>
        public string C { get { return _C; } set { _C = value; } }
        /// <summary>
        /// Equipment ID, which is a destination of the cassette 
        /// </summary>
        public string D { get { return _D; } set { _D = value; } }
        /// <summary>
        /// ID of a release batch where the cassette belongs
        /// </summary>
        public string RBID { get { return _RBID; } }

        public DateTime DateTimeDueDate
        {
            get { return _DueDate; }
            set { _DueDate = value; }
        }

        public double DueDate
        {
            get { return _DoubleDueDate; }
            set { _DoubleDueDate = value; }
        }
        
        public double ReleaseDate
        {
            get { return _ReleaseDate; }
            set { _ReleaseDate = value; }
        }

        /// <summary>
        /// Time when a cassette arrives at the queue of next equipment
        /// </summary>
        public double ArrivalDate
        {
            get { return _ArrivalDate; }
            set { _ArrivalDate = value; }
        }

        #endregion

        #region Constructors
        public Foup(string rbid, string j, string p, int n, string d)
        {
            _RBID = rbid;
            _J = j;
            _P = p;
            _N = n;
            _D = d;
        }

        public Foup(string j, string p, int n, string c)
        {            
            _J = j;
            _P = p;
            _N = n;
            _C = c;
        }
        #endregion

        #region Methods
        public override string ToString()
        {
            string rslt = string.Format("Cassette({0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8})", this.ID, _RBID, _J, _P, _N, _C, _D, _ReleaseDate, _DoubleDueDate);
            return rslt;
        }
        #endregion
    }
}
