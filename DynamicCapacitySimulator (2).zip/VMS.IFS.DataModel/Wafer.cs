﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.DataModel
{
    public class Wafer : SimulationEntity
    {
        #region Member Variables
        private int _CID;
        private string _J;
        private string _P;
        private int _N;
        #endregion

        #region Properties
        /// <summary>
        /// ID of the cassette to which a glass belongs
        /// </summary>
        public int CID { get { return _CID; } }
        /// <summary>
        /// Product ID (or job type) of a glass
        /// </summary>
        public string J { get { return _J; } }
        /// <summary>
        /// Processing Step ID which the glass will undergo
        /// </summary>
        public string P { get { return _P; } }
        /// <summary>
        /// Number of glasses in a cassette to which a glass belongs
        /// </summary>
        public int N { get { return _N; } }
        #endregion

        #region Constructors
        public Wafer(int cid, string j, string p, int n)
        {
            _CID = cid;
            _J = j;
            _P = p;
            _N = n;
        }
        #endregion

        #region Methods

        #endregion
    }
}
