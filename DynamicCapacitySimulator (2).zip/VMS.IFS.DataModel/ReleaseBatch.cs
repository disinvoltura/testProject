﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.DataModel
{
    public class ReleaseBatch
    {
        #region Member Variables
        private string _ID;
        private string _ProductID;
        private int _Quantity;
        private List<Foup> _Cassttes; //replace with CassetteCollection
        private DateTime _Start;
        private DateTime _End;
        private DateTime _Due;
        #endregion

        #region Properties
        public string ReleaseBatchID { get { return _ID; } }
        public string ProductID { get { return _ProductID; } }
        /// <summary>
        /// Number of glasses in a release batch
        /// </summary>
        public int Quantity { get { return _Quantity; } }
        public List<Foup> Cassettes { get { return _Cassttes; } }
        public DateTime ReleaseStartTime { get { return _Start; } }
        public DateTime ReleaseEndTime { get { return _End; } }
        public DateTime DueDate{ get { return _Due; } }
        #endregion

        #region Constructors
        public ReleaseBatch(string rbid, string productid, int quantity, DateTime start, DateTime end, DateTime due)
        {
            _ID = rbid;
            _ProductID = productid;
            _Quantity = quantity;
            _Cassttes = new List<Foup>();
            _Start = start;
            _End = end;
            _Due = due;
        }
        #endregion

        #region Methods
        public void CreateCassettes(int glassespercassette, string firstStepID)
        {
            int noCassettes = _Quantity / glassespercassette;
            int noRemainigGlasses = _Quantity % glassespercassette;

            for (int i = 0; i < noCassettes; i++)
            {
                Foup cst = new Foup(_ID, _ProductID, firstStepID, glassespercassette, string.Empty);
                cst.DateTimeDueDate = this.DueDate;
                _Cassttes.Add(cst);
            }
        }
        #endregion
    }
}
