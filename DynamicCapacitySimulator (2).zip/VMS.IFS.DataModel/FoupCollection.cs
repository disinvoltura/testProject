﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.DataModel
{ 
    public class FoupCollection
    {
        #region Member Variables
        //private Dictionary<int, Cassette> _Cassettes;
        private List<Foup> _Cassettes;

        #endregion

        #region Properties
        public IEnumerable<Foup> Cassettes
        {
            get { return _Cassettes; }
        }

        public int Count
        {
            get { return _Cassettes.Count; }
        }

        //public Cassette this[int cassetteID]
        //{
        //    get
        //    {
        //        Cassette rslt = null;
        //        if (_Cassettes.ContainsKey(cassetteID))
        //            rslt = _Cassettes[cassetteID];
        //        return rslt;
        //    }
        //}
        #endregion

        #region Constructors
        public FoupCollection()
        {
            _Cassettes = new List<Foup>();
            //_Cassettes = new Dictionary<int, Cassette>();
        }
        #endregion

        #region Methods
        public void Clear()
        {
            _Cassettes.Clear();
        }

        public void Enqueue(Foup cst)
        {
            _Cassettes.Add(cst);
        }

        public Foup Dequeue()
        {
            Foup  rslt = null;

            if (_Cassettes.Count > 0)
            {
                rslt = _Cassettes[0];
                _Cassettes.RemoveAt(0);
            }

            return rslt;
        }

        public Foup Dequeue(int cassetteid)
        {
            int idx = -1;
            Foup rslt = null;
            for (int i = 0; i < _Cassettes.Count; i++)
            {
                if (_Cassettes[i].ID == cassetteid)
                {
                    idx = i;
                    rslt = _Cassettes[i];
                    break;
                }
            }

            if (idx >= 0)
                _Cassettes.RemoveAt(idx);

            return rslt;
        }

        public Foup Peek()
        {
            Foup  rslt = null;

            if (_Cassettes.Count > 0)
            {
                rslt = _Cassettes[0];
            }

            return rslt;
        }

        /// <summary>
        /// Remove a given cassette from the collection
        /// </summary>
        /// <param name="cst"></param>
        public void Remove(Foup cst)
        {
            _Cassettes.Remove(cst);
        }       
        
        public void Remove(int cassetteid)
        {
            int idx = -1;
            for (int i = 0; i < _Cassettes.Count; i++)
            {
                if (_Cassettes[i].ID == cassetteid)
                {
                    idx = i;
                    break;
                }
            }

            if (idx >= 0)
                _Cassettes.RemoveAt(idx);

        }
        /*
        /// <summary>
        /// Remove a casseet whose cassette id matches a given value
        /// </summary>
        /// <param name="cassetteID">ID of a cassette to be removed</param>
        public void Remove(int cassetteID)
        {
            if (_Cassettes.ContainsKey(cassetteID))
                _Cassettes.Remove(cassetteID);
        }
         * */
        #endregion
    }
}
