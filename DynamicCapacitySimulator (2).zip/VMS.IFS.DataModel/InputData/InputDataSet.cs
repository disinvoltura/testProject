﻿namespace VMS.IFS.DataModel.InputData {
    
    
    public partial class InputDataSet {
    }
}
