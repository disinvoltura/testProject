﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.DataModel.InputData;
using VMS.IFS.DataModel;

namespace VMS.IFS.Models
{
    public delegate void SimulationEndedEventHandler();

    public class Factory
    {
        #region Member Variables
        private string _Name;
        private SimulationCoordinator _SC;
        private Dictionary<string, EventObjectSimulator> _EQPs;
        private PushFabInSimulator _FabIn;
        private FabOutSimulator _FabOut;
        private MaterialHandling _MH;
        private MasterData _MasterData;
        
        private RealTimeDispatcher _RTD;

        private UniInlineCell _UniInlineCell;
        private BiInlineCell _BiInlineCell;
        private Oven _Oven;
        private Chamber _Chamber;

        private Dictionary<string, object> _SimArgs;
        #endregion

        #region Events
        public event SimulationEndedEventHandler SimulationEnded;
        #endregion

        #region Properties
        public double Clock
        {
            get { return _SC.Clock; }
        }

        public SimulationCoordinator SimulationCoordinator
        {
            get { return _SC; }
        }

        public MasterData MasterData
        {
            get { return _MasterData; }
        }

        public RealTimeDispatcher RTD
        {
            get { return _RTD; }
        }

        public UniInlineCell UniInlineCell
        {
            get { return _UniInlineCell; }
            set { _UniInlineCell = value; }
        }
        public BiInlineCell BiInlineCell
        {
            get { return _BiInlineCell; }
            set { _BiInlineCell = value; }
        }
        public Oven Oven
        {
            get { return _Oven; }
            set { _Oven = value; }
        }
        public Chamber Chamber
        {
            get { return _Chamber; }
            set { _Chamber = value; }
        }

        public PushFabInSimulator FabIn
        {
            get { return _FabIn; }
            set { _FabIn = value; }
        }

        public FabOutSimulator FabOut
        {
            get { return _FabOut; }
            set { _FabOut = value; }
        }

        public MaterialHandling MaterialHandling
        {
            get { return _MH; }
            set { _MH = value; }
        }

        public Equipment this[string eqpid]
        {
            get
            {
                Equipment rslt = null;

                if (this.MasterData.EQP[eqpid].EQP_Type == EquipmentType.UniInlineCell)
                    rslt = _UniInlineCell;
                else if (this.MasterData.EQP[eqpid].EQP_Type == EquipmentType.BiInlineCell)
                    rslt = _BiInlineCell;
                else if (this.MasterData.EQP[eqpid].EQP_Type == EquipmentType.Chamber)
                    rslt = _Chamber;
                else if (this.MasterData.EQP[eqpid].EQP_Type == EquipmentType.Oven)
                    rslt = _Oven;

                return rslt;
            }
        }
        #endregion

        #region Constructors
        public Factory(string name)
        {
            _Name = name;            
            _EQPs = new Dictionary<string, EventObjectSimulator>();
        }
        #endregion

        #region Methods
        public void Initialize(InputDataSet ds, Dictionary<string, object> args)
        {
            SimulationEntity.Initialize();

            //Simulation Argument 정의:
            _MasterData = new DataModel.SimulationData.MasterData();
            _MasterData.Initialize(ds, args);

            _SC = new SimulationCoordinator();
            _SC.Initialize();

            double eosTime = (double)args[SimulationArguments.EOSTime];
            _SC.StopAtTime(eosTime);            

            //설비 시뮬레이터 생성
            _UniInlineCell = new UniInlineCell(this);
            _UniInlineCell.Initialize(args);
            _Oven = new Oven(this);
            _Oven.Initialize(args);
            _BiInlineCell = new BiInlineCell(this);
            _BiInlineCell.Initialize(args);
            _Chamber = new Chamber(this);
            _Chamber.Initialize(args);

            //FabIn, FabOut 생성
            _FabIn = new PushFabInSimulator(this);
            _FabIn.Initialize(args);

            double saveWIPTime = double.Parse(args[SimulationArguments.SaveWIPTime].ToString());
            _FabOut = new FabOutSimulator(this, saveWIPTime);
            _FabOut.Initialize(args);

            //Material Handling
            _MH = new MaterialHandling(this);
            _MH.Initialize(args);

            //RTd
            _RTD = new RealTimeDispatcher(this);

            _SC.AddEventObjectSimulator(_UniInlineCell);
            _SC.AddEventObjectSimulator(_BiInlineCell);
            _SC.AddEventObjectSimulator(_Chamber);
            _SC.AddEventObjectSimulator(_Oven);
            _SC.AddEventObjectSimulator(_MH);
            _SC.AddEventObjectSimulator(_FabIn);
            _SC.AddEventObjectSimulator(_FabOut);
         
        }

        public void Run()
        {
            if (_SC.Run())
            {                                
                if (SimulationEnded != null && SimulationEnded.GetInvocationList().Length > 0)
                    SimulationEnded();
            }
        }

        public void Stop()
        {
            _SC.Abort();
        }

        public MachineInfo GetMachine(string eqpid)
        {
            MachineInfo m = new MachineInfo(eqpid, this);

            return m;
        }
        
        #endregion
    }
}
