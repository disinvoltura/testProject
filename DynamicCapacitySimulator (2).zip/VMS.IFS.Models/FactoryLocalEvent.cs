﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel;

namespace VMS.IFS.Models
{
    public class FactoryLocalEvent : LocalEvent
    {
        #region Member Variables
        private string _EQPID;
        private Foup _CST;
        private Wafer _GLS;
        #endregion 

        #region Properties
        public string EQPID
        {
            get
            {
                return _EQPID;
            }
        }

        public Foup Cassette
        {
            get { return _CST; }
        }

        public Wafer Glass
        {
            get { return _GLS; }
        }
        #endregion

        #region Constructors
        public FactoryLocalEvent(string objectName, string eventName, double eventTime, string eqpid)
            : base(objectName, eventName, eventTime)
        {
            _EQPID = eqpid;
        }

        public FactoryLocalEvent(string objectName, string eventName, double eventTime, string eqpid, Foup cst)
            : base(objectName, eventName, eventTime)
        {
            _EQPID = eqpid;
            _CST = cst;
        }

        public FactoryLocalEvent(string objectName, string eventName, double eventTime, string eqpid, Wafer gls)
            : base(objectName, eventName, eventTime)
        {
            _EQPID = eqpid;
            _GLS = gls;
        }
        #endregion
    }
}
