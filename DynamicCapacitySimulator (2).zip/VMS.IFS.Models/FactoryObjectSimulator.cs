﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public abstract class FactoryObjectSimulator : EventObjectSimulator
    {
        #region Member Variables
        private Factory _Factory;
        #endregion

        #region Properties
        public Factory Factory
        {
            get { return _Factory; }
        }

        public MasterData MasterData
        {
            get { return _Factory.MasterData; }
        }

        public RealTimeDispatcher RTD
        {
            get { return _Factory.RTD; }
        }
        #endregion

        #region Constructors
        public FactoryObjectSimulator(string name, Factory factory)
            : base(name, factory.SimulationCoordinator)
        {
            _Factory = factory;
        }
        #endregion

        #region Methods
        //public abstract void Execute_Move_Routine(double time, string eqpid, Cassette cst);

        public void ScheduleLocalEvent(string eventName, double time, string eqpid)
        {
            FactoryLocalEvent e = new FactoryLocalEvent(this.Name, eventName, time, eqpid);
            _SC.ScheduleLocalEvent(e);
        }

        public void ScheduleLocalEvent(string eventName, double time, string eqpid, Foup cst)
        {
            FactoryLocalEvent e = new FactoryLocalEvent(this.Name, eventName, time, eqpid, cst);
            _SC.ScheduleLocalEvent(e);
        }

        public void ScheduleLocalEvent(string eventName, double time, string eqpid, Wafer gls)
        {
            FactoryLocalEvent e = new FactoryLocalEvent(this.Name, eventName, time, eqpid, gls);
            _SC.ScheduleLocalEvent(e);
        }

        public void ScheduleMirrorEvent(string objectid, string eventName, double time, string eqpid, Foup cst)
        {
            FactoryLocalEvent e = new FactoryLocalEvent(objectid, eventName, time, eqpid, cst);
            _SC.ScheduleLocalEvent(e);
        }

        public void ScheduleMirrorEvent(string objectid, string eventName, double time, string eqpid)
        {
            FactoryLocalEvent e = new FactoryLocalEvent(objectid, eventName, time, eqpid);
            _SC.ScheduleLocalEvent(e);
        }
        #endregion
    }

    
}
