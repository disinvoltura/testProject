﻿using System;
using System.Collections.Generic;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Linq;
using System.Reflection;
using System.Text;
using Microsoft.CSharp;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.DispatchingRuleData;
using VMS.IFS.DataModel.SimulationData;
using VMS.Foundation.Logging;

namespace VMS.IFS.Models
{
    public class MachineSelectionRuleGenerator : DispatchingRuleGenerator
    {
        #region Member Variables
        private CompilerParameters cp = new CompilerParameters();
        private Factory _Factory;
        private DispatchingRuleDefinition _DRDef;
        private string _Code;
        #endregion

        #region Properties
        public override string Code
        {
            get { return _Code; }
        }
        #endregion

        #region Constructors
        public MachineSelectionRuleGenerator(Factory factory)
        {
            _Factory = factory;
        }
        #endregion

        #region Methods
        public override DispatchingRule GetInstance(Dictionary<string, object> args)
        {
            MachineSelectionRule rule = null;
            _DRDef = (DispatchingRuleDefinition)args[SimulationArguments.MachineSelectionRule];

            if (!generateCode(_DRDef))
                return rule;

            cp.GenerateExecutable = false;
            cp.GenerateInMemory = true;
            cp.IncludeDebugInformation = false;

            CodeDomProvider cdp = new Microsoft.CSharp.CSharpCodeProvider();
            Assembly asm = null;
            asm = compile(_Code, cdp);

            try
            {
                foreach (Type t in asm.GetTypes())
                {
                    if (!t.IsClass)
                        continue;

                    if (!t.IsPublic)
                        continue;

                    if (t.BaseType != typeof(MachineSelectionRule))
                        continue;

                    try
                    {
                        rule = null;
                        //Construction
                        object objInstance = null;
                        object[] objectArgs = new object[1];
                        Type[] argTypes = new Type[1];
                        objectArgs[0] = _Factory;
                        argTypes[0] = typeof(Factory);
                        objInstance = ReflectionHelper.CreateObject(t, objectArgs, argTypes);

                        if (objInstance != null)
                        {
                            //Parameter
                            foreach (DRParameter pm in _DRDef.Parameters)
                            {
                                FieldInfo _FieldInfo = null;
                                object _objValue = null;
                                if (pm.Type == DRParameterType.Double)
                                {
                                    _FieldInfo = t.GetField(pm.Name);
                                    _objValue = double.Parse(args["MSR_" + pm.Name].ToString());
                                    _FieldInfo.SetValue(objInstance, _objValue);//
                                }
                                else if (pm.Type == DRParameterType.Integer)
                                {
                                    _FieldInfo = t.GetField(pm.Name);
                                    _objValue = int.Parse(args["MSR_" + pm.Name].ToString());
                                    _FieldInfo.SetValue(objInstance, _objValue);//
                                }
                                else if (pm.Type == DRParameterType.Float)
                                {
                                    _FieldInfo = t.GetField(pm.Name);
                                    _objValue = float.Parse(args["MSR_" + pm.Name].ToString());
                                    _FieldInfo.SetValue(objInstance, _objValue);//
                                }
                                else if (pm.Type == DRParameterType.String)
                                {
                                    _FieldInfo = t.GetField(pm.Name);
                                    _objValue = args["MSR_" + pm.Name].ToString();
                                    _FieldInfo.SetValue(objInstance, _objValue);//
                                }
                            }
                            rule = objInstance as MachineSelectionRule;
                        }
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine(ex.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
            }

            return rule;
        }

        private Assembly compile(string code, CodeDomProvider cdp)
        {
            cp.CompilerOptions = "/unsafe";
            cp.ReferencedAssemblies.Clear();

            string path = System.Reflection.Assembly.GetEntryAssembly().Location;
            if (path.Contains("exe"))
                path = path.Substring(0, path.LastIndexOf('\\'));

            cp.ReferencedAssemblies.Add(path + @"\" + "VMS.IFS.DataModel.dll");
            cp.ReferencedAssemblies.Add(path + @"\" + "VMS.IFS.Models.dll");
            //cp.ReferencedAssemblies.Add(path + @"\" + "Troschuetz.Random.dll");

            CompilerResults cr = cdp.CompileAssemblyFromSource(cp, code);

            if (cr.Errors.HasErrors || cr.Errors.HasWarnings)
            {
                // Handle compiler errors
                StringBuilder error = new StringBuilder();
                foreach (CompilerError err in cr.Errors)
                {
                    string type = (err.IsWarning ? "Warning" : "Error");
                    if (error.Length > 0)
                        error.Append(Environment.NewLine);
                    error.AppendFormat("{0} {1}: Line {2} Column {3}: {4}", type, err.ErrorNumber, err.Line, err.Column, err.ErrorText);
                }
                System.Diagnostics.Debug.WriteLine(error.ToString());

                if (cr.Errors.HasErrors)
                    throw new Exception(error.ToString());
            }

            // Success, return our new assembly
            return cr.CompiledAssembly;
        }

        private string _N = Environment.NewLine;
        private string _Q = "\""; //quotation
        private string _L = "{";
        private string _R = "}";
        private string _T = "\t";
        private string _S = "#region";
        private string _E = "#endregion";
        private string _C = ";";
        private string _U = " = ";

        public override bool generateCode(DispatchingRuleDefinition drDef)
        {
            bool rslt = false;

            string name = drDef.Name.Replace(" ", "").Replace("-", "_");
            string className = name + "MachineSelectionRule";
            _Code = generateHeader(drDef, name);

            _Code += "namespace " + name + _N;
            _Code += _L + _N;
            _Code += getTab(1) + "public class " + className + " : MachineSelectionRule" + _N;
            _Code += getTab(1) + _L + _N;

            //Member Variables
            _Code += generateMemberVariables(drDef);

            //Constructors
            _Code += generateConstructor(name, className);

            //NextEQP Method
            _Code += generateNextEQPMethod(drDef);

            //Factor Methods
            //TODO
            _Code += generateFactorMethods(drDef);

            //end of class
            _Code += getTab(1) + _R + _N;
            _Code += _R + _N;

            rslt = true;
            return rslt;
        }

        private string generateMemberVariables(DispatchingRuleDefinition drDef)
        {
            string code = string.Empty;
            code += getTab(2) + _S + " Member Variables" + _N;

            //Parameters
            foreach (DRParameter p in drDef.Parameters)
            {
                string pType = "int";
                if (p.Type == DRParameterType.Float)
                    pType = "float";
                else if (p.Type == DRParameterType.Double)
                    pType = "double";
                else if (p.Type == DRParameterType.String)
                    pType = "string";

                code += getTab(2) + "//" + p.Description + _N;
                code += getTab(2) + string.Format("public {0} {1};", pType, p.Name) + _N;
            }

            code += getTab(2) + _E + _N;

            return code;
        }

        private string generateProperties(DispatchingRuleDefinition drDef)
        {
            string code = string.Empty;
            code += getTab(2) + _S + " Properties" + _N;

            code += getTab(2) + _E + _N;
            return code;
        }

        private string generateNextEQPMethod(DispatchingRuleDefinition drDef)
        {
            string code = string.Empty;
            code += getTab(2) + "public override string NextEQP(Foup cassette)" + _N;
            code += getTab(2) + _L + _N;
            
            code += getTab(3) + "string[] loadables = _Factory.MasterData.Loadable[cassette.J, cassette.P]" + _C + _N;
            code += getTab(3) + "if (loadables == null || loadables.Length == 0)" + _N;
            code += getTab(4) + "return string.Empty" + _C + _N;

            code += getTab(3) + "MachineInfo nextEQP = null" + _C + _N;
            if (drDef.SelectionOrder == SelectionCriteriaType.Minimum)
                code += getTab(3) + "double nextPriority = double.MaxValue" + _C + _N;
            else if (drDef.SelectionOrder == SelectionCriteriaType.Maximum)
                code += getTab(3) + "double nextPriority = double.MinValue" + _C + _N;
            
            code += getTab(3) + "foreach (string eqpid in loadables)" + _N;
            code += getTab(3) + _L + _N;
            code += getTab(4) + "MachineInfo machine = new MachineInfo(eqpid, _Factory)" + _C + _N;
            string priorityFunc = drDef.PriorityFunction.Replace("Cassette", "cassette").Replace("Machine", "machine").Replace(" ", "").Replace("-", "_");
            code += getTab(4) + "double priority = " + priorityFunc + _C + _N;
            
            if (drDef.SelectionOrder == SelectionCriteriaType.Minimum)
            {
                code += getTab(4) + "if (nextEQP == null || priority < nextPriority) " + _N;
                code += getTab(4) + _L + _N;
                code += getTab(5) + "nextEQP = machine; nextPriority = priority " + _C + _N;
                code += getTab(4) + _R + _N;
            }
            else if (drDef.SelectionOrder == SelectionCriteriaType.Maximum)
            {
                code += getTab(4) + "if (nextEQP == null || priority > nextPriority) " + _N;
                code += getTab(4) + _L + _N;
                code += getTab(5) + "nextEQP = machine; nextPriority = priority " + _C + _N;
                code += getTab(4) + _R + _N;
            }
            
            //TODO
            //tie-breaking: -- comment out for a moment
            //code += getTab(4) + "else if (priority == nextPriority) { } " + _R + _N;

            code += getTab(3) + _R + _N; //end of foreach

            code += getTab(3) + "return nextEQP.ID" + _C + _N;
            code += getTab(2) + _R + _N;//end of method

            return code;
        }

        private string generateFactorMethods(DispatchingRuleDefinition drDef)
        {
            string code = string.Empty;
            foreach (DRFactor factor in drDef.Factors)
            {
                code += getTab(2) + "//" + factor.Description + _N;
                string factorName = factor.Name.Replace(" ", "").Replace("-", "_");
                code += getTab(2) + "public double " + factorName + "(Foup Cassette, MachineInfo Machine)" + _N;
                code += getTab(2) + _L + _N;

                code += getTab(3) + "double factorValue = 0" + _C + _N;

                code += getTab(3) + "factorValue = " + factor.Expression + _C + _N;

                code += getTab(3) + "return factorValue" + _C + _N;

                code += getTab(2) + _R + _N; //end of method
                code += getTab(2) + _N;
            }

            return code;
        }

        private string generateConstructor(string name, string className)
        {
            string code = "";
            code += getTab(2) + _S + " Constructors" + _N;

            code += getTab(2) + "public " + className + "(Factory factory)" + _N;
            code += getTab(3) + ": base(\"" + name + "\", factory)" + _N;
            code += getTab(2) + _L + _N;
            code += getTab(2) + _R + _N;

            code += getTab(2) + _E + _N;
            return code;
        }

        private string generateHeader(DispatchingRuleDefinition drDef, string name)
        {
            string headerTemplate =
@"/* 
 * This code is automatically generated, Copyright (C) Donghun Kang, VMS Laboratory.
 * Date: {0}
 * Time: {1}
 * Model Name: {2}
 *
 */
using System;
using System.Collections.Generic;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.Models;" + _N + _N;
            string code = string.Format(
                headerTemplate,
                DateTime.Now.ToString("yyyy-MM-dd"),
                DateTime.Now.ToString("HH:mm"),
                name);

            return code;
        }

        private string getTab(int count)
        {
            string tab = string.Empty;
            for (int i = 0; i < count; i++)
                tab += _T;
            return tab;
        }

        #endregion

    }
}
