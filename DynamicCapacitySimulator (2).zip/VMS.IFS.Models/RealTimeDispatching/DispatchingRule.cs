﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public abstract class DispatchingRule
    {
        #region Member Variables
        protected Factory _Factory;
        protected string _Name;
        protected Dictionary<string, object> _Parameters;
        #endregion

        #region Properties
        public double Clock
        {
            get { return _Factory.Clock; }
        }

        public double CLK
        {
            get { return _Factory.Clock; }
        }


        public Dictionary<string, object> Parameters
        {
            get { return _Parameters; }
        }
        #endregion

        #region Constructors
        public DispatchingRule(string name, Factory factory)
        {
            _Factory = factory;
            _Name = name;
            _Parameters = new Dictionary<string, object>();
        }
        #endregion

        #region Methods
        public void Initialize(Dictionary<string, object> args)
        {
            foreach (string key in args.Keys)
            {
                _Parameters.Add(key, args[key]);                   
            }
        }

        /// <summary>
        /// Processing time of a cassette at an equipment
        /// </summary>
        /// <param name="cst">Cassette</param>
        /// <param name="eqpid">Equipment ID</param>
        /// <returns>Processing Time</returns>
        public double PT(Foup cst, MachineInfo eqp)
        //public double PT(Cassette cst, string eqpid)
        {
            double rslt = 0;

            //설비별 구분
            if (eqp.Type == "U") //Uni-inline
            {
                rslt = cst.N * _Factory.MasterData.TactTime[cst.J, cst.P, eqp.ID] + _Factory.MasterData.FlowTime[cst.J, cst.P, eqp.ID];
            }
            else if (eqp.Type == "B") //BiInline
            {
                rslt = cst.N * _Factory.MasterData.TactTime[cst.J, cst.P, eqp.ID] + _Factory.MasterData.FlowTime[cst.J, cst.P, eqp.ID];
            }
            else if (eqp.Type == "C") //Chamber
            {
                int noCycles = cst.N / eqp.PC;
                if (cst.N % eqp.PC > 0)
                    noCycles++;

                rslt = noCycles * (2 * _Factory.MasterData.TactTime[cst.J, cst.P, eqp.ID] + _Factory.MasterData.FlowTime[cst.J, cst.P, eqp.ID]);
                //rslt = 2 * cst.N * _Factory.MasterData.TactTime[cst.J, cst.P, eqp.ID] + _Factory.MasterData.FlowTime[cst.J, cst.P, eqp.ID];
            }
            else if (eqp.Type == "V") //Oven
            {
                rslt = 2 * cst.N * _Factory.MasterData.TactTime[cst.J, cst.P, eqp.ID] +_Factory.MasterData.FlowTime[cst.J, cst.P, eqp.ID];
            }

            return rslt;
        }

        /// <summary>
        /// Planned Transport Time
        /// </summary>
        /// <param name="?"></param>
        /// <returns></returns>
        public double PTT(Foup cst, MachineInfo eqp)
        //public double PTT(Cassette cst, string eqpid)
        {
            double rslt = 0;

            if (string.IsNullOrEmpty(cst.C))
                return rslt;

            string curSTKID = string.Empty;
            string nextSTKID = string.Empty;

            EquipmentType curType = _Factory.MasterData.EQP[cst.C].EQP_Type;
            if (curType == EquipmentType.UniInlineCell ||
                curType == EquipmentType.Chamber ||
                curType == EquipmentType.Oven)
                curSTKID = _Factory.MasterData.EQPPort[cst.C].INOUTSTKID;
            else if (curType == EquipmentType.BiInlineCell)
                curSTKID = _Factory.MasterData.EQPPort[cst.C].OUTSTKID;

            if (eqp.Type == "U" ||
                eqp.Type == "C" ||
                eqp.Type == "V")
                nextSTKID = _Factory.MasterData.EQPPort[eqp.ID].INOUTSTKID;
            else
                nextSTKID = _Factory.MasterData.EQPPort[eqp.ID].INSTKID;

            if (string.IsNullOrEmpty(curSTKID) || string.IsNullOrEmpty(nextSTKID))
                rslt = 0;
            else
                rslt = _Factory.MasterData.MoveTime[curSTKID, nextSTKID];

            return rslt;
        }

        /// <summary>
        /// Remaining Processing Time
        /// </summary>
        /// <param name="cst"></param>
        /// <returns></returns>
        public double RPT(Foup cst)
        {
            double rslt = 0;

            //TODO
            //어떤 설비에 처리될지 모르는데?
            string finalStepID = _Factory.MasterData.BOP.GetLastStepID(cst.J);
            
            string nextStepID = cst.P;

            do
            {
                string[] loadables = _Factory.MasterData.Loadable[cst.J, nextStepID];

                MachineInfo eqp = new MachineInfo(loadables[0], _Factory);
                
                if (eqp.Type == "U") //Uni-inline
                {
                    rslt += cst.N * _Factory.MasterData.TactTime[cst.J, nextStepID, eqp.ID] + _Factory.MasterData.FlowTime[cst.J, nextStepID, eqp.ID];
                }
                else if (eqp.Type == "B") //BiInline
                {
                    rslt += cst.N * _Factory.MasterData.TactTime[cst.J, nextStepID, eqp.ID] + _Factory.MasterData.FlowTime[cst.J, nextStepID, eqp.ID];
                }
                else if (eqp.Type == "C") //Chamber
                {
                    int noCycles = cst.N / eqp.PC;
                    if (cst.N % eqp.PC > 0)
                        noCycles++;

                    rslt = noCycles * (2 * _Factory.MasterData.TactTime[cst.J, cst.P, eqp.ID] + _Factory.MasterData.FlowTime[cst.J, cst.P, eqp.ID]);
                }
                else if (eqp.Type == "V") //Oven
                {
                    rslt += 2 * cst.N * _Factory.MasterData.TactTime[cst.J, nextStepID, eqp.ID] + _Factory.MasterData.FlowTime[cst.J, nextStepID, eqp.ID];
                }

                nextStepID = _Factory.MasterData.BOP[cst.J, nextStepID];

            } while (!string.IsNullOrEmpty(nextStepID) && !nextStepID.Equals(finalStepID));

            return rslt;
        }

        public override string ToString()
        {
            return _Name;
        }
        #endregion
    }
}
