﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;

namespace VMS.IFS.Models
{
    public abstract class JobSelectionRule : DispatchingRule
    {
        public JobSelectionRule(string name, Factory factory)
            : base(name, factory)
        {

        }
        public abstract int NextCassette(string eqpid, FoupCollection cstlist);
    }
}
