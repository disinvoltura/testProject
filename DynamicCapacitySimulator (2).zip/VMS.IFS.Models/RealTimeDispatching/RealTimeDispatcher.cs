﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.DispatchingRuleData;
using VMS.IFS.DataModel.SimulationData;
using VMS.Foundation.Logging;

namespace VMS.IFS.Models
{
    public class RealTimeDispatcher
    {
        #region Member Variables
        private Factory _Factory;
        private JobSelectionRule _JSR;
        private MachineSelectionRule _MSR;

        private Logger _LoggerMSR;
        private Logger _LoggerJSR;

        #endregion

        #region Properties
        public Factory Factory
        {
            get { return _Factory; }
        }

        public JobSelectionRule JSR
        {
            get { return _JSR; }
            set { _JSR = value; }
        }

        public MachineSelectionRule MSR
        {
            get { return _MSR; }
            set { _MSR = value; }
        }
        #endregion

        #region Constructors
        public RealTimeDispatcher(Factory factory)
        {
            _Factory = factory;

            _LoggerJSR = LogManager.GetLogger("JobSelectionRule");
            _LoggerMSR = LogManager.GetLogger("MachineSelectionRule");
        }
        #endregion

        #region Methods
        public void Initialize(Dictionary<string, object> args)
        {
            //Job Selection Rule
            JobSelectionRuleGenerator jsrGen = new JobSelectionRuleGenerator(_Factory);
            _JSR = (JobSelectionRule)jsrGen.GetInstance(args);

            //Machine Selection Rule
            MachineSelectionRuleGenerator msrGen = new MachineSelectionRuleGenerator(_Factory);
            _MSR = (MachineSelectionRule)msrGen.GetInstance(args);
        }

        public string NextStep(Foup cst)
        {
            string nextStepID = _Factory.MasterData.BOP[cst.J, cst.P];
            return nextStepID;
        }

        /// <summary>
        /// Machine Selection 
        /// </summary>
        /// <param name="cst"></param>
        /// <returns></returns>
        public string NextEQP(Foup cst)
        {
            _LoggerMSR.Debug("NextEQP (" + cst.ID + ", " + cst.J + ", " + cst.P + ", " + cst.D+")");

            string eqpid = _MSR.NextEQP(cst);

            _LoggerMSR.Debug("=> " + eqpid);

            return eqpid;
        }

        /// <summary>
        /// Select a cassette from the cassette collection at a given equipment (EQP ID) 
        /// </summary>
        /// <param name="eqpid">EQP ID</param>
        /// <param name="cstlist">Cassette Collection</param>
        /// <returns></returns>
        public int NextCassette(string eqpid, FoupCollection cstlist) //추후 eqpid 가 필요할 것으로 사료되어 수정함
        //public int NextCassette(string eqpid, CassetteCollection cstlist)
        {
            int nextCassetteID = -1;

            _LoggerJSR.Debug("NextCassette (" + eqpid + ")");
            _LoggerJSR.Debug("- Candidate Cassettes: ");
            int count = 1;
            foreach(Foup cst in cstlist.Cassettes){
                _LoggerJSR.Debug("  [" + count + "] " + cst.ID + "," + cst.J  +"," + cst.P+")");
                count++;
            }

            nextCassetteID = _JSR.NextCassette(eqpid, cstlist);
            _LoggerJSR.Debug("- next cassette: " + nextCassetteID);                        

            return nextCassetteID;
        }
        #endregion
    }
}
