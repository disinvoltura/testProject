﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;

namespace VMS.IFS.Models
{
    public abstract class MachineSelectionRule: DispatchingRule
    {
        public MachineSelectionRule(string name, Factory factory)
            : base(name, factory)
        {

        }
        public abstract string NextEQP(Foup cst);
    }
}
