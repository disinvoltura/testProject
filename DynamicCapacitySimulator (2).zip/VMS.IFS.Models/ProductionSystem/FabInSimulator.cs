﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;

namespace VMS.IFS.Models
{
    public class FabInSimulator : FactoryObjectSimulator
    {
        #region Member Variables
        private ReleaseController _FIQ;
        #endregion

        #region Properties
        public Dictionary<string, ReleaseBatch> ReleaseBatches
        {
            get { return _FIQ.ReleaseBatches; }
        }
        #endregion

        #region Constructors
        public FabInSimulator(Factory factory)
            : base("FabIn", factory)
        {
            _FIQ = new ReleaseController(factory);
        }
        #endregion

        #region Methods
        private void Execute_CFI_Routine(double now)
        {
            Foup nextCst = _FIQ.NextCassette();
            if (nextCst != null)
            {
                nextCst.ReleaseDate = now;
                nextCst.D = Factory.RTD.NextEQP(nextCst);

                if (_FIQ.Count > 0)
                {
                    double timeToNextRelease = _FIQ.TimeToNextRelease;
                    ScheduleLocalEvent("CFI", now + timeToNextRelease);
                }

                ScheduleLocalEvent("Move", now, this.Name, nextCst);

                //ScheduleMirrorEvent("MaterialHandling", "Move", now, this.Name, nextCst);
            }
        }

        private void Execute_Move_Routine(double now, string eqpid, Foup cst)
        {
            ScheduleMirrorEvent("MaterialHandling", "Move", now, eqpid, cst);
        }

        public override void Run()
        {
            ScheduleLocalEvent("CFI", 0);
        }

        public override void ExecuteLocalEvent(Engine.LocalEvent e)
        {
            if (e.ObjectName == "FabIn" && e.Name == "CFI" )
            {
                Execute_CFI_Routine(e.Time);
            }
            else if (e.ObjectName == "FabIn" && e.Name == "Move")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)e;
                Execute_Move_Routine(fle.Time, fle.EQPID, fle.Cassette);
            }
        }

        public override void Initialize(Dictionary<string, object> args)
        {
            _FIQ.Clear();
            foreach (string rbid in this.Factory.MasterData.ReleaseBatch.ReleaseBatches)
            {
                ReleaseBatch rb = this.Factory.MasterData.ReleaseBatch[rbid];
                _FIQ.Add(rb);
            }
        }
        #endregion

    }

    
}
