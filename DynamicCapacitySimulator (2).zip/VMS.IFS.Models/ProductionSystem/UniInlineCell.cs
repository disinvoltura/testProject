﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public class UniInlineCell : Equipment
    {
        #region Member Variables
        /// <summary>
        /// Key: EQP ID, value: CassetteCollection (B[u])
        /// </summary>
        private Dictionary<string, FoupCollection> _B;

        private Dictionary<string, FoupCollection> _BWIP;

        //Key: EQP ID, value: true when it's for Step Kanban
        private Dictionary<string, bool> _StepKanbanEqpList;
        /// <summary>
        /// Status of Track-in Robot where the key is EQP ID and the value is status of the track-in robot at the EQP
        /// </summary>
        private Dictionary<string, int> _R;
        #endregion

        #region Properties
        /// <summary>
        /// List of Cassettes on the port
        /// </summary>
        public Dictionary<string, FoupCollection> B
        {
            get { return _B; }
        }

        public Dictionary<string, FoupCollection> BWIP
        {
            get { return _BWIP; }
        }
        #endregion

        #region Constructors
        public UniInlineCell(Factory factory)
            : base ("UniInlineCell", factory)
        {
            _Q = new Dictionary<string, FoupCollection>();
            _M = new Dictionary<string, int>();
            _B = new Dictionary<string, FoupCollection>();
            _BWIP = new Dictionary<string, FoupCollection>();
            _R = new Dictionary<string, int>();
            _JT = new Dictionary<string, string>();
            
            _StepKanbanEqpList = new Dictionary<string, bool>();
        }
        #endregion

        #region Event Routines
        private void Execute_uCL_Routine(double now, string u)
        {
            int cassetteID = Factory.RTD.NextCassette(u, _Q[u]);
            Foup cst = _Q[u].Dequeue(cassetteID);            
            
            _B[u].Enqueue(cst);            
            
            _P[u].ChangePortState(PortState.RX, PortState.F);
            bool RsvR = false;
            if (_R[u] == 1)
            {
                _R[u] = -1;
                RsvR = true;
            }

            if (RsvR)
                ScheduleLocalEvent("TrackIn", now, u);

            if (_StepKanbanEqpList[u])
                ScheduleMirrorEvent("FabIn", "CL", now);
        }

        private void Execute_TrackIn_Routine(double now, string u)
        {
            Foup cst = _B[u].Dequeue();
            _BWIP[u].Enqueue(cst);
            _R[u] = 0;            

            if (cst.J == _JT[u])
                ScheduleLocalEvent("FGL", now, u, cst);
            else
                ScheduleLocalEvent("SS", now, u, cst);
        }

        private void Execute_FGL_Routine(double now, string u, Foup cst)
        {            
            double t1 = cst.N * MasterData.TactTime[cst.J, cst.P, u];
            ScheduleLocalEvent("LGL", now + t1, u, cst);
        }

        private void Execute_SS_Routine(double now, string u, Foup cst)
        {
            ScheduleLocalEvent("FGL", now + MasterData.SetupTime[u], u, cst);
        }
        
        private void Execute_LGL_Routine(double now, string u, Foup cst)
        {
            _R[u] = 1;
            _P[u].ChangePortState(PortState.F, PortState.E);
            _JT[u] = cst.J;

            bool RsvR = false;
            if (_B[u].Count > 0)
            {
                _R[u] = -1;
                RsvR = true;
            }
            
            if (RsvR)
                ScheduleLocalEvent("TrackIn", now, u);

            ScheduleLocalEvent("CD", now + MasterData.FlowTime[cst.J, cst.P, u], u, cst);
        }

        private void Execute_CD_Routine(double now, string u, Foup cst)
        {
            if (_Q[u].Count > 0 && _P[u].RX == 0)
            {
                _P[u].ChangePortState(PortState.E, PortState.RX);
                
                ScheduleLocalEvent("uCL", now, u);
            }
            else
            {
                _P[u].ChangePortState(PortState.E, PortState.X);
            }
            
            cst.P = RTD.NextStep(cst);
            cst.D = RTD.NextEQP(cst);

            _BWIP[u].Dequeue(cst.ID);

            //ScheduleLocalEvent("Move", now, u, cst);
            ScheduleMirrorEvent("MaterialHandling", "Move", now, u, cst);            
        }

        private void Execute_Move_Routine(double now, string eqpid, DataModel.Foup cst)
        {
            ScheduleMirrorEvent("MaterialHandling", "Move", now, eqpid, cst);
        }

        #endregion

        #region Methods
        public override void Run()
        {
            foreach (string eqpid in Factory.MasterData.EQP.UnilineCells)
            {
                if (_B[eqpid].Count > 0)
                {
                    ScheduleLocalEvent("TrackIn", 0, eqpid);
                }

                int rx = _P[eqpid].RX;
                while (rx > 0)
                {
                    ScheduleLocalEvent("uCL", 0, eqpid);
                    rx--;
                }                
            }
        }

        public override void ExecuteLocalEvent(Engine.LocalEvent e)
        {
            if (e.ObjectName == this.Name)
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)e;
                if (e.Name == "uCL")
                {
                    Execute_uCL_Routine(fle.Time, fle.EQPID);
                }
                else if (e.Name == "TrackIn")
                {
                    Execute_TrackIn_Routine(fle.Time, fle.EQPID);
                }
                else if (e.Name == "FGL")
                {
                    Execute_FGL_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "SS")
                {
                    Execute_SS_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "LGL")
                {
                    Execute_LGL_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "CD")
                {
                    Execute_CD_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "Move")
                {
                    Execute_Move_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
            }
        }

        public override void Initialize(Dictionary<string, object> args)
        {
            _P = new Dictionary<string, Port>();
            _B = new Dictionary<string,FoupCollection>();
            _BWIP = new Dictionary<string, FoupCollection>();
            _R = new Dictionary<string,int>();
            _Q = new Dictionary<string,FoupCollection>();
            _M = new Dictionary<string, int>();
            _JT = new Dictionary<string, string>();
            _StepKanbanEqpList = new Dictionary<string, bool>();

            foreach (string eqpid in Factory.MasterData.EQP.UnilineCells)
            {
                //Port
                Port p = new Port(Factory.MasterData.EQPPort[eqpid].INOUT);
                _P.Add(eqpid, p);

                //Port Queue
                _B.Add(eqpid, new FoupCollection());
                _BWIP.Add(eqpid, new FoupCollection());
                if (MasterData.WIP.hasBWIP(eqpid))
                {
                    foreach (Foup cst in MasterData.WIP[eqpid, "B"])
                    {
                        _B[eqpid].Enqueue(cst);
                        _P[eqpid].ChangePortState(PortState.X, PortState.F);
                    }
                }
                
                //Track-in Robot
                _R.Add(eqpid, 1);

                //Stocker Queue
                _Q.Add(eqpid, new FoupCollection());
                if (MasterData.WIP.hasQWIP(eqpid))
                {
                    foreach (Foup cst in MasterData.WIP[eqpid, "Q"])
                    {
                        _Q[eqpid].Enqueue(cst);
                        if (_P[eqpid].X > 0)
                        {
                            _P[eqpid].ChangePortState(PortState.X, PortState.RX);
                        }
                    }
                }

                //Job Type for last proceessed cassette
                _JT.Add(eqpid, string.Empty);

                //Number of cassettes moving to the equipment
                _M.Add(eqpid, 0);

                //Step Kanban
                if (Factory.MasterData.StepKanbanEqpList.Contains(eqpid))
                    _StepKanbanEqpList.Add(eqpid, true);
                else
                    _StepKanbanEqpList.Add(eqpid, false);
            }
        }

        #endregion
    }
}
