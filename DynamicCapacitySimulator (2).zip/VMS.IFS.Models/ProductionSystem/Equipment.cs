﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;

namespace VMS.IFS.Models
{
    public abstract class Equipment: FactoryObjectSimulator
    {
        #region Member Variables
        protected Dictionary<string, FoupCollection> _Q;
        /// <summary>
        /// Number of Cassettes moving to an equipment (key: eqp id, value: number of cassettes moving to eqp id)
        /// </summary>
        protected Dictionary<string, int> _M;
        protected Dictionary<string, string> _JT;
        protected Dictionary<string, Port> _P;

        #endregion

        #region Properties

        /// <summary>
        /// List of Cassettes waiting at the buffer of an equipment 
        /// where key is the equipment id and value is the cassette list
        /// </summary>
        public Dictionary<string, FoupCollection> Q
        {
            get { return _Q;}
            set { _Q = value; }
        }

        /// <summary>
        /// Number of Cassettes moving to an equipment 
        /// where key is the equipment id and value is number of cassettes
        /// </summary>
        public Dictionary<string, int> M
        {
            get { return _M; }
            set { _M = value; }
        }

        public Dictionary<string, string> JT
        {
            get { return _JT; }
            set { _JT = value; }
        }

        public Dictionary<string, Port> P
        {
            get { return _P; }
            set { _P = value; }
        }

        #endregion

        #region Constructors
        public Equipment(string name, Factory factory)
            : base(name, factory)
        {
            //_Q = new Dictionary<string, CassetteCollection>();
            _JT = new Dictionary<string, string>();
            _P = new Dictionary<string, Port>();
            _M = new Dictionary<string, int>();
        }
        #endregion

        #region Methods

        #endregion
    }
}
