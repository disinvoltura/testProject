﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public class Oven : Equipment
    {
        #region Member Variables
        /// <summary>
        /// Key: EQP ID, value: CassetteCollection (B[v])
        /// </summary>
        private Dictionary<string, FoupCollection> _B;

        private Dictionary<string, FoupCollection> _BWIP;

        /// <summary>
        /// Status of Track-in Robot where the key is EQP ID and the value is status of the track-in robot at the EQP
        /// </summary>
        private Dictionary<string, int> _R;
        #endregion

        #region Properties
        public Dictionary<string, FoupCollection> B
        {
            get { return _B; }
        }

        public Dictionary<string, FoupCollection> BWIP
        {
            get { return _BWIP; }
        }

        #endregion

        #region Constructors
        public Oven(Factory factory)
            : base("Oven", factory)
        {
            _Q = new Dictionary<string, FoupCollection>();
            _M = new Dictionary<string, int>();
            _B = new Dictionary<string, FoupCollection>();
            _BWIP = new Dictionary<string, FoupCollection>();
            _R = new Dictionary<string, int>();
            _JT = new Dictionary<string, string>();
        }
        #endregion

        #region Event Routines
        private void Execute_vCL_Routine(double now, string v)
        {
            int cassetteID = Factory.RTD.NextCassette(v, _Q[v]);
            Foup cst = _Q[v].Dequeue(cassetteID);

            _B[v].Enqueue(cst);

            _P[v].ChangePortState(PortState.RX, PortState.F);
            bool RsvR = false;
            if (_R[v] == 1)
            {
                _R[v] = -1;
                RsvR = true;
            }

            if (RsvR)
                ScheduleLocalEvent("TrackIn", now, v);
        }

        private void Execute_TrackIn_Routine(double now, string v)
        {
            Foup cst = _B[v].Dequeue();
            _BWIP[v].Enqueue(cst);
            _R[v] = 0;

            if (cst.J == _JT[v])
                ScheduleLocalEvent("FGL", now, v, cst);
            else
                ScheduleLocalEvent("SS", now, v, cst);
        }

        private void Execute_FGL_Routine(double now, string v, Foup cst)
        {
            double t1 = cst.N * MasterData.TactTime[cst.J, cst.P, v];
            ScheduleLocalEvent("LGL", now + t1, v, cst);
        }

        private void Execute_SS_Routine(double now, string v, Foup cst)
        {
            ScheduleLocalEvent("FGL", now + MasterData.SetupTime[v], v, cst);
        }

        private void Execute_LGL_Routine(double now, string v, Foup cst)
        {
            _P[v].ChangePortState(PortState.F, PortState.E);
            _JT[v] = cst.J;

            double t1 = cst.N * MasterData.TactTime[cst.J, cst.P, v];
            double tp = MasterData.FlowTime[cst.J, cst.P, v] + t1;
            ScheduleLocalEvent("CD", now + tp, v, cst);
        }

        private void Execute_CD_Routine(double now, string v, Foup cst)
        {
            _R[v] = 1;

            if (_Q[v].Count > 0 && _P[v].RX == 0)
            {
                _P[v].ChangePortState(PortState.E, PortState.RX);

                ScheduleLocalEvent("vCL", now, v);
            }
            else
            {
                _P[v].ChangePortState(PortState.E, PortState.X);
            }

            cst.P = RTD.NextStep(cst);
            cst.D = RTD.NextEQP(cst);

            _BWIP[v].Dequeue(cst.ID);

            bool RsvR = false;
            if (_B[v].Count > 0)
            {
                _R[v] = -1;
                RsvR = true;
            }

            if (RsvR)
                ScheduleLocalEvent("TrackIn", now, v);

            //ScheduleLocalEvent("Move", now, v, cst);
            ScheduleMirrorEvent("MaterialHandling", "Move", now, v, cst);
        }

        private void Execute_Move_Routine(double now, string eqpid, DataModel.Foup cst)
        {
            ScheduleMirrorEvent("MaterialHandling", "Move", now, eqpid, cst);
        }

        #endregion

        #region Methods
        public override void Run()
        {
            foreach (string eqpid in Factory.MasterData.EQP.Ovens)
            {
                if (_B[eqpid].Count > 0)
                {
                    ScheduleLocalEvent("TrackIn", 0, eqpid);
                }

                int rx = _P[eqpid].RX;
                while (rx > 0)
                {
                    ScheduleLocalEvent("vCL", 0, eqpid);
                    rx--;
                } 
            }
        }

        public override void ExecuteLocalEvent(Engine.LocalEvent e)
        {
            if (e.ObjectName == this.Name)
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)e;
                if (e.Name == "vCL")
                {
                    Execute_vCL_Routine(fle.Time, fle.EQPID);
                }
                else if (e.Name == "TrackIn")
                {
                    Execute_TrackIn_Routine(fle.Time, fle.EQPID);
                }
                else if (e.Name == "FGL")
                {
                    Execute_FGL_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "SS")
                {
                    Execute_SS_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "LGL")
                {
                    Execute_LGL_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "CD")
                {
                    Execute_CD_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "Move")
                {
                    Execute_Move_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
            }
        }

        public override void Initialize(Dictionary<string, object> args)
        {
            _P = new Dictionary<string, Port>();
            _B = new Dictionary<string, FoupCollection>();
            _BWIP = new Dictionary<string, FoupCollection>();
            _R = new Dictionary<string, int>();
            _Q = new Dictionary<string, FoupCollection>();
            _M = new Dictionary<string, int>();
            _JT = new Dictionary<string, string>();
            foreach (string eqpid in Factory.MasterData.EQP.Ovens)
            {
                //Port
                Port p = new Port(Factory.MasterData.EQPPort[eqpid].INOUT);
                _P.Add(eqpid, p);

                //Port Queue
                _B.Add(eqpid, new FoupCollection());
                _BWIP.Add(eqpid, new FoupCollection());
                if (MasterData.WIP.hasBWIP(eqpid))
                {
                    foreach (Foup cst in MasterData.WIP[eqpid, "B"])
                    {
                        _B[eqpid].Enqueue(cst);
                        _P[eqpid].ChangePortState(PortState.X, PortState.F);
                    }
                }

                //Track-in Robot
                _R.Add(eqpid, 1);

                //Stocker Queue
                _Q.Add(eqpid, new FoupCollection());
                if (MasterData.WIP.hasQWIP(eqpid))
                {
                    foreach (Foup cst in MasterData.WIP[eqpid, "Q"])
                    {
                        _Q[eqpid].Enqueue(cst);
                        if (_P[eqpid].X > 0)
                        {
                            _P[eqpid].ChangePortState(PortState.X, PortState.RX);
                        }
                    }
                }

                //Job Type for last proceessed cassette
                _JT.Add(eqpid, string.Empty);

                //Number of cassettes moving to the equipment
                _M.Add(eqpid, 0);
            }
        }
        #endregion
    }
}
