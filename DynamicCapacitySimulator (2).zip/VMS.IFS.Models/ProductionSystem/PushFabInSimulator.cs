﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public class PushFabInSimulator : FactoryObjectSimulator
    {
        #region Member Variables
        private PushReleaseController _RC;
        private List<Foup> _ReleasedCassettes;
        /// <summary>
        /// Kanban for Fab WIP (cassette)
        /// </summary>
        private int _FWK;
        /// <summary>
        /// Target Step WIP (cassette)
        /// </summary>
        //private int _TSW;
        /// <summary>
        /// Kanban for Target Step WIP (cassette)
        /// </summary>
        private int _TWK;

        //private string _TargetStepID;
        //private List<string> _TargetEQPList;

        private bool _Locked;
        #endregion

        #region Properties
        public List<Foup> ReleaseCassettes
        {
            get { return _ReleasedCassettes; }
        }      
        #endregion

        #region Constructors
        public PushFabInSimulator(Factory factory)
            : base("FabIn", factory)
        {
            _ReleasedCassettes = new List<Foup>();

            _Locked = false;
            //_TSW = 0;
            _FWK = int.MaxValue;
            _TWK = int.MaxValue;
        }
        #endregion

        #region Methods

        private void Execute_CFI_Routine(double now)
        {
            Foup nextCst = _RC.NextCassette();
            if (nextCst != null)
            {
                nextCst.ReleaseDate = now;
                nextCst.D = Factory.RTD.NextEQP(nextCst);

                _ReleasedCassettes.Add(nextCst);
                _FWK--;
                //_FWK -= nextCst.N;

                System.Diagnostics.Trace.WriteLine("[FabIn@" + now + "] " + nextCst.ToString());
            }

            if (nextCst != null)
                ScheduleLocalEvent("Move", now, this.Name, nextCst);

            //updateTSW();
            if (_FWK > 0 && _TWK > 0)
                _Locked = false;
            else
                _Locked = true;

            if (!_Locked)
                ScheduleLocalEvent("CFI", now);
        }

        private void Execute_CFO_Routine(double now, Foup cst)
        {
            _FWK++;

            //updateTSW();
            if (_FWK == 1 && _TWK > 0)
                _Locked = false;
            else
                _Locked = true;

            if (!_Locked)
                ScheduleLocalEvent("CFI", now);
        }

        private void Execute_CA_Routine(double now)
        {
            _TWK--;
        }

        private void Execute_CL_Routine(double now)
        {
            _TWK++;

            if (_TWK == 1 && _FWK > 0)
            {
                
                ScheduleLocalEvent("CFI", now);
            }
        }

        private void Execute_Move_Routine(double now, string eqpid, Foup cst)
        {
            ScheduleMirrorEvent("MaterialHandling", "Move", now, eqpid, cst);
        }
        
        public override void Initialize(Dictionary<string, object> args)
        {
            //Kanban for Fab WIP
            _FWK = (int)args[SimulationArguments.KanbanFabWIP];
            //Kanban for Step WIP
            _TWK = (int)args[SimulationArguments.KanbanStepWIP];

            //Decrement the WIP Cassettes from the FabOutPlan
            foreach (string eqpid in Factory.MasterData.WIP.BufferWIP.Keys)
            {
                List<Foup> cstlist = Factory.MasterData.WIP.BufferWIP[eqpid];
                _FWK -= cstlist.Count;
            }

            foreach (string eqpid in Factory.MasterData.WIP.QueueWIP.Keys)
            {
                List<Foup> cstlist = Factory.MasterData.WIP.QueueWIP[eqpid];

                if (Factory.MasterData.StepKanbanEqpList.Contains(eqpid))
                    _TWK -= cstlist.Count;
                
                _FWK -= cstlist.Count;
            }

            _RC = new PushReleaseController(this.Factory);
            _RC.Initialize(args);
        }

        public override void Run()
        {
            /////////////////////////////
            //TODO: FabOut 에서 WIP 차감
            /////////////////////////////

            ScheduleLocalEvent("CFI", 0);
        }

        public override void ExecuteLocalEvent(Engine.LocalEvent e)
        {
            if (e.ObjectName == "FabIn" && e.Name == "CFI" )
            {
                Execute_CFI_Routine(e.Time);
            }
            else if (e.ObjectName == "FabIn" && e.Name == "Move")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)e;
                Execute_Move_Routine(fle.Time, fle.EQPID, fle.Cassette);
            }
            else if (e.ObjectName == "FabIn" && e.Name == "CFO")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)e;
                Execute_CFO_Routine(e.Time, fle.Cassette);
            }
            else if (e.ObjectName == "FabIn" && e.Name == "CL")
            {
                Execute_CL_Routine(e.Time);
            }
            else if (e.ObjectName == "FabIn" && e.Name == "CA")
            {
                Execute_CA_Routine(e.Time);
            }
        }
        #endregion

    }

    
}
