﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public class BiInlineCell : Equipment
    {
        #region Member Variables
        /// <summary>
        /// Ouput Ports
        /// </summary>
        private Dictionary<string, Port> _PO;
        /// <summary>
        /// Status of track-in robot at a bi-inline cell
        /// </summary>
        private Dictionary<string, int> _RI;
        /// <summary>
        /// Status of track-out robot at a bi-inline cell
        /// </summary>
        private Dictionary<string, int> _RO;
        /// <summary>
        /// List of cassettes on the input queue of the bi-inline cell
        /// </summary>
        private Dictionary<string, FoupCollection> _IQ;

        private Dictionary<string, FoupCollection> _BWIP;
        /// <summary>
        /// List of cassettes on the output queue of the bi-inline cell
        /// </summary>
        private Dictionary<string, FoupCollection> _OQ;

        #endregion

        #region Properties
        public Dictionary<string, FoupCollection> IQ
        {
            get { return _IQ; }
        }

        public Dictionary<string, FoupCollection> OQ
        {
            get { return _OQ; }
        }

        public Dictionary<string, Port> PO
        {
            get { return _PO; }
        }

        public Dictionary<string, FoupCollection> BWIP
        {
            get { return _BWIP; }
        }

        #endregion

        #region Constructors
        public BiInlineCell(Factory factory)
            : base("BiInlineCell", factory)
        {
            _Q = new Dictionary<string, FoupCollection>();
            _P = new Dictionary<string, Port>();
            _PO = new Dictionary<string, Port>();
            _RI = new Dictionary<string, int>();
            _RO = new Dictionary<string, int>();
            _IQ = new Dictionary<string, FoupCollection>();
            _BWIP = new Dictionary<string, FoupCollection>();
            _OQ = new Dictionary<string, FoupCollection>();
            _M = new Dictionary<string, int>();
        }
        #endregion

        #region Event Routines
        private void Execute_bCL_Routine(double now, string b)
        {
            int cassetteID = Factory.RTD.NextCassette(b, _Q[b]);
            Foup cst = _Q[b].Dequeue(cassetteID);

            _IQ[b].Enqueue(cst);

            _P[b].ChangePortState(PortState.RX, PortState.F);

            bool c1 = RsvRI(b);
            
            if (c1)
                ScheduleLocalEvent("TrackIn", now, b);            
        }

        private void Execute_TrackIn_Routine(double now, string b)
        {
            _RI[b] = 0;
            Foup cst = _IQ[b].Dequeue();
            _BWIP[b].Enqueue(cst);
            
            if (cst.J == _JT[b])
                ScheduleLocalEvent("FGL", now, b, cst);
            else
                ScheduleLocalEvent("SS", now, b, cst);
        }

        private void Execute_SS_Routine(double now, string b, Foup cst)
        {
            ScheduleLocalEvent("FGL", now + MasterData.SetupTime[b], b, cst);
        }

        private void Execute_FGL_Routine(double now, string b, Foup cst)
        {
            double t1 = cst.N * MasterData.TactTime[cst.J, cst.P, b];
            ScheduleLocalEvent("LGL", now + t1, b, cst);

            double t2 = MasterData.TactTime[cst.J, cst.P, b] + MasterData.FlowTime[cst.J, cst.P, b];
            ScheduleLocalEvent("FGP", now + t2, b, cst);
        }

        private void Execute_LGL_Routine(double now, string b, Foup cst)
        {
            _JT[b] = cst.J;
            if (_Q[b].Count > 0 && _P[b].RX == 0)
            {
                _P[b].ChangePortState(PortState.F, PortState.RX);

                ScheduleLocalEvent("bCL", now, b);
            }
            else
                _P[b].ChangePortState(PortState.F, PortState.X);
        
            if (_IQ[b].Count > 0)
                _RI[b] = -1;
            else
                _RI[b] = 1;

            //Schedule Next Event              
            if (_IQ[b].Count > 0)
                ScheduleLocalEvent("TrackIn", now, b);            
        }

        private void Execute_FGP_Routine(double now, string b, Foup cst)
        {
            _OQ[b].Enqueue(cst);
            bool c2 = RsvRO(b);

            if (c2)
                ScheduleLocalEvent("FGU", now, b);
        }

        private void Execute_FGU_Routine(double now, string b)
        {
            _RO[b] = 0;
            Foup cst = _OQ[b].Dequeue();

            double t1 = cst.N * MasterData.TactTime[cst.J, cst.P, b];
            ScheduleLocalEvent("CD", now + t1, b, cst);
        }

        private void Execute_CD_Routine(double now, string b, Foup cst)
        {
            bool c3 = false;
            _PO[b].ChangePortState(PortState.E, PortState.X);
            if (_PO[b].E > 0)
            {
                if (_OQ[b].Count > 0) { 
                    _RO[b] = -1; c3 = true; 
                } else { 
                    _RO[b] = 1; c3 = false; 
                }
            }

            cst.P = RTD.NextStep(cst);
            cst.D = RTD.NextEQP(cst);

            _BWIP[b].Dequeue(cst.ID);

            if (c3)
                ScheduleLocalEvent("FGU", now, b);

            double te = 0; //empty-cassette supplying time
            ScheduleLocalEvent("X2PO", now + te, b);

            ScheduleMirrorEvent("MaterialHandling", "Move", now, b, cst);            
        }

        private void Execute_X2PO_Routine(double now, string b)
        {
            _PO[b].ChangePortState(PortState.X, PortState.E);

            bool c4 = false;
            if (_PO[b].E == 1)
            {
                if (_OQ[b].Count > 0)
                    c4 = true;
                else
                {
                    c4 = false;
                    _RO[b] = 1;
                }
            }

            if (c4)
                ScheduleLocalEvent("FGU", now, b);
        }        

        private bool RsvRI(string b)
        {
            if (_RI[b] == 1)
            {
                _RI[b] = -1; return true;
            }

            return false;
        }

        private bool RsvRO(string b)
        {
            if (_RO[b] == 1)
            {
                _RO[b] = -1; return true;
            }

            return false;
        }
        #endregion

        #region Methods
        public override void Run()
        {
            foreach (string eqpid in Factory.MasterData.EQP.BilineCells)
            {
                if (_IQ[eqpid].Count > 0)
                {
                    ScheduleLocalEvent("TrackIn", 0, eqpid);
                }

                int rx = _P[eqpid].RX;
                while (rx > 0)
                {
                    ScheduleLocalEvent("bCL", 0, eqpid);
                    rx--;
                } 
            }
        }

        public override void ExecuteLocalEvent(Engine.LocalEvent e)
        {
            if (e.ObjectName == this.Name)
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)e;
                if (e.Name == "bCL")
                {
                    Execute_bCL_Routine(fle.Time, fle.EQPID);
                }
                else if (e.Name == "TrackIn")
                {
                    Execute_TrackIn_Routine(fle.Time, fle.EQPID);
                }
                else if (e.Name == "FGL")
                {
                    Execute_FGL_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "FGP")
                {
                    Execute_FGP_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "SS")
                {
                    Execute_SS_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "LGL")
                {
                    Execute_LGL_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "FGU")
                {
                    Execute_FGU_Routine(fle.Time, fle.EQPID);
                }
                else if (e.Name == "X2PO")
                {
                    Execute_X2PO_Routine(fle.Time, fle.EQPID);
                }
                else if (e.Name == "CD")
                {
                    Execute_CD_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                //else if (e.Name == "Move")
                //{
                //    Execute_Move_Routine(fle.Time, fle.EQPID, fle.Cassette);
                //}
            }
        }

        public override void Initialize(Dictionary<string, object> args)
        {
            _Q = new Dictionary<string, FoupCollection>();
            _M = new Dictionary<string, int>();
            _P = new Dictionary<string, Port>();
            _PO = new Dictionary<string, Port>();
            _IQ = new Dictionary<string, FoupCollection>();
            _BWIP = new Dictionary<string, FoupCollection>();
            _OQ = new Dictionary<string, FoupCollection>();
            _RI = new Dictionary<string, int>();
            _RO = new Dictionary<string, int>();
            _JT = new Dictionary<string, string>();

            foreach (string eqpid in Factory.MasterData.EQP.BilineCells)
            {
                //Port
                Port inPorts = new Port(PortState.X, Factory.MasterData.EQPPort[eqpid].IN);
                _P.Add(eqpid, inPorts);

                Port outPorts = new Port(PortState.E, Factory.MasterData.EQPPort[eqpid].OUT);
                _PO.Add(eqpid, outPorts);

                //Port Queue
                _IQ.Add(eqpid, new FoupCollection());
                _BWIP.Add(eqpid, new FoupCollection());
                _OQ.Add(eqpid, new FoupCollection());
                if (MasterData.WIP.hasBWIP(eqpid))
                {
                    foreach (Foup cst in MasterData.WIP[eqpid, "B"])
                    {
                        _IQ[eqpid].Enqueue(cst);
                        _P[eqpid].ChangePortState(PortState.X, PortState.F);
                    }
                }
                
                //Track-in Robot
                _RI.Add(eqpid, 1);
                _RO.Add(eqpid, 1);

                //Stocker Queue
                _Q.Add(eqpid, new FoupCollection());
                if (MasterData.WIP.hasQWIP(eqpid))
                {
                    foreach (Foup cst in MasterData.WIP[eqpid, "Q"])
                    {
                        _Q[eqpid].Enqueue(cst);
                        if (_P[eqpid].X > 0)
                        {
                            _P[eqpid].ChangePortState(PortState.X, PortState.RX);
                        }
                    }
                }

                //Job Type for last proceessed cassette
                _JT.Add(eqpid, string.Empty);

                //Number of cassettes moving to the equipment
                _M.Add(eqpid, 0);
            }

        }
        #endregion
    }
}
