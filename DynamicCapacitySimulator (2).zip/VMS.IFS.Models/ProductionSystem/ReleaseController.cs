﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;

namespace VMS.IFS.Models
{
    public class ReleaseController
    {
        #region Member Variables
        private Factory _Factory;
        private Dictionary<string, ReleaseBatch> _ReleaseBatches;
        private List<Foup> _Cassetes;
        private Dictionary<int, DateTime> _ReleaseTimes;
        //private SortedList<DateTime, Cassette> _Cassetes;
        private double _TimeToNextRelease;

        private DateTime _ReferenceDate;
        #endregion

        #region Properties
        public Dictionary<string, ReleaseBatch> ReleaseBatches
        {
            get { return _ReleaseBatches; }
        }

        public double TimeToNextRelease
        {
            get
            {
                return _TimeToNextRelease;
            }
        }

        public int Count
        {
            get { return _Cassetes.Count; }
        }
        #endregion

        #region Constructors
        public ReleaseController(Factory factory)
        {
            _Factory = factory;
            _ReleaseBatches = new Dictionary<string, ReleaseBatch>();
            //_Cassetes = new SortedList<DateTime, Cassette>();
            _Cassetes = new List<Foup>();
            _ReleaseTimes = new Dictionary<int, DateTime>();
            _TimeToNextRelease = 0;
            _ReferenceDate = DateTime.MaxValue;
        }
        #endregion

        #region Methods
        public void Clear()
        {
            _ReleaseBatches.Clear();
            _Cassetes.Clear();
            _TimeToNextRelease = 0;
            _ReferenceDate = DateTime.MaxValue;
        }

        public void Add(ReleaseBatch rb)
        {
            //Create Cassettes
            int cassetteCapa = _Factory.MasterData.Product[rb.ProductID].GlassQuantity;
            string firstStepID = _Factory.MasterData.BOP.GetFirstStepID(rb.ProductID);
            rb.CreateCassettes(cassetteCapa, firstStepID);

            //Determine the release times of the cassettes
            TimeSpan releasePeriod = rb.ReleaseEndTime.Subtract(rb.ReleaseStartTime);
            double interReleaseTime = releasePeriod.TotalSeconds / rb.Cassettes.Count;
            interReleaseTime = Math.Ceiling(interReleaseTime);

            for (int i = 0; i < rb.Cassettes.Count; i++)
            {
                Foup cst = rb.Cassettes[i];
                DateTime releaseTime = rb.ReleaseStartTime.AddSeconds(interReleaseTime*i);
                _ReleaseTimes.Add(cst.ID, releaseTime);
                insertCassette(cst);               
            }

            if (rb.ReleaseStartTime < _ReferenceDate)
                _ReferenceDate = rb.ReleaseStartTime;

            _ReleaseBatches.Add(rb.ReleaseBatchID, rb);
        }

        private void insertCassette(Foup cst)
        {
            if (_Cassetes.Count == 0)
                _Cassetes.Add(cst);
            else
            {
                bool inserted = false;
                DateTime releaseTime = _ReleaseTimes[cst.ID];
                for (int i = 0; i < _Cassetes.Count; i++)
                {
                    DateTime targetReleaseTime = _ReleaseTimes[_Cassetes[i].ID];
                    if (releaseTime < targetReleaseTime)
                    {
                        _Cassetes.Insert(i, cst);
                        inserted = true;
                        break;
                    }
                }

                if (!inserted)
                    _Cassetes.Add(cst);
            }
        }

        public void AddRange(IEnumerable<ReleaseBatch> rblist)
        {
            foreach (ReleaseBatch rb in rblist)
            {
                Add(rb);
            }
        }

        public Foup NextCassette()
        {
            Foup rslt = null;

            if (_Cassetes.Count == 0)
                return rslt;

            rslt = _Cassetes[0];
            _Cassetes.RemoveAt(0);
            DateTime releaseTime = _ReleaseTimes[rslt.ID];
            _ReleaseTimes.Remove(rslt.ID);

            rslt.DueDate = rslt.DateTimeDueDate.Subtract(_ReferenceDate).TotalSeconds;

            if (_Cassetes.Count > 0)
            {
                DateTime nextReleaseTime = _ReleaseTimes[_Cassetes[0].ID];
                _TimeToNextRelease = nextReleaseTime.Subtract(releaseTime).TotalSeconds;
            }            
            return rslt;
        }
        #endregion
    }
}
