﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.Engine;

namespace VMS.IFS.Models
{
    public class FabOutSimulator : FactoryObjectSimulator
    {
        #region Member Variables
        private Dictionary<int, Foup> _FOQ;

        public double saveWIPTime;

        #endregion

        #region Properties
        public IEnumerable<Foup> FabOutCassettes
        {
            get { return _FOQ.Values; }
        }
        #endregion

        #region Constructors
        public FabOutSimulator(Factory factory, double save)
            : base("FabOut", factory) 
        {
            _FOQ = new Dictionary<int, Foup>();

            saveWIPTime = save;
        }
        #endregion

        #region Methods

        private void Execute_CFO_Routine(double now, Foup cst)
        {
            _FOQ.Add(cst.ID, cst);            
        }

        private void Execute_SaveWIP_Routine(double now)
        {           
            this.Factory.MasterData.WIP.Clear();
            Dictionary<string, List<Foup>> Q = new Dictionary<string, List<Foup>>();
            Dictionary<string, List<Foup>> B = new Dictionary<string, List<Foup>>();
            List<Foup> FO = new List<Foup>();

            foreach (string eqpid in this.Factory.MasterData.EQP.UnilineCells)
            {
                Q.Add(eqpid, new List<Foup>());
                B.Add(eqpid, new List<Foup>());

                foreach (Foup cstQ in this.Factory.UniInlineCell.Q[eqpid].Cassettes)
                {
                    Q[eqpid].Add(cstQ);
                }
                foreach (Foup cstB in this.Factory.UniInlineCell.B[eqpid].Cassettes)
                {
                    B[eqpid].Add(cstB);
                }
                foreach (Foup cstBWIP in this.Factory.UniInlineCell.BWIP[eqpid].Cassettes)
                {
                    B[eqpid].Add(cstBWIP);
                }
            }
            foreach (string eqpid in this.Factory.MasterData.EQP.BilineCells)
            {
                Q.Add(eqpid, new List<Foup>());
                B.Add(eqpid, new List<Foup>());                

                foreach (Foup cstQ in this.Factory.BiInlineCell.Q[eqpid].Cassettes)
                {
                    Q[eqpid].Add(cstQ);
                }
                foreach (Foup cstB in this.Factory.BiInlineCell.IQ[eqpid].Cassettes)
                {
                    B[eqpid].Add(cstB);
                }
                foreach (Foup cstBWIP in this.Factory.BiInlineCell.BWIP[eqpid].Cassettes)
                {
                    B[eqpid].Add(cstBWIP);
                }
            }
            foreach (string eqpid in this.Factory.MasterData.EQP.Ovens)
            {
                Q.Add(eqpid, new List<Foup>());
                B.Add(eqpid, new List<Foup>());

                foreach (Foup cstQ in this.Factory.Oven.Q[eqpid].Cassettes)
                {
                    Q[eqpid].Add(cstQ);
                }
                foreach (Foup cstB in this.Factory.Oven.B[eqpid].Cassettes)
                {
                    B[eqpid].Add(cstB);
                }
                foreach (Foup cstBWIP in this.Factory.Oven.BWIP[eqpid].Cassettes)
                {
                    B[eqpid].Add(cstBWIP);
                }
            }
            foreach (string eqpid in this.Factory.MasterData.EQP.Chambers)
            {
                Q.Add(eqpid, new List<Foup>());
                B.Add(eqpid, new List<Foup>());

                foreach (Foup cstQ in this.Factory.Chamber.Q[eqpid].Cassettes)
                {
                    Q[eqpid].Add(cstQ);
                }
                foreach (Foup cstB in this.Factory.Chamber.B[eqpid].Cassettes)
                {
                    B[eqpid].Add(cstB);
                }
            }
            foreach (string eqpid in this.Factory.MasterData.EQP.Equipments)
            {
                foreach (Foup cstM in this.Factory.MaterialHandling.M[eqpid].Cassettes)
                {
                    Q[eqpid].Add(cstM);
                }
            }

            foreach (int key in _FOQ.Keys)
            {
                FO.Add(_FOQ[key]);
            }

            this.Factory.MasterData.WIP.Save(Q, B, FO);        
        }

        public override void Run()
        {
            if (saveWIPTime >= 0)
            {
                ScheduleLocalEvent("SaveWIP", saveWIPTime);
            }
        }

        public override void ExecuteLocalEvent(LocalEvent e)
        {
            if (e.Name == "CFO" && e.ObjectName == "FabOut")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)e;
                Execute_CFO_Routine(fle.Time, fle.Cassette);
            }
            else if (e.Name == "SaveWIP")
            {                
                Execute_SaveWIP_Routine(e.Time);
            }
        }

        public override void Initialize(Dictionary<string, object> args)
        {
            _FOQ = new Dictionary<int, Foup>();            
        }


        #endregion
    }
}
