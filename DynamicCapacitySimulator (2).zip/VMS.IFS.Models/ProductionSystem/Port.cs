﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.Models
{
    //public enum PortState { EmptyPort, ReservedPort, FullCassettePort, EmptyCassettePort};
    public enum PortState { X, RX, F, E};
    public class Port
    {
        #region Member Variables
        private Dictionary<PortState, int> _PortStates;
        #endregion

        #region Properties
        public int this[PortState ps]
        {
            get { return _PortStates[ps]; }
        }
        public int X
        {
            get { return this[PortState.X]; }
        }
        public int RX
        {
            get { return this[PortState.RX]; }
        }
        public int F
        {
            get { return this[PortState.F]; }
        }
        public int E
        {
            get { return this[PortState.E]; }
        }

        public int Count
        {
            get { return this.X + this.RX + this.F + this.E; }
        }
        #endregion

        #region Constructors
        /// <summary>
        /// Consturctor for Port
        /// </summary>
        /// <param name="x">Number of Ports</param>
        public Port(int x)
        {
            _PortStates = new Dictionary<PortState, int>();
            _PortStates.Add(PortState.X, x);
            _PortStates.Add(PortState.RX, 0);
            _PortStates.Add(PortState.F, 0);
            _PortStates.Add(PortState.E, 0);
        }

        public Port(PortState ps, int x)
        {
            _PortStates = new Dictionary<PortState, int>();
            if (ps == PortState.X)
                _PortStates.Add(PortState.X, x);
            else
                _PortStates.Add(PortState.X, 0);
            
            if (ps == PortState.E)
                _PortStates.Add(PortState.E, x);
            else
                _PortStates.Add(PortState.E, 0);

            _PortStates.Add(PortState.RX, 0);
            _PortStates.Add(PortState.F, 0);
            
        }
        #endregion

        #region Methods
        public void ChangePortState(PortState from, PortState to)
        {
            int fromNo = _PortStates[from];
            int toNo = _PortStates[to];

            _PortStates[from] = fromNo - 1;
            _PortStates[to] = toNo + 1;
        }
        #endregion
    }
}
