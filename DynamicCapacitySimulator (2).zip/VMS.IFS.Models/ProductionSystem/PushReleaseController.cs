﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public class PushReleaseController
    {
        private Factory _Factory;

        private DateTime _CurFabOutDate;
        private DateTime _ReferenceDate;
        private Dictionary<DateTime, List<FabOutPlan>> _Data;
        /// <summary>
        /// Total quantity to be fab-out
        /// </summary>
        private int _RemainedQuantity;
        private List<string> _ProdList;

        public PushReleaseController(Factory factory)
        {
            _Factory = factory;

            _CurFabOutDate = _Factory.MasterData.FabOutPlan.FirstFabOutDate;

            _ProdList = new List<string>();
            _ProdList = _Factory.MasterData.Product.Products.ToList<string>();
            _R = new Random();
        }

        public void Initialize(Dictionary<string, object> args)
        {
            _ReferenceDate = (DateTime)args[SimulationArguments.ReferenceDateTime];
            _Data = _Factory.MasterData.FabOutPlan.Data;

            foreach (DateTime date in _Data.Keys)
            {
                List<FabOutPlan> plans = _Data[date];
                foreach (FabOutPlan p in plans)
                {
                    _RemainedQuantity += p.TargetQuantity;
                }
            }

            _LastCursors = new Dictionary<string, DateTime>();
            //Decrement the Fabout Cassettes from the FabOut Plan
            foreach (Foup foCst in _Factory.MasterData.WIP.FabOutWIP)
            {
                handleFabOutCassette(foCst);
            }

            //Decrement the WIP Cassettes from the FabOutPlan
            foreach (string key in _Factory.MasterData.WIP.BufferWIP.Keys)
            {
                List<Foup> cstlist = _Factory.MasterData.WIP.BufferWIP[key];
                foreach (Foup bCst in cstlist)
                {
                    handleFabOutCassette(bCst);
                }
            }

            foreach (string key in _Factory.MasterData.WIP.QueueWIP.Keys)
            {
                List<Foup> cstlist = _Factory.MasterData.WIP.QueueWIP[key];
                foreach (Foup qCst in cstlist)
                {
                    handleFabOutCassette(qCst);
                }
            }
        }

        private Dictionary<string, DateTime> _LastCursors;

        private void handleFabOutCassette(Foup cst)
        {
            DateTime cursorDate = _ReferenceDate;

            if (_LastCursors.ContainsKey(cst.J))
                cursorDate = _LastCursors[cst.J];

            while (!_Data.ContainsKey(cursorDate))
            {
                cursorDate = cursorDate.AddDays(1);
            }

            bool found = false;
            do
            {
                List<FabOutPlan> plans = _Data[cursorDate];

                foreach (FabOutPlan foPlan in plans)
                {
                    if (foPlan.ProductID == cst.J)
                    {
                        if (foPlan.RemainedQuantity > 0)
                        {
                            found = true;
                            foPlan.RemainedQuantity--;
                            _RemainedQuantity--;
                            
                            if (_LastCursors.ContainsKey(cst.J))
                                _LastCursors[cst.J] = cursorDate;
                            else
                                _LastCursors.Add(cst.J, cursorDate);

                            break;
                        }
                    }
                }

                cursorDate = cursorDate.AddDays(1);

                while (!_Data.ContainsKey(cursorDate))
                {
                    cursorDate = cursorDate.AddDays(1);
                }

            } while (!found);
        }

        public Foup NextCassette()
        {
            if (_RemainedQuantity == 0)
                return getNextCassetteOnRandom();
            else
            {
                return getNextCassetteOnFabOutPlan();
            }
        }

        private Random _R;
        private Foup getNextCassetteOnRandom()
        {
            int idx = _R.Next(_ProdList.Count);

            string prodid = _ProdList[idx];

            int cassetteCapa = _Factory.MasterData.Product[prodid].GlassQuantity;
            string firstStepID = _Factory.MasterData.BOP.GetFirstStepID(prodid);
            Foup nextCst = new Foup("1", prodid, firstStepID, cassetteCapa, string.Empty);
            nextCst.ReleaseDate = _Factory.Clock;
            nextCst.DueDate = DateTime.MaxValue.Subtract(_ReferenceDate).TotalSeconds;

            return nextCst;
        }

        private Foup getNextCassetteOnFabOutPlan()
        {
            while (!_Data.ContainsKey(_CurFabOutDate))
            {
                _CurFabOutDate.AddDays(1);
            }

            List<FabOutPlan> plans = _Data[_CurFabOutDate];
            plans.Sort(new FabOutPlanComparer());

            while (plans[0].RemainedQuantity == 0)
            {
                _CurFabOutDate = _CurFabOutDate.AddDays(1);

                while (!_Data.ContainsKey(_CurFabOutDate))
                {
                    _CurFabOutDate = _CurFabOutDate.AddDays(1);
                }

                //search again
                plans = _Data[_CurFabOutDate];
                plans.Sort(new FabOutPlanComparer());
            }

            FabOutPlan nextPlan = plans[0];

            //create cassette
            int cassetteCapa = _Factory.MasterData.Product[nextPlan.ProductID].GlassQuantity;
            string firstStepID = _Factory.MasterData.BOP.GetFirstStepID(nextPlan.ProductID);
            Foup nextCst = new Foup("1", nextPlan.ProductID, firstStepID, cassetteCapa, string.Empty);
            nextCst.ReleaseDate = _Factory.Clock;
            nextCst.DueDate = nextPlan.Date.Subtract(_ReferenceDate).TotalSeconds;

            //decrease ...rem
            nextPlan.RemainedQuantity--;
            _RemainedQuantity--;
            //decrease 된 것이 그대로 반영되는지 확인 요망

            return nextCst;
        }

    }
}
