﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;

namespace VMS.IFS.UI
{
    public class InputDataChecker
    {
        #region Member Variables
        public DataTable _DTError;
        #endregion

        #region Properties
        public DataTable Errors
        {
            get { return _DTError; }
        }
        #endregion

        #region Constructors
        public InputDataChecker()
        {
            initialize();
        }

        #endregion

        #region Methods
        private void initialize()
        {
            _DTError = new DataTable();
            _DTError.Columns.Add("Tab");
            _DTError.Columns.Add("Row");
            _DTError.Columns.Add("Column");
            _DTError.Columns.Add("Error");
        }

        public bool hasErrors(string name)
        {
            foreach (DataRow dr in _DTError.Rows)
            {
                if (dr[0].ToString() == name)
                    return true;
            }
            return false;
        }
        #endregion

        #region Error Check Method

        public void Check(InputDataSet ids)
        {
            _DTError.Rows.Clear();

            Dictionary<string, string> dicEQPID_TYPE = new Dictionary<string, string>();
            Dictionary<string, List<string>> dicPID_BOP = new Dictionary<string, List<string>>();
            Dictionary<string, List<string>> dicPIDSID_EQP = new Dictionary<string, List<string>>();
            List<string> lstSTK = new List<string>();

            EquipmentCheck(ids.EquipmentDataTable, dicEQPID_TYPE);
            EQPPortCheck(ids.EQP_PortDataTable, dicEQPID_TYPE, lstSTK);
            ProductCheck(ids.ProductDataTable, dicPID_BOP);
            BOPCheck(ids.BOPDataTable, dicPID_BOP);
            LoadableSetCheck(ids.LoadableSetDataTable, dicPID_BOP, dicEQPID_TYPE, dicPIDSID_EQP);
            ProcessingTimeCheck(ids.ProcessingTimeDataTable, dicPID_BOP, dicEQPID_TYPE, dicPIDSID_EQP);
            FaboutPlanCheck(ids.FabOutPlanDataTable, dicPID_BOP);
            MovingTimeCheck(ids.MovingTimeDataTable, lstSTK);
            WIPCheck(ids.WIPDataTable, dicPID_BOP, dicEQPID_TYPE);
        }

        private void EquipmentCheck(DataTable dtEQP, Dictionary<string, string> dicEQPID_TYPE)
        {
            string tab = "Equipment";

            List<string> listEQP_TYPE = new List<string>();
            listEQP_TYPE.Add("U");
            listEQP_TYPE.Add("B");
            listEQP_TYPE.Add("V");
            listEQP_TYPE.Add("C");

            for (int i = 0; i < dtEQP.Rows.Count; i++)
            {
                NullCheck(tab, dtEQP.Rows[i], i, new string[] { "EQP_ID", "EQP_TYPE", "NUM" });
                NotNegativeDoubleParsingCheck(tab, dtEQP.Rows[i], i, new string[] { "SETUP_TIME" });
                PositiveIntParsingCheck(tab, dtEQP.Rows[i], i, new string[] { "NUM" });

                if (!dicEQPID_TYPE.ContainsKey(dtEQP.Rows[i]["EQP_ID"].ToString()) && dtEQP.Rows[i]["EQP_ID"].ToString() != "")
                {
                    dicEQPID_TYPE.Add(dtEQP.Rows[i]["EQP_ID"].ToString(), dtEQP.Rows[i]["EQP_TYPE"].ToString());
                }

                if (!listEQP_TYPE.Contains(dtEQP.Rows[i]["EQP_TYPE"].ToString()) && dtEQP.Rows[i]["EQP_TYPE"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "EQP_TYPE", "Only use U (Uni-inline cell), B (Bi-inline cell), V (Oven type), or C (Chamber type)" });
                }

                if (!(dtEQP.Rows[i]["BOTTLENECK"].ToString() == "" || dtEQP.Rows[i]["BOTTLENECK"].ToString() == "BN"))
                {
                    _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "BOTTLENECK", "Only use BN (Bottleneck EQP) or blank (Not bottleneck EQP)" });
                }                
            }
        }

        private void EQPPortCheck(DataTable dtEQPPort, Dictionary<string, string> dicEQPID_TYPE, List<string> lstSTK)
        {
            string tab = "EQP_Port";

            Dictionary<string, string> dicEQP_PORT = new Dictionary<string, string>();

            for (int i = 0; i < dtEQPPort.Rows.Count; i++)
            {
                NullCheck(tab, dtEQPPort.Rows[i], i, new string[] { "EQP_ID", "PORT_TYPE", "PORT_CAPA", "STK_ID" });
                PositiveIntParsingCheck(tab, dtEQPPort.Rows[i], i, new string[] { "PORT_CAPA" });

                if (dicEQP_PORT.ContainsKey(dtEQPPort.Rows[i]["EQP_ID"].ToString()))
                {
                    dicEQP_PORT[dtEQPPort.Rows[i]["EQP_ID"].ToString()] += dtEQPPort.Rows[i]["PORT_TYPE"].ToString();
                }
                else
                {
                    dicEQP_PORT.Add(dtEQPPort.Rows[i]["EQP_ID"].ToString(), dtEQPPort.Rows[i]["PORT_TYPE"].ToString());
                }

                if (!lstSTK.Contains(dtEQPPort.Rows[i]["STK_ID"].ToString()) && dtEQPPort.Rows[i]["STK_ID"].ToString() != "")
                {
                    lstSTK.Add(dtEQPPort.Rows[i]["STK_ID"].ToString());
                }

                if (!dicEQPID_TYPE.ContainsKey(dtEQPPort.Rows[i]["EQP_ID"].ToString()) && dtEQPPort.Rows[i]["EQP_ID"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "EQP_ID", "Not defined EQP_ID in Equipment tab" });
                }
                else if (dtEQPPort.Rows[i]["PORT_TYPE"].ToString() != "I" && dtEQPPort.Rows[i]["PORT_TYPE"].ToString() != "O" && dtEQPPort.Rows[i]["PORT_TYPE"].ToString() != "U" && dtEQPPort.Rows[i]["PORT_TYPE"].ToString() != "V" && dtEQPPort.Rows[i]["PORT_TYPE"].ToString() != "C")
                {
                    _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "PORT_TYPE", "Only use U(Uni-inline cell I/O port), I (Bi-inline cell In port), O (Bi-inline cell Out port), V (Oven type eqiupment I/O port), or C (Chamber type equipment I/O port)" });
                }
                else if (!dicEQPID_TYPE[dtEQPPort.Rows[i]["EQP_ID"].ToString()].Equals(dtEQPPort.Rows[i]["PORT_TYPE"].ToString()) && dtEQPPort.Rows[i]["PORT_TYPE"].ToString() != "")
                {
                    if (dicEQPID_TYPE[dtEQPPort.Rows[i]["EQP_ID"].ToString()] == "B" && (dtEQPPort.Rows[i]["PORT_TYPE"].ToString() != "I" && dtEQPPort.Rows[i]["PORT_TYPE"].ToString() != "O"))
                    {
                        _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "PORT_TYPE", "Only use I (In-port) or O (Out-port) for bi-inline cells" });
                    }
                    else if (dicEQPID_TYPE[dtEQPPort.Rows[i]["EQP_ID"].ToString()] != "B" && (dicEQPID_TYPE[dtEQPPort.Rows[i]["EQP_ID"].ToString()] == "U" || dicEQPID_TYPE[dtEQPPort.Rows[i]["EQP_ID"].ToString()] == "V" || dicEQPID_TYPE[dtEQPPort.Rows[i]["EQP_ID"].ToString()] == "C"))
                    {
                        _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "PORT_TYPE", "Different PORT_TYPE with Equipment tab" });
                    }                    
                }                
            }

            foreach (string key in dicEQPID_TYPE.Keys)
            {
                if (!dicEQP_PORT.ContainsKey(key))
                {
                    _DTError.Rows.Add(new string[] { tab, "-", "-", key + " port is not defined" });
                }
                else if (dicEQPID_TYPE[key] == "B")
                {
                    if (dicEQP_PORT[key] != "IO" && dicEQP_PORT[key] != "OI")
                    {
                        _DTError.Rows.Add(new string[] { tab, "-", "-", key + " (bi-inline cell) needs to defined one in-port and one out-port" });
                    }
                }
            }
        }

        private void ProductCheck(DataTable dtProduct, Dictionary<string, List<string>> dicPID_BOP)
        {
            string tab = "Product";

            for (int i = 0; i < dtProduct.Rows.Count; i++)
            {
                NullCheck(tab, dtProduct.Rows[i], i, new string[] { "PROD_ID", "GLASS_QTY", "AVG_YIELD" });
                PositiveIntParsingCheck(tab, dtProduct.Rows[i], i, new string[] { "GLASS_QTY" });
                ZeroOneDoubleParsingCheck(tab, dtProduct.Rows[i], i, new string[] { "AVG_YIELD" });
                SpecialCharacterCheck(tab, dtProduct.Rows[i], i, new string[] { "PROD_ID" });

                if (dicPID_BOP.ContainsKey(dtProduct.Rows[i]["PROD_ID"].ToString()))
                {
                    _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "PROD_ID", "This product ID is already defined" });
                }
                else
                {
                    dicPID_BOP.Add(dtProduct.Rows[i]["PROD_ID"].ToString(), new List<string>());
                }
            }
        }

        private void BOPCheck(DataTable dtBOP, Dictionary<string, List<string>> dicPID_BOP)
        {
            string tab = "BOP";

            Dictionary<string, List<string>> dicPID_FROM = new Dictionary<string, List<string>>();
            Dictionary<string, List<string>> dicPID_TO = new Dictionary<string, List<string>>();

            for (int i = 0; i < dtBOP.Rows.Count; i++)
            {
                NullCheck(tab, dtBOP.Rows[i], i, new string[] { "PROD_ID", "FROM_STEP", "TO_STEP", "RATIO" });
                ZeroOneDoubleParsingCheck(tab, dtBOP.Rows[i], i, new string[] { "RATIO" });
                SpecialCharacterCheck(tab, dtBOP.Rows[i], i, new string[] { "PROD_ID" });

                if (!dicPID_BOP.ContainsKey(dtBOP.Rows[i]["PROD_ID"].ToString()) && dtBOP.Rows[i]["PROD_ID"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "PROD_ID", "Not defined PROD_ID in Product tab" });
                    continue;
                }

                if (dicPID_FROM.ContainsKey(dtBOP.Rows[i]["PROD_ID"].ToString()) && dtBOP.Rows[i]["PROD_ID"].ToString() != "")
                {
                    if (!dicPID_FROM[dtBOP.Rows[i]["PROD_ID"].ToString()].Contains(dtBOP.Rows[i]["FROM_STEP"].ToString()))
                    {
                        dicPID_FROM[dtBOP.Rows[i]["PROD_ID"].ToString()].Add(dtBOP.Rows[i]["FROM_STEP"].ToString());
                    }
                    if (!dicPID_TO[dtBOP.Rows[i]["PROD_ID"].ToString()].Contains(dtBOP.Rows[i]["TO_STEP"].ToString()))
                    {
                        dicPID_TO[dtBOP.Rows[i]["PROD_ID"].ToString()].Add(dtBOP.Rows[i]["TO_STEP"].ToString());
                    }
                }
                else
                {
                    dicPID_FROM.Add(dtBOP.Rows[i]["PROD_ID"].ToString(), new List<string>());
                    dicPID_FROM[dtBOP.Rows[i]["PROD_ID"].ToString()].Add(dtBOP.Rows[i]["FROM_STEP"].ToString());
                    dicPID_TO.Add(dtBOP.Rows[i]["PROD_ID"].ToString(), new List<string>());
                    dicPID_TO[dtBOP.Rows[i]["PROD_ID"].ToString()].Add(dtBOP.Rows[i]["TO_STEP"].ToString());
                }

                double temp;
                if (double.TryParse(dtBOP.Rows[i]["RATIO"].ToString(), out temp))
                {
                    if (temp > 1)
                    {
                        _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "RATIO", "Cannot be over 1" });
                    }
                }
            }

            foreach (string key in dicPID_FROM.Keys)
            {
                List<string> fromCheckList = new List<string>();
                foreach (string step in dicPID_FROM[key])
                {
                    if (!dicPID_BOP[key].Contains(step))
                        dicPID_BOP[key].Add(step);

                    if (!dicPID_TO[key].Contains(step))
                    {
                        fromCheckList.Add(step);
                    }
                }
                if (fromCheckList.Count > 1 || fromCheckList.Count == 0)
                {
                    _DTError.Rows.Add(new string[] { tab, "-", "-", "The first step of " + key + " is not clearly defined" });
                }
            }
            foreach (string key in dicPID_TO.Keys)
            {
                List<string> toCheckList = new List<string>();
                foreach (string step in dicPID_TO[key])
                {
                    if (!dicPID_BOP[key].Contains(step))
                        dicPID_BOP[key].Add(step);

                    if (!dicPID_FROM[key].Contains(step))
                    {
                        toCheckList.Add(step);
                    }
                }
                if (toCheckList.Count == 0)
                {
                    _DTError.Rows.Add(new string[] { tab, "-", "-", "The last step of " + key + " is not clearly defined" });
                }
            }
            foreach (string key in dicPID_BOP.Keys)
            {
                if (dicPID_BOP[key].Count == 0)
                {
                    _DTError.Rows.Add(new string[] { tab, "-", "-", "BOP of PROD_ID - " + key + " is not defined" });
                }
            }
        }

        private void LoadableSetCheck(DataTable dtLS, Dictionary<string, List<string>> dicPID_BOP, Dictionary<string, string> dicEQPID_TYPE, Dictionary<string, List<string>> dicPIDSID_EQP)
        {
            string tab = "Loadable Set";

            Dictionary<string, List<string>> dicVersion_PIDSTEPID = new Dictionary<string, List<string>>();

            for (int i = 0; i < dtLS.Rows.Count; i++)
            {
                NullCheck(tab, dtLS.Rows[i], i, new string[] { "VERSION_NO", "PROD_ID", "STEP_ID", "EQP_ID" });
                SpecialCharacterCheck(tab, dtLS.Rows[i], i, new string[] { "PROD_ID" });

                if (dicVersion_PIDSTEPID.ContainsKey(dtLS.Rows[i]["VERSION_NO"].ToString()) && dtLS.Rows[i]["VERSION_NO"].ToString() != "")
                {
                    dicVersion_PIDSTEPID[dtLS.Rows[i]["VERSION_NO"].ToString()].Add(dtLS.Rows[i]["PROD_ID"].ToString() + "," + dtLS.Rows[i]["STEP_ID"].ToString());
                }
                else if (dtLS.Rows[i]["VERSION_NO"].ToString() != "")
                {
                    dicVersion_PIDSTEPID.Add(dtLS.Rows[i]["VERSION_NO"].ToString(), new List<string>());
                    dicVersion_PIDSTEPID[dtLS.Rows[i]["VERSION_NO"].ToString()].Add(dtLS.Rows[i]["PROD_ID"].ToString() + "," + dtLS.Rows[i]["STEP_ID"].ToString());
                }

                if (dicPIDSID_EQP.ContainsKey(dtLS.Rows[i]["PROD_ID"].ToString() + "," + dtLS.Rows[i]["STEP_ID"].ToString()) && dtLS.Rows[i]["PROD_ID"].ToString() != "" && dtLS.Rows[i]["STEP_ID"].ToString() != "")
                {
                    if (!dicPIDSID_EQP[dtLS.Rows[i]["PROD_ID"].ToString() + "," + dtLS.Rows[i]["STEP_ID"].ToString()].Contains(dtLS.Rows[i]["EQP_ID"].ToString()))
                    {
                        dicPIDSID_EQP[dtLS.Rows[i]["PROD_ID"].ToString() + "," + dtLS.Rows[i]["STEP_ID"].ToString()].Add(dtLS.Rows[i]["EQP_ID"].ToString());
                    }
                }
                else if (dtLS.Rows[i]["PROD_ID"].ToString() != "" && dtLS.Rows[i]["STEP_ID"].ToString() != "")
                {
                    dicPIDSID_EQP.Add(dtLS.Rows[i]["PROD_ID"].ToString() + "," + dtLS.Rows[i]["STEP_ID"].ToString(), new List<string>());
                    dicPIDSID_EQP[dtLS.Rows[i]["PROD_ID"].ToString() + "," + dtLS.Rows[i]["STEP_ID"].ToString()].Add(dtLS.Rows[i]["EQP_ID"].ToString());
                }

                if (!dicPID_BOP.ContainsKey(dtLS.Rows[i]["PROD_ID"].ToString()) && dtLS.Rows[i]["PROD_ID"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "PROD_ID", "Not defined PROD_ID in Product tab" });
                }
                else if (!dicPID_BOP[dtLS.Rows[i]["PROD_ID"].ToString()].Contains(dtLS.Rows[i]["STEP_ID"].ToString()) && dtLS.Rows[i]["STEP_ID"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "STEP_ID", "Not defined STEP_ID in BOP tab" });
                }

                if (!dicEQPID_TYPE.ContainsKey(dtLS.Rows[i]["EQP_ID"].ToString()) && dtLS.Rows[i]["EQP_ID"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "EQP_ID", "Not defined EQP_ID in Equipment tab" });
                }
            }

            foreach (string keyVer in dicVersion_PIDSTEPID.Keys)
            {
                foreach (string keyPID in dicPID_BOP.Keys)
                {
                    if (dicPID_BOP[keyPID].Count == 0)
                    {
                        _DTError.Rows.Add(new string[] { tab, "-", "-", keyVer + " (Loadable Set Version) doesn't contain PROD_ID - " + keyPID });
                    }
                    foreach (string valSID in dicPID_BOP[keyPID])
                    {
                        string temp = keyPID + "," + valSID;
                        if (!dicVersion_PIDSTEPID[keyVer].Contains(temp))
                        {
                            _DTError.Rows.Add(new string[] { tab, "-", "-", keyVer + " (Loadable Set Version) doesn't contain {Product ID - " + keyPID + ", Step ID - " + valSID + "}" });
                        }
                    }
                }
            }
        }

        private void ProcessingTimeCheck(DataTable dtPT, Dictionary<string, List<string>> dicPID_BOP, Dictionary<string, string> dicEQPID_TYPE, Dictionary<string, List<string>> dicPIDSID_EQP)
        {
            string tab = "Processing Time";

            Dictionary<string, List<string>> dicCompare = new Dictionary<string, List<string>>();

            for (int i = 0; i < dtPT.Rows.Count; i++)
            {
                NullCheck(tab, dtPT.Rows[i], i, new string[] { "PROD_ID", "STEP_ID", "EQP_ID", "TACT_TIME", "FLOW_TIME" });
                NotNegativeDoubleParsingCheck(tab, dtPT.Rows[i], i, new string[] { "TACT_TIME", "FLOW_TIME" });
                SpecialCharacterCheck(tab, dtPT.Rows[i], i, new string[] { "PROD_ID" });

                if (dtPT.Rows[i]["PROD_ID"].ToString() != "" && dtPT.Rows[i]["STEP_ID"].ToString() != "")
                {
                    string key = dtPT.Rows[i]["PROD_ID"].ToString() + "," + dtPT.Rows[i]["STEP_ID"].ToString();
                    if (dicCompare.ContainsKey(key))
                    {
                        if (!dicCompare[key].Contains(dtPT.Rows[i]["EQP_ID"].ToString()))
                        {
                            dicCompare[key].Add(dtPT.Rows[i]["EQP_ID"].ToString());
                        }
                    }
                    else
                    {
                        dicCompare.Add(key, new List<string>());
                        dicCompare[key].Add(dtPT.Rows[i]["EQP_ID"].ToString());
                    }
                }

                if (!dicPID_BOP.ContainsKey(dtPT.Rows[i]["PROD_ID"].ToString()) && dtPT.Rows[i]["PROD_ID"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "PROD_ID", "Not defined PROD_ID in Product tab" });
                }
                else
                {
                    if (!dicPID_BOP[dtPT.Rows[i]["PROD_ID"].ToString()].Contains(dtPT.Rows[i]["STEP_ID"].ToString()) && dtPT.Rows[i]["STEP_ID"].ToString() != "")
                    {
                        _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "STEP_ID", "Not defined STEP_ID in BOP tab" });
                    }

                    if (!dicEQPID_TYPE.ContainsKey(dtPT.Rows[i]["EQP_ID"].ToString()) && dtPT.Rows[i]["EQP_ID"].ToString() != "")
                    {
                        _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "EQP_ID", "Not defined EQP_ID in Equipment tab" });
                    }
                }
            }

            foreach (string key in dicPID_BOP.Keys)
            {
                if (dicPID_BOP[key].Count == 0)
                {
                    _DTError.Rows.Add(new string[] { tab, "-", "-", "Processing time of PROD_ID - " + key + " is not defined" });
                }
            }
            
            foreach (string key in dicPIDSID_EQP.Keys)
            {
                string[] param = key.Split(',');
                string PID = param[0];
                string SID = param[1];

                if (!dicCompare.ContainsKey(key))
                {
                    _DTError.Rows.Add(new string[] { tab, "-", "-", "Processing time of {Product ID - " + PID + ", Step ID - " + SID + "} is not defined" });
                }
                else
                {
                    foreach (string valEQP in dicPIDSID_EQP[key])
                    {
                        if (!dicCompare[key].Contains(valEQP))
                        {
                            _DTError.Rows.Add(new string[] { tab, "-", "-", "Processing time of {Product ID - " + PID + ", Step ID - " + SID + ", EQP ID - " + valEQP + "} is not defined" });
                        }
                    }
                }
            }
        }

        private void FaboutPlanCheck(DataTable dtFP, Dictionary<string, List<string>> dicPID_BOP)
        {
            string tab = "Fabout Plan";

            List<string> columnList = new List<string>();
            List<string> woTimeColumnList = new List<string>();
            foreach (DataColumn dc in dtFP.Columns)
            {
                columnList.Add(dc.ColumnName);
                if(dc.ColumnName.ToUpper() != "DATE")
                    woTimeColumnList.Add(dc.ColumnName);
            }
            foreach (string pid in woTimeColumnList)
            {
                if (!dicPID_BOP.ContainsKey(pid))
                {
                    _DTError.Rows.Add(new string[] { tab, "-", "-", "Product ID - " + pid + " is not defined in Product tab" });
                }
            }
            foreach (string pid in dicPID_BOP.Keys)
            {
                if (!woTimeColumnList.Contains(pid))
                {
                    _DTError.Rows.Add(new string[] { tab, "-", "-", "Product ID - " + pid + " is not defined to column in this tab" });
                }
            }

            List<string> dateList = new List<string>();
            for (int i = 0; i < dtFP.Rows.Count; i++)
            {
                NullCheck(tab, dtFP.Rows[i], i, columnList.ToArray());
                PositiveIntParsingCheck(tab, dtFP.Rows[i], i, woTimeColumnList.ToArray());

                if (dateList.Contains(dtFP.Rows[i]["DATE"].ToString()))
                {
                    _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "DATE", "This date already defined" });
                }
                
                DateTime tempDate = new DateTime();
                if (dtFP.Rows[i]["DATE"].ToString().Length != 8)
                {
                    _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "DATE", "This value must be endtered by yyyyMMdd type" });
                }
                else if (!DateTime.TryParse(dtFP.Rows[i]["DATE"].ToString().Substring(0, 4) + "-" + dtFP.Rows[i]["DATE"].ToString().Substring(4, 2) + "-" + dtFP.Rows[i]["DATE"].ToString().Substring(6, 2), out tempDate) && dtFP.Rows[i]["DATE"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "DATE", "This value must be endtered by yyyyMMdd type" });
                }
                else
                {
                    dateList.Add(dtFP.Rows[i]["DATE"].ToString());
                }
            }
        }

        private void MovingTimeCheck(DataTable dtMT, List<string> lstSTK)
        {
            string tab = "Moving Time";

            List<string> lstSTKinMTtab = new List<string>();
            for (int i = 0; i < dtMT.Rows.Count; i++)
            {
                NullCheck(tab, dtMT.Rows[i], i, new string[] { "FROM_STK", "TO_STK", "MOVE_TIME" });
                NotNegativeDoubleParsingCheck(tab, dtMT.Rows[i], i, new string[] { "MOVE_TIME" });

                if (!lstSTK.Contains(dtMT.Rows[i]["FROM_STK"].ToString()) && dtMT.Rows[i]["FROM_STK"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "FROM_STK", "Not defined STK_ID in EQP_Port tab" });
                }

                if (!lstSTK.Contains(dtMT.Rows[i]["TO_STK"].ToString()) && dtMT.Rows[i]["TO_STK"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "TO_STK", "Not defined STK_ID in EQP_Port tab" });
                }

                if(!lstSTKinMTtab.Contains(dtMT.Rows[i]["FROM_STK"].ToString()))
                {
                    lstSTKinMTtab.Add(dtMT.Rows[i]["FROM_STK"].ToString());
                }
                if (!lstSTKinMTtab.Contains(dtMT.Rows[i]["TO_STK"].ToString()))
                {
                    lstSTKinMTtab.Add(dtMT.Rows[i]["TO_STK"].ToString());
                }
            }

            foreach (string stk in lstSTK)
            {
                if (!lstSTKinMTtab.Contains(stk))
                {
                    _DTError.Rows.Add(new string[] { tab, "-", "-", "Moving Time related to STK_ID - " + stk + " is not defined" });
                }
            }
        }

        private void WIPCheck(DataTable dtWIP, Dictionary<string, List<string>> dicPID_BOP, Dictionary<string, string> dicEQPID_TYPE)
        {
            string tab = "WIP";

            List<string> eqpList = new List<string>();
            for (int i = 0; i < dtWIP.Rows.Count; i++)
            {
                string eqp = dtWIP.Rows[i]["EQP_ID"].ToString();
                if (!dicEQPID_TYPE.ContainsKey(eqp) && eqp != "FabOut")
                {
                    _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "EQP_ID", "Not defined EQP_ID in Equipment tab" });
                    continue;
                }
                else
                {
                    if (eqpList.Contains(eqp))
                    {
                        _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "EQP_ID", "EQP_ID - " + eqp + " is already defined in this tab" });
                    }
                    else
                    {
                        eqpList.Add(eqp);
                    }
                }

                if (eqp != "FabOut")
                {
                    string[] paramQ = dtWIP.Rows[i]["Q"].ToString().Split(new char[] { '(', ',', ')' });
                    if (paramQ.Length != 1 && paramQ.Length % 5 != 0)
                    {
                        _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "Q", "Check the format for cassette in the Q -> format: (PROD_ID, STEP_ID, GLASS_QUANTITY)" });
                    }
                    else if (paramQ.Length == 1 && paramQ[0] != "")
                    {
                        _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "Q", "Check the format for cassette in the Q -> format: (PROD_ID, STEP_ID, GLASS_QUANTITY)" });
                    }
                    else
                    {
                        for (int j = 1; j < paramQ.Length; j = j + 5)
                        {
                            string pID = paramQ[j];
                            string sID = paramQ[j + 1];
                            if (!dicPID_BOP.ContainsKey(pID))
                            {
                                int num = ((j - 1) / 5) + 1;
                                _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "Q", "PROD_ID - " + pID + " (cassette #" + num + ") in the Q column is not defined in Product tab" });
                            }
                            else if (!dicPID_BOP[pID].Contains(sID))
                            {
                                int num = ((j - 2) / 5) + 1;
                                _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "Q", "STEP_ID - " + sID + " (cassette #" + num + ") in the Q column is not defined in BOP tab" });
                            }
                            int qty = 0;
                            if (!int.TryParse(paramQ[j + 2], out qty) && paramQ[j + 2] != "")
                            {
                                int num = ((j - 3) / 5) + 1;
                                _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "Q", "GLASS_QUANTITY of cassette #" + num + " in the Q column makes parsing error(int)" });
                            }
                        }
                    }

                    string[] paramB = dtWIP.Rows[i]["B"].ToString().Split(new char[] { '(', ',', ')' });
                    if (paramB.Length != 1 && paramB.Length % 5 != 0)
                    {
                        _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "B", "Check the format for cassette in the B -> format: (PROD_ID, STEP_ID, GLASS_QUANTITY)" });
                    }
                    else
                    {
                        for (int j = 1; j < paramB.Length; j = j + 5)
                        {
                            string pID = paramB[j];
                            string sID = paramB[j + 1];
                            if (!dicPID_BOP.ContainsKey(pID))
                            {
                                int num = ((j - 1) / 5) + 1;
                                _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "B", "PROD_ID - " + pID + " (cassette #" + num + ") in the B column is not defined in Product tab" });
                            }                            
                            else if (!dicPID_BOP[pID].Contains(sID))
                            {
                                int num = ((j - 2) / 5) + 1;
                                _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "B", "STEP_ID - " + sID + " (cassette #" + num + ") in the Q column is not defined in BOP tab" });
                            }
                            int qty = 0;
                            if (!int.TryParse(paramB[j + 2], out qty) && paramB[j + 2] != "")
                            {
                                int num = ((j - 3) / 5) + 1;
                                _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "B", "GLASS_QUANTITY of cassette #" + num + " in the B column makes parsing error(int)" });
                            }
                        }
                    }
                }
                else
                {
                    string[] paramFOQ = dtWIP.Rows[i]["Q"].ToString().Split(new char[] { '(', ',', ')' });
                    if (paramFOQ.Length != 1 && paramFOQ.Length % 4 != 0)
                    {
                        _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "Q", "Check the format for cassette in the Q for Fab out -> format: (PROD_ID, GLASS_QUANTITY)" });
                    }
                    else if (paramFOQ.Length == 1 && paramFOQ[0] != "")
                    {
                        _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "Q", "Check the format for cassette in the Q for Fab out -> format: (PROD_ID, GLASS_QUANTITY)" });
                    }
                    else
                    {
                        for (int j = 1; j < paramFOQ.Length; j = j + 4)
                        {
                            string pID = paramFOQ[j];
                            if (!dicPID_BOP.ContainsKey(pID))
                            {
                                int num = ((j - 1) / 4) + 1;
                                _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "Q", "PROD_ID - " + pID + " (Fab out data #" + num + ") in the Q column for Fab out is not defined in Product tab" });
                            }
                            int qty = 0;
                            if (!int.TryParse(paramFOQ[j + 1], out qty) && paramFOQ[j + 1] != "")
                            {
                                int num = ((j - 2) / 4) + 1;
                                _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "Q", "GLASS_QUANTITY of Fab out data #" + num + " in the Q column makes parsing error(int)" });
                            }
                        }
                    }

                    if (dtWIP.Rows[i]["B"].ToString() != "")
                    {
                        _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "B", "This field must be empty" });
                    }
                }
            }

            List<string> definedEQPID = new List<string>();
            foreach (DataRow dr in dtWIP.Rows)
            {
                definedEQPID.Add(dr["EQP_ID"].ToString());
            }
            foreach (string key in dicEQPID_TYPE.Keys)
            {
                if (!definedEQPID.Contains(key))
                {
                    _DTError.Rows.Add(new string[] { tab, "-", "-", "Initial WIP for EQP ID - " + key + " is not defined" });
                }
            }
        }

        private void SpecialCharacterCheck(string tab, DataRow dr, int i, string[] colName)
        {
            foreach (string col in colName)
            {
                if (dr[col].ToString().Contains('[') || dr[col].ToString().Contains(']') || dr[col].ToString().Contains('!') || dr[col].ToString().Contains('.')
                    || dr[col].ToString().Contains('(') || dr[col].ToString().Contains(')') || dr[col].ToString().Contains(','))
                {
                    _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), col, "The value contains special character cannot be used." });
                }
            }
        }

        private void NullCheck(string tab, DataRow dr, int i, string[] colName)
        {
            foreach (string col in colName)
            {
                if (dr[col].ToString() == "")
                {
                    _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), col, "Null error" });
                }
            }
        }

        private void PositiveIntParsingCheck(string tab, DataRow dr, int i, string[] colName)
        {
            foreach (string col in colName)
            {
                int temp;

                if (dr[col].ToString() != "")
                {
                    if (!int.TryParse(dr[col].ToString(), out temp))
                    {
                        _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), col, "Parsing error (int)" });
                    }
                    else if (temp <= 0)
                    {
                        _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), col, "This value must be positive integer" });
                    }
                }                  
            }
        }

        private void ZeroOneDoubleParsingCheck(string tab, DataRow dr, int i, string[] colName)
        {
            foreach (string col in colName)
            {
                double temp;

                if (dr[col].ToString() != "")
                {
                    if (!double.TryParse(dr[col].ToString(), out temp))
                    {
                        _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), col, "Parsing error (double)" });
                    }
                    else if(temp <= 0 || temp > 1)
                    {
                        _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), col, "This value must be in (0, 1]" });
                    }
                }                                
            }
        }

        private void NotNegativeDoubleParsingCheck(string tab, DataRow dr, int i, string[] colName)
        {
            foreach (string col in colName)
            {
                double temp;

                if (dr[col].ToString() != "")
                {
                    if (!double.TryParse(dr[col].ToString(), out temp))
                    {
                        _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), col, "Parsing error (double)" });
                    }
                    else if (temp < 0)
                    {
                        _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), col, "This value must be greater than or equal to 0" });
                    }
                } 
            }
        }

        #endregion

    }
}
