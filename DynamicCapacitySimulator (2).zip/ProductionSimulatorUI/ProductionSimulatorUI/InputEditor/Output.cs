﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using VMS.Foundation.Logging;

namespace VMS.IFS.UI
{
    public partial class Output : DockContent
    {
        private NewInputEditor _Parent;

        TextBoxLogHandler2 handler1; 
        TextBoxLogHandler2 handler2;
        TextBoxLogHandler2 handler3;
 
        public Output(NewInputEditor parent)
        {
            _Parent = parent;
            InitializeComponent();

        }

        public void ConnectLogHandlers()
        {

            VMS.Foundation.Logging.SimpleFormatter formatter =
                new VMS.Foundation.Logging.SimpleFormatter();
            formatter.WriteLoggerInfo = false;

            formatter.WriteTimeStamp = false;
            Logger logger1 = LogManager.GetLogger("SimulationCoordinator");
            logger1.Level = LogLevel.Always;

            handler1 =
                new TextBoxLogHandler2(txtGeneral, formatter);
            logger1.AddHandler(handler1);

            Logger logger2 = LogManager.GetLogger("JobSelectionRule");
            logger2.Level = LogLevel.Always;

            handler2 =
                new TextBoxLogHandler2(txtJSR, formatter);
            logger2.AddHandler(handler2);

            Logger logger3 = LogManager.GetLogger("MachineSelectionRule");
            logger3.Level = LogLevel.Always;

            handler3 =
                new TextBoxLogHandler2(txtMSR, formatter);
            logger3.AddHandler(handler3);
            
            txtGeneral.Visible = true;
            txtJSR.Visible = false;
            txtMSR.Visible = false;
        }

        public void DisconnectLogHandlers()
        {
            Logger logger1 = LogManager.GetLogger("SimulationCoordinator");
            Logger logger2 = LogManager.GetLogger("JobSelectionRule");
            Logger logger3 = LogManager.GetLogger("MachineSelectionRule");

            logger1.RemoveHandler(handler1);
            logger2.RemoveHandler(handler2);
            logger3.RemoveHandler(handler3);
        }

        private void cbOutputSources_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbOutputSources.SelectedIndex == 0)
            {
                txtGeneral.Visible = true;
                txtJSR.Visible = false;
                txtMSR.Visible = false;
            }
            else if (cbOutputSources.SelectedIndex == 1)
            {
                txtGeneral.Visible = false;
                txtJSR.Visible = true;
                txtMSR.Visible = false;
            }
            else if (cbOutputSources.SelectedIndex == 2)
            {
                txtGeneral.Visible = false;
                txtJSR.Visible = false;
                txtMSR.Visible = true;
            }
        }

        public void Clear()
        {
            txtGeneral.Text = "";
            txtJSR.Text = "";
            txtMSR.Text = "";
        }
    }
}
