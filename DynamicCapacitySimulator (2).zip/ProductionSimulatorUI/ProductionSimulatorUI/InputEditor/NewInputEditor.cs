﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using OfficeOpenXml;
using VMS.IFS.DataModel.InputData;
using WeifenLuo.WinFormsUI.Docking;
using VMS.Foundation.Logging;

namespace VMS.IFS.UI
{
    public partial class NewInputEditor : Form
    {
        #region Member Variables
        public InputDataSet _InputData;
        public Dictionary<string, bool> _IsModified;
        private bool _IsNew;
        public string _FileName;        
        
        private Dictionary<string, TableEditor> _TableEditors;
        private ModelExplorer _ModelExplorer;
        private ErrorList _ErrorList;
        private Output _Output;

        private string[] _SheetNames;
        private Dictionary<string, string> _SheetToTableMapping;
        public Dictionary<string, string> _TableToSheetMapping;
        public Dictionary<string, object> RunOptions;

        private InputDataChecker _Checker;

        private bool _CatchEvent = false;
        private int _CntEvent = 1;
        #endregion

        #region Properties
        public bool HasErrors
        {
            get { return (_Checker.Errors.Rows.Count > 0); }
        }

        public bool IsNew
        {
            get { return _IsNew; }
        }

        public InputDataSet InputData
        {
            get { return _InputData; }
        }

        public TableEditor TableEditor(string name)
        {
            return _TableEditors[name];
        }

        #endregion

        #region Constructors
        public NewInputEditor(string fileName)
        {
            _FileName = fileName;

            InitializeComponent();

            initialize();

            if (_FileName == "")
                _IsNew = true;
            else
                _IsNew = false;

            open(); 
        }

        private void initialize()
        {
            //1. Sheet to Table, Table to Sheet Mapping
            _SheetNames = new string[] { "Equipment", "EQP_Port", "Product", "BOP", "Loadable Set", "Processing Time", "Fabout Plan", "Moving Time", "WIP" };
            _SheetToTableMapping = new Dictionary<string, string>();
            _TableToSheetMapping = new Dictionary<string, string>();
            _IsModified = new Dictionary<string, bool>();

            AddMappingRelation("Equipment", "EquipmentDataTable");
            AddMappingRelation("EQP_Port", "EQP_PortDataTable");
            AddMappingRelation("Product", "ProductDataTable");
            AddMappingRelation("BOP", "BOPDataTable");
            AddMappingRelation("Loadable Set", "LoadableSetDataTable");
            AddMappingRelation("Processing Time", "ProcessingTimeDataTable");
            //AddMappingRelation("Order", "OrderDataTable");
            AddMappingRelation("Moving Time", "MovingTimeDataTable");
            AddMappingRelation("WIP", "WIPDataTable");
            AddMappingRelation("Fabout Plan", "FabOutPlanDataTable");

            //2. Windows
            _TableEditors = new Dictionary<string, TableEditor>();
            _ModelExplorer = new ModelExplorer(this);
            _ModelExplorer.TableSelected += new InputDataTableSelectedEventHandler(OnModelExplorer_TableSelected);  
            
            _ErrorList = new ErrorList(this);
            _Output = new Output(this);

            //3. Input Data Checker
            _Checker = new InputDataChecker();

            //4. Logger
            //LogManager.GetLogger("
        }

        private void AddMappingRelation(string sheetName, string tableName)
        {
            _SheetToTableMapping.Add(sheetName, tableName);
            _TableToSheetMapping.Add(tableName, sheetName);
            _IsModified.Add(sheetName, false);
        }
        #endregion

        #region Open and Save Operation Methods
        private void open()
        {
            _InputData = new InputDataSet();

            if (!string.IsNullOrEmpty(_FileName))
            {
                //treeView1.Nodes[0].Text = this.fileName;

                string conStr = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + _FileName + ";Extended Properties=" + '"' + "Excel 12.0;HDR=YES;" + '"';
                OleDbConnection excelConnection = new OleDbConnection(conStr);

                OleDbDataAdapter da = new OleDbDataAdapter();
                excelConnection.Open();

                foreach (string sheetName in _SheetNames)
                {
                    if (!_SheetToTableMapping.ContainsKey(sheetName))
                        continue;

                    OleDbCommand cmd = new OleDbCommand("SELECT * FROM [" + sheetName + "$]", excelConnection);

                    da.SelectCommand = cmd;

                    DataTable table = _InputData.Tables[_SheetToTableMapping[sheetName]];
                    try
                    {
                        da.Fill(table);
                    }
                    catch (OleDbException e)
                    {
                        
                    }

                    if (sheetName.Equals("WIP"))
                    {
                        BuildWipTable(_InputData);
                    }
                    else if (sheetName.Equals("Fabout Plan"))
                    {
                        BuildFabOutTable(_InputData);
                    }

                    TableEditor tEditor = new TableEditor(this);
                    tEditor.LoadData(table.DefaultView);
                    tEditor.Text = sheetName;

                    dockPanel1.ActiveDocumentChanged += new EventHandler(dockPanel1_ActiveDocumentChanged);                    
                    
                    _TableEditors.Add(sheetName, tEditor);
                    _ModelExplorer.Add("InputData", sheetName);
                }

                excelConnection.Close();
                excelConnection.Dispose();

                Save("Save");

                //Check Erros
                doCheckErrors();
            }
            else
            {
                foreach (string sheetName in _SheetNames)
                {
                    if (!_SheetToTableMapping.ContainsKey(sheetName))
                        continue;
                    
                    DataTable table = _InputData.Tables[_SheetToTableMapping[sheetName]];

                    TableEditor tEditor = new TableEditor(this);
                    tEditor.LoadData(table.DefaultView);
                    tEditor.Text = sheetName;

                    _TableEditors.Add(sheetName, tEditor);
                    _ModelExplorer.Add("InputData", sheetName);
                }
            }

            createLayout();

            _CatchEvent = true;
        }
        
        void dockPanel1_ActiveDocumentChanged(object sender, EventArgs e)
        {            
            if (_CatchEvent && dockPanel1.ActiveDocument != null)
            {
                if (_CntEvent < dockPanel1.DocumentsCount)
                {
                    _CntEvent++;
                }
                else if(_CntEvent == dockPanel1.DocumentsCount)
                {
                    if (dockPanel1.ActiveDocument.ToString().Contains("Fabout") && _IsModified["Product"])
                    {
                        //doCheckErrors();

                        //if (_Checker.hasErrors("Product"))
                        //{
                        //    MessageBox.Show("Errors in Product tab are removed before editing Fabout Plan tab. \r\nPlease go back to Product tab.");
                        //    _CntEvent = 1;                            
                        //    return;
                        //}

                        BuildFabOutTable(_InputData);

                        _TableEditors["Fabout Plan"].LoadData(_InputData.FabOutPlanDataTable.DefaultView);
                    }
                    else if (dockPanel1.ActiveDocument.ToString().Contains("WIP") && _IsModified["Equipment"])
                    {
                        //doCheckErrors();

                        //if (_Checker.hasErrors("Equipment"))
                        //{
                        //    MessageBox.Show("Errors in Equipment tab are removed before editing Fabout Plan tab. \r\nPlease go back to Equipment tab.");
                        //    _CntEvent = 1;                            
                        //    return;
                        //}
                        
                        BuildWipTable(_InputData);

                        _TableEditors["WIP"].LoadData(_InputData.WIPDataTable.DefaultView);
                    }
                    _CntEvent = 1;             
                }
            }
        }

        private void BuildWipTable(InputDataSet ids)
        {
            List<string> eqpInEQPSheet = new List<string>();
            List<string> eqpInWIPSheet = new List<string>();
            bool isFabOut = false;
            InputDataSet.WIPDataTableRow faboutRow = ids.WIPDataTable.NewWIPDataTableRow();

            foreach (InputDataSet.EquipmentDataTableRow dr in ids.EquipmentDataTable.Rows)
            {
                if (!eqpInEQPSheet.Contains(dr.EQP_ID))
                    eqpInEQPSheet.Add(dr.EQP_ID);
            }
            foreach (InputDataSet.WIPDataTableRow dr in ids.WIPDataTable.Rows)
            {
                if (dr.EQP_ID == "FabOut")
                {
                    isFabOut = true;                                      
                    continue;
                }
                eqpInWIPSheet.Add(dr.EQP_ID);
            }            

            foreach (string eqp in eqpInEQPSheet)
            {
                if (!eqpInWIPSheet.Contains(eqp))
                {
                    DataRow dr = ids.WIPDataTable.NewRow();
                    dr["EQP_ID"] = eqp;
                    ids.WIPDataTable.Rows.Add(dr);
                }
                eqpInWIPSheet.Remove(eqp);
            }
            foreach (string eqp in eqpInWIPSheet)
            {
                foreach (InputDataSet.WIPDataTableRow dr in ids.WIPDataTable.Rows)
                {
                    if (eqp == dr["EQP_ID"].ToString())
                    {
                        ids.WIPDataTable.RemoveWIPDataTableRow(dr);
                        break;
                    }
                }
            }

            if (!isFabOut)
            {
                DataRow dr = ids.WIPDataTable.NewRow();
                dr["EQP_ID"] = "FabOut";
                ids.WIPDataTable.Rows.Add(dr);
            }
            else
            {
                foreach (InputDataSet.WIPDataTableRow dr in ids.WIPDataTable.Rows)
                {
                    if (dr.EQP_ID == "FabOut")
                    {                        
                        for (int i = 0; i < ids.WIPDataTable.Columns.Count; i++)
                        {
                            faboutRow[i] = dr[i];
                        }
                        ids.WIPDataTable.RemoveWIPDataTableRow(dr);
                        break;
                    }                    
                }
                ids.WIPDataTable.Rows.Add(faboutRow);
            }
        }

        private void BuildFabOutTable(InputDataSet ids)
        {
            List<string> eqpInProductSheet = new List<string>();
            List<string> eqpInFabOutSheet = new List<string>();
            bool isDate = false;

            foreach (InputDataSet.ProductDataTableRow dr in ids.ProductDataTable.Rows)
            {
                if(!eqpInProductSheet.Contains(dr.PROD_ID))
                    eqpInProductSheet.Add(dr.PROD_ID);
            }            
            foreach (DataColumn dc in ids.FabOutPlanDataTable.Columns)
            {
                if (dc.ColumnName == "DATE")
                {
                    isDate = true;
                    continue;
                }
                eqpInFabOutSheet.Add(dc.ColumnName);
            }

            if (!isDate)
            {
                ids.FabOutPlanDataTable.Columns.Add("DATE", typeof(string));
            }
            foreach (string pID in eqpInProductSheet)
            {
                if (!eqpInFabOutSheet.Contains(pID))
                {
                    ids.FabOutPlanDataTable.Columns.Add(pID, typeof(string));
                }
                eqpInFabOutSheet.Remove(pID);
            }
            foreach (string pID in eqpInFabOutSheet)
            {
                foreach (DataColumn dc in ids.FabOutPlanDataTable.Columns)
                {
                    if (pID == dc.ColumnName)
                    {
                        ids.FabOutPlanDataTable.Columns.Remove(pID);
                        break;
                    }
                }
            }
        }

        public void CheckErrors()
        {
            doCheckErrors();
        }

        private void doCheckErrors()
        {
            _Checker.Check(_InputData);
            _ErrorList.LoadData(_Checker.Errors.DefaultView);

            _ErrorList.Show();
        }

        public void Save(string type) //type이 "Save"이면 저장, "SaveAs"면 다른 이름으로 저장
        {
            if (type == "SaveAs" || _IsNew)
            {
                this.saveFileDialog1.Filter = "Excel Files|*.xls;*.xlsx|All files|*.*";
                if (this.saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    _FileName = saveFileDialog1.FileName;
                    _IsNew = false;
                }
            }

            if (_FileName != "")
            {
                FileInfo file = new FileInfo(_FileName);
                if (file.Exists)
                {
                    try
                    {
                        file.Delete();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("The specified file is used by other process. Check the file is closed.");
                        return;
                    }

                    file = new FileInfo(_FileName);
                }
                ExcelPackage package = new ExcelPackage(file);

                foreach (DataTable dt in _InputData.Tables)
                {
                    ExcelWorksheet worksheet = 
                        package.Workbook.Worksheets.Add(_TableToSheetMapping[dt.TableName]);
                    if(dt.Columns.Count > 0)
                        worksheet.Cells.LoadFromDataTable(dt, true);
                }

                package.Save();

                //_IsModified = false;
            }
        }        
                
        #endregion

        #region Event Handling Methods
        private void NewInputEditor_FormClosing(object sender, FormClosingEventArgs e)
        {
            bool cancel = false;

            foreach (string key in _IsModified.Keys)
            {
                if (_IsModified[key])
                {
                    switch (MessageBox.Show(this, "Current input file is changed.\r\nSave changes?", "Save changes", MessageBoxButtons.YesNoCancel))
                    {
                        case DialogResult.Yes:
                            {
                                Save("Save");
                                return;
                            }
                        case DialogResult.No:
                            {
                                return;
                            }
                        case DialogResult.Cancel:
                            {
                                e.Cancel = true;
                                cancel = true;
                                break;
                            }
                    }
                }
                if (cancel)
                    break;
            }
        }

        public void OnModelExplorer_TableSelected(string name)
        {
            if (_TableEditors.ContainsKey(name))
            {
                if (name.Contains("Fab") && _IsModified["Product"])
                {
                    //doCheckErrors();

                    //if (_Checker.hasErrors("Product"))
                    //{
                    //    MessageBox.Show("Errors in Product tab are removed before editing Fabout Plan tab.");
                    //    return;
                    //}
                    
                    BuildFabOutTable(_InputData);

                    _TableEditors["Fabout Plan"].LoadData(_InputData.FabOutPlanDataTable.DefaultView);                    
                }
                else if (name.Contains("WIP") && _IsModified["Equipment"])
                {
                    //doCheckErrors();

                    //if (_Checker.hasErrors("Equipment"))
                    //{
                    //    MessageBox.Show("Errors in Equipment tab are removed before editing WIP tab.");
                    //    return;
                    //}
                    
                    BuildWipTable(_InputData);

                    _TableEditors["WIP"].LoadData(_InputData.WIPDataTable.DefaultView);
                }
                
                TableEditor editor = _TableEditors[name];
                editor.Show();
            }
        }
        #endregion

        #region Window Management Methods
        public void ResetLayout()
        {
            createLayout();

        }

        public void Float()
        {
            dockPanel1.ActiveContent.DockHandler.DockState = DockState.Float;
        }

        private void createLayout()
        {
            dockPanel1.Theme = new WeifenLuo.WinFormsUI.Docking.VS2012LightTheme(); ;

            _ModelExplorer.Show(dockPanel1, DockState.DockLeft);
            //_ModelExplorer.Show(firstEditor.Pane, DockAlignment.Left, 0.2);
            //_ModelExplorer.Show(dockPanel1, DockState.DockLeft);
            _ModelExplorer.DockHandler.CloseButtonVisible = false;
            _ModelExplorer.DockHandler.CloseButton = false;

            TableEditor firstEditor = _TableEditors[_SheetNames[0]];
            //firstEditor.Show(_ModelExplorer.Pane, DockAlignment.Right, 1);
            //firstEditor.Show(dockPanel1, DockState.DockTop);
            firstEditor.Show(dockPanel1, DockState.Document);
            firstEditor.DockHandler.CloseButtonVisible = false;
            firstEditor.DockHandler.CloseButton = false;

            _ErrorList.Show(dockPanel1, DockState.DockBottom);
            //_ErrorList.Show(firstEditor.Pane, DockAlignment.Bottom, 0.2);
            _ErrorList.DockHandler.CloseButtonVisible = false;
            _ErrorList.DockHandler.CloseButton = false;

            _Output.Show(dockPanel1, DockState.DockBottom);
            _Output.DockHandler.CloseButtonVisible = false;
            _Output.DockHandler.CloseButton = false;

            for (int i = 1; i < _SheetNames.Length; i++)
            {
                string sheetName = _SheetNames[i];
                if (!_TableEditors.ContainsKey(sheetName))
                    continue;

                TableEditor editor = _TableEditors[sheetName];
                editor.Show(dockPanel1, DockState.Document);
                //editor.Show(dockPanel1, DockState.DockTop);
                //editor.Show(firstEditor.Pane, DockAlignment.Right, 0.5);
                //editor.Show(firstEditor.Pane, DockAlignment.Right, 0.5);
                editor.DockHandler.CloseButtonVisible = false;
                editor.DockHandler.CloseButton = false;

            }
        }
        #endregion

        #region Methods
        public void DisconnectLogHandlers()
        {
            _Output.DisconnectLogHandlers();
        }

        public void ConnectLogHandlers()
        {
            _Output.ConnectLogHandlers();
        }

        public List<string> MakeLoadableSetVersionList()
        {
            List<string> lstLoadableSet = new List<string>();

            foreach (DataRow dr in _InputData.LoadableSetDataTable.Rows)
            {
                if (!lstLoadableSet.Contains(dr["VERSION_NO"].ToString()))
                {
                    lstLoadableSet.Add(dr["VERSION_NO"].ToString());
                }
            }

            return lstLoadableSet;
        }

        public void GoTo(string sheetName, int row, string columnName)
        {
            if (_TableEditors.ContainsKey(sheetName))
            {
                TableEditor editor = _TableEditors[sheetName];
                editor.Show();
                editor.GoTo(row, columnName);
            }
        }

        public DateTime GetFirstFabOutDate()
        {
            string year = _InputData.FabOutPlanDataTable.Rows[0][0].ToString().Substring(0, 4);
            string month = _InputData.FabOutPlanDataTable.Rows[0][0].ToString().Substring(4, 2);
            string day = _InputData.FabOutPlanDataTable.Rows[0][0].ToString().Substring(6, 2);

            DateTime rslt = new DateTime(int.Parse(year), int.Parse(month), int.Parse(day));

            foreach (DataRow dr in _InputData.FabOutPlanDataTable.Rows)
            {
                string year2 = dr[0].ToString().Substring(0, 4);
                string month2 = dr[0].ToString().Substring(4, 2);
                string day2 = dr[0].ToString().Substring(6, 2);

                DateTime temp = new DateTime(int.Parse(year2), int.Parse(month2), int.Parse(day2));

                if (temp < rslt)
                {
                    rslt = new DateTime(temp.Year, temp.Month, temp.Day);
                }
            }

            return rslt;
        }
        #endregion

        public class InputEditorValueChangedEvent : SourceGrid.Cells.Controllers.ControllerBase
        {
            private NewInputEditor form;

            public InputEditorValueChangedEvent(NewInputEditor form)
            {
                this.form = form;
            }

            public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
            {
                base.OnValueChanging(sender, e);

                /*SourceGrid.Cells.Cell nameCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 1);
                SourceGrid.Cells.Cell typeCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 2);
                SourceGrid.Cells.Cell valueCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 3);*/
            }            
        }
    }
}
