﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace VMS.IFS.UI
{
    public delegate void InputDataTableSelectedEventHandler (string name);
    public partial class ModelExplorer : DockContent
    {
        private NewInputEditor _Parent;
        private TreeNode _InputDataNode;

        public event InputDataTableSelectedEventHandler TableSelected;

        public ModelExplorer(NewInputEditor parent)
        {
            _Parent = parent;
            InitializeComponent();

            initialize();
        }

        private void initialize()
        {
            _InputDataNode = new TreeNode("Input Data");
            _InputDataNode.ImageIndex = 0;
            _InputDataNode.ExpandAll();

            tvModel.Nodes.Clear();
            tvModel.Nodes.Add(_InputDataNode);
        }

        public void Add(string category, string item)
        {
            if (category.Equals("InputData"))
            {
                TreeNode itemNode = new TreeNode(item);
                itemNode.ImageIndex = 1;
                _InputDataNode.Nodes.Add(itemNode);
                
            }                
        }

        private void tvModel_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.Level == 1 && e.Node.Parent.Text.Equals("Input Data"))
            {
                if (TableSelected != null && TableSelected.GetInvocationList().Length > 0)
                    TableSelected(e.Node.Text);
            }
        }
    }
}
