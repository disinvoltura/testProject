﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VMS.IFS.DataModel.DispatchingRuleData;
using ICSharpCode.TextEditor;
using ICSharpCode.TextEditor.Document;
using VMS.IFS.Models;

namespace VMS.IFS.UI
{
    public partial class CodeViewer : Form
    {
        private DispatchingRuleDefinition _DRDef;

        public CodeViewer(DispatchingRuleDefinition drdef)
        {
            _DRDef = drdef;

            InitializeComponent();
        }

        private void CodeViewer_Load(object sender, EventArgs e)
        {
            string code = string.Empty;
            if (_DRDef.Type == DispatchingRuleType.JobSelectionRule)
            {
                JobSelectionRuleGenerator generator = new JobSelectionRuleGenerator(null);
                if (generator.generateCode(_DRDef))
                    code = generator.Code;
            }
            else if (_DRDef.Type == DispatchingRuleType.MachineSelectionRule)
            {
                MachineSelectionRuleGenerator generator = new MachineSelectionRuleGenerator(null);
                if (generator.generateCode(_DRDef))
                    code = generator.Code;
            }
                
            string tefsmName = _DRDef.Name;
            ICSharpCode.TextEditor.TextEditorControl tecMainCode = new ICSharpCode.TextEditor.TextEditorControl();
            tecMainCode.Document.HighlightingStrategy = HighlightingStrategyFactory.CreateHighlightingStrategy("C#");
            tecMainCode.Dock = DockStyle.Fill;
            tecMainCode.IsReadOnly = false;
            tecMainCode.Name = _DRDef.Name + ".cs";
            tecMainCode.Text = code;
            TabPage tpMainCode = new TabPage(_DRDef.Name + ".cs");
            tpMainCode.Controls.Add(tecMainCode);
            tcCodes.TabPages.Add(tpMainCode);

        }
    }
}
