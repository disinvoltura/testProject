﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using OfficeOpenXml;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.UI
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        #region File Menu
        
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            doNew();       
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            doOpen();             
        }               

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            doSave();
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            doSaveAs();
        }

        private void doSaveAs()
        {
            if (ActiveMdiChild is NewInputEditor)
            {
                NewInputEditor ieForm = (NewInputEditor)this.ActiveMdiChild;
                ieForm.Save("SaveAs");
            }
            else if (ActiveMdiChild is SingleOutputViewer)
            {
                SingleOutputViewer ovForm = (SingleOutputViewer)this.ActiveMdiChild;
                ovForm.Save("SaveAs");
            }         

        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ActiveMdiChild.Close();            
        }

        private void errorCheckToolStripMenuItem_Click(object sender, EventArgs e)
        {
            doCheckErrors();
        }

        private void doCheckErrors()
        {
            if (this.ActiveMdiChild is NewInputEditor)
            {
                NewInputEditor ieForm = (NewInputEditor)this.ActiveMdiChild;
                ieForm.CheckErrors();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
            this.Dispose();
        }

        #endregion                                                        

        #region Simulation Menu
        private void singleRunOptionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showRunOptions();
        }

        private void showRunOptions()
        {
            NewInputEditor ieForm = getCurrentNewInputEditor(); //changed by D. Kang

            if (ieForm == null) //added by D. Kang
                return;

            ieForm.CheckErrors();
            ieForm.CheckErrors();

            if (ieForm.HasErrors)
            {
                MessageBox.Show(this, "Please check errors in the input file.", "Error", MessageBoxButtons.OK);
                return;
            }
            else
            {
                List<string> lstLoadableSet = ieForm.MakeLoadableSetVersionList();
                SingleRunOption roForm = new SingleRunOption(ieForm.InputData, lstLoadableSet, ieForm.RunOptions, ieForm.GetFirstFabOutDate());
                DialogResult rslt = roForm.ShowDialog();

                if (rslt == System.Windows.Forms.DialogResult.OK)
                {
                    Dictionary<string, object> runOptions = roForm.RunOptions;
                    ieForm.RunOptions = runOptions;

                    tsBtn_Run.Enabled = true;
                    tsBtn_Stop.Enabled = true;
                    runToolStripMenuItem.Visible = true;
                }
                else if (rslt == System.Windows.Forms.DialogResult.Abort)
                {
                    Dictionary<string, object> runOptions = roForm.RunOptions;
                    ieForm.RunOptions = runOptions;

                    tsBtn_Run.Enabled = true;
                    tsBtn_Stop.Enabled = true;
                    runToolStripMenuItem.Visible = true;

                    doRun();
                }
            }
        }

        private NewInputEditor getCurrentNewInputEditor()
        {
            NewInputEditor rslt = null;
            if (this.ActiveMdiChild != null && this.ActiveMdiChild is NewInputEditor)
                rslt = (NewInputEditor)this.ActiveMdiChild;

            return rslt;
        }

        #endregion       

        #region Event Handling

        private void Main_MdiChildActivate(object sender, EventArgs e)
        {
            if (ActiveMdiChild == null)
            {
                saveToolStripMenuItem.Visible = false;
                saveAsToolStripMenuItem.Visible = false;
                closeToolStripMenuItem.Visible = false;
                toolStripSeparator1.Visible = false;
               // errorCheckToolStripMenuItem.Visible = false;
                simulationToolStripMenuItem.Visible = false;
                windowToolStripMenuItem.Visible = false;

                toolStripSeparator.Visible = false;
                tsBtn_SingleRunOption.Visible = false;
                tsBtn_Run.Visible = false;
                tsBtn_Stop.Visible = false;
                
                saveToolStripButton.Visible = false;

            }
            else if (ActiveMdiChild is NewInputEditor)
            {
                saveToolStripMenuItem.Visible = true;
                saveAsToolStripMenuItem.Visible = true;
                closeToolStripMenuItem.Visible = true;
                toolStripSeparator1.Visible = true;
                //errorCheckToolStripMenuItem.Visible = true;
                simulationToolStripMenuItem.Visible = true;
                if (getCurrentNewInputEditor().RunOptions == null)
                {
                    runToolStripMenuItem.Visible = false;
                    tsBtn_Run.Enabled = false;
                    tsBtn_Stop.Enabled = false;
                }
                else
                {
                    runToolStripMenuItem.Visible = true;
                    tsBtn_Run.Enabled = true;
                    tsBtn_Stop.Enabled = true;
                }
                windowToolStripMenuItem.Visible = true;

                saveToolStripButton.Visible = true;
                tsBtn_SingleRunOption.Visible = true;
                tsBtn_Run.Visible = true;
                tsBtn_Stop.Visible = true;
            }
            else if (ActiveMdiChild is SingleOutputViewer)
            {
                saveToolStripMenuItem.Visible = true;
                saveAsToolStripMenuItem.Visible = true;
                closeToolStripMenuItem.Visible = true;
                toolStripSeparator1.Visible = false;
                errorCheckToolStripMenuItem.Visible = false;
                simulationToolStripMenuItem.Visible = false;
                windowToolStripMenuItem.Visible = false;

                saveToolStripButton.Visible = true;
                tsBtn_SingleRunOption.Visible = false;
                tsBtn_Run.Visible = false;
                tsBtn_Stop.Visible = false;
            }
        }          

        #endregion

        private void tsBtn_Run_Click(object sender, EventArgs e)
        {
            doRun();
        }

        private void runToolStripMenuItem_Click(object sender, EventArgs e)
        {
            doRun();
        }

        private void doRun()
        {
            NewInputEditor ieForm = getCurrentNewInputEditor(); //changed by D. Kang
            if (ieForm == null) //added by D. Kang
                return;

            if (ieForm.RunOptions == null)                            
                return;            

            Dictionary<string, object> runOptions = ieForm.RunOptions;

            if ((bool)runOptions[SimulationArguments.Logging])
            {
                ieForm.ConnectLogHandlers();            
            }

            SimulationRunner runner = new SimulationRunner(ieForm.InputData, ieForm.RunOptions);
            runner.Run();

            if (runner._Factory.FabOut.saveWIPTime >= 0)
            {
                SaveInputWithWIP(ieForm, runner);
            }
            //SimulationRunnerWithUI runner = new SimulationRunnerWithUI(ieForm.ids, ieForm.RunOptions);
            //runner.ShowDialog();
            
            SingleOutputViewer sov = new SingleOutputViewer(runner.OutputData, runner.RunOptions);
            sov.MdiParent = this;
            sov.Show();            
        }

        private void SaveInputWithWIP(NewInputEditor ie, SimulationRunner sr)
        {
            string filename = ie._FileName;
            string filename2 = filename.Replace(".xls", "_WIP_" + sr._Factory.FabOut.saveWIPTime + ".xls");

            FileInfo file = new FileInfo(filename2);
            if (file.Exists)
            {
                try
                {
                    file.Delete();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("The specified file is used by other process. Check the file is closed.");
                    return;
                }

                file = new FileInfo(filename2);
            }
            ExcelPackage package = new ExcelPackage(file);

            foreach (DataTable dt in sr._InputData.Tables)
            {
                if (dt.TableName.Contains("WIP"))
                    continue;

                ExcelWorksheet worksheet =
                    package.Workbook.Worksheets.Add(ie._TableToSheetMapping[dt.TableName]);
                worksheet.Cells.LoadFromDataTable(dt, true);
            }

            DataTable dtWIP = new DataTable();
            dtWIP = sr._InputData.WIPDataTable;
            foreach (DataRow dr in dtWIP.Rows)
            {
                dr["Q"] = "";
                dr["B"] = "";
            }

            Dictionary<string, int> dic_pID_num = new Dictionary<string, int>();
            foreach (Foup cst in sr._Factory.MasterData.WIP.FabOutWIP)
            {
                if (dic_pID_num.ContainsKey(cst.J))
                {
                    dic_pID_num[cst.J] += cst.N;
                }
                else
                {
                    dic_pID_num.Add(cst.J, cst.N);
                }
            }
            string FOcell = "";
            foreach (string pID in dic_pID_num.Keys)
            {
                if (FOcell == "")
                {
                    FOcell += "(" + pID + "," + dic_pID_num[pID] + ")";
                }
                else
                {
                    FOcell += ",(" + pID + "," + dic_pID_num[pID] + ")";
                }
            }
            foreach (DataRow dr in dtWIP.Rows)
            {
                if (dr["EQP_ID"].ToString() == "FabOut")
                {
                    dr["Q"] = FOcell;
                }
            }

            foreach (string eqp in sr._Factory.MasterData.EQP.Equipments)
            {
                string Qcell = "";
                foreach (Foup cstQ in sr._Factory.MasterData.WIP.QueueWIP[eqp])
                {
                    if (Qcell == "")
                    {
                        Qcell += "(" + cstQ.J + "," + cstQ.P + "," + cstQ.N + ")";
                    }
                    else
                    {
                        Qcell += ",(" + cstQ.J + "," + cstQ.P + "," + cstQ.N + ")";
                    }
                }

                string Bcell = "";
                foreach (Foup cstB in sr._Factory.MasterData.WIP.BufferWIP[eqp])
                {
                    if (Bcell == "")
                    {
                        Bcell += "(" + cstB.J + "," + cstB.P + "," + cstB.N + ")";
                    }
                    else
                    {
                        Bcell += ",(" + cstB.J + "," + cstB.P + "," + cstB.N + ")";
                    }
                }

                foreach (DataRow dr in dtWIP.Rows)
                {
                    if (dr["EQP_ID"].ToString() == eqp)
                    {
                        dr["Q"] = Qcell;
                        dr["B"] = Bcell;
                    }
                }
            }

            ExcelWorksheet worksheetWIP = package.Workbook.Worksheets.Add("WIP");
            worksheetWIP.Cells.LoadFromDataTable(dtWIP, true);

            package.Save();
        }

        private void manageDispatchingRulesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DispatchingRuleManager dialog = new DispatchingRuleManager();

            DialogResult rslt = dialog.ShowDialog();
            if (rslt == System.Windows.Forms.DialogResult.OK)
            {

            }
        }
       
        private void floatToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            NewInputEditor curInputEditor = getCurrentNewInputEditor();
            if (curInputEditor != null)
            {
                curInputEditor.Float();
            }

        }

        private void resetLayoutToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            NewInputEditor curInputEditor = getCurrentNewInputEditor();
            if (curInputEditor != null)
            {
                curInputEditor.ResetLayout();
            }
        }

        #region Toolbar Event Handling Methods
        private void activeFileMenu()
        {
            saveAsToolStripMenuItem.Enabled = true;
        }
        
        private void deActiveFileMenu()
        {
            saveAsToolStripMenuItem.Enabled = false;
        }
        private void newToolStripButton_Click(object sender, EventArgs e)
        {
            doNew();
        }

        private void doNew()
        {
            activeFileMenu();

            NewInputEditor ieForm = new NewInputEditor("");
            ieForm.MdiParent = this;
            ieForm.Text += " - New Input File";
            ieForm.Show();
        }

        private void openToolStripButton_Click(object sender, EventArgs e)
        {
            activeFileMenu();

            doOpen();
        }

        private void doOpen()
        {
            string fileName = "";

            this.openFileDialog1.Filter = "Excel Files|*.xlsx;*.xls|All files|*.*";
            if (this.openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                fileName = openFileDialog1.FileName;

                NewInputEditor ieForm = new NewInputEditor(fileName);
                ieForm.MdiParent = this;
                ieForm.Text += " - " + fileName;
                ieForm.WindowState = FormWindowState.Maximized;
                ieForm.Show();

                //InputEditor ieForm = new InputEditor(fileName);
                //ieForm.MdiParent = this;
                //ieForm.Text += " - " + fileName;
                //ieForm.Show();
            }  
        }

        private void saveToolStripButton_Click(object sender, EventArgs e)
        {
            doSave();
        }

        private void doSave()
        {
            if (ActiveMdiChild is NewInputEditor)
            {
                NewInputEditor ieForm = (NewInputEditor)this.ActiveMdiChild;
                ieForm.Save("Save");
            }
            else if (ActiveMdiChild is SingleOutputViewer)
            {
                SingleOutputViewer ovForm = (SingleOutputViewer)this.ActiveMdiChild;
                ovForm.Save("Save");
            }
        }
        #endregion
    }
}
