﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.UI
{
    public class FactorExpressionTypeMap
    {
        #region Member Variables
        private Dictionary<string, List<FactorExpressionTypeData>> _Data;
        #endregion

        #region Properties
        public IEnumerable<string> Categories
        {
            get { return _Data.Keys; }
        }

        public IEnumerable<FactorExpressionTypeData> this[string category]
        {
            get { return _Data[category]; }
        }
        #endregion

        #region Constructors
        public FactorExpressionTypeMap()
        {
            _Data = new Dictionary<string, List<FactorExpressionTypeData>>();
        }
        #endregion

        #region Methods
        public void Add(string category, FactorExpressionTypeData factorExprType)
        {
            if (!_Data.ContainsKey(category))
            {
                List<FactorExpressionTypeData> list = new List<FactorExpressionTypeData>();

                bool isInserted = false;
                for (int i = 0; i < list.Count; i++)
                {
                    FactorExpressionTypeData exprType = list[i];
                    if (factorExprType.Name.CompareTo(exprType.Name) < 0)
                    {
                        list.Insert(i, factorExprType);
                        isInserted = true;
                        break;
                    }
                }
                if (!isInserted)
                    list.Add(factorExprType);

                _Data.Add(category, list);
            }
            else
            {
                List<FactorExpressionTypeData> list = _Data[category];
                list.Add(factorExprType);
                _Data[category] = list;
            }
        }

        /// <summary>
        /// Add a factor expression type whose type is a property
        /// </summary>
        /// <param name="category"></param>
        /// <param name="name"></param>
        /// <param name="desc"></param>
        public void Add(string category, string name, string desc)
        {
            FactorExpressionTypeData factorExprType = new FactorExpressionTypeData(name, desc);
            this.Add(category, factorExprType);
        }

        /// <summary>
        /// Add a factor expression type whose type is a method
        /// </summary>
        /// <param name="category"></param>
        /// <param name="name"></param>
        /// <param name="parameter"></param>
        /// <param name="desc"></param>
        public void Add(string category, string name, string parameter, string desc)
        {
            FactorExpressionTypeData factorExprType = new FactorExpressionTypeData(name, parameter, desc);
            this.Add(category, factorExprType);
        }
        #endregion
    }

}
