﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.UI
{
    public enum FactorExpressionTypeKind { Property, Method };
    public class FactorExpressionTypeData
    {
        //Name, Type (Property, Function), Parameter (applicable if type is function), Description
        public string Name;
        public FactorExpressionTypeKind Type;
        public string Parameter;
        public string Description;

        public FactorExpressionTypeData(string name, string desc)
        {
            this.Name = name;
            this.Type = FactorExpressionTypeKind.Property;
            this.Parameter = string.Empty;
            this.Description = desc;
        }

        public FactorExpressionTypeData(string name, string parameter, string desc)
        {
            this.Name = name;
            this.Type = FactorExpressionTypeKind.Method;
            this.Parameter = parameter;
            this.Description = desc;
        }

    }
}
