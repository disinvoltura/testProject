﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VMS.IFS.DataModel.DispatchingRuleData;

namespace VMS.IFS.UI
{
    public partial class DispatchingRuleEditor : Form
    {
        #region Member Variables
        private DispatchingRuleDefinition _DR;

        private CellDoubleClikedEvent _FactorCellEvent;
        private CellDoubleClikedEvent _ParameterCellEvent;
        #endregion

        #region Properties
        public DispatchingRuleDefinition DispatchingRule
        {
            get { return _DR; }
        }
        #endregion

        #region Constructors
        public DispatchingRuleEditor()
        {
            InitializeComponent();

            drawParameterHeader();
            drawFactorHeader();

            _FactorCellEvent = new CellDoubleClikedEvent();
            _FactorCellEvent.FactorSelected += new FactorSelectedEventHandler(cdEvent_FactorSelected);
            _ParameterCellEvent = new CellDoubleClikedEvent();
            _ParameterCellEvent.ParameterSelected += new ParameterSelectedEventHandler(_ParameterCellEvent_ParameterSelected);
        }

        

        public DispatchingRuleEditor(DispatchingRuleDefinition dr)
            : this()
        {
            loadDispatchingRule(dr);
        }

        #endregion

        #region Draw Table Headers
        private void drawParameterHeader()
        {
            gParameters.Rows.Clear();

            gParameters.BorderStyle = BorderStyle.None;
            gParameters.Redim(1, 3);
            gParameters.FixedRows = 1;
            gParameters.Font = new Font("Calibe", 9);
            
            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            string[] columns = { "Name", "Type", "Description" };
            for (int i = 0; i < columns.Length; i++)
            {
                SourceGrid.Cells.ColumnHeader header =
                    new SourceGrid.Cells.ColumnHeader(columns[i]);

                header.View = titleModel;
                gParameters[0, i] = header;
            }
        }

        private void drawFactorHeader()
        {
            gFactors.Rows.Clear();

            gFactors.BorderStyle = BorderStyle.None;
            gFactors.Redim(1, 2);
            gFactors.FixedRows = 1;
            gFactors.Font = new Font("Calibe", 9);

            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            string[] columns = { "Name", "Description" };
            for (int i = 0; i < columns.Length; i++)
            {
                SourceGrid.Cells.ColumnHeader header =
                    new SourceGrid.Cells.ColumnHeader(columns[i]);

                header.View = titleModel;
                gFactors[0, i] = header;
            }
        }
        #endregion

        #region Button Event Handlers
        private void btnParamAdd_Click(object sender, EventArgs e)
        {
            insertEmptyParameter();
        }
        
        private void btnParamDelete_Click(object sender, EventArgs e)
        {
            removeParameter();
        }

        private void btnFactorAdd_Click(object sender, EventArgs e)
        {
            insertNewFactor();
        }

        private void btnFactorEdit_Click(object sender, EventArgs e)
        {
            editFactor();
        }

        private void btnFactorDelete_Click(object sender, EventArgs e)
        {
            removeFactor();
        }
        #endregion

        #region Parameter-related Methods
        private void insertEmptyParameter()
        {
            int rowIndex = gParameters.RowsCount;
            gParameters.Rows.Insert(rowIndex);

            //Name
            string pName = "Parameter " + rowIndex;
            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(pName, typeof(string));
            nameCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            gParameters[rowIndex, 0] = nameCell;
            gParameters[rowIndex, 0].AddController(_ParameterCellEvent);

            //Type
            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            string[] types = new string[] { "string", "int", "float", "double" };
            cbEditor.StandardValues = types;
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;
            cbEditor.Control.DropDownStyle = ComboBoxStyle.DropDownList;

            SourceGrid.Cells.Cell typeCell = new SourceGrid.Cells.Cell("int", cbEditor);
            typeCell.View = SourceGrid.Cells.Views.ComboBox.Default;
            typeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            gParameters[rowIndex, 1] = typeCell;
            gParameters[rowIndex, 1].AddController(_ParameterCellEvent);

            //Description
            SourceGrid.Cells.Cell descCell = new SourceGrid.Cells.Cell("", typeof(string));
            descCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            gParameters[rowIndex, 2] = descCell;
            gParameters[rowIndex, 2].AddController(_ParameterCellEvent);

            if (gParameters.Rows.Count == 2)
                gParameters.AutoSizeCells();
        }

        private void insertParameter(DRParameter p)
        {
            int rowIndex = gParameters.RowsCount;
            gParameters.Rows.Insert(rowIndex);

            //Name
            string pName = p.Name;
            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(pName, typeof(string));
            nameCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            gParameters[rowIndex, 0] = nameCell;
            gParameters[rowIndex, 0].AddController(_ParameterCellEvent);
            
            //Type
            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            string[] types = new string[] { "string", "int", "float", "double" };
            cbEditor.StandardValues = types;
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;
            cbEditor.Control.DropDownStyle = ComboBoxStyle.DropDownList;

            string pType = "int";
            if (p.Type == DRParameterType.Double)
                pType = "double";
            else if (p.Type == DRParameterType.Float)
                pType = "float";
            else if (p.Type == DRParameterType.String)
                pType = "string";

            SourceGrid.Cells.Cell typeCell = new SourceGrid.Cells.Cell(pType, cbEditor);
            typeCell.View = SourceGrid.Cells.Views.ComboBox.Default;
            typeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            gParameters[rowIndex, 1] = typeCell;
            gParameters[rowIndex, 1].AddController(_ParameterCellEvent);

            //Description
            SourceGrid.Cells.Cell descCell = new SourceGrid.Cells.Cell(p.Description, typeof(string));
            descCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            gParameters[rowIndex, 2] = descCell;
            gParameters[rowIndex, 2].AddController(_ParameterCellEvent);

            if (gParameters.Rows.Count == 2)
                gParameters.AutoSizeCells();
        }

        private void _ParameterCellEvent_ParameterSelected(DRParameter p)
        {
            insertStringIntoExpr(p.Name);
        }

        private void removeParameter()
        {
            //int sRow = gParameters.Selection.ActivePosition.Row;
            int sRow = _ParameterCellEvent.SelectedRow;
            if (sRow < 0 || gParameters[sRow, 0] == null)
                return;

            gParameters.Rows.Remove(sRow);
        }
        #endregion

        #region Factor-related Methods

        private void insertNewFactor()
        {
            //dialog
            DispatchingRuleFactorEditor dialog = new DispatchingRuleFactorEditor();
            DialogResult rslt = dialog.ShowDialog();

            if (rslt == System.Windows.Forms.DialogResult.OK)
            {
                DRFactor f = dialog.Factor;

                insertFactor(f);
            }
        }

        private void insertFactor(DRFactor f)
        {
            string factorName = f.Name;
            string factorDesc = f.Description;

            int rowIndex = gFactors.RowsCount;
            gFactors.Rows.Insert(rowIndex);           

            //Name
            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(factorName, typeof(string));
            nameCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            gFactors[rowIndex, 0] = nameCell;
            gFactors[rowIndex, 0].Tag = f;
            gFactors[rowIndex, 0].AddController(_FactorCellEvent);

            //Description
            SourceGrid.Cells.Cell descCell = new SourceGrid.Cells.Cell(factorDesc, typeof(string));
            descCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            gFactors[rowIndex, 1] = descCell;
            gFactors[rowIndex, 1].AddController(_FactorCellEvent);

            if (gFactors.Rows.Count == 2)
                gFactors.AutoSizeCells();
        }

        private void cdEvent_FactorSelected(DRFactor f)
        {
            string sFactor = string.Format("{0}(Cassette, Machine)", f.Name);

            insertStringIntoExpr(sFactor);
        }

        private void editFactor()
        {
            //int sRow = gFactors.Selection.ActivePosition.Row;
            int sRow = _FactorCellEvent.SelectedRow;
            if (sRow < 0 || gFactors[sRow, 0] == null)
                return;

            SourceGrid.Cells.Cell nameCell = (SourceGrid.Cells.Cell)gFactors[sRow, 0];
            SourceGrid.Cells.Cell descCell = (SourceGrid.Cells.Cell)gFactors[sRow, 1];

            DRFactor f = (DRFactor)nameCell.Tag;

            DispatchingRuleFactorEditor dialog = new DispatchingRuleFactorEditor(f);
            DialogResult rslt = dialog.ShowDialog();

            if (rslt == System.Windows.Forms.DialogResult.OK)
            {
                DRFactor newFactor = dialog.Factor;

                nameCell.Value = newFactor.Name;
                descCell.Value = newFactor.Description;
                nameCell.Tag = newFactor;
            }
        }

        private void removeFactor()
        {
            int sRow = gFactors.Selection.ActivePosition.Row;
            if (sRow < 0 || gFactors[sRow, 0] == null)
                return;

            gFactors.Rows.Remove(sRow);
        }
        #endregion

        #region Load/Save Dispatching Rule
        private void loadDispatchingRule(DispatchingRuleDefinition dr)
        {
            txtName.Text = dr.Name;
            txtDesc.Text = dr.Description;
            txtPriorityFunc.Text = dr.PriorityFunction;

            if (dr.Type == DispatchingRuleType.JobSelectionRule)
                cbType.Text = "Job Selection Rule";
            else
                cbType.Text = "Machine Selection Rule";

            if (dr.SelectionOrder == SelectionCriteriaType.Minimum)
            {
                rbMinPriority.Checked = true;
                rbMaxPriority.Checked = false;
            }
            else
            {
                rbMinPriority.Checked = false;
                rbMaxPriority.Checked = true;
            }

            //Parameters
            foreach (DRParameter p in dr.Parameters)
            {
                insertParameter(p);
            }
            
            //Factors
            foreach (DRFactor f in dr.Factors)
            {
                insertFactor(f);
            }
        }

        private DispatchingRuleDefinition buildDispatchingRule()
        {
            string name =txtName.Text;
            DispatchingRuleType type = DispatchingRuleType.JobSelectionRule;
            if (cbType.Text.Equals("Machine Selection Rule"))
                type = DispatchingRuleType.MachineSelectionRule;

            DispatchingRuleDefinition dr = new DispatchingRuleDefinition(name, type);

            dr.Description = txtDesc.Text;
            dr.PriorityFunction = txtPriorityFunc.Text;

            dr.SelectionOrder = SelectionCriteriaType.Minimum;
            if (rbMaxPriority.Checked)
                dr.SelectionOrder = SelectionCriteriaType.Maximum;

            //Parameter
            for (int i = 1; i < gParameters.RowsCount; i++)
            {
                string pName = gParameters[i, 0].DisplayText;
                string strType  = gParameters[i, 1].DisplayText;
                DRParameterType pType = DRParameterType.Integer;
                if (strType.Equals("double"))
                    pType = DRParameterType.Double;
                else if (strType.Equals("float"))
                    pType = DRParameterType.Float;
                else if (strType.Equals("string"))
                    pType = DRParameterType.String;
                string pDesc = gParameters[i, 2].DisplayText;

                dr.AddParameter(pName, pType, pDesc);
            }

            //Factors
            for (int i = 1; i < gFactors.RowsCount; i++)
            {
                if (gFactors[i, 0].Tag != null)
                {
                    DRFactor f = (DRFactor)gFactors[i, 0].Tag;
                    dr.AddFactor(f.Name, f.Description, f.Expression);
                }
            }

            return dr;
        }
        #endregion

        #region Button Event Handlers
        private void btnOK_Click(object sender, EventArgs e)
        {
            //Valid Check
            if (string.IsNullOrEmpty(txtName.Text) ||
                string.IsNullOrEmpty(cbType.Text) ||
                string.IsNullOrEmpty(txtPriorityFunc.Text))
                return;
            
            _DR = buildDispatchingRule();

            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }
        #endregion

        #region Operator Methods
        private void insertStringIntoExpr(string val)
        {
            int cursor = txtPriorityFunc.SelectionStart;
            txtPriorityFunc.Text = txtPriorityFunc.Text.Insert(cursor, val);
            txtPriorityFunc.Focus();
            txtPriorityFunc.SelectionStart = cursor + val.Length;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr("+");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr("-");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr("*");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr("/");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr("==");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr("<>");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr("<");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr(">");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr("<=");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr(">=");
        }
        #endregion        
    }

    public delegate void FactorSelectedEventHandler (DRFactor f);
    public delegate void ParameterSelectedEventHandler(DRParameter p);

    public class CellDoubleClikedEvent : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event FactorSelectedEventHandler FactorSelected;
        public event ParameterSelectedEventHandler ParameterSelected;

        public int SelectedRow;

        public CellDoubleClikedEvent()
        {

        }

        public override void OnFocusEntered(SourceGrid.CellContext sender, EventArgs e)
        {
            SelectedRow = sender.Position.Row;
        }

        public override void OnDoubleClick(SourceGrid.CellContext sender, EventArgs e)
        {
            base.OnDoubleClick(sender, e);

            SourceGrid.Cells.Cell nameCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 0);
            //SourceGrid.Cells.Cell descCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 1);

            if (nameCell.Tag != null)
            {
                if (nameCell.Tag is DRFactor)
                {
                    DRFactor f = (DRFactor)nameCell.Tag;

                    if (FactorSelected != null && FactorSelected.GetInvocationList().Length > 0)
                        FactorSelected(f);
                }
                else if (nameCell.Tag is DRParameter)
                {
                    DRParameter p = (DRParameter)nameCell.Tag;

                    if (ParameterSelected != null && ParameterSelected.GetInvocationList().Length > 0)
                        ParameterSelected(p);
                }
            }           


            //SourceGrid.Cells.Cell nameCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 0);
            //SourceGrid.Cells.Cell descCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 1);

            //if (nameCell.Tag != null)
            //{
            //    DRFactor f = (DRFactor)nameCell.Tag;

            //    DispatchingRuleFactorEditor dialog = new DispatchingRuleFactorEditor(f);
            //    DialogResult rslt = dialog.ShowDialog();

            //    if (rslt == System.Windows.Forms.DialogResult.OK)
            //    {
            //        DRFactor newFactor = dialog.Factor;

            //        nameCell.Value = newFactor.Name;
            //        descCell.Value = newFactor.Description;
            //        nameCell.Tag = newFactor;
            //    }
            //}
            
            
        }

    }
}
