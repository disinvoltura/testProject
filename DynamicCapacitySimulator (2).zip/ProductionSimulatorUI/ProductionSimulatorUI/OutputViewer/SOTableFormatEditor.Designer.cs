﻿namespace VMS.IFS.UI
{
    partial class SOTableFormatEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lv_Selected = new System.Windows.Forms.ListView();
            this.lv_Unselected = new System.Windows.Forms.ListView();
            this.btn_Select = new System.Windows.Forms.Button();
            this.btn_Unselect = new System.Windows.Forms.Button();
            this.btn_Up = new System.Windows.Forms.Button();
            this.btn_Down = new System.Windows.Forms.Button();
            this.btn_OK = new System.Windows.Forms.Button();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Selected Column";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(349, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Unselected Column";
            // 
            // lv_Selected
            // 
            this.lv_Selected.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lv_Selected.Location = new System.Drawing.Point(31, 35);
            this.lv_Selected.Name = "lv_Selected";
            this.lv_Selected.Size = new System.Drawing.Size(244, 339);
            this.lv_Selected.TabIndex = 2;
            this.lv_Selected.UseCompatibleStateImageBehavior = false;
            this.lv_Selected.View = System.Windows.Forms.View.List;
            // 
            // lv_Unselected
            // 
            this.lv_Unselected.Location = new System.Drawing.Point(371, 35);
            this.lv_Unselected.Name = "lv_Unselected";
            this.lv_Unselected.Size = new System.Drawing.Size(244, 339);
            this.lv_Unselected.TabIndex = 3;
            this.lv_Unselected.UseCompatibleStateImageBehavior = false;
            this.lv_Unselected.View = System.Windows.Forms.View.List;
            // 
            // btn_Select
            // 
            this.btn_Select.Location = new System.Drawing.Point(306, 114);
            this.btn_Select.Name = "btn_Select";
            this.btn_Select.Size = new System.Drawing.Size(30, 23);
            this.btn_Select.TabIndex = 4;
            this.btn_Select.Text = "◀";
            this.btn_Select.UseVisualStyleBackColor = true;
            this.btn_Select.Click += new System.EventHandler(this.btn_Select_Click);
            // 
            // btn_Unselect
            // 
            this.btn_Unselect.Location = new System.Drawing.Point(306, 210);
            this.btn_Unselect.Name = "btn_Unselect";
            this.btn_Unselect.Size = new System.Drawing.Size(30, 23);
            this.btn_Unselect.TabIndex = 5;
            this.btn_Unselect.Text = "▶";
            this.btn_Unselect.UseVisualStyleBackColor = true;
            this.btn_Unselect.Click += new System.EventHandler(this.btn_Unselect_Click);
            // 
            // btn_Up
            // 
            this.btn_Up.Location = new System.Drawing.Point(100, 393);
            this.btn_Up.Name = "btn_Up";
            this.btn_Up.Size = new System.Drawing.Size(30, 23);
            this.btn_Up.TabIndex = 6;
            this.btn_Up.Text = "▲";
            this.btn_Up.UseVisualStyleBackColor = true;
            this.btn_Up.Click += new System.EventHandler(this.btn_Up_Click);
            // 
            // btn_Down
            // 
            this.btn_Down.Location = new System.Drawing.Point(167, 393);
            this.btn_Down.Name = "btn_Down";
            this.btn_Down.Size = new System.Drawing.Size(30, 23);
            this.btn_Down.TabIndex = 7;
            this.btn_Down.Text = "▼";
            this.btn_Down.UseVisualStyleBackColor = true;
            this.btn_Down.Click += new System.EventHandler(this.btn_Down_Click);
            // 
            // btn_OK
            // 
            this.btn_OK.Location = new System.Drawing.Point(446, 408);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(75, 23);
            this.btn_OK.TabIndex = 8;
            this.btn_OK.Text = "OK";
            this.btn_OK.UseVisualStyleBackColor = true;
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.Location = new System.Drawing.Point(542, 408);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_Cancel.TabIndex = 9;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // SOTableFormatEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(649, 446);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.btn_Down);
            this.Controls.Add(this.btn_Up);
            this.Controls.Add(this.btn_Unselect);
            this.Controls.Add(this.btn_Select);
            this.Controls.Add(this.lv_Unselected);
            this.Controls.Add(this.lv_Selected);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "SOTableFormatEditor";
            this.Text = "Table Format Editor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListView lv_Selected;
        private System.Windows.Forms.ListView lv_Unselected;
        private System.Windows.Forms.Button btn_Select;
        private System.Windows.Forms.Button btn_Unselect;
        private System.Windows.Forms.Button btn_Up;
        private System.Windows.Forms.Button btn_Down;
        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.Button btn_Cancel;
    }
}