﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VMS.IFS.UI
{
    public partial class SORatioChartFormatEditor : Form
    {
        #region Member Variable
        private List<string> xValues;
        public List<string> selectedXValues;

        #endregion

        public SORatioChartFormatEditor(List<string> x, List<string> selectedX)
        {
            InitializeComponent();

            this.xValues = x;
            this.selectedXValues = selectedX;

            grid_X.ColumnsCount = 2;
            grid_X.FixedRows = 1;
            grid_X.Rows.Insert(0);

            grid_X[0, 0] = new SourceGrid.Cells.ColumnHeader("Select");
            grid_X[0, 1] = new SourceGrid.Cells.ColumnHeader("X Value Name");

            int i = 1;
            bool selectAll = true;
            foreach (string str in xValues)
            {
                grid_X.Rows.Insert(i);
                if (selectedXValues.Contains(str))
                {
                    grid_X[i, 0] = new SourceGrid.Cells.CheckBox(null, true);
                }
                else
                {                    
                    grid_X[i, 0] = new SourceGrid.Cells.CheckBox(null, false);
                    selectAll = false;
                }
                grid_X[i, 1] = new SourceGrid.Cells.Cell(str);
                i++;
            }
            if (selectAll)
                cb_All.Checked = true;

            grid_X.Columns.AutoSize(true);
        }        

        #region Button Handling

        private void btn_OK_Click(object sender, EventArgs e)
        {
            selectedXValues = new List<string>();
            for (int i = 1; i < grid_X.Rows.Count; i++)
            {
                if ((bool)grid_X[i, 0].Value)
                {
                    selectedXValues.Add(grid_X[i, 1].Value.ToString());
                }
            }

            this.DialogResult = System.Windows.Forms.DialogResult.OK;

            this.Close();
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion

        private void cb_All_CheckedChanged(object sender, EventArgs e)
        {
            if (cb_All.Checked == true)
            {
                for (int i = 1; i < grid_X.Rows.Count; i++)
                {
                    grid_X[i, 0].Value = true;
                }
            }
            else
            {
                for (int i = 1; i < grid_X.Rows.Count; i++)
                {
                    grid_X[i, 0].Value = false;
                }
            }
        }
    }
}
