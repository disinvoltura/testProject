﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace VMS.IFS.UI
{
    public partial class ChartTable : UserControl
    {
        #region Member Variable
        
        public DataTable dtShowTable;
        public DataTable dtShowChart;
        
        private string _ChartType;
        private List<string> _XList;
        private List<string> _YList;

        public Dictionary<string, object> RunOptions;

        #endregion

        #region Constructor

        public ChartTable(Dictionary<string, object> ro, DataTable dt, string chartType, List<string> xList, List<string> yList, bool makeChart)
        {
            InitializeComponent();

            RunOptions = ro;
            
            DataTable chart = dt.Copy();
            dtShowChart = chart;
            DataTable table = dt.Copy();
            dtShowTable = table;            
                        
            this._ChartType = chartType;
            this._XList = xList;
            this._YList = yList;

            if (makeChart)
            {
                OutputChartData chartData = new OutputChartData(this, dtShowChart, _ChartType, _XList, _YList);
                chartData.BuildChart();

                SOTable sot = new SOTable(dtShowTable);
                sot.Parent = splitContainer1.Panel2;
                sot.Dock = DockStyle.Fill;
                sot.Show();
            }
            else
            {
                Controls.Remove(splitContainer1);
                
                SOTable sot = new SOTable(dtShowTable);
                sot.Parent = this;
                sot.Dock = DockStyle.Fill;
                sot.Show();
            }
        }

        public ChartTable(DataTable dt, string chartType, List<string> xList, List<string> yList, bool makeChart)
        {
            InitializeComponent();

            DataTable chart = dt.Copy();
            dtShowChart = chart;
            DataTable table = dt.Copy();
            dtShowTable = table;

            this._ChartType = chartType;
            this._XList = xList;
            this._YList = yList;

            if (makeChart)
            {
                OutputChartData chartData = new OutputChartData(this, dtShowChart, _ChartType, _XList, _YList);
                chartData.BuildChart();

                SOTable sot = new SOTable(dtShowTable);
                sot.Parent = splitContainer1.Panel2;
                sot.Dock = DockStyle.Fill;
                sot.Show();
            }
            else
            {
                Controls.Remove(splitContainer1);

                SOTable sot = new SOTable(dtShowTable);
                sot.Parent = this;
                sot.Dock = DockStyle.Fill;
                sot.Show();
            }
        }

        public ChartTable(DataTable dtChart, DataTable dtTable, string chartType, List<string> xList, List<string> yList)
        {
            InitializeComponent();

            DataTable chart = dtChart.Copy();
            dtShowChart = chart;
            DataTable table = dtTable.Copy();
            dtShowTable = table; 

            this._ChartType = chartType;
            this._XList = xList;
            this._YList = yList;

            OutputChartData chartData = new OutputChartData(this, dtShowChart, _ChartType, _XList, _YList);
            chartData.BuildChart();

            SOTable sot = new SOTable(dtShowTable);
            sot.Parent = splitContainer1.Panel2;
            sot.Dock = DockStyle.Fill;
            sot.Show();
        }

        #endregion
              
    }
}
