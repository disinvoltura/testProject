﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace VMS.IFS.UI
{
    public partial class SOTATRatioChart : UserControl
    {
        #region Member Variable

        private DataTable dtMaster;
        private DataTable dtShow;

        private List<string> xValues;
        private List<string> selectedXValues;

        #endregion

        #region Constructor

        public SOTATRatioChart(DataTable dt)
        {
            InitializeComponent();

            this.dtMaster = dt;
            DataTable dtCopy = dtMaster.Copy();
            this.dtShow = dtCopy;

            xValues = new List<string>();
            selectedXValues = new List<string>();

            foreach (DataRow dr in dtMaster.Rows)
            {
                if (!xValues.Contains(dr[0].ToString()))
                {
                    xValues.Add(dr[0].ToString());
                    selectedXValues.Add(dr[0].ToString());
                }
            }

            Print();
        }

        #endregion

        #region Print Method

        private void Print()
        {
            chart.Series.Clear();
            chart.ChartAreas[0].AxisX.CustomLabels.Clear();

            Dictionary<string, double> dicID_Value = new Dictionary<string, double>();
            Dictionary<double, string> dicValue_ID = new Dictionary<double, string>();
            Dictionary<string, int> dicSeriesName = new Dictionary<string, int>();

            double value = 1;
            int value2 = 1;        
            foreach (DataRow dr in dtShow.Rows)
            {
                if (!dicID_Value.ContainsKey(dr[0].ToString()))
                {
                    dicID_Value.Add(dr[0].ToString(), value);
                    dicValue_ID.Add(value, dr[0].ToString());
                    value++;
                }

                if (!dicSeriesName.ContainsKey(dr[1].ToString()))
                {
                    dicSeriesName.Add(dr[1].ToString(), value2);
                    value2++;
                }
            }

            foreach (string series in dicSeriesName.Keys)
            {
                Series s = new Series();
                s.Name = series;
                s.ChartType = SeriesChartType.StackedColumn;                
                s.BorderWidth = 5;

                chart.Series.Add(s);                
            }

            foreach (string pID in selectedXValues)
            {
                foreach (string sID in dicSeriesName.Keys)
                {
                    DataPoint dp = new DataPoint(dicID_Value[pID], getValue(pID, sID));
                    chart.Series[sID].Points.Add(dp);
                }
            }
            
            
            
            //double sumTAT = 0;
            
            //foreach (DataRow dr in dtShow.Rows)
            //{
            //    if (dr["Product ID"].ToString() == "PRODUCT2" && dr["Step ID"].ToString() == "STEP3")
            //    {
            //        DataPoint dp2 = new DataPoint(dicID_Value["PRODUCT1"], 0);
            //        chart.Series[dr[1].ToString()].Points.Add(dp2);
            //        //sumTAT += double.Parse(dr[2].ToString());
            //    }

            //    DataPoint dp = new DataPoint(dicID_Value[dr[0].ToString()], double.Parse(dr[2].ToString()));
            //    chart.Series[dr[1].ToString()].Points.Add(dp);
            //    sumTAT += double.Parse(dr[2].ToString());                
            //}

            foreach (double key in dicValue_ID.Keys)
            {
                chart.ChartAreas[0].AxisX.CustomLabels.Add(key - 0.1, key + 0.1, dicValue_ID[key]);
            }
        }

        #endregion

        #region Chart Edit Method

        private DataTable EditChart()
        {
            DataTable dt = new DataTable();

            foreach (DataColumn dc in dtMaster.Columns)
            {
                dt.Columns.Add(dc.ColumnName);
            }
            foreach (DataRow dr in dtMaster.Rows)
            {
                if (selectedXValues.Contains(dr[0].ToString()))
                {
                    DataRow row = dt.NewRow();
                    foreach (DataColumn dc in dt.Columns)
                    {
                        row[dc.ColumnName] = dr[dc.ColumnName].ToString();
                    }
                    dt.Rows.Add(row);
                }
            }

            return dt;
        }

        #endregion 

        #region Tool Strip Buntton Handling

        private void tsBtn_ChartEdit_Click(object sender, EventArgs e)
        {
            SORatioChartFormatEditor cfe = new SORatioChartFormatEditor(xValues, selectedXValues);

            switch (cfe.ShowDialog())
            {
                case DialogResult.OK:
                    {
                        selectedXValues = cfe.selectedXValues;

                        dtShow = EditChart();
                        Print();

                        break;
                    }
            }
        }

        private void tsBtn_ChartReset_Click(object sender, EventArgs e)
        {
            DataTable dtCopy = dtMaster.Copy();
            dtShow = dtCopy;

            xValues = new List<string>();
            selectedXValues = new List<string>();

            foreach (DataRow dr in dtMaster.Rows)
            {
                xValues.Add(dr[0].ToString());
                selectedXValues.Add(dr[0].ToString());
            }

            Print();
        }

        #endregion

        #region Method

        private double getValue(string pID, string sID)
        {
            double rslt = 0;

            foreach (DataRow dr in dtShow.Rows)
            {
                if (dr[0].ToString() == pID && dr[1].ToString() == sID)
                {
                    rslt = double.Parse(dr[2].ToString());
                }
            }
            
            return rslt;
        }

        #endregion
    }
}
