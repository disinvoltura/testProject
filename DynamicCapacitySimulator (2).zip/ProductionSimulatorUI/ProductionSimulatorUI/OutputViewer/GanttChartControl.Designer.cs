﻿namespace VMS.IFS.UI
{
    partial class GanttChartControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GanttChartControl));
            this.grid = new SourceGrid.Grid();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label_Time = new System.Windows.Forms.Label();
            this.label_idle = new System.Windows.Forms.Label();
            this.label_setup = new System.Windows.Forms.Label();
            this.label_run = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsBtn_ChartEdit = new System.Windows.Forms.ToolStripButton();
            this.tsBtn_ChartReset = new System.Windows.Forms.ToolStripButton();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // grid
            // 
            this.grid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid.EnableSort = true;
            this.grid.FixedColumns = 3;
            this.grid.FixedRows = 1;
            this.grid.Location = new System.Drawing.Point(0, 25);
            this.grid.Name = "grid";
            this.grid.OptimizeMode = SourceGrid.CellOptimizeMode.ForColumns;
            this.grid.SelectionMode = SourceGrid.GridSelectionMode.Cell;
            this.grid.Size = new System.Drawing.Size(702, 258);
            this.grid.TabIndex = 1;
            this.grid.TabStop = true;
            this.grid.ToolTipText = "";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.label_Time);
            this.panel1.Controls.Add(this.label_idle);
            this.panel1.Controls.Add(this.label_setup);
            this.panel1.Controls.Add(this.label_run);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.toolStrip1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(702, 25);
            this.panel1.TabIndex = 4;
            // 
            // label_Time
            // 
            this.label_Time.AutoSize = true;
            this.label_Time.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Time.Location = new System.Drawing.Point(426, 0);
            this.label_Time.Name = "label_Time";
            this.label_Time.Size = new System.Drawing.Size(41, 19);
            this.label_Time.TabIndex = 10;
            this.label_Time.Text = "Time";
            // 
            // label_idle
            // 
            this.label_idle.AutoSize = true;
            this.label_idle.BackColor = System.Drawing.Color.White;
            this.label_idle.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_idle.Location = new System.Drawing.Point(358, 0);
            this.label_idle.Name = "label_idle";
            this.label_idle.Size = new System.Drawing.Size(49, 19);
            this.label_idle.TabIndex = 9;
            this.label_idle.Text = "          ";
            // 
            // label_setup
            // 
            this.label_setup.AutoSize = true;
            this.label_setup.BackColor = System.Drawing.Color.Red;
            this.label_setup.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_setup.Location = new System.Drawing.Point(245, 0);
            this.label_setup.Name = "label_setup";
            this.label_setup.Size = new System.Drawing.Size(49, 19);
            this.label_setup.TabIndex = 8;
            this.label_setup.Text = "          ";
            // 
            // label_run
            // 
            this.label_run.AutoSize = true;
            this.label_run.BackColor = System.Drawing.Color.Gold;
            this.label_run.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_run.Location = new System.Drawing.Point(122, 0);
            this.label_run.Name = "label_run";
            this.label_run.Size = new System.Drawing.Size(49, 19);
            this.label_run.TabIndex = 7;
            this.label_run.Text = "          ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(311, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 19);
            this.label3.TabIndex = 4;
            this.label3.Text = "Idle: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(186, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "Setup: ";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBtn_ChartEdit,
            this.tsBtn_ChartReset});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(58, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsBtn_ChartEdit
            // 
            this.tsBtn_ChartEdit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsBtn_ChartEdit.Image = ((System.Drawing.Image)(resources.GetObject("tsBtn_ChartEdit.Image")));
            this.tsBtn_ChartEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsBtn_ChartEdit.Name = "tsBtn_ChartEdit";
            this.tsBtn_ChartEdit.Size = new System.Drawing.Size(23, 22);
            this.tsBtn_ChartEdit.Text = "Chart Edit";
            this.tsBtn_ChartEdit.Click += new System.EventHandler(this.tsBtn_ChartEdit_Click);
            // 
            // tsBtn_ChartReset
            // 
            this.tsBtn_ChartReset.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsBtn_ChartReset.Image = ((System.Drawing.Image)(resources.GetObject("tsBtn_ChartReset.Image")));
            this.tsBtn_ChartReset.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsBtn_ChartReset.Name = "tsBtn_ChartReset";
            this.tsBtn_ChartReset.Size = new System.Drawing.Size(23, 22);
            this.tsBtn_ChartReset.Text = "Chart Reset";
            this.tsBtn_ChartReset.Click += new System.EventHandler(this.tsBtn_ChartReset_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(74, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Run: ";
            // 
            // GanttChartControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.grid);
            this.Controls.Add(this.panel1);
            this.Name = "GanttChartControl";
            this.Size = new System.Drawing.Size(702, 283);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private SourceGrid.Grid grid;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsBtn_ChartEdit;
        private System.Windows.Forms.ToolStripButton tsBtn_ChartReset;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label_run;
        private System.Windows.Forms.Label label_setup;
        private System.Windows.Forms.Label label_idle;
        private System.Windows.Forms.Label label_Time;
    }
}
