﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using OfficeOpenXml;
using VMS.IFS.DataModel.OutputData;
using VMS.IFS.DataModel.DispatchingRuleData;

namespace VMS.IFS.UI
{
    public partial class SingleOutputViewer : Form
    {
        #region Member Variables

        private string fileName;
        private Dictionary<string, string> tableTabMapping;
        private Dictionary<string, ChartTable> tabCTMapping;
        private bool isNew;

        OutputDataSet ods;
        Dictionary<string, object> ro;

        #endregion

        #region Constructor

        public SingleOutputViewer(OutputDataSet ods, Dictionary<string, object> ro)
        {
            InitializeComponent();

            this.ods = ods;
            this.ro = ro;

            tabControl1.TabPages.Clear();

            tableTabMapping = new Dictionary<string, string>();
            tableTabMapping.Add("FabInOutDataTable", "Fab In/Out");
            tableTabMapping.Add("ProductInOutDataTable", "Product In/Out");
            tableTabMapping.Add("ProductTATDataTable", "Product TAT");
            tableTabMapping.Add("ProductStepTATDataTable", "Product-Step TAT");
            //tableTabMapping.Add("DueDateSatisfactionDataTable", "Due Date Satisfaction");
            tableTabMapping.Add("ProcessingStepWIPDataTable", "Processing Step WIP");
            tableTabMapping.Add("ProcessingStepOutputDataTable", "Processing Step Output");
            tableTabMapping.Add("EQPUtilizationDataTable", "EQP Utilization");
            tableTabMapping.Add("EQPOutputDataTable", "EQP Output");
            tableTabMapping.Add("EQPWIPDataTable", "EQP WIP");
            tableTabMapping.Add("FabWIPDataTable", "Fab WIP");
            tableTabMapping.Add("ReleaseBatchDataTable", "Release Plan");
            tableTabMapping.Add("FabOutPlanDataTable", "FabOut Plan");
            tableTabMapping.Add("EQPGanttChartDataTable", "EQP GanttChart");
            //tableTabMapping.Add("BNEQPDataTable", "Bottleneck detection - Tool group");
            //tableTabMapping.Add("BNProductStepDataTable", "Bottleneck detection - Product-Step");

            treeView1.Nodes.Clear();
            TreeNode topNode = new TreeNode("Simulation Output");

            BuildChartTable();

            foreach (string tableName in tableTabMapping.Keys)
            {
                string tabName = tableTabMapping[tableName];

                TabPage tp = new TabPage(tabName);
                tp.Controls.Add(tabCTMapping[tabName]);
                tabCTMapping[tabName].Dock = DockStyle.Fill;
                tabControl1.TabPages.Add(tp);
                
                TreeNode childnode = new TreeNode(tabName);
                topNode.Nodes.Add(childnode);
            }
            
            treeView1.Nodes.Add(topNode);

            isNew = true;
        }

        private void BuildChartTable()
        {
            tabCTMapping = new Dictionary<string, ChartTable>();

            ChartTable ctFIO = new ChartTable(ods.FabInOutDataTable, "Line", null, null, true);
            tabCTMapping.Add("Fab In/Out", ctFIO);

            ChartTable ctPIO = new ChartTable(ods.ProductInOutDataTable, "Line", null, null, true);
            tabCTMapping.Add("Product In/Out", ctPIO);

            List<string> xPTAT = new List<string>();
            xPTAT.Add("Product ID");            
            List<string> yPTAT = new List<string>();
            yPTAT.Add("Total TAT");
            ChartTable ctPTAT = new ChartTable(ods.ProductTATDataTable, "Column", xPTAT, yPTAT, true);
            tabCTMapping.Add("Product TAT", ctPTAT);

            List<string> xPStepTAT = new List<string>();
            xPStepTAT.Add("Product ID");
            ChartTable ctPStepTAT = new ChartTable(ods.StepTATChartDataTable, ods.ProductStepTATDataTable, "StackedColumn", xPStepTAT, null);
            tabCTMapping.Add("Product-Step TAT", ctPStepTAT);

            //List<string> xDDS = new List<string>();
            //xPTAT.Add("Release Batch ID");
            //List<string> yDDS = new List<string>();
            //yPTAT.Add("Satisfaction Ratio");
            //ChartTable ctDDS = new ChartTable(ods.DueDateSatisfactionDataTable, "Column", xDDS, yDDS);
            //tabCTMapping.Add("Due Date Satisfaction", ctDDS);

            ChartTable ctPStepWIP = new ChartTable(ods.ProcessingStepWIPDataTable, "Line", null, null, true);
            tabCTMapping.Add("Processing Step WIP", ctPStepWIP);

            ChartTable ctPStepOut = new ChartTable(ods.ProcessingStepOutputDataTable, "Line", null, null, true);
            tabCTMapping.Add("Processing Step Output", ctPStepOut);

            List<string> xEQPUtil = new List<string>();
            xEQPUtil.Add("EQP ID");
            ChartTable ctEQPUtil = new ChartTable(ods.EQPUtilizationDataTable, "StackedColumn", xEQPUtil, null, true);
            tabCTMapping.Add("EQP Utilization", ctEQPUtil);

            ChartTable ctEQPOut = new ChartTable(ods.EQPOutputDataTable, "Line", null, null, true);
            tabCTMapping.Add("EQP Output", ctEQPOut);

            ChartTable ctEQPWIP = new ChartTable(ods.EQPWIPDataTable, "Line", null, null, true);
            tabCTMapping.Add("EQP WIP", ctEQPWIP);

            ChartTable ctFabWIP = new ChartTable(ods.FabWIPDataTable, "Line", null, null, true);
            tabCTMapping.Add("Fab WIP", ctFabWIP);

            ChartTable ctRPlan = new ChartTable(ods.ReleaseBatchDataTable, "Column", new List<string>(), new List<string>(), false);
            tabCTMapping.Add("Release Plan", ctRPlan);

            ChartTable ctFOPlan = new ChartTable(ods.FabOutPlanDataTable, "Column", new List<string>(), new List<string>(), false);
            tabCTMapping.Add("FabOut Plan", ctFOPlan);

            ChartTable ctEQPGantt = new ChartTable(ods.EQPGanttChartDataTable, "Gantt", null, null, true);
            tabCTMapping.Add("EQP GanttChart", ctEQPGantt);

            //ChartTable ctBNEQP = new ChartTable(ro, ods.BNEQPDataTable, "Line-Column", null, null, true);
            //tabCTMapping.Add("Bottleneck detection - Tool group", ctBNEQP);

            //ChartTable ctBNPS = new ChartTable(ro, ods.BNProductStepDataTable, "Line-Column", null, null, true);
            //tabCTMapping.Add("Bottleneck detection - Product-Step", ctBNPS);
        }

        #endregion

        #region Event Handling

        private void treeView1_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            string tab = treeView1.SelectedNode.Text;
            foreach (TabPage tp in tabControl1.TabPages)
            {
                if (tp.Text.Equals(tab))
                {
                    tabControl1.SelectedTab = tp;
                }
            }
        }

        #endregion        

        #region Save Method

        public void Save(string type) //type이 "Save"이면 저장, "SaveAs"면 다른 이름으로 저장
        {
            if (type == "SaveAs" || isNew)
            {
                this.saveFileDialog1.Filter = "Excel Files|*.xls;*.xlsx|All files|*.*";
                if (this.saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    this.fileName = saveFileDialog1.FileName;
                    isNew = false;
                }
            }

            if (fileName != "")
            {
                FileInfo file = new FileInfo(this.fileName);
                if (file.Exists)
                {
                    file.Delete();
                    file = new FileInfo(this.fileName);
                }
                ExcelPackage package = new ExcelPackage(file);

                ExcelWorksheet ws = package.Workbook.Worksheets.Add("Run Option");
                ws.Cells[1, 1].Value = "EOS Mode";
                ws.Cells[1, 2].Value = ro["EOSMode"];
                if (ro["EOSMode"] == "Time")
                {
                    ws.Cells[2, 1].Value = "EOS Time";
                    ws.Cells[2, 2].Value = ro["EOSTime"];
                }
                ws.Cells[4, 1].Value = "Unit Data Collection Time";
                ws.Cells[4, 2].Value = ro["UnitTime"];
                
                ws.Cells[6, 1].Value = "Job Selection Rule";
                ws.Cells[7, 1].Value = ((DispatchingRuleDefinition)ro["JSR"]).Name;
                int i = 2;
                foreach (string key in ro.Keys)
                {
                    if (key.Contains("JSR_"))
                    {
                        ws.Cells[6, i].Value = key.Remove(0, 4);
                        ws.Cells[7, i].Value = ro[key];
                        i++;
                    }
                }

                ws.Cells[9, 1].Value = "Machine Selection Rule";
                ws.Cells[10, 1].Value = ((DispatchingRuleDefinition)ro["MSR"]).Name;
                int j = 2;
                foreach (string key in ro.Keys)
                {
                    if (key.Contains("MSR_"))
                    {
                        ws.Cells[9, i].Value = key.Remove(0, 4);
                        ws.Cells[10, i].Value = ro[key];
                        j++;
                    }
                }
                
                foreach (DataTable dt in ods.Tables)
                {
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(tableTabMapping[dt.TableName]);
                    worksheet.Cells.LoadFromDataTable(dt, true);
                }

                package.Save();
            }
        }

        #endregion
    }
}
