﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VMS.IFS.UI
{
    public partial class SOTable : UserControl
    {
        #region Member Variable
        
        private DataTable dtMaster;
        private DataTable dtShow;

        private List<string> selected;
        private List<string> unselected;

        #endregion

        #region Constructor

        public SOTable(DataTable dt)
        {
            InitializeComponent();

            this.dtMaster = dt;
            DataTable dtCopy = dtMaster.Copy();
            this.dtShow = dtCopy;

            selected = new List<string>();
            unselected = new List<string>();
            foreach (DataColumn dc in dtMaster.Columns)
            {
                selected.Add(dc.ColumnName);
            }

            Print();
        }

        #endregion

        #region Print Method

        private void Print()
        {
            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            datagrid.Columns.Clear();
            datagrid.DataSource = new DevAge.ComponentModel.BoundDataView(dtShow.DefaultView);

            for (int i = 0; i < datagrid.Columns.Count; i++)
            {
                datagrid.Columns[i].HeaderCell.View = titleModel;
                //datagrid.Columns[i].MinimalWidth = (datagrid.Columns[i].PropertyName.Length + 5) * (int)datagrid.Font.Size;
                //grid.Columns[i].AutoSizeMode = SourceGrid.AutoSizeMode.

                //_ColumnNameToIndex.Add(grid.Columns[i].PropertyName, i);
            }


            datagrid.Columns.AutoSize(true);
        }

        #endregion

        #region Table Edit Method

        private DataTable EditTable()
        {
            DataTable dt = new DataTable();

            foreach (string str in selected)
            {
                dt.Columns.Add(str);
            }

            foreach (DataRow dr in dtMaster.Rows)
            {
                DataRow row = dt.NewRow();
                foreach (string str in selected)
                {
                    row[str] = dr[str].ToString();
                }
                dt.Rows.Add(row);
            }

            return dt;
        }

        #endregion

        #region Tool Strip Button Handling

        private void tsBtn_TableEdit_Click(object sender, EventArgs e)
        {
            SOTableFormatEditor tfe = new SOTableFormatEditor(selected, unselected);

            switch (tfe.ShowDialog())
            {
                case DialogResult.OK:
                    {
                        selected = tfe.selected;
                        unselected = tfe.unselected;

                        dtShow = EditTable();
                        Print();
                        break;
                    }
            }
        }

        private void tsBtn_TableReset_Click(object sender, EventArgs e)
        {
            DataTable dtCopy = dtMaster.Copy();
            dtShow = dtCopy;

            Print();
        }

        #endregion
    }
}
