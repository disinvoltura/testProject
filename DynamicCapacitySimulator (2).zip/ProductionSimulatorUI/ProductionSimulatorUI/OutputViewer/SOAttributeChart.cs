﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace VMS.IFS.UI
{
    public partial class SOAttributeChart : UserControl
    {
        #region Member Variable

        private DataTable dtMaster;
        private DataTable dtShow;
        
        private List<string> xColumns;
        private List<string> yColumns;

        private List<string> xValues;
        private List<string> selectedXValues;

        #endregion

        #region Constructor

        public SOAttributeChart(DataTable dt, List<string> xColumns, List<string> yColumns)
        {
            InitializeComponent();

            this.dtMaster = dt;
            DataTable dtCopy = dtMaster.Copy();
            this.dtShow = dtCopy;

            this.xColumns = xColumns;
            this.yColumns = yColumns;

            xValues = new List<string>();
            selectedXValues = new List<string>();
            for (int i = 0; i < dtMaster.Rows.Count; i++)
            {
                string x = "";
                foreach (string str in xColumns)
                {
                    if (x == "")
                    {
                        x += dtMaster.Rows[i][str].ToString();
                    }
                    else
                    {
                        x += "-" + dtMaster.Rows[i][str].ToString();
                    }
                }
                if (x != "")
                {
                    x.Remove(x.Length - 2, 1);

                    xValues.Add(x);
                    selectedXValues.Add(x);
                }
            }

            Print();
        }

        #endregion

        #region Print Method

        private void Print()
        {            
            chart.Series.Clear();
            chart.ChartAreas[0].AxisX.CustomLabels.Clear();

            Dictionary<string, double> dicID_Value = new Dictionary<string, double>();
            Dictionary<double, string> dicValue_ID = new Dictionary<double, string>();

            double value = 1;
            for (int i = 1; i < dtShow.Columns.Count; i++)
            {                
                if (yColumns.Contains(dtShow.Columns[i].ColumnName))
                {
                    Series s = new Series();
                    s.Name = dtShow.Columns[i].ColumnName;
                    s.ChartType = SeriesChartType.Column;                    
                    s.BorderWidth = 5;

                    for (int j = 0; j < dtShow.Rows.Count; j++)
                    {
                        string id = "";
                        foreach (string str in xColumns)
                        {
                            if (id == "")
                            {
                                id += dtShow.Rows[j][str].ToString();
                            }
                            else
                            {
                                id += "-" + dtShow.Rows[j][str].ToString();
                            }
                        }
                        
                        if (!dicID_Value.ContainsKey(id))
                        {
                            dicID_Value.Add(id, value);
                            dicValue_ID.Add(value, id);
                            value++;
                        }

                        DataPoint dp = new DataPoint(dicID_Value[id], double.Parse(dtShow.Rows[j][i].ToString()));
                        s.Points.Add(dp);
                    }                                       

                    chart.Series.Add(s);
                }
            }

            foreach (double key in dicValue_ID.Keys)
            {
                chart.ChartAreas[0].AxisX.CustomLabels.Add(key - 0.1, key + 0.1, dicValue_ID[key]);
            }  
        }

        #endregion

        #region Chart Edit Method

        private DataTable EditChart()
        {
            DataTable dt = new DataTable();

            foreach (DataColumn dc in dtMaster.Columns)
            {
                dt.Columns.Add(dc.ColumnName);
            }
            foreach (DataRow dr in dtMaster.Rows)
            {
                string id = "";
                foreach (string str in xColumns)
                {
                    if (id == "")
                    {
                        id += dr[str].ToString();
                    }
                    else
                    {
                        id += "-" + dr[str].ToString();
                    }
                }
                
                if (selectedXValues.Contains(id))
                {
                    DataRow row = dt.NewRow();
                    foreach (DataColumn dc in dt.Columns)
                    {
                        row[dc.ColumnName] = dr[dc.ColumnName].ToString();
                    }
                    dt.Rows.Add(row);
                }
            }

            return dt;
        }

        #endregion

        #region Tool Strip Button Handling

        private void tsBtn_ChartEdit_Click(object sender, EventArgs e)
        {
            SOAttributeChartFormatEditor cfe = new SOAttributeChartFormatEditor(xValues, selectedXValues);

            switch (cfe.ShowDialog())
            {
                case DialogResult.OK:
                    {
                        selectedXValues = cfe.selectedXValues;

                        dtShow = EditChart();
                        Print();

                        break;
                    }
            }
        }

        private void tsBtn_ChartReset_Click(object sender, EventArgs e)
        {
            DataTable dtCopy = dtMaster.Copy();
            dtShow = dtCopy;

            xValues = new List<string>();
            selectedXValues = new List<string>();
            for (int i = 0; i < dtMaster.Rows.Count; i++)
            {
                string x = "";
                foreach (string str in xColumns)
                {
                    if (x == "")
                    {
                        x += dtMaster.Rows[i][str].ToString();
                    }
                    else
                    {
                        x += "-" + dtMaster.Rows[i][str].ToString();
                    }
                }
                x.Remove(x.Length - 2, 1);

                xValues.Add(x);
                selectedXValues.Add(x);
            }

            Print();
        }

        #endregion
    }
}
