﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VMS.IFS.UI
{
    public partial class SOTimeSeriesChartFormatEditor : Form
    {
        #region Member Variable

        public string selectedStart;
        public string selectedEnd;

        private List<string> yValues;
        public List<string> selectedYValues;        

        #endregion

        #region Constructor

        public SOTimeSeriesChartFormatEditor(string start, string end, List<string> sColumns, List<string> columns)
        {
            InitializeComponent();

            this.selectedStart = start;
            this.selectedEnd = end;
            this.selectedYValues = sColumns;
            this.yValues = columns;
          
            tb_Start.Text = start;
            tb_End.Text = end;

            grid_Y.ColumnsCount = 2;
            grid_Y.FixedRows = 1;
            grid_Y.Rows.Insert(0);

            grid_Y[0, 0] = new SourceGrid.Cells.ColumnHeader("Select");
            grid_Y[0, 1] = new SourceGrid.Cells.ColumnHeader("Y Value Name");

            int i = 1;
            bool selectAll = true;
            foreach (string str in yValues)
            {
                grid_Y.Rows.Insert(i);
                if (selectedYValues.Contains(str))
                {
                    grid_Y[i, 0] = new SourceGrid.Cells.CheckBox(null, true);
                }
                else
                {
                    grid_Y[i, 0] = new SourceGrid.Cells.CheckBox(null, false);
                    selectAll = false;
                }
                grid_Y[i, 1] = new SourceGrid.Cells.Cell(str);
                i++;
            }

            if (selectAll)
                cb_All.Checked = true;

            grid_Y.Columns.AutoSize(true);            
        }

        #endregion

        #region Button Handling

        private void btn_OK_Click(object sender, EventArgs e)
        {
            selectedStart = tb_Start.Text;
            selectedEnd = tb_End.Text;
            selectedYValues = new List<string>();
            for (int i = 1; i < grid_Y.Rows.Count; i++)
            {
                if ((bool)grid_Y[i, 0].Value)
                {
                    selectedYValues.Add(grid_Y[i, 1].Value.ToString());
                }
            }

            this.DialogResult = System.Windows.Forms.DialogResult.OK;

            this.Close();
        }
        
        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion        

        private void cb_All_CheckedChanged(object sender, EventArgs e)
        {
            if (cb_All.Checked == true)
            {
                for (int i = 1; i < grid_Y.Rows.Count; i++)
                {
                    grid_Y[i, 0].Value = true;                    
                }
            }
            else
            {
                for (int i = 1; i < grid_Y.Rows.Count; i++)
                {
                    grid_Y[i, 0].Value = false;
                }
            }
        }
    }
}
