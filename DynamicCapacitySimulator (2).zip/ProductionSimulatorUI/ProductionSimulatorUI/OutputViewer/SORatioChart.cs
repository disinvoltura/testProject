﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace VMS.IFS.UI
{
    public partial class SORatioChart : UserControl
    {
        #region Member Variable

        private DataTable dtMaster;
        private DataTable dtShow;

        private List<string> xColumns;

        private List<string> xValues;
        private List<string> selectedXValues;        

        #endregion

        #region Constructor

        public SORatioChart(DataTable dt, List<string> xColumns)
        {
            InitializeComponent();

            this.dtMaster = dt;
            DataTable dtCopy = dtMaster.Copy();
            this.dtShow = dtCopy;

            this.xColumns = xColumns;

            xValues = new List<string>();
            selectedXValues = new List<string>();

            for (int i = 0; i < dtMaster.Rows.Count; i++)
            {
                string x = "";
                foreach (string str in xColumns)
                {
                    if (x == "")
                    {
                        x += dtMaster.Rows[i][str].ToString();
                    }
                    else
                    {
                        x += "-" + dtMaster.Rows[i][str].ToString();
                    }
                }
                x.Remove(x.Length - 2, 1);

                xValues.Add(x);
                selectedXValues.Add(x);
            }

            //foreach (DataRow dr in dtMaster.Rows)
            //{
            //    xValues.Add(dr[0].ToString());
            //    selectedXValues.Add(dr[0].ToString());
            //}

            Print();
        }

        #endregion

        #region Print Method

        private void Print()
        {            
            chart.Series.Clear();
            chart.ChartAreas[0].AxisX.CustomLabels.Clear();

            Dictionary<string, double> dicID_Value = new Dictionary<string, double>();
            Dictionary<double, string> dicValue_ID = new Dictionary<double, string>();
            Dictionary<string, int> dicSeriesName = new Dictionary<string, int>();

            int series = 1;
            double value = 1;
            for (int i = 1; i < dtShow.Columns.Count; i++)
            {
                Series s = new Series();
                s.Name = dtShow.Columns[i].ColumnName;
                s.ChartType = SeriesChartType.StackedColumn;
                s.BorderWidth = 5;

                if (!dicSeriesName.ContainsKey(s.Name))
                {
                    dicSeriesName.Add(s.Name, series);
                    series++;
                }                
                
                chart.Series.Add(s);
            }

            foreach (string x in selectedXValues)
            {                
                if (!dicID_Value.ContainsKey(x))
                {
                    dicID_Value.Add(x, value);
                    dicValue_ID.Add(value, x);
                    value++;
                }

                //DataPoint dp = new DataPoint(dicID_Value[id], double.Parse(dr[i].ToString()));
                //s.Points.Add(dp);
            }

            foreach (string x in selectedXValues)
            {
                foreach (string sID in dicSeriesName.Keys)
                {
                    DataPoint dp = new DataPoint(dicID_Value[x], getValue(x, sID));
                    chart.Series[sID].Points.Add(dp);
                }
            }

            foreach (double key in dicValue_ID.Keys)
            {
                chart.ChartAreas[0].AxisX.CustomLabels.Add(key - 0.1, key + 0.1, dicValue_ID[key]);
            }                       
        }

        #endregion

        #region Chart Edit Method

        private DataTable EditChart()
        {                        
            DataTable dt = new DataTable();

            foreach (DataColumn dc in dtMaster.Columns)
            {
                dt.Columns.Add(dc.ColumnName);
            }
            foreach (DataRow dr in dtMaster.Rows)
            {
                if (selectedXValues.Contains(dr[0].ToString()))
                {
                    DataRow row = dt.NewRow();
                    foreach (DataColumn dc in dt.Columns)
                    {
                        row[dc.ColumnName] = dr[dc.ColumnName].ToString();
                    }
                    dt.Rows.Add(row);
                }
            }

            return dt;
        }

        #endregion        

        #region Tool Strip Button Handling

        private void tsBtn_ChartEdit_Click(object sender, EventArgs e)
        {
            SORatioChartFormatEditor cfe = new SORatioChartFormatEditor(xValues, selectedXValues);

            switch (cfe.ShowDialog())
            {
                case DialogResult.OK:
                    {
                        selectedXValues = cfe.selectedXValues;

                        dtShow = EditChart();
                        Print();

                        break;
                    }
            }
        }

        private void tsBtn_ChartReset_Click(object sender, EventArgs e)
        {
            DataTable dtCopy = dtMaster.Copy();
            dtShow = dtCopy;

            xValues = new List<string>();
            selectedXValues = new List<string>();

            foreach (DataRow dr in dtMaster.Rows)
            {
                xValues.Add(dr[0].ToString());
                selectedXValues.Add(dr[0].ToString());
            }

            Print();
        }

        #endregion

        #region Method

        private double getValue(string key, string series)
        {
            double rslt = 0;

            foreach (DataRow dr in dtShow.Rows)
            {
                string x = "";
                foreach (string str in xColumns)
                {
                    if (x == "")
                    {
                        x += dr[str].ToString();
                    }
                    else
                    {
                        x += "-" + dr[str].ToString();
                    }
                }
                x.Remove(x.Length - 2, 1);
                
                if (x == key)
                {
                    double parse = 0;
                    double.TryParse(dr[series].ToString(), out parse);
                    rslt = parse;
                }
            }

            return rslt;
        }

        #endregion
    }
}
