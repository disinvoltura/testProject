﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VMS.IFS.UI
{
    public partial class GanttChartControl : UserControl
    {
        #region Member Variables
        private GanttChartData _GCData;
        private Dictionary<string, SourceGrid.Cells.Views.Cell> _BGModels;
        private Dictionary<string, SourceGrid.Cells.Controllers.ToolTipText> _TCControllers;
        private int _DefaultWidth = 1;
        private int _DefaultHeight = 25;

        private DateTime _Start;
        private DateTime _End;
        private bool _Range;

        private List<string> _Members;
        private List<string> _SelectedMembers;
        #endregion

        #region Properties
        /// <summary>
        /// Pixel per minute
        /// </summary>
        public int DefaultWidth
        {
            get { return _DefaultWidth; }
            set { _DefaultWidth = value; }
        }
        public int DefaultHeight
        {
            get { return _DefaultHeight; }
            set { _DefaultHeight = value; }
        }
        #endregion

        #region Constructors
        public GanttChartControl()
        {
            InitializeComponent();
        }
        #endregion

        #region Methods
        public void LoadGanttChartData(GanttChartData data, bool showIdle, bool showDaySeparator)
        {
            _GCData = data;
            _Members = new List<string>();
            _SelectedMembers = new List<string>();
            foreach (string eqp in _GCData.Resources)
            {
                _Members.Add(eqp);
                _SelectedMembers.Add(eqp);
            }
            label_Time.Text = _GCData.MinimumTime.ToString("yyyy-MM-dd HH:mm") + " ~ " + _GCData.MaximumTime.ToString("yyyy-MM-dd HH:mm");
            _Start = new DateTime(_GCData.MinimumTime.Year, _GCData.MinimumTime.Month, _GCData.MinimumTime.Day, _GCData.MinimumTime.Hour, _GCData.MinimumTime.Minute, _GCData.MinimumTime.Second);
            _End = new DateTime(_GCData.MaximumTime.Year, _GCData.MaximumTime.Month, _GCData.MaximumTime.Day, _GCData.MaximumTime.Hour, _GCData.MaximumTime.Minute, _GCData.MaximumTime.Second);
            _Range = false;

            doInitialize();
            doShowGanttChart(showIdle, showDaySeparator);
        }

        private void doInitialize()
        {
            _BGModels = new Dictionary<string, SourceGrid.Cells.Views.Cell>();
            _TCControllers = new Dictionary<string, SourceGrid.Cells.Controllers.ToolTipText>();
            foreach (string categoryName in _GCData.Categories)
            {
                SourceGrid.Cells.Views.Cell barModel = new SourceGrid.Cells.Views.Cell();
                DevAge.Drawing.VisualElements.BackgroundSolid backgroundSetup =
                    new DevAge.Drawing.VisualElements.BackgroundSolid();
                backgroundSetup.BackColor = Color.FromName(_GCData.GetColor(categoryName));
                barModel.Background = backgroundSetup;
                barModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

                _BGModels.Add(categoryName, barModel);


                //tooltip
                SourceGrid.Cells.Controllers.ToolTipText toolTipController =
                    new SourceGrid.Cells.Controllers.ToolTipText();
                toolTipController.ToolTipTitle = categoryName;
                toolTipController.ToolTipIcon = ToolTipIcon.Info;
                if (categoryName == "Idle")
                {
                    toolTipController.IsBalloon = false;
                }
                else
                {
                    toolTipController.IsBalloon = true;
                }
                _TCControllers.Add(categoryName, toolTipController);
            }

            label_run.BackColor = Color.FromName(_BGModels["Run"].BackColor.Name);
            label_setup.BackColor = Color.FromName(_BGModels["Setup"].BackColor.Name);
            label_idle.BackColor = Color.FromName(_BGModels["Idle"].BackColor.Name);

            //SourceGrid.Cells.Controllers.ToolTipText idleToolTipController =
            //        new SourceGrid.Cells.Controllers.ToolTipText();
            //idleToolTipController.ToolTipTitle = "Idle";
            //idleToolTipController.ToolTipIcon = ToolTipIcon.Info;
            //idleToolTipController.IsBalloon = false;

            //_TCControllers.Add("Idle", idleToolTipController);
        }

        private void doShowGanttChart(bool showIdle, bool showDaySeparator)
        {           
            grid.Rows.Clear();
            grid.Columns.Clear();

            grid.AllowOverlappingCells = true;

            //Calculate columsn and rows
            int rows = _GCData.Count + 3;//date, hours, minutes

            //resource column + total minutes  + header columns
            //int cols = (int)data.MaximumTime.Subtract(data.MinimumTime).TotalMinutes + 2;
            int cols = (int)_End.Subtract(_Start).TotalMinutes;
            if (cols % 60 > 0)
                cols += (60 - (cols % 60));
            cols += 3; //3인걸 2로 수정!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

            //Resource Columns.
            grid.DefaultWidth = _DefaultWidth;
            grid.DefaultHeight = _DefaultHeight;
            grid.Redim(rows, cols);
            grid.FixedRows = 3;
            grid.FixedColumns = 2;

            //Headers
            drawHeaders(_GCData, showDaySeparator);

            //Data Rows
            SourceGrid.Cells.Views.Cell headerModel = new SourceGrid.Cells.Views.Cell();
            DevAge.Drawing.VisualElements.BackgroundSolid backgroundHeader =
                new DevAge.Drawing.VisualElements.BackgroundSolid();
            backgroundHeader.BackColor = Color.Lavender;
            headerModel.Background = backgroundHeader;
            headerModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
                        
            int rowIndex = 3;
            foreach (string resourceid in _GCData.Resources)
            {
                if (_SelectedMembers.Contains(resourceid))
                {
                    GanttChartResource res = _GCData[resourceid];

                    SourceGrid.Cells.RowHeader l_00Header = new SourceGrid.Cells.RowHeader(null);
                    grid[rowIndex, 0] = l_00Header;
                    grid.Rows[rowIndex].Height = 35;

                    SourceGrid.Cells.Cell eqpidCell = new SourceGrid.Cells.Cell(resourceid, typeof(string));
                    eqpidCell.View = headerModel;
                    eqpidCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
                    eqpidCell.RowSpan = 1;
                    grid[rowIndex, 1] = eqpidCell;

                    int lastColIndex = 2;
                    for (int i = 0; i < res.Items.Count; i++)
                    {
                        GanttChartBar bar = res.Items[i];
                        if (bar.StartTime == bar.EndTime)
                            continue;

                        //int colIndex = (int)bar.StartTime.Subtract(_GCData.MinimumTime).TotalMinutes + 2;
                        //int width = (int)bar.EndTime.Subtract(bar.StartTime).TotalMinutes;

                        int colIndex = 0;
                        int width = 0;

                        if (bar.StartTime < _Start && bar.EndTime <= _Start)
                        {
                            continue;
                        }
                        else if (bar.StartTime < _Start && bar.EndTime > _Start && bar.EndTime <= _End)
                        {
                            colIndex = (int)bar.StartTime.Subtract(_Start).TotalMinutes + 2;
                            width = (int)bar.EndTime.Subtract(_Start).TotalMinutes;
                        }
                        else if (bar.StartTime >= _Start && bar.EndTime < _End)
                        {
                            colIndex = (int)bar.StartTime.Subtract(_Start).TotalMinutes + 2;
                            width = (int)bar.EndTime.Subtract(bar.StartTime).TotalMinutes;
                        }
                        else if (bar.StartTime >= _Start && bar.EndTime == _End)
                        {
                            colIndex = (int)bar.StartTime.Subtract(_Start).TotalMinutes + 2;
                            width = cols - colIndex - 1;
                        }
                        else if (bar.StartTime >= _Start && bar.StartTime < _End && bar.EndTime > _End)
                        {
                            colIndex = (int)bar.StartTime.Subtract(_Start).TotalMinutes + 2;
                            width = cols - colIndex - 1;
                        }
                        else if (bar.StartTime < _Start && bar.EndTime > _End)
                        {
                            colIndex = 2;
                            width = cols - colIndex - 1;
                        }
                        else if (bar.StartTime >= _End)
                        {
                            break;
                        }

                        if (showIdle)
                        {
                            int idleCols = colIndex - lastColIndex;
                            if (idleCols > 0)
                            {
                                InsertIdleCell(rowIndex, lastColIndex, idleCols);
                            }
                        }
                        if (width > 0)
                        {
                            string tooltip = string.Format("Start: {0} \r\n End: {1}", bar.StartTime.ToString("yyyy-MM-dd HH:mm"), bar.EndTime.ToString("yyyy-MM-dd HH:mm"));
                            //string tooltip = string.Format("{0}: {1} ~ {2}", bar.Category, bar.StartTime.ToString("yyyy-MM-dd HH:mm"), bar.EndTime.ToString("yyyy-MM-dd HH:mm"));
                            InsertBarCell(rowIndex, colIndex, width, bar.Category, bar.Text, tooltip);
                        }
                        lastColIndex = colIndex + width;

                    }
                    if (showIdle)
                    {
                        if (lastColIndex < cols - 1)
                        {
                            InsertIdleCell(rowIndex, lastColIndex, (cols - 1) - lastColIndex);
                        }
                    }
                    rowIndex++;
                }
                grid.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
                //grid.AutoSizeCells();
                grid.Columns.AutoSizeColumn(1);
                grid.SelectionMode = SourceGrid.GridSelectionMode.Cell;
            }
        }

        private void InsertBarCell(int row, int colStart, int width, string category, string text, string tooltip)
        {
            SourceGrid.Cells.Cell barCell = new SourceGrid.Cells.Cell(text, typeof(string));
            barCell.View = _BGModels[category];
            barCell.ColumnSpan = width;
            barCell.Editor.EnableEdit = false;
            grid[row, colStart] = barCell;
            barCell.ToolTipText = tooltip;
            //barCell.AddController(SourceGrid.Cells.Controllers.ToolTipText.Default);
            //barCell.Model.AddModel(MyToolTipModel.Default);

            if (_TCControllers.ContainsKey(category))
                barCell.AddController(_TCControllers[category]);
        }

        private class MyToolTipModel : SourceGrid.Cells.Models.IToolTipText
        {
            public static readonly MyToolTipModel Default = new MyToolTipModel();

            public string GetToolTipText(SourceGrid.CellContext cellContext)
            {
                SourceGrid.DataGrid grid = (SourceGrid.DataGrid)cellContext.Grid;
                DataRowView row = (DataRowView)grid.Rows.IndexToDataSourceRow(cellContext.Position.Row);
                if (row != null)
                {
                    if (bool.Equals(row["Selected"], true))
                        return "Row " + cellContext.Position.Row.ToString() + " is selected";
                    else
                        return "Row " + cellContext.Position.Row.ToString() + " is NOT selected";
                }
                else
                    return string.Empty;
            }
        }

        private void InsertIdleCell(int row, int colStart, int width)
        {
            SourceGrid.Cells.Cell idlebarCell = new SourceGrid.Cells.Cell("", typeof(string));
            idlebarCell.View = _BGModels["Idle"];
            idlebarCell.ColumnSpan = width;            
            grid[row, colStart] = idlebarCell;
            
            idlebarCell.ToolTipText = "Idle Time: " + width + " minutes";
            //idlebarCell.AddController(SourceGrid.Cells.Controllers.ToolTipText.Default);
            //idlebarCell.Model.AddModel(MyToolTipModel.Default);

            if (_TCControllers.ContainsKey("Idle"))
                idlebarCell.AddController(_TCControllers["Idle"]);
        }

        private void InsertBarrierCell(int row, int colStart, int width)
        {
            SourceGrid.Cells.Views.Cell headerModel = new SourceGrid.Cells.Views.Cell();
            DevAge.Drawing.VisualElements.BackgroundSolid backgroundHeader =
                new DevAge.Drawing.VisualElements.BackgroundSolid();
            backgroundHeader.BackColor = Color.HotPink;
            headerModel.Background = backgroundHeader;
            headerModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            SourceGrid.Cells.Cell barrierbarCell = new SourceGrid.Cells.Cell("", typeof(string));
            barrierbarCell.View = headerModel;
            barrierbarCell.ColumnSpan = width;
            grid[row, colStart] = barrierbarCell;

            //idlebarCell.ToolTipText = "Idle Time: " + width + " minutes";
            ////idlebarCell.AddController(SourceGrid.Cells.Controllers.ToolTipText.Default);
            ////idlebarCell.Model.AddModel(MyToolTipModel.Default);

            //if (_TCControllers.ContainsKey("Idle"))
            //    idlebarCell.AddController(_TCControllers["Idle"]);
        }

        private void drawHeaders(GanttChartData data, bool showDaySeparator)
        {
            DateTime now1 = DateTime.Now;
            int timeCols = (int)_End.Subtract(_Start).TotalMinutes;
            if (timeCols % 60 > 0)
                timeCols += (60 - (timeCols % 60));

            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
            
            grid.Font = new Font("Calibe", 9);
            grid.EnableSort = false;
            
            grid.Columns[0].AutoSizeMode = SourceGrid.AutoSizeMode.None;
            grid.Columns[0].Width = 20;
            SourceGrid.Cells.RowHeader l_00Header = new SourceGrid.Cells.RowHeader(null);
            grid[0, 0] = l_00Header;
            grid[1, 0] = new SourceGrid.Cells.RowHeader(null); ;

            DateTime after1 = DateTime.Now;
            System.Diagnostics.Trace.WriteLine("drawheader:1 took " + after1.Subtract(now1).TotalSeconds + " seconds.");

            DateTime now2 = DateTime.Now;
            string[] columns = { "EQP ID"};
            for (int i = 0; i < columns.Length; i++)
            {
                SourceGrid.Cells.ColumnHeader header =
                    new SourceGrid.Cells.ColumnHeader(columns[i]);

                header.View = titleModel;
                header.RowSpan = 2;
                grid[0, 1 + i] = header;
            }
            grid.Columns[1].Width = 100;

            DateTime after2 = DateTime.Now;
            System.Diagnostics.Trace.WriteLine("drawheader:2 took " + after2.Subtract(now2).TotalSeconds + " seconds.");

            DateTime now3 = DateTime.Now;

            for (int i = 0; i < timeCols; i++) // <=인걸 <로 수정!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            {
                DateTime curTime = _Start.AddMinutes(i);
                
                if (curTime.Hour == 0 
                    && curTime.Minute == 0)
                {
                    SourceGrid.Cells.ColumnHeader header1 =
                        new SourceGrid.Cells.ColumnHeader(curTime.ToString("yyyy-MM-dd"));
                    header1.View = titleModel;

                    if ((timeCols - i) < 1440)
                        header1.ColumnSpan = timeCols - i + 1;
                    else
                        header1.ColumnSpan = 1440;

                    grid[0, 2 + i] = header1;
                }
                else if (i == 0)
                {
                    SourceGrid.Cells.ColumnHeader header1 =
                        new SourceGrid.Cells.ColumnHeader(curTime.ToString("yyyy-MM-dd"));
                    header1.View = titleModel;
                    header1.ColumnSpan = 1440 - (int)curTime.TimeOfDay.TotalMinutes;
                    grid[0, 2 + i] = header1;
                }

                if (curTime.Minute == 0)
                {
                    int hour = i / 60 + 1;// 1;
                    SourceGrid.Cells.ColumnHeader header1 =
                        new SourceGrid.Cells.ColumnHeader(curTime.ToString("HH"));
                    header1.View = titleModel;
                    
                    if ( (timeCols - i)  < 60)
                        header1.ColumnSpan = timeCols -i+1;
                    else
                        header1.ColumnSpan = 60;
                    
                    grid[1, 2 + i] = header1;
                }

                //if (curTime.Minute == 59 && showDaySeparator)
                //{
                //    for (int k = 3; k < grid.Rows.Count; k++)
                //    {
                //        InsertBarrierCell(k, 2 + i, 1);
                //    }
                //}
                
                SourceGrid.Cells.ColumnHeader header2 =
                    new SourceGrid.Cells.ColumnHeader("");

                header2.View = titleModel;
                grid[2, 2 + i] = header2;
                
                grid.Columns[2+i].MinimalWidth = 1;
            }
             
            DateTime after3 = DateTime.Now;
            System.Diagnostics.Trace.WriteLine("drawheader:3 took " + after3.Subtract(now3).TotalSeconds + " seconds.");

            grid.Rows[2].Height = 0;
            grid.SelectionMode = SourceGrid.GridSelectionMode.Row;
        }

        #endregion

        #region Tool Strip Button Handling

        private void tsBtn_ChartEdit_Click(object sender, EventArgs e)
        {
            GanttChartFormatEditor gce = new GanttChartFormatEditor(_Range, _GCData.MinimumTime, _GCData.MaximumTime, _Start, _End, _Members, _SelectedMembers, _BGModels["Run"].BackColor.ToArgb(), _BGModels["Setup"].BackColor.ToArgb(), _BGModels["Idle"].BackColor.ToArgb());

            DialogResult rslt = gce.ShowDialog();
            if (rslt == DialogResult.OK)
            {
                _SelectedMembers = gce.SelectedMembers;
                
                _BGModels["Run"].BackColor = Color.FromArgb(gce.RunColor);
                _BGModels["Setup"].BackColor = Color.FromArgb(gce.SetupColor);
                _BGModels["Idle"].BackColor = Color.FromArgb(gce.IdleColor);

                label_run.BackColor = Color.FromArgb(_BGModels["Run"].BackColor.ToArgb());
                label_setup.BackColor = Color.FromArgb(_BGModels["Setup"].BackColor.ToArgb());
                label_idle.BackColor = Color.FromArgb(_BGModels["Idle"].BackColor.ToArgb());

                _Range = gce.Range;
                _Start = gce.From;
                _End = gce.To;

                label_Time.Text = _Start.ToString("yyyy-MM-dd HH:mm") + " ~ " + _End.ToString("yyyy-MM-dd HH:mm");

                doShowGanttChart(true, true);
            }
        }

        private void tsBtn_ChartReset_Click(object sender, EventArgs e)
        {
            _SelectedMembers = _Members;

            _BGModels["Run"].BackColor = Color.FromName("Gold");
            _BGModels["Setup"].BackColor = Color.FromName("Red");
            _BGModels["Idle"].BackColor = Color.FromName("White");

            label_run.BackColor = Color.FromArgb(_BGModels["Run"].BackColor.ToArgb());
            label_setup.BackColor = Color.FromArgb(_BGModels["Setup"].BackColor.ToArgb());
            label_idle.BackColor = Color.FromArgb(_BGModels["Idle"].BackColor.ToArgb());

            doShowGanttChart(true, true);
        }

        #endregion
    }
}
