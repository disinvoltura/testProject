﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace VMS.IFS.UI
{
    public partial class LineColumnSumPerHoursChart : UserControl
    {
        #region Member Variable

        private DataTable dtMaster;
        private DataTable dtShow;

        private DateTime simulationStartTime;
        private int startTimeBucket;
        private int endTimeBucket;
        private int timeBucketHours;

        private string lineKeyword;
        private string columnKeyword;
        
        private List<string> yValues;        
        private List<string> selectedYValues;

        #endregion

        #region Constructor

        public LineColumnSumPerHoursChart(DataTable dt, string line, string column, DateTime start, int tb)
        {
            InitializeComponent();

            this.dtMaster = dt;
            DataTable dtCopy = dtMaster.Copy();
            this.dtShow = dtCopy;

            lineKeyword = line;
            columnKeyword = column;

            simulationStartTime = start;
            timeBucketHours = tb;

            startTimeBucket = 1;
            endTimeBucket = (dt.Rows.Count - 1) / timeBucketHours + 1;

            yValues = new List<string>();
            selectedYValues = new List<string>();

            foreach (DataColumn dc in dtMaster.Columns)
            {
                if (dc.ColumnName == "Time")
                    continue;

                string name = dc.ColumnName.Remove(dc.ColumnName.Length - 4, 4);
                if(!yValues.Contains(name))
                {
                    yValues.Add(name);
                    selectedYValues.Add(name);
                }
            }

            //Print();
        }

        #endregion

        #region Print Method

        private void Print()
        {
            chart.DataSource = dtShow;
            chart.Series.Clear();

            foreach (DataColumn dc in dtShow.Columns)
            {
                if (dc.ColumnName != "Time")
                {
                    if (dc.ColumnName.Contains(columnKeyword))
                    {
                        Series s = new Series();
                        s.Name = dc.ColumnName;
                        s.ChartType = SeriesChartType.Column;
                        s.BorderWidth = 5;
                        s.XValueMember = "Time";
                        s.YValueMembers = dc.ColumnName;
                        if (cb_Value.Checked)
                            s.IsValueShownAsLabel = true;
                        else
                            s.IsValueShownAsLabel = false;
                        chart.Series.Add(s);                        
                    }
                    else if (dc.ColumnName.Contains(lineKeyword))
                    {
                        Series s = new Series();
                        s.Name = dc.ColumnName;
                        s.ChartType = SeriesChartType.Line;
                        s.BorderWidth = 5;
                        s.XValueMember = "Time";
                        s.YValueMembers = dc.ColumnName;
                        if (cb_Value.Checked)
                            s.IsValueShownAsLabel = true;
                        else
                            s.IsValueShownAsLabel = false;
                        chart.Series.Add(s);
                    }
                }
            }
            chart.ChartAreas[0].AxisX.Interval = 1;
            //chart.ChartAreas[0].AxisX.LabelStyle.Angle = -90;
            chart.DataBind();
            
        }

        #endregion

        #region Chart Edit Method

        private DataTable EditChart()
        {
            DataTable dt = new DataTable();

            dt.Columns.Add("Time");
            dt.Columns.Add(columnKeyword);
            dt.Columns.Add(lineKeyword);            

            DateTime start = simulationStartTime.AddHours((startTimeBucket - 1) * timeBucketHours);
            DateTime end = simulationStartTime.AddHours(endTimeBucket * timeBucketHours);

            DateTime before = new DateTime();

            foreach (DataRow dr in dtMaster.Rows)
            {
                DateTime drDT = DateTime.Parse(dr["Time"].ToString());
                if (drDT >= start && drDT <= end)
                {
                    DataRow row = dt.NewRow();
                    if (before.Date == drDT.Date)
                    {
                        row["Time"] = drDT.ToShortTimeString();
                    }
                    else
                    {
                        row["Time"] = drDT.ToShortDateString() + " " + drDT.ToShortTimeString();
                    }
                    before = new DateTime(drDT.Year, drDT.Month, drDT.Day);

                    //To-Be changed
                    double lineValue = 0;
                    double columnValue = 0;
                    foreach (string str in selectedYValues)
                    {
                        columnValue += double.Parse(dr[str + "." + columnKeyword].ToString());
                        lineValue += double.Parse(dr[str + "." + lineKeyword].ToString());                        
                    }
                    row[columnKeyword] = columnValue;
                    row[lineKeyword] = lineValue;                    
                    dt.Rows.Add(row);
                }                               
            }

            return dt;
        }

        #endregion 

        private void tsBtn_ChartEdit_Click(object sender, EventArgs e)
        {
            SOTimeSeriesChartFormatEditor cfe = new SOTimeSeriesChartFormatEditor(startTimeBucket.ToString(), endTimeBucket.ToString(), selectedYValues, yValues);

            switch (cfe.ShowDialog())
            {
                case DialogResult.OK:
                    {
                        startTimeBucket = int.Parse(cfe.selectedStart);
                        endTimeBucket = int.Parse(cfe.selectedEnd);
                        selectedYValues = cfe.selectedYValues;

                        dtShow = EditChart();
                        Print();

                        break;
                    }
            }
        }

        private void cb_Value_CheckedChanged(object sender, EventArgs e)
        {
            if (cb_Value.Checked)
            {
                foreach (Series s in chart.Series)
                {
                    s.IsValueShownAsLabel = true;
                }
            }
            else
            {
                foreach (Series s in chart.Series)
                {
                    s.IsValueShownAsLabel = false;
                }
            }                
        }
    }
}