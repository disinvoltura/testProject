﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;

namespace VMS.IFS.UI
{
    public class OutputChartData
    {
        #region Member variables

        private ChartTable _CTParent;
        private DataTable _DT;
        private string _ChartType;
        private List<string> _XList;
        private List<string> _YList;

        #endregion

        #region Constructors

        public OutputChartData(ChartTable ct, DataTable dt, string chartType, List<string> x, List<string> y)
        {
            _CTParent = ct;
            _DT = dt;
            _ChartType = chartType;
            _XList = x;
            _YList = y;           
        }

        #endregion

        #region Methods

        public void BuildChart()
        {
            UserControl uc = new UserControl();
            
            if (_ChartType == "Line")
            {
                uc = new SOTimeSeriesChart(_DT);
                uc.Parent = _CTParent.splitContainer1.Panel1;
                uc.Dock = DockStyle.Fill;
                uc.Show();
            }
            else if (_ChartType == "Column")
            {
                uc = new SOAttributeChart(_DT, _XList, _YList);
                uc.Parent = _CTParent.splitContainer1.Panel1;
                uc.Dock = DockStyle.Fill;
                uc.Show();
            }
            else if (_ChartType == "StackedColumn")
            {
                uc = new SORatioChart(_DT, _XList);
                uc.Parent = _CTParent.splitContainer1.Panel1;
                uc.Dock = DockStyle.Fill;
                uc.Show();
            }
            else if (_ChartType == "Gantt")
            {
                GanttChartData gcData = new GanttChartData();
                                              
                foreach (DataRow dr in _DT.Rows)
                {
                    DateTime startTime = (DateTime)dr["StartTime"];                    
                    DateTime endTime = (DateTime)dr["EndTime"];
                    
                    gcData.AddBar(dr["EQPID"].ToString(),
                        startTime,
                        endTime,
                        dr["Category"].ToString(),
                        "");
                }

                gcData.AddCategory("Run", "Gold");
                gcData.AddCategory("Setup", "Red");
                gcData.AddCategory("Idle", "White");

                GanttChartControl gc = new GanttChartControl();
                gc.DefaultWidth = 2;
                gc.LoadGanttChartData(gcData, true, true);
                gc.Parent = _CTParent.splitContainer1.Panel1;
                gc.Dock = DockStyle.Fill;
                gc.Show();
            }
            else if (_ChartType == "Line-Column")
            {
                uc = new LineColumnSumPerHoursChart(_DT, "Out", "WIP", (DateTime)_CTParent.RunOptions["RefDateTime"], (int)_CTParent.RunOptions["UnitTime"]);
                uc.Parent = _CTParent.splitContainer1.Panel1;
                uc.Dock = DockStyle.Fill;
                uc.Show();
            }
        }

        #endregion
    }
}
