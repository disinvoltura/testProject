﻿namespace VMS.IFS.UI
{
    partial class SOTable
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SOTable));
            this.panel1 = new System.Windows.Forms.Panel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsBtn_TableEdit = new System.Windows.Forms.ToolStripButton();
            this.tsBtn_TableReset = new System.Windows.Forms.ToolStripButton();
            this.datagrid = new SourceGrid.DataGrid();
            this.panel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.toolStrip1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(719, 28);
            this.panel1.TabIndex = 0;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStrip1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBtn_TableEdit,
            this.tsBtn_TableReset});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(715, 24);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsBtn_TableEdit
            // 
            this.tsBtn_TableEdit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsBtn_TableEdit.Image = ((System.Drawing.Image)(resources.GetObject("tsBtn_TableEdit.Image")));
            this.tsBtn_TableEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsBtn_TableEdit.Name = "tsBtn_TableEdit";
            this.tsBtn_TableEdit.Size = new System.Drawing.Size(23, 21);
            this.tsBtn_TableEdit.Text = "Table Edit";
            this.tsBtn_TableEdit.Click += new System.EventHandler(this.tsBtn_TableEdit_Click);
            // 
            // tsBtn_TableReset
            // 
            this.tsBtn_TableReset.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsBtn_TableReset.Image = ((System.Drawing.Image)(resources.GetObject("tsBtn_TableReset.Image")));
            this.tsBtn_TableReset.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsBtn_TableReset.Name = "tsBtn_TableReset";
            this.tsBtn_TableReset.Size = new System.Drawing.Size(23, 21);
            this.tsBtn_TableReset.Text = "Table Reset";
            this.tsBtn_TableReset.Click += new System.EventHandler(this.tsBtn_TableReset_Click);
            // 
            // datagrid
            // 
            this.datagrid.DeleteQuestionMessage = "Are you sure to delete all the selected rows?";
            this.datagrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datagrid.EnableSort = false;
            this.datagrid.FixedRows = 1;
            this.datagrid.Location = new System.Drawing.Point(0, 28);
            this.datagrid.Name = "datagrid";
            this.datagrid.SelectionMode = SourceGrid.GridSelectionMode.Row;
            this.datagrid.Size = new System.Drawing.Size(719, 368);
            this.datagrid.TabIndex = 1;
            this.datagrid.TabStop = true;
            this.datagrid.ToolTipText = "";
            // 
            // SOTable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.datagrid);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "SOTable";
            this.Size = new System.Drawing.Size(719, 396);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsBtn_TableEdit;
        private System.Windows.Forms.ToolStripButton tsBtn_TableReset;
        private SourceGrid.DataGrid datagrid;
    }
}
