﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VMS.IFS.UI
{
    public partial class SOTableFormatEditor : Form
    {        
        public List<string> selected;
        public List<string> unselected;

        public SOTableFormatEditor(List<string> selected, List<string> unselected)
        {
            InitializeComponent();
            
            this.selected = selected;
            this.unselected = unselected;

            Print();
        }

        #region Print Method

        private void Print()
        {
            lv_Selected.Clear();
            lv_Unselected.Clear();
            foreach (string str in selected)
            {
                lv_Selected.Items.Add(str);
            }
            foreach (string str in unselected)
            {
                lv_Unselected.Items.Add(str);
            }
        }

        #endregion

        #region Button Handling

        private void btn_Select_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lv_Unselected.SelectedItems.Count; i++)
            {
                string strUnselected = lv_Unselected.SelectedItems[i].Text;
                unselected.Remove(strUnselected);
                selected.Add(strUnselected);
            }

            Print();
        }

        private void btn_Unselect_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lv_Selected.SelectedItems.Count; i++)
            {
                string strSelected = lv_Selected.SelectedItems[i].Text;
                selected.Remove(strSelected);
                unselected.Add(strSelected);
            }

            Print();
        }

        private void btn_Up_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lv_Selected.SelectedItems.Count; i++)
            {
                int index = lv_Selected.SelectedItems[i].Index;
                if (index != 0)
                {
                    string temp = lv_Selected.Items[index - 1].Text;
                    lv_Selected.Items[index - 1].Text = lv_Selected.Items[index].Text;
                    lv_Selected.Items[index].Text = temp;
                }
            }

            selected = new List<string>();
            foreach (ListViewItem item in lv_Selected.Items)
            {
                selected.Add(item.Text);
            }
        }

        private void btn_Down_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lv_Selected.SelectedItems.Count; i++)
            {
                int index = lv_Selected.SelectedItems[i].Index;
                if (index != lv_Selected.Items.Count - 1)
                {
                    string temp = lv_Selected.Items[index + 1].Text;
                    lv_Selected.Items[index + 1].Text = lv_Selected.Items[index].Text;
                    lv_Selected.Items[index].Text = temp;
                }
            }

            selected = new List<string>();
            foreach (ListViewItem item in lv_Selected.Items)
            {
                selected.Add(item.Text);
            }
        }
        
        private void btn_OK_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;

            this.Close();
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion                
    }
}
