﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VMS.IFS.UI
{
    public partial class GanttChartFormatEditor : Form
    {
        #region Member Variables

        private int _RunColor;
        private int _SetupColor;
        private int _IdleColor;
        private List<string> _Members;
        private List<string> _SelectedMembers;
        private DateTime _FromTotal;
        private DateTime _ToTotal;
        private DateTime _From;
        private DateTime _To;
        private bool _Range;

        #endregion

        #region Property

        public int RunColor
        {
            get { return _RunColor; }
        }

        public int SetupColor
        {
            get { return _SetupColor; }
        }

        public int IdleColor
        {
            get { return _IdleColor; }
        }

        public List<string> SelectedMembers
        {
            get { return _SelectedMembers; }
        }

        public DateTime From
        {
            get { return _From; }
        }

        public DateTime To
        {
            get { return _To; }
        }

        public bool Range
        {
            get { return _Range; }
        }

        #endregion

        public GanttChartFormatEditor(bool range, DateTime fromT, DateTime toT, DateTime fromS, DateTime toS, List<string> members, List<string> selectedMembers, int run, int setup, int idle)
        {
            InitializeComponent();
            _Members = members;
            _SelectedMembers = selectedMembers;
            _RunColor = run;
            _SetupColor = setup;
            _IdleColor = idle;

            if (range)
            {
                radioButton1.Checked = false;
                radioButton2.Checked = true;
            }
            else
            {
                radioButton1.Checked = true;
                radioButton2.Checked = false;
            }
            label_FromT.Text = "Start: " + fromT.ToString("yyyy-MM-dd HH:mm");
            label_ToT.Text = "End: " + toT.ToString("yyyy-MM-dd HH:mm");
            dtp_From.Value = fromS;
            dtp_To.Value = toS;
            dtp_From.CustomFormat = "yyyy-MM-dd HH:mm";
            dtp_To.CustomFormat = "yyyy-MM-dd HH:mm";

            _FromTotal = fromT;
            _ToTotal = toT;
            _From = fromS;
            _To = toS;

            grid.ColumnsCount = 2;
            grid.FixedRows = 1;
            grid.Rows.Insert(0);

            grid[0, 0] = new SourceGrid.Cells.ColumnHeader("Select");
            grid[0, 1] = new SourceGrid.Cells.ColumnHeader("Member Name");

            int i = 1;
            bool selectAll = true;
            foreach (string str in _Members)
            {
                grid.Rows.Insert(i);
                if (_SelectedMembers.Contains(str))
                {
                    grid[i, 0] = new SourceGrid.Cells.CheckBox(null, true);
                }
                else
                {
                    grid[i, 0] = new SourceGrid.Cells.CheckBox(null, false);
                    selectAll = false;
                }
                grid[i, 1] = new SourceGrid.Cells.Cell(str);
                i++;
            }

            if (selectAll)
                cb_All.Checked = true;

            grid.Columns.AutoSize(true);

            label_run.BackColor = Color.FromArgb(_RunColor);
            label_setup.BackColor = Color.FromArgb(_SetupColor);
            label_idle.BackColor = Color.FromArgb(_IdleColor);
        }

        private void btn_OK_Click(object sender, EventArgs e)
        {
            _SelectedMembers = new List<string>();
            for (int i = 1; i < grid.Rows.Count; i++)
            {
                if ((bool)grid[i, 0].Value)
                {
                    _SelectedMembers.Add(grid[i, 1].Value.ToString());
                }
            }

            if (radioButton1.Checked)
            {
                _Range = false;
                _From = _FromTotal;
                _To = _ToTotal;
            }
            else if (radioButton2.Checked)
            {
                _Range = true;
                _From = dtp_From.Value;
                _To = dtp_To.Value;
            }
            
            this.DialogResult = System.Windows.Forms.DialogResult.OK;

            this.Close();
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult rslt = colorDialog1.ShowDialog();

            if (rslt == System.Windows.Forms.DialogResult.OK)
            {
                _RunColor = colorDialog1.Color.ToArgb();
                label_run.BackColor = Color.FromArgb(_RunColor);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult rslt = colorDialog1.ShowDialog();

            if (rslt == System.Windows.Forms.DialogResult.OK)
            {
                _SetupColor = colorDialog1.Color.ToArgb();
                label_setup.BackColor = Color.FromArgb(_SetupColor);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult rslt = colorDialog1.ShowDialog();

            if (rslt == System.Windows.Forms.DialogResult.OK)
            {
                _IdleColor = colorDialog1.Color.ToArgb();
                label_idle.BackColor = Color.FromArgb(_IdleColor);
            }
        }

        private void cb_All_CheckedChanged(object sender, EventArgs e)
        {
            if (cb_All.Checked == true)
            {
                for (int i = 1; i < grid.Rows.Count; i++)
                {
                    grid[i, 0].Value = true;
                }
            }
            else
            {
                for (int i = 1; i < grid.Rows.Count; i++)
                {
                    grid[i, 0].Value = false;
                }
            }
        }
    }
}
