﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace VMS.IFS.UI
{
    public partial class SOTimeSeriesChart : UserControl
    {
        #region Member Variable
        
        private DataTable dtMaster;
        private DataTable dtShow;

        private string start;
        private string end;
        private List<string> yValues;
        private List<string> selectedYValues;

        #endregion

        #region Constructor

        public SOTimeSeriesChart(DataTable dt)
        {
            InitializeComponent();

            this.dtMaster = dt;
            DataTable dtCopy = dtMaster.Copy();
            this.dtShow = dtCopy;

            yValues = new List<string>();
            selectedYValues = new List<string>();
            
            start = dtMaster.Rows[0]["Time Bucket"].ToString();
            end = dtMaster.Rows[dtMaster.Rows.Count - 1]["Time Bucket"].ToString();
            foreach (DataColumn dc in dtMaster.Columns)
            {
                if (dc.ColumnName != "Time Bucket")
                {
                    yValues.Add(dc.ColumnName);
                    selectedYValues.Add(dc.ColumnName);
                }
            }

            Print();
        }

        #endregion

        #region Print Method

        private void Print()
        {
            chart.DataSource = dtShow;
            chart.Series.Clear();

            foreach (DataColumn dc in dtShow.Columns)
            {
                if (dc.ColumnName != "Time Bucket")
                {
                    Series s = new Series();
                    s.Name = dc.ColumnName;
                    s.ChartType = SeriesChartType.Line;                    
                    s.BorderWidth = 5;
                    s.XValueMember = "Time Bucket";
                    s.YValueMembers = dc.ColumnName;
                    chart.Series.Add(s);
                }
            }

            chart.DataBind();
        }

        #endregion

        #region Chart Edit Method

        private DataTable EditChart()
        {
            DataTable dt = new DataTable();

            dt.Columns.Add("Time Bucket");
            foreach (string str in selectedYValues)
            {
                dt.Columns.Add(str);
            }
            foreach (DataRow dr in dtMaster.Rows)
            {
                if (int.Parse(dr["Time Bucket"].ToString()) >= int.Parse(start) && int.Parse(dr["Time Bucket"].ToString()) <= int.Parse(end))
                {
                    DataRow row = dt.NewRow();

                    row["Time Bucket"] = dr["Time Bucket"].ToString();

                    foreach (string str in selectedYValues)
                    {
                        row[str] = dr[str].ToString();
                    }
                    dt.Rows.Add(row);
                }
            }

            return dt;
        }

        #endregion        

        #region Tool Strip Button Handling

        private void tsBtn_ChartEdit_Click(object sender, EventArgs e)
        {
            SOTimeSeriesChartFormatEditor cfe = new SOTimeSeriesChartFormatEditor(start, end, selectedYValues, yValues);

            switch (cfe.ShowDialog())
            {
                case DialogResult.OK:
                    {                        
                        start = cfe.selectedStart;
                        end = cfe.selectedEnd;
                        selectedYValues = cfe.selectedYValues;

                        dtShow = EditChart();
                        Print();

                        break;
                    }
            }
        }

        private void tsBtn_ChartReset_Click(object sender, EventArgs e)
        {
            DataTable dtCopy = dtMaster.Copy();
            dtShow = dtCopy;

            yValues = new List<string>();
            selectedYValues = new List<string>();

            start = dtMaster.Rows[0]["Time Bucket"].ToString();
            end = dtMaster.Rows[dtMaster.Rows.Count - 1]["Time Bucket"].ToString();
            foreach (DataColumn dc in dtMaster.Columns)
            {
                if (dc.ColumnName != "Time Bucket")
                {
                    yValues.Add(dc.ColumnName);
                    selectedYValues.Add(dc.ColumnName);
                }
            }

            Print();
        }

        #endregion
    }
}
