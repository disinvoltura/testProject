﻿namespace VMS.IFS.UI
{
    partial class SingleOutputViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Fab In/Out");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Product In/Out");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Product TAT");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Product-Step TAT");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Due Date Satisfaction");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Processing Step WIP");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Processing Step Output");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("EQP Utilization");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("EQP Output");
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Fab WIP");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Release Plan");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("EQP Gantt Chart");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Release Batch Gantt Chart");
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Simulation Output", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4,
            treeNode5,
            treeNode6,
            treeNode7,
            treeNode8,
            treeNode9,
            treeNode10,
            treeNode11,
            treeNode12,
            treeNode13});
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tp_FIO = new System.Windows.Forms.TabPage();
            this.tp_PIO = new System.Windows.Forms.TabPage();
            this.tp_PTAT = new System.Windows.Forms.TabPage();
            this.tp_PStepTAT = new System.Windows.Forms.TabPage();
            this.tp_DDS = new System.Windows.Forms.TabPage();
            this.tp_StepWIP = new System.Windows.Forms.TabPage();
            this.tp_StepOut = new System.Windows.Forms.TabPage();
            this.tp_EQPUtil = new System.Windows.Forms.TabPage();
            this.tp_EQPOut = new System.Windows.Forms.TabPage();
            this.tp_RBGantt = new System.Windows.Forms.TabPage();
            this.tp_EQPGantt = new System.Windows.Forms.TabPage();
            this.tp_FabWIP = new System.Windows.Forms.TabPage();
            this.tp_RPlan = new System.Windows.Forms.TabPage();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.treeView1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tabControl1);
            this.splitContainer1.Size = new System.Drawing.Size(1184, 662);
            this.splitContainer1.SplitterDistance = 289;
            this.splitContainer1.TabIndex = 0;
            // 
            // treeView1
            // 
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.treeView1.Location = new System.Drawing.Point(0, 0);
            this.treeView1.Name = "treeView1";
            treeNode1.Name = "Node_0_0";
            treeNode1.Text = "Fab In/Out";
            treeNode2.Name = "Node_0_1";
            treeNode2.Text = "Product In/Out";
            treeNode3.Name = "Node_0_10";
            treeNode3.Text = "Product TAT";
            treeNode4.Name = "Node_0_2";
            treeNode4.Text = "Product-Step TAT";
            treeNode5.Name = "Node_0_3";
            treeNode5.Text = "Due Date Satisfaction";
            treeNode6.Name = "Node_0_4";
            treeNode6.Text = "Processing Step WIP";
            treeNode7.Name = "Node_0_5";
            treeNode7.Text = "Processing Step Output";
            treeNode8.Name = "Node_0_6";
            treeNode8.Text = "EQP Utilization";
            treeNode9.Name = "Node_0_7";
            treeNode9.Text = "EQP Output";
            treeNode10.Name = "Node3";
            treeNode10.Text = "Fab WIP";
            treeNode11.Name = "Node0";
            treeNode11.Text = "Release Plan";
            treeNode12.Name = "Node_0_9";
            treeNode12.Text = "EQP Gantt Chart";
            treeNode13.Name = "Node_0_8";
            treeNode13.Text = "Release Batch Gantt Chart";
            treeNode14.Name = "Node_0";
            treeNode14.Text = "Simulation Output";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode14});
            this.treeView1.Size = new System.Drawing.Size(285, 658);
            this.treeView1.TabIndex = 0;
            this.treeView1.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeView1_NodeMouseDoubleClick);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tp_FIO);
            this.tabControl1.Controls.Add(this.tp_PIO);
            this.tabControl1.Controls.Add(this.tp_PTAT);
            this.tabControl1.Controls.Add(this.tp_PStepTAT);
            this.tabControl1.Controls.Add(this.tp_DDS);
            this.tabControl1.Controls.Add(this.tp_StepWIP);
            this.tabControl1.Controls.Add(this.tp_StepOut);
            this.tabControl1.Controls.Add(this.tp_EQPUtil);
            this.tabControl1.Controls.Add(this.tp_EQPOut);
            this.tabControl1.Controls.Add(this.tp_RBGantt);
            this.tabControl1.Controls.Add(this.tp_EQPGantt);
            this.tabControl1.Controls.Add(this.tp_FabWIP);
            this.tabControl1.Controls.Add(this.tp_RPlan);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(887, 658);
            this.tabControl1.TabIndex = 0;
            // 
            // tp_FIO
            // 
            this.tp_FIO.Location = new System.Drawing.Point(4, 28);
            this.tp_FIO.Name = "tp_FIO";
            this.tp_FIO.Padding = new System.Windows.Forms.Padding(3);
            this.tp_FIO.Size = new System.Drawing.Size(879, 626);
            this.tp_FIO.TabIndex = 0;
            this.tp_FIO.Text = "Fab In/Out";
            this.tp_FIO.UseVisualStyleBackColor = true;
            // 
            // tp_PIO
            // 
            this.tp_PIO.Location = new System.Drawing.Point(4, 28);
            this.tp_PIO.Name = "tp_PIO";
            this.tp_PIO.Padding = new System.Windows.Forms.Padding(3);
            this.tp_PIO.Size = new System.Drawing.Size(879, 626);
            this.tp_PIO.TabIndex = 1;
            this.tp_PIO.Text = "Product In/Out";
            this.tp_PIO.UseVisualStyleBackColor = true;
            // 
            // tp_PTAT
            // 
            this.tp_PTAT.Location = new System.Drawing.Point(4, 28);
            this.tp_PTAT.Name = "tp_PTAT";
            this.tp_PTAT.Size = new System.Drawing.Size(879, 626);
            this.tp_PTAT.TabIndex = 2;
            this.tp_PTAT.Text = "Product TAT";
            this.tp_PTAT.UseVisualStyleBackColor = true;
            // 
            // tp_PStepTAT
            // 
            this.tp_PStepTAT.Location = new System.Drawing.Point(4, 28);
            this.tp_PStepTAT.Name = "tp_PStepTAT";
            this.tp_PStepTAT.Size = new System.Drawing.Size(879, 626);
            this.tp_PStepTAT.TabIndex = 10;
            this.tp_PStepTAT.Text = "Product-Step TAT";
            this.tp_PStepTAT.UseVisualStyleBackColor = true;
            // 
            // tp_DDS
            // 
            this.tp_DDS.Location = new System.Drawing.Point(4, 28);
            this.tp_DDS.Name = "tp_DDS";
            this.tp_DDS.Size = new System.Drawing.Size(879, 626);
            this.tp_DDS.TabIndex = 3;
            this.tp_DDS.Text = "Due Date Satisfaction";
            this.tp_DDS.UseVisualStyleBackColor = true;
            // 
            // tp_StepWIP
            // 
            this.tp_StepWIP.Location = new System.Drawing.Point(4, 28);
            this.tp_StepWIP.Name = "tp_StepWIP";
            this.tp_StepWIP.Size = new System.Drawing.Size(879, 626);
            this.tp_StepWIP.TabIndex = 4;
            this.tp_StepWIP.Text = "Processing Step WIP";
            this.tp_StepWIP.UseVisualStyleBackColor = true;
            // 
            // tp_StepOut
            // 
            this.tp_StepOut.Location = new System.Drawing.Point(4, 28);
            this.tp_StepOut.Name = "tp_StepOut";
            this.tp_StepOut.Size = new System.Drawing.Size(879, 626);
            this.tp_StepOut.TabIndex = 5;
            this.tp_StepOut.Text = "Processing Step Output";
            this.tp_StepOut.UseVisualStyleBackColor = true;
            // 
            // tp_EQPUtil
            // 
            this.tp_EQPUtil.Location = new System.Drawing.Point(4, 28);
            this.tp_EQPUtil.Name = "tp_EQPUtil";
            this.tp_EQPUtil.Size = new System.Drawing.Size(879, 626);
            this.tp_EQPUtil.TabIndex = 6;
            this.tp_EQPUtil.Text = "EQP Utilization";
            this.tp_EQPUtil.UseVisualStyleBackColor = true;
            // 
            // tp_EQPOut
            // 
            this.tp_EQPOut.Location = new System.Drawing.Point(4, 28);
            this.tp_EQPOut.Name = "tp_EQPOut";
            this.tp_EQPOut.Size = new System.Drawing.Size(879, 626);
            this.tp_EQPOut.TabIndex = 7;
            this.tp_EQPOut.Text = "EQP Output";
            this.tp_EQPOut.UseVisualStyleBackColor = true;
            // 
            // tp_RBGantt
            // 
            this.tp_RBGantt.Location = new System.Drawing.Point(4, 28);
            this.tp_RBGantt.Name = "tp_RBGantt";
            this.tp_RBGantt.Size = new System.Drawing.Size(879, 626);
            this.tp_RBGantt.TabIndex = 8;
            this.tp_RBGantt.Text = "Release Batch Gantt Chart";
            this.tp_RBGantt.UseVisualStyleBackColor = true;
            // 
            // tp_EQPGantt
            // 
            this.tp_EQPGantt.Location = new System.Drawing.Point(4, 28);
            this.tp_EQPGantt.Name = "tp_EQPGantt";
            this.tp_EQPGantt.Size = new System.Drawing.Size(879, 626);
            this.tp_EQPGantt.TabIndex = 9;
            this.tp_EQPGantt.Text = "EQP Gantt Chart";
            this.tp_EQPGantt.UseVisualStyleBackColor = true;
            // 
            // tp_FabWIP
            // 
            this.tp_FabWIP.Location = new System.Drawing.Point(4, 28);
            this.tp_FabWIP.Name = "tp_FabWIP";
            this.tp_FabWIP.Size = new System.Drawing.Size(879, 626);
            this.tp_FabWIP.TabIndex = 11;
            this.tp_FabWIP.Text = "Fab WIP";
            this.tp_FabWIP.UseVisualStyleBackColor = true;
            // 
            // tp_RPlan
            // 
            this.tp_RPlan.Location = new System.Drawing.Point(4, 28);
            this.tp_RPlan.Name = "tp_RPlan";
            this.tp_RPlan.Size = new System.Drawing.Size(879, 626);
            this.tp_RPlan.TabIndex = 12;
            this.tp_RPlan.Text = "Release Plan";
            this.tp_RPlan.UseVisualStyleBackColor = true;
            // 
            // SingleOutputViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 662);
            this.Controls.Add(this.splitContainer1);
            this.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "SingleOutputViewer";
            this.Text = "Single Simulation Output Viewer";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tp_FIO;
        private System.Windows.Forms.TabPage tp_PIO;
        private System.Windows.Forms.TabPage tp_PTAT;
        private System.Windows.Forms.TabPage tp_DDS;
        private System.Windows.Forms.TabPage tp_StepWIP;
        private System.Windows.Forms.TabPage tp_StepOut;
        private System.Windows.Forms.TabPage tp_EQPUtil;
        private System.Windows.Forms.TabPage tp_EQPOut;
        private System.Windows.Forms.TabPage tp_RBGantt;
        private System.Windows.Forms.TabPage tp_EQPGantt;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.TabPage tp_PStepTAT;
        private System.Windows.Forms.TabPage tp_FabWIP;
        private System.Windows.Forms.TabPage tp_RPlan;
    }
}