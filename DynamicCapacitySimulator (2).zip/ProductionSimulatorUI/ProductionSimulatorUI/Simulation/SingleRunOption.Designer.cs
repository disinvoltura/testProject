﻿namespace VMS.IFS.UI
{
    partial class SingleRunOption
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbTimeUnit = new System.Windows.Forms.ComboBox();
            this.rb_End = new System.Windows.Forms.RadioButton();
            this.tb_EOSTime = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.rb_EOSTime = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.btnSelectJSR = new System.Windows.Forms.Button();
            this.txtJSR = new System.Windows.Forms.TextBox();
            this.gJSRParams = new SourceGrid.Grid();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.btnSelectMSR = new System.Windows.Forms.Button();
            this.txtMSR = new System.Windows.Forms.TextBox();
            this.gMSRParams = new SourceGrid.Grid();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_OK = new System.Windows.Forms.Button();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cb_LoadableSet = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.tb_SaveWIP = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_Shift = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.cbSteps = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtTSK = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtFWK = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.btn_OKRun = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbTimeUnit);
            this.groupBox1.Controls.Add(this.rb_End);
            this.groupBox1.Controls.Add(this.tb_EOSTime);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.rb_EOSTime);
            this.groupBox1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(11, 11);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.groupBox1.Size = new System.Drawing.Size(265, 125);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "End of Simulation";
            // 
            // cbTimeUnit
            // 
            this.cbTimeUnit.FormattingEnabled = true;
            this.cbTimeUnit.Items.AddRange(new object[] {
            "Days",
            "Hours",
            "Minutes",
            "Seconds"});
            this.cbTimeUnit.Location = new System.Drawing.Point(175, 51);
            this.cbTimeUnit.Name = "cbTimeUnit";
            this.cbTimeUnit.Size = new System.Drawing.Size(81, 27);
            this.cbTimeUnit.TabIndex = 6;
            this.cbTimeUnit.Text = "Hours";
            // 
            // rb_End
            // 
            this.rb_End.AutoSize = true;
            this.rb_End.Enabled = false;
            this.rb_End.Location = new System.Drawing.Point(15, 83);
            this.rb_End.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.rb_End.Name = "rb_End";
            this.rb_End.Size = new System.Drawing.Size(239, 23);
            this.rb_End.TabIndex = 4;
            this.rb_End.TabStop = true;
            this.rb_End.Text = "Stop at the End of Release Batch";
            this.rb_End.UseVisualStyleBackColor = true;
            this.rb_End.CheckedChanged += new System.EventHandler(this.rb_End_CheckedChanged);
            // 
            // tb_EOSTime
            // 
            this.tb_EOSTime.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_EOSTime.Location = new System.Drawing.Point(85, 51);
            this.tb_EOSTime.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.tb_EOSTime.Name = "tb_EOSTime";
            this.tb_EOSTime.Size = new System.Drawing.Size(84, 27);
            this.tb_EOSTime.TabIndex = 3;
            this.tb_EOSTime.Text = "168";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(30, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "Time: ";
            // 
            // rb_EOSTime
            // 
            this.rb_EOSTime.AutoSize = true;
            this.rb_EOSTime.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_EOSTime.Location = new System.Drawing.Point(15, 21);
            this.rb_EOSTime.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.rb_EOSTime.Name = "rb_EOSTime";
            this.rb_EOSTime.Size = new System.Drawing.Size(108, 23);
            this.rb_EOSTime.TabIndex = 0;
            this.rb_EOSTime.TabStop = true;
            this.rb_EOSTime.Text = "Stop at Time";
            this.rb_EOSTime.UseVisualStyleBackColor = true;
            this.rb_EOSTime.CheckedChanged += new System.EventHandler(this.rb_EOSTime_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tabControl1);
            this.groupBox2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 248);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.groupBox2.Size = new System.Drawing.Size(647, 211);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Dispatching Rule";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(14, 29);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(622, 167);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.btnSelectJSR);
            this.tabPage1.Controls.Add(this.txtJSR);
            this.tabPage1.Controls.Add(this.gJSRParams);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.tabPage1.Size = new System.Drawing.Size(614, 135);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Job Selection Rule";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(11, 53);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 19);
            this.label9.TabIndex = 10;
            this.label9.Text = "Weights:";
            // 
            // btnSelectJSR
            // 
            this.btnSelectJSR.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectJSR.Location = new System.Drawing.Point(346, 16);
            this.btnSelectJSR.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.btnSelectJSR.Name = "btnSelectJSR";
            this.btnSelectJSR.Size = new System.Drawing.Size(86, 27);
            this.btnSelectJSR.TabIndex = 9;
            this.btnSelectJSR.Text = "Select...";
            this.btnSelectJSR.UseVisualStyleBackColor = true;
            this.btnSelectJSR.Click += new System.EventHandler(this.btnSelectJSR_Click);
            // 
            // txtJSR
            // 
            this.txtJSR.Location = new System.Drawing.Point(96, 16);
            this.txtJSR.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.txtJSR.Name = "txtJSR";
            this.txtJSR.ReadOnly = true;
            this.txtJSR.Size = new System.Drawing.Size(227, 27);
            this.txtJSR.TabIndex = 3;
            // 
            // gJSRParams
            // 
            this.gJSRParams.EnableSort = true;
            this.gJSRParams.Location = new System.Drawing.Point(96, 53);
            this.gJSRParams.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.gJSRParams.Name = "gJSRParams";
            this.gJSRParams.OptimizeMode = SourceGrid.CellOptimizeMode.ForRows;
            this.gJSRParams.SelectionMode = SourceGrid.GridSelectionMode.Cell;
            this.gJSRParams.Size = new System.Drawing.Size(335, 68);
            this.gJSRParams.TabIndex = 0;
            this.gJSRParams.TabStop = true;
            this.gJSRParams.ToolTipText = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 19);
            this.label4.TabIndex = 2;
            this.label4.Text = "Name:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.btnSelectMSR);
            this.tabPage2.Controls.Add(this.txtMSR);
            this.tabPage2.Controls.Add(this.gMSRParams);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.tabPage2.Size = new System.Drawing.Size(614, 135);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Machine Selection Rule";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 54);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 19);
            this.label8.TabIndex = 9;
            this.label8.Text = "Weights:";
            // 
            // btnSelectMSR
            // 
            this.btnSelectMSR.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectMSR.Location = new System.Drawing.Point(346, 17);
            this.btnSelectMSR.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.btnSelectMSR.Name = "btnSelectMSR";
            this.btnSelectMSR.Size = new System.Drawing.Size(86, 27);
            this.btnSelectMSR.TabIndex = 8;
            this.btnSelectMSR.Text = "Select...";
            this.btnSelectMSR.UseVisualStyleBackColor = true;
            this.btnSelectMSR.Click += new System.EventHandler(this.btnSelectMSR_Click);
            // 
            // txtMSR
            // 
            this.txtMSR.Location = new System.Drawing.Point(98, 17);
            this.txtMSR.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.txtMSR.Name = "txtMSR";
            this.txtMSR.ReadOnly = true;
            this.txtMSR.Size = new System.Drawing.Size(226, 27);
            this.txtMSR.TabIndex = 6;
            // 
            // gMSRParams
            // 
            this.gMSRParams.EnableSort = true;
            this.gMSRParams.Location = new System.Drawing.Point(98, 54);
            this.gMSRParams.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.gMSRParams.Name = "gMSRParams";
            this.gMSRParams.OptimizeMode = SourceGrid.CellOptimizeMode.ForRows;
            this.gMSRParams.SelectionMode = SourceGrid.GridSelectionMode.Cell;
            this.gMSRParams.Size = new System.Drawing.Size(334, 68);
            this.gMSRParams.TabIndex = 4;
            this.gMSRParams.TabStop = true;
            this.gMSRParams.ToolTipText = "";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 19);
            this.label5.TabIndex = 5;
            this.label5.Text = "Name:";
            // 
            // btn_OK
            // 
            this.btn_OK.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_OK.Location = new System.Drawing.Point(480, 469);
            this.btn_OK.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(86, 30);
            this.btn_OK.TabIndex = 4;
            this.btn_OK.Text = "Save";
            this.btn_OK.UseVisualStyleBackColor = true;
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cancel.Location = new System.Drawing.Point(573, 469);
            this.btn_Cancel.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(86, 30);
            this.btn_Cancel.TabIndex = 5;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.cb_LoadableSet);
            this.groupBox4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(403, 146);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.groupBox4.Size = new System.Drawing.Size(256, 97);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Loadable Set";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 19);
            this.label7.TabIndex = 1;
            this.label7.Text = "Version:";
            // 
            // cb_LoadableSet
            // 
            this.cb_LoadableSet.FormattingEnabled = true;
            this.cb_LoadableSet.Location = new System.Drawing.Point(83, 27);
            this.cb_LoadableSet.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.cb_LoadableSet.Name = "cb_LoadableSet";
            this.cb_LoadableSet.Size = new System.Drawing.Size(126, 27);
            this.cb_LoadableSet.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.dateTimePicker1);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.tb_SaveWIP);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.tb_Shift);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(284, 11);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.groupBox3.Size = new System.Drawing.Size(375, 125);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Data Collection";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(9, 27);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(79, 19);
            this.label15.TabIndex = 6;
            this.label15.Text = "Start Time:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(103, 22);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(261, 27);
            this.dateTimePicker1.TabIndex = 2;
            this.dateTimePicker1.Value = new System.DateTime(2013, 9, 8, 0, 0, 0, 0);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(187, 90);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(177, 19);
            this.label10.TabIndex = 5;
            this.label10.Text = "(unit data collection time)";
            // 
            // tb_SaveWIP
            // 
            this.tb_SaveWIP.Location = new System.Drawing.Point(103, 86);
            this.tb_SaveWIP.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.tb_SaveWIP.Name = "tb_SaveWIP";
            this.tb_SaveWIP.Size = new System.Drawing.Size(76, 27);
            this.tb_SaveWIP.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(273, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 19);
            this.label3.TabIndex = 3;
            this.label3.Text = "(hours)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "Save WIP:";
            // 
            // tb_Shift
            // 
            this.tb_Shift.Location = new System.Drawing.Point(203, 53);
            this.tb_Shift.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.tb_Shift.Name = "tb_Shift";
            this.tb_Shift.Size = new System.Drawing.Size(62, 27);
            this.tb_Shift.TabIndex = 1;
            this.tb_Shift.Text = "8";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(180, 19);
            this.label6.TabIndex = 0;
            this.label6.Text = "Unit Data Collection Time:";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(12, 469);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(212, 18);
            this.checkBox1.TabIndex = 8;
            this.checkBox1.Text = "Log the simulation run the logging";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.cbSteps);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.txtTSK);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.txtFWK);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(11, 146);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.groupBox5.Size = new System.Drawing.Size(377, 97);
            this.groupBox5.TabIndex = 8;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Kanban";
            // 
            // cbSteps
            // 
            this.cbSteps.FormattingEnabled = true;
            this.cbSteps.Location = new System.Drawing.Point(91, 60);
            this.cbSteps.Name = "cbSteps";
            this.cbSteps.Size = new System.Drawing.Size(113, 27);
            this.cbSteps.TabIndex = 6;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(294, 64);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 19);
            this.label11.TabIndex = 5;
            this.label11.Text = "(cassettes)";
            // 
            // txtTSK
            // 
            this.txtTSK.Location = new System.Drawing.Point(210, 60);
            this.txtTSK.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.txtTSK.Name = "txtTSK";
            this.txtTSK.Size = new System.Drawing.Size(76, 27);
            this.txtTSK.TabIndex = 4;
            this.txtTSK.Text = "200";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(190, 29);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(81, 19);
            this.label12.TabIndex = 3;
            this.label12.Text = "(cassettes)";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(11, 63);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(71, 19);
            this.label13.TabIndex = 2;
            this.label13.Text = "Step WIP:";
            // 
            // txtFWK
            // 
            this.txtFWK.Location = new System.Drawing.Point(86, 24);
            this.txtFWK.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.txtFWK.Name = "txtFWK";
            this.txtFWK.Size = new System.Drawing.Size(98, 27);
            this.txtFWK.TabIndex = 1;
            this.txtFWK.Text = "400";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(11, 29);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(66, 19);
            this.label14.TabIndex = 0;
            this.label14.Text = "Fab WIP:";
            // 
            // btn_OKRun
            // 
            this.btn_OKRun.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_OKRun.Location = new System.Drawing.Point(387, 469);
            this.btn_OKRun.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.btn_OKRun.Name = "btn_OKRun";
            this.btn_OKRun.Size = new System.Drawing.Size(86, 30);
            this.btn_OKRun.TabIndex = 9;
            this.btn_OKRun.Text = "Run";
            this.btn_OKRun.UseVisualStyleBackColor = true;
            this.btn_OKRun.Click += new System.EventHandler(this.btn_OKRun_Click);
            // 
            // SingleRunOption
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(671, 510);
            this.Controls.Add(this.btn_OKRun);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SingleRunOption";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Run Options";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tb_EOSTime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rb_EOSTime;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cb_LoadableSet;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox tb_Shift;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private SourceGrid.Grid gJSRParams;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txtJSR;
        private System.Windows.Forms.TextBox txtMSR;
        private SourceGrid.Grid gMSRParams;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnSelectMSR;
        private System.Windows.Forms.Button btnSelectJSR;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.RadioButton rb_End;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tb_SaveWIP;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtTSK;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtFWK;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cbSteps;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cbTimeUnit;
        private System.Windows.Forms.Button btn_OKRun;
    }
}