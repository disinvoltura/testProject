﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.IFS.DataModel.OutputData;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.DataModel;
using VMS.IFS.Models;
using VMS.IFS.OuputDataCollection;
using VMS.IFS.Engine;
using VMS.IFS.DecisionLogics;
using VMS.Foundation.Logging;

namespace VMS.IFS.UI
{
    public class SimulationRunner
    {
        #region Member Variables
        private Dictionary<string, object> _RunOptions;
        public InputDataSet _InputData;

        public Factory _Factory;
        private OutputReportGenerator _oprGen;

        private DateTime _SimStartTime;
        private DateTime _SimEndTime;

        private Dictionary<string, Observer> _Observers;

        private OutputDataSet _OutputData;
        #endregion

        #region Properties
        public OutputDataSet OutputData
        {
            get { return _OutputData; }
        }

        public Dictionary<string, object> RunOptions
        {
            get { return _RunOptions; }
        }
        #endregion

        #region Constructors
        public SimulationRunner(InputDataSet ids, Dictionary<string, object> runOptions)
        {
            _InputData = ids;
            _RunOptions = runOptions;
            _Observers = new Dictionary<string, Observer>();
        }
        #endregion

        #region Methods
        public bool Run()
        {
            bool rslt = true;
            bool logging = (bool)_RunOptions[SimulationArguments.Logging];

            DateTime expStart = DateTime.Now;
            doInitialize();
            doSetExpFrame();
            
            if (logging)
                doSetLogger();
            
            doRun();            
            doFinalize();
            doGenerateOutputData();

            DateTime expEnd = DateTime.Now;

            System.Diagnostics.Debug.WriteLine("Simulation Rune Time: " + expEnd.Subtract(expStart).Seconds + " secs");

            return rslt;
        }

        private void doInitialize()
        {
            _Factory = new Factory("LCD Fab");
            _Factory.Initialize(_InputData, _RunOptions);

            //RTD
            _Factory.RTD.Initialize(_RunOptions);

            //MCS

            //OutputReport Generator
            _oprGen = new OutputReportGenerator(_Factory, _RunOptions);
            _oprGen.Initialize();
        }

        private void doSetExpFrame()
        {           
            _Factory.UniInlineCell.AddObserver(_oprGen.CassetteObserveer);
            _Factory.BiInlineCell.AddObserver(_oprGen.CassetteObserveer);
            _Factory.Chamber.AddObserver(_oprGen.CassetteObserveer);
            _Factory.Oven.AddObserver(_oprGen.CassetteObserveer);
            _Factory.MaterialHandling.AddObserver(_oprGen.CassetteObserveer);

            _Factory.UniInlineCell.AddObserver(_oprGen.EquipmentObserver);
            _Factory.BiInlineCell.AddObserver(_oprGen.EquipmentObserver);
            _Factory.Chamber.AddObserver(_oprGen.EquipmentObserver);
            _Factory.Oven.AddObserver(_oprGen.EquipmentObserver);

            _Factory.FabIn.AddObserver(_oprGen.FabInObserver);
            _Factory.FabOut.AddObserver(_oprGen.FabOutObserver);

            _Factory.FabIn.AddObserver(_oprGen.CassetteTATObserver);
            _Factory.FabOut.AddObserver(_oprGen.CassetteTATObserver);

            _Factory.FabIn.AddObserver(_oprGen.FabWIPObserver);
            _Factory.FabOut.AddObserver(_oprGen.FabWIPObserver);

            _Factory.MaterialHandling.AddObserver(_oprGen.EQPWIPObserver);
            _Factory.UniInlineCell.AddObserver(_oprGen.EQPWIPObserver);
            _Factory.BiInlineCell.AddObserver(_oprGen.EQPWIPObserver);
            _Factory.Oven.AddObserver(_oprGen.EQPWIPObserver);
            _Factory.Chamber.AddObserver(_oprGen.EQPWIPObserver);
        }

        private void doSetLogger()
        {
            VMS.Foundation.Logging.SimpleFormatter formatter = new VMS.Foundation.Logging.SimpleFormatter();
            formatter.WriteLoggerInfo = false;
            formatter.WriteTimeStamp = false;

            Logger logger = LogManager.GetLogger("SimulationCoordinator");
            logger.Level = LogLevel.Always;
            logger.AddHandler(new VMS.Foundation.Logging.FileLogHandler("SimulationCoordinator", formatter));

            Logger logger2 = LogManager.GetLogger("SimulationData");
            logger2.Level = LogLevel.Always;
            logger2.AddHandler(new VMS.Foundation.Logging.FileLogHandler("SimulationData", formatter));

            Logger logger3 = LogManager.GetLogger("JobSelectionRule");
            logger3.Level = LogLevel.Always;
            logger3.AddHandler(new VMS.Foundation.Logging.FileLogHandler("JobSelectionRule", formatter));

            Logger logger4 = LogManager.GetLogger("MachineSelectionRule");
            logger4.Level = LogLevel.Always;
            logger4.AddHandler(new VMS.Foundation.Logging.FileLogHandler("MachineSelectionRule", formatter));
         
            //Log RunOptions
            logger.Info("Run Options --------------------------------------");
            foreach (string key in _RunOptions.Keys)
            {
                string log = string.Format("{0} = {1}", key, _RunOptions[key].ToString());
                logger.Info(log);
            }
            logger.Info("--------------------------------------------------");

        }

        private void doRun()
        {
            Logger logger = LogManager.GetLogger("SimulationCoordinator");

            //Run
            _SimStartTime = DateTime.Now;
            logger.Info("Starts at " + _SimStartTime.ToString());
            
            _Factory.Run();

            _SimEndTime = DateTime.Now;
            logger.Info("Ends at " + _SimEndTime.ToString());
            
        }

        private void doFinalize()
        {
            //Finalize Observer
            _oprGen.Finish();

            //Shutdown Loggers
            LogManager.Shutdown();
        }

        private void doGenerateOutputData()
        {
            //Generate Output Data
            _OutputData = new OutputDataSet();
            _OutputData = _oprGen.Transduce();
        }
        #endregion
    }
}
