﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.DataModel.OutputData;
using VMS.IFS.DataModel;
using VMS.IFS.Models;
using VMS.IFS.OuputDataCollection;
using VMS.IFS.Engine;

namespace VMS.IFS.UI
{
    public class OutputReportGenerator
    {
        #region Member Variables
        private Factory _Factory;
        private OutputDataSet _OutputData;
        private Dictionary<string, object> _RunOptions;

        private CassetteObserver _cstObs;
        private EquipmentObserver _eqpObs;
        private FabInObserver _fabInObs;
        private FabOutObserver _fabOutObs;
        private CassetteTATObserver _tatObs;
        private FabWipObserver _fabWipObs;
        private EQPWipObserver _eqpWipObs;        

        private Dictionary<string, Observer> _Observers;
        #endregion

        #region Properties
        public CassetteObserver CassetteObserveer
        {
            get { return _cstObs; }
        }

        public EquipmentObserver EquipmentObserver
        {
            get { return _eqpObs; }
        }

        public FabInObserver FabInObserver
        {
            get { return _fabInObs; }
        }

        public FabOutObserver FabOutObserver
        {
            get { return _fabOutObs; }
        }

        public CassetteTATObserver CassetteTATObserver
        {
            get { return _tatObs; }
        }

        public FabWipObserver FabWIPObserver
        {
            get { return _fabWipObs; }
        }

        public EQPWipObserver EQPWIPObserver
        {
            get { return _eqpWipObs; }
        }

        #endregion

        #region Constructors
        public OutputReportGenerator(Factory factory, Dictionary<string, object> runOptions)
        {
            _Factory = factory;
            _RunOptions = runOptions;
        }
        #endregion

        #region Methods
        public void Initialize()
        {
            _Observers = new Dictionary<string, Observer>();

            _cstObs = new CassetteObserver(_RunOptions);
            _eqpObs = new EquipmentObserver(_RunOptions);
            _fabInObs = new FabInObserver(_RunOptions);
            _fabOutObs = new FabOutObserver(_RunOptions);
            _tatObs = new CassetteTATObserver(_RunOptions);
            _fabWipObs = new FabWipObserver(_RunOptions);
            _eqpWipObs = new EQPWipObserver(_RunOptions);

            _Observers.Add(_cstObs.Name, _cstObs);
            _Observers.Add(_eqpObs.Name, _eqpObs);
            _Observers.Add(_fabInObs.Name, _fabInObs);
            _Observers.Add(_fabOutObs.Name, _fabOutObs);
            _Observers.Add(_tatObs.Name, _tatObs);
            _Observers.Add(_fabWipObs.Name, _fabWipObs);
            _Observers.Add(_eqpWipObs.Name, _eqpWipObs);

            InitializeWIP();
        }

        private void InitializeWIP()
        {
            int count = 0;
            Dictionary<string, int> eqp_Count = new Dictionary<string, int>();

            foreach (string eqpid in _Factory.MasterData.EQP.UnilineCells)
            {
                eqp_Count.Add(eqpid, 0);
                foreach (Foup cst in _Factory.UniInlineCell.B[eqpid].Cassettes)
                {
                    int cid = cst.ID;
                    CassetteLog log = new CassetteLog(0, cst.RBID, cst.J, cst.ID, CassetteState.Arrived, cst.C, cst.P, cst.D);
                    _cstObs.addCassetteLog(cid, log);

                    string key = string.Format("{0}.{1}", cst.J, cst.P);
                    _cstObs.enQueue(key);

                    count++;
                    eqp_Count[eqpid]++;
                }

                foreach (Foup cst in _Factory.UniInlineCell.Q[eqpid].Cassettes)
                {
                    int cid = cst.ID;
                    CassetteLog log = new CassetteLog(0, cst.RBID, cst.J, cst.ID, CassetteState.Arrived, cst.C, cst.P, cst.D);
                    _cstObs.addCassetteLog(cid, log);

                    string key = string.Format("{0}.{1}", cst.J, cst.P);
                    _cstObs.enQueue(key);
                    
                    count++;
                    eqp_Count[eqpid]++;
                }
            }

            foreach (string eqpid in _Factory.MasterData.EQP.BilineCells)
            {
                eqp_Count.Add(eqpid, 0);
                foreach (Foup cst in _Factory.BiInlineCell.IQ[eqpid].Cassettes)
                {
                    int cid = cst.ID;
                    CassetteLog log = new CassetteLog(0, cst.RBID, cst.J, cst.ID, CassetteState.Arrived, cst.C, cst.P, cst.D);
                    _cstObs.addCassetteLog(cid, log);

                    string key = string.Format("{0}.{1}", cst.J, cst.P);
                    _cstObs.enQueue(key);

                    count++;
                    eqp_Count[eqpid]++;
                }

                foreach (Foup cst in _Factory.BiInlineCell.Q[eqpid].Cassettes)
                {
                    int cid = cst.ID;
                    CassetteLog log = new CassetteLog(0, cst.RBID, cst.J, cst.ID, CassetteState.Arrived, cst.C, cst.P, cst.D);
                    _cstObs.addCassetteLog(cid, log);

                    string key = string.Format("{0}.{1}", cst.J, cst.P);
                    _cstObs.enQueue(key);

                    count++;
                    eqp_Count[eqpid]++;
                }
            }

            foreach (string eqpid in _Factory.MasterData.EQP.Ovens)
            {
                eqp_Count.Add(eqpid, 0);
                foreach (Foup cst in _Factory.Oven.B[eqpid].Cassettes)
                {
                    int cid = cst.ID;
                    CassetteLog log = new CassetteLog(0, cst.RBID, cst.J, cst.ID, CassetteState.Arrived, cst.C, cst.P, cst.D);
                    _cstObs.addCassetteLog(cid, log);

                    string key = string.Format("{0}.{1}", cst.J, cst.P);
                    _cstObs.enQueue(key);

                    count++;
                    eqp_Count[eqpid]++;
                }

                foreach (Foup cst in _Factory.Oven.Q[eqpid].Cassettes)
                {
                    int cid = cst.ID;
                    CassetteLog log = new CassetteLog(0, cst.RBID, cst.J, cst.ID, CassetteState.Arrived, cst.C, cst.P, cst.D);
                    _cstObs.addCassetteLog(cid, log);

                    string key = string.Format("{0}.{1}", cst.J, cst.P);
                    _cstObs.enQueue(key);

                    count++;
                    eqp_Count[eqpid]++;
                }
            }

            foreach (string eqpid in _Factory.MasterData.EQP.Chambers)
            {
                eqp_Count.Add(eqpid, 0);
                foreach (Foup cst in _Factory.Chamber.B[eqpid].Cassettes)
                {
                    int cid = cst.ID;
                    CassetteLog log = new CassetteLog(0, cst.RBID, cst.J, cst.ID, CassetteState.Arrived, cst.C, cst.P, cst.D);
                    _cstObs.addCassetteLog(cid, log);

                    string key = string.Format("{0}.{1}", cst.J, cst.P);
                    _cstObs.enQueue(key);

                    count++;
                    eqp_Count[eqpid]++;
                }

                foreach (Foup cst in _Factory.Chamber.Q[eqpid].Cassettes)
                {
                    int cid = cst.ID;
                    CassetteLog log = new CassetteLog(0, cst.RBID, cst.J, cst.ID, CassetteState.Arrived, cst.C, cst.P, cst.D);
                    _cstObs.addCassetteLog(cid, log);
                    
                    string key = string.Format("{0}.{1}", cst.J, cst.P);
                    _cstObs.enQueue(key);

                    count++;
                    eqp_Count[eqpid]++;
                }
            }

            _fabWipObs.Initialize(count);
            _eqpWipObs.Initialize(eqp_Count);
            _cstObs.InitializeProductStepWIP();
        }

        public void Finish()
        {
            foreach (Observer obs in _Observers.Values)
            {
                obs.Finalize(_Factory.Clock);
            }
        }

        public OutputDataSet Transduce()
        {
            //Generate Output Data
            _OutputData = new OutputDataSet();

            double eosTime = _Factory.Clock;
            DateTime startTime = (DateTime)_RunOptions["RefDateTime"];

            //shiftTime: in seconds
            double shiftTime = (int)_RunOptions[SimulationArguments.UnitTime] * 3600;
            int noShifts = 0;
            if (eosTime % shiftTime > 0)
            {
                noShifts = (int)(eosTime / shiftTime) + 1;
            }
            else
            {
                noShifts = (int)(eosTime / shiftTime);
            }
            int noHours = (int)(eosTime / 3600) + 1;

            foreach (string eqpid in _Factory.MasterData.EQP.Equipments)
            {
                //EQPOutput
                _OutputData.EQPOutputDataTable.Columns.Add(eqpid);

                //EQPWIP
                _OutputData.EQPWIPDataTable.Columns.Add(eqpid);

                _OutputData.BNEQPDataTable.Columns.Add(eqpid + ".WIP");
                _OutputData.BNEQPDataTable.Columns.Add(eqpid + ".Out");
            }

            //ProcessingStepOut/ProcessingStepWIP
            List<string> stepOutKeys = new List<string>(); //이런 형태로 다른 output data 도 간결하게 정리할 것!!!
            foreach (string productid in _Factory.MasterData.Product.Products)
            {
                IEnumerable<string> steplist = _Factory.MasterData.BOP.ProductSteps[productid];

                foreach (string stepid in steplist)
                {
                    string key = string.Format("{0}.{1}", productid, stepid);
                    stepOutKeys.Add(key);

                    _OutputData.ProcessingStepOutputDataTable.Columns.Add(key);
                    _OutputData.ProcessingStepWIPDataTable.Columns.Add(key);

                    //StepTATChart
                    if (!_OutputData.StepTATChartDataTable.Columns.Contains(stepid))
                    {
                        _OutputData.StepTATChartDataTable.Columns.Add(stepid);
                    }

                    _OutputData.BNProductStepDataTable.Columns.Add(key + ".WIP");
                    _OutputData.BNProductStepDataTable.Columns.Add(key + ".Out");
                }
            }

            //ProductInOut
            foreach (string productid in _Factory.MasterData.Product.Products)
            {
                _OutputData.ProductInOutDataTable.Columns.Add(productid + " In", typeof(int));
                _OutputData.ProductInOutDataTable.Columns.Add(productid + " Out", typeof(int));
            }

            //Shift 0 WIP 관련 추가 2013.11.16
            OutputDataSet.FabWIPDataTableRow FabWIProw = _OutputData.FabWIPDataTable.NewFabWIPDataTableRow();
            FabWIProw.Time_Bucket = "0";
            FabWIProw.WIP = _fabWipObs.ShiftFabWIP[0].ToString();
            _OutputData.FabWIPDataTable.Rows.Add(FabWIProw);

            OutputDataSet.EQPWIPDataTableRow EQPWIProw = _OutputData.EQPWIPDataTable.NewEQPWIPDataTableRow();
            EQPWIProw["Time Bucket"] = "0";
            foreach (string eqpid in _Factory.MasterData.EQP.Equipments)
            {
                EQPWIProw[eqpid] = _eqpWipObs.ShiftEQPWIP(eqpid, 0).ToString();
            }
            _OutputData.EQPWIPDataTable.Rows.Add(EQPWIProw);

            OutputDataSet.ProcessingStepWIPDataTableRow PsWIProw = _OutputData.ProcessingStepWIPDataTable.NewProcessingStepWIPDataTableRow();
            PsWIProw["Time Bucket"] = "0";
            foreach (string key in stepOutKeys)
            {
                TimeBucketDependentStatistics statWip = null;
                if (_cstObs.StepWIP.ContainsKey(key))
                {
                    statWip = _cstObs.StepWIP[key];
                    PsWIProw[key] = statWip[0];
                }
                else
                {
                    PsWIProw[key] = 0;
                }
            }
            _OutputData.ProcessingStepWIPDataTable.Rows.Add(PsWIProw);
            //이상 Shift 0 WIP 관련 추가 내용 2013.11.16


            for (int i = 1; i <= noShifts; i++)
            {
                //FabInOut
                OutputDataSet.FabInOutDataTableRow row1 =
                    _OutputData.FabInOutDataTable.NewFabInOutDataTableRow();

                row1.Time_Bucket = i.ToString();
                row1.Fab_In = _fabInObs.Statistics[i].ToString();
                row1.Fab_Out = _fabOutObs.Statistics[i].ToString();

                _OutputData.FabInOutDataTable.Rows.Add(row1);

                //FabWIP
                OutputDataSet.FabWIPDataTableRow row3 =
                    _OutputData.FabWIPDataTable.NewFabWIPDataTableRow();

                row3.Time_Bucket = i.ToString();
                row3.WIP= _fabWipObs.ShiftFabWIP[i].ToString();

                _OutputData.FabWIPDataTable.Rows.Add(row3);                               
                
                //EQPOutput
                OutputDataSet.EQPOutputDataTableRow row2 = _OutputData.EQPOutputDataTable.NewEQPOutputDataTableRow();
                row2.Time_Bucket = i.ToString();

                OutputDataSet.EQPWIPDataTableRow rowEQPWIP = _OutputData.EQPWIPDataTable.NewEQPWIPDataTableRow();
                rowEQPWIP["Time Bucket"] = i.ToString();

                foreach (string eqpid in _Factory.MasterData.EQP.Equipments)
                {
                    TimeBucketTallyStatistics stat = _eqpObs.GetTimeBucketOutData(eqpid);
                    if (stat != null)
                        row2[eqpid] = stat[i];
                    else
                        row2[eqpid] = 0;
                    
                    rowEQPWIP[eqpid] = _eqpWipObs.ShiftEQPWIP(eqpid, i).ToString();                    
                }

                _OutputData.EQPOutputDataTable.Rows.Add(row2);
                
                _OutputData.EQPWIPDataTable.Rows.Add(rowEQPWIP);

                OutputDataSet.ProcessingStepOutputDataTableRow rowOut
                    = _OutputData.ProcessingStepOutputDataTable.NewProcessingStepOutputDataTableRow();
                rowOut["Time Bucket"] = i.ToString();
                OutputDataSet.ProcessingStepWIPDataTableRow rowWIP =
                    _OutputData.ProcessingStepWIPDataTable.NewProcessingStepWIPDataTableRow();
                rowWIP["Time Bucket"] = i.ToString();
                foreach (string key in stepOutKeys)
                {
                    TimeBucketTallyStatistics statOut = null;
                    if (_cstObs.StepOut.ContainsKey(key))
                    {
                        statOut = _cstObs.StepOut[key];
                        rowOut[key] = statOut[i];
                    }
                    else
                    {
                        rowOut[key] = 0;
                    }

                    TimeBucketDependentStatistics statWip = null;
                    if (_cstObs.StepWIP.ContainsKey(key))
                    {
                        statWip = _cstObs.StepWIP[key];
                        rowWIP[key] = statWip[i];
                    }
                    else
                    {
                        rowWIP[key] = 0;
                    }
                }

                //ProcessingStepOut
                _OutputData.ProcessingStepOutputDataTable.Rows.Add(rowOut);
                //ProcessingStepWIP
                _OutputData.ProcessingStepWIPDataTable.Rows.Add(rowWIP);

                //ProductInOut
                OutputDataSet.ProductInOutDataTableRow rowInOut =
                    _OutputData.ProductInOutDataTable.NewProductInOutDataTableRow();
                rowInOut.Time_Bucket = i.ToString();

                foreach (string productid in _Factory.MasterData.Product.Products)
                {
                    TimeBucketTallyStatistics inStat = _fabInObs[productid];
                    if (inStat != null)
                        rowInOut[productid + " In"] = inStat[i];
                    else
                        rowInOut[productid + " In"] = 0;
                    TimeBucketTallyStatistics outStat = _fabOutObs[productid];
                    if (outStat != null)
                        rowInOut[productid + " Out"] = outStat[i];
                    else
                        rowInOut[productid + " Out"] = 0;
                }

                _OutputData.ProductInOutDataTable.Rows.Add(rowInOut);
            }

            for (int i = 1; i < noHours; i++)
            {
                OutputDataSet.BNEQPDataTableRow row = _OutputData.BNEQPDataTable.NewBNEQPDataTableRow();
                DateTime time = startTime.AddHours(i);
                row.Time = time.ToString();
                foreach (string eqpid in _eqpObs.Equipments)
                {                    
                    TimeBucketTallyStatistics EQPOut = _eqpObs.GetHourOutData(eqpid);
                    
                    row[eqpid + ".WIP"] = _eqpWipObs.HoursEQPWIP(eqpid, i).ToString();
                    if (EQPOut == null)
                    {
                        row[eqpid + ".Out"] = 0;
                    }
                    else
                    {
                        row[eqpid + ".Out"] = EQPOut[i];
                    }
                }
                _OutputData.BNEQPDataTable.Rows.Add(row);

                OutputDataSet.BNProductStepDataTableRow rowPS = _OutputData.BNProductStepDataTable.NewBNProductStepDataTableRow();
                time = startTime.AddHours(i);
                rowPS.Time = time.ToString();
                foreach (string key in stepOutKeys)
                {
                    TimeBucketDependentStatistics statWip = null;
                    if (_cstObs.StepWIP.ContainsKey(key))
                    {
                        statWip = _cstObs.StepWIPHours[key];
                        rowPS[key + ".WIP"] = statWip[i];
                    }
                    else
                    {
                        rowPS[key + ".WIP"] = 0;
                    }
                    TimeBucketTallyStatistics statOut = null;
                    if (_cstObs.StepOut.ContainsKey(key))
                    {
                        statOut = _cstObs.StepOutHours[key];
                        rowPS[key + ".Out"] = statOut[i];
                    }
                    else
                    {
                        rowPS[key + ".Out"] = 0;
                    }                    
                }
                _OutputData.BNProductStepDataTable.Rows.Add(rowPS);
            }

            //EQPUtilization
            foreach (string eqpid in _Factory.MasterData.EQP.Equipments)
            {
                OutputDataSet.EQPUtilizationDataTableRow row =
                    _OutputData.EQPUtilizationDataTable.NewEQPUtilizationDataTableRow();
                row.EQP_ID = eqpid;
                if (_eqpObs[eqpid] == null)
                    continue;
                //row.Run = _eqpObs[eqpid].Run.ToString();
                row.Idle = _eqpObs[eqpid].Idle.ToString();
                row.Setup = _eqpObs[eqpid].Setup.ToString();

                _OutputData.EQPUtilizationDataTable.Rows.Add(row);                               
            }

            //DueDatesatisfaction
            foreach (string rbid in _Factory.MasterData.ReleaseBatch.ReleaseBatches)
            {
                ReleaseBatch rb = _Factory.MasterData.ReleaseBatch[rbid];

                int noGlasses = 0;

                if (_fabOutObs.NumberOfSatisfiedCassettes.ContainsKey(rb.ReleaseBatchID))
                    noGlasses = _fabOutObs.NumberOfSatisfiedCassettes[rb.ReleaseBatchID];
                double ratio = Math.Round((double)noGlasses / (double)rb.Quantity, 2);

                OutputDataSet.DueDateSatisfactionDataTableRow row =
                    _OutputData.DueDateSatisfactionDataTable.NewDueDateSatisfactionDataTableRow();

                row.Release_Batch_ID = rb.ReleaseBatchID;
                row.Product_ID = rb.ProductID;
                row.Quantity = rb.Quantity.ToString();
                row.Due_Date = rb.DueDate.ToString();
                row.Satisfaction_Ratio = ratio.ToString();

                _OutputData.DueDateSatisfactionDataTable.Rows.Add(row);
            }

            //ProductStepTAT            
            foreach (string productid in _Factory.MasterData.Product.Products)
            {
                IEnumerable<string> steps = _Factory.MasterData.BOP.ProductSteps[productid];                

                OutputDataSet.StepTATChartDataTableRow row4StepTATChart = _OutputData.StepTATChartDataTable.NewStepTATChartDataTableRow();
                row4StepTATChart.Product_ID = productid;
                foreach (string stepid in steps)
                {
                    SampleStatistics stat = _cstObs[productid, stepid];

                    double tat = 0;
                    if (stat != null)
                        tat = stat.Mean;
                    OutputDataSet.ProductStepTATDataTableRow row =
                        _OutputData.ProductStepTATDataTable.NewProductStepTATDataTableRow();

                    row.Product_ID = productid;
                    row.Step_ID = stepid;
                    row.Average_TAT = tat.ToString();
                    _OutputData.ProductStepTATDataTable.Rows.Add(row);                    

                    row4StepTATChart[stepid] = tat.ToString();                   
                }
                _OutputData.StepTATChartDataTable.Rows.Add(row4StepTATChart);
            }

            //ProductTAT
            foreach (string productid in _Factory.MasterData.Product.Products)
            {
                SampleStatistics stat = _tatObs[productid];

                double tat = 0;
                if (stat != null)
                    tat = stat.Mean;

                OutputDataSet.ProductTATDataTableRow row =
                    _OutputData.ProductTATDataTable.NewProductTATDataTableRow();

                row.Product_ID = productid;
                row.Total_TAT = tat.ToString();
                _OutputData.ProductTATDataTable.Rows.Add(row);
            }

            //Release Batch
            if (_Factory.FabIn.ReleaseCassettes.Count > 0)
            {
                Dictionary<string, int> sumData = new Dictionary<string,int>();
                for(int i = 0; i < _Factory.FabIn.ReleaseCassettes.Count; i++)
                {
                    Foup cst = _Factory.FabIn.ReleaseCassettes[i];

                    string key = cst.ReleaseDate + "." + cst.J;

                    if (sumData.ContainsKey(key))
                    {
                        sumData[key] = sumData[key] + cst.N;
                    }else{
                        sumData.Add(key, cst.N);
                    }
                }

                foreach(string key in sumData.Keys)
                {
                    string[] splitData = key.Split('.');

                    int releaseDate = int.Parse(splitData[0]);
                    string productid = splitData[1];
                    int qty = sumData[key];

                    OutputDataSet.ReleaseBatchDataTableRow row =
                        _OutputData.ReleaseBatchDataTable.NewReleaseBatchDataTableRow();

                    row.DateTime = _Factory.MasterData.ReferenceStartDate.AddSeconds(releaseDate);
                    row.ProductID = productid;
                    row.Quantity = qty;

                    _OutputData.ReleaseBatchDataTable.Rows.Add(row);
                }
            }

            //Fabout Plan
            DateTime endDate = _Factory.MasterData.ReferenceStartDate.AddSeconds(_Factory.Clock);
            foreach (DateTime date in _Factory.MasterData.FabOutPlan.Data.Keys)
            {
                List<FabOutPlan> plans = _Factory.MasterData.FabOutPlan.Data[date];

                if (_OutputData.FabOutPlanDataTable.Columns.Count == 1)
                {
                    foreach (FabOutPlan fop in plans)
                    {
                        _OutputData.FabOutPlanDataTable.Columns.Add(fop.ProductID);
                    }
                }

                OutputDataSet.FabOutPlanDataTableRow row =  _OutputData.FabOutPlanDataTable.NewFabOutPlanDataTableRow();
                row.Date = date;
                if (row.Date > endDate)
                    continue;

                foreach (FabOutPlan fop in plans)
                {
                    int planedQty = fop.TargetQuantity;
                    int actualQty = 0;
                    int baseShift = 0;
                    TimeSpan ts = date.Subtract(_Factory.MasterData.ReferenceStartDate);
                    baseShift = ((int)ts.TotalDays) * 3 + 1;
                    //9/8:0  -> 1, 2, 3
                    //9/9:1  -> 4, 5, 6
                    //9/10:2 -> 7, 8, 9

                    int glasspercst = _Factory.MasterData.Product[fop.ProductID].GlassQuantity;
                    for (int i = baseShift; i <= baseShift+2; i++)//start with 1st shift
                    {
                        if (_fabOutObs[fop.ProductID] == null)
                        {
                            actualQty += 0;
                        }
                        else
                        {
                            actualQty += _fabOutObs[fop.ProductID][i] * glasspercst;
                            //_prod.Statistics[i] * glasspercst;
                        }
                    }

                    row[fop.ProductID] = actualQty + "/" + planedQty;
                }

                _OutputData.FabOutPlanDataTable.Rows.Add(row);
            }

            //GanttChart
            foreach (string eqpid in _Factory.MasterData.EQP.Equipments)
            {
                EquipmentHistory eh = _eqpObs[eqpid];
                if (eh == null)
                    continue;

                EquipmentLog lastLog = null;
                foreach (EquipmentLog log in eh.Logs)
                {
                    System.Diagnostics.Debug.WriteLine(log.State + "\t" + log.Time + "\t" + log.CassetteID);
                }
                
                foreach (EquipmentLog log in eh.Logs)
                {
                    if (lastLog != null)
                    {
                        if (lastLog.State != EquipmentState.Idle && lastLog.Time != log.Time)
                        {
                            OutputDataSet.EQPGanttChartDataTableRow row =
                                _OutputData.EQPGanttChartDataTable.NewEQPGanttChartDataTableRow();
                            row.EQPID = eqpid;
                            if (lastLog.State == EquipmentState.Busy)
                                row.Category = "Run";
                            else if (lastLog.State == EquipmentState.Setup)
                                row.Category = "Setup";
                            row.StartTime = _Factory.MasterData.ReferenceStartDate.AddSeconds(lastLog.Time);
                            row.EndTime = _Factory.MasterData.ReferenceStartDate.AddSeconds(log.Time);

                            _OutputData.EQPGanttChartDataTable.Rows.Add(row);
                        }
                    }
                    lastLog = log;                    
                }
                //Gantt chart 종료 시점 반영 - 김현식 / 2013.11.20
                if (lastLog.State != EquipmentState.Idle)
                {
                    OutputDataSet.EQPGanttChartDataTableRow row =
                                _OutputData.EQPGanttChartDataTable.NewEQPGanttChartDataTableRow();
                    row.EQPID = eqpid;
                    if (lastLog.State == EquipmentState.Busy)
                        row.Category = "Run";
                    else if (lastLog.State == EquipmentState.Setup)
                        row.Category = "Setup";

                    row.StartTime = _Factory.MasterData.ReferenceStartDate.AddSeconds(lastLog.Time);
                    row.EndTime = _Factory.MasterData.ReferenceStartDate.AddSeconds(_Factory.SimulationCoordinator.EOSClock);

                    _OutputData.EQPGanttChartDataTable.Rows.Add(row);
                }

            }
            return _OutputData;
        }
        #endregion
    }
}
