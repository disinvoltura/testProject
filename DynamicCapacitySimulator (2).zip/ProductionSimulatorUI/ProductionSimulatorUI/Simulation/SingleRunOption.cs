﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.DataModel.InputData;
using VMS.IFS.DataModel.DispatchingRuleData;

namespace VMS.IFS.UI
{
    public partial class SingleRunOption : Form
    {
        #region Member Variables
        public InputDataSet ids;
        private double EOSTime;
        private bool isEOSTime;              
        private List<string> lstLoadableSet;
        private string selectedLoadableSet;
        private int shift;
        private int saveWIPTime;

        private List<string> _StepList;
        private DateTime firstFO;
        #endregion

        #region Properties
        public Dictionary<string, object> RunOptions
        {
            get
            {
                Dictionary<string, object> args = new Dictionary<string, object>();
                args.Add(SimulationArguments.RandomSeed, DateTime.Now.Second);
                args.Add(SimulationArguments.LoadableEQPVersionNo, selectedLoadableSet);

                if (isEOSTime)
                {
                    args.Add(SimulationArguments.EOSMode, "Time");
                    args.Add(SimulationArguments.EOSTime, this.EOSTime);
                }
                else
                {
                    args.Add(SimulationArguments.EOSMode, "Time");
                    args.Add(SimulationArguments.EOSTime, double.MaxValue);                    
                }

                args.Add(SimulationArguments.UnitTime, this.shift);
                args.Add(SimulationArguments.SaveWIPTime, this.saveWIPTime);

                //dispatching rule
                args.Add(SimulationArguments.JobSelectionRule, _JSR);                
                if (_JSR.Parameters.Count<DRParameter>() > 0)
                {
                    for (int i = 1; i < gJSRParams.Columns.Count; i++)
                    {
                        args.Add("JSR_" + gJSRParams[0, i].DisplayText, gJSRParams[1, i].DisplayText);
                    }
                }

                args.Add(SimulationArguments.MachineSelectionRule, _MSR);
                if (_MSR.Parameters.Count<DRParameter>() > 0)
                {
                    for (int i = 1; i < gMSRParams.Columns.Count; i++)
                    {
                        args.Add("MSR_" + gMSRParams[0, i].DisplayText, gMSRParams[1, i].DisplayText);
                    }
                }

                args.Add(SimulationArguments.Logging, checkBox1.Checked);

                //Start Time
                args.Add(SimulationArguments.ReferenceDateTime, dateTimePicker1.Value);

                //Kanban                
                args.Add(SimulationArguments.KanbanFabWIP, int.Parse(txtFWK.Text));
                args.Add(SimulationArguments.KanbanStepWIP, int.Parse(txtTSK.Text));
                args.Add(SimulationArguments.KanbanStepID, cbSteps.Text);
                return args;
            }
        }
        #endregion

        #region Constructor

        public SingleRunOption(InputDataSet ids, List<string> lstLoadableSet, Dictionary<string, object> befRO, DateTime firstFODate)
        {
            InitializeComponent();

            this.ids = ids;
            this.lstLoadableSet = new List<string>();
            this.lstLoadableSet = lstLoadableSet;

            this.firstFO = firstFODate;
            
            foreach(string version in lstLoadableSet)
            {
                cb_LoadableSet.Items.Add(version);
            }

            _StepList = new List<string>();
            foreach (InputDataSet.BOPDataTableRow row in ids.BOPDataTable.Rows)
            {
                if (!_StepList.Contains(row.FROM_STEP))
                    _StepList.Add(row.FROM_STEP);

                if (!_StepList.Contains(row.TO_STEP))
                    _StepList.Add(row.TO_STEP);
            }

            foreach (string stepid in _StepList)
            {
                cbSteps.Items.Add(stepid);
            }

            if (befRO != null)
            {
                cb_LoadableSet.SelectedItem = befRO["LoadableEQPVersionNo"];
                double eos = double.Parse(befRO["EOSTime"].ToString());
                eos = eos / 3600;
                tb_EOSTime.Text = eos.ToString();
                tb_Shift.Text = befRO["UnitTime"].ToString();
                if (befRO["SaveWIPTime"].ToString() != "-1")
                {
                    double save = double.Parse(befRO["SaveWIPTime"].ToString());
                    save = save / 3600;
                    tb_SaveWIP.Text = save.ToString();
                }
                if (befRO["Logging"].ToString() == "False")
                {
                    checkBox1.Checked = false;
                }
                else
                {
                    checkBox1.Checked = true;
                }
                dateTimePicker1.Value = DateTime.Parse(befRO["RefDateTime"].ToString());
                txtFWK.Text = befRO["FabWIPKanban"].ToString();
                txtTSK.Text = befRO["StepWIPKanban"].ToString();
                cbSteps.SelectedItem = befRO["StepIDKanban"].ToString();
                
                _JSR = (DispatchingRuleDefinition) befRO["JSR"];
                txtJSR.Text = _JSR.Name;

                //Parameters
                int pCountJSR = _JSR.Parameters.Count<DRParameter>();
                if (pCountJSR > 0)
                {
                    //Headers
                    gJSRParams.Rows.Clear();
                    gJSRParams.Columns.Clear();

                    gJSRParams.Redim(2, pCountJSR + 1);
                    gJSRParams.FixedRows = 1;

                    SourceGrid.Cells.Header l_00Header = new SourceGrid.Cells.Header(null);
                    gJSRParams[0, 0] = l_00Header;
                    gJSRParams[1, 0] = new SourceGrid.Cells.RowHeader(null);

                    SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
                    DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
                    backHeader.BackColor = Color.Lavender;
                    backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
                    titleModel.Background = backHeader;
                    titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

                    int colCount = 1;
                    foreach (DRParameter p in _JSR.Parameters)
                    {
                        SourceGrid.Cells.ColumnHeader header =
                             new SourceGrid.Cells.ColumnHeader(p.Name);

                        header.View = titleModel;
                        gJSRParams[0, colCount] = header;

                        SourceGrid.Cells.Cell pCell = new SourceGrid.Cells.Cell("1", typeof(string));
                        pCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
                        gJSRParams[1, colCount] = pCell;

                        colCount++;
                    }
                }

                _MSR = (DispatchingRuleDefinition) befRO["MSR"];

                //Name
                txtMSR.Text = _MSR.Name;

                //Parameters
                int pCountMSR = _MSR.Parameters.Count<DRParameter>();
                if (pCountMSR > 0)
                {
                    //Headers
                    gMSRParams.Rows.Clear();
                    gMSRParams.Columns.Clear();

                    gMSRParams.Redim(2, pCountMSR + 1);
                    gMSRParams.FixedRows = 1;

                    SourceGrid.Cells.Header l_00Header = new SourceGrid.Cells.Header(null);
                    gMSRParams[0, 0] = l_00Header;
                    gMSRParams[1, 0] = new SourceGrid.Cells.RowHeader(null);

                    SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
                    DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
                    backHeader.BackColor = Color.Lavender;
                    backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
                    titleModel.Background = backHeader;
                    titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

                    int colCount = 1;
                    foreach (DRParameter p in _MSR.Parameters)
                    {
                        SourceGrid.Cells.ColumnHeader header =
                             new SourceGrid.Cells.ColumnHeader(p.Name);

                        header.View = titleModel;
                        gMSRParams[0, colCount] = header;

                        SourceGrid.Cells.Cell pCell = new SourceGrid.Cells.Cell("", typeof(string));
                        pCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
                        gMSRParams[1, colCount] = pCell;

                        colCount++;
                    }
                }
            }
        }

        #endregion

        #region Event Handling

        private void rb_EOSTime_CheckedChanged(object sender, EventArgs e)
        {
            tb_EOSTime.Enabled = true;
            isEOSTime = true;
        }

        private void rb_End_CheckedChanged(object sender, EventArgs e)
        {
            tb_EOSTime.Enabled = false;
            isEOSTime = false;
        }

        private void btn_OK_Click(object sender, EventArgs e)
        {
            if (rb_EOSTime.Checked)
            {
                if (!double.TryParse(tb_EOSTime.Text.ToString(), out EOSTime))
                {
                    MessageBox.Show(this, "Please enter number in EOS Time field (double type).", "Error", MessageBoxButtons.OK);
                    return;
                }

                string timeUnit = cbTimeUnit.Text.ToLower();
                if (timeUnit == "days")
                {
                    EOSTime = EOSTime * 24 * 3600;
                }
                else if (timeUnit == "hours")
                {
                    EOSTime = EOSTime * 3600;
                }
                else if (timeUnit == "minutes")
                {
                    EOSTime = EOSTime * 60;
                }
            }
            
            if (dateTimePicker1.Value.Date > firstFO.Date)
            {
                MessageBox.Show(this, "Please select Start Time before first Fab out date in input data.", "Error", MessageBoxButtons.OK);
                return;
            }

            if (cb_LoadableSet.SelectedItem == null)
            {
                MessageBox.Show(this, "Please select Loadable Set.", "Error", MessageBoxButtons.OK);
                return;
            }

            selectedLoadableSet = cb_LoadableSet.SelectedItem.ToString();

            if (!int.TryParse(tb_Shift.Text.ToString(), out shift))
            {
                MessageBox.Show(this, "Please enter number in Unit Data Collection Time field (int type).", "Error", MessageBoxButtons.OK);
                return;
            }

            if (_JSR == null)
            {
                MessageBox.Show(this, "Please select Job Selection Rule.", "Error", MessageBoxButtons.OK);
                return;
            }
            if (_MSR == null)
            {
                MessageBox.Show(this, "Please select Machine Selection Rule.", "Error", MessageBoxButtons.OK);
                return;
            }
            
            if (!int.TryParse(tb_SaveWIP.Text.ToString(), out saveWIPTime))
            {
                this.saveWIPTime = -1;
            }
            else
            {
                this.saveWIPTime = this.saveWIPTime * this.shift * 3600;
            }

            // 시뮬레이션 실행 메소드 추가 필요
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }

        private void btn_OKRun_Click(object sender, EventArgs e)
        {
            if (rb_EOSTime.Checked)
            {
                if (!double.TryParse(tb_EOSTime.Text.ToString(), out EOSTime))
                {
                    MessageBox.Show(this, "Please enter number in EOS Time field (double type).", "Error", MessageBoxButtons.OK);
                    return;
                }

                string timeUnit = cbTimeUnit.Text.ToLower();
                if (timeUnit == "days")
                {
                    EOSTime = EOSTime * 24 * 3600;
                }
                else if (timeUnit == "hours")
                {
                    EOSTime = EOSTime * 3600;
                }
                else if (timeUnit == "minutes")
                {
                    EOSTime = EOSTime * 60;
                }
            }

            if (dateTimePicker1.Value.Date > firstFO.Date)
            {
                MessageBox.Show(this, "Please select Start Time before first Fab out date in input data.", "Error", MessageBoxButtons.OK);
                return;
            }

            if (cb_LoadableSet.SelectedItem == null)
            {
                MessageBox.Show(this, "Please select Loadable Set.", "Error", MessageBoxButtons.OK);
                return;
            }

            selectedLoadableSet = cb_LoadableSet.SelectedItem.ToString();

            if (!int.TryParse(tb_Shift.Text.ToString(), out shift))
            {
                MessageBox.Show(this, "Please enter number in Unit Data Collection Time field (int type).", "Error", MessageBoxButtons.OK);
                return;
            }

            if (_JSR == null)
            {
                MessageBox.Show(this, "Please select Job Selection Rule.", "Error", MessageBoxButtons.OK);
                return;
            }
            if (_MSR == null)
            {
                MessageBox.Show(this, "Please select Machine Selection Rule.", "Error", MessageBoxButtons.OK);
                return;
            }

            if (!int.TryParse(tb_SaveWIP.Text.ToString(), out saveWIPTime))
            {
                this.saveWIPTime = -1;
            }
            else
            {
                this.saveWIPTime = this.saveWIPTime * this.shift * 3600;
            }

            // 시뮬레이션 실행 메소드 추가 필요
            this.DialogResult = System.Windows.Forms.DialogResult.Abort;
            this.Close();
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        #endregion                                

        #region Job Selection Rule Methods
        private DispatchingRuleDefinition _JSR;
        private DispatchingRuleDefinition _MSR;

        private void btnSelectJSR_Click(object sender, EventArgs e)
        {
            DispatchingRuleSelector dialog = new DispatchingRuleSelector(DispatchingRuleType.JobSelectionRule);
            DialogResult rslt = dialog.ShowDialog();

            if (rslt == System.Windows.Forms.DialogResult.OK)
            {
                _JSR = dialog.SelectedDispatchingRule;
                
                //Name
                txtJSR.Text = _JSR.Name;

                //Parameters
                int pCount = _JSR.Parameters.Count<DRParameter>();
                if (pCount > 0)
                {
                    //Headers
                    gJSRParams.Rows.Clear();
                    gJSRParams.Columns.Clear();

                    gJSRParams.Redim(2, pCount+1);
                    gJSRParams.FixedRows = 1;

                    SourceGrid.Cells.Header l_00Header = new SourceGrid.Cells.Header(null);
                    gJSRParams[0, 0] = l_00Header;
                    gJSRParams[1, 0] = new SourceGrid.Cells.RowHeader(null);

                    SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
                    DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
                    backHeader.BackColor = Color.Lavender;
                    backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
                    titleModel.Background = backHeader;
                    titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

                    int colCount = 1;
                    foreach(DRParameter p in _JSR.Parameters)
                    {
                        SourceGrid.Cells.ColumnHeader header =
                             new SourceGrid.Cells.ColumnHeader(p.Name);

                        header.View = titleModel;
                        gJSRParams[0, colCount] = header;

                        SourceGrid.Cells.Cell pCell = new SourceGrid.Cells.Cell("1", typeof(string));
                        pCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
                        gJSRParams[1, colCount] = pCell;
                        
                        colCount++;
                    }
                }
            }
        }
        #endregion

        #region Machine Selection Rule Methods
        private void btnSelectMSR_Click(object sender, EventArgs e)
        {
            DispatchingRuleSelector dialog = new DispatchingRuleSelector(DispatchingRuleType.MachineSelectionRule);
            DialogResult rslt = dialog.ShowDialog();

            if (rslt == System.Windows.Forms.DialogResult.OK)
            {
                _MSR = dialog.SelectedDispatchingRule;

                //Name
                txtMSR.Text = _MSR.Name;

                //Parameters
                int pCount = _MSR.Parameters.Count<DRParameter>();
                if (pCount > 0)
                {
                    //Headers
                    gMSRParams.Rows.Clear();
                    gMSRParams.Columns.Clear();

                    gMSRParams.Redim(2, pCount+1);
                    gMSRParams.FixedRows = 1;

                    SourceGrid.Cells.Header l_00Header = new SourceGrid.Cells.Header(null);
                    gMSRParams[0, 0] = l_00Header;
                    gMSRParams[1, 0] = new SourceGrid.Cells.RowHeader(null);

                    SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
                    DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
                    backHeader.BackColor = Color.Lavender;
                    backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
                    titleModel.Background = backHeader;
                    titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

                    int colCount = 1;
                    foreach (DRParameter p in _MSR.Parameters)
                    {
                        SourceGrid.Cells.ColumnHeader header =
                             new SourceGrid.Cells.ColumnHeader(p.Name);

                        header.View = titleModel;
                        gMSRParams[0, colCount] = header;

                        SourceGrid.Cells.Cell pCell = new SourceGrid.Cells.Cell("", typeof(string));
                        pCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
                        gMSRParams[1, colCount] = pCell;

                        colCount++;
                    }
                }
            }
        }
        #endregion                
    }
}
