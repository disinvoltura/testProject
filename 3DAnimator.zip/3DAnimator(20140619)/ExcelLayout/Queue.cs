﻿//@Author Seyoun Park

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Runtime.InteropServices;

namespace ExcelLayout
{
	//[Guid("63CE4712-2433-4A5E-ABBF-ADC11EE265BC")]
	public class Queue
	{
        string stockerName;
		string name;
		string type;
		double x, y, z;
        double cx, cy, cz;
		string targetName; //port 종류인 경우에만 사
        string cpName;

		public Queue()
		{
			name = "";
			type = "";
			x = y = z = 0;

			targetName = "";
		}
		public Queue(string n)
		{
			name = n;
			x = y = z = 0;

			targetName = "";
		}
		public Queue(string n, string t, double px, double py, double pz)
		{
			name = n;
			type = t;
            x = px; y = py; z = pz;

			targetName = "";
		}

		public string getName() { return name; }
        public string getCPName() { return cpName; }
		public string getType() { return type; }
		public double getPositionX() { return x; }
		public double getPositionY() { return y; }
        public double getPositionZ() { return z; }
        
        public double getPositionCX() { return cx; }
        public double getPositionCY() { return cy; }
        public double getPositionCZ() { return cz; }

		public void setTargetName(string pn) { this.targetName = pn; }
		public void setName(string name) { this.name = name; }
        public void setCPName(string name) { this.cpName = name; }
		public void setType(string type) { this.type = type; }
		public void setPosition(double x, double y, double z)
		{
            this.x = x; this.y = y; this.z = z;
		}

        public void setControlPosition(double x, double y, double z)
        {
            this.cx = x; this.cy = y; this.cz = z;
        }

        public void setStockerName(string sn) { this.stockerName = sn; }
        public string getStockerName() { return this.stockerName; }
	}
}
