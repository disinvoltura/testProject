﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace ExcelLayout
{
    //[ComVisible(true)]
    //[Guid("F4D098FF-565D-4F01-BDF7-6BE48B3D70DA")]
    public class LinearMotor
    {
        #region Variables
        public string name;
        public string type;
        public Cell startCell;
        public Cell endCell;
        public List<Cell> bufferList;
        #endregion

        #region Constructor
        public LinearMotor(string name, string type, Cell startCell, Cell endCell, List<Cell> bufferList)
        {
            this.name = name;
            this.type = type;
            this.startCell = startCell;
            this.endCell = endCell;
            this.bufferList = bufferList;
        }
        #endregion
    }
}
