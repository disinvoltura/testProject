﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace ExcelLayout
{
    //[ComVisible(true)]
    //Guid("B34FF4A5-FD1D-4886-AD62-5161B66EA719")]
    public class Info
    {
        #region Variables

        public List<InlineStocker> inlineStocker;
        public List<LinearMotor> linearMotor;
        public Dictionary<string, int> resource;
        public Dictionary<string, string> resourceType;
        public List<Cell> cells;

        public int minRow;
        public int minCol;
        public int maxRow;
        public int maxCol;

        public string COLORSINGLECRANEPATH;
        public string COLORDUALCRANEPATH;
        public string COLORCONVEYORBELT;
        public string COLORCONVEYORCORNER;
        public string COLORLINEARMOTORLINE;
        public string COLORLINEARMOTORBUFFER;
        public string COLORSHELF;
        public string COLORIOPORT;
        public string COLORBIINPORT;
        public string COLORBIOUTPORT;
        public string COLORUNIINLINE;
        public string COLORBIINLINE;
        public string COLORSTKINPORTC;
        public string COLORSTKOUTPORTC;
        public string COLORSTKINPORTL;
        public string COLORSTKOUTPORTL;
        public string COLORSTKBIDIRECTIONPORT;

        public string hostName;

        public int scaleX;
        public int scaleY;
        public int scaleZ;

//        public string outputPath;

        public Dictionary<string, string> r;
        #endregion

        #region Constructor
        public Info()
        {
            cells = new List<Cell>();
            inlineStocker = new List<InlineStocker>();
            linearMotor = new List<LinearMotor>();
            resource = new Dictionary<string, int>();
            resourceType = new Dictionary<string, string>();

            minRow = 99999;
            minCol = 99999;
            maxRow = 0;
            maxCol = 0;

            hostName = "";

            scaleX = 1;
            scaleY = 1;
            scaleZ = 1;

//            outputPath = "";

            r = new Dictionary<string, string>();
        }
        #endregion

        #region Methods
        public int countResource(string t)
        {
            return resource[t];
        }

        public void checkRow(int row)
        {
            if (row > maxRow)
                maxRow = row;
            if (row < minRow)
                minRow = row;
        }

        public void checkCol(int col)
        {
            if (col > maxCol)
                maxCol = col;
            if (col < minCol)
                minCol = col;
        }
        public void addCell(Cell c)
        {
            cells.Add(c);
            if (c.row < minRow)
                minRow = c.row;
            if (c.row > maxRow)
                maxRow = c.row;
            if (c.col < minCol)
                minCol = c.col;
            if (c.col > maxCol)
                maxCol = c.col;
        }
        public void addResource(Cell c)
        {
            if (resource.ContainsKey(c.value))
                resource[c.value]++;
            else
            {
                resource.Add(c.value, 1);
                if (c.c.Name == COLORIOPORT)
                    resourceType.Add(c.value, "u");
                else
                    resourceType.Add(c.value, "b");
            }
        }
        #endregion
    }
}