﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;

namespace ExcelLayout
{
    [ComVisible(true)]
    [Guid("F9DAF250-F40B-4305-BDE4-8C0D6351F252")]
    public class VIPInterface
    {
        #region Variables
        Info data;

        private string COLORSINGLECRANEPATH;
        private string COLORDUALCRANEPATH;
        private string COLORCONVEYORBELT;
        private string COLORCONVEYORCORNER;
        private string COLORLINEARMOTORLINE;
        private string COLORLINEARMOTORBUFFER;
        private string COLORSHELF;
        private string COLORIOPORT;
        private string COLORBIINPORT;
        private string COLORBIOUTPORT;
        private string COLORUNIINLINE;
        private string COLORBIINLINE;
        private string COLORSTKINPORTC;
        private string COLORSTKOUTPORTC;
        private string COLORSTKINPORTL;
        private string COLORSTKOUTPORTL;
        private string COLORSTKBIDIRECTIONPORT;

        private Dictionary<string, int> resourceCount;
        private Dictionary<string, string> resource3DModel;
        private List<string> stkList;
        private List<string> V_stkList;
        private List<string> conveyorList;
        private List<string> V_conveyorList;
        private List<string> eqpList;
        private List<string> V_eqpList;
        private List<string> V_eqpType;
        private List<string> V_eqpLocation;
        private List<string> V_portType;
        private List<string> V_shelfLocation;
        private List<string>V_queueLocation;
        private List<string> V_queue;
        private List<string> V_resourceList;
        private List<string> V_stkportLocation;
        private string V_numBuffer;
        private string V_buffer;
        private string V_bufferLocation;
        private string moveToDeliverSTK;
        private string moveToDeliverCNV;
        private string workOk;
        private string vehicleIndex;
        private string rsrcConfig;
        private string tempStr;

        private string hostName;

        private Dictionary<Cell, string> convQueue;

        private int scaleX;
        private int scaleY;
        private int scaleZ;

        private string outputPath;

        private int minx;
        private int miny;
        private int maxx;
        private int maxy;

        private string strDir;
        private string strPath;
        private string inputText;

        private List<string> systemList;
        #endregion

        #region Constructor
        public VIPInterface(Info data)
        {
            this.data = data;

            COLORSINGLECRANEPATH = data.COLORSINGLECRANEPATH;
            COLORDUALCRANEPATH = data.COLORDUALCRANEPATH;
            COLORCONVEYORBELT = data.COLORCONVEYORBELT;
            COLORCONVEYORCORNER = data.COLORCONVEYORCORNER;
            COLORLINEARMOTORLINE = data.COLORLINEARMOTORLINE;
            COLORLINEARMOTORBUFFER = data.COLORLINEARMOTORBUFFER;
            COLORSHELF = data.COLORSHELF;
            COLORIOPORT = data.COLORIOPORT;
            COLORBIINPORT = data.COLORBIINPORT;
            COLORBIOUTPORT = data.COLORBIOUTPORT;
            COLORUNIINLINE = data.COLORUNIINLINE;
            COLORBIINLINE = data.COLORBIINLINE;
            COLORSTKINPORTC = data.COLORSTKINPORTC;
            COLORSTKOUTPORTC = data.COLORSTKOUTPORTC;
            COLORSTKINPORTL = data.COLORSTKINPORTL;
            COLORSTKOUTPORTL = data.COLORSTKOUTPORTL;
            COLORSTKBIDIRECTIONPORT = data.COLORSTKBIDIRECTIONPORT;

            resourceCount = new Dictionary<string, int>();
            resource3DModel = data.r;

            stkList = new List<string>();
            V_stkList = new List<string>();
            conveyorList = new List<string>();
            V_conveyorList = new List<string>();
            eqpList = new List<string>();
            V_eqpList = new List<string>();
            V_eqpType = new List<string>();
            V_eqpLocation = new List<string>();
            V_portType = new List<string>();
            V_shelfLocation = new List<string>();
            V_queueLocation = new List<string>();
            V_queue = new List<string>();
            V_resourceList = new List<string>();
            V_stkportLocation = new List<string>();
            V_numBuffer = "";
            V_buffer = "";
            V_bufferLocation = "";
            moveToDeliverSTK = "";
            moveToDeliverCNV = "";
            workOk = "";
            vehicleIndex = "";
            rsrcConfig = "";
            tempStr = "";

            hostName = data.hostName;

            convQueue = new Dictionary<Cell, string>();

            scaleX = data.scaleX;
            scaleY = data.scaleY;
            scaleZ = data.scaleZ;

            minx = data.minCol;
            miny = data.minRow;
            maxx = data.maxCol;
            maxy = data.maxRow;

            this.outputPath = data.outputPath;

            systemList = new List<string>();
        }
        #endregion

        #region Methods
        public void export()
        {
            strDir = outputPath + "\\projectName.arc";

            Dictionary<string, string> queue = new Dictionary<string, string>();
            Dictionary<string, int> resources = new Dictionary<string, int>();
            List<string> resourceList = new List<string>();

            foreach (InlineStocker STK in data.inlineStocker)
            {
                if (STK.type == "single")
                {
                    stkList.Add(STK.name);
                }
                else
                {
                    stkList.Add(STK.name + "_1");
                    stkList.Add(STK.name + "_2");
                }
            }

            Dictionary<int, LinearMotor> temp = new Dictionary<int, LinearMotor>();
            data.linearMotor.Sort(
                delegate(
                    LinearMotor first,
                    LinearMotor second)
                {
                    return first.name.CompareTo(second.name);
                }
            );
            conveyorList.Sort(
                delegate(
                    string first,
                    string second)
                {
                    return first.CompareTo(second);
                }
            );
            foreach (LinearMotor LM in data.linearMotor)
            {
                conveyorList.Add(LM.name);
                if (LM.startCell.c.Name == COLORSTKBIDIRECTIONPORT)
                {
                    string name = "CNV" + (data.linearMotor.Count + temp.Count + 1);
                    //conveyorList.Add(name);
                    Cell startCell = LM.endCell;
                    Cell endCell = LM.startCell;
                    List<Cell> bufferList = new List<Cell>();
                    foreach (Cell c in LM.bufferList)
                    {
                        bufferList.Insert(0, c);
                    }
                    temp.Add(data.linearMotor.IndexOf(LM), new LinearMotor(name, LM.type, startCell, endCell, bufferList));
                }
            }
            foreach (LinearMotor LM in temp.Values)
            {
                data.linearMotor.Add(LM);
                conveyorList.Add(LM.name);
                //data.linearMotor.Insert(index + 1, temp[index]);
            }

            #region Inline Stocker
            foreach (InlineStocker STK in data.inlineStocker)
            {
                string systemConfig = "";
                string controlPoint = "";
                string workList = "";
                string nameList = "";
                string vehicleConfig = "";

                int countBuffer = 0;
                int countInport = 0;
                int countOutport = 0;
                int countAll = 0;

                //process system에 queue 생성
                queue.Add(STK.name, "");

                if (STK.type == "single")
                {
                    //V_stkList에 추가
                    tempStr = "" + (stkList.IndexOf(STK.name) + 1) + STK.name;
                    V_stkList.Add(tempStr);

                    //move to deliver 추가
                    moveToDeliverSTK += makeMoveToDeliverSingleSTK(STK.name);
                }
                else
                {
                    //V_stkList에 추가
                    tempStr = "" + (stkList.IndexOf(STK.name + "_1") + 1) + '/' + STK.name;
                    V_stkList.Add(tempStr);
                    tempStr = "" + (stkList.IndexOf(STK.name + "_2") + 1) + '/' + STK.name;
                    V_stkList.Add(tempStr);

                    //move to deliver 추가
                    moveToDeliverSTK += makeMoveToDeliverDualSTK(STK.name + "_1");
                    moveToDeliverSTK += makeMoveToDeliverDualSTK(STK.name + "_2");
                }

                //path의 위치
                double bx, by, ex, ey;

                if (STK.direction == "horizontal")
                {
                    bx = (STK.startCell.col - minx) * scaleX - 1.0 / 2.0 * scaleX;
                    by = -1 * ((STK.startCell.row - miny) * scaleY);
                    ex = bx + (STK.endCell.col - STK.startCell.col + 1) * scaleX;
                    ey = by;
                }
                else
                {
                    bx = (STK.startCell.col - minx) * scaleX;
                    by = -1 * ((STK.startCell.row - miny - 1) * scaleY + 1.0 / 2.0 * scaleY);
                    ex = bx + (STK.endCell.col - STK.startCell.col) * scaleX;
                    ey = by - (STK.endCell.row - STK.startCell.row + 1) * scaleY;
                }

                string zeroBX = "";
                string zeroEX = "";
                string zeroBY = "";
                string zeroEY = "";

                if (bx == 0)
                    zeroBX = ".0";
                if (by == 0)
                    zeroBY = ".0";
                if (ex == 0)
                    zeroEX = ".0";
                if (ey == 0)
                    zeroEY = ".0";

                //path 설정
                string path = "GPATH name path1 two piece begx " + bx + zeroBX + " begy " + by + zeroBY + " endx " + ex + zeroEX + " endy " + ey + zeroEY + " upz 1\r\n";

                //shelf와 port
                foreach (Cell cell in STK.cells)
                {
                    string cp = "";
                    int side = findSide(STK, cell);
                    string type = findType(cell);

                    if (type != "bidirectionport")
                    {
                        //queue
                        queue[STK.name] += "dis " + ++countAll + " Stacking OTT_LDDISP\r\n";
                        queue[STK.name] += "\tpicpos begx " + (cell.col - minx) * scaleX + " begy " + (cell.row - miny) * scaleY * -1;
                        String q2 = " endx " + ((cell.col - minx) * scaleX) + " endy " + ((cell.row - miny) * scaleY) * -1;
                        if (cell.sheet > 1)
                        {
                            queue[STK.name] += " begz " + (cell.sheet - 1) * scaleZ;
                            q2 += " endz " + ((cell.sheet - 1) * scaleZ);
                        }
                        queue[STK.name] += q2;
                        queue[STK.name] += " upz 0.5 scx 0.5 scy 0.5 scz 0.5\r\n";

                        //control point, work list, name list, variable

                        if (type == "shelf")
                        {
                            cp = "cp_buffer_" + side + "_" + cell.sheet + "_" + ++countBuffer;
                            controlPoint += makeControlPoint(STK.direction, cp, cell.row, cell.col, STK.startCell.row, STK.startCell.col, scaleX, scaleY);
                            workList += "WORKLST name " + cp + " Oldest item All\r\n";

                            if (STK.type == "single")
                            {
                                tempStr = "" + (stkList.IndexOf(STK.name) + 1) + ", " + countBuffer + ") to \"" + STK.name + ":" + cp;
                                V_shelfLocation.Add(tempStr);
                            }
                            else
                            {
                                tempStr = "" + (stkList.IndexOf(STK.name + "_1") + 1) + ", " + countBuffer + ") to \"" + STK.name + "_1:" + cp;
                                V_shelfLocation.Add(tempStr);
                                tempStr = "" + (stkList.IndexOf(STK.name + "_2") + 1) + ", " + countBuffer + ") to \"" + STK.name + "_2:" + cp;
                                V_shelfLocation.Add(tempStr);
                            }
                        }
                        else if (type == "eqp")
                        {
                            if (!resourceCount.ContainsKey("T" + cell.value))
                            {
                                eqpList.Add("T" + cell.value);
                                tempStr = "" + (eqpList.IndexOf("T" + cell.value) + 1) + ") to \"T" + cell.value;
                                V_eqpList.Add(tempStr); 
                                resourceCount.Add("T" + cell.value, 0);
                                rsrcConfig += "RSRC name R_" + resourceCount.Count + " 10 cap 10 prtime con 5 Seconds stream stream_R_" + resourceCount.Count + "_1\r\n";

                                ///////////////////////////////////////////

                                if (STK.direction == "horizontal")
                                {
                                    if (cell.row < STK.startCell.row)
                                    {
                                        rsrcConfig += " dis 1 picpos begx " + scaleX * (cell.col - minx + 0.5) + " begy " + -1 * scaleY * (cell.row - miny - 1.5);
                                        rsrcConfig += " endx " + scaleX * (cell.col - minx + 1.5) + " endy " + -1 * scaleY * (cell.row - miny - 1.5);
                                    }
                                    else
                                    {
                                        rsrcConfig += " dis 1 picpos begx " + scaleX * (cell.col - minx + 0.5) + " begy " + -1 * scaleY * (cell.row - miny + 1.5);
                                        rsrcConfig += " endx " + scaleX * (cell.col - minx + 1.5) + " endy " + -1 * scaleY * (cell.row - miny + 1.5);
                                    }
                                }
                                else
                                {
                                    if (cell.col < STK.startCell.col)
                                    {
                                        rsrcConfig += " dis 1 picpos begx " + scaleX * (cell.col - minx - 1.5) + " begy " + -1 * scaleY * (cell.row - miny - 0.5);
                                        rsrcConfig += " endx " + scaleX * (cell.col - minx - 0.5) + " endy " + -1 * scaleY * (cell.row - miny - 0.5);
                                    }
                                    else
                                    {
                                        rsrcConfig += " dis 1 picpos begx " + scaleX * (cell.col - minx + 1.5) + " begy " + -1 * scaleY * (cell.row - miny - 0.5);
                                        rsrcConfig += " endx " + scaleX * (cell.col - minx + 2.5) + " endy " + -1 * scaleY * (cell.row - miny - 0.5);
                                    }
                                }

                                rsrcConfig += " UserDef template Meters\r\n";
                                rsrcConfig += "310 1\r\n";

                                if (cell.c.Name == COLORBIINPORT)
                                {
                                    rsrcConfig += "4 4 0 1 1 none\r\n";
                                }
                                else
                                {
                                    rsrcConfig += "3 3 0 1 1 none\r\n";
                                }
                                rsrcConfig += "4 4 4 4 4 0 0\r\n";
                                rsrcConfig += "end\r\n";

                                ///////////////////////////////////////////



                                if (cell.c.Name == COLORIOPORT)
                                    V_eqpType += "	set V_eqpType(" + (eqpList.IndexOf("T" + cell.value) + 1) + ") to \"u\"\r\n";
                                else
                                    V_eqpType += "	set V_eqpType(" + (eqpList.IndexOf("T" + cell.value) + 1) + ") to \"b\"\r\n";

                                V_resourceList += "	set V_resourceList(" + (eqpList.IndexOf("T" + cell.value) + 1) + ") to R_" + resourceCount.Count + "(1)\r\n";
                            }


                            cp = "cp_T" + cell.value + "_" + side + "_" + cell.sheet + "_" + ++resourceCount["T" + cell.value];
                            controlPoint += makeControlPoint(STK.direction, cp, cell.row, cell.col, STK.startCell.row, STK.startCell.col, scaleX, scaleY);
                            workList += "WORKLST name " + cp + " Oldest item All\r\n";

                            //variable
                            if (STK.type == "single")
                            {
                                V_eqpLocation += "	set V_eqpLocation(" + (eqpList.IndexOf("T" + cell.value) + 1) + ", " + resourceCount["T" + cell.value] + ", 1) to \"" + STK.name + ":" + cp + "\"\r\n";
                            }
                            else
                            {
                                V_eqpLocation += "	set V_eqpLocation(" + (eqpList.IndexOf("T" + cell.value) + 1) + ", " + resourceCount["T" + cell.value] + ", 1) to \"" + STK.name + "_1:" + cp + "\"\r\n";
                                V_eqpLocation += "	set V_eqpLocation(" + (eqpList.IndexOf("T" + cell.value) + 1) + ", " + resourceCount["T" + cell.value] + ", 2) to \"" + STK.name + "_2:" + cp + "\"\r\n";
                            }

                            if (cell.c.Name == COLORIOPORT)
                                V_portType += "	set V_portType(" + (eqpList.IndexOf("T" + cell.value) + 1) + ", " + resourceCount["T" + cell.value] + ") to \"io\"\r\n";
                            else if (cell.c.Name == COLORBIINPORT)
                                V_portType += "	set V_portType(" + (eqpList.IndexOf("T" + cell.value) + 1) + ", " + resourceCount["T" + cell.value] + ") to \"i\"\r\n";
                            else
                                V_portType += "	set V_portType(" + (eqpList.IndexOf("T" + cell.value) + 1) + ", " + resourceCount["T" + cell.value] + ") to \"o\"\r\n";
                        }
                        else if (type == "inport")
                        {
                            cp = "cp_inport_" + side + "_" + cell.sheet + "_" + ++countInport;
                            controlPoint += makeControlPoint(STK.direction, cp, cell.row, cell.col, STK.startCell.row, STK.startCell.col, scaleX, scaleY);
                            workList += "WORKLST name " + cp + " Oldest item All\r\n";
                            if (countInport * countOutport == 0)
                                nameList += "NAMELST name start\r\nNAMELST name start item " + cp + "\r\n";

                            if (cell.value != "")
                            {
                                conveyorList.Add(cell.value);
                                if (STK.type == "single")
                                {
                                    V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name) + 1) + ", " + (conveyorList.Count) + ") to \"" + STK.name + ":" + cp + "\"\r\n";
                                }
                                else
                                {
                                    V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name + "_1") + 1) + ", " + (conveyorList.Count) + ") to \"" + STK.name + "_1:" + cp + "\"\r\n";
                                    V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name + "_2") + 1) + ", " + (conveyorList.Count) + ") to \"" + STK.name + "_2:" + cp + "\"\r\n";
                                }
                            }
                            else
                            {
                                string conv = "";
                                foreach (LinearMotor LM in data.linearMotor)
                                    if (LM.endCell.c.Name != COLORSTKBIDIRECTIONPORT && (cell.sheet == LM.endCell.sheet && cell.row == LM.endCell.row && cell.col == LM.endCell.col))
                                        conv = LM.name;
                                if (STK.type == "single")
                                {
                                    V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name) + 1) + ", " + (conveyorList.IndexOf(conv) + 1) + ") to \"" + STK.name + ":" + cp + "\"\r\n";
                                }
                                else
                                {
                                    V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name + "_1") + 1) + ", " + (conveyorList.IndexOf(conv) + 1) + ") to \"" + STK.name + "_1:" + cp + "\"\r\n";
                                    V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name + "_2") + 1) + ", " + (conveyorList.IndexOf(conv) + 1) + ") to \"" + STK.name + "_2:" + cp + "\"\r\n";
                                }

                            }
                        }
                        else if (type == "outport")
                        {
                            cp = "cp_outport_" + side + "_" + cell.sheet + "_" + ++countOutport;
                            controlPoint += makeControlPoint(STK.direction, cp, cell.row, cell.col, STK.startCell.row, STK.startCell.col, scaleX, scaleY);
                            workList += "WORKLST name " + cp + " Oldest item All\r\n";
                            if (countInport * countOutport == 0)
                                nameList += "NAMELST name start\r\nNAMELST name start item " + cp + "\r\n";

                            string conv = "";
                            foreach (LinearMotor LM in data.linearMotor)
                                if (LM.startCell.c.Name != COLORSTKBIDIRECTIONPORT && (cell.sheet == LM.startCell.sheet && cell.row == LM.startCell.row && cell.col == LM.startCell.col))
                                    conv = LM.name;
                            if (STK.type == "single")
                            {
                                V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name) + 1) + ", " + (conveyorList.IndexOf(conv) + 1) + ") to \"" + STK.name + ":" + cp + "\"\r\n";
                            }
                            else
                            {
                                V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name + "_1") + 1) + ", " + (conveyorList.IndexOf(conv) + 1) + ") to \"" + STK.name + "_1:" + cp + "\"\r\n";
                                V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name + "_2") + 1) + ", " + (conveyorList.IndexOf(conv) + 1) + ") to \"" + STK.name + "_2:" + cp + "\"\r\n";
                            }

                        }

                        //guqueLocation이랑 queue 생성
                        if (STK.type == "single")
                        {
                            V_queueLocation += "	set V_queueLocation(" + (stkList.IndexOf(STK.name) + 1) + ", " + countAll + ") to \"" + STK.name + ":" + cp + "\"\r\n";
                            V_queue += "	set V_queue(" + (stkList.IndexOf(STK.name) + 1) + ", " + countAll + ") to Q_" + int.Parse(STK.name.Substring(1, 2)) + "(" + countAll + ")\r\n";
                        }
                        else
                        {
                            V_queueLocation += "	set V_queueLocation(" + (stkList.IndexOf(STK.name + "_1") + 1) + ", " + countAll + ") to \"" + STK.name + "_1:" + cp + "\"\r\n";
                            V_queueLocation += "	set V_queueLocation(" + (stkList.IndexOf(STK.name + "_2") + 1) + ", " + countAll + ") to \"" + STK.name + "_2:" + cp + "\"\r\n";
                            V_queue += "	set V_queue(" + (stkList.IndexOf(STK.name + "_1") + 1) + ", " + countAll + ") to Q_" + int.Parse(STK.name.Substring(1, 2)) + "(" + countAll + ")\r\n";
                        }

                        if (((cell.c.Name == COLORSTKINPORTC || cell.c.Name == COLORSTKINPORTL) && cell.value == "") || cell.c.Name == COLORSTKBIDIRECTIONPORT)
                            convQueue.Add(cell, "Q_" + int.Parse(STK.name.Substring(1, 2)) + "(" + countAll + ")");
                    }
                    else //(type == "bidirectionport")
                    {
                        //역방향
                        //queue
                        queue[STK.name] += "dis " + ++countAll + " Stacking OTT_LDDISP\r\n";
                        queue[STK.name] += "\tpicpos begx " + (cell.col - minx) * scaleX + " begy " + (cell.row - miny) * scaleY * -1;
                        String q2 = " endx " + ((cell.col - minx) * scaleX) + " endy " + ((cell.row - miny) * scaleY) * -1;
                        if (cell.sheet > 1)
                        {
                            queue[STK.name] += " begz " + (cell.sheet - 1) * scaleZ;
                            q2 += " endz " + ((cell.sheet - 1) * scaleZ);
                        }
                        queue[STK.name] += q2;
                        queue[STK.name] += " upz 0.5 scx 0.5 scy 0.5 scz 0.5\r\n";

                        //control point, work list, name list, variable
                        cp = "cp_inport_" + side + "_" + cell.sheet + "_" + ++countInport;
                        controlPoint += makeControlPoint(STK.direction, cp, cell.row, cell.col, STK.startCell.row, STK.startCell.col, scaleX, scaleY);
                        if (countInport * countOutport == 0)
                            nameList += "NAMELST name start\r\nNAMELST name start item " + cp + "\r\n";
                        workList += "WORKLST name " + cp + " Oldest item All\r\n";

                        string conv = "";
                        foreach (LinearMotor LM in data.linearMotor)
                            if (cell.sheet == LM.endCell.sheet && cell.row == LM.endCell.row && cell.col == LM.endCell.col)
                                conv = LM.name;
                        if (cell.value != "")
                        {
                            if (STK.type == "single")
                            {
                                V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name) + 1) + ", " + (conveyorList.IndexOf(conv) + 1) + ") to \"" + STK.name + cp + "\"\r\n";
                            }
                            else
                            {
                                V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name + "_1") + 1) + ", " + (conveyorList.IndexOf(conv) + 1) + ") to \"" + STK.name + "_1:" + cp + "\"\r\n";
                                V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name + "_2") + 1) + ", " + (conveyorList.IndexOf(conv) + 1) + ") to \"" + STK.name + "_2:" + cp + "\"\r\n";
                            }
                        }
                        else
                        {
                            if (STK.type == "single")
                            {
                                V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name) + 1) + ", " + (conveyorList.IndexOf(conv) + 1) + ") to \"" + STK.name + cp + "\"\r\n";
                            }
                            else
                            {
                                V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name + "_1") + 1) + ", " + (conveyorList.IndexOf(conv) + 1) + ") to \"" + STK.name + "_1:" + cp + "\"\r\n";
                                V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name + "_2") + 1) + ", " + (conveyorList.IndexOf(conv) + 1) + ") to \"" + STK.name + "_2:" + cp + "\"\r\n";
                            }
                        }

                        //guqueLocation이랑 queue 생성
                        if (STK.type == "single")
                        {
                            V_queueLocation += "	set V_queueLocation(" + (stkList.IndexOf(STK.name) + 1) + ", " + countAll + ") to \"" + STK.name + cp + "\"\r\n";
                            V_queue += "	set V_queue(" + (stkList.IndexOf(STK.name) + 1) + ", " + countAll + ") to Q_" + int.Parse(STK.name.Substring(1, 2)) + "(" + countAll + ")\r\n";
                        }
                        else
                        {
                            V_queueLocation += "	set V_queueLocation(" + (stkList.IndexOf(STK.name + "_1") + 1) + ", " + countAll + ") to \"" + STK.name + "_1:" + cp + "\"\r\n";
                            V_queueLocation += "	set V_queueLocation(" + (stkList.IndexOf(STK.name + "_2") + 1) + ", " + countAll + ") to \"" + STK.name + "_2:" + cp + "\"\r\n";
                            V_queue += "	set V_queue(" + (stkList.IndexOf(STK.name + "_1") + 1) + ", " + countAll + ") to Q_" + int.Parse(STK.name.Substring(1, 2)) + "(" + countAll + ")\r\n";
                        }


                        //if ((cell.c.Name == COLORSTKINPORT && cell.value == "") || cell.c.Name == COLORSTKBIDIRECTIONPORT)
                        //    convQueue.Add(cell, "Q_" + int.Parse(STK.name.Substring(1, 2)) + "(" + countAll + ")");


                        //정방향?
                        //queue
                        if (cell.c.Name == COLORSTKBIDIRECTIONPORT)
                        {
                            queue[STK.name] += "dis " + ++countAll + " Stacking OTT_LDDISP\r\n";
                            queue[STK.name] += "\tpicpos begx " + (cell.col - minx) * scaleX + " begy " + (cell.row - miny) * scaleY * -1;
                            q2 = " endx " + ((cell.col - minx) * scaleX) + " endy " + ((cell.row - miny) * scaleY) * -1;
                            if (cell.sheet > 1)
                            {
                                queue[STK.name] += " begz " + (cell.sheet - 1) * scaleZ;
                                q2 += " endz " + ((cell.sheet - 1) * scaleZ);
                            }
                            queue[STK.name] += q2;
                            queue[STK.name] += " upz 0.5 scx 0.5 scy 0.5 scz 0.5\r\n";
                        }

                        //control point, work list, name list, variable
                        cp = "cp_outport_" + side + "_" + cell.sheet + "_" + ++countOutport;
                        controlPoint += makeControlPoint(STK.direction, cp, cell.row, cell.col, STK.startCell.row, STK.startCell.col, scaleX, scaleY);
                        if (countInport * countOutport == 0)
                            nameList += "NAMELST name start\r\nNAMELST name start item " + cp + "\r\n";
                        workList += "WORKLST name " + cp + " Oldest item All\r\n";

                        conv = "";
                        foreach (LinearMotor LM in data.linearMotor)
                            if (cell.sheet == LM.startCell.sheet && cell.row == LM.startCell.row && cell.col == LM.startCell.col)
                                conv = LM.name;
                        if (cell.value != "")
                        {
                            if (STK.type == "single")
                            {
                                V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name) + 1) + ", " + (conveyorList.IndexOf(conv) + 1) + ") to \"" + STK.name + cp + "\"\r\n";
                            }
                            else
                            {
                                V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name + "_1") + 1) + ", " + (conveyorList.IndexOf(conv) + 1) + ") to \"" + STK.name + "_1:" + cp + "\"\r\n";
                                V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name + "_2") + 1) + ", " + (conveyorList.IndexOf(conv) + 1) + ") to \"" + STK.name + "_2:" + cp + "\"\r\n";
                            }
                        }
                        else
                        {
                            if (STK.type == "single")
                            {
                                V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name) + 1) + ", " + (conveyorList.IndexOf(conv) + 1) + ") to \"" + STK.name + cp + "\"\r\n";
                            }
                            else
                            {
                                V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name + "_1") + 1) + ", " + (conveyorList.IndexOf(conv) + 1) + ") to \"" + STK.name + "_1:" + cp + "\"\r\n";
                                V_stkportLocation += "	set V_stkportLocation(" + (stkList.IndexOf(STK.name + "_2") + 1) + ", " + (conveyorList.IndexOf(conv) + 1) + ") to \"" + STK.name + "_2:" + cp + "\"\r\n";
                            }
                        }

                        //guqueLocation이랑 queue 생성
                        if (STK.type == "single")
                        {
                            V_queueLocation += "	set V_queueLocation(" + (stkList.IndexOf(STK.name) + 1) + ", " + countAll + ") to \"" + STK.name + cp + "\"\r\n";
                            V_queue += "	set V_queue(" + (stkList.IndexOf(STK.name) + 1) + ", " + countAll + ") to Q_" + int.Parse(STK.name.Substring(1, 2)) + "(" + countAll + ")\r\n";
                        }
                        else
                        {
                            V_queueLocation += "	set V_queueLocation(" + (stkList.IndexOf(STK.name + "_1") + 1) + ", " + countAll + ") to \"" + STK.name + "_1:" + cp + "\"\r\n";
                            V_queueLocation += "	set V_queueLocation(" + (stkList.IndexOf(STK.name + "_2") + 1) + ", " + countAll + ") to \"" + STK.name + "_2:" + cp + "\"\r\n";
                            V_queue += "	set V_queue(" + (stkList.IndexOf(STK.name + "_1") + 1) + ", " + countAll + ") to Q_" + int.Parse(STK.name.Substring(1, 2)) + "(" + countAll + ")\r\n";
                        }


                    }

                }

                //vehicle config
                vehicleConfig += "AGVSVEH type DefVehicle cap " + 1 + " pickup " + 3 + " Seconds setdown " + 3 + " Seconds numveh " + 1 + " start start\r\n";
                vehicleConfig += "			load Default \r\n";
                vehicleConfig += "				accel	0 1 Feet Seconds Seconds\r\n";
                vehicleConfig += "				decel	0 1 Feet Seconds Seconds\r\n";
                vehicleConfig += "				vel	0 1.6 Meters Seconds\r\n";
                vehicleConfig += "				crvvel	0 3 Feet Seconds\r\n";
                vehicleConfig += "				sprvel	0 1.6 Meters Seconds\r\n";
                vehicleConfig += "				rvel	0 1.6 Meters Seconds\r\n";
                vehicleConfig += "				rcrvvel	0 3 Feet Seconds\r\n";
                vehicleConfig += "				rsprvel	0 3 Feet Seconds\r\n";
                vehicleConfig += "				crabvel	0 3 Feet Seconds\r\n";
                vehicleConfig += "				rotate	0 2 Seconds\r\n";
                vehicleConfig += "				brakedist	0 4.5 Feet\r\n";
                vehicleConfig += "				stopdist	0 0 Feet\r\n";
                vehicleConfig += "			load Empty \r\n";
                vehicleConfig += "				accel	1 0 Feet Seconds Seconds\r\n";
                vehicleConfig += "				decel	1 0 Feet Seconds Seconds\r\n";
                vehicleConfig += "				vel	1 0 Feet Seconds\r\n";
                vehicleConfig += "				crvvel	1 0 Feet Seconds\r\n";
                vehicleConfig += "				sprvel	1 0 Feet Seconds\r\n";
                vehicleConfig += "				rvel	1 0 Feet Seconds\r\n";
                vehicleConfig += "				rcrvvel	1 0 Feet Seconds\r\n";
                vehicleConfig += "				rsprvel	1 0 Feet Seconds\r\n";
                vehicleConfig += "				crabvel	1 0 Feet Seconds\r\n";
                vehicleConfig += "				rotate	1 0 Seconds\r\n";
                vehicleConfig += "				brakedist	1 0 Feet\r\n";
                vehicleConfig += "				stopdist	1 0 Feet\r\n";

                //queue 마지막
                queue[STK.name] += " UserDef template Meters\r\n";
                queue[STK.name] += "310 17\r\n";
                queue[STK.name] += "2 2 0 1 0 none\r\n";
                queue[STK.name] += "4 4 4 4 4 0 0\r\n";
                queue[STK.name] += "end\r\n";

                //export
                string systemName = STK.name;
                if (STK.type == "single")
                {
                    systemList.Add(systemName);

                    strPath = strDir + "\\" + STK.name + ".asy";
                    inputText = systemConfig + path + controlPoint + workList + nameList + vehicleConfig;

                    if (!Directory.Exists(strDir))
                    {
                        Directory.CreateDirectory(strDir);
                    }

                    Byte[] info8 = new UTF8Encoding(true).GetBytes(inputText);
                    FileStream fs8 = File.Open(strPath, FileMode.Create);
                    fs8.Write(info8, 0, info8.Length);

                    fs8.Close();
                }
                else
                {
                    systemList.Add(systemName + "_1");
                    systemList.Add(systemName + "_2");

                    strPath = strDir + "\\" + STK.name + "_1.asy";
                    inputText = systemConfig + path + controlPoint + workList + nameList + vehicleConfig;

                    if (!Directory.Exists(strDir))
                    {
                        Directory.CreateDirectory(strDir);
                    }

                    Byte[] info8 = new UTF8Encoding(true).GetBytes(inputText);
                    FileStream fs8 = File.Open(strPath, FileMode.Create);
                    fs8.Write(info8, 0, info8.Length);

                    fs8.Close();

                    strPath = strDir + "\\" + STK.name + "_2.asy";
                    FileStream fs9 = File.Open(strPath, FileMode.Create);
                    fs9.Write(info8, 0, info8.Length);

                    fs9.Close();
                }

                //queue.Add(STK.name + "_2", "QUEUE name Q_" + int.Parse(STK.name.Substring(1)) + "_2 " + countAll + " cap 2147483647\r\n" + queue[STK.name]);
                queue[STK.name] = "QUEUE name Q_" + int.Parse(STK.name.Substring(1)) + " " + countAll + " cap 2147483647\r\n" + queue[STK.name];

            }
            #endregion

            #region Linear Motor
            foreach (LinearMotor cnv in data.linearMotor)
            {
                if (cnv.type == "conv")
                {
                    systemList.Add(cnv.name);
                    V_conveyorList += "	set V_conveyorList(" + (data.linearMotor.IndexOf(cnv) + 1) + ") to \"" + cnv.name + "\"\r\n";
                    string config = "";
                    string nexts = "";
                    string config2 = "";
                    string sections = "";
                    string config3 = "";
                    string tran = "";

                    List<Cell> points = new List<Cell>();
                    points.Add(cnv.startCell);
                    foreach (Cell c in cnv.bufferList)
                        points.Add(c);
                    points.Add(cnv.endCell);

                    config += "SYSTYPE Conveyor\r\n";
                    config += "UNITS Meters Seconds\r\n";
                    config += "SYSDEF limit Infinite timeout 60 Seconds confname Config1\r\n";
                    config += "FLAGS System NoColor\r\n";
                    config += "	Text NoColor Sections GTemplate NoColor SectionNames NoColor Direction NoColor Stations NoColor StationNames NoColor\r\n";
                    config += "	Transfers NoColor Loads NoColor Photoeyes NoColor PhotoeyeNames NoColor FixedInterval NoColor\r\n";
                    config += "CONVDEF UserId 7\r\n";

                    nexts += "	NEXTSEC name sec" + points.Count + " type DefaultSection\r\n";
                    nexts += "	NEXTSTA name sta3 type DefaultStation\r\n";
                    nexts += "	NEXTTRAN name tran" + (2 * (points.Count - 1) - 1) + " type DefaultTransfer\r\n";
                    nexts += "	NEXTMOTOR name motor1 type DefaultMotor\r\n";
                    nexts += "	NEXTPHOTOEYE name photoeye1 type DefaultPhotoeye\r\n";
                    nexts += "	ALTERNATE NONE EXTRASECTIONWIDTH 0 Meters\r\n";

                    config2 += "CONVTOL minang 450 maxang 1350\r\n";
                    config2 += "CONVMOTORTYPE name DefaultMotor\r\n";
                    config2 += "CONVMOTOR name M_sec1 type DefaultMotor\r\n";
                    config2 += "CONVSECTIONTYPE name DefaultSection motor M_sec1 width 2 Meters vel " + 0.3 + " Meters Seconds acc " + 0.3 + " Meters Seconds Seconds dec " + 0.3 + " Meters Seconds Seconds accum load stopsize 1 0 Meters movesize 1 0 Meters inductsize 1 0 Meters fixed 0 Meters align centered_in_interval nav 1\r\n";

                    //int lastPosition = 0;
                    int length = 0;
                    Boolean horizontal = true;

                    for (int i = 1; i < points.Count; i++)
                    {
                        Cell startCell = points[i - 1];
                        Cell endCell = points[i];

                        double bx = 0.0;
                        double by = 0.0;
                        double ex = 0.0;
                        double ey = 0.0;


                        //double addY = 0;

                        //string direction = "horizontal";

                        if (startCell.row == endCell.row)
                        {
                            if (i == points.Count - 1)
                            {
                                horizontal = true;
                            }
                            length = scaleX * Math.Abs(endCell.col - startCell.col);
                            if (startCell.col < endCell.col)    //좌->우
                            {
                                bx = scaleX * (startCell.col - minx - 0.5);
                                by = -1 * scaleY * (startCell.row - miny);
                                ex = bx + scaleX * (endCell.col - startCell.col + 1);
                                ey = by;
                            }
                            else //우->좌
                            {
                                bx = scaleX * (startCell.col - minx + 0.5);
                                by = -1 * scaleY * (startCell.row - miny);
                                ex = bx + (endCell.col - startCell.col - 1) * scaleX;
                                ey = by;
                            }
                        }
                        if (startCell.col == endCell.col)
                        {
                            if (i == points.Count - 1)
                            {
                                horizontal = false;
                            }
                            length = scaleY * Math.Abs(endCell.row - startCell.row);
                            if (startCell.row < endCell.row)    //상->하
                            {
                                bx = (startCell.col - minx) * scaleX;
                                by = -1 * scaleY * (startCell.row - miny - 0.5);
                                ex = bx;
                                ey = by - scaleY * (endCell.row - startCell.row + 1);
                            }
                            else //하->상
                            {
                                bx = (startCell.col - minx) * scaleX;
                                by = -1 * scaleY * (startCell.row - miny + 0.5);
                                ex = bx;
                                ey = by - scaleY * (endCell.row - startCell.row - 1);
                            }

                        }

                        sections += "CONVSECTION name sec" + i + " type DefaultSection ";

                        if (i == 0)
                        {
                            sections += "motor M_sec1 ";
                        }
                        sections += "piece begx " + bx + " begy " + by + " endx " + ex + " endy " + ey + " upz 1\r\n";

                        tran += "CONVTRANSFER name tran" + (2 * i - 1) + " type DefaultTransfer from sec" + i + " " + (length) + " to sec" + (i + 1) + " 1\r\n";
                        tran += "CONVTRANSFER name tran" + (2 * i) + " type DefaultTransfer from sec" + i + " " + (length) + " to sec" + (i + 1) + " 0\r\n";
                    }

                    config3 += "CONVSTATIONTYPE name DefaultStation raise 0 Seconds lower 0 Seconds dist 0 Meters release norestriction align leading cap Infinite\r\n";
                    config3 += "CONVSTATION name sta1 type DefaultStation at sec1 1\r\n";
                    if (horizontal)
                    {
                        config3 += "CONVSTATION name sta2 type DefaultStation at sec" + (points.Count - 1) + " " + (length + 0.5 * scaleX) + "\r\n";
                    }
                    else
                    {
                        config3 += "CONVSTATION name sta2 type DefaultStation at sec" + (points.Count - 1) + " " + (length + 0.5 * scaleY) + "\r\n";
                    }
                    config3 += "CONVPHOTOEYETYPE name DefaultPhotoeye blocktimeout 5 Seconds cleartimeout 5 Seconds\r\n";
                    config3 += "CONVTRANSFERTYPE name DefaultTransfer inductsize 1 0 Meters aheadinductsize 1 0 Meters speedadjust Origin starttime 0 Seconds finishtime 0 Seconds style double movemethod movesection\r\n";
                    strPath = strDir + "\\" + cnv.name + ".asy";
                    inputText = config + nexts + config2 + sections + config3 + tran;
                    if (!Directory.Exists(strDir))
                    {
                        Directory.CreateDirectory(strDir);
                    }

                    Byte[] info = new UTF8Encoding(true).GetBytes(inputText);
                    FileStream fs = File.Open(strPath, FileMode.Create);
                    fs.Write(info, 0, info.Length);
                    fs.Close();
                }
                else
                {
                    string systemConfig = "";
                    string path = "";
                    string controlPoint = "";
                    string workList = "";
                    string vehicleConfig = "";

                    int countAll = 0;

                    List<Cell> buffers = new List<Cell>();
                    buffers.Add(cnv.startCell);
                    foreach (Cell cell in cnv.bufferList)
                        buffers.Add(cell);
                    buffers.Add(cnv.endCell);

                    //system list에 추가
                    systemList.Add(cnv.name);

                    //V_conveyorList에 추가
                    V_conveyorList += "	set V_conveyorList(" + (conveyorList.IndexOf(cnv.name) + 1) + ") to \"" + cnv.name + "\"\r\n";

                    //V_numBuffer에 추가
                    V_numBuffer += "	set V_numBuffer(" + (conveyorList.IndexOf(cnv.name) + 1) + ") to " + (cnv.bufferList.Count + 2) + "\r\n";

                    //V_buffer에 추가
                    V_buffer += "	set V_buffer(" + (conveyorList.IndexOf(cnv.name) + 1) + ", 1) to Q_c" + (conveyorList.IndexOf(cnv.name) + 1) + "(1)\r\n";
                    foreach (Cell cell in cnv.bufferList)
                    {
                        V_buffer += "	set V_buffer(" + (conveyorList.IndexOf(cnv.name) + 1) + ", " + (cnv.bufferList.IndexOf(cell) + 2) + ") to Q_c" + (conveyorList.IndexOf(cnv.name) + 1) + "(" + (cnv.bufferList.IndexOf(cell) + 2) + ")\r\n";
                    }
                    V_buffer += "	set V_buffer(" + (conveyorList.IndexOf(cnv.name) + 1) + ", " + (cnv.bufferList.Count + 2) + ") to Q_c" + (conveyorList.IndexOf(cnv.name) + 1) + "(" + (cnv.bufferList.Count + 2) + ")\r\n";

                    //V_bufferLocation에 추가
                    V_bufferLocation += "	set V_bufferLocation(" + (conveyorList.IndexOf(cnv.name) + 1) + ", 1) to \"" + cnv.name + ":buffer_" + "1\"\r\n";
                    foreach (Cell cell in cnv.bufferList)
                    {
                        V_bufferLocation += "	set V_bufferLocation(" + (conveyorList.IndexOf(cnv.name) + 1) + ", " + (cnv.bufferList.IndexOf(cell) + 2) + ") to \"" + cnv.name + ":buffer_" + (cnv.bufferList.IndexOf(cell) + 2) + "\"\r\n";
                    }
                    V_bufferLocation += "	set V_bufferLocation(" + (conveyorList.IndexOf(cnv.name) + 1) + ", " + (cnv.bufferList.Count + 2) + ") to \"" + cnv.name + ":buffer_" + (cnv.bufferList.Count + 2) + "\"\r\n";

                    //move to deliver 추가
                    moveToDeliverCNV += makeMoveToDeliverCNV(cnv.name);

                    //vehicle index 추가
                    //for (int i = 1; i < (LM.bufferList.Count + 2); i++)
                    //    vehicleIndex += "\tset " + LM.name + ":DefVehicle(" + i + ") A_index to " + i + "\r\n";

                    ////work ok function
                    //workOk += makeWorkOkFunction(LM.name);
                    //if (LM.startCell.c.Name == COLORSTKBIDIRECTIONPORT)
                    //    workOk += makeWorkOkFunction(LM.name + "_2");

                    //system config
                    systemConfig += "SYSTYPE AGVS\r\n";
                    systemConfig += "UNITS Meters Seconds\r\n";
                    systemConfig += "SYSDEF limit Infinite timeout 60 Seconds confname Config1\r\n";
                    systemConfig += "FLAGS System NoColor\r\n";
                    systemConfig += "\tText NoColor Paths GTemplate NoColor PathNames NoColor Direction NoColor ControlPoints NoColor ControlPointNames NoColor\r\n";
                    systemConfig += "\tTransfers NoColor Vehicles NoColor\r\n";
                    systemConfig += "AGVSDEF secname path1 name cp1 UserId 2 cpcap Infinite cprel distance 0 Feet ALTERNATE NONE ResumeSpeedWhenClaimed\r\n";
                    systemConfig += "\t\tvel 0 Infinite Feet Seconds\r\n";
                    systemConfig += "\t\tcrabvel 0 Infinite Feet Seconds\r\n";
                    systemConfig += "\t\tsprvel 0 Infinite Feet Seconds\r\n";
                    systemConfig += "\t\tcrvvel 0 Infinite Feet Seconds\r\n";
                    systemConfig += "AGVSTOL minang 450 maxang 1350\r\n";

                    //process system에 buffer 생성
                    queue.Add(cnv.name, "QUEUE name Q_c" + (conveyorList.IndexOf(cnv.name) + 1) + " " + buffers.Count + " cap 2147483647\r\n");

                    for (int i = 1; i < buffers.Count; i++)
                    {
                        double bx;
                        double by;
                        double ex;
                        double ey;
                        string direction;
                        Cell startCell = buffers.ElementAt(i - 1);
                        Cell endCell = buffers.ElementAt(i);

                        //path 생성
                        if (startCell.row == endCell.row)
                            direction = "horizontal";
                        else
                            direction = "vertical";

                        if (direction == "horizontal")
                        {
                            if (startCell.col < endCell.col)
                            {
                                bx = (startCell.col - minx) * scaleX;
                                by = -1 * ((startCell.row - miny) * scaleY);
                                ex = bx + (endCell.col - startCell.col) * scaleX;
                                ey = by;
                            }
                            else
                            {
                                bx = (startCell.col - minx) * scaleX;
                                by = -1 * ((startCell.row - miny) * scaleY);
                                ex = bx + (endCell.col - startCell.col) * scaleX;
                                ey = by;
                            }
                        }
                        else
                        {
                            if (startCell.row < endCell.row)
                            {
                                bx = (startCell.col - minx) * scaleX;
                                by = -1 * ((startCell.row - miny) * scaleY);
                                ex = bx;
                                ey = by - (endCell.row - startCell.row) * scaleY;
                            }
                            else
                            {
                                bx = (startCell.col - minx) * scaleX;
                                by = -1 * ((startCell.row - miny) * scaleY);
                                ex = bx;
                                ey = by - (endCell.row - startCell.row) * scaleY;
                            }
                        }

                        string zeroBX = "";
                        string zeroEX = "";
                        string zeroBY = "";
                        string zeroEY = "";

                        if (bx == 0)
                            zeroBX = ".0";
                        if (by == 0)
                            zeroBY = ".0";
                        if (ex == 0)
                            zeroEX = ".0";
                        if (ey == 0)
                            zeroEY = ".0";

                        path += "GPATH name path" + i + " two piece begx " + bx + zeroBX + " begy " + by + zeroBY;
                        if (cnv.startCell.sheet != 1)
                        {
                            path += " begz " + (cnv.startCell.sheet - 1) * scaleZ;
                        }
                        path += " endx " + ex + zeroEX + " endy " + ey + zeroEY;
                        if (cnv.startCell.sheet != 1)
                        {
                            path += " endz " + (cnv.startCell.sheet - 1) * scaleZ;
                        }
                        path += " upz 1\r\n";

                        //control point, work list 설정
                        controlPoint += "CPOINT name buffer_" + i + " at path" + i + " 0\r\n";
                        //workList += "WORKLST name buffer_" + i + " Oldest item All\r\n";

                        if (i == buffers.Count - 1)
                        {
                            int k;
                            if (direction == "horizontal")
                                k = (endCell.col - startCell.col) * scaleY;
                            else
                                k = (endCell.row - startCell.row) * scaleX;
                            controlPoint += "CPOINT name buffer_" + (i + 1) + " at path" + i + " " + Math.Abs(k) + "\r\n";
                        }
                    }

                    //workList 생성
                    for (int i = 0; i < buffers.Count; i++)
                    {
                        workList += "WORKLST name buffer_" + (i + 1) + " Oldest item All\r\n";
                    }

                    //queue 생성
                    foreach (Cell cell in cnv.bufferList)
                    {
                        queue[cnv.name] += "dis " + ++countAll + " Stacking OTT_LDDISP\r\n";
                        queue[cnv.name] += "\tpicpos begx " + (cell.col - minx) * scaleX + " begy " + (cell.row - miny) * scaleY * -1;
                        String q2 = " endx " + ((cell.col - minx) * scaleX) + " endy " + ((cell.row - miny) * scaleY) * -1;
                        if (cell.sheet > 1)
                        {
                            queue[cnv.name] += " begz " + (cell.sheet - 1) * scaleZ;
                            q2 += " endz " + ((cell.sheet - 1) * scaleZ);
                        }
                        queue[cnv.name] += q2;
                        queue[cnv.name] += " upz 0.5 scx 0.5 scy 0.5 scz 0.5\r\n";
                    }

                    //vehicle config
                    //vehicleConfig += "AGVSVEH type DefVehicle cap " + 1 + " pickup " + 15 + " Seconds setdown " + 15 + " Seconds numveh " + (LM.bufferList.Count + 1) + "\r\n";
                    vehicleConfig += "AGVSVEH type DefVehicle cap " + 1 + " pickup " + 15 + " Seconds setdown " + 15 + " Seconds numveh " + 1 + "\r\n";
                    vehicleConfig += "			load Default \r\n";
                    vehicleConfig += "				accel	0 1 Feet Seconds Seconds\r\n";
                    vehicleConfig += "				decel	0 1 Feet Seconds Seconds\r\n";
                    vehicleConfig += "				vel	0 0.5 Meters Seconds\r\n";
                    vehicleConfig += "				crvvel	0 3 Feet Seconds\r\n";
                    vehicleConfig += "				sprvel	0 3 Meters Seconds\r\n";
                    vehicleConfig += "				rvel	0 3 Meters Seconds\r\n";
                    vehicleConfig += "				rcrvvel	0 3 Feet Seconds\r\n";
                    vehicleConfig += "				rsprvel	0 3 Feet Seconds\r\n";
                    vehicleConfig += "				crabvel	0 3 Feet Seconds\r\n";
                    vehicleConfig += "				rotate	0 2 Seconds\r\n";
                    vehicleConfig += "				brakedist	0 4.5 Feet\r\n";
                    vehicleConfig += "				stopdist	0 0 Feet\r\n";
                    vehicleConfig += "			load Empty \r\n";
                    vehicleConfig += "				accel	1 0 Feet Seconds Seconds\r\n";
                    vehicleConfig += "				decel	1 0 Feet Seconds Seconds\r\n";
                    vehicleConfig += "				vel	1 0 Feet Seconds\r\n";
                    vehicleConfig += "				crvvel	1 0 Feet Seconds\r\n";
                    vehicleConfig += "				sprvel	1 0 Feet Seconds\r\n";
                    vehicleConfig += "				rvel	1 0 Feet Seconds\r\n";
                    vehicleConfig += "				rcrvvel	1 0 Feet Seconds\r\n";
                    vehicleConfig += "				rsprvel	1 0 Feet Seconds\r\n";
                    vehicleConfig += "				crabvel	1 0 Feet Seconds\r\n";
                    vehicleConfig += "				rotate	1 0 Seconds\r\n";
                    vehicleConfig += "				brakedist	1 0 Feet\r\n";
                    vehicleConfig += "				stopdist	1 0 Feet\r\n";

                    strPath = strDir + "\\" + cnv.name + ".asy";
                    Byte[] info4 = new UTF8Encoding(true).GetBytes(systemConfig + path + controlPoint + workList + vehicleConfig);
                    FileStream fs4 = File.Open(strPath, FileMode.CreateNew);
                    fs4.Write(info4, 0, info4.Length);
                    fs4.Close();

                    //queue 마지막
                    queue[cnv.name] += " UserDef template Meters\r\n";
                    queue[cnv.name] += "310 17\r\n";
                    queue[cnv.name] += "2 2 0 1 0 none\r\n";
                    queue[cnv.name] += "4 4 4 4 4 0 0\r\n";
                    queue[cnv.name] += "end\r\n";

                    if (cnv.startCell.c.Name == COLORSTKBIDIRECTIONPORT)
                    {
                        systemConfig = "";
                        path = "";
                        controlPoint = "";
                        workList = "";
                        //nameList = "";
                        vehicleConfig = "";

                        countAll = 0;

                        buffers = new List<Cell>();
                        buffers.Add(cnv.startCell);
                        foreach (Cell cell in cnv.bufferList)
                            buffers.Add(cell);
                        buffers.Add(cnv.endCell);

                        //system list에 추가
                        systemList.Add(cnv.name + "_2");

                        //system config
                        systemConfig += "SYSTYPE AGVS\r\n";
                        systemConfig += "UNITS Meters Seconds\r\n";
                        systemConfig += "SYSDEF limit Infinite timeout 60 Seconds confname Config1\r\n";
                        systemConfig += "FLAGS System NoColor\r\n";
                        systemConfig += "\tText NoColor Paths GTemplate NoColor PathNames NoColor Direction NoColor ControlPoints NoColor ControlPointNames NoColor\r\n";
                        systemConfig += "\tTransfers NoColor Vehicles NoColor\r\n";
                        systemConfig += "AGVSDEF secname path1 name cp1 UserId 2 cpcap Infinite cprel distance 0 Feet ALTERNATE NONE ResumeSpeedWhenClaimed\r\n";
                        systemConfig += "\t\tvel 0 Infinite Feet Seconds\r\n";
                        systemConfig += "\t\tcrabvel 0 Infinite Feet Seconds\r\n";
                        systemConfig += "\t\tsprvel 0 Infinite Feet Seconds\r\n";
                        systemConfig += "\t\tcrvvel 0 Infinite Feet Seconds\r\n";
                        systemConfig += "AGVSTOL minang 450 maxang 1350\r\n";

                        //process system에 buffer 생성
                        if (!queue.ContainsKey(cnv.name + "_2"))
                            queue.Add(cnv.name + "_2", "QUEUE name Q_c" + cnv.name.Substring(3) + "_2 " + buffers.Count + " cap 2147483647\r\n");

                        for (int i = buffers.Count - 1; i > 0; i--)
                        {
                            double bx;
                            double by;
                            double ex;
                            double ey;
                            string direction;
                            Cell startCell = buffers.ElementAt(i);
                            Cell endCell = buffers.ElementAt(i - 1);

                            //path 생성
                            if (startCell.row == endCell.row)
                                direction = "horizontal";
                            else
                                direction = "vertical";

                            if (direction == "horizontal")
                            {
                                if (startCell.col < endCell.col)
                                {
                                    bx = (startCell.col - minx) * scaleX;
                                    by = -1 * ((startCell.row - miny) * scaleY);
                                    ex = bx + (endCell.col - startCell.col) * scaleX;
                                    ey = by;
                                }
                                else
                                {
                                    bx = (startCell.col - minx) * scaleX;
                                    by = -1 * ((startCell.row - miny) * scaleY);
                                    ex = bx + (endCell.col - startCell.col) * scaleX;
                                    ey = by;
                                }
                            }
                            else
                            {
                                if (startCell.row < endCell.row)
                                {
                                    bx = (startCell.col - minx) * scaleX;
                                    by = -1 * ((startCell.row - miny) * scaleY);
                                    ex = bx;
                                    ey = by - (endCell.row - startCell.row) * scaleY;
                                }
                                else
                                {
                                    bx = (startCell.col - minx) * scaleX;
                                    by = -1 * ((startCell.row - miny) * scaleY);
                                    ex = bx;
                                    ey = by - (endCell.row - startCell.row) * scaleY;
                                }
                            }

                            string zeroBX = "";
                            string zeroEX = "";
                            string zeroBY = "";
                            string zeroEY = "";

                            if (bx == 0)
                                zeroBX = ".0";
                            if (by == 0)
                                zeroBY = ".0";
                            if (ex == 0)
                                zeroEX = ".0";
                            if (ey == 0)
                                zeroEY = ".0";

                            path += "GPATH name path" + (buffers.Count - i) + " two piece begx " + bx + zeroBX + " begy " + by + zeroBY;
                            if (cnv.startCell.sheet != 1)
                            {
                                path += " begz " + (cnv.startCell.sheet - 1) * scaleZ;
                            }
                            path += " endx " + ex + zeroEX + " endy " + ey + zeroEY;
                            if (cnv.startCell.sheet != 1)
                            {
                                path += " endz " + (cnv.startCell.sheet - 1) * scaleZ;
                            }
                            path += " upz 1\r\n";

                            //control point, work list 설정
                            controlPoint += "CPOINT name buffer_" + (buffers.Count - i) + " at path" + (buffers.Count - i) + " 0\r\n";
                            //workList += "WORKLST name buffer_" + i + " Oldest item All\r\n";

                            if (i == 1)
                            {
                                int k;
                                if (direction == "horizontal")
                                    k = (endCell.col - startCell.col) * scaleY;
                                else
                                    k = (endCell.row - startCell.row) * scaleX;
                                controlPoint += "CPOINT name buffer_" + (buffers.Count) + " at path" + (buffers.Count - i) + " " + Math.Abs(k) + "\r\n";
                            }
                        }

                        //workList 생성
                        for (int i = 0; i < buffers.Count; i++)
                        {
                            workList += "WORKLST name buffer_" + (i + 1) + " Oldest item All\r\n";
                        }

                        //queue 생성
                        foreach (Cell cell in cnv.bufferList)
                        {
                            queue[cnv.name + "_2"] += "dis " + ++countAll + " Stacking OTT_LDDISP\r\n";
                            queue[cnv.name + "_2"] += "\tpicpos begx " + (cell.col - minx) * scaleX + " begy " + (cell.row - miny) * scaleY * -1;
                            String q2 = " endx " + ((cell.col - minx) * scaleX) + " endy " + ((cell.row - miny) * scaleY) * -1;
                            if (cell.sheet > 1)
                            {
                                queue[cnv.name + "_2"] += " begz " + (cell.sheet - 1) * scaleZ;
                                q2 += " endz " + ((cell.sheet - 1) * scaleZ);
                            }
                            queue[cnv.name + "_2"] += q2;
                            queue[cnv.name + "_2"] += " upz 0.5 scx 0.5 scy 0.5 scz 0.5\r\n";
                        }

                        //vehicle config
                        //vehicleConfig += "AGVSVEH type DefVehicle cap " + 1 + " pickup " + 15 + " Seconds setdown " + 15 + " Seconds numveh " + (LM.bufferList.Count + 1) + "\r\n";
                        vehicleConfig += "AGVSVEH type DefVehicle cap " + 1 + " pickup " + 15 + " Seconds setdown " + 15 + " Seconds numveh " + 1 + "\r\n";
                        vehicleConfig += "			load Default \r\n";
                        vehicleConfig += "				accel	0 1 Feet Seconds Seconds\r\n";
                        vehicleConfig += "				decel	0 1 Feet Seconds Seconds\r\n";
                        vehicleConfig += "				vel	0 3 Feet Seconds\r\n";
                        vehicleConfig += "				crvvel	0 3 Feet Seconds\r\n";
                        vehicleConfig += "				sprvel	0 3 Feet Seconds\r\n";
                        vehicleConfig += "				rvel	0 3 Feet Seconds\r\n";
                        vehicleConfig += "				rcrvvel	0 3 Feet Seconds\r\n";
                        vehicleConfig += "				rsprvel	0 3 Feet Seconds\r\n";
                        vehicleConfig += "				crabvel	0 3 Feet Seconds\r\n";
                        vehicleConfig += "				rotate	0 2 Seconds\r\n";
                        vehicleConfig += "				brakedist	0 4.5 Feet\r\n";
                        vehicleConfig += "				stopdist	0 0 Feet\r\n";
                        vehicleConfig += "			load Empty \r\n";
                        vehicleConfig += "				accel	1 0 Feet Seconds Seconds\r\n";
                        vehicleConfig += "				decel	1 0 Feet Seconds Seconds\r\n";
                        vehicleConfig += "				vel	1 0 Feet Seconds\r\n";
                        vehicleConfig += "				crvvel	1 0 Feet Seconds\r\n";
                        vehicleConfig += "				sprvel	1 0 Feet Seconds\r\n";
                        vehicleConfig += "				rvel	1 0 Feet Seconds\r\n";
                        vehicleConfig += "				rcrvvel	1 0 Feet Seconds\r\n";
                        vehicleConfig += "				rsprvel	1 0 Feet Seconds\r\n";
                        vehicleConfig += "				crabvel	1 0 Feet Seconds\r\n";
                        vehicleConfig += "				rotate	1 0 Seconds\r\n";
                        vehicleConfig += "				brakedist	1 0 Feet\r\n";
                        vehicleConfig += "				stopdist	1 0 Feet\r\n";

                        strPath = strDir + "\\" + cnv.name + "_2.asy";
                        Byte[] info5 = new UTF8Encoding(true).GetBytes(systemConfig + path + controlPoint + workList + vehicleConfig);
                        FileStream fs5 = File.Open(strPath, FileMode.Create);
                        fs5.Write(info5, 0, info5.Length);
                        fs5.Close();

                        //queue 마지막
                        queue[cnv.name + "_2"] += " UserDef template Meters\r\n";
                        queue[cnv.name + "_2"] += "310 17\r\n";
                        queue[cnv.name + "_2"] += "2 2 0 1 0 none\r\n";
                        queue[cnv.name + "_2"] += "4 4 4 4 4 0 0\r\n";
                        queue[cnv.name + "_2"] += "end\r\n";
                    }
                }

            }
            #endregion

            #region amo
            string systems = "";

            systems += "VERSION 11.2 BUILD 1949.23.30\r\n";
            systems += "UNITS Meters Seconds\r\n";
            systems += "RNSET 1\r\n";
            systems += "DRAWPOS minx 0.0 maxx 30 miny -34 maxy 0.0 minz 0 maxz 8.16 trx 0 try 0\r\n";

            foreach (string name in systemList)
            {
                systems += "MOVESYS name " + name + "\r\n";
                systems += "\tSYSPOS endx 1\r\n";
            }
            systems += "PROCSYS name projectName~\r\n";
            systems += "\tSYSPOS endx 1\r\n";
            systems += "CONTROL snaplen 365 Days counts 1 autorep\r\n";

            strPath = strDir + "\\model.amo";
            Byte[] info6 = new UTF8Encoding(true).GetBytes(systems);
            FileStream fs6 = File.Open(strPath, FileMode.Create);
            fs6.Write(info6, 0, info6.Length);
            fs6.Close();
            #endregion

            #region Process System
            string sysConfig = "";
            string procConfig = "";
            string loadConfig = "";
            string rnd = "";
            string orderList = "";
            string attribute = "";
            string varConfig = "";
            string rsrc = "";
            string q = "";
            string funcConfig = "";
            string proc = "";
            string var = "";

            sysConfig += "SYSTYPE Process\r\n";
            sysConfig += "UNITS Meters Seconds\r\n";
            sysConfig += "SYSDEF UtilByAvail off RefCheck on debugger off warningMessages on report standard\r\n";
            sysConfig += "FLAGS System NoColor\r\n";
            sysConfig += "Text NoColor Resources NoColor ResourceNames NoColor Queues NoColor QueueNames NoColor QueueAmounts NoColor\r\n";
            sysConfig += "Blocks NoColor BlockNames NoColor Labels NoColor Loads NoColor\r\n";

            procConfig += "PROCDEF\r\n";
            procConfig += "PROC name P_Listen 0 traf Infinite nextproc die\r\n";
            procConfig += "PROC name P_Clock 0 traf Infinite nextproc die\r\n";
            procConfig += "PROC name P_Clock_Send 0 traf Infinite nextproc die\r\n";
            procConfig += "PROC name P_Move 0 traf Infinite nextproc die\r\n";
            procConfig += "PROC name P_Start 0 traf Infinite nextproc die\r\n";
            procConfig += "PROC name P_Dummy 0 traf Infinite nextproc die\r\n";
            procConfig += "PROC name P_Delay 0 traf Infinite nextproc die\r\n";
            procConfig += "PROC name P_Listen_2 0 traf Infinite nextproc die\r\n";
            procConfig += "PROC name P_Dummy_2 0 traf Infinite nextproc die\r\n";
            procConfig += "PROC name P_Dummy_3 0 traf Infinite nextproc die\r\n";
            procConfig += "PROC name P_Clock_Ready 0 traf Infinite nextproc die\r\n";
            procConfig += "PROC name P_Update_Shelf 0 traf Infinite nextproc die\r\n";
            procConfig += "PROC name P_Seize_EQP 0 traf Infinite nextproc die\r\n";
            procConfig += "PROC name P_Release_EQP 0 traf Infinite nextproc die\r\n";
            procConfig += "PROC name P_Move2OutPort 50 traf Infinite nextproc die\r\n";
            procConfig += "PROC name P_Wait_EQP 0 traf Infinite nextproc die\r\n";
            procConfig += "PROC name P_Empty 0 traf Infinite nextproc die\r\n";
            procConfig += "PROC name P_moveLMV 0 traf Infinite nextproc die\r\n";

            loadConfig += "LDTYPE name L_Job 0 dis\r\n";
            loadConfig += "picpos begy -6 endx 1 endy -6\r\n";
            loadConfig += " color 6 template Meters\r\n";
            loadConfig += "310 17\r\n";
            loadConfig += "6 6 0 1 1 none\r\n";
            loadConfig += "1 1 1 1 1 0 0\r\n";
            loadConfig += "end\r\n";
            loadConfig += "		create con 5 Seconds stream stream_L_Job_1 foa con 0 Seconds stream stream_L_Job_1 First P_Start 0 Limit 1\r\n";
            loadConfig += "LDTYPE name L_Empty 0 dis\r\n";
            loadConfig += "picpos begx -1 begy -6 endy -6\r\n";
            loadConfig += " color 8 template Meters\r\n";
            loadConfig += "700 17\r\n";
            loadConfig += "8 8 0 1 1 none\r\n";
            loadConfig += "1\r\n";
            loadConfig += "310 0\r\n";
            loadConfig += "1 1 1 1 1 0 0\r\n";
            loadConfig += "end\r\n";
            loadConfig += "       create con 5 Seconds stream stream_L_Empty_1 foa con 0 Seconds stream stream_L_Empty_1 First P_Dummy 0 Limit 1\r\n";

            loadConfig += "LDTYPE name L_Processing 0 dis\r\n";
            loadConfig += " picpos begx -2 begy -6 endx -1 endy -6\r\n";
            loadConfig += " color 5 template Meters\r\n";
            loadConfig += "310 17\r\n";
            loadConfig += "5 5 0 1 1 none\r\n";
            loadConfig += "1 1 1 1 1 0 0\r\n";
            loadConfig += "end\r\n";
            loadConfig += "		create con 5 Seconds stream stream_L_Processing_1 First P_Dummy 0 Limit 1\r\n";


            rnd += "RNSTREAM stream0 0 type CMRG flags 1\r\n";
            rnd += "	cmrgseed 1 12345 12345 12345 12345 12345 12345\r\n";
            rnd += "RNSTATE 3692455944 1366884236 2968912127 335948734 4161675175 475798818\r\n";
            rnd += "RNSTREAM stream_L_Job_1 0 type CMRG flags 1\r\n";
            rnd += "	title \"Generated automatically for L_Job\"\r\n";
            rnd += "	cmrgseed 1 3692455944 1366884236 2968912127 335948734 4161675175 475798818\r\n";
            rnd += "RNSTREAM stream_L_Empty_1 0 type CMRG flags 1\r\n";
            rnd += "	title \"Generated automatically for L_Empty\"\r\n";
            rnd += "	cmrgseed 1 2182669320 3385890625 3665797567 4231471703 3643646033 7276979\r\n";
            rnd += "RNSTREAM stream_L_Processing_1 0 type CMRG flags 1\r\n";
            rnd += "	title \"Generated automatically for L_Processing\"\r\n";
            rnd += "	cmrgseed 1 3692455944 1366884236 2968912127 335948734 4161675175 475798818\r\n";

            for (int i = 0; i < resourceCount.Count; i++)
            {
                rnd += "RNSTREAM stream_R_" + (i + 1) + "_1 10 type CMRG flags 1\r\n";
                rnd += "	title \"Generated automatically for R_" + (i + 1) + "\"\r\n";
                rnd += "	cmrgseed 1 1597262096 3906379055 3312112953 1016013135 4099474108 275305423\r\n";
                rnd += "	cmrgseed 2 97147054 3131372450 829345164 3691032523 3006063034 4259826321\r\n";
                rnd += "	cmrgseed 3 796079799 2105258207 955365076 2923159030 4116632677 3067683584\r\n";
                rnd += "	cmrgseed 4 3281794178 2616230133 1457051261 2762791137 2480527362 2282316169\r\n";
                rnd += "	cmrgseed 5 3777646647 1837464056 4204654757 664239048 4190510072 2959195122\r\n";
                rnd += "	cmrgseed 6 4215590817 3862461878 1087200967 1544910132 936383720 1611370123\r\n";
                rnd += "	cmrgseed 7 1683636369 362165168 814316280 869382050 980203903 2062101717\r\n";
                rnd += "	cmrgseed 8 272317999 166758548 310112982 201045826 1680231254 118290799\r\n";
                rnd += "	cmrgseed 9 2245755202 1652682525 2865544364 721509566 209733568 592362218\r\n";
                rnd += "	cmrgseed 10 3003961408 3529909391 14538032 3603919910 566682685 1235016484\r\n";
            }

            orderList += "ORDER name OL_1 0\r\n";
            orderList += "ORDER name OL_2 200\r\n";
            orderList += "ORDER name OL_3 200\r\n";

            attribute += "ATT name A_msg 0 type String\r\n";
            attribute += "ATT name A_ID 0 type String\r\n";
            attribute += "ATT name A_time 0 type Real\r\n";
            attribute += "ATT name A_fromLoc 0 type Location\r\n";
            attribute += "ATT name A_toLoc 0 type Location\r\n";
            attribute += "ATT name A_oID 0 type Integer\r\n";
            attribute += "ATT name A_fromNum 0 type Integer\r\n";
            attribute += "ATT name A_toNum 0 type Integer\r\n";
            attribute += "ATT name A_toID 0 type Integer\r\n";
            attribute += "ATT name A_obj 0 type String\r\n";
            attribute += "ATT name A_fromID 0 type Integer\r\n";
            attribute += "ATT name A_fromLocS 0 type String\r\n";
            attribute += "ATT name A_toLocS 0 type String\r\n";
            attribute += "ATT name A_temp 1 10 type String\r\n";
            attribute += "ATT name A_iTemp 1 10 type Integer\r\n";
            attribute += "ATT name A_bufferIndex 0 type Integer\r\n";
            attribute += "ATT name A_index 0 type Integer\r\n";
            attribute += "Att name A_cnv 0 type Integer\r\n";

            varConfig += "VAR name V_sock1 0 type SocketPtr\r\n";
            varConfig += "VAR name V_msg 0 type String\r\n";
            varConfig += "VAR name V_rMsg 0 type String\r\n";
            varConfig += "VAR name V_lot 1 10 type LoadPtr\r\n";
            varConfig += "VAR name V_temp 1 10 type String\r\n";
            varConfig += "VAR name V_sMsg 0 type String\r\n";
            varConfig += "VAR name V_size 0 type Integer\r\n";
            varConfig += "VAR name V_loadList 0 type LoadList\r\n";
            varConfig += "VAR name V_shelfStatus 2 38 200 type Integer\r\n";
            varConfig += "VAR name V_shelfLocation 2 38 200 type Location\r\n";
            varConfig += "VAR name V_eqpList 1 200 type String\r\n";
            varConfig += "VAR name V_eqpLocation 3 200 200 2 type Location\r\n";
            varConfig += "VAR name V_eqpStatus 2 200 10 type Integer\r\n";
            varConfig += "VAR name V_stkportLocation 2 38 79 type Location\r\n";
            varConfig += "VAR name V_tLot 0 type LoadPtr\r\n";
            varConfig += "VAR name V_count 0 type Integer\r\n";
            varConfig += "VAR name V_iTemp 1 10 type Integer\r\n";
            varConfig += "VAR name V_clock 1 2 type String\r\n";
            varConfig += "VAR name V_empty 1 5 type String\r\n";
            varConfig += "VAR name V_stk 0 type Integer\r\n";
            varConfig += "VAR name V_crane 0 type Integer\r\n";
            varConfig += "VAR name V_cnv 0 type Integer\r\n";
            varConfig += "VAR name V_clockList 0 type LoadList\r\n";
            varConfig += "VAR name V_resourceList 1 200 type ResourcePtr\r\n";
            varConfig += "VAR name V_location 1 5 type String\r\n";
            varConfig += "VAR name V_moveStatus 0 type Integer\r\n";
            varConfig += "VAR name V_clockStatus 0 type Integer\r\n";
            varConfig += "VAR name V_queueLocation 2 38 200 type Location\r\n";
            varConfig += "VAR name V_queue 2 38 200 type QueuePtr\r\n";
            varConfig += "VAR name V_eqpType 1 200 type String\r\n";
            varConfig += "VAR name V_portType 2 200 10 type String\r\n";
            varConfig += "VAR name V_numPort 1 50 type Integer\r\n";
            varConfig += "VAR name V_eqpQueue 1 2 type LoadList\r\n";
            varConfig += "VAR name V_EmptyCstList 0 type LoadList\r\n";
            varConfig += "VAR name V_from 1 2 type String\r\n";
            varConfig += "VAR name V_to 1 2 type String\r\n";
            varConfig += "VAR name V_stkList 1 38 type String\r\n";
            varConfig += "VAR name V_conveyorList 1 79 type String\r\n";
            varConfig += "VAR name V_numBuffer 1 78 type Integer\r\n";
            varConfig += "VAR name V_buffer 2 78 4 type QueuePtr\r\n";
            varConfig += "VAR name V_bufferLocation 2 78 4 type Location\r\n";

            ///////////////////////////
            //rsrc
            ///////////////////////////

            foreach (string s in queue.Values)
                q += s;

            funcConfig += "FUNC name F_CustomSendString type Integer PARAM name Arg1 type LoadPtr\r\n";
            funcConfig += "FUNC name F_readallString type Integer\r\n";
            funcConfig += "FUNC name F_SearchLocation type Integer PARAM name Arg1 type LoadPtr\r\n";
            funcConfig += "FUNC name F_findToLocation type Integer PARAM name Arg1 type LoadPtr\r\n";
            funcConfig += "FUNC name F_searchSTKIndex type Integer PARAM name Arg1 type LoadPtr\r\n";
            funcConfig += "FUNC name F_searchCNVIndex type Integer PARAM name Arg1 type LoadPtr\r\n";
            funcConfig += "FUNC name F_Listen type Integer PARAM name Arg1 type LoadPtr\r\n";
            funcConfig += "FUNC name F_Read type Integer PARAM name Arg1 type LoadPtr\r\n";
            funcConfig += "FUNC name F_MoveI2O type Integer PARAM name Arg1 type LoadPtr\r\n";

            proc += "SFileBegin	name code.m\r\n";
            var += V_eqpList + V_eqpType + V_eqpLocation + V_portType + V_shelfLocation + V_queueLocation + V_queue + V_resourceList + V_stkportLocation + V_stkList + V_numBuffer + V_bufferLocation + V_buffer + var + V_conveyorList + "	set V_conveyorList(" + conveyorList.Count + ") to \"CNV00\"\r\n";
            proc += makeSourceCode(var);

            strPath = strDir + "\\" + "projectName~.asy";
            Byte[] info3 = new UTF8Encoding(true).GetBytes(sysConfig + procConfig + loadConfig + rsrcConfig + rnd + orderList + attribute + varConfig + rsrc + q + funcConfig + proc + moveToDeliverSTK + moveToDeliverCNV + makeModelReadyFunction(hostName));
            FileStream fs3 = File.Open(strPath, FileMode.Create);
            fs3.Write(info3, 0, info3.Length);
            fs3.Close();
            #endregion
        }

        private int findSide(InlineStocker STK, Cell cell)
        {
            if (STK.direction == "vertical")
            {
                if (cell.col < STK.startCell.col)
                    return 1;
                else
                    return 2;
            }
            else
            {
                if (cell.row < STK.startCell.row)
                    return 1;
                else
                    return 2;
            }
        }

        private string findType(Cell cell)
        {
            if (cell.c.Name == COLORSHELF)
                return "shelf";
            else if (cell.c.Name == COLORIOPORT || cell.c.Name == COLORBIINPORT || cell.c.Name == COLORBIOUTPORT)
                return "eqp";
            else if (cell.c.Name == COLORSTKINPORTC || cell.c.Name == COLORSTKINPORTL)
                return "inport";
            else if (cell.c.Name == COLORSTKOUTPORTC || cell.c.Name == COLORSTKOUTPORTL)
                return "outport";
            else if (cell.c.Name == COLORSTKBIDIRECTIONPORT)
                return "bidirectionport";
            else
                return null;

        }

        private string makeControlPoint(string direction, string cp, int row, int col, int begRow, int begCol, int scaleX, int scaleY)
        {
            int p;
            int bp;
            int scaleP;
            if (direction == "horizontal")
            {
                p = col;
                bp = begCol;
                scaleP = scaleX;
            }
            else
            {
                p = row;
                bp = begRow;
                scaleP = scaleY;
            }

            return "CPOINT name " + cp + " at path1 " + ((p - bp) * scaleP + 1) + "\r\n";
        }

        private string makeMoveToDeliverSingleSTK(string name)
        {
            string m = "";
            m += "begin " + name + " move to deliver procedure\r\n\r\n";
            m += "	set V_lot(5) to this vehicle current schedjob load\r\n";
            m += "	call F_CustomSendString(V_lot(5))\r\n";
            m += "	call F_readallString()\r\n";
            m += "	call F_Read(V_lot(5))\r\n";
            m += "	call F_readallString()\r\n";
            m += "	clone V_lot(5) to P_Clock_Ready\r\n";
            m += "	print V_lot(5) A_fromLoc to V_temp(1)\r\n";
            m += "	if V_temp(1) substring(8,1) = \"T\" then begin\r\n";
            m += "		choose a load from among V_loadList whose A_ID = V_lot(5) A_ID save choice as V_lot(6)\r\n";
            m += "		remove V_lot(6) from V_loadList\r\n";
            m += "		order V_lot(6) from OL_1 to die\r\n";
            m += "		order 1 load from OL_2(V_lot(5) A_fromID) to P_Release_EQP\r\n";
            m += "		set V_eqpStatus(V_lot(5) A_fromID, V_lot(5) A_fromNum) to 0\r\n";
            m += "	end\r\n";
            m += "	else if V_temp(1) substring(8,1) = \"b\" and V_lot(5) type = L_Job then begin\r\n";
            m += "		choose a load from among V_loadList whose A_ID = V_lot(5) A_ID save choice as V_lot(6)\r\n";
            m += "		remove V_lot(6) from V_loadList\r\n";
            m += "		order V_lot(6) from OL_1 to die\r\n";
            m += "		read V_temp(1), V_temp(2) from V_lot(5) A_obj with delimiter \"_\"\r\n";
            m += "		set V_crane to V_temp(2)\r\n";
            m += "\r\n";
            m += "		if V_crane = 1 then\r\n";
            m += "		    set V_iTemp(7) to 1\r\n";
            m += "		else\r\n";
            m += "			set V_iTemp(7) to -1	\r\n";
            m += "\r\n";
            m += "		decrement V_shelfStatus(V_lot(5) A_fromID, V_lot(5) A_fromNum) by 1\r\n";
            m += "	end\r\n";
            m += "  else if V_temp(1) substring(8,1) = \"i\" then begin\r\n";
            m += "      choose a load from among V_loadList whose A_ID = V_lot(5) A_ID save choice as V_lot(6)\r\n";
            m += "      remove V_lot(6) from V_loadList\r\n";
            m += "      order V_lot(6) from OL_1 to die	\r\n";
            m += "  end\r\n";
            m += "  else if V_temp(1) substring(8,1) = \"o\" then begin\r\n";
            m += "      print \"outout\", V_lot(5) A_ID, V_lot(5) A_fromLocS, V_lot(5) A_toLocS to message\r\n";
            m += "  end\r\n";
            m += "end\r\n";

            return m;
        }

        private string makeMoveToDeliverDualSTK(string name)
        {
            string m = "";
            m += "begin " + name + " move to deliver procedure\r\n\r\n";
            m += "	set V_lot(5) to this vehicle current schedjob load\r\n";
            m += "	call F_CustomSendString(V_lot(5))\r\n";
            m += "	call F_readallString()\r\n";
            m += "	call F_Read(V_lot(5))\r\n";
            m += "	call F_readallString()\r\n";
            m += "	clone V_lot(5) to P_Clock_Ready\r\n";
            m += "	print V_lot(5) A_fromLoc to V_temp(1)\r\n";
            m += "	if V_temp(1) substring(10,1) = \"T\" then begin\r\n";
            m += "		choose a load from among V_loadList whose A_ID = V_lot(5) A_ID save choice as V_lot(6)\r\n";
            m += "		remove V_lot(6) from V_loadList\r\n";
            m += "		order V_lot(6) from OL_1 to die\r\n";
            m += "		order 1 load from OL_2(V_lot(5) A_fromID) to P_Release_EQP\r\n";
            m += "		set V_eqpStatus(V_lot(5) A_fromID, V_lot(5) A_fromNum) to 0\r\n";
            m += "	end\r\n";
            m += "	else if V_temp(1) substring(10,1) = \"b\" and V_lot(5) type = L_Job then begin\r\n";
            m += "		choose a load from among V_loadList whose A_ID = V_lot(5) A_ID save choice as V_lot(6)\r\n";
            m += "		remove V_lot(6) from V_loadList\r\n";
            m += "		order V_lot(6) from OL_1 to die\r\n";
            m += "		read V_temp(1), V_temp(2) from V_lot(5) A_obj with delimiter \"_\"\r\n";
            m += "		set V_crane to V_temp(2)\r\n";
            m += "\r\n";
            m += "		if V_crane = 1 then\r\n";
            m += "		    set V_iTemp(7) to 1\r\n";
            m += "		else\r\n";
            m += "			set V_iTemp(7) to -1	\r\n";
            m += "\r\n";
            m += "		decrement V_shelfStatus(V_lot(5) A_fromID, V_lot(5) A_fromNum) by 1\r\n";
            m += "		decrement V_shelfStatus(V_lot(5) A_fromID + V_iTemp(7), V_lot(5) A_fromNum) by 1\r\n";
            m += "	end\r\n";
            m += "  else if V_temp(1) substring(10,1) = \"i\" then begin\r\n";
            m += "      choose a load from among V_loadList whose A_ID = V_lot(5) A_ID save choice as V_lot(6)\r\n";
            m += "      remove V_lot(6) from V_loadList\r\n";
            m += "      order V_lot(6) from OL_1 to die	\r\n";
            m += "  end\r\n";
            m += "  else if V_temp(1) substring(10,1) = \"o\" then begin\r\n";
            m += "      print \"outout\", V_lot(5) A_ID, V_lot(5) A_fromLocS, V_lot(5) A_toLocS to message\r\n";
            m += "  end\r\n";
            m += "end\r\n";

            return m;
        }

        private string makeMoveToDeliverCNV(string name)
        {
            string m = "";
            m += "begin " + name + " move to deliver procedure\r\n\r\n";
            m += "	set V_lot(5) to this vehicle current schedjob load\r\n";
            m += "	if V_lot(5) A_index = 1 then begin\r\n";
            m += "		call F_CustomSendString(V_lot(5))\r\n";
            m += "		call F_readallString()\r\n";
            m += "		call F_Read(V_lot(5))\r\n";
            m += "     	call F_readallString()\r\n";
            m += "     	clone V_lot(5) to P_Clock_Ready\r\n";
            m += "		choose a load from among V_loadList whose A_ID = V_lot(5) A_ID save choice as V_lot(6)\r\n";
            m += "		remove V_lot(6) from V_loadList\r\n";
            m += "		order V_lot(6) from OL_1 to die\r\n";
            m += "	end\r\n";
            m += "end\r\n";

            return m;
        }

        private string makeWorkOkFunction(string name)
        {
            string w = "begin " + name + " work ok function\r\n";
            w += "\tif theVehicle A_index = theLoad A_index then return true\r\n";
            w += "\telse return false\r\n";
            w += "end\r\n";

            return w;
        }

        private string makeSourceCode(string var)
        {
            string sourceCode = "";

            sourceCode += "begin P_Start arriving procedure\r\n";
            sourceCode += "\r\n";
            sourceCode += var + "\r\n\r\n";
            sourceCode += "	print \"Simulation Start!\" to V_msg\r\n";
            sourceCode += "	print \"Send \" V_msg to message\r\n";
            sourceCode += "	set V_size to SendSocketString(V_sock1, V_msg)\r\n";
            sourceCode += "	print displaystep to message\r\n";
            sourceCode += "\r\n";
            sourceCode += "	send to P_Listen\r\n";
            sourceCode += "\r\n";
            sourceCode += "end\r\n";
            sourceCode += "\r\n";
            sourceCode += "begin P_Listen arriving procedure\r\n";
            sourceCode += "\r\n";
            sourceCode += "	call F_readallString()\r\n";
            sourceCode += "\r\n";
            sourceCode += "	if V_rMsg substring(1,1) = \"C\" then clone 1 load to P_Clock_Ready\r\n";
            sourceCode += "	else if V_rMsg substring(1,1) = \"D\" then begin\r\n";
            sourceCode += "		call F_Read(this load)\r\n";
            sourceCode += "		clone 1 load to P_Move\r\n";
            sourceCode += "		call F_readallString()\r\n";
            sourceCode += "		clone 1 load to P_Clock_Ready\r\n";
            sourceCode += "	end\r\n";
            sourceCode += "	else if V_rMsg substring(1,1) = \"E\" then begin\r\n";
            sourceCode += "		call F_Read(this load)\r\n";
            sourceCode += "		clone 1 load to P_Empty\r\n";
            sourceCode += "		call F_readallString()\r\n";
            sourceCode += "		clone 1 load to P_Clock_Ready\r\n";
            sourceCode += "	end\r\n";
            sourceCode += "\r\n";
            sourceCode += "	else if V_rMsg substring(1,1) = \"S\" then terminate\r\n";
            sourceCode += "\r\n";
            sourceCode += "	send to die\r\n";
            sourceCode += "\r\n";
            sourceCode += "end\r\n";
            sourceCode += "\r\n";
            sourceCode += "begin P_Clock_Ready arriving procedure\r\n";
            sourceCode += "\r\n";
            sourceCode += "	call F_Read(this load)\r\n";
            sourceCode += "	read V_clock(1), V_clock(2) from A_msg with delimiter \"_\"\r\n";
            sourceCode += "	if V_clock(2) substring (1,1) = \"E\" then clone 1 load to P_Clock\r\n";
            sourceCode += "	else if V_moveStatus = 0 and V_clockStatus = 0 then\r\n";
            sourceCode += "	begin\r\n";
            sourceCode += "		print \"No More Entity!\" to V_msg\r\n";
            sourceCode += "		print \"Send \" V_msg to message\r\n";
            sourceCode += "		set V_size to SendSocketString(V_sock1, V_msg)\r\n";
            sourceCode += "		clone 1 load to P_Listen\r\n";
            sourceCode += "	end\r\n";
            sourceCode += "	send to die\r\n";
            sourceCode += "\r\n";
            sourceCode += "end\r\n";
            sourceCode += "\r\n";
            sourceCode += "begin P_Clock arriving procedure\r\n";
            sourceCode += "\r\n";
            sourceCode += "	choose a load from among V_clockList whose A_msg = this load A_msg save choice as V_lot(1)\r\n";
            sourceCode += "	if V_lot(1) = null then insert this load into V_clockList at end\r\n";
            sourceCode += "	else begin\r\n";
            sourceCode += "		print \"Cancel \" V_lot(1) A_msg to message\r\n";
            sourceCode += "		send to die\r\n";
            sourceCode += "	end\r\n";
            sourceCode += "\r\n";
            sourceCode += "	increment V_clockStatus by 1\r\n";
            sourceCode += "	if (A_time - ac) < 0.0001 then wait for 0\r\n";
            sourceCode += "	else wait for (A_time - ac)\r\n";
            sourceCode += "\r\n";
            sourceCode += "	clone this load to P_Clock_Send\r\n";
            sourceCode += "	remove this load from V_clockList\r\n";
            sourceCode += "	send to die\r\n";
            sourceCode += "end\r\n";

            sourceCode += "begin P_Clock_Send arriving procedure\r\n";
            sourceCode += "\r\n";
            sourceCode += "	call F_CustomSendString(this load)\r\n";
            sourceCode += "	decrement V_clockStatus by 1\r\n";
            sourceCode += "\r\n";
            sourceCode += "	clone 1 load to P_Listen\r\n";
            sourceCode += "\r\n";
            sourceCode += "	send to die\r\n";
            sourceCode += "\r\n";
            sourceCode += "end\r\n";
            sourceCode += "\r\n";
            sourceCode += "begin P_Move arriving procedure\r\n";
            sourceCode += "\r\n";
            sourceCode += "	increment V_moveStatus by 1\r\n";
            sourceCode += "\r\n";
            sourceCode += "	if A_obj substring(1,1) = \"L\" then begin\r\n";
            sourceCode += "		set A_index to 1\r\n";
            sourceCode += "		send to P_moveLMV\r\n";
            sourceCode += "	end\r\n";
            sourceCode += "	call F_SearchLocation(this load)\r\n";
            sourceCode += "\r\n";
            sourceCode += "	move into A_fromLoc\r\n";
            sourceCode += "	travel to A_toLoc\r\n";
            sourceCode += "\r\n";
            sourceCode += "	send to P_Update_Shelf\r\n";
            sourceCode += "\r\n";
            sourceCode += "end\r\n";
            sourceCode += "\r\n";
            sourceCode += "begin P_Empty arriving procedure\r\n";
            sourceCode += "\r\n";
            sourceCode += "	read V_empty(1), V_empty(2), V_empty(3) from A_msg with delimiter \"_\"\r\n";
            sourceCode += "	read V_empty(4), V_empty(5) from A_ID with \"_\"\r\n";
            sourceCode += "	if V_empty(3) = \"bLGL\" then begin\r\n";
            sourceCode += "		choose a load from among V_loadList whose A_ID = V_empty(5) save choice as V_lot(3)\r\n";
            sourceCode += "		set V_lot(3) type to L_Empty\r\n";
            sourceCode += "		set V_lot(3) A_ID to V_empty(4)\r\n";
            sourceCode += "	end\r\n";
            sourceCode += "	if V_empty(3) = \"bCDR\" then begin\r\n";
            sourceCode += "		choose a load from among V_loadList whose A_ID = V_empty(4) save choice as V_lot(3)\r\n";
            sourceCode += "		set V_lot(3) type to L_Job\r\n";
            sourceCode += "		set V_lot(3) A_ID to V_empty(5)\r\n";
            sourceCode += "	end	\r\n";
            sourceCode += "\r\n";
            sourceCode += "	send to die\r\n";
            sourceCode += "\r\n";
            sourceCode += "end\r\n";
            sourceCode += "\r\n";
            sourceCode += "begin P_Update_Shelf arriving procedure\r\n";
            sourceCode += "\r\n";
            sourceCode += "	print A_toLoc to A_temp(1)\r\n";
            sourceCode += "	read A_temp(1), A_temp(2), A_temp(3) from A_temp(1) with delimiter \"_\"\r\n";
            sourceCode += "\r\n";
            sourceCode += "	if A_obj substring(1,1) = \"S\" then begin\r\n";
            sourceCode += "		set A_iTemp(1) to F_searchSTKIndex(this load)\r\n";
            sourceCode += "		set V_count to 1\r\n";
            sourceCode += "		while V_queueLocation(A_iTemp(1), V_count) <> A_toLoc do\r\n";
            sourceCode += "			increment V_count by 1\r\n";
            sourceCode += "		set V_stk to A_temp(1)\r\n";
            sourceCode += "		set V_crane to A_temp(2)\r\n";
            sourceCode += "		if V_crane = 2 then\r\n";
            sourceCode += "			decrement A_iTemp(1) by 1\r\n";
            sourceCode += "\r\n";
            sourceCode += "		move into V_queue(A_iTemp(1), V_count)\r\n";
            sourceCode += "\r\n";
            sourceCode += "		if A_temp(2) substring(1,1) = \"T\" and type = L_Job then begin\r\n";
            sourceCode += "			set this load type to L_Processing\r\n";
            sourceCode += "			clone 1 load to P_Seize_EQP\r\n";
            sourceCode += "		end\r\n";
            sourceCode += "		if A_temp(3) substring(1,1) = \"T\" and type = L_Job then begin\r\n";
            sourceCode += "			set this load type to L_Processing\r\n";
            sourceCode += "			clone 1 load to P_Seize_EQP\r\n";
            sourceCode += "		end\r\n";
            sourceCode += "\r\n";
            sourceCode += "		call F_CustomSendString(this load)\r\n";
            sourceCode += "		decrement V_moveStatus by 1\r\n";
            sourceCode += "		clone 1 load to P_Listen\r\n";
            sourceCode += "\r\n";
            sourceCode += "		insert this load into V_loadList at end\r\n";
            sourceCode += "		wait to be ordered on orderlist OL_1\r\n";
            sourceCode += "	end\r\n";
            sourceCode += "	else if A_obj substring(1,1) = \"C\" begin\r\n";
            sourceCode += "		call F_CustomSendString(this load)\r\n";
            sourceCode += "		decrement V_moveStatus by 1\r\n";
            sourceCode += "		clone 1 load to P_Listen\r\n";
            sourceCode += "	end	\r\n";
            sourceCode += "	else begin\r\n";
            sourceCode += "		set V_count to 1\r\n";
            sourceCode += "		while V_conveyorList(V_count) <> A_obj do\r\n";
            sourceCode += "		increment V_count by 1\r\n";
            sourceCode += "		set A_cnv to V_count\r\n";
            sourceCode += "		move into V_buffer(A_cnv, A_index)\r\n";
            sourceCode += "		call F_CustomSendString(this load)\r\n";
            sourceCode += "		decrement V_moveStatus by 1\r\n";
            sourceCode += "		clone 1 load to P_Listen\r\n";
            sourceCode += "\r\n";
            sourceCode += "		insert this load into V_loadList at end\r\n";
            sourceCode += "		wait to be ordered on orderlist OL_1\r\n";
            sourceCode += "	end\r\n";
            sourceCode += "\r\n";
            sourceCode += "end\r\n";
            sourceCode += "\r\n";
            sourceCode += "begin P_Seize_EQP arriving procedure\r\n";
            sourceCode += "\r\n";
            sourceCode += "	get V_resourceList(A_toID)\r\n";
            sourceCode += "	wait to be ordered on orderlist OL_2(A_toID)\r\n";
            sourceCode += "	send to die\r\n";
            sourceCode += "\r\n";
            sourceCode += "end\r\n";
            sourceCode += "\r\n";
            sourceCode += "begin P_Release_EQP arriving procedure\r\n";
            sourceCode += "\r\n";
            sourceCode += "	free V_resourceList(A_toID)\r\n";
            sourceCode += "	send to die\r\n";
            sourceCode += "\r\n";
            sourceCode += "end\r\n";
            sourceCode += "\r\n";
            sourceCode += "begin P_moveLMV arriving procedure\r\n";
            sourceCode += "\r\n";
            sourceCode += "	set V_count to 1\r\n";
            sourceCode += "	while V_conveyorList(V_count) <> A_obj do\r\n";
            sourceCode += "		increment V_count by 1\r\n";
            sourceCode += "	set A_cnv to V_count\r\n";
            sourceCode += "\r\n";
            sourceCode += "	if A_index = V_numBuffer(A_cnv) then\r\n";
            sourceCode += "		send to P_Update_Shelf\r\n";
            sourceCode += "\r\n";
            sourceCode += "	set A_fromLoc to V_bufferLocation(A_cnv, A_index)\r\n";
            sourceCode += "\r\n";
            sourceCode += "	set A_toLoc to V_bufferLocation(A_cnv, A_index + 1)\r\n";
            sourceCode += "	\r\n";
            sourceCode += "	move into A_fromLoc\r\n";
            sourceCode += "	travel to A_toLoc\r\n";
            sourceCode += "\r\n";
            sourceCode += "	increment A_index by 1\r\n";
            sourceCode += "	move into V_buffer(A_cnv, A_index)\r\n";
            sourceCode += "\r\n";
            sourceCode += "	send to P_moveLMV\r\n";
            sourceCode += "\r\n";
            sourceCode += "end\r\n";
            sourceCode += "\r\n";
            sourceCode += "begin F_SearchLocation function\r\n";
            sourceCode += "	set V_lot(2) to Arg1\r\n";
            sourceCode += "\r\n";

            sourceCode += "	if V_lot(2) A_obj substring(1,1) = \"C\" then begin\r\n";
            sourceCode += "	\r\n";
            sourceCode += "		print V_lot(2) A_obj \":sta1\" to V_temp(1)\r\n";
            sourceCode += "		set V_lot(2) A_fromLoc to V_temp(1)\r\n";
            sourceCode += "		print V_lot(2) A_obj \":sta2\" to V_temp(1)\r\n";
            sourceCode += "		set V_lot(2) A_toLoc to V_temp(1)\r\n";
            sourceCode += "	\r\n";
            sourceCode += "		return 1\r\n";
            sourceCode += "	end\r\n";

            sourceCode += "		else begin\r\n";
            sourceCode += "		read V_temp(1), V_temp(2) from V_lot(2) A_obj with delimiter \"_\"\r\n";
            sourceCode += "		set V_crane to V_temp(2)\r\n";
            sourceCode += "		if V_crane = 0 then set V_crane to 1\r\n";
            sourceCode += "	\r\n";
            sourceCode += "		set V_stk to F_searchSTKIndex(V_lot(2))\r\n";
            sourceCode += "	\r\n";
            sourceCode += "		print V_lot(2) A_fromLocS to V_temp(1)\r\n";
            sourceCode += "		read V_from(1), V_from(2) from V_temp(1) with delimiter \"_\"\r\n";
            sourceCode += "	\r\n";
            sourceCode += "		if V_from(1) substring(1,1) = \"i\" then begin\r\n";
            sourceCode += "			set V_count to 1\r\n";
            sourceCode += "			while V_conveyorList(V_count) <> V_from(2) do\r\n";
            sourceCode += "				increment V_count by 1\r\n";
            sourceCode += "			set V_lot(2) A_cnv to V_count\r\n";
            sourceCode += "			set V_lot(2) A_fromLoc to V_stkportLocation(V_stk, V_lot(2) A_cnv)\r\n";
            sourceCode += "			set V_lot(2) type to L_Job\r\n";
            sourceCode += "		end\r\n";
            sourceCode += "		else if V_temp(1) substring(1,1) = \"e\" then begin\r\n";
            sourceCode += "			set V_lot(2) A_fromLoc to V_shelfLocation(V_stk, 1)\r\n";
            sourceCode += "			set V_lot(2) type to L_Empty\r\n";
            sourceCode += "		end\r\n";
            sourceCode += "		else if V_temp(1) substring(1,1) = \"b\" then begin\r\n";
            sourceCode += "			choose a load from among V_loadList whose A_ID = V_lot(2) A_ID save choice as V_lot(3)\r\n";
            sourceCode += "			set V_lot(2) A_fromLoc to V_shelfLocation(V_stk, V_lot(3) A_toNum)\r\n";
            sourceCode += "			set V_lot(2) A_fromID to V_stk\r\n";
            sourceCode += "			set V_lot(2) A_fromNum to V_lot(3) A_toNum\r\n";
            sourceCode += "			set V_lot(2) type to L_Job\r\n";
            sourceCode += "		end\r\n";
            sourceCode += "		else begin\r\n";
            sourceCode += "			choose a load from among V_loadList whose A_ID = V_lot(2) A_ID save choice as V_lot(3)\r\n";
            sourceCode += "			set V_lot(2) A_fromLoc to V_eqpLocation(V_lot(3) A_toID, V_lot(3) A_toNum, V_crane)\r\n";
            sourceCode += "			set V_lot(2) A_fromID to V_lot(3) A_toID\r\n";
            sourceCode += "			set V_lot(2) A_fromNum to V_lot(3) A_toNum\r\n";
            sourceCode += "			set V_lot(2) type to L_Job\r\n";
            sourceCode += "		end\r\n";
            sourceCode += "	\r\n";
            sourceCode += "		call F_findToLocation(V_lot(2))\r\n";
            sourceCode += "	\r\n";
            sourceCode += "		return 1\r\n";
            sourceCode += "	end\r\n";
            sourceCode += "end\r\n";

            sourceCode += "\r\n";
            sourceCode += "begin F_findToLocation function\r\n";
            sourceCode += "\r\n";
            sourceCode += "	set V_lot(4) to Arg1\r\n";
            sourceCode += "\r\n";
            sourceCode += "	read V_temp(1), V_temp(2) from V_lot(4) A_obj with delimiter \"_\"\r\n";
            sourceCode += "	set V_crane to V_temp(2)\r\n";
            sourceCode += "	if V_crane = 0 then set V_crane to 1\r\n";
            sourceCode += "\r\n";
            sourceCode += "	set V_stk to F_searchSTKIndex(V_lot(4))\r\n";
            sourceCode += "\r\n";
            sourceCode += "	print V_lot(4) A_toLocS to V_temp(1)\r\n";
            sourceCode += "	read V_to(1), V_to(2) from V_temp(1) with delimiter \"_\"\r\n";
            sourceCode += "\r\n";
            sourceCode += "	if V_temp(1) substring(1,1) = \"o\" then begin\r\n";
            sourceCode += "		set V_count to 1\r\n";
            sourceCode += "		while V_conveyorList(V_count) <> V_to(2) do\r\n";
            sourceCode += "			increment V_count by 1\r\n";
            sourceCode += "		set V_lot(4) A_cnv to V_count\r\n";
            sourceCode += "		set V_lot(4) A_toLoc to V_stkportLocation(V_stk, V_lot(4) A_cnv)\r\n";
            sourceCode += "	end\r\n";
            sourceCode += "	else if V_temp(1) substring(1,1) = \"e\" then begin\r\n";
            sourceCode += "		set V_lot(4) A_toLoc to V_shelfLocation(V_stk, 1)\r\n";
            sourceCode += "		set V_lot(4) type to L_Empty\r\n";
            sourceCode += "	end\r\n";
            sourceCode += "	else if V_temp(1) substring(1,1) = \"T\" then begin\r\n";
            sourceCode += "		set V_count to 1\r\n";
            sourceCode += "		while V_eqpList(V_count) <> V_temp(1) do\r\n";
            sourceCode += "			increment V_count by 1\r\n";
            sourceCode += "		set V_lot(4) A_toID to V_count\r\n";
            sourceCode += "\r\n";
            sourceCode += "		set V_count to 1\r\n";
            sourceCode += "		if V_eqpType(V_lot(4) A_toID) = \"u\" then begin\r\n";
            sourceCode += "			while V_eqpStatus(V_lot(4) A_toID, V_count) <> 0 do\r\n";
            sourceCode += "				increment V_count by 1\r\n";
            sourceCode += "		end\r\n";
            sourceCode += "		else begin\r\n";
            sourceCode += "			if V_lot(4) type = L_Job then begin\r\n";
            sourceCode += "				while V_portType(V_lot(4) A_toID, V_count) <> \"i\" or V_eqpStatus(V_lot(4) A_toID, V_count) <> 0 do begin\r\n";
            sourceCode += "					increment V_count by 1\r\n";
            sourceCode += "				end\r\n";
            sourceCode += "			end\r\n";
            sourceCode += "			else begin\r\n";
            sourceCode += "				while V_portType(V_lot(4) A_toID, V_count) <> \"o\" or V_eqpStatus(V_lot(4) A_toID, V_count) <> 0 do begin\r\n";
            sourceCode += "					increment V_count by 1\r\n";
            sourceCode += "				end\r\n";
            sourceCode += "			end\r\n";
            sourceCode += "		end\r\n";
            sourceCode += "		set V_lot(4) A_toNum to V_count\r\n";
            sourceCode += "		set V_lot(4) A_toLoc to V_eqpLocation(V_lot(4) A_toID, V_lot(4) A_toNum, V_crane)\r\n";
            sourceCode += "		set V_eqpStatus(V_lot(4) A_toID, V_lot(4) A_toNum) to 1\r\n";
            sourceCode += "	end\r\n";
            sourceCode += "	else if V_temp(1) substring(1,1) = \"b\" then begin\r\n";
            sourceCode += "		if V_crane = 1 then\r\n";
            sourceCode += "			set V_iTemp(7) to 1\r\n";
            sourceCode += "		else\r\n";
            sourceCode += "			set V_iTemp(7) to -1\r\n";
            sourceCode += "\r\n";
            sourceCode += "		set V_lot(4) A_toID to V_stk\r\n";
            sourceCode += "\r\n";
            sourceCode += "		set V_count to 2\r\n";
            sourceCode += "		while V_shelfStatus(V_lot(4) A_toID, V_count) <> 0 do\r\n";
            sourceCode += "			increment V_count by 1\r\n";
            sourceCode += "		set V_lot(4) A_toNum to V_count\r\n";
            sourceCode += "\r\n";
            sourceCode += "		set V_lot(4) A_toLoc to V_shelfLocation(V_lot(4) A_toID, V_lot(4) A_toNum)	\r\n";
            sourceCode += "\r\n";
            sourceCode += "		if V_lot(4) A_toLoc = null then begin\r\n";
            sourceCode += "			set V_lot(4) A_toNum to 1\r\n";
            sourceCode += "			set V_lot(4) A_toLoc to V_shelfLocation(V_lot(4) A_toID, V_lot(4) A_toNum)\r\n";
            sourceCode += "end\r\n";
            sourceCode += "		increment V_shelfStatus(V_lot(4) A_toID, V_lot(4) A_toNum) by 1\r\n";
            sourceCode += "		if V_iTemp(7) <> -1 then\r\n";
            sourceCode += "			increment V_shelfStatus(V_lot(4) A_toID + V_iTemp(7), V_lot(4) A_toNum) by 1\r\n";
            sourceCode += "	end\r\n";
            sourceCode += "\r\n";
            sourceCode += "	return 1\r\n";
            sourceCode += "\r\n";
            sourceCode += "end\r\n";
            sourceCode += "\r\n";
            sourceCode += "begin F_searchSTKIndex function\r\n";
            sourceCode += "\r\n";
            sourceCode += "	set V_lot(3) to Arg1\r\n";
            sourceCode += "	set V_count to 1\r\n";
            sourceCode += "	while V_lot(3) A_obj <> V_stkList(V_count)\r\n";
            sourceCode += "		increment V_count by 1\r\n";
            sourceCode += "\r\n";
            sourceCode += "	return V_count\r\n";
            sourceCode += "\r\n";
            sourceCode += "end\r\n";
            sourceCode += "\r\n";
            sourceCode += "begin F_searchCNVIndex function\r\n";
            sourceCode += "\r\n";
            sourceCode += "	set V_lot(3) to Arg1\r\n";
            sourceCode += "	set V_count to 1\r\n";
            sourceCode += "	while V_lot(3) A_obj <> V_conveyorList(V_count)\r\n";
            sourceCode += "increment V_count by 1\r\n";
            sourceCode += "					\r\n";
            sourceCode += "	return V_count\r\n";
            sourceCode += "\r\n";
            sourceCode += "end\r\n";
            sourceCode += "\r\n";
            sourceCode += "begin F_CustomSendString function\r\n";
            sourceCode += "\r\n";
            sourceCode += "	set V_lot(6) to Arg1\r\n";
            sourceCode += "	print V_lot(6) A_msg \"#\" V_lot(6) A_obj \"#\" V_lot(6) A_ID \"#\" ac \"#\" V_lot(6) A_fromLocS \"#\" V_lot(6) A_toLocS to V_sMsg\r\n";
            sourceCode += "	print \"Send \" V_sMsg to message\r\n";
            sourceCode += "\r\n";
            sourceCode += "	set V_size to SendSocketString(V_sock1, V_sMsg)\r\n";
            sourceCode += "\r\n";
            sourceCode += "	if V_size = 0 then begin\r\n";
            sourceCode += "		print \"Warning! Message send faild\" to message\r\n";
            sourceCode += "		set V_sock1 to null\r\n";
            sourceCode += "		return 0\r\n";
            sourceCode += "	end\r\n";
            sourceCode += "\r\n";
            sourceCode += "	return 1\r\n";
            sourceCode += "\r\n";
            sourceCode += "end\r\n";
            sourceCode += "\r\n";
            sourceCode += "begin F_readallString function\r\n";
            sourceCode += "\r\n";
            sourceCode += "	if ValidSocket(V_sock1) = false then begin\r\n";
            sourceCode += "		print \"Warning\" to message\r\n";
            sourceCode += "		return 0\r\n";
            sourceCode += "	end\r\n";
            sourceCode += "\r\n";
            sourceCode += "	set V_rMsg to ReadSocketString(V_sock1)\r\n";
            sourceCode += "	print \"Read \" V_rMsg to message\r\n";
            sourceCode += "\r\n";
            sourceCode += "	return 1\r\n";
            sourceCode += "\r\n";
            sourceCode += "end\r\n";
            sourceCode += "\r\n";
            sourceCode += "begin F_Read function\r\n";
            sourceCode += "\r\n";
            sourceCode += "	set V_lot(6) to Arg1\r\n";
            sourceCode += "	read V_lot(6) A_msg, V_lot(6) A_obj, V_lot(6) A_ID, V_lot(6) A_time, V_lot(6) A_fromLocS, V_lot(6) A_toLocS from V_rMsg with delimiter \"#\"\r\n";
            sourceCode += "	return 1\r\n";
            sourceCode += "\r\n";
            sourceCode += "end\r\n\r\n";

            return sourceCode;
        }

        private string makeModelReadyFunction(string hostName)
        {
            string mrf = "";
            mrf += "begin model ready function\r\n";
            mrf += "	set V_sock1 to ConnectSocketPort(\"" + hostName + "\", 5555)\r\n";
            mrf += "	call SetSocketNonBlocking(V_sock1,0)\r\n";
            mrf += "	return 1\r\n";
            mrf += "end\r\n\r\n";
            mrf += "#@!\r\n";
            return mrf;
        }

        #endregion
    }
}