﻿using System;
using System.Collections.Generic;
using Microsoft.Office.Interop.Excel;
using System.Reflection;
using System.Linq;
using System.Drawing;
using System.Text;
using System.Runtime.InteropServices;

namespace ExcelLayout
{
//[Guid("B20B636D-0A04-447E-90D4-C10D84A0C3D8")]
    public class CellDataReader : ExInterface
    {
        #region Variables
        private Info data;
		private VIPInfo output;
        private int StartRow;
        private int EndRow;
        private int StartCol;
        private int EndCol;
        private string FilePath;
        private Dictionary<int, Worksheet> sheets;
        private Range range;

        private string COLORSINGLECRANEPATH;
        private string COLORDUALCRANEPATH;
        private string COLORCONVEYORBELT;
        private string COLORCONVEYORCORNER;
        private string COLORLINEARMOTORLINE;
        private string COLORLINEARMOTORBUFFER;
        private string COLORSHELF;
        private string COLORIOPORT;
        private string COLORBIINPORT;
        private string COLORBIOUTPORT;
        private string COLORUNIINLINE;
        private string COLORBIINLINE;
        private string COLORSTKINPORTC;
        private string COLORSTKOUTPORTC;
        private string COLORSTKINPORTL;
        private string COLORSTKOUTPORTL;
        private string COLORSTKBIDIRECTIONPORT;

        private Dictionary<string, InlineStocker> inlineStocker;
        private Dictionary<string, LinearMotor> linearMotor;

		VIPConverter converter;
        #endregion

        #region Constructor
        public CellDataReader()
        {
            data = new Info();
            sheets = new Dictionary<int, Worksheet>();
            inlineStocker = new Dictionary<string, InlineStocker>();
            linearMotor = new Dictionary<string, LinearMotor>();
            System.Diagnostics.Debug.WriteLine("Excel Reader");

			output = new VIPInfo();
        }
        #endregion

        #region Interfaces
		public void set(string filePath)
        {
            FilePath = filePath;// System.Runtime.InteropServices.Marshal.PtrToStringUni(filePath);
            StartRow = 1;
            EndRow = 15;
            StartCol = 1;
            EndCol = 35;
            System.Diagnostics.Debug.WriteLine(FilePath);
        }

        public int getPathMoverSystemSize()
        {
            return data.inlineStocker.Count();
        }
        public int getConveyorSize()
        {
            return output.conveyor.Count();
        }
        public int getResourceSize()
        {
			return output.resource.Count();
        }
		public int getQueueSize()
		{
			return output.queues.Count();
		}
		public string getPathMoverSystemName(int i)
        //public IntPtr getPathMoverSystemName(int i)
		{
			return output.stocker[i].getName();
            //return Marshal.StringToBSTR(output.stocker[i].getName());
		}
        public PathMoverSystem getPathMoverSystem(int i)
        {
            return output.stocker[i];
        }
        public string getConveyorName(int i)
		{
			return output.conveyor[i].getName();
            //return Marshal.StringToBSTR(output.conveyor[i].getName());
		}
		public string getResourceName(int i)
		{
			return output.resource[i].getName();
		}
		public string getQueueName(int i)
		{
			return output.queues[i].getName();
            //return Marshal.StringToBSTR(output.queues[i].getName());
		}
		public string getQueueType(int i)
		{
			return output.queues[i].getType();
            //return Marshal.StringToBSTR(output.queues[i].getType());
		}
		public int getControlPointSize(int si)
		{
			return output.stocker[si].getPointSize();
		}
		public double getControlPointX(int si, int ci)
		{		
			return output.stocker[si].getPoit(ci).getX();
		}
		public double getControlPointY(int si, int ci)
		{
			return output.stocker[si].getPoit(ci).getY();
		}
		public string getControlPointName(int si, int ci)
            //public IntPtr getControlPointName(int si, int ci)
		{
			return output.stocker[si].getPoit(ci).getName();
            //return Marshal.StringToBSTR(output.stocker[si].getPoit(ci).getName());
		}
		public int getConveyorPathSize(int ci)
		{
			return output.conveyor[ci].getNoPoints();
		}
		public double getConveyorPointX(int ci, int pi)
		{
			return output.conveyor[ci].getPoint(pi)[0];
		}
		public double getConveyorPointY(int ci, int pi)
		{
			return output.conveyor[ci].getPoint(pi)[1];
		}
        public Resource getResource(int i)
        {
            return output.resource[i];
        }
		public double getResourcePosition(int i, int ax)
		{
			if (ax == 0)
				return output.resource[i].getPositionX();
			else
				return output.resource[i].getPositionY();
		}
		public double getResourceLength(int i, int ax)
		{
			if (ax == 0)
				return output.resource[i].getSizeX();
			else
				return output.resource[i].getSizeY();
		}
		public double getQueuePosition(int i, int ax)
		{
			if(ax == 0)
				return output.queues[i].getPositionX();
			else if(ax == 1)
				return output.queues[i].getPositionY();
            else
                return output.queues[i].getPositionZ();          
		}
        #endregion

        #region Methods
		public void parse()
		{
			loadCellData();
			convert();

            int qi = 0;
            int sn = getPathMoverSystemSize();
            for (int i = 0; i < sn; i++)
            {
                PathMoverSystem pms = getPathMoverSystem(i);
                int cn = getControlPointSize(i);
                for (int j = 0; j < cn; j++)
                {
                    string cpName = getControlPointName(i, j);
                    output.queues[qi].setControlPosition(getControlPointX(i, j), getControlPointY(i, j), 0);
                    output.queues[qi].setCPName(cpName);
                    qi++;
                }
            }
		}

        void loadRange()
        {
			System.Diagnostics.Debug.Write("scan range: ");

			foreach (int s in sheets.Keys)
			{
				System.Diagnostics.Debug.Write("sheet : " + s + "- ");
				Worksheet sheet = sheets[s];
				Range range = (Range)sheet.Cells[1, 1];
				StartRow = Int32.Parse(range.Text.ToString());

				range = (Range)sheet.Cells[1, 2];
				EndRow = Int32.Parse(range.Text.ToString());

				range = (Range)sheet.Cells[2, 1];
				StartCol = Int32.Parse(range.Text.ToString());

				range = (Range)sheet.Cells[2, 2];
				EndCol = Int32.Parse(range.Text.ToString());

				System.Diagnostics.Debug.Write(StartRow); System.Diagnostics.Debug.Write(", ");
				System.Diagnostics.Debug.Write(EndRow); System.Diagnostics.Debug.Write(", ");
				System.Diagnostics.Debug.Write(StartCol); System.Diagnostics.Debug.Write(", ");
				System.Diagnostics.Debug.WriteLine(EndCol);

				break;
			}
        }

        public void loadCellData()
        {
            ApplicationClass app = new ApplicationClass();
            Workbook book = app.Workbooks.Open(FilePath, Missing.Value, Missing.Value, Missing.Value
                                  , Missing.Value, Missing.Value, Missing.Value, Missing.Value
                                 , Missing.Value, Missing.Value, Missing.Value, Missing.Value
                                , Missing.Value, Missing.Value, Missing.Value);

            // find color information & store layout sheets
            foreach (Worksheet s in book.Worksheets)
            {
                if (s.Name == "color")
                {
                    for (int i = 2; i < 18; i++)
                    {
                        range = (Range)s.Cells[i, 1];
                        string type = range.Text.ToString();
                        range = (Range)s.Cells[i, 2];

                        Cell wow = range2cell(s.Index, range);

                        string color = range.Cells.Interior.Color.ToString();
                        Color c = System.Drawing.ColorTranslator.FromOle(int.Parse(color));
                        c = Color.FromArgb(c.R, c.G, c.B);

                        switch (type)
                        {
                            case "Single Crane Path": COLORSINGLECRANEPATH = wow.c.Name; break;
                            case "Dual Crane Path": COLORDUALCRANEPATH = wow.c.Name; break;
                            case "Conveyor Belt": COLORCONVEYORBELT = wow.c.Name; break;
                            case "Conveyor Corner": COLORCONVEYORCORNER = wow.c.Name; break;
                            case "Linear Motor Line": COLORLINEARMOTORLINE = wow.c.Name; break;
                            case "Linear Motor Buffer": COLORLINEARMOTORBUFFER = wow.c.Name; break;
                            case "Shelf": COLORSHELF = wow.c.Name; break;
                            case "IO Port": COLORIOPORT = wow.c.Name; break;
                            case "Bi-Inport": COLORBIINPORT = wow.c.Name; break;
                            case "Bi-Outport": COLORBIOUTPORT = wow.c.Name; break;
                            case "Uni-Inline": COLORUNIINLINE = wow.c.Name; break;
                            case "Bi-Inline": COLORBIINLINE = wow.c.Name; break;
                            case "Stocker Inport C": COLORSTKINPORTC = wow.c.Name; break;
                            case "Stocker Outport C": COLORSTKOUTPORTC = wow.c.Name; break;
                            case "Stocker Inport L": COLORSTKINPORTL = wow.c.Name; break;
                            case "Stocker Outport L": COLORSTKOUTPORTL = wow.c.Name; break;
                            case "Stocker Bidirection port": COLORSTKBIDIRECTIONPORT = wow.c.Name; break;
                        }

                        addColor2Data();
                    }
                }
                else
                    sheets.Add(int.Parse(s.Name), s);
            }

			loadRange();

            foreach (int s in sheets.Keys)
            {
                Worksheet sheet = sheets[s];

                for (int col = StartCol; col < EndCol; col++)
                {
                    for (int row = StartRow; row < EndRow; row++)
                    {
                        Range range = (Range)sheet.Cells[row, col];
                        string color = range.Cells.Interior.Color.ToString();
                        Color c = System.Drawing.ColorTranslator.FromOle(int.Parse(color));
                        c = Color.FromArgb(c.R, c.G, c.B);

                        Cell cell = range2cell(s, range);
                        if (checkColorAll(cell))
                            data.addCell(cell);

                        if ((cell.c.Name == COLORSINGLECRANEPATH || cell.c.Name == COLORDUALCRANEPATH) && cell.value != "")
                        {
                            Cell endPoint = findEndPoint(sheet, cell, EndRow, EndCol);
                            string type = "single";
                            if (cell.c.Name == COLORDUALCRANEPATH) type = "dual";
                            InlineStocker stk = new InlineStocker(cell.value, type, cell, endPoint);
                            data.inlineStocker.Add(stk);
                        }
                        else if (checkStartLinearMotor(cell))
                        {
                            List<Cell> bufferList = new List<Cell>();
                            Cell before = cell;
                            Cell endPoint = findEndPoint(sheet, before, StartRow, EndRow, StartCol, EndCol, "unknown");

                            while (endPoint.c.Name == COLORLINEARMOTORBUFFER || endPoint.c.Name == COLORCONVEYORCORNER)
                            {
                                bufferList.Add(endPoint);
                                string direction = "";
                                if (before.row < endPoint.row)
                                    direction = "up";
                                else if (before.row > endPoint.row)
                                    direction = "down";
                                else if (before.col < endPoint.col)
                                    direction = "left";
                                else
                                    direction = "right";

                                before = endPoint;
                                endPoint = findEndPoint(sheet, endPoint, StartRow, EndRow, StartCol, EndCol, direction);
                            }
                            string type = "conv";
                            if (cell.c.Name == COLORSTKOUTPORTL) type = "linear";
                            LinearMotor conv = new LinearMotor(cell.value, type, cell, endPoint, bufferList);
                            data.linearMotor.Add(conv);
                        }
                    }
                }
            }

            // Inline stocker의 설비(shelf, in-port, out-port, IO port) 검색
            foreach (InlineStocker stk in data.inlineStocker)
            {
                //stk의 방향 찾기
                if (stk.startCell.row == stk.endCell.row)
                    stk.direction = "horizontal";
                else
                    stk.direction = "vertical";

                foreach (int s in sheets.Keys)
                {
                    Worksheet sheet = sheets[s];

                    if (stk.direction == "horizontal")
                    {
                        //crane path 위의 cell 검색
                        if (stk.startCell.row > StartRow)
                        {
                            for (int c = stk.startCell.col; c <= stk.endCell.col; c++)
                            {
                                Cell b = range2cell(s, (Range)sheet.Cells[stk.startCell.row - 1, c]);
                                if (checkDefinedColor(b))
                                    stk.cells.Add(b);
                                if (b.c.Name == COLORIOPORT || b.c.Name == COLORBIINPORT || b.c.Name == COLORBIOUTPORT)
                                {
                                    stk.resource.Add(b);
                                    data.addResource(b);
                                }
                                if ((b.c.Name == COLORSTKINPORTC || b.c.Name == COLORSTKINPORTL) && b.value != "")
                                    stk.inputPort = b;
                            }
                        }
                        //crane path 아래의 cell 검색
                        if (stk.startCell.row < EndRow)
                        {
                            for (int c = stk.startCell.col; c <= stk.endCell.col; c++)
                            {
                                Cell b = range2cell(s, (Range)sheet.Cells[stk.startCell.row + 1, c]);
                                if (checkDefinedColor(b))
                                    stk.cells.Add(b);
                                if (b.c.Name == COLORIOPORT || b.c.Name == COLORBIINPORT || b.c.Name == COLORBIOUTPORT)
                                {
                                    stk.resource.Add(b);
                                    data.addResource(b);
                                }
                                if ((b.c.Name == COLORSTKINPORTC || b.c.Name == COLORSTKINPORTL) && b.value != "")
                                    stk.inputPort = b;
                            }
                        }
                    }
                    else
                    {
                        //crane path의 왼쪽 cell 검색
                        if (stk.startCell.col > StartCol)
                        {
                            for (int r = stk.startCell.row; r <= stk.endCell.row; r++)
                            {
                                Cell b = range2cell(s, (Range)sheet.Cells[r, stk.startCell.col - 1]);
                                if (checkDefinedColor(b))
                                    stk.cells.Add(b);
                                if (b.c.Name == COLORIOPORT || b.c.Name == COLORBIINPORT || b.c.Name == COLORBIOUTPORT)
                                {
                                    stk.resource.Add(b);
                                    data.addResource(b);
                                }
                                if ((b.c.Name == COLORSTKINPORTC || b.c.Name == COLORSTKINPORTL) && b.value != "")
                                    stk.inputPort = b;
                            }
                        }
                        //crane path의 오른쪽 cell 검색
                        if (stk.startCell.col < EndCol)
                        {
                            for (int r = stk.startCell.row; r <= stk.endCell.row; r++)
                            {
                                Cell b = range2cell(s, (Range)sheet.Cells[r, stk.startCell.col + 1]);
                                if (checkDefinedColor(b))
                                    stk.cells.Add(b);
                                if (b.c.Name == COLORIOPORT || b.c.Name == COLORBIINPORT || b.c.Name == COLORBIOUTPORT)
                                {
                                    stk.resource.Add(b);
                                    data.addResource(b);
                                }
                                if ((b.c.Name == COLORSTKINPORTC || b.c.Name == COLORSTKINPORTL) && b.value != "")
                                    stk.inputPort = b;
                            }
                        }
                    }
                }
            }

            book.Close(false);
            app.Quit();
            app = null;
        }

		public void convert()
		{
			VIPConverter converter = new VIPConverter(data, output);
			converter.convert();
		}

        private Boolean checkColorAll(Cell cell)
        {
            Color c = cell.c;
            return (c.Name == COLORSINGLECRANEPATH || c.Name == COLORDUALCRANEPATH || c.Name == COLORCONVEYORBELT || c.Name == COLORCONVEYORCORNER || c.Name == COLORLINEARMOTORLINE || c.Name == COLORLINEARMOTORBUFFER || c.Name == COLORSHELF || c.Name == COLORIOPORT || c.Name == COLORBIINPORT || c.Name == COLORBIOUTPORT || c.Name == COLORUNIINLINE || c.Name == COLORBIINLINE || c.Name == COLORSTKINPORTC || c.Name == COLORSTKOUTPORTC || c.Name == COLORSTKINPORTL || c.Name == COLORSTKOUTPORTL || c.Name == COLORSTKBIDIRECTIONPORT);
        }

        private Cell findEndPoint(Worksheet sheet, Cell cell, int EndRow, int EndCol)
        {
            Cell current = cell;
            Cell candidate = cell;
            Cell right = new Cell();
            Cell down = new Cell();
            int r = 0;
            int c = 0;

            if (cell.row < EndRow)
                down = range2cell(cell.sheet, (Range)sheet.Cells[cell.row + 1, cell.col]);
            if (cell.col < EndCol)
                right = range2cell(cell.sheet, (Range)sheet.Cells[cell.row, cell.col + 1]);

            if (down == null || (down.c.Name != COLORSINGLECRANEPATH && down.c.Name != COLORDUALCRANEPATH))
                c++;
            else
                r++;

            while (candidate.c.Name == COLORSINGLECRANEPATH || candidate.c.Name == COLORDUALCRANEPATH)
            {
                if (r > 0 && candidate.row == EndRow)
                    break;
                else if (c > 0 && candidate.col == EndCol)
                    break;
                candidate = range2cell(cell.sheet, (Range)sheet.Cells[candidate.row + r, candidate.col + c]);
                if (candidate.c.Name == COLORSINGLECRANEPATH || candidate.c.Name == COLORDUALCRANEPATH)
                    current = candidate;
            }

            return current;
        }

        private Cell findEndPoint(Worksheet sheet, Cell cell, int StartRow, int EndRow, int StartCol, int EndCol, string direction)
        {
            Cell current = cell;
            Cell candidate = cell;
            Cell right = new Cell();
            Cell left = new Cell();
            Cell up = new Cell();
            Cell down = new Cell();
            int r = 0;
            int c = 0;

            if (cell.col < EndCol)
                right = range2cell(cell.sheet, (Range)sheet.Cells[cell.row, cell.col + 1]);
            if (cell.col > StartCol)
                left = range2cell(cell.sheet, (Range)sheet.Cells[cell.row, cell.col - 1]);
            if (cell.row > StartRow)
                up = range2cell(cell.sheet, (Range)sheet.Cells[cell.row - 1, cell.col]);
            if (cell.row < EndRow)
                down = range2cell(cell.sheet, (Range)sheet.Cells[cell.row + 1, cell.col]);

            if (direction == "unknown")
            {
                if (right.c.Name == COLORLINEARMOTORLINE || right.c.Name == COLORCONVEYORBELT)
                    c++;
                else if (left.c.Name == COLORLINEARMOTORLINE || left.c.Name == COLORCONVEYORBELT)
                    c--;
                else if (up.c.Name == COLORLINEARMOTORLINE || up.c.Name == COLORCONVEYORBELT)
                    r--;
                else
                    r++;
            }
            else if (direction == "left")
            {
                if (right.c.Name == COLORLINEARMOTORLINE || right.c.Name == COLORCONVEYORBELT)
                    c++;
                else if (up.c.Name == COLORLINEARMOTORLINE || up.c.Name == COLORCONVEYORBELT)
                    r--;
                else
                    r++;
            }
            else if (direction == "right")
            {
                if (left.c.Name == COLORLINEARMOTORLINE || left.c.Name == COLORCONVEYORBELT)
                    c--;
                else if (up.c.Name == COLORLINEARMOTORLINE || up.c.Name == COLORCONVEYORBELT)
                    r--;
                else
                    r++;
            }
            else if (direction == "up")
            {
                if (right.c.Name == COLORLINEARMOTORLINE || right.c.Name == COLORCONVEYORBELT)
                    c++;
                else if (left.c.Name == COLORLINEARMOTORLINE || left.c.Name == COLORCONVEYORBELT)
                    c--;
                else
                    r++;
            }
            else
            {
                if (right.c.Name == COLORLINEARMOTORLINE || right.c.Name == COLORCONVEYORBELT)
                    c++;
                else if (left.c.Name == COLORLINEARMOTORLINE || left.c.Name == COLORCONVEYORBELT)
                    c--;
                else
                    r--;
            }

            if (c > 0)
                candidate = right;
            else if (c < 0)
                candidate = left;
            else if (r > 0)
                candidate = down;
            else
                candidate = up;

            while (candidate.c.Name == COLORLINEARMOTORLINE || candidate.c.Name == COLORLINEARMOTORBUFFER || candidate.c.Name == COLORCONVEYORBELT || candidate.c.Name == COLORCONVEYORCORNER || candidate.c.Name == COLORSTKINPORTC || candidate.c.Name == COLORSTKINPORTL || candidate.c.Name == COLORSTKBIDIRECTIONPORT)
            {
                candidate = range2cell(cell.sheet, (Range)sheet.Cells[current.row + r, current.col + c]);
                if (candidate.c.Name == COLORLINEARMOTORLINE || candidate.c.Name == COLORLINEARMOTORBUFFER || candidate.c.Name == COLORCONVEYORBELT || candidate.c.Name == COLORCONVEYORCORNER || candidate.c.Name == COLORSTKINPORTC || candidate.c.Name == COLORSTKINPORTL || candidate.c.Name == COLORSTKBIDIRECTIONPORT)
                    current = candidate;
                if (candidate.c.Name == COLORLINEARMOTORBUFFER || candidate.c.Name == COLORCONVEYORCORNER || candidate.c.Name == COLORSTKINPORTC || candidate.c.Name == COLORSTKINPORTL || candidate.c.Name == COLORSTKBIDIRECTIONPORT)
                    break;
            }

            return current;
        }

        public Cell range2cell(int s, Range r)
        {
            int sheet = s;
            int row = r.Row;
            int col = r.Column;
            string value = r.Text.ToString();
            string color = r.Cells.Interior.Color.ToString();
            Color c = System.Drawing.ColorTranslator.FromOle(int.Parse(color));
            c = Color.FromArgb(c.R, c.G, c.B);

            return new Cell(s, row, col, value, c);
        }

        public Boolean checkStartCranePath(Cell cell)
        {
            if ((cell.c.Name == COLORSINGLECRANEPATH || cell.c.Name == COLORDUALCRANEPATH) && cell.value != "")
                return true;
            else
                return false;
        }

        public Boolean checkStartLinearMotor(Cell cell)
        {
            if ((cell.c.Name == COLORSTKOUTPORTC || cell.c.Name == COLORSTKOUTPORTL || cell.c.Name == COLORSTKBIDIRECTIONPORT) && cell.value != "")
                return true;
            else
                return false;
        }

        private Boolean checkDefinedColor(Cell cell)
        {
            string c = cell.c.Name;
            if (c == COLORBIINPORT || c == COLORBIOUTPORT || c == COLORIOPORT || c == COLORLINEARMOTORBUFFER || c == COLORSHELF || c == COLORSTKBIDIRECTIONPORT || c == COLORSTKINPORTC || c == COLORSTKOUTPORTC || c == COLORSTKINPORTL || c == COLORSTKOUTPORTL)
                return true;
            else
                return false;
        }

        private void addColor2Data()
        {
            data.COLORSINGLECRANEPATH = COLORSINGLECRANEPATH;
            data.COLORDUALCRANEPATH = COLORDUALCRANEPATH;
            data.COLORLINEARMOTORLINE = COLORLINEARMOTORLINE;
            data.COLORLINEARMOTORBUFFER = COLORLINEARMOTORBUFFER;
            data.COLORSHELF = COLORSHELF;
            data.COLORIOPORT = COLORIOPORT;
            data.COLORBIINPORT = COLORBIINPORT;
            data.COLORBIOUTPORT = COLORBIOUTPORT;
            data.COLORUNIINLINE = COLORUNIINLINE;
            data.COLORBIINLINE = COLORBIINLINE;
            data.COLORSTKINPORTC = COLORSTKINPORTC;
            data.COLORSTKOUTPORTC = COLORSTKOUTPORTC;
            data.COLORSTKINPORTL = COLORSTKINPORTL;
            data.COLORSTKOUTPORTL = COLORSTKOUTPORTL;
            data.COLORSTKBIDIRECTIONPORT = COLORSTKBIDIRECTIONPORT;
        }
        #endregion
    }
}
