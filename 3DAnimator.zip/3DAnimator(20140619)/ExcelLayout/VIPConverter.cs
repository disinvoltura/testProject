﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;

namespace ExcelLayout
{
    //[Guid("F9DAF250-F40B-4305-BDE4-8C0D6351F252")]
    public class VIPConverter
    {
        #region Variables
        Info data;
		VIPInfo output;

        private string COLORSINGLECRANEPATH;
        private string COLORDUALCRANEPATH;
        private string COLORCONVEYORBELT;
        private string COLORCONVEYORCORNER;
        private string COLORLINEARMOTORLINE;
        private string COLORLINEARMOTORBUFFER;
        private string COLORSHELF;
        private string COLORIOPORT;
        private string COLORBIINPORT;
        private string COLORBIOUTPORT;
        private string COLORUNIINLINE;
        private string COLORBIINLINE;
        private string COLORSTKINPORTC;
        private string COLORSTKOUTPORTC;
        private string COLORSTKINPORTL;
        private string COLORSTKOUTPORTL;
        private string COLORSTKBIDIRECTIONPORT;

        private Dictionary<string, int> resourceCount;
		private Dictionary<string, string> resource3DModel;
		private List<string> conveyorList;
		private List<string> eqpList;
		private List<string> V_portType;
		private string V_numBuffer;
		private string V_buffer;
		private string V_bufferLocation;
		private string tempStr;

        private Dictionary<Cell, string> convQueue; //??

        private int scaleX;
        private int scaleY;
        private int scaleZ;

        private int minx;
        private int miny;
        private int maxx;
        private int maxy;

		private List<string> systemList;
        #endregion

        #region Constructor
        public VIPConverter(Info data, VIPInfo output)
        {
            this.data = data;
			this.output = output;

            COLORSINGLECRANEPATH = data.COLORSINGLECRANEPATH;
            COLORDUALCRANEPATH = data.COLORDUALCRANEPATH;
            COLORCONVEYORBELT = data.COLORCONVEYORBELT;
            COLORCONVEYORCORNER = data.COLORCONVEYORCORNER;
            COLORLINEARMOTORLINE = data.COLORLINEARMOTORLINE;
            COLORLINEARMOTORBUFFER = data.COLORLINEARMOTORBUFFER;
            COLORSHELF = data.COLORSHELF;
            COLORIOPORT = data.COLORIOPORT;
            COLORBIINPORT = data.COLORBIINPORT;
            COLORBIOUTPORT = data.COLORBIOUTPORT;
            COLORUNIINLINE = data.COLORUNIINLINE;
            COLORBIINLINE = data.COLORBIINLINE;
            COLORSTKINPORTC = data.COLORSTKINPORTC;
            COLORSTKOUTPORTC = data.COLORSTKOUTPORTC;
            COLORSTKINPORTL = data.COLORSTKINPORTL;
            COLORSTKOUTPORTL = data.COLORSTKOUTPORTL;
            COLORSTKBIDIRECTIONPORT = data.COLORSTKBIDIRECTIONPORT;

            resourceCount = new Dictionary<string, int>();
            resource3DModel = data.r;

            conveyorList = new List<string>();
            eqpList = new List<string>();
            V_portType = new List<string>();
            V_numBuffer = "";
            V_buffer = "";
			V_bufferLocation = "";
            tempStr = "";

			convQueue = new Dictionary<Cell, string>();

            scaleX = data.scaleX;
            scaleY = data.scaleY;
            scaleZ = data.scaleZ;

            minx = data.minCol;
            miny = data.minRow;
            maxx = data.maxCol;
            maxy = data.maxRow;

            systemList = new List<string>();
        }
        #endregion

        #region Methods
        public void convert()
        {
            Dictionary<string, string> queue = new Dictionary<string, string>();
            Dictionary<string, int> resources = new Dictionary<string, int>();
            List<string> resourceList = new List<string>();

            foreach (InlineStocker STK in data.inlineStocker)
            {
                if (STK.type == "single")
                {
					output.stocker.Add(new PathMoverSystem(STK.name));
                }
                else
                {
					output.stocker.Add(new PathMoverSystem(STK.name + "_1"));
					output.stocker.Add(new PathMoverSystem(STK.name + "_2"));
                }
            }

            Dictionary<int, LinearMotor> temp = new Dictionary<int, LinearMotor>();
            data.linearMotor.Sort(
                delegate(LinearMotor first, LinearMotor second)
                {
                    return first.name.CompareTo(second.name);
                }
            );
            conveyorList.Sort(
                delegate(string first, string second)
                {
                    return first.CompareTo(second);
                }
            );
            foreach (LinearMotor LM in data.linearMotor)
            {
                conveyorList.Add(LM.name);
                if (LM.startCell.c.Name == COLORSTKBIDIRECTIONPORT)
                {
                    string name = "CNV" + (data.linearMotor.Count + temp.Count + 1);
                    Cell startCell = LM.endCell;
                    Cell endCell = LM.startCell;
                    List<Cell> bufferList = new List<Cell>();
                    foreach (Cell c in LM.bufferList)
                    {
                        bufferList.Insert(0, c);
                    }
                    temp.Add(data.linearMotor.IndexOf(LM), new LinearMotor(name, LM.type, startCell, endCell, bufferList));
                }
            }
            foreach (LinearMotor LM in temp.Values)
            {
                data.linearMotor.Add(LM);
                conveyorList.Add(LM.name);
            }

			#region Linear Motor
			exportLinearMotor(queue);
			#endregion

            #region Inline Stocker
            exportInlineStocker(queue);
            #endregion

            foreach (ConveyorSystem conv in output.conveyor)
            {
                double sx = conv.getSP()[0];
                double sy = conv.getSP()[1];
                //double sz = conv.getSP()[2];

                foreach (Queue shelf in output.queues)
                {
                    if (shelf.getPositionX() == sx &&
                        shelf.getPositionY() == sy)
                        //shelf.getPositionZ() == sz)
                    {
                        shelf.setName ( "outport_" + conv.getName());
                        break;
                    }
                }

                double ex = conv.getEP()[0];
                double ey = conv.getEP()[1];
                //double ez = conv.getEP()[2];
                foreach (Queue shelf in output.queues)
                {
                    if (shelf.getPositionX() == ex &&
                        shelf.getPositionY() == ey)
                        //shelf.getPositionZ() == ez)
                    {
                        shelf.setName("inport_" + conv.getName());
                        break;
                    }
                }
            }
            
            #region Process System
            string rnd = "";
            string q = "";

            for (int i = 0; i < resourceCount.Count; i++)
            {
                rnd += "RNSTREAM stream_R_" + (i + 1) + "_1 10 type CMRG flags 1\r\n";
                rnd += "	title \"Generated automatically for R_" + (i + 1) + "\"\r\n";
            }

            foreach (string s in queue.Values)
                q += s;

            #endregion

            
        }

        private int findSide(InlineStocker STK, Cell cell)
        {
            if (STK.direction == "vertical")
            {
                if (cell.col < STK.startCell.col)
                    return 1;
                else
                    return 2;
            }
            else
            {
                if (cell.row < STK.startCell.row)
                    return 1;
                else
                    return 2;
            }
        }

        private string findType(Cell cell)
        {
            if (cell.c.Name == COLORSHELF)
                return "shelf";
            else if (cell.c.Name == COLORIOPORT || cell.c.Name == COLORBIINPORT || cell.c.Name == COLORBIOUTPORT)
                return "eqp";
            else if (cell.c.Name == COLORSTKINPORTC || cell.c.Name == COLORSTKINPORTL)
                return "inport";
            else if (cell.c.Name == COLORSTKOUTPORTC || cell.c.Name == COLORSTKOUTPORTL)
                return "outport";
            else if (cell.c.Name == COLORSTKBIDIRECTIONPORT)
                return "bidirectionport";
            else
                return null;

        }

        private ControlPoint makeControlPoint(string direction, string cp, int row, int col, int begRow, int begCol, int scaleX, int scaleY)
        {
			ControlPoint point = new ControlPoint(cp);

            if (direction == "horizontal")
            {
				point.setX((col - begCol) * scaleX + 0.5);
				point.setY(row * scaleY);
            }
            else
            {
				point.setY((row - begRow) * scaleY + 0.5);
				point.setX(col * scaleX);
            }
			return point;
        }

        private void exportInlineStocker(Dictionary<string, string> queue)
        {
			int si = 0;
            foreach (InlineStocker STK in data.inlineStocker)
            {
                int countBuffer = 0;
                int countInport = 0;
                int countOutport = 0;
                //int countAll = 0;

                //process system에 queue 생성
                queue.Add(STK.name, "");

                //path의 위치
                double bx, by, ex, ey;

                if (STK.direction == "horizontal")
                {
                    bx = (STK.startCell.col - minx) * scaleX - 1.0 / 2.0 * scaleX;
                    //by = -1 * ((STK.startCell.row - miny) * scaleY);
					by = ((STK.startCell.row - miny) * scaleY);
                    ex = bx + (STK.endCell.col - STK.startCell.col + 1) * scaleX;
                    ey = by;
                }
                else
                {
                    bx = (STK.startCell.col - minx) * scaleX;
                    //by = -1 * ((STK.startCell.row - miny - 1) * scaleY + 1.0 / 2.0 * scaleY);
					by =  ((STK.startCell.row - miny - 1) * scaleY + 1.0 / 2.0 * scaleY);
                    ex = bx + (STK.endCell.col - STK.startCell.col) * scaleX;
                    ey = by + (STK.endCell.row - STK.startCell.row + 1) * scaleY;
                }

				output.stocker[si].setSP(bx, by);
				output.stocker[si].setEP(ex, ey);
				if (STK.type != "single")
				{
					output.stocker[si+1].setSP(bx, by);
					output.stocker[si+1].setEP(ex, ey);
				}

                //shelf와 port
                foreach (Cell cell in STK.cells)
                {
                    string cp = "";
                    int side = findSide(STK, cell);
                    string type = findType(cell);

                    if (type != "bidirectionport") 
					{
						ControlPoint p = makeControlPoint(STK.direction, cp, cell.row, cell.col, STK.startCell.row, STK.startCell.col, scaleX, scaleY);
						if (STK.direction == "horizontal")
						{
							p.setX(bx + p.getX()); p.setY(by);
						}
						else
						{
							p.setX(bx); p.setY(by + p.getY());
						}

						output.stocker[si].addPoint(p);
						if (STK.type != "single")
							output.stocker[si + 1].addPoint(p);

						Queue shelf = new Queue(cp);
                        shelf.setStockerName(STK.name);
						shelf.setType("buffer");
						if(STK.direction == "horizontal")
							shelf.setPosition(p.getX(), (cell.row - miny) * scaleY, cell.sheet - 1);
						else
                            shelf.setPosition((cell.col - minx) * scaleX, p.getY(), cell.sheet - 1);

                        if (type == "shelf") 
						{				//shelf와 control point 만들기
							cp = STK.name + ":" + "buffer_" + side + "_" + cell.sheet + "_" + (++countBuffer);
							p.setName(cp);
							shelf.setName(cp);
							shelf.setType("buffer");
                        }
                        else if (type == "eqp")
                        {
							cp = "T" + cell.value;
							if (!resourceCount.ContainsKey("T" + cell.value))
							{
								resourceCount.Add("T" + cell.value, 0);
								/**/
								++resourceCount["T" + cell.value];
								Resource rs = new Resource(cp);
								output.resource.Add(rs);
								double rbx, rby, rex, rey;

								if (STK.direction == "horizontal")
								{
									if (cell.row < STK.startCell.row)
									{
										rbx = scaleX * (cell.col - minx + 0.5);
										rby = scaleY * (cell.row - miny - 0.5);
										rex = scaleX * (cell.col - minx + 1.5);
										rey = scaleY * (cell.row - miny - 2.5);
									}
									else
									{
										rbx = scaleX * (cell.col - minx + 0.5);
										rby = scaleY * (cell.row - miny + 0.5);
										rex = scaleX * (cell.col - minx + 1.5); 
										rey = scaleY * (cell.row - miny + 2.5);
									}
								}
								else
								{
									if (cell.col < STK.startCell.col)
									{
										rbx = scaleX * (cell.col - minx - 1.5);
										rby = scaleY * (cell.row - miny - 0.5);
										rex = scaleX * (cell.col - minx - 0.5);
										rey = scaleY * (cell.row - miny - 0.5);
									}
									else
									{
										rbx = scaleX * (cell.col - minx + 1.5);
										rby = scaleY * (cell.row - miny - 0.5);
										rex = scaleX * (cell.col - minx + 2.5);
										rey = scaleY * (cell.row - miny - 0.5);
									}
								}

								rs.setSP(rbx, rby); rs.setEP(rex, rey);
							}

							p.setName(cp);
							shelf.setName(cp);
							shelf.setTargetName("T" + cell.value);

                            if (cell.c.Name == COLORIOPORT) shelf.setType("TM_IO");
                            else if (cell.c.Name == COLORBIINPORT) shelf.setType("TM_I");
                            else shelf.setType("TM_O");
                        }
                        else if (type == "inport")
                        {
							cp = "inport_" + cell.value;
							/**/++countInport;
							p.setName(cp);
							shelf.setName(cp);
							shelf.setType("inport");   
                        }
                        else if (type == "outport")
                        {
							cp = "outport_" + cell.value; 
							/**/++countOutport;
							p.setName(cp);
							shelf.setName(cp);
							shelf.setTargetName(cp);
							shelf.setType("outport");
                        }

						output.queues.Add(shelf);
                        output.stocker[si].Queues.Add(shelf);
                    }
                    else //(type == "bidirectionport")
                    {
                        //역방향 queue
                    }
                }
				si++;
            }
		}

		private void exportLinearMotor(Dictionary<string, string> queue)
		{
			foreach (LinearMotor cnv in data.linearMotor)
			{
				if (cnv.type == "conv")
				{
					ConveyorSystem conveyor = new ConveyorSystem(cnv.name);
					output.conveyor.Add(conveyor);

					List<Cell> points = new List<Cell>();
					points.Add(cnv.startCell);
					foreach (Cell c in cnv.bufferList) points.Add(c);
					points.Add(cnv.endCell);

					/**/System.Diagnostics.Debug.WriteLine("Conveyor points: " + points.Count());

					int length = 0;

					for (int i = 1; i < points.Count; i++)
					{
						Cell startCell = points[i - 1];
						Cell endCell = points[i];

						double bx = 0.0;
						double by = 0.0;
						double ex = 0.0;
						double ey = 0.0;

						if (startCell.row == endCell.row)
						{
							length = scaleX * Math.Abs(endCell.col - startCell.col);
							if (startCell.col < endCell.col)    //좌->우
							{
								bx = scaleX * (startCell.col - minx);
								by = scaleY * (startCell.row - miny);
								ex = bx + scaleX * (endCell.col - startCell.col);
								ey = by;
							}
							else //우->좌
							{
								bx = scaleX * (startCell.col - minx);
								by = scaleY * (startCell.row - miny);
								ex = bx + (endCell.col - startCell.col) * scaleX;
								ey = by;
							}

							/**/
							System.Diagnostics.Debug.WriteLine("" + bx + ", " + by + ", " + ex + ", " + ey);
						}
						else if (startCell.col == endCell.col)
						{
							length = scaleY * Math.Abs(endCell.row - startCell.row);
							if (startCell.row < endCell.row)    //상->하
							{
								bx = (startCell.col - minx) * scaleX;
								by = scaleY * (startCell.row - miny);
								ex = bx;
								ey = by + scaleY * (endCell.row - startCell.row);
							}
							else //하->상
							{
								bx = (startCell.col - minx) * scaleX;
								by = scaleY * (startCell.row - miny);
								ex = bx;
								ey = by + scaleY * (endCell.row - startCell.row);
							}
						}
							
						if (i == 1)
							conveyor.setSP(bx, by);
						if (i == points.Count() - 1)
							conveyor.setEP(ex, ey);
						else
							conveyor.addPoint(new double[2] { ex, ey });
					}

                    //search conveyor's inport = stocker output
                    string outPortName = "inport_" + cnv.name;
                    string inPortName = "outport_" + cnv.name;
                    foreach (Queue q in output.queues)
                    {
                        if (q.getType() == "inport" && q.getName() == outPortName)
                        {

                        }
                        else if (q.getType() == "output" && q.getName() == inPortName)
                        {

                        }
                    }
				}
				else               //이건 부슨 type??
				{
					//일단 지우고 보자 Seyoun Park
				}

			}
		}

		#endregion
	}
}