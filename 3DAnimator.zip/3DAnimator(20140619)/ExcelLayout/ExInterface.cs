﻿//@Author Seyoun Park (2014-03)
//C# - C++ interoperation interface

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace ExcelLayout
{
    //[Guid("487D4E94-6DBC-4E85-B1C4-A992D21D1183")]
    public interface ExInterface
    {
        void parse();

        int getPathMoverSystemSize();
        int getConveyorSize();
        int getResourceSize();
        int getQueueSize();

		string getPathMoverSystemName(int i);
        string getConveyorName(int i);
        string getResourceName(int i);
        string getQueueName(int i);
        string getQueueType(int i);
        //IntPtr getPathMoverSystemName(int i);
        //IntPtr getConveyorName(int i);
        //IntPtr getResourceName(int i);
        //IntPtr getQueueName(int i);
        //IntPtr getQueueType(int i);
		int getControlPointSize(int si);
		double getControlPointX(int si, int ci);
		double getControlPointY(int si, int ci);
		string getControlPointName(int si, int ci);
        //IntPtr getControlPointName(int si, int ci);
		
		int getConveyorPathSize(int ci);
		double getConveyorPointX(int ci, int pi);
		double getConveyorPointY(int ci, int pi);
		double getResourcePosition(int i, int ax);
		double getResourceLength(int i, int ax);
		double getQueuePosition(int i, int ax);
		void set(string filePath);
    }
}
