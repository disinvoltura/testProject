﻿//@Author Seyoun Park (2014-03)

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExcelLayout
{
	public class Resource
	{
		string name;
		string type;
		double x, y;
		double[] sp;
		double[] ep;

		public Resource()
		{
			name = "";
			type = "";
			sp = new double[2];
			ep = new double[2];
		}
		public Resource(string n)
		{
			name = n;
			sp = new double[2];
			ep = new double[2];
		}
		public Resource(string n, string t, double px, double py)
		{
			name = n;
			type = t;
			sp = new double[2] {px, py};
			ep = new double[2];
		}

		public string getName() { return name; }
		public string getType() { return type; }
		public double getPositionX() { return (sp[0] + ep[0]) / 2; }
		public double getPositionY() { return (sp[1] + ep[1]) / 2; }
		public double getSizeX() { return Math.Abs(ep[0] - sp[0]); }
		public double getSizeY() { return Math.Abs(ep[1] - sp[1]); }
		public void setSP(double x, double y) { sp[0] = x; sp[1] = y; }
        public double[] getSP() { return sp; }
        public double[] getEP() { return ep; }
		public void setEP(double x, double y) { ep[0] = x; ep[1] = y; }
	}
}
