﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace ExcelLayout
{
    //[Guid("D984439D-C250-4868-BBB5-DA944D730BA3")]
    public class PathMoverSystem
    {
        #region Variables
        private string name;
		private string type;
		private double[] sp;
		private double[] ep;
		private List<ControlPoint> points;
        private Boolean complete;
        private int Cap;
        private int ST;
        private int PT;
        private int NV;
        private int VV;

        public List<Queue> Queues;
        #endregion

        #region Constructor
		public PathMoverSystem(string name)
		{
			this.name = name;
			this.type = "";
			this.sp = new double[2];
			this.ep = new double[2];
			this.points = new List<ControlPoint>();
            this.Queues = new List<Queue>();
			this.complete = true;
		}
		public PathMoverSystem(string name, double sx, double sy, double ex, double ey)
        {
            this.name = name;
			this.type = "";
			this.sp = new double[2] { sx, sy };
			this.ep = new double[2] { ex, ey };
			this.points = new List<ControlPoint>();
            this.Queues = new List<Queue>();
            this.complete = true;
        }
        #endregion

        #region Methods
        public string getName()
        {
            return name;
        }
		public string getType()
		{
			return type;
		}

		public double[] getSP()
        {
            return sp;
        }

		public double[] getEP()
        {
            return ep;
        }
		public ControlPoint getPoit(int pi)
		{
			return points[pi];
		}

        public int[] getOption()
        {
            return new int[5] { Cap, ST, PT, NV, VV };
        }
        public void setName(string name)
        {
            this.name = name;
        }
		public void setType(string type)
		{
			this.type = type;
		}
		public void setSP(double x, double y)
        {
			this.sp = new double[2] { x, y };
        }
		public void setEP(double x, double y)
        {
			this.ep = new double[2] { x, y };
        }
        public void addPoint(int x, int y)
        {
            points.Add(new ControlPoint(x, y));
        }
		public void addPoint(ControlPoint p)
		{
			points.Add(p);
		}
        public void setComplete(Boolean complete)
        {
            this.complete = complete;
        }
        public void setOption(int Cap, int ST, int PT, int NV, int VV)
        {
            this.Cap = Cap;
            this.ST = ST;
            this.PT = PT;
            this.NV = NV;
            this.VV = VV;
        }
		public int getPointSize()
		{
			return points.Count();
		}
        #endregion
    }
}
