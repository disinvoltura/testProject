﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace ExcelLayout
{
   //// [ComVisible(true)]
   // [Guid("78828F68-03BE-42C8-AAC2-AB1FC9BF30A4")]
    public class InlineStocker
    {
        #region Variables
        public string name;
        public string type;
        public Cell startCell;
        public Cell endCell;
        public string direction;
        public List<Cell> cells;
        public List<Cell> resource;
        public Cell inputPort;
        #endregion

        #region Constructor
        public InlineStocker(string name, string type, Cell startCell, Cell endCell)
        {
            this.name = name;
            this.type = type;
            this.startCell = startCell;
            this.endCell = endCell;
            cells = new List<Cell>();
            resource = new List<Cell>();
        }
        #endregion
    }
}
