﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace ExcelLayout
{
    //[Guid("117681DF-CA19-4E40-9B0D-F04C7276F093")]
    public class ConveyorSystem
    {
        #region Variables
        private string name;
        private int floor;
		private double[] sp;
		private double[] ep;
		private List<double[]> points;
        private Boolean complete;
        private double SV;
        private double SA;
        private double SD;
		
		Queue inport, outport;			//Seyoun Park (2014-03)

        #endregion

        #region Constructor
		public ConveyorSystem(string name)
		{
			this.name = name;
			sp = new double[2];
			ep = new double[2];
			points = new List<double[]>();
			complete = true;
		}
        public ConveyorSystem(string name, int sx, int sy)
        {
            this.name = name;
			sp = new double[2] { sx, sy };
			ep = new double[2];
			points = new List<double[]>();
            complete = true;
        }
        #endregion

        #region Methods
        public string getName()
        {
            return name;
        }

        public int getFloor()
        {
            return floor;
        }

		public double[] getSP()
        {
            return sp;
        }

		public double[] getEP()
        {
            return ep;
        }

		public List<double[]> getPoints()
        {
            return points;
        }

		public double[] getPoint(int i)
		{
			if (i == 0) return sp;
			if (i == points.Count() + 1) return ep;
			return points[i-1];
		}
        public Boolean getComplete()
        {
            return complete;
        }

        public double[] getOption()
        {
            return new double[3] { SV, SA, SD };
        }

        public void setName(string name)
        {
            this.name = name;
        }

        public void setFloor(int s)
        {
            floor = s;
        }

		public void setSP(double x, double y)
        {
			this.sp = new double[2] { x, y };
        }

		public void setEP(double x, double y)
        {
			this.ep = new double[2] { x, y };
        }

		public void addPoint(double[] p)
		{
			points.Add(p);
		}
		public void addPoint(List<double[]> paths)
        {
			foreach (double[] path in paths)
                points.Add(path);
        }

        public void setComplete(Boolean complete)
        {
            this.complete = complete;
        }

        public void setOption(double SV, double SA, double SD)
        {
            this.SV = SV;
            this.SA = SA;
            this.SD = SD;
        }
		public int getNoPoints()
		{
			return (points.Count() + 2);
		}

        #endregion
    }
}
