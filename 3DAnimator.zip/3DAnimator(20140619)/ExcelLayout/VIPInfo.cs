﻿//@Author Seyoun Park(2014-03)

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExcelLayout
{
	public class VIPInfo
	{
		public List<PathMoverSystem> stocker;
		public List<ConveyorSystem> conveyor;
		public List<Resource> resource;
		public List<Queue> queues;				//buffer

		public VIPInfo()
		{
			stocker = new List<PathMoverSystem>();
			conveyor = new List<ConveyorSystem>();
			resource = new List<Resource>();
			queues = new List<Queue>();
		}
	}
}
