﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExcelLayout
{
	public class ControlPoint
	{
		string name;
		string type;
		double x, y;

		public ControlPoint(string name)
		{
			this.name = name;
			type = "";
			x = y = 0;
		}
		public ControlPoint(double x, double y)
		{
			name = "";
			type = "";
			this.x = x; this.y = y;
		}
		public void setName(string name)
		{
			this.name = name;
		}
		public void setType(string type)
		{
			this.type = type;
		}
		public string getName() { return name; }
		public string getType() { return type; }
		public double getX() { return x; }
		public double getY() { return y; }
		public void setX(double x) { this.x = x; }
		public void setY(double y) { this.y = y; }
	}
}
