﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Runtime.InteropServices;

namespace ExcelLayout
{
    public class Cell
    {
        public int sheet;
        public int row;
        public int col;
        public string value;
        public Color c;

        public Cell()
        {
            c = new Color();
        }

        public Cell(int sheet, int row, int col, string value, Color c)
        {
            this.sheet = sheet;
            this.row = row;
            this.col = col;
            this.value = value;
            this.c = c;
        }
    }
}
