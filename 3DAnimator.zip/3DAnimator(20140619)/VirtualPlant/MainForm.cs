﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Mogre;
using MOIS;

namespace VMS.VirtualPlant
{
    public partial class MainForm : Form
    {
        public static MainForm App;

        private bool _IsInitialized = false;

        private OutputWindow _OutputWindow;
        public double TimeScale
        {
            get { return _TimeScale; }
        }

        private World _World;

        public World World
        {
            get { return _World; }
        }
        public double Clock
        {
            get { return _Clock; }
        }

        private ApplicationConnector _Connector;

        #region Constructors
        public MainForm()
        {
            Form.CheckForIllegalCrossThreadCalls = false;
            MainForm.App = this;

            InitializeComponent();

            this.Size = new Size(800, 600);
            Disposed += new EventHandler(Form_Disposed);
            Resize += new EventHandler(Form_Resize);

            //_OutputWindow = new OutputWindow();
        }
        #endregion

        #region Windows Event Handlers
        void Form_Disposed(object sender, EventArgs e)
        {
            if (_World != null)
                _World.Dispose();
        }

        void Form_Resize(object sender, EventArgs e)
        {
            if (_World != null)
                _World.Window.WindowMovedOrResized();
        }
        #endregion

        #region 3D methods
        public void Go()
        {
            Show();

            while (!_IsInitialized)
            {
                try
                {
                    Application.DoEvents();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(ex.ToString());
                }
            }
            while (_World.Root != null
                && _World.Root.RenderOneFrame())
            {
                try
                {
                    Application.DoEvents();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(ex.ToString());
                }
            }            
        }

        public void Init()
        {
            _World = new World(this);
            _World.Initialize();
        }
        #endregion

        #region toolbar event handlers
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            _World.Camera.Yaw(new Radian(0.01f));
        }

        private void yawCameraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _World.Camera.Yaw(new Radian(-0.01f));
        }

        private void setLockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //_Locked = true;
            _World.Locked = true;
        }

        private void freeLockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _World.Locked = false;
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Thread t = new Thread(new ThreadStart(doConnect));
            t.Start();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            //ApplicationConnector.Instance.Disconnect();
        }

        private void outputToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _OutputWindow.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            doOpen();
        }
        #endregion

        #region Communication Methods
        private void doConnect()
        {
            _Connector = new ApplicationConnector();
            if (_Connector.Connect())
            {
                _Locked = false;

                doRun();

            }
        }


        
        private bool _Locked = true;
        

        private double _Clock;
        private double _TimeScale = 10;
        private ApplicationMessage _ClockMsg;
        private bool _Wait = false;
        
        
        private DateTime _LastWallClock;

        private System.Windows.Forms.Timer _Timer;
        private AutoResetEvent _ASE;
        private void doRun()
        {
            ApplicationMessage msg;
            _Clock = 0;
            EventQueue.Instance.Enqueued += new EnqueuedEventHandler(Instance_Enqueued);
            _Timer = new System.Windows.Forms.Timer();
            _Timer.Tick += new EventHandler(_Timer_Tick);
            _ASE = new AutoResetEvent(false);

            while (true)
            {
                if (_Locked)
                    continue;
              
                do
                {
                    System.Diagnostics.Debug.WriteLine("[EventDispatcher] reading....");
                    string rawMsg = _Connector.Read_Msg();
                    
                    msg = ApplicationMessage.Parse(rawMsg);

                    if (msg.Type == ApplicationMessageType.Delay ||
                        msg.Type == ApplicationMessageType.EmptyCst)
                    {
                        bool rslt = _World.Plant.ProcessEvent(new VIPEvent(null, msg, null, msg.EventTime, false));

                        System.Diagnostics.Debug.WriteLine("[EventDispatcher] Application Message is Processed/");
                    }
                } while (msg.Type != ApplicationMessageType.Clock);

                _ClockMsg = msg;

                if (msg.Action == "Nothing")
                {
                    System.Diagnostics.Debug.WriteLine("[EventDispatcher] Handle Clock_Nothing");
                    _LastWallClock = DateTime.Now;
                    lock (_locker)
                    {
                        _Wait = true;
                    }
                    _World.FreeLock();
                    
                    //while (_Wait)
                    //    continue;

                    if (_ASE.WaitOne())
                    {
                        //got signal: handle delay_deliver
                        DateTime curTime = DateTime.Now;
                        TimeSpan elaspedTime = curTime.Subtract(_LastWallClock);

                        _World.SetLock();

                        System.Diagnostics.Debug.WriteLine("[EventDispatcher] New VIPEvent is enqueued.");
                        System.Diagnostics.Debug.WriteLine("[EventDispatcher] - Current Time: " + curTime.ToString());
                        System.Diagnostics.Debug.WriteLine("[EventDispatcher] - Physical ElapsedTime: " + elaspedTime.TotalSeconds + " seconds.");

                        double logicalElapsedTime = elaspedTime.TotalMilliseconds * _TimeScale / 1000;
                        System.Diagnostics.Debug.WriteLine("[EventDispatcher] - Localgical ElapsedTime: " + logicalElapsedTime + " seconds.");
                        _Clock += logicalElapsedTime;
                        VIPEvent e = EventQueue.Instance.Dequeue();
                        e.Message.EventTime = _Clock;
                        e.Time = _Clock;
                        _Connector.Send_Msg(e);
                    }

                    lock (_locker)
                    {
                        _Wait = false;
                    }
                }
                else if (msg.EventTime == _Clock || System.Math.Abs(msg.EventTime - _Clock) < 0.00001)
                {
                    System.Diagnostics.Debug.WriteLine("[EventDispatcher] Handle Clock_Exist, immediately");
                    _Connector.Send_Msg(new VIPEvent(null, msg, null, msg.EventTime, false));
                }
                else if (_Clock < msg.EventTime)
                {
                    System.Diagnostics.Debug.WriteLine("[EventDispatcher] Handle Clock_Exist with time advance");
                    double logicalDelayTime = msg.EventTime - _Clock ;
                    int physicalDelayTime = (int)(logicalDelayTime * 1000 / _TimeScale);
                    System.Diagnostics.Debug.WriteLine("[EventDispatcher] Time to Delay (Logical,Physical)= (" + logicalDelayTime + ", " + physicalDelayTime + ")");
                    
                    lock (_locker)
                    {
                        _Wait = true;
                    }
                    
                    _LastWallClock = DateTime.Now;
                    System.Diagnostics.Debug.WriteLine("[EventDispatcher] Last Wall Clock: " + _LastWallClock.ToString());
                    _World.FreeLock();
                    
                    if (_ASE.WaitOne(physicalDelayTime))
                    {
                        //got signal: handle delay_deliver
                        DateTime curTime = DateTime.Now;
                        TimeSpan elaspedTime = curTime.Subtract(_LastWallClock);

                        _World.SetLock();
            
                        System.Diagnostics.Debug.WriteLine("[EventDispatcher] New VIPEvent is enqueued.");
                        System.Diagnostics.Debug.WriteLine("[EventDispatcher] - Current Time: " + curTime.ToString());
                        System.Diagnostics.Debug.WriteLine("[EventDispatcher] - Physical ElapsedTime: " + elaspedTime.TotalSeconds + " seconds.");
            
                        double logicalElapsedTime = elaspedTime.TotalMilliseconds * _TimeScale / 1000;
                        System.Diagnostics.Debug.WriteLine("[EventDispatcher] - Localgical ElapsedTime: " + logicalElapsedTime + " seconds.");
                        _Clock += logicalElapsedTime;
                        VIPEvent e = EventQueue.Instance.Dequeue();
                        e.Message.EventTime = _Clock;
                        e.Time = _Clock;
                        _Connector.Send_Msg(e);
            
                        
                    }else{
                        //timeout....
                        System.Diagnostics.Debug.WriteLine("[EventDispatcher] Time Advanced (Timer_Tick).");
                        _World.SetLock();

                        _Clock = _ClockMsg.EventTime;
                        _Connector.Send_Msg(new VIPEvent(null, _ClockMsg, null, _ClockMsg.EventTime, false));

                    }

                    lock (_locker)
                    {
                        _Wait = false;
                    }
                    //_Timer = new System.Windows.Forms.Timer();
                    //_Timer.Enabled = true;
                    //_Timer.Interval = physicalDelayTime;
                    //_Timer.Tick += new EventHandler(_Timer_Tick);
                    //_Timer.Start();

                    

                    //while (_Wait)
                    //    continue;
                }

                System.Diagnostics.Debug.WriteLine("[EventDispatcher] EventDispatcher.Iteration ends");
            }
        }


        readonly object _locker = new object();

        private void Instance_Enqueued()
        {
            _ASE.Set();
            return;

            DateTime curTime = DateTime.Now;
            TimeSpan elaspedTime = curTime.Subtract(_LastWallClock);

            _World.SetLock();
            
            if (_Timer != null && _Timer.Enabled)
                _Timer.Stop();

            System.Diagnostics.Debug.WriteLine("[EventDispatcher] New VIPEvent is enqueued.");
            
            System.Diagnostics.Debug.WriteLine("[EventDispatcher] - Current Time: " + curTime.ToString());
            
            System.Diagnostics.Debug.WriteLine("[EventDispatcher] - Physical ElapsedTime: " + elaspedTime.TotalSeconds + " seconds.");
            
            double logicalElapsedTime = elaspedTime.TotalMilliseconds * _TimeScale / 1000;
            System.Diagnostics.Debug.WriteLine("[EventDispatcher] - Localgical ElapsedTime: " + logicalElapsedTime + " seconds.");
            _Clock += logicalElapsedTime;
            VIPEvent e = EventQueue.Instance.Dequeue();
            e.Message.EventTime = _Clock;
            e.Time = _Clock;
            _Connector.Send_Msg(e);

            
            lock (_locker)
            {
                _Wait = false;
            }
        }

        void _Timer_Tick(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("[EventDispatcher] Time Advanced (Timer_Tick).");
            _World.SetLock();
            _Timer.Stop();

            _Clock = _ClockMsg.EventTime;
            _Connector.Send_Msg(new VIPEvent(null, _ClockMsg, null, _ClockMsg.EventTime, false));

            

            lock (_locker)
            {
                _Wait = false;
            }
        }

        

        public void WriteOutput(string line)
        {
            _OutputWindow.WriteLine(line);
        }
        #endregion

        #region Menu Handlers
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            doOpen();
        }

        private void doOpen()
        {
            System.Threading.Thread.CurrentThread.SetApartmentState(System.Threading.ApartmentState.STA);

            GetFileNameClass oGetFileName = new GetFileNameClass();
            oGetFileName.Filter = "Excel Files (*.xlsx)|*.xlsx|Excel files (*.xls)|*.xls|All files (*.*)|*.*"; 
            oGetFileName.InitialDirectory =
                Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            Thread threadGetExcelFile = new Thread(new ThreadStart(oGetFileName.GetFileName));
            threadGetExcelFile.ApartmentState = ApartmentState.STA;
            try
            {
                threadGetExcelFile.Start();
                while (!threadGetExcelFile.IsAlive) ; // Wait for thread to get started
                Thread.Sleep(1);  // Wait a sec more
                threadGetExcelFile.Join();    // Wait for thread to end

                // Use file name as you will here
                _World.Load(oGetFileName.FileName);
                _IsInitialized = true;
            }
            catch (Exception ex)
            {
                //_SBO_Application.MessageBox(ex.Message, 1, "OK", "", "");
            }
            threadGetExcelFile = null;
            oGetFileName = null;
        }

        private void toolStripButton1_Click_1(object sender, EventArgs e)
        {
            _World.LoadTest();
            _IsInitialized = true;
        }

        private int LoadNo = 1;
        private void loadAJobToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _World.AddALoad();
        }

        private void removeAJobToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _World.RemoveJob();
        }

        /*
        private void doOpen()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            //ofd.Filter = "Excel Files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
            //ofd.DefaultExt = "xlsx";

            DialogResult rslt = ofd.ShowDialog();
            if (rslt == DialogResult.OK)
            {
                string fileName = ofd.FileName;

                _World.Load(fileName);
                
            }
        }*/
        #endregion

        
    }
}
