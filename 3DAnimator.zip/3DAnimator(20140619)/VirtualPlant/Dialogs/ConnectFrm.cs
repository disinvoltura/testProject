﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VMS.VirtualPlant
{
    public partial class ConnectFrm : Form
    {
        #region Member Variables
        private string _IP;
        private int _Port;
        #endregion

        #region Properties
        public string IP { get { return _IP; } }
        public int Port { get { return _Port; } }
        #endregion

        #region Constructors
        public ConnectFrm()
        {
            InitializeComponent();
        }
        #endregion

        #region Event Handlers 
        private void ConnectFrm_Load(object sender, EventArgs e)
        {
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) 
                || string.IsNullOrEmpty(textBox2.Text))
                return;

            _IP = textBox1.Text;
            if (!int.TryParse(textBox2.Text, out _Port))
            {
                MessageBox.Show ("Please, check the Port field [0~].");
                return;
            }

            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }
        #endregion
    }
}
