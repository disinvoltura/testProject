﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mogre;
using MOIS;
using System.Windows.Forms;

namespace VMS.VirtualPlant
{
    public class World
    {
        #region Member Variables
        private Form _Parent;
        private Root _Root;
        private SceneManager _Mgr;
        private Camera _Camera;
        private  CameraMan _CameraMan;
        private RenderWindow _Window;

        protected int mTextureMode = 0;
        protected int mRenderMode = 0;

        protected MOIS.InputManager mInputMgr;
        protected MOIS.Keyboard mLocalKeyboard;
        protected MOIS.Mouse mLocalMouse;

        private Plant _Plant;
        private bool _Locked = false;
        #endregion

        #region Properties
        public Root Root{
            get { return _Root;}
        }
        public RenderWindow Window
        {
            get { return _Window; }
            set { _Window = value; }
        }

        public Plant Plant
        {
            get { return _Plant; }
        }
        public Camera Camera
        {
            get { return _Camera; }
        }
        public bool Locked
        {
            get { return _Locked; }
            set { _Locked = value; }
        }

        #endregion

        #region Constructors
        public World(Form parent)
        {
            _Parent = parent;
            _Locked = true;
            //_Mgr = mgr;
            //_Window = window;
        }
        #endregion

        #region Initialization Methods
        public void Initialize()
        {
            // Create root object         
            _Root = new Root();
            _Root.FrameRenderingQueued += 
                new FrameListener.FrameRenderingQueuedHandler(ProcessBufferedInput);

            // Define Resources
            ConfigFile cf = new ConfigFile();
            cf.Load("resources.cfg", "\t:=", true);
            ConfigFile.SectionIterator seci = cf.GetSectionIterator();
            String secName, typeName, archName;

            while (seci.MoveNext())
            {
                secName = seci.CurrentKey;
                ConfigFile.SettingsMultiMap settings = seci.Current;
                foreach (KeyValuePair<string, string> pair in settings)
                {
                    typeName = pair.Key;
                    archName = pair.Value;
                    ResourceGroupManager.Singleton.AddResourceLocation(archName, typeName, secName);
                }
            }

            // Setup RenderSystem
            RenderSystem rs = _Root.GetRenderSystemByName("Direct3D9 Rendering Subsystem");
            // or use "OpenGL Rendering Subsystem"
            _Root.RenderSystem = rs;
            rs.SetConfigOption("Full Screen", "No");
            rs.SetConfigOption("Video Mode", "800 x 600 @ 32-bit colour");

            // Create Render Window
            _Root.Initialise(false, "Virtual Plant");
            NameValuePairList misc = new NameValuePairList();
            misc["externalWindowHandle"] = _Parent.Handle.ToString();
            _Window = _Root.CreateRenderWindow("Main RenderWindow", 800, 600, false, misc);

            // Init resources
            TextureManager.Singleton.DefaultNumMipmaps = 5;
            ResourceGroupManager.Singleton.InitialiseAllResourceGroups();

            _Mgr = _Root.CreateSceneManager(SceneType.ST_GENERIC);
            
            EventQueue eq = new EventQueue();
            ProcessSystem ps = new ProcessSystem(_Mgr);

            _Locked = true;
            //CreateScene(fileName);
            //EventDispatcher.Instance.Plant = _Plant;

            //InitializeInput();

            
        }

        private void CreateSceneTest()
        {
            _Camera = _Mgr.CreateCamera("Camera");
            _Camera.AutoAspectRatio = true;
            _Window.AddViewport(_Camera);

            readLayoutTest();

            //plane
            MaterialPtr mat = MaterialManager.Singleton.Create(
                "PlaneMat", ResourceGroupManager.DEFAULT_RESOURCE_GROUP_NAME);
            Plane plane = new Plane(Mogre.Vector3.UNIT_Y, 0);
            MeshManager.Singleton.CreatePlane("ground",
                    ResourceGroupManager.DEFAULT_RESOURCE_GROUP_NAME, plane,
                    1500, 1500, 20, 20, true, 1, 5, 5, Mogre.Vector3.UNIT_Z);
            Entity groundEnt = _Mgr.CreateEntity("GroundEntity", "ground");
            _Mgr.RootSceneNode.CreateChildSceneNode().AttachObject(groundEnt);
            groundEnt.SetMaterialName("Examples/BumpyMetal"); //
            groundEnt.CastShadows = false;

            //camera
            _Camera.Position = new Mogre.Vector3(0, -600, 0);
            _Camera.SetFixedYawAxis(true, new Mogre.Vector3(1, 0, 0));
            _Camera.LookAt(new Mogre.Vector3(0, 0, 0));
            _Camera.Roll(new Radian(1.57079633f));
            //mCamera.LookAt(lastEntity.BoundingBox.Center);//(new Mors01Node.b.BoundingBox.Center);
            _CameraMan = new CameraMan(_Camera);
        }

        private void CreateScene(string fileName)
        {
            _Camera = _Mgr.CreateCamera("Camera");
            _Camera.AutoAspectRatio = true;
            _Window.AddViewport(_Camera);

            readLayoutTest();

            //plane
            MaterialPtr mat = MaterialManager.Singleton.Create(
                "PlaneMat", ResourceGroupManager.DEFAULT_RESOURCE_GROUP_NAME);
            Plane plane = new Plane(Mogre.Vector3.UNIT_Y, 0);
            MeshManager.Singleton.CreatePlane("ground",
                    ResourceGroupManager.DEFAULT_RESOURCE_GROUP_NAME, plane,
                    1500, 1500, 20, 20, true, 1, 5, 5, Mogre.Vector3.UNIT_Z);
            Entity groundEnt = _Mgr.CreateEntity("GroundEntity", "ground");
            _Mgr.RootSceneNode.CreateChildSceneNode().AttachObject(groundEnt);
            groundEnt.SetMaterialName("Examples/BumpyMetal"); //
            groundEnt.CastShadows = false;

            //camera
            _Camera.Position = new Mogre.Vector3(0, -600, 0);
            _Camera.SetFixedYawAxis(true, new Mogre.Vector3(1, 0, 0));
            _Camera.LookAt(new Mogre.Vector3(0, 0, 0));
            _Camera.Roll(new Radian(1.57079633f));
            //mCamera.LookAt(lastEntity.BoundingBox.Center);//(new Mors01Node.b.BoundingBox.Center);
            _CameraMan = new CameraMan(_Camera);

        }

        private void InitializeInput()
        {
            int windowHnd;
            _Window.GetCustomAttribute("WINDOW", out windowHnd);
            var inputMgr = MOIS.InputManager.CreateInputSystem((uint)windowHnd);

            mLocalKeyboard = (MOIS.Keyboard)inputMgr.CreateInputObject(MOIS.Type.OISKeyboard, true);
            //mLocalMouse = (MOIS.Mouse)inputMgr.CreateInputObject(MOIS.Type.OISMouse, true);

            mLocalKeyboard.KeyPressed += new MOIS.KeyListener.KeyPressedHandler(OnKeyPressed);
            mLocalKeyboard.KeyReleased += new MOIS.KeyListener.KeyReleasedHandler(OnKeyReleased);
            //mLocalMouse.MouseMoved += new MOIS.MouseListener.MouseMovedHandler(OnMouseMoved);
            //mLocalMouse.MousePressed += new MOIS.MouseListener.MousePressedHandler(OnMousePressed);
            //mLocalMouse.MouseReleased += new MOIS.MouseListener.MouseReleasedHandler(OnMouseReleased);

        }
        #endregion

        #region Update Methods
        private bool ProcessBufferedInput(FrameEvent evt)
        {
            try
            {
                ProcessInput();

                UpdateScence(evt);

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }

        }

        private void ProcessInput()
        {
            if (mLocalKeyboard != null)
                mLocalKeyboard.Capture();
            //mLocalMouse.Capture();
        }

         readonly object _locker = new object();
 
        public void SetLock()
        {
            lock (_locker)
            {
                _Locked = true;
            }
        }

        public void FreeLock()
        {
            lock (_locker)
            {
                _Locked = false;
            }
        }

        private void UpdateScence(FrameEvent evt)
        {
            if (_Locked)
                return;
        
            if (_Parent != null)
                _Plant.UpdatePosition(evt.timeSinceLastFrame);

            if (_CameraMan != null)
                _CameraMan.UpdateCamera(evt.timeSinceLastFrame);

        }
        #endregion

        #region Keyboard Input Handling Methods
        private bool OnKeyPressed(KeyEvent evt)
        {
            switch (evt.key)
            {
                case KeyCode.KC_W:
                case KeyCode.KC_UP:
                    _CameraMan.GoingForward = true;
                    break;

                case KeyCode.KC_S:
                case KeyCode.KC_DOWN:
                    _CameraMan.GoingBack = true;
                    break;

                case KeyCode.KC_A:
                case KeyCode.KC_LEFT:
                    _CameraMan.GoingLeft = true;
                    break;

                case KeyCode.KC_D:
                case KeyCode.KC_RIGHT:
                    _CameraMan.GoingRight = true;
                    break;

                case KeyCode.KC_E:
                case KeyCode.KC_PGUP:
                    _CameraMan.GoingUp = true;
                    break;

                case KeyCode.KC_Q:
                case KeyCode.KC_PGDOWN:
                    _CameraMan.GoingDown = true;
                    break;

                case KeyCode.KC_LSHIFT:
                case KeyCode.KC_RSHIFT:
                    _CameraMan.FastMove = true;
                    break;

                case KeyCode.KC_T:
                    CycleTextureFilteringMode();
                    break;

                case KeyCode.KC_R:
                    CyclePolygonMode();
                    break;

                case KeyCode.KC_F5:
                    ReloadAllTextures();
                    break;

                case KeyCode.KC_SYSRQ:
                    TakeScreenshot();
                    break;

                case KeyCode.KC_ESCAPE:
                    Shutdown();
                    break;
            }

            return true;
        }

        protected virtual bool OnKeyReleased(KeyEvent evt)
        {
            switch (evt.key)
            {
                case KeyCode.KC_W:
                case KeyCode.KC_UP:
                    _CameraMan.GoingForward = false;
                    break;

                case KeyCode.KC_S:
                case KeyCode.KC_DOWN:
                    _CameraMan.GoingBack = false;
                    break;

                case KeyCode.KC_A:
                case KeyCode.KC_LEFT:
                    _CameraMan.GoingLeft = false;
                    break;

                case KeyCode.KC_D:
                case KeyCode.KC_RIGHT:
                    _CameraMan.GoingRight = false;
                    break;

                case KeyCode.KC_E:
                case KeyCode.KC_PGUP:
                    _CameraMan.GoingUp = false;
                    break;

                case KeyCode.KC_Q:
                case KeyCode.KC_PGDOWN:
                    _CameraMan.GoingDown = false;
                    break;

                case KeyCode.KC_LSHIFT:
                case KeyCode.KC_RSHIFT:
                    _CameraMan.FastMove = false;
                    break;
            }
            return true;
        }
        #endregion

        #region Mouse Input Handling Methods
        protected virtual bool OnMouseMoved(MouseEvent evt)
        {
            _CameraMan.MouseMovement(evt.state.X.rel, evt.state.Y.rel);
            return true;
        }

        protected virtual bool OnMousePressed(MouseEvent evt, MouseButtonID id)
        {
            return true;
        }

        protected virtual bool OnMouseReleased(MouseEvent evt, MouseButtonID id)
        {
            return true;
        }
        #endregion

        #region Methods
        protected void ReloadAllTextures()
        {
            TextureManager.Singleton.ReloadAll();
        }

        protected void CycleTextureFilteringMode()
        {
            mTextureMode = (mTextureMode + 1) % 4;
            switch (mTextureMode)
            {
                case 0:
                    MaterialManager.Singleton.SetDefaultTextureFiltering(TextureFilterOptions.TFO_BILINEAR);
                    //mDebugOverlay.AdditionalInfo = "BiLinear";
                    break;

                case 1:
                    MaterialManager.Singleton.SetDefaultTextureFiltering(TextureFilterOptions.TFO_TRILINEAR);
                    //mDebugOverlay.AdditionalInfo = "TriLinear";
                    break;

                case 2:
                    MaterialManager.Singleton.SetDefaultTextureFiltering(TextureFilterOptions.TFO_ANISOTROPIC);
                    MaterialManager.Singleton.DefaultAnisotropy = 8;
                    //mDebugOverlay.AdditionalInfo = "Anisotropic";
                    break;

                case 3:
                    MaterialManager.Singleton.SetDefaultTextureFiltering(TextureFilterOptions.TFO_NONE);
                    MaterialManager.Singleton.DefaultAnisotropy = 1;
                    //mDebugOverlay.AdditionalInfo = "None";
                    break;
            }
        }

        protected void CyclePolygonMode()
        {
            mRenderMode = (mRenderMode + 1) % 3;
            switch (mRenderMode)
            {
                case 0:
                    _Camera.PolygonMode = PolygonMode.PM_SOLID;
                    break;

                case 1:
                    _Camera.PolygonMode = PolygonMode.PM_WIREFRAME;
                    break;

                case 2:
                    _Camera.PolygonMode = PolygonMode.PM_POINTS;
                    break;
            }
        }

        protected void TakeScreenshot()
        {
            _Window.WriteContentsToTimestampedFile("screenshot", ".png");
        }

        protected void Shutdown()
        {
            //throw new ShutdownException();
        }

        public void Dispose()
        {
            if (_Root != null)
                _Root.Dispose();
            _Root = null;
        }
        #endregion

        public void Load(string fileName)
        {
            CreateScene(fileName);
            _Locked = false;

            InitializeInput();
        }

        public void LoadTest()
        {
            CreateSceneTest();
            _Locked = false;

            InitializeInput();
        }

        private void readLayoutTest()
        {
            SceneNode plantNode = _Mgr.RootSceneNode.CreateChildSceneNode("Plant");
            _Plant = new Plant(plantNode, "Plant");
            ////////////////////////////////////////////
            string cnvName = "CNV_001";

            Entity tmEntity = _Mgr.CreateEntity(SceneManager.PrefabType.PT_CUBE);
            tmEntity.SetMaterialName("Examples/TransparentGreen");
            
            SceneNode cnvBackNode = _Plant.SceneNode.CreateChildSceneNode(cnvName+"_Back");
            //default, width, height = 100, 100...
            cnvBackNode.AttachObject(tmEntity);
            cnvBackNode.ShowBoundingBox = true;
            cnvBackNode.Scale(11, 0.1f, 1);
            cnvBackNode.Translate(
                (float)0,
                1.0f,
                (float)0);
            
            SceneNode cnvNode = _Plant.SceneNode.CreateChildSceneNode(cnvName);
            cnvNode.ShowBoundingBox = true;
            cnvNode.Translate(
                -500.0f,
                1.0f,
                (float)0);

            Conveyor cnv = new Conveyor(cnvNode, cnvName);

            Mogre.Vector3 cnvSP = new Mogre.Vector3(0,-50,0);
            //Mogre.Vector3 cnvSP = new Mogre.Vector3(-500, -50, 0);
            Mogre.Vector3 cnvEP = new Mogre.Vector3(1000,-50,0);

            LinePath cnvPath = new LinePath();
            cnvPath.StartPosition = cnvSP;
            cnvPath.EndPosition = cnvEP;
            cnvPath.Initialize();
            cnv.AddPath(cnvPath);

            //cnv.InPort = ProcessSystem.Instance.GetShelf("outport_" + cnv.Name);
            //cnv.OutPort = ProcessSystem.Instance.GetShelf("inport_" + cnv.Name);
            _Plant.AddChild(cnv);
            _CNV = cnv;

            //Conveyor 2
            string cnvName2 = "CNV_002";
            Entity tmEntity2 = _Mgr.CreateEntity(SceneManager.PrefabType.PT_CUBE);
            tmEntity2.SetMaterialName("Examples/TransparentYellow");

            SceneNode cnvBackNode2 = _Plant.SceneNode.CreateChildSceneNode(cnvName2 + "_Back");
            cnvBackNode2.AttachObject(tmEntity2);
            cnvBackNode2.ShowBoundingBox = true;
            cnvBackNode2.Scale(5, 0.1f, 1);
            cnvBackNode2.Translate(
                (float)800,
                1.0f,
                (float)0); //중심은 x=800 으로 움직인다. 단, 원래 가로세로높이가 100x100x100 이므로, x축으로 5배하여 500x1x100 이므로, 
                           //시작점은 x=800 - 250 = 550 임

            SceneNode cnvNode2 = _Plant.SceneNode.CreateChildSceneNode(cnvName2);
            cnvNode2.ShowBoundingBox = true;
            cnvNode2.Translate(500,1.0f,(float)0);

            Conveyor cnv2 = new Conveyor(cnvNode2, cnvName2);

            Mogre.Vector3 cnvSP2 = new Mogre.Vector3(0, -50, 0);//크기가 50이므로, 중심위치로 하는 것이 좋음
            Mogre.Vector3 cnvEP2 = new Mogre.Vector3(500, -50, 0);

            LinePath cnvPath2 = new LinePath();
            cnvPath2.StartPosition = cnvSP2;
            cnvPath2.EndPosition = cnvEP2;
            cnvPath2.Initialize();
            cnv2.AddPath(cnvPath2);
            _Plant.AddChild(cnv2);
            _CNV2 = cnv2;

            ////////////////////////////////////////////
            _Plant.SceneNode.Scale(1, 1, 1);
        }

        private Conveyor _CNV;
        private Conveyor _CNV2;

        private int LoadNo = 1;
        public void AddALoad()
        {

            ProcessSystem set = ProcessSystem.Instance;

            string name = LoadNo.ToString();
            Load g = set.AddNewCassette(LoadNo);

            Entity loadEntity = (Entity)g.SceneNode.DetachObject(g.Name);
            if (loadEntity != null)
            {
                //_CNV.InPort.SceneNode.AttachObject(loadEntity);
                //g.SceneNode = _CNV.InPort.SceneNode;
                //_CNV.InPort.AddChild(g);

                //_CNV.SceneNode.AttachObject(loadEntity);
                //g.SceneNode = _CNV.SceneNode;
                //_CNV.AddChild(g);

                SceneNode loadNode = _CNV.SceneNode.CreateChildSceneNode(_CNV.Name + "_" + g.Name);
                loadNode.AttachObject(loadEntity);
                //loadNode.Scale(new Mogre.Vector3(0.01f, 0.01f, 0.01f));
                loadNode.ShowBoundingBox = true;
                loadNode.Translate(0, -50, 0);
                g.SceneNode = loadNode;
                
                _CNV.AddChild(g);
            }

            LoadNo++;
        }

        public void RemoveJob()
        {
            Entity loadEntity = _CNV.RemoveFirstJob();

            ProcessSystem set = ProcessSystem.Instance;
            int no = int.Parse(loadEntity.Name.Substring(loadEntity.Name.IndexOf('_') + 1));
            Load g = (Load)set.FindLoad(no);
            SceneNode loadNode = _CNV2.SceneNode.CreateChildSceneNode(_CNV2.Name + "_" + g.Name);
            loadNode.AttachObject(loadEntity);
            //loadNode.Scale(new Mogre.Vector3(0.01f, 0.01f, 0.01f));
            loadNode.ShowBoundingBox = true;
            loadNode.Translate(0, -50, 0);
            g.SceneNode = loadNode;
            g.Accumulated = false;
            _CNV2.AddChild(g);
        }

        /*
        private void readInlineStockers()
        {
            //Stocker
            int qi = 0;
            int sn = _Reader.getPathMoverSystemSize();
            for (int i = 0; i < sn; i++)
            {
                ExcelLayout.PathMoverSystem pms = _Reader.getPathMoverSystem(i);
                string stkName = pms.getName();
                SceneNode stkNode = _Plant.SceneNode.CreateChildSceneNode(stkName);
                stkNode.ShowBoundingBox = true;

                System.Diagnostics.Debug.WriteLine("[" + stkName + "] adding an inline stocker");
                System.Diagnostics.Debug.WriteLine("- SP = (" + pms.getSP()[0] + "," + pms.getSP()[1] + ")");
                System.Diagnostics.Debug.WriteLine("- EP = (" + pms.getEP()[0] + "," + pms.getEP()[1] + ")");
                double[] stkSP = pms.getSP();
                Mogre.Vector3 stkPos = new Mogre.Vector3((float)stkSP[0], 0, (float)stkSP[1]);
                //Mogre.Vector3 stkPos = new Mogre.Vector3((float)stkSP[0], 0.5f, (float)stkSP[1]);
                stkNode.Translate(stkPos);
                InlineStocker stk = new InlineStocker(stkNode, stkName);
                _Plant.AddChild(stk);

                //Crane
                System.Diagnostics.Debug.WriteLine("[" + stkName + "] adding a crane");
                string craneName = "Crane" + "_" + stkName;
                System.Diagnostics.Debug.WriteLine(" - " + craneName);
                Entity craneEntity = _Mgr.CreateEntity(SceneManager.PrefabType.PT_CUBE);
                craneEntity.SetMaterialName("Examples/TransparentYellow");
                SceneNode craneNode = stkNode.CreateChildSceneNode(
                    craneName, 
                    new Mogre.Vector3(0.5f, -0.5f, 0));
                craneNode.AttachObject(craneEntity);
                craneNode.Scale(new Mogre.Vector3(0.01f, 0.01f, 0.01f));
                Crane crane = new Crane(craneNode, craneName);
                crane.SetCurrentPosition(new ControlPoint(0.5f, -0.5f, 0, craneName + "_cp"));
                stk.Crane = crane;
                System.Diagnostics.Debug.WriteLine(" - Position: " + craneNode.Position.x + "," + craneNode.Position.y + "," + craneNode.Position.y + ")");

                //Shelf
                Dictionary<string, int> numCount = new Dictionary<string, int>();

                foreach (ExcelLayout.Queue queue in pms.Queues)
                {
                    float x = (float)queue.getPositionX() - (float)stkSP[0];
                    float z = (float)queue.getPositionY() - (float)stkSP[1];
                    float y = (float)queue.getPositionZ() + 0.5f;
                    y = -y;
                    string shelfName = queue.getName();//stkName + "_" + "Shelf_" + 
                    
                    //설비 port 의 경우 TM1 으로 모두 동일함...-.-
                    if (numCount.ContainsKey(shelfName))
                    {
                        numCount[shelfName]++;
                        shelfName += "_" + numCount[shelfName];
                    }
                    else
                    {
                        
                        numCount.Add(shelfName, 1);
                        if (shelfName.StartsWith("T"))
                            shelfName += "_" + 1;
                    }
                                        
                    float cx = (float)queue.getPositionCX() - (float)stkSP[0];
                    float cz = (float)queue.getPositionCY() - (float)stkSP[1];
                    float cy = -(float)queue.getPositionCZ() - 0.5f;

                    System.Diagnostics.Debug.WriteLine("[" + shelfName + "] adding a shelf");
                    System.Diagnostics.Debug.WriteLine("- Position: " + x + "," + y + "," + z);
                    System.Diagnostics.Debug.WriteLine("- Control Position: " + cx + "," + cy + "," + cz);

                    ControlPoint shelfCP =
                        new ControlPoint(
                            cx, 
                            cy, 
                            cz, queue.getCPName());//shelfName);
                    stk.AddControlPoint(shelfCP);

                    string shelfType = queue.getType();

                    Entity shelfEntity = _Mgr.CreateEntity(SceneManager.PrefabType.PT_CUBE);
                    if (shelfType[0] == 'T')
                        shelfEntity.SetMaterialName("Examples/TransparentRed");
                    else if (shelfType == "inport")
                        shelfEntity.SetMaterialName("Examples/TransparentBlue");
                    else if (shelfType == "outport")
                        shelfEntity.SetMaterialName("Examples/TransparentBlue");
                    else
                        shelfEntity.SetMaterialName("Examples/TransparentTest");

                    System.Diagnostics.Debug.WriteLine(shelfName);
                    SceneNode shelfNode = stkNode.CreateChildSceneNode(shelfName);
                    shelfNode.AttachObject(shelfEntity);
                    shelfNode.Scale(new Mogre.Vector3(0.01f, 0.01f, 0.01f));
                    shelfNode.Translate(x, y, z);
                    //shelfNode.Translate(x, z, y);
                    //0 + i * 50, 25.0f, 45.0f);

                    System.Diagnostics.Debug.WriteLine(" - Position: " + x + "," + y + "," + y);

                    Shelf shelf = new Shelf(shelfNode, shelfName);
                    shelf.Stocker = stkName;

                    if (shelfType[0] == 'T')
                    {
                        //설비 Port
                        shelf.Type = ShelfType.TM;
                        shelf.Capacity = 1;  //just for now, it will be replaced with 1
                    }
                    else if (shelfType == "inport")
                    {
                        //Stocker Inport
                        shelf.Type = ShelfType.InPort;
                        shelf.Capacity = 1;
                    }
                    else if (shelfType == "outport")
                    {
                        //Stocker Outport
                        shelf.Type = ShelfType.OutPort;
                        shelf.Capacity = 1;
                    }
                    else
                    {
                        shelf.Type = ShelfType.Buffer;
                        shelf.Capacity = 10;
                    }

                    shelf.Stocker = stkName;
                    shelf.ControlPoint = shelfCP;
                    stk.AddChild(shelf);
                    ProcessSystem.Instance.AddShelf(shelf);
                }
            }
        }

        private void readResources()
        {
            int rn = _Reader.getResourceSize();
            for (int i = 0; i < rn; i++)
            {
                ExcelLayout.Resource res = _Reader.getResource(i);
                string resName = res.getName();//_Reader.getResourceName(i);

                System.Diagnostics.Debug.WriteLine("[" + resName + "] adding a resource.");
                System.Diagnostics.Debug.WriteLine("- SP: " + res.getSP()[0] + ", " + res.getSP()[1]);
                System.Diagnostics.Debug.WriteLine("- EP: " + res.getEP()[0] + ", " + res.getEP()[1]);
                Entity tmEntity = _Mgr.CreateEntity(SceneManager.PrefabType.PT_CUBE);
                tmEntity.SetMaterialName("Examples/TransparentGreen");
                SceneNode tmNode = _Plant.SceneNode.CreateChildSceneNode(resName);
                tmNode.AttachObject(tmEntity);

                float xLength = (float)_Reader.getResourceLength(i, 0);
                float yLength = (float)_Reader.getResourceLength(i, 1);
                tmNode.Scale(
                    new Mogre.Vector3(
                        yLength * 0.01f,
                        0.01f,
                        xLength * 0.01f*2));

                System.Diagnostics.Debug.WriteLine(" - Size (x,y):" + _Reader.getResourceLength(i, 0) + "," + _Reader.getResourceLength(i, 1));
                tmNode.Translate(
                    (float)_Reader.getResourcePosition(i, 0) - 0.5f,
                    -0.5f,
                    (float)_Reader.getResourcePosition(i, 1)
                    );
                
                System.Diagnostics.Debug.WriteLine(" - Position:" + _Reader.getResourcePosition(i, 0) + "," + _Reader.getResourcePosition(i, 1));
                
                Equipment tm = new Equipment(tmNode, resName);
                _Plant.AddChild(tm);
            }
        }

        private void readConveyors()
        {
            int cn = _Reader.getConveyorSize();
            for (int i = 0; i < cn; i++)
            {
                string cnvName = _Reader.getConveyorName(i);
                SceneNode cnvNode = _Plant.SceneNode.CreateChildSceneNode(cnvName);
                cnvNode.ShowBoundingBox = true;
                cnvNode.Translate(
                    (float)_Reader.getConveyorPointX(i, 0),
                    0.0f,
                    //0.5f, 
                    (float)_Reader.getConveyorPointY(i, 0));

                Conveyor cnv = new Conveyor(cnvNode, cnvName);
                int pn = _Reader.getConveyorPathSize(i);

                Mogre.Vector3 cnvSP = new Mogre.Vector3(
                    (float)_Reader.getConveyorPointX(i, 0),
                    0.0f,
                    //0.5f, 
                    (float)_Reader.getConveyorPointY(i, 0));

                Mogre.Vector3 cnvEP = new Mogre.Vector3(
                    (float)_Reader.getConveyorPointX(i, pn-1),
                    0.0f,
                    //0.5f, 
                    (float)_Reader.getConveyorPointY(i, pn-1));

                for (int j = 0; j < pn - 1; j++)
                {
                    LinePath cnvPath = new LinePath();
                    cnvPath.StartPosition = 
                        new Mogre.Vector3(
                            (float)_Reader.getConveyorPointX(i, j) - cnvSP.x,
                            0.0f,
                            //0.5f,
                            (float)_Reader.getConveyorPointY(i, j)- cnvSP.z);
                    cnvPath.EndPosition=
                        new Mogre.Vector3(
                            (float)_Reader.getConveyorPointX(i, j + 1) - cnvSP.x,
                            0.0f,
                            //0.5f,
                            (float)_Reader.getConveyorPointY(i, j + 1) - cnvSP.z);
                    cnvPath.Initialize();
                    cnv.AddPath(cnvPath);
                }

                cnv.InPort = ProcessSystem.Instance.GetShelf("outport_" + cnv.Name);
                cnv.OutPort = ProcessSystem.Instance.GetShelf("inport_" + cnv.Name);
                _Plant.AddChild(cnv);
            }
        }
        

        private void readLayout(string fileName)
        {
            _Reader = new ExcelLayout.CellDataReader();
            _Reader.set(fileName);
            _Reader.parse();

            SceneNode plantNode = _Mgr.RootSceneNode.CreateChildSceneNode("Plant");
            _Plant = new Plant(plantNode, "Plant");

            //Inline stockers
            readInlineStockers();

            //resource
            readResources();
            
            //Conveyor
            readConveyors();

            _Plant.SceneNode.Scale(20, 20, 20);
        }
        */
    }
}
