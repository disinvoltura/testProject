﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mogre;

namespace VMS.VirtualPlant
{
    public class Conveyor : Model
    {
        #region Member Variables
        private float _Velocity;
        private Shelf _OutPort;
        private Shelf _Inport;

        //추후 다수개의 job 이 convey 되기 위해서 List 로 변경할 필요가 있음
        private ApplicationMessage _Msg;
        private List<Path> _Paths;

        #endregion

        #region Properties
        public float Velocity
        {
            get { return _Velocity; }
            set { _Velocity = value; }
        }

        public Shelf OutPort
        {
            get { return _OutPort; }
            set
            {
                _OutPort = value;
                //string name = value.Name;
                //name += this.Name;
                //_OutPort.set.Name = name;
            }
        }

        public Shelf InPort
        {
            get { return _Inport; }
            set
            {
                _Inport = value;
            }
        }

        public ApplicationMessage Message
        {
            set { _Msg = value; }
        }
        #endregion

        #region Constructors
        public Conveyor(SceneNode node, string name)
            : base(node, name)
        {
            Initialize();
        }
        
        #endregion

        #region Methods
        public void AddPath(Path p)
        {
            _Paths.Add(p);
        }
        #endregion

        #region Abstract Methods
        public override bool Initialize()
        {
            _Velocity = 5.0f; ;
            _OutPort = null;
            _Inport = null;
            _Paths = new List<Path>();
            return true;
        }

        public override bool ProcessEvent(VIPEvent e)
        {
            _Msg = e.Message;
            Load g = ProcessSystem.Instance.FindLoad(_Msg.CassetteID);

            _Inport.Remove();
            _Inport.RemoveChild(g);
            Entity loadEntity = (Entity)_Inport.SceneNode.DetachObject(g.Name);
            if (loadEntity != null)
            {
                SceneNode loadNode = this.SceneNode.CreateChildSceneNode(this.Name +"_"+g.Name);
                loadNode.AttachObject(loadEntity);
                loadNode.Scale(new Mogre.Vector3(0.01f, 0.01f, 0.01f));
                loadNode.ShowBoundingBox = true;
                g.SceneNode = loadNode;
            }
            
            this.AddChild(g);

            return true;
        }

        public override void UpdatePosition(float dt)
        {
            for(int i = 0 ; i < this.ChildrenCount; i++)
            {
                Model child = this.GetChild(i);

                Load g = (Load)child;
                if (!g.Accumulated)
                    UpdatePosition(child, i, dt);
            }
        }

        private int NoAccumulated;

        public Entity RemoveFirstJob()
        {
            Entity rslt = null;
            if (this.ChildrenCount > 0)
            {
                Load g = (Load )this.GetChild(0);
                this.RemoveChild(g);

                Entity loadEntity = (Entity)g.SceneNode.DetachObject(g.Name);
                this.SceneNode.RemoveAndDestroyChild(this.Name + "_" + g.Name);

                NoAccumulated--;

                for (int i = 0; i < this.ChildrenCount; i++)
                {
                    Load rg = (Load)this.GetChild(i);
                    rg.Accumulated = false;
                }

                rslt = loadEntity;
            }

            return rslt;
        }

        public override void UpdatePosition(Model child, float dt)
        {
        }

        public void UpdatePosition(Model child, int idx, float dt)
        {
            if (child == null) return;

            Vector3 newPos = child.SceneNode.Position;
            int pn = _Paths.Count;
            for (int i = 0; i < pn; i++)
            {
                if (!_Paths[i].Include(newPos))
                    continue;

                Vector3 move = _Paths[i].CalcNextPosition(newPos, _Velocity * MainForm.App.TimeScale * dt);
                child.SceneNode.Translate(move, Node.TransformSpace.TS_PARENT);
                newPos = newPos + move;
                double distance = Distance(_Paths[i].EndPosition, newPos);
                double gap = 0.1f;
                gap += idx * 100;
                //System.Diagnostics.Debug.WriteLine("[Conveyor] Distance = " + distance);
                if ( distance <= gap)
                {
                    if (i == pn - 1)
                    {
                        Load g = (Load)child;
                        if (!g.Accumulated)
                        {
                            g.Accumulated = true;
                            NoAccumulated++;
                        }

                        /*
                         
                        PostEvent(this, _Msg, null, _Msg.EventTime, false);
                        
                        Load g = (Load)child;
                        this.RemoveChild(g);
                        
                        Entity loadEntity = (Entity)g.SceneNode.DetachObject(g.Name);
                        this.SceneNode.RemoveAndDestroyChild(this.Name + "_" + g.Name);
                        if (loadEntity != null)
                        {
                            _OutPort.SceneNode.AttachObject(loadEntity);
                            g.SceneNode = _OutPort.SceneNode;
                        }
                        _OutPort.AddChild(g);
                         */
                    }
                    else
                    {
                        child.SceneNode.Position = new Vector3(_Paths[i].EndPosition.x, _Paths[i].EndPosition.y, _Paths[i].EndPosition.z);
                    }
                }
            }
        }
        #endregion
    }
}
