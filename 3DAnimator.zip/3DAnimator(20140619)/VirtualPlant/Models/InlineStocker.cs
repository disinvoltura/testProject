﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mogre;

namespace VMS.VirtualPlant
{
    public enum InlineStockerType { Lower, Upper };

    public class InlineStocker: Model
    {
        #region Member Variables
        private List<ControlPoint> _ControlPoints;
        private Crane _Crane;
        private int _Type;
        #endregion

        #region Properties
        public Crane Crane
        {
            set { _Crane = value; }
        }
        public int Type
        {
            set { _Type = value; }
        }
        #endregion

        #region Constructors
        public InlineStocker(SceneNode node, string name)
            : base(node, name)
        {
            Initialize();
        }
        #endregion

        #region Methods
        public void AddControlPoint(ControlPoint p)
        {
            _ControlPoints.Add(p);
        }

        public ControlPoint GetPoint(string name)
        {
            int cn = _ControlPoints.Count;
            for (int i = 0; i < cn; i++)
            {
                if (_ControlPoints[i].Name == name)
                    return _ControlPoints[i];
            }

            return _ControlPoints[0]; //Default Position
        }

        public ControlPoint GetPoint(Shelf shelf)
        {
            //if (shelf.ControlPoint != null)
                return shelf.ControlPoint;
          
        }

        //public void Build()
        //{
        //}
        #endregion

        #region Abstract Methods
        public override bool Initialize()
        {
            _Crane = null;
            _Type = 0;
            _ControlPoints = new List<ControlPoint>();
            return true;
        }

        public override bool ProcessEvent(VIPEvent e)
        {
            System.Diagnostics.Debug.WriteLine("[" + this.Name + "] ProcessEvent : " + e.Message.Type.ToString() + "_" + e.Message.Action);
            ApplicationMessage msg = e.Message;
            
            if (msg.Action[0] == 'R') //Delay_Retrieval
            {
                Load g = ProcessSystem.Instance.FindLoad(msg.CassetteID);
                if (g== null && msg.Source == "empty")
                    g = ProcessSystem.Instance.AddEmptyCassette(msg.CassetteID, null);

                System.Diagnostics.Debug.WriteLine("- Load = " + g.Name + "("+ g.ID+")");
                
                Shelf source = (Shelf)ProcessSystem.Instance.GetSource(msg.Source, this.Name, g);
                System.Diagnostics.Debug.WriteLine("- Source.Name = " + source.Name + "(" + source.ControlPoint + ")");
                System.Diagnostics.Debug.WriteLine("- Source.ControlPoint = " + source.ControlPoint.ToString());
                System.Diagnostics.Debug.WriteLine("- Source.Position= " + source.SceneNode.Position.ToString());

                if (msg.Source == "empty")
                {
                    source.AddChild(g);
                    Entity loadEntity = (Entity) g.SceneNode.DetachObject(0);
                    source.SceneNode.AttachObject(loadEntity);
                    g.SceneNode = source.SceneNode;
                    //source.AddChild(g.SceneNode);
                }

		        Shelf dest = (Shelf)ProcessSystem.Instance.GetShelf(msg.Destination, this.Name);
                if (dest == null){
                    _Crane.Target = null; return false;
                }

                System.Diagnostics.Debug.WriteLine("- Destination.Name = " + dest.Name + "(" + dest.ControlPoint + ")");
                System.Diagnostics.Debug.WriteLine("- Destination.ControlPoint = " + dest.ControlPoint.ToString());
                System.Diagnostics.Debug.WriteLine("- Destination.Position= " + dest.SceneNode.Position.ToString());

                if (msg.Destination != "empty")
                    dest.Add(); //destination 예약

		        //Crane setting
                _Crane.Message = msg;
                _Crane.SetTargetPosition(GetPoint(source));
                _Crane.Target = dest;

            }else if (msg.Action[0] == 'D') //Delay_Delivery
            {
                if(_Crane.Target == null) return false;

                Load g = ProcessSystem.Instance.FindLoad(msg.CassetteID);
                System.Diagnostics.Debug.WriteLine("- Load = " + g.Name + "("+ g.ID+")");

                Shelf source = (Shelf)ProcessSystem.Instance.GetSource(msg.Source, this.Name, g);
                source.Remove();

                System.Diagnostics.Debug.WriteLine("- Source.Name = " + source.Name + "(" + source.ControlPoint + ")");
                System.Diagnostics.Debug.WriteLine("- Source.ControlPoint = " + source.ControlPoint.ToString());
                System.Diagnostics.Debug.WriteLine("- Source.Position= " + source.SceneNode.Position.ToString());

                source.RemoveChild(g);
                Entity loadEntity = null;
                try
                {
                    loadEntity = (Entity)source.SceneNode.DetachObject(g.Name);//"Cassette_" + g.ID);
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(ex.ToString());
                    System.Diagnostics.Debug.WriteLine("This shelf <" + source.Name + "> does not have a cassette <" + g.Name+">");
                }

                if (loadEntity != null)
                {
                    _Crane.SceneNode.AttachObject(loadEntity);
                    g.SceneNode = _Crane.SceneNode;
                }

                _Crane.AddChild(g);

                _Crane.IsEmpty = false;
                _Crane.SetTargetPosition(GetPoint(
                    (Shelf)_Crane.Target));
		        _Crane.Message = msg;
            }
            return true;
        }

        public override void UpdatePosition(float dt)
        {
            _Crane.UpdatePosition(dt);
        }

        public override void UpdatePosition(Model child, float dt)
        {
            _Crane.UpdatePosition(child, dt);
        }
        #endregion
    }
}
