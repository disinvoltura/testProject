﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mogre;

namespace VMS.VirtualPlant
{
    public class Crane : Model
    {
        #region Member Variables
        private float _Velocity;
        private Vector3 _Dir; //moving direction
        private ControlPoint _CurPos;
        private ControlPoint _TargetPos;
        private Model _Dest;
        private ApplicationMessage _msg;
        private bool _Moving;
        private bool _Empty;
        private int _Deliver;
        #endregion

        #region Properties
        public float Velocity
        {
            get { return _Velocity; }
            set { _Velocity = value; }
        }
        public Vector3 CurrentPosition 
        { 
            get { return _CurPos.Position; }
        }

        public Vector3 TargetPosition 
        { 
            get { return _TargetPos.Position; }
        }
        public Model Target { 
            get { return _Dest; }
            set { _Dest = value; }
        }
        public ApplicationMessage Message
        {
            set { _msg = value; }
        }
        public bool IsEmpty
        {
            get { return _Empty; }
            set { _Empty = value; }
        }
        #endregion

        #region Constructors
        public Crane(SceneNode node, string name)
            : base(node, name)
        {
            Initialize();
        }
        #endregion

        #region Methods
        public void SetCurrentPosition(ControlPoint p)
        {
            _CurPos = new ControlPoint(p.Position.x, p.Position.y, p.Position.z, p.Name);// p;
        }

        public void SetTargetPosition(ControlPoint p)
        {
            _TargetPos = new ControlPoint(p.Position.x, p.Position.y, p.Position.z, p.Name);
            _Dir = _TargetPos.Position - _CurPos.Position;
            _Dir.Normalise();
            _Moving = true;
        }
        #endregion

        #region Abstract Methods
        public override bool Initialize()
        {
            _Velocity = 0.5f;
            //_Velocity = 20.0f;
            _Dest = null;
            _Moving = false;
            _Empty = true;
            _Deliver = 0;
            return true;
        }

        public override bool ProcessEvent(VIPEvent e)
        {
            return false;
        }

        public override void UpdatePosition(float dt)
        {
            if (!_Moving || _Dest == null) return;
            if (!_Empty && this.ChildrenCount == 0) return;

            //System.Diagnostics.Debug.WriteLine("[" + this.Name + "] UpdatePosition...");

            //목표지점에 도달하는 경우
            double distance = Distance(_TargetPos.Position, _CurPos.Position);
            //System.Diagnostics.Debug.WriteLine("[" + this.Name + "] Distance = " + distance); 

            if (distance < 0.001f
                || (_TargetPos.Position - _CurPos.Position).DotProduct(_Dir) < 0.001f)
            {
                //옮기는 데에 걸리는 시간을 임의로 지정
                /**/
                if (_Deliver < 10) { _Deliver++; return; }

                if (_msg.Action[0] == 'R'
                    || _msg.Action[0] == 'D' && this.ChildrenCount > 0)
                {
                    //목표지점에 도달해서 운반까지 완료하면 event 생성 날림
                    //double time = VIPTimer.GetTime();
                    //_msg.EventTime = time;
                    PostEvent(this, _msg, null, _msg.EventTime, false);
                    _CurPos = _TargetPos;
                    //this.SceneNode.Position = _CurPos.Position;
                    _Moving = false;
                    _Deliver = 0;
                }

                if (this.ChildrenCount > 0)
                {
                    //Empty cassette 처리 (2014-03-13)
                    Load g = (Load)this.GetChild(0);
                    if (g.State == LoadState.Empty
                        && _msg.Source != "empty")
                    {
                        g.State = LoadState.Removed;
                        //loadEntity.Visible = false;
                        //ProcessSystem.Instance.RemoveLoad(g.ID);
                        //ProcessSystem.Instance.RemoveAndDestoryLoad(g.ID, loadEntity);
                    }

                    //crane --> shelf 로 이동

                    Entity loadEntity = (Entity)this.SceneNode.DetachObject(g.Name);
                    if (loadEntity != null)
                    {
                        _Dest.SceneNode.AttachObject(loadEntity);
                        g.SceneNode = _Dest.SceneNode;
                        _Dest.AddChild(g);
                    }
                    this.RemoveChild(g);

                    _Dest = null;
                    _Empty = true;
                }
            }
            else
            {
                float movingLength = 0.0f;
                if (!_Empty)
                {
                    movingLength = (_Velocity * (float)MainForm.App.TimeScale * dt);
                }
                else
                {
                    movingLength = (_Velocity * (float)MainForm.App.TimeScale * dt);
                }

                Mogre.Vector3 move = _Dir * movingLength;
                _CurPos.Position = _CurPos.Position + move;
                this.SceneNode.Translate(move, Node.TransformSpace.TS_PARENT);//, Node.TransformSpace.TS_WORLD);
            }
        }

        public override void UpdatePosition(Model child, float dt)
        {
            if (!_Moving || _Dest == null) return;
            if (!_Empty && this.ChildrenCount == 0) return;

            //System.Diagnostics.Debug.WriteLine("[" + this.Name + "] UpdatePosition...");

            //목표지점에 도달하는 경우
            double distance = Distance(_TargetPos.Position, _CurPos.Position);
            //System.Diagnostics.Debug.WriteLine("[" + this.Name + "] Distance = " + distance); 

            if (distance < 0.001f
                || (_TargetPos.Position - _CurPos.Position).DotProduct(_Dir) < 0.001f)
            {
                //옮기는 데에 걸리는 시간을 임의로 지정
                /**/
                if (_Deliver < 10) { _Deliver++; return; }

                if (_msg.Action[0] == 'R'
                    || _msg.Action[0] == 'D' && this.ChildrenCount > 0)
                {
                    //목표지점에 도달해서 운반까지 완료하면 event 생성 날림
                    //double time = VIPTimer.GetTime();
                    //_msg.EventTime = time;
                    PostEvent(this, _msg, null, _msg.EventTime, false);
                    _CurPos = _TargetPos;
                    //this.SceneNode.Position = _CurPos.Position;
                    _Moving = false;
                    _Deliver = 0;
                }

                if (this.ChildrenCount > 0)
                {
                    //Empty cassette 처리 (2014-03-13)
                    Load g = (Load)this.GetChild(0);
                    if (g.State == LoadState.Empty
                        && _msg.Source != "empty")
                    {
                        g.State = LoadState.Removed;
                        //loadEntity.Visible = false;
                        //ProcessSystem.Instance.RemoveLoad(g.ID);
                        //ProcessSystem.Instance.RemoveAndDestoryLoad(g.ID, loadEntity);
                    }

                    //crane --> shelf 로 이동

                    Entity loadEntity = (Entity)this.SceneNode.DetachObject(g.Name);
                    if (loadEntity != null)
                    {
                        _Dest.SceneNode.AttachObject(loadEntity);
                        g.SceneNode = _Dest.SceneNode;
                        _Dest.AddChild(g);
                    }
                    this.RemoveChild(g);

                    _Dest = null;
                    _Empty = true;
                }
            }
            else
            {
                float movingLength = 0.0f;
                if (!_Empty)
                {
                    movingLength = (_Velocity * (float)MainForm.App.TimeScale * dt);
                }
                else
                {
                    movingLength = (_Velocity * (float)MainForm.App.TimeScale * dt);
                }

                Mogre.Vector3 move = _Dir * movingLength;
                _CurPos.Position = _CurPos.Position + move;
                this.SceneNode.Translate(move, Node.TransformSpace.TS_PARENT);//, Node.TransformSpace.TS_WORLD);
            }
        }
        #endregion
    }
}
