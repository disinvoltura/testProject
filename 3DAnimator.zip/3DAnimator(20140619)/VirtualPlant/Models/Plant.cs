﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mogre;

namespace VMS.VirtualPlant
{
    public class Plant : Model
    {
        public Plant(SceneNode node, string name)
            : base(node, name)
        {

        }

        public void DispatchEvent(VIPEvent e)
        {
            ApplicationMessage msg = e.Message;

            Model child = GetChild(msg.ObjectID);
            child.ProcessEvent(new VIPEvent(this, msg, child, e.Time, e.SimType));
            //PostEvent(this, msg, (Model)GetChild(msg.ObjectID), e.Time, e.SimType);

        }
        public override bool Initialize()
        {
            return true;
        }

        public override bool ProcessEvent(VIPEvent e)
        {
            ApplicationMessage msg = e.Message;

	        ProcessSystem set = ProcessSystem.Instance;

            if (msg.Type == ApplicationMessageType.Delay 
                && msg.Action[0] == 'R')
            {
                Model child = (Model) GetChild(msg.ObjectID);
                if (child == null) return false;

                Load g = set.FindLoad(msg.CassetteID);
                if (g == null){ //glass 가 새로 생성되어야 하는 경우
                    if (msg.Source == "empty")
                        g = set.AddEmptyCassette(msg.CassetteID, g);
                    else
                        g = set.AddNewCassette(msg.CassetteID);
                    
                    if (msg.Source == "empty") //Empty cassette 처리 
                        g.State = LoadState.Empty;
                    else
                    {
                        Shelf inPort = (Shelf)set.GetShelf("inport_CNV00", "S01");
                        inPort.AddChild(g);
                        Entity loadEntity = (Entity)g.SceneNode.DetachObject(0);
                        inPort.SceneNode.AttachObject(loadEntity);                       
                    }
                }
            }

	        DispatchEvent(e);
	        return true;
        }

        public override void UpdatePosition(float dt)
        {
            foreach (Model child in _Children)
            {
                if (child is Conveyor)
                    child.UpdatePosition(dt);
                else
                    child.UpdatePosition(null, dt);
                
            }
        }

        public override void UpdatePosition(Model child, float dt)
        {
            //do nothing
        }
    }
}
