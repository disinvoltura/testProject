﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mogre;

namespace VMS.VirtualPlant
{
    public class ProcessSystem
    {
        #region Member Variables
        private SceneManager _Mgr;
        private Dictionary<int, Load> _Loads;
        private List<Shelf> _Shelves;
        private List<Equipment> _Equipments;//resources
        private int _TotalSize;
        #endregion

        public static ProcessSystem Instance;

        #region Properties
        public int TotalSize
        {
            get { return _TotalSize; }
        }

        public int ProcesingSize
        {
            get { return _Loads.Count; }
        }

        //GetQueueSize()
        public int ShelfCount { get { return _Shelves.Count; } }
        //GetResourceSize()
        public int EquipmentCount { get { return _Equipments.Count; } }
        #endregion

        #region Constructors
        public ProcessSystem(SceneManager mgr)
        {
            ProcessSystem.Instance = this;

            _Loads = new Dictionary<int, Load>();
            _Shelves = new List<Shelf>();
            _Equipments = new List<Equipment>();

            _Mgr = mgr;
        }
        #endregion

        #region Methods
        public void Clear()
        {
            _Loads.Clear();
            _Shelves.Clear();
            _Equipments.Clear();
        }

        public Model GetSource(string name, string objectid, Load g)
        {
            int qn = _Shelves.Count;
            if (name == "empty") //handle empty cassette
            {
                for (int i = 0; i < qn; i++)
                {
                    if (_Shelves[i].Stocker == objectid
                        && _Shelves[i].Type == ShelfType.Buffer)
                    {
                        return _Shelves[i];
                    }
                }
            }

            char ch = name[0];
            if (ch == 'i' || ch == 'I') //inport
            {
                for (int i = 0; i < qn; i++)
                {
                    if (_Shelves[i].Stocker == objectid
                        && _Shelves[i].Type == ShelfType.InPort
                        && name == _Shelves[i].Name)
                        return _Shelves[i];
                }

                return null;
            }
            else if (ch == 'o' || ch == 'O') //outport
            {
                for (int i = 0; i < qn; i++)
                {
                    if (_Shelves[i].Stocker == objectid
                        && _Shelves[i].Type == ShelfType.OutPort
                        && name == _Shelves[i].Name)
                        return _Shelves[i];
                }
            }
            else
                return (Model)g.Parent;

            return null;
        }

        //GetQueue
        public Model GetShelf(string name, string objectid)
        {
            int qn = _Shelves.Count;
            if (name == "empty")
            {
                for (int i = 0; i < qn; i++)
                {
                    if (_Shelves[i].Stocker == objectid
                        && _Shelves[i].Type == ShelfType.Buffer)
                        return _Shelves[i];
                }
            }

            char ch = name[0];
            if (ch == 'T')
            {
                for (int i = 0; i < qn; i++)
                {
                    if (_Shelves[i].Stocker == objectid
                        && _Shelves[i].Type == ShelfType.TM
                        && _Shelves[i].Name.StartsWith(name)
                        && !_Shelves[i].IsFull)
                        return _Shelves[i];
                }
            }
            else if (ch == 'i' || ch == 'I')
            {
                for (int i = 0; i < qn; i++)
                {
                    if (_Shelves[i].Stocker == objectid
                        && _Shelves[i].Type == ShelfType.InPort
                        && name == _Shelves[i].Name)
                        return _Shelves[i];
                }
                return null;
            }
            else if(ch == 'o' || ch == 'O') {
		        for(int i=0; i<qn; i++) {
			        if(_Shelves[i].Stocker == objectid 
                        && _Shelves[i].Type == ShelfType.OutPort
                        && name == _Shelves[i].Name) 
			        {
				        return _Shelves[i];
			        }
                }
            }

	        //여전히 못찾았으면 buffer에 저장
	        for(int i=0; i<qn; i++) {
		        if(_Shelves[i].Stocker == objectid 
                    && _Shelves[i].Type == ShelfType.Buffer) {
			        if(! _Shelves[i].IsFull) return _Shelves[i];
			        else continue;
		        }
	        }

	        return null;
        }

        //GetQueue
        public Model GetShelf(int i)
        {
            return _Shelves[i];
        }

        public Shelf GetShelf(string name)
        {
            Shelf rslt = null;
            foreach (Shelf s in _Shelves)
            {
                if (s.Name.Equals(name))
                {
                    rslt = s;
                    break;
                }
            }
            return rslt;
        }

        //?뭐에 필요하지?
        //CGV3F: x, y, z 가 float 인 vector 로 Mogre.Vector3와 같음
        public Model GetInPort(Mogre.Vector3 p)
        {
            int qn = (int)_Shelves.Count;

	        //확인 필요 (2014-03-25)
	        float dist, minDist = float.MaxValue; int qi = 0;
	        Mogre.Vector3 c2d;
	        for(int i=0; i<qn; i++) {
		        if(_Shelves[i].Type == ShelfType.InPort) {
			        c2d = _Shelves[i].SceneNode.Position; 
                    c2d.z = p.z;
			        dist = (float)System.Math.Sqrt( 
                                    (p.x - c2d.x) * (p.x - c2d.x) + 
                                    (p.y - c2d.y) * (p.y - c2d.y) + 
                                    (p.z - c2d.z)*(p.z - c2d.z));
                    //p.DistTo(c2d);
			        if(dist < minDist) { 
				        minDist = dist; qi = i; 
			        }
		        }
	        }

	        return _Shelves[qi];
        }

        public Model GetOutPort(Mogre.Vector3 p)
        {
            int qn = (int)_Shelves.Count;

            //확인 필요 (2014-03-25)
            float dist, minDist = float.MaxValue; int qi = 0;
            Mogre.Vector3 c2d;
            for (int i = 0; i < qn; i++)
            {
                if (_Shelves[i].Type == ShelfType.OutPort)
                {
                    c2d = _Shelves[i].SceneNode.Position;
                    c2d.z = p.z;
                    dist = (float)System.Math.Sqrt(
                                    (p.x - c2d.x) * (p.x - c2d.x) +
                                    (p.y - c2d.y) * (p.y - c2d.y) +
                                    (p.z - c2d.z) * (p.z - c2d.z));
                    //p.DistTo(c2d);
                    if (dist < minDist)
                    {
                        minDist = dist; qi = i;
                    }
                }
            }

            return _Shelves[qi];
        }

        //GetResource
        public Model GetEquipment(string name)
        {
            int cn = _Equipments.Count;
            for (int i = 0; i < cn; i++)
            {
                if (name == _Equipments[i].Name)
                    return _Equipments[i];
            }

            return null;
        }

        //GetResource
        public Model GetEquipmet(int ri)
        {
            return _Equipments[ri];
        }

        //AddNewGlass

        public Load AddNewCassette(int id)
        {
            string name = "Cassette_" + id;
            Entity loadEntity = _Mgr.CreateEntity(name, SceneManager.PrefabType.PT_CUBE);
            loadEntity.SetMaterialName("Examples/Blue");
            //Entity loadEntity = _Mgr.CreateEntity(name, "porshe.x");
            //loadEntity.SetMaterialName("Examples/Rockwall");
            SceneNode loadNode = _Mgr.RootSceneNode.CreateChildSceneNode(name);// , new Mogre.Vector3(0, 30, 60));
            loadNode.AttachObject(loadEntity);
            loadNode.Scale(0.01f, 0.01f, 0.01f);

            Load g = new Load(loadNode, name);
            g.ID = id;
            _Loads.Add(id, g);

            _TotalSize++;
            return g;
        }

        public void AddCassette(int id, Load cs)
        {
            //기존의 emptycasstte을 full cassette로 변경
            _Loads.Add(id, cs);
            _TotalSize++;
        }

        //AddEmptyGlass
        public Load AddEmptyCassette(int id, Load cs)
        {
            if (cs == null)
            {
                string name = "Cassette_" + id;
                Entity loadEntity = _Mgr.CreateEntity(name, SceneManager.PrefabType.PT_CUBE);
                loadEntity.SetMaterialName("Examples/Red");
                //loadEntity.SetMaterialName("Examples/Rockwall");
                SceneNode loadNode = _Mgr.RootSceneNode.CreateChildSceneNode(name);// , new Mogre.Vector3(0, 30, 60));
                loadNode.AttachObject(loadEntity);
                loadNode.Scale(0.01f, 0.01f, 0.01f);

                cs = new Load(loadNode, name);
                cs.State = LoadState.Empty;
                cs.ID = id;
                _Loads.Add(id, cs);
            }
            else
            {
                Entity fullLoadEntity = (Entity)cs.SceneNode.DetachObject(cs.Name);
                //_Mgr.DestroyEntity(fullLoadEntity);

                string name = "Cassette_" + id;
                Entity emptyLoadEntity = _Mgr.CreateEntity(name, SceneManager.PrefabType.PT_CUBE);
                //emptyLoadEntity.SetMaterialName("Examples/Rockwall");
                emptyLoadEntity.SetMaterialName("Examples/Red");

                RemoveLoad(cs.ID);

                cs.State = LoadState.Empty;
                cs.Name = name;
                cs.ID = id;
                cs.SceneNode.AttachObject(emptyLoadEntity);
                if (!_Loads.ContainsKey(id))
                {
                    _Loads.Add(id, cs);
                }

            }


	        return cs;
        }

        //AddQueue
        public void AddShelf(Shelf s)
        {
            _Shelves.Add(s);
        }

        //AddResource
        public void AddEquipment(Equipment e)
        {
            _Equipments.Add(e);
        }

        public void RemoveLoad(int id)
        {
            _Loads.Remove(id);
        }

        public void RemoveAndDestoryLoad(int id, Entity entity)
        {
            _Loads.Remove(id);
            _Mgr.DestroyEntity(entity);
        }

        public void DeleteLoad(Load cs)
        {
            _Loads.Remove(cs.ID);
            cs = null;
        }

        public Model GetChild(int id) { return FindLoad(id); }

        public Load FindLoad(int id)
        {
            if (_Loads.ContainsKey(id))
                return _Loads[id];
            else
                return null;
	    }

        public void ChangeEmpty2FullCassette(int emptyCstID, int fullCstID)
        {
            //결국, 설비의 outport 의 entity 를 교체해주면 됨

            //Empty Cassette --> full cassette
            Load emptyCst = FindLoad(emptyCstID);
            emptyCst.ID = fullCstID;
            emptyCst.State = LoadState.Full;
            emptyCst.Name = "Cassette_" + fullCstID;

            string emptyLoadName = "Cassette_" + emptyCstID;
            Entity emptyLoadEntity = 
                (Entity)emptyCst.SceneNode.DetachObject(emptyLoadName);
            //_Mgr.DestroyEntity(emptyLoadEntity);
            emptyLoadEntity.Visible = false;

            string fullLoadName = "Cassette_" + fullCstID;
            
            //Entity fullLoadEntity = _Mgr.query
            Entity fullLoadEntity = _Mgr.GetEntity(fullLoadName);
            //Entity fullLoadEntity = _Mgr.CreateEntity(fullLoadName, SceneManager.PrefabType.PT_CUBE);
            //fullLoadEntity.SetMaterialName("Examples/Blue");
            if (fullLoadEntity.IsAttached)
            {
                fullLoadEntity.DetachFromParent();
            }
            fullLoadEntity.Visible = true;
            emptyCst.SceneNode.AttachObject(fullLoadEntity);

            //기존의 empty cassette id 로 되어 있던 것은 삭제
            //e.g. empty cassette (id:1) -> full (id:3)
            //기존에 id 3으로 load가 등록되어 있음
            RemoveLoad(emptyCstID);
            //RemoveLoad(fullCstID);
            AddCassette(fullCstID, emptyCst);
        }

        #endregion
    }
}
