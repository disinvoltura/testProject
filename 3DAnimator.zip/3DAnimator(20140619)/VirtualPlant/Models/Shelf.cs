﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mogre;

namespace VMS.VirtualPlant
{
    public enum ShelfType { Buffer, TM, InPort, OutPort };
    public class Shelf: Model
    {
        #region Member Variables
        public ShelfType Type;
        public int Capacity;
        public string Stocker;
        public int State;
        public int No;
        private ControlPoint _Point;
        #endregion

        #region Properties
        public bool IsEmpty
        {
            get { return (this.No == 0);}
        }

        public bool IsFull
        {
            get { return (this.No == this.Capacity);}
        }

        public ControlPoint ControlPoint
        {
            get { return _Point; }
            set { _Point = value; }
        }
        #endregion

        #region Constructors
        public Shelf(SceneNode node, string name)
            : base(node, name)
        {
            Initialize();

            this.Capacity = 10;
            this.No = 0;
            this.Type = ShelfType.Buffer;
            
        }
        #endregion

        #region Methods
        public bool Add()
        {
            if (IsFull) return false;
            No++;
            return true;
        }

        public void Remove()
        {
            if (!IsEmpty)
                No--;
        }

        public override bool Initialize()
        {
            this.State = 0;
            return false;
        }

        public override bool ProcessEvent(VIPEvent e)
        {
            return false;
        }

        public override void UpdatePosition(float dt)
        {
            //do nothing
        }

        public override void UpdatePosition(Model child, float dt)
        {
            //do nothing
        }
        #endregion

    }
}
