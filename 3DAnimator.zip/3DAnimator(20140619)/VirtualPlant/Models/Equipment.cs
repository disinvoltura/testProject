﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mogre;

namespace VMS.VirtualPlant
{
    //Resource = Equipment
    public class Equipment: Model
    {
        public Equipment(SceneNode node, string name)
            : base(node, name)
        {
            
        }

        public override bool Initialize()
        {
            return true;
        }

        public override bool ProcessEvent(VIPEvent e)
        {
            //Handle Empty Cassette Messages
            ApplicationMessage msg = e.Message;
            
            if (msg.EventName == "bLGL")
            {
                //full cassette --> empty cassette
                Load fullcst = ProcessSystem.Instance.FindLoad(msg.CassetteID);
                ProcessSystem.Instance.AddEmptyCassette(msg.EmptyCassetteID, fullcst);
                return true;

            }else{
                //empty cassette --> full cassette
                ProcessSystem.Instance.ChangeEmpty2FullCassette(msg.EmptyCassetteID, msg.CassetteID);
                return true;
            }
        }

        public override void UpdatePosition(float dt)
        {
            //do nothing
        }

        public override void UpdatePosition(Model child, float dt)
        {
            //do nothing
        }
    }
}
