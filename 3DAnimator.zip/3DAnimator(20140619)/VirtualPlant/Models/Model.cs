﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mogre;

namespace VMS.VirtualPlant
{
    public abstract class Model 
    {
        protected SceneNode _Node;
        protected string _Name;
        protected Model _Parent;
        protected  List<Model> _Children;

        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        public Model Parent
        {
            get { return _Parent; }
            set { _Parent = value; }
        }

        public int ChildrenCount
        {
            get { return _Children.Count; }
        }

        public SceneNode SceneNode
        {
            get { return _Node; }
            set { _Node = value ; }
        }
        public Model (SceneNode node, string name)
        {
            _Node = node;
            _Name = name;
            _Children = new List<Model>();
        }
        
        public void PostEvent(Model from, ApplicationMessage msg, Model to, double time, bool simul)
        {
            if (to == null) to = _Parent;
            //if (to == null) to = (Model)this.Parent;
            VIPEvent e = new VIPEvent(from, msg, to, time, simul);
            EventQueue.Instance.Enqueue(e);
        }

        public void PostEvent(VIPEvent e)
        {
            EventQueue.Instance.Enqueue(e);
        }

        public double Distance(Vector3 a, Vector3 b)
        {
            double distance = 0;

            distance = System.Math.Sqrt(
                (a.x - b.x) * (a.x - b.x) +
                (a.y - b.y) * (a.y - b.y) +
                (a.z - b.z) * (a.z - b.z));

            return distance;
        }

        public abstract bool Initialize();
        public abstract bool ProcessEvent(VIPEvent e);
        public abstract void UpdatePosition(float dt);
        public abstract void UpdatePosition(Model child, float dt);

        #region Children Management Methods
        public Model GetChild(int i)
        {
            return _Children[i];
        }

        public Model GetChild(string name)
        {
            int cn = _Children.Count;

            for (int i = 0; i < cn; i++)
            {
                if (name == _Children[i].Name)
                    return _Children[i];
            }

            Model child = ProcessSystem.Instance.GetEquipment(name);
            if (child != null) return child;

            return null;
        }

        public void AddChild(Model m)
        {
            m.Parent = this;//2014/06/04
            _Children.Add(m);
        }

        public void RemoveChild(Model m)
        {
            int spot = -1;
            for (int i = 0; i < _Children.Count; i++)
            {
                if (_Children[i].Name == m.Name)
                {
                    spot = i;
                    break;
                }
            }

            if (spot >= 0)
                _Children.RemoveAt(spot);
        }
        #endregion
    }
}
