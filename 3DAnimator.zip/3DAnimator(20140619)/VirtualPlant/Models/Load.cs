﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mogre;

namespace VMS.VirtualPlant
{
    public enum LoadState { Full, Processing, Empty, Removed };

    public class Load: Model
    {
        #region Member Variables
        public int ID;
        public LoadState State = LoadState.Full;
        public bool Accumulated;
        #endregion

        #region Constructors
        public Load(SceneNode node, string name)
            : base(node, name)
        {
            this.State = LoadState.Full;
            Initialize();
        }
        #endregion

        #region Methods

        #endregion
        #region Abstract Methods
        public override bool Initialize()
        {
            this.ID = -1;

            return true;
        }

        public override void UpdatePosition(float dt)
        {
            this.Parent.UpdatePosition(this, dt);
        }

        public override void UpdatePosition(Model child, float dt)
        {
            this.Parent.UpdatePosition(this, dt);
        }

        public override bool ProcessEvent(VIPEvent e)
        {
            return false;
        }
        #endregion


    }
}
