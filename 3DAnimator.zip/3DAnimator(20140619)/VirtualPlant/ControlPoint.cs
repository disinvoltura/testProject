﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mogre;

namespace VMS.VirtualPlant
{
    public class ControlPoint
    {
        #region Member Variables
        private Vector3 _Pos;
        private string _Name;
        #endregion

        #region Properties
        public Vector3 Position
        {
            get { return _Pos; }
            set { _Pos = value; }
        }

        public string Name
        {
            get { return _Name; }
        }
        #endregion

        #region Constructors
        public ControlPoint()
        {
            _Pos.x = 0;
            _Pos.y = 0;
            _Pos.z = 0;
        }

        public ControlPoint(float x, float y, string n)
        {
            _Pos.x = x;
            _Pos.y = y;
            _Pos.z = 0;
            _Name = n;
        }

        public ControlPoint(float x, float y, float z, string n)
        {
            _Pos.x = x;
            _Pos.y = y;
            _Pos.z = z;
            _Name = n;
        }
        #endregion

        #region Methods
        public void Set(float x, float y, string n)
        {
            _Pos.x = x;
            _Pos.y = y;
            _Pos.z = 0;
            _Name = n;
        }

        public void Set(float x, float y, float z, string n)
        {
            _Pos.x = x;
            _Pos.y = y;
            _Pos.z = z;
            _Name = n;
        }

        public override string ToString()
        {
            return "ControlPoint(" + _Pos.x +", " + _Pos.y + ", " + _Pos.z + ")";
        }
        #endregion
    }
}
