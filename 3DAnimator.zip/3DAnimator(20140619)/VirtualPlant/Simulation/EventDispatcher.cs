﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace VMS.VirtualPlant
{
    public class EventDispatcher
    {
        public static EventDispatcher Instance;

        #region Member Variables
        private DateTime _StartTime;
        private double _PauseTime;
        private double _ResumeTime;
        private bool _Locked = true;
        private bool _Stop = false;
        private Plant _Plant;

        private double _LastEventTime;

        private System.Windows.Forms.Timer _Timer;

        private ApplicationConnector _Connector;
        #endregion

        #region Properties
        public double LastEventTime
        {
            get { return _LastEventTime; }
            set { _LastEventTime = value; }
        }

        public Plant Plant
        {
            set { _Plant = value; }
        }

        public bool Locked
        {
            get { return _Locked; }
            set { _Locked = value; }
        }
        #endregion

        #region Constructors
        public EventDispatcher()
        {
            EventDispatcher.Instance = this;
            _Stop = true;

            EventQueue.Instance.Enqueued += new EnqueuedEventHandler(Instance_Enqueued);
            _Timer = new System.Windows.Forms.Timer();
            _Timer.Tick += new EventHandler(_Timer_Tick);
        }
        #endregion

        #region Methods
        public void Initialize()
        {
            _StartTime = DateTime.Now;
            _PauseTime = 0;
            _ResumeTime = 0;
            _Locked = true;
        }

        private double _Clock;
        private double _TimeScale = 10;
        private ApplicationMessage _ClockMsg;
        private bool _Wait = false;
        public void Run()
        {
            ApplicationMessage msg;
            _Clock = 0;

            while (true)
            {
                if (_Locked)
                    continue;
                //if (ApplicationConnector.Instance == null
                //    || !ApplicationConnector.Instance.IsConnected)
                //    continue;

                do
                {
                    System.Diagnostics.Debug.WriteLine("[EventDispatcher] reading....");
                    string rawMsg = _Connector.Read_Msg();
                    msg = ApplicationMessage.Parse(rawMsg);

                    if (msg.Type == ApplicationMessageType.Delay ||
                        msg.Type == ApplicationMessageType.EmptyCst)
                    {
                        bool rslt = _Plant.ProcessEvent(new VIPEvent(null, msg, null, msg.EventTime, false));

                        System.Diagnostics.Debug.WriteLine("[EventDispatcher] Application Message is Processed/");
                    }
                } while (msg.Type != ApplicationMessageType.Clock);

                _ClockMsg = msg;

                if (msg.Action == "Nothing")
                {
                    System.Diagnostics.Debug.WriteLine("[EventDispatcher] Handle Clock_Nothing");
                    _LastWallClock = DateTime.Now;
                    _Wait = true;
                    MainForm.App.World.Locked = false;
                    

                    while (_Wait)
                        continue;
                }
                else if (msg.EventTime == _Clock)
                {
                    System.Diagnostics.Debug.WriteLine("[EventDispatcher] Handle Clock_Exist, immediately");
                    _Connector.Send_Msg(new VIPEvent(null, msg, null, msg.EventTime, false));
                }
                else if (_Clock < msg.EventTime)
                {
                    System.Diagnostics.Debug.WriteLine("[EventDispatcher] Handle Clock_Exist wit time advance");
                    _Wait = true;
                    MainForm.App.World.Locked = false;
                    _LastWallClock = DateTime.Now;
                    _Timer.Interval = (int)((msg.EventTime * 1000 - _Clock * 1000) / MainForm.App.TimeScale);
                    _Timer.Start();

                    while (_Wait)
                        continue;
                }

                System.Diagnostics.Debug.WriteLine("[EventDispatcher] EventDispatcher.Iteration ends");
            }

            
        }

        private DateTime _LastWallClock;
        private void Instance_Enqueued()
        {
            MainForm.App.World.Locked = true;

            DateTime curTime = DateTime.Now;
            TimeSpan elaspedTime = curTime.Subtract(_LastWallClock);
            _Clock += elaspedTime.TotalMilliseconds * MainForm.App.TimeScale / 1000;
            VIPEvent e = EventQueue.Instance.Dequeue();
            e.Message.EventTime = _Clock;
            e.Time = _Clock;
            _Connector.Send_Msg(e);

            if (_Timer.Enabled)
                _Timer.Stop();

            _Wait = false;
        }

        void _Timer_Tick(object sender, EventArgs e)
        {
            MainForm.App.World.Locked = true;
            _Clock = _ClockMsg.EventTime;
            _Connector.Send_Msg(new VIPEvent(null, _ClockMsg, null, _ClockMsg.EventTime, false));

            _Timer.Stop();
            _Wait = false;
        }
        /*

        public void Run()
        {
            ApplicationMessage msg;
            VIPEvent e = null;

            //TODO
            //start timer

            while (true)
            {
                System.Threading.Thread.Sleep(50);

                if (_Locked || EventQueue.Instance.IsEmpty)
                    continue;

                e = EventQueue.Instance.Peek();

                if (e.Message.Type == ApplicationMessageType.Resume)
                {
                    EventQueue.Instance.Dequeue();
                    SetStop(false);
                    continue;
                }

                double time = VIPTimer.GetTime();
                while (!_Stop && !EventQueue.Instance.IsEmpty)
                {
                    e = EventQueue.Instance.Peek();
                    if (e.Message.Type == ApplicationMessageType.Pause)
                    {
                        EventQueue.Instance.Dequeue();
                        SetStop(true);
                        break;
                    }
                    else if (e.Message.EventTime > time ||
                        e.Message.EventTime > _LastEventTime)
                    {
                        break;
                    }

                    EventQueue.Instance.Dequeue();

                    if (e.To != null)
                    {
                        e.To.ProcessEvent(e);
                    }
                    else
                    {
                        ApplicationConnector.Send_Msg(e);

                        if (e.Message.Type == ApplicationMessageType.Delay)
                        {
                            break;
                        }
                    }
                }

            }
        }
        */

        public void SetStop(bool flag)
        {
            if (flag)
                _PauseTime = DateTime.Now.Subtract(_StartTime).TotalSeconds;
            else
            {
                _ResumeTime = DateTime.Now.Subtract(_StartTime).TotalSeconds;
                EventQueue tmpQueue = new EventQueue();
                while (!EventQueue.Instance.IsEmpty)
                {
                    VIPEvent e = EventQueue.Instance.Peek();
                    e.Time = e.Time + _ResumeTime - _PauseTime;

                    EventQueue.Instance.Dequeue();
                    tmpQueue.Enqueue(e);
                }
                while (!tmpQueue.IsEmpty)
                {
                    VIPEvent e = tmpQueue.Dequeue();
                    EventQueue.Instance.Enqueue(e);
                }
            }

            _Stop = flag;
        }
        #endregion

        #region Communication methods
        public void Connect()
        {
            //_Connector.ServerConnected +=
            //    new ServerConnectedEventHandler(ApplicationConnector_ServerConnected);
            _Connector = new ApplicationConnector();
            if (_Connector.Connect())
            {
                _Locked = false;
            }

        }

        #endregion
    }
}
