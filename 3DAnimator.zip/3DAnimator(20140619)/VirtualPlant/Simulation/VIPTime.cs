﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.VirtualPlant
{
    public static class VIPTimer
    {
        private static DateTime _StartTime;
        private static double _TimeScale;

        public static void StartTimer()
        {

        }

        public static void SetTimeScale(double s)
        {
            _TimeScale = s;
        }

        public static double GetTime()
        {
            DateTime currentTime = DateTime.Now;

            double seconds = currentTime.Subtract(_StartTime).TotalSeconds * _TimeScale;
            return seconds;
        }
    }
}
