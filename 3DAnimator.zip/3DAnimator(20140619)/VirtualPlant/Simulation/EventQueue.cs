﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.VirtualPlant
{
    public delegate void EnqueuedEventHandler();

    public class EventQueue
    {
        #region Member Variables
        private List<VIPEvent> _Q;
        #endregion
        readonly object _locker = new object();
        public static EventQueue Instance;

        public event EnqueuedEventHandler Enqueued;

        #region Properties
        public int Count { get { return _Q.Count; } }
        public bool IsEmpty
        {
            get { if (_Q.Count == 0) return true; else return false; }
        }
        #endregion

        #region Constructors
        public EventQueue()
        {
            _Q = new List<VIPEvent>();

            EventQueue.Instance = this;
        }
        #endregion

        #region Methods
        public void Clear()
        {
            _Q.Clear();
        }

        public VIPEvent Peek()
        {
            VIPEvent rslt = null;

            if (_Q.Count > 0)
            {
                rslt = _Q[0];
            }

            return rslt;
        }

        public VIPEvent Dequeue()
        {
            VIPEvent rslt = null;

            lock (_locker)
            {
                if (_Q.Count > 0)
                {
                    rslt = _Q[0];
                    _Q.RemoveAt(0);
                }
            }

            return rslt;
        }

        public bool Enqueue(VIPEvent e)
        {
            int qn = _Q.Count;

            lock (_locker)
            {
                if (qn == 0 || _Q[qn] < e)
                {
                    _Q.Add(e);
                    if (this.Enqueued != null || this.Enqueued.GetInvocationList().Length > 0)
                        this.Enqueued();
                    return true;
                }

                for (int i = qn - 1; i >= 0; i--)
                {
                    if (e == _Q[i])
                        return false;
                    else if (_Q[i] < e)
                    {
                        _Q.Insert(i + 1, e);
                        if (this.Enqueued != null || this.Enqueued.GetInvocationList().Length > 0)
                            this.Enqueued();
                        return true;
                    }
                }

                _Q.Insert(0, e);
            }

            if (this.Enqueued != null || this.Enqueued.GetInvocationList().Length > 0)
                this.Enqueued();

            return true;
        }

        
        #endregion
    }
}
