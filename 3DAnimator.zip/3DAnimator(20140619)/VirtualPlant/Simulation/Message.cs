﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.VirtualPlant
{
    public enum ApplicationMessageType { Clock, Delay, EmptyCst, NoMoreEntity, Resume, Pause };
    //Clock: Exit, Nothing
    //Delay: conveyor, Retrieval, Delivery
    public class ApplicationMessage
    {
        public ApplicationMessageType Type;
        public string Action; //Exit and Nothing for Clock, Conveyor, Retrieval, Delivery for Delay
        public string EventName;
        public int EventNo; //Only applies for Clock_Exist
        public string ObjectID;
        public int CassetteID;// only applies for Delay-type message
        public double EventTime;
        public string Source;//Only apply for Delay-type message
        public string Destination; //only apply for Delay-type message
        public int EmptyCassetteID; //empty cassette ID (default: -1 empty cassette 이 없는 경우)

        public static ApplicationMessage Parse(string strLine)
        {
            ApplicationMessage msg = new ApplicationMessage();

            if (strLine[0].Equals('D'))
            {
                //Delay-type message
                //Msg: Delay_<Action>_<EventName>#<ObjectID>#<CassetteID>#<EventTime>#<FromLoc>#<ToLoc>
                int cr = -1;
                msg.Type = ApplicationMessageType.Delay;

                string[] delayMsg = strLine.Split('#');
                string[] msgType = delayMsg[0].Split('_');
                if (!msgType[1].Equals("Conveyor"))
                {
                    //Retrieval or Delivery
                    msg.Action = msgType[1];

                    //Stocker's crane id
                    if (delayMsg[1].Split('_').Length == 1)
                        cr = 1;
                    else
                        cr = int.Parse(delayMsg[1].Split('_')[1]);

                    delayMsg[1] = delayMsg[1].Split('_')[0];
                }
                else
                {
                    msg.Action = "Conveyor";
                }

                msg.EventName = msgType[2];
                msg.ObjectID = delayMsg[1];



                msg.CassetteID = int.Parse(delayMsg[2]);
                msg.EventTime = double.Parse(delayMsg[3]);

                //From and To
                //string[] from = delayMsg[4].Split('_');
                //if (delayMsg[4].StartsWith("inport_"))
                //{
                //    msg.Source = from[1];
                //}
                //else if (delayMsg[4].StartsWith("outport_"))
                //{
                //    msg.Source = from[1];
                //}
                //else
                //{
                //    //conveyor name, eqp name, buffer (Stocker)
                //    msg.Source = delayMsg[4];
                //}
                msg.Source = delayMsg[4];
                msg.Destination = delayMsg[5];
                //string[] to = delayMsg[5].Split('_');
                //if (delayMsg[5].StartsWith("inport_"))
                //{
                //    msg.Destination = to[1];
                //}
                //else if (delayMsg[5].StartsWith("outport_"))
                //{
                //    msg.Destination = to[1];
                //}
                //else
                //{
                //    //conveyor name, eqp name, buffer (Stocker)
                //    msg.Destination = delayMsg[5];
                //}
            }
            else if (strLine.StartsWith("No More"))
            {
                msg.Type = ApplicationMessageType.NoMoreEntity;
            }
            else if (strLine[0].Equals('E'))
            {
                msg.Type = ApplicationMessageType.EmptyCst;
                
                string[] delayMsg = strLine.Split('#');
                string[] msgType = delayMsg[0].Split('_');

                msg.Action = "Cst";
                msg.EventName = msgType[2];
                msg.ObjectID = delayMsg[1];

                string [] strIDs = delayMsg[2].Split(new char[] { '_' }, StringSplitOptions.RemoveEmptyEntries);
                msg.CassetteID = int.Parse(strIDs[1]);
                msg.EmptyCassetteID = int.Parse(strIDs[0]);

                msg.EventTime = double.Parse(delayMsg[3]);

                msg.Source = "";
                msg.Destination = "";
            }
            else if (strLine[0].Equals('C')) //수정 3/23 김현식
            {
                msg.Type = ApplicationMessageType.Clock;

                string[] delayMsg = strLine.Split('#');
                string[] msgType = delayMsg[0].Split('_');

                msg.Action = msgType[1];

                if (msg.Action.Equals("Exist"))
                {
                    msg.EventName = msgType[2];
                    msg.EventNo = int.Parse(msgType[3]);
                    msg.ObjectID = delayMsg[1];
                    msg.EventTime = double.Parse(delayMsg[3]);
                }
                //수정 3/23 김현식
                else if (msg.Action.Equals("Nothing"))
                    return msg;
            }
            //수정 3/23 김현식
            else
            {
                return null;
            }

            return msg;
        }
    }
}
