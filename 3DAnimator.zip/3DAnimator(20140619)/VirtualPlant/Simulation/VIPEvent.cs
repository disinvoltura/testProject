﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.VirtualPlant
{
    public class VIPEvent
    {
        #region Member Variables
        private double _Time;
        private Model _From;
        private Model _To;
        private ApplicationMessage _Message;
        private bool _SimType = false;
        #endregion

        #region Properties
        public double Time { get { return _Time; } set { _Time = value; } }
        public Model From { get { return _From; } set { _From = value; } }
        public Model To { get { return _To; } set { _To = value; } }
        public ApplicationMessage Message { get { return _Message; } set { _Message = value; } }
        public bool SimType { get { return _SimType; } set { _SimType = value; } }
        #endregion

        #region Constructors
        public VIPEvent(
            Model from, 
            ApplicationMessage msg, 
            Model to, 
            double time, 
            bool simul)
        {
            _From = from;
            _Message = msg;
            _To = to;
            _Time = time;
            _SimType = simul;
        }
        #endregion

        #region Operator Methods
        public static bool operator < (VIPEvent a, VIPEvent b)
        {
            if (a.Message.EventTime < b.Message.EventTime) 
                return true;
            else 
                return false;
        }

        public static bool operator > (VIPEvent a, VIPEvent b)
        {
            if (a.Message.EventTime > b.Message.EventTime)
                return true;
            else
                return false;
        }

        public static bool operator ==(VIPEvent a, VIPEvent b)
        {
            if (a.Message.EventTime == b.Message.EventTime)
                return true;
            else
                return false;
        }

        public static bool operator !=(VIPEvent a, VIPEvent b)
        {
            if (a.Message.EventTime != b.Message.EventTime)
                return true;
            else
                return false;
        }

        #endregion
    }
}
