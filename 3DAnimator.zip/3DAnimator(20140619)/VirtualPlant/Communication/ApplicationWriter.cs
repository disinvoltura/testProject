﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace VMS.VirtualPlant
{
    public abstract class ApplicationWriter
    {
        protected StreamWriter _BaseWriter = null;

        public ApplicationWriter(Stream stream)
        {
            _BaseWriter = new StreamWriter(stream);
        }

        public abstract void WriteLine(string line);

        public void Close()
        {
            this.Dispose();
        }

        public void Dispose()
        {
            if (_BaseWriter != null)
                _BaseWriter.Dispose();
        }
    }

    public static class ApplicationWriterFactory
    {
        public static ApplicationWriter GetInstance(string name, Stream stream)
        {
            ApplicationWriter rslt = null;

            if (name.Equals("automod"))
            {
                rslt = new AutomodWriter(stream);
            }

            return rslt;
        }
    }
}
