﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace VMS.VirtualPlant
{
    public class AutomodWriter : ApplicationWriter
    {
        public AutomodWriter(Stream stream)
            : base(stream)
        {

        }
        public override void WriteLine(string line)
        {
            char[] length = new char[2];
            length[0] = (char)(line.Length >> 8);
            length[1] = (char)(line.Length & 0xff);

            _BaseWriter.Write(length);
            _BaseWriter.Write(line);
            _BaseWriter.Flush();
        }
    }
}
