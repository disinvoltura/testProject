﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace VMS.VirtualPlant
{
    public abstract class ApplicationReader : IDisposable
    {
        protected StreamReader _BaseReader = null;

        public ApplicationReader(Stream stream)
        {
            this._BaseReader = new StreamReader(stream);
        }

        public abstract string ReadLine();

        public void Close()
        {
            this.Dispose();
        }

        public void Dispose()
        {
            if (this._BaseReader != null)
                this._BaseReader.Dispose();
        }
    }

    public static class ApplicationReaderFactory
    {
        public static ApplicationReader GetInstance(string name, Stream stream)
        {
            ApplicationReader rslt = null;

            if (name.Equals("automod"))
            {
                rslt = new AutomodReader(stream);
            }

            return rslt;
        }
    }
}
