﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Net.Sockets;
using System.Net;
using VMS.Foundation.Logging;

namespace VMS.VirtualPlant
{
    public delegate void ServerConnectedEventHandler();
    public delegate void ServerDisconnectedEventHandler();
    public class ApplicationConnector
    {
        //public static ApplicationConnector Instance;

        #region Member Variables
        private NetworkStream _Stream;
        private string _IP = "127.0.0.1";
        private int _Port = 5555;
        private TcpListener _Listener = null;
        private TcpClient _TcpClient = null;
        private ApplicationWriter _Writer = null;
        private ApplicationReader _Reader = null;
        private Socket _Client;
        #endregion

        public event ServerConnectedEventHandler ServerConnected;
        public event ServerDisconnectedEventHandler ServerDisconnected;

        #region Properties
        public  string IP
        {
            get { return _IP; }
            set { _IP = value; }
        }

        public  int Port
        {
            get { return _Port; }
            set { _Port = value; }
        }

        public  ApplicationWriter Writer
        {
            get { return _Writer; }
        }

        public  ApplicationReader Reader
        {
            get { return _Reader; }
        }

        public bool IsConnected
        {
            get {
                if (_TcpClient == null)
                    return false;

                else return _TcpClient.Connected;
            }
        }

        #endregion

        public ApplicationConnector()
        {
            //ApplicationConnector.Instance = this;
        }

        #region Methods
        public  bool Connect()
        {
            bool rslt = false;
            _TcpClient = null;

            try
            {
                _TcpClient = new TcpClient();
                _TcpClient.Connect(_IP, _Port);
                
                
            }
            catch (Exception ex)
            {
                rslt = false;
                System.Diagnostics.Debug.WriteLine("Error Message: " + ex.StackTrace);
            }

            if (_TcpClient.Connected)
            {
                rslt = true;
                
                _Client = _TcpClient.Client;
                _Stream = new NetworkStream(_Client);
                _Reader = ApplicationReaderFactory.GetInstance("automod", _Stream);
                _Writer = ApplicationWriterFactory.GetInstance("automod", _Stream);
                
                _Writer.WriteLine("Simulation Start");//.ReadLine();

                if (ServerConnected != null && ServerConnected.GetInvocationList().Length>0)
                    ServerConnected();
            }

            return rslt;
        }
       
        public  void Send_Msg(string msg)
        {
            System.Diagnostics.Debug.WriteLine("[Send] " + msg);

            Logger logger = LogManager.GetLogger("Communication");
            logger.Log(LogLevel.Debug, "Send: " + msg);

            try
            {
                _Writer.WriteLine(msg);
            }
            catch (Exception ex)
            {
                logger.Error("IFS is disconnected.");
                System.Diagnostics.Debug.WriteLine("[Send] IFS is disconnected.");

                if (ServerDisconnected != null && ServerDisconnected.GetInvocationList().Length > 0)
                    ServerDisconnected();
            }
        }

        public  void Send_Msg(VIPEvent e)
        {
            string msgType = "";
            string msg ="";
            if (e.Message.Type == ApplicationMessageType.Clock)
            {
                msgType = "Clock_" + e.Message.Action;

                if (e.Message.Action.ToLower() == "exist")
                    msgType += "_" + e.Message.EventName+ "_" + e.Message.EventNo;

                msg = string.Format("{0}#{1}#{2}#{3}#{4}#{5}", msgType, e.Message.ObjectID, e.Message.CassetteID, e.Message.EventTime, e.Message.Source, e.Message.Destination);
            }
            else if (e.Message.Type == ApplicationMessageType.Delay)
            {
                msgType = "Delay_" + e.Message.Action + "_" + e.Message.EventName;

                msg = string.Format("{0}#{1}#{2}#{3}#{4}#{5}",
                    msgType, e.Message.ObjectID, e.Message.CassetteID, e.Time, e.Message.Source, e.Message.Destination);
            }
            else if (e.Message.Type == ApplicationMessageType.EmptyCst)
            {
                msgType = "Empty_Cst_" + e.Message.EventName;
                msg = string.Format("{0}#{1}#{2}#{3}#{4}#{5}",
                    msgType, e.Message.ObjectID, e.Message.CassetteID, e.Time, e.Message.Source, e.Message.Destination);
            }

            Send_Msg(msg);
        }

        public  string Read_Msg()
        {
            string msg = string.Empty;

            try
            {
                msg = _Reader.ReadLine();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());

                if (ServerDisconnected != null && 
                    ServerDisconnected.GetInvocationList().Length > 0)
                    ServerDisconnected();
                //throw new Exception("Error while reading a message", ex);
            }

            Logger logger = LogManager.GetLogger("Communication");
            logger.Log(LogLevel.Debug, "Receive: " + msg);

            System.Diagnostics.Debug.WriteLine("[Read] " + msg);

            return msg;
        }

        public  void Close()
        {
            if (_Client != null)
                _Client.Close();
            if (_Writer != null)
                _Writer.Close();
            if (_Reader != null)
                _Reader.Close();
            if (_Stream != null)
            _Stream.Close();
            if (_Listener!= null)
            _Listener.Stop();
        }

        public  void Disconnect()
        {
            Close();
        }
        #endregion
    }
}
