﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace VMS.VirtualPlant
{
    public class AutomodReader : ApplicationReader
    {
        public AutomodReader(Stream stream)
            : base(stream)
        {
        }

        public override string ReadLine()
        {
            int l0, l1;
            l0 = _BaseReader.Read();
            l1 = _BaseReader.Read();

            int length = (l0 << 8) | l1;

            char[] buffer = new char[length];

            _BaseReader.Read(buffer, 0, length);

            return new String(buffer);
        }
    }

}
