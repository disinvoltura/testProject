﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mogre;

namespace VMS.VirtualPlant
{
    public abstract class Path
    {
        #region Member Variables
        protected Vector3 _SP;
        protected Vector3 _EP;
        #endregion

        #region Properties
        public Vector3 StartPosition
        {
            get { return _SP; }
            set { _SP = value; }
        }

        public Vector3 EndPosition
        {
            get { return _EP; }
            set { _EP = value; }
        }
        #endregion 

        #region Constructors
        public Path(){}
        #endregion;

        #region abstract methods
        public abstract Vector3 CalcNextPosition(Vector3 curPos, double ds);
        public abstract bool Include(Vector3 p);
        #endregion

        public double Distance(Vector3 a, Vector3 b)
        {
            double distance = 0;

            distance = System.Math.Sqrt(
                (a.x - b.x) * (a.x - b.x) +
                (a.y - b.y) * (a.y - b.y) +
                (a.z - b.z) * (a.z - b.z));

            return distance;
        }
    }

    public class LinePath : Path
    {
        private Vector3 _Dir;

        #region Abstract Methods
        public void Initialize()
        {
            _Dir = _EP - _SP;
            _Dir.Normalise();
        }

        public override Vector3 CalcNextPosition(Vector3 curPos, double ds)
        {
            Mogre.Vector3 move = _Dir * (float)ds;
            return move;
        }
        /*
        public override Vector3 CalcNextPosition(Vector3 curPos, double ds)
        {
            double dist = Distance(_EP, _SP);// _EP.DistTo(_SP);
            double t = (Distance(curPos, _SP) + ds) / dist;//curPos.DistTo(_SP) + ds) / dist;
            if (t < 0) t = 0;
            else if (t > 1) t = 1;
            return (_SP * (float)(1 - t) + _EP * (float)t);
        }
        */

        public override bool Include(Vector3 p)
        {
            double t = (p - _SP).DotProduct((_EP - _SP).NormalisedCopy) / Distance(_EP, _SP);
            //double t = (p - sp).Dot((ep - sp).GetUnitV()) / ep.DistTo(sp);
            if (t < 0) return false;
            else if (t > 1) return false;
            return true;
        }
        #endregion
    }

    /*
    public class CircularPath : Path
    {
        private Vector3 _Center;

        #region Abstract Methods
        public Vector3 CalcNextPosition(Vector3 curPos, double ds)
        {
            Vector3 normal = curPos - _Center;
            normal.Normalise();

            Vector3 tangent = normal.Perpendicular;
            Vector3 np = curPos + tangent * (float)ds;
            np = _Center + (np - _Center).NormalisedCopy * (Distance(_SP, _Center));

            //CGV3F normal = curPos - center; normal.Normalize();
            //CGV3F tangent = normal.PerpDot();
            //CGV3F np = curPos + tangent * ds;
            ////원주 위로 project
            //np = center + (np - center).GetUnitV() * (sp.DistTo(center));
        }

        public bool Include(Vector3 p)
        {
            return false;
        }
    }*/
}
