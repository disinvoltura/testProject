﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.Foundation.Logging;

namespace VMS.VirtualPlant
{
    public class RichTextBoxLogHandler : LogHandler
    {
        private System.Windows.Forms.RichTextBox _writer = null;
        private StringBuilder _SB;
        public RichTextBoxLogHandler(
            System.Windows.Forms.RichTextBox txtbox, LogFormatter fmt)
            : base(fmt)
        {
            TextBoxWriter = txtbox;
            if (_SB == null)
                _SB = new StringBuilder();
        }

        public virtual System.Windows.Forms.RichTextBox TextBoxWriter
        {
            set
            {
                lock (this)
                {
                    ResetWriter();
                    _writer = value;
                    WriteHeader();
                }
            }
        }

        protected override void DoPublish(LogRecord record)
        {
            Write(Formatter.Format(record));
        }

        protected virtual void Write(string text)
        {
            _writer.AppendText(text);
        }

        protected void WriteFooter()
        {
            if (Formatter != null && _writer != null)
            {
                _SB.Append(Formatter.GetFooter(this));
            }
        }

        protected virtual void ResetWriter()
        {
            WriteFooter();
            CloseWriter();
            _writer = null;
        }

        protected void CloseWriter()
        {
            if (_writer != null)
            {
                try
                {
                    _writer = null;
                }
                catch (Exception e)
                {
                    throw new InvalidOperationException("Could not close writer [" + _writer + "]", e);
                    // do need to invoke an error handler
                    // at this late stage
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            this.CloseWriter();
        }

        protected void WriteHeader()
        {
            if (Formatter != null && _writer != null)
            {
                if (_SB == null)
                    _SB = new StringBuilder();

                _SB.Append(Formatter.GetHeader(this));
            }
        }
    }
}
