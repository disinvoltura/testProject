﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Mogre;
using MOIS;

namespace VMS.VirtualPlant
{
    public partial class OrgeControl : UserControl
    {
        Root mRoot;
        RenderWindow mWindow;
        protected Camera mCamera;
        protected CameraMan mCameraMan;
        protected int mTextureMode = 0;

        protected int mRenderMode = 0;
        public OrgeControl()
        {
            InitializeComponent();

            this.Size = new Size(1920, 1080);
            Disposed += new EventHandler(OgreForm_Disposed);
            //Resize += new EventHandler(OgreForm_Resize);
            this.Resize += new EventHandler(OrgeControl_Resize);
        }

        void OrgeControl_Resize(object sender, EventArgs e)
        {
            if (mWindow != null)
                mWindow.WindowMovedOrResized();
        }

        void OgreForm_Disposed(object sender, EventArgs e)
        {
            if (mRoot != null)
                mRoot.Dispose();
            mRoot = null;
        }

        void OgreForm_Resize(object sender, EventArgs e)
        {
            if (mWindow != null)
            mWindow.WindowMovedOrResized();
        }

        public void Go()
        {
            Show();

            try
            {
                while (mRoot != null && mRoot.RenderOneFrame())
                    Application.DoEvents();

            }catch(Exception ex){}
        }

        public void Init()
        {
            // Create root object
            mRoot = new Root();
            mRoot.FrameRenderingQueued += new FrameListener.FrameRenderingQueuedHandler(ProcessBufferedInput);

            // Define Resources
            ConfigFile cf = new ConfigFile();
            cf.Load("resources.cfg", "\t:=", true);
            ConfigFile.SectionIterator seci = cf.GetSectionIterator();
            String secName, typeName, archName;

            while (seci.MoveNext())
            {
                secName = seci.CurrentKey;
                ConfigFile.SettingsMultiMap settings = seci.Current;
                foreach (KeyValuePair<string, string> pair in settings)
                {
                    typeName = pair.Key;
                    archName = pair.Value;
                    ResourceGroupManager.Singleton.AddResourceLocation(archName, typeName, secName);
                }
            }

            // Setup RenderSystem
            RenderSystem rs = mRoot.GetRenderSystemByName("Direct3D9 Rendering Subsystem");
            // or use "OpenGL Rendering Subsystem"
            mRoot.RenderSystem = rs;
            rs.SetConfigOption("Full Screen", "No");
            rs.SetConfigOption("Video Mode", "1920 x 1080 @ 32-bit colour");

            // Create Render Window
            mRoot.Initialise(false, "Main Ogre Window");
            NameValuePairList misc = new NameValuePairList();
            misc["externalWindowHandle"] = Handle.ToString();
            mWindow = mRoot.CreateRenderWindow("Main RenderWindow", 1920, 1080, false, misc);

            // Init resources
            TextureManager.Singleton.DefaultNumMipmaps = 5;
            ResourceGroupManager.Singleton.InitialiseAllResourceGroups();

            initializeInput();

            // Create a Simple Scene
            SceneManager mgr = mRoot.CreateSceneManager(SceneType.ST_GENERIC);
            Camera mCamera = mgr.CreateCamera("Camera");
            mCamera.AutoAspectRatio = true;
            mWindow.AddViewport(mCamera);

            Entity ent = mgr.CreateEntity("ninja", "ninja.mesh");
            mgr.RootSceneNode.CreateChildSceneNode().AttachObject(ent);

            mCamera.Position = new Mogre.Vector3(0, 200, -400);
            mCamera.LookAt(ent.BoundingBox.Center);
            mCameraMan = new CameraMan(mCamera);

        }

        protected MOIS.InputManager mInputMgr;
        protected MOIS.Keyboard mLocalKeyboard;
        protected MOIS.Mouse mLocalMouse;

        private void initializeInput()
        {
            int windowHnd;
            
            //mWindow.GetCustomAttribute("WINDOW", out windowHnd);
            //var inputMgr = MOIS.InputManager.CreateInputSystem((uint)windowHnd);
            
            //var inputMgr = MOIS.InputManager.CreateInputSystem((uint)this.Parent.Handle);
            
            //mLocalKeyboard = (MOIS.Keyboard)inputMgr.CreateInputObject(MOIS.Type.OISKeyboard, true);
            //mLocalMouse = (MOIS.Mouse)inputMgr.CreateInputObject(MOIS.Type.OISMouse, true);

            //mLocalKeyboard.KeyPressed += new MOIS.KeyListener.KeyPressedHandler(OnKeyPressed);
            //mLocalKeyboard.KeyReleased += new MOIS.KeyListener.KeyReleasedHandler(OnKeyReleased);
            
            
            
            
            //mLocalMouse.MouseMoved += new MOIS.MouseListener.MouseMovedHandler(OnMouseMoved);
            //mLocalMouse.MousePressed += new MOIS.MouseListener.MousePressedHandler(OnMousePressed);
            //mLocalMouse.MouseReleased += new MOIS.MouseListener.MouseReleasedHandler(OnMouseReleased);

        }

        bool ProcessBufferedInput(FrameEvent evt)
        {
            try
            {
                ProcessInput();

                UpdateScence(evt);

                mCameraMan.UpdateCamera(evt.timeSinceLastFrame);

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }

        }

        private void ProcessInput()
        {
            mLocalKeyboard.Capture();
            mLocalMouse.Capture();
        }

        private void UpdateScence(FrameEvent evt)
        {
            //Vector3 ninjaMove = Vector3.ZERO;

            //if (mKeyboard.IsKeyDown(MOIS.KeyCode.KC_I))
            //    ninjaMove.z -= 200;

            //if (mKeyboard.IsKeyDown(MOIS.KeyCode.KC_K))
            //    ninjaMove.z += 200;

            //if (mKeyboard.IsKeyDown(MOIS.KeyCode.KC_J))
            //    ninjaMove.x -= 200;

            //if (mKeyboard.IsKeyDown(MOIS.KeyCode.KC_L))
            //    ninjaMove.x += 200;

            //mNinjaNode.Translate(ninjaMove * evt.timeSinceLastFrame, Node.TransformSpace.TS_LOCAL);

        }

        protected virtual bool OnKeyPressed(KeyEvent evt)
        {
            switch (evt.key)
            {
                case KeyCode.KC_W:
                case KeyCode.KC_UP:
                    mCameraMan.GoingForward = true;
                    break;

                case KeyCode.KC_S:
                case KeyCode.KC_DOWN:
                    mCameraMan.GoingBack = true;
                    break;

                case KeyCode.KC_A:
                case KeyCode.KC_LEFT:
                    mCameraMan.GoingLeft = true;
                    break;

                case KeyCode.KC_D:
                case KeyCode.KC_RIGHT:
                    mCameraMan.GoingRight = true;
                    break;

                case KeyCode.KC_E:
                case KeyCode.KC_PGUP:
                    mCameraMan.GoingUp = true;
                    break;

                case KeyCode.KC_Q:
                case KeyCode.KC_PGDOWN:
                    mCameraMan.GoingDown = true;
                    break;

                case KeyCode.KC_LSHIFT:
                case KeyCode.KC_RSHIFT:
                    mCameraMan.FastMove = true;
                    break;

                case KeyCode.KC_T:
                    CycleTextureFilteringMode();
                    break;

                case KeyCode.KC_R:
                    CyclePolygonMode();
                    break;

                case KeyCode.KC_F5:
                    ReloadAllTextures();
                    break;

                case KeyCode.KC_SYSRQ:
                    TakeScreenshot();
                    break;

                case KeyCode.KC_ESCAPE:
                    Shutdown();
                    break;
            }

            return true;
        }


        protected virtual bool OnKeyReleased(KeyEvent evt)
        {
            switch (evt.key)
            {
                case KeyCode.KC_W:
                case KeyCode.KC_UP:
                    mCameraMan.GoingForward = false;
                    break;

                case KeyCode.KC_S:
                case KeyCode.KC_DOWN:
                    mCameraMan.GoingBack = false;
                    break;

                case KeyCode.KC_A:
                case KeyCode.KC_LEFT:
                    mCameraMan.GoingLeft = false;
                    break;

                case KeyCode.KC_D:
                case KeyCode.KC_RIGHT:
                    mCameraMan.GoingRight = false;
                    break;

                case KeyCode.KC_E:
                case KeyCode.KC_PGUP:
                    mCameraMan.GoingUp = false;
                    break;

                case KeyCode.KC_Q:
                case KeyCode.KC_PGDOWN:
                    mCameraMan.GoingDown = false;
                    break;

                case KeyCode.KC_LSHIFT:
                case KeyCode.KC_RSHIFT:
                    mCameraMan.FastMove = false;
                    break;
            }

            return true;
        }

        protected virtual bool OnMouseMoved(MouseEvent evt)
        {
            mCameraMan.MouseMovement(evt.state.X.rel, evt.state.Y.rel);
            return true;
        }

        protected virtual bool OnMousePressed(MouseEvent evt, MouseButtonID id)
        {
            return true;
        }

        protected virtual bool OnMouseReleased(MouseEvent evt, MouseButtonID id)
        {
            return true;
        }


        protected void ReloadAllTextures()
        {
            TextureManager.Singleton.ReloadAll();
        }

        protected void CycleTextureFilteringMode()
        {
            mTextureMode = (mTextureMode + 1) % 4;
            switch (mTextureMode)
            {
                case 0:
                    MaterialManager.Singleton.SetDefaultTextureFiltering(TextureFilterOptions.TFO_BILINEAR);
                    //mDebugOverlay.AdditionalInfo = "BiLinear";
                    break;

                case 1:
                    MaterialManager.Singleton.SetDefaultTextureFiltering(TextureFilterOptions.TFO_TRILINEAR);
                    //mDebugOverlay.AdditionalInfo = "TriLinear";
                    break;

                case 2:
                    MaterialManager.Singleton.SetDefaultTextureFiltering(TextureFilterOptions.TFO_ANISOTROPIC);
                    MaterialManager.Singleton.DefaultAnisotropy = 8;
                    //mDebugOverlay.AdditionalInfo = "Anisotropic";
                    break;

                case 3:
                    MaterialManager.Singleton.SetDefaultTextureFiltering(TextureFilterOptions.TFO_NONE);
                    MaterialManager.Singleton.DefaultAnisotropy = 1;
                    //mDebugOverlay.AdditionalInfo = "None";
                    break;
            }
        }

        protected void CyclePolygonMode()
        {
            mRenderMode = (mRenderMode + 1) % 3;
            switch (mRenderMode)
            {
                case 0:
                    mCamera.PolygonMode = PolygonMode.PM_SOLID;
                    break;

                case 1:
                    mCamera.PolygonMode = PolygonMode.PM_WIREFRAME;
                    break;

                case 2:
                    mCamera.PolygonMode = PolygonMode.PM_POINTS;
                    break;
            }
        }

        protected void TakeScreenshot()
        {
            mWindow.WriteContentsToTimestampedFile("screenshot", ".png");
        }

        protected void Shutdown()
        {
            //throw new ShutdownException();
        }

        private void OrgeControl_SizeChanged(object sender, EventArgs e)
        {
            if (mWindow != null)
                mWindow.WindowMovedOrResized();
        }

    }
}
