﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VMS.Foundation.Logging;

namespace VMS.VirtualPlant
{
    public partial class OutputWindow : Form
    {
        RichTextBoxLogHandler handler1; 

        public OutputWindow()
        {
            Form.CheckForIllegalCrossThreadCalls = false;
            InitializeComponent();

            ConnectLogHandlers();
        }

        public void ConnectLogHandlers()
        {
            VMS.Foundation.Logging.SimpleFormatter formatter =
                new VMS.Foundation.Logging.SimpleFormatter();
            formatter.WriteLoggerInfo = false;

            formatter.WriteTimeStamp = false;
            Logger logger1 = LogManager.GetLogger("Communication");
            logger1.Level = LogLevel.Always;

            handler1 =
                new RichTextBoxLogHandler(txtCom, formatter);
            logger1.AddHandler(handler1);
        }

        public void DisconnectLogHandlers()
        {
            Logger logger1 = LogManager.GetLogger("Communication");

            logger1.RemoveHandler(handler1);
        }

        public void Clear()
        {
            txtCom.Text = "";
        }

        public void WriteLine(string line)
        {
            txtCom.AppendText(line);
        }
    }

}
