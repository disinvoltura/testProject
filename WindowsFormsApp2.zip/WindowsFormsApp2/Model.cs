﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    public delegate void PropertyChangedEventHandler(object target, string propertyName, object oldPropertyValue, object newPropertyValue);
    
    [Serializable()]
    public class Model : ISerializable
    {
        #region Member Variables
        private Guid _ID;
        private string _Name;
        private string _Description;
        private string _Creator;
        private string _FileName;

        private List<ModelProperty> _Properties;
        #endregion

        #region Properties
        public Guid ID
        {
            get
            {
                if (_ID.ToString() == "00000000-0000-0000-0000-000000000000")
                    _ID = Guid.NewGuid(); return _ID;
            }
            set { _ID = value; }
        }

        public List<ModelProperty> Properties { get { return _Properties; } set { _Properties = value; } }
        public string Name { get { return _Name; } set { _Name = value; } }
        public string Description { get { return _Description; } set { _Description = value; } }
        public string Creator { get { return _Creator; } set { _Creator = value; } }
        public string FileName { get { return _FileName; } set { _FileName = value; } }

        #endregion

        #region Constructors
        public Model()
        {
            _Name = string.Empty;
            _Description = string.Empty;
            _Creator = string.Empty;
            _FileName = string.Empty;

            _Properties = new List<ModelProperty>();

        }

        public Model(string name, string desc, string creator)
            : this()
        {
            _ID = Guid.NewGuid();
            _Name = name;
            _Description = desc;
            _Creator = creator;
        }

        public Model(SerializationInfo info, StreamingContext ctx)
        {
            _ID = (Guid)info.GetValue("ID", typeof(Guid));
            _Name = (string)info.GetValue("Name", typeof(string));
            _Description = (string)info.GetValue("Description", typeof(string));
            _Creator = (string)info.GetValue("Creator", typeof(string));
            try { _Properties = (List<OOMMModelProperty>)info.GetValue("Properties", typeof(List<OOMMModelProperty>)); } catch (Exception e) { }

            try { _ID = (Guid)info.GetValue("ID", typeof(Guid)); } catch (Exception e) { _ID = Guid.NewGuid(); }
            try { _FileName = (string)info.GetValue("FileName", typeof(string)); } catch (Exception e) { }

            if (_ID.ToString() == "00000000-0000-0000-0000-000000000000")
                _ID = Guid.NewGuid();
        }
        #endregion

        #region Methods
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("ID", _ID);
            info.AddValue("Name", _Name);
            info.AddValue("Description", _Description);
            info.AddValue("Creator", _Creator);
            info.AddValue("Properties", _Properties);

            info.AddValue("ID", _ID);
            info.AddValue("FileName", _FileName);
        }

        public object FindProperty(string name)
        {
            object rslt = null;

            foreach (ModelProperty property in _Properties)
            {
                if (property.Name.Equals(name))
                {
                    rslt = property.Value;
                    break;
                }
            }
            return rslt;
        }

        public void SetProperty(string name, object value)
        {
            bool isNew = true;
            foreach (ModelProperty property in _Properties)
            {
                if (property.Name.Equals(name))
                {
                    property.Value = value;
                    isNew = false;
                    break;
                }
            }

            if (isNew)
            {
                _Properties.Add(new ModelProperty(name, value));
            }
        }
        #endregion
    }
}
