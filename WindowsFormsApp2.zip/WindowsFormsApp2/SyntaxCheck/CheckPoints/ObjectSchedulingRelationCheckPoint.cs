﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.OID;
using DHKANG.SEA.Model.OID.Charts;
using DHKANG.SEA.Model.OID.Data;
using DHKANG.SEA.Model.EventObjects;

namespace DHKANG.SEA.UI.SyntaxCheck
{
    public class ObjectSchedulingRelationCheckPoint : ICheckPoint
    {
        public List<CheckPointMessage> Check(OOMMModel model)
        {
            List<CheckPointMessage> rslt = new List<CheckPointMessage>();

            OOMMObjectInteractionDiagram diagram = model.ObjectInteractionDiagram;
            //1. not-connected event object node
            foreach (OOMMObjectNode node in diagram.ObjectNodes)
            {
                bool isConnected = false;
                foreach (OOMMObjectInteractionEdge edge in diagram.ObjectInteractionEdges)
                {
                    if (node.NodeID.Equals(edge.BoundaryObject) ||
                        node.NodeID.Equals(edge.MirrorObject))
                    {
                        isConnected = true;
                        break;
                    }
                }
                if (!isConnected)
                {
                    if (diagram.ObjectNodes.Count > 1)
                    {
                        CheckPointMessage msg = new CheckPointMessage(CheckPointType.Warning,
                                  "An Object node <" + node.Name + "> is not connected to any other Object nodes, <" + node.Name + ">", node.Name, model.Name);
                        msg.ScopeId = node.NodeID;
                        rslt.Add(msg);
                    }
                }
            }
            //2. duplicate name
            List<string> namelist = new List<string>();
            foreach (OOMMObjectNode node in diagram.ObjectNodes)
            {
                if (namelist.Contains(node.Name))
                {
                    CheckPointMessage msg =
                            new CheckPointMessage(CheckPointType.Error,
                                                  "Duplicated Names in Object Nodes, <" + node.Name + ">", node.Name, model.Name);
                    msg.ScopeId = node.NodeID;
                    rslt.Add(msg);
                }
                else
                {
                    namelist.Add(node.Name);
                }
            }

            namelist = new List<string>();
            foreach (OOMMBarChart chart in diagram.BarCharts)
            {
                if (namelist.Contains(chart.Title))
                {
                    CheckPointMessage msg =
                            new CheckPointMessage(CheckPointType.Error,
                                                  "Duplicated Names in Bar Chart, <" + chart.Title + ">", chart.Title, model.Name);
                    rslt.Add(msg);
                }
                else
                {
                    namelist.Add(chart.Title);
                }
            }
            foreach (OOMMPieChart chart in diagram.PieCharts)
            {
                if (namelist.Contains(chart.Title))
                {
                    CheckPointMessage msg =
                            new CheckPointMessage(CheckPointType.Error,
                                                  "Duplicated Names in Pie Chart, <" + chart.Title + ">", chart.Title, model.Name);
                    rslt.Add(msg);
                }
                else
                {
                    namelist.Add(chart.Title);
                }
            }
            foreach (OOMMTimePlot chart in diagram.TimePlots)
            {
                if (namelist.Contains(chart.Title))
                {
                    CheckPointMessage msg =
                            new CheckPointMessage(CheckPointType.Error,
                                                  "Duplicated Names in Time Plot, <" + chart.Title + ">", chart.Title, model.Name);
                    rslt.Add(msg);
                }
                else
                {
                    namelist.Add(chart.Title);
                }
            }
            foreach (OOMMPlot chart in diagram.Plots)
            {
                if (namelist.Contains(chart.Title))
                {
                    CheckPointMessage msg =
                            new CheckPointMessage(CheckPointType.Error,
                                                  "Duplicated Names in Plot, <" + chart.Title + ">", chart.Title, model.Name);
                    rslt.Add(msg);
                }
                else
                {
                    namelist.Add(chart.Title);
                }
            }
            namelist = new List<string>();
            foreach (OOMMDataSetNode ds in diagram.DataSetNodes)
            {
                if (namelist.Contains(ds.DataSetName))
                {
                    CheckPointMessage msg =
                            new CheckPointMessage(CheckPointType.Error,
                                                  "Duplicated Names in Data Sets, <" + ds.DataSetName + ">", ds.DataSetName, model.Name);
                    rslt.Add(msg);
                }
                else
                {
                    namelist.Add(ds.DataSetName);
                }
            }
            /*
            //3. at least one event object node has the initial event
            List<Guid> activeEOs = new List<Guid>();
            foreach (OOMMObjectNode node in diagram.ObjectNodes)
            {
                if (node.Type == ObjectNodeType.EventObject)
                {
                    if (!activeEOs.Contains(node.ModelID))
                    {
                        activeEOs.Add(node.ModelID);
                    }
                }
            }

            int initialCount = 0;
            foreach (Guid id in activeEOs)
            {
                OOEGEventObjectModel eo = model.FindEventObjectModel(id);

                bool hasInitialEvent = false;
                foreach(OOEGEventTransition et in eo.EventTransitions)
                {
                    if (et.InitialEvent)
                    {
                        hasInitialEvent = true; break;
                    }
                }
                if (!hasInitialEvent)
                {
                    initialCount++;
                }
            }

            if (initialCount == activeEOs.Count)
            {
                CheckPointMessage msg = new CheckPointMessage(CheckPointType.Error,
                          "None of active event object models has the initial event, which leads to non-executable simulation.", "", model.Name);
                rslt.Add(msg);
            }
            */

            return rslt;
        }
    }
}
