﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI.SyntaxCheck
{
    public interface ICheckPoint
    {
        List<CheckPointMessage> Check(Model model);
    }
}
