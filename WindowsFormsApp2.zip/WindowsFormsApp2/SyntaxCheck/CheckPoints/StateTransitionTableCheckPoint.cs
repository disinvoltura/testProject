﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.StateObjects;

namespace DHKANG.SEA.UI.SyntaxCheck
{
    public class StateTransitionTableCheckPoint : ICheckPoint
    {
        public List<CheckPointMessage> Check(OOMMModel model)
        {
            List<CheckPointMessage> rslt = new List<CheckPointMessage>();

            foreach (OOSGStateObjectModel eoModel in model.StateObjectModels)
            {
                List<CheckPointMessage> eoMessages = new List<CheckPointMessage>();
                eoMessages = doCheck(model.Name, eoModel);
                if (eoMessages.Count > 0)
                    rslt.AddRange(eoMessages);
            }
            return rslt;
        }

        private List<CheckPointMessage> doCheck(string modelName, OOSGStateObjectModel model)
        {
            List<CheckPointMessage> rslt = new List<CheckPointMessage>();

            //Initial State 
            if (model.InitialState == null)
            {
                CheckPointMessage msg = new CheckPointMessage(CheckPointType.Warning,
                                  "A state object model <" + model.Name + "> does not have an initial state, which may hinder the execution of a simulation run.", model.Name, modelName);
                rslt.Add(msg);
            }

            //Not used state variable
            bool hasNotUsedStateVariable = false;
            string targetName = string.Empty;
            string targetAtomicModel = string.Empty;

            foreach (OOSGStateVariable var in model.StateVariables)
            {
                bool isUsedInAtomicModels = false;
                foreach (OOSGStateTransition transition in model.STT)
                {
                    //action
                    if (transition.EntryAction.Contains(var.Name) ||
                        transition.InputAction.Contains(var.Name) ||
                        transition.TransitionAction.Contains(var.Name))
                    {
                        isUsedInAtomicModels = true;
                        break;
                    }
                }

                if (!isUsedInAtomicModels)
                {
                    hasNotUsedStateVariable = true;
                    targetName = var.Name;
                    targetAtomicModel = model.Name;
                    break;
                }
            }

            if (hasNotUsedStateVariable)
            {
                string desc = "The defined state variable <" + targetName + "> in the atomic model <" + targetAtomicModel + "> is not used. Check the state variable correctly defined.";

                CheckPointMessage msg = new CheckPointMessage(CheckPointType.Warning, desc, model.Name, modelName);
                rslt.Add(msg);
            }

            //dangling states
            bool hasDanglingState = false;
            targetName = string.Empty;
            targetAtomicModel = string.Empty;

            foreach (OOSGState state in model.States)
            {
                bool hasIncoming = false;
                bool hasOutgoing = false;
                foreach (OOSGStateTransition transition in model.STT)
                {
                    //incoming transition
                    if (transition.CurrentState == null ||
                        transition.NextState == null)
                        continue;

                    if (!transition.CurrentState.Name.Equals(state.Name) &&
                        transition.NextState.Name.Equals(state.Name))
                    {
                        hasIncoming = true;
                    }
                    //outgoing transition
                    if (transition.CurrentState.Name.Equals(state.Name) &&
                        transition.NextState != null &&
                        !string.IsNullOrEmpty(transition.NextState.Name))
                    {
                        hasOutgoing = true;
                    }
                }

                if (!hasIncoming && !hasOutgoing)
                {
                    hasDanglingState = true;
                    targetName = state.Name;
                    targetAtomicModel = model.Name;
                    break;
                }
            }

            if (hasDanglingState)
            {
                string desc = "The state <" + targetName + "> in the state object model <" + targetAtomicModel + "> is connected among other states.";

                CheckPointMessage msg = new CheckPointMessage(CheckPointType.Warning, desc, targetAtomicModel, modelName);
                rslt.Add(msg);
            }

            //not used message
            foreach (OOSGMessage msg in model.Messages)
            {
                bool isUsedInAtomicModels = false;
                foreach (OOSGStateTransition transition in model.STT)
                {
                    //input 
                    if (transition.InputOrDelay.Contains(msg.MName))
                    {
                        isUsedInAtomicModels = true;
                        break;
                    }

                    //output
                    if (transition.EntryAction.Contains(msg.MName) ||
                        transition.InputAction.Contains(msg.MName) ||
                        transition.TransitionAction.Contains(msg.MName))
                    {
                        isUsedInAtomicModels = true;
                        break;
                    }
                }

                if (!isUsedInAtomicModels)
                {
                    targetName = msg.MName;

                    string desc = "The defined message <" + targetName + "> is not used. Check the message correctly defined.";
                    CheckPointMessage cpMsg = new CheckPointMessage(CheckPointType.Warning, desc, model.Name, modelName);
                    rslt.Add(cpMsg);
                }
            }


            foreach (OOSGStateTransition st in model.STT)
            {
                if (!string.IsNullOrEmpty(st.TransitionAction))
                {
                    string[] tas = st.TransitionAction.Replace(" ", "").Replace("\r\n", "").Split(',', ';'); //공백 제거
                    foreach (string ta in tas)
                    {
                        if (ta.Contains('!') && ta.Contains('(') && ta.Contains(')'))
                        {
                            string nta = ta.Replace("!", "").Replace("(", "").Replace(")", "");

                            if (nta != null)
                            {
                                if (nta.Equals(string.Empty))
                                    continue;
                                if (model.FindMessage(nta) == null)
                                {
                                    string desc = "Message used in transisiton action<" + nta + "> in the state object model <" + model.Name + "> is not defined in message definition.";
                                    CheckPointMessage msgs = new CheckPointMessage(CheckPointType.Error, desc, model.Name, modelName);
                                    rslt.Add(msgs);
                                }
                            }
                        }
                    }
                }
            }

            foreach (OOSGStateTransition st in model.STT)
            {
                if (!string.IsNullOrEmpty(st.TransitionAction))
                {
                    string[] tas = st.TransitionAction.Replace(" ", "").Replace("\r\n", "").Split(',', ';'); //공백 제거
                    foreach (string ta in tas)
                    {
                        if (ta.Contains('!') && ta.Contains('(') && ta.Contains(')'))
                        {
                            string nta = ta.Replace("!", "").Replace("(", "").Replace(")", "");

                            OOSGMessage outmsg = model.FindMessage(nta);

                            if (outmsg != null)
                            {
                                if (outmsg.Equals(string.Empty))
                                    continue;
                                if (outmsg.Type != MessageType.Output)
                                {
                                    if (outmsg.Type == MessageType.Input)
                                    {
                                        string desc = "Message  <" + nta + ">used  in the state object model <" + model.Name + "> is defined as input type of message.";
                                        CheckPointMessage msgs = new CheckPointMessage(CheckPointType.Error, desc, model.Name, modelName);
                                        rslt.Add(msgs);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return rslt;
        }
    }
}
