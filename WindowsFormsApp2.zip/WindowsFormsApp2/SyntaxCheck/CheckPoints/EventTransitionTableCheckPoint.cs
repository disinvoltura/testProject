﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;

namespace DHKANG.SEA.UI.SyntaxCheck
{
    public class EventTransitionTableCheckPoint : ICheckPoint
    {
        public List<CheckPointMessage> Check(OOMMModel model)
        {
            List<CheckPointMessage> rslt = new List<CheckPointMessage>();

            foreach (OOEGEventObjectModel eoModel in model.EventObjectModels)
            {
                List<CheckPointMessage> eoMessages = new List<CheckPointMessage>();
                eoMessages = doCheck(model.Name, eoModel);
                if (eoMessages.Count > 0)
                    rslt.AddRange(eoMessages);
            }
            return rslt;
        }

        private List<CheckPointMessage> doCheck(string modelName, OOEGEventObjectModel model)
        {
            List<CheckPointMessage> rslt = new List<CheckPointMessage>();

            rslt.AddRange(checkInitialEvent(modelName, model));

            return rslt;
        }

        private List<CheckPointMessage> checkInitialEvent(string modelName, OOEGEventObjectModel model)
        {
            List<CheckPointMessage> rslt = new List<CheckPointMessage>();

            bool hasInitialEvent = false;
            foreach (OOEGEventTransition et in model.EventTransitions)
            {
                if (et.InitialEvent)
                {
                    hasInitialEvent = true; break;
                }
            }
            if (!hasInitialEvent)
            {
                CheckPointMessage msg = new CheckPointMessage(CheckPointType.Warning,
                                  "An event object model <" + model.Name + "> does not have an initial event, which may hinder the execution of a simulation run.", model.Name, modelName);
                msg.ScopeId = model.ID;
                rslt.Add(msg);
            }

            return rslt;
        }
    }
}
