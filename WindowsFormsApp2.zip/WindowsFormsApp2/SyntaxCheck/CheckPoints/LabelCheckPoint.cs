﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.Model;
using System.IO;
using DHKANG.SEA.Model.Data;
using DHKANG.SEA.Model.OID.Presentation;
using DHKANG.SEA.Model.OID;
using DHKANG.SEA.Model.ActivityObjects;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.StateObjects;

namespace DHKANG.SEA.UI.SyntaxCheck
{
    public class LabelCheckPoint : ICheckPoint
    {
        public List<CheckPointMessage> Check(OOMMModel model)
        {
            List<CheckPointMessage> rslt = new List<CheckPointMessage>();

            foreach (OOMMLabelNode label in model.ObjectInteractionDiagram.Labels)
            {
                if (label.ObjectID == null)
                {
                    CheckPointMessage msg = new CheckPointMessage(
                                                    CheckPointType.Error, "No object is associated with the label.", label.LabelName, "Label");
                    rslt.Add(msg);
                }
                else
                {
                    OOMMObjectNode objectNode = model.ObjectInteractionDiagram.FindObjectNode(label.ObjectID);
                    if (objectNode == null)
                    {
                        CheckPointMessage msg = new CheckPointMessage(
                                                    CheckPointType.Error, "The object node associated with the label does not exist.", label.LabelName, "Label");
                        rslt.Add(msg);
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(label.StateVariableName))
                        {
                            CheckPointMessage msg2 = new CheckPointMessage(
                                                        CheckPointType.Error, "The state variable is not assigned to the label.", label.LabelName, "Label");
                            rslt.Add(msg2);
                            continue;
                        }else if (objectNode.Type == ObjectNodeType.ActivityObject)
                        {
                            OOAGActivityObjectModel objectModel = model.FindActivityObjectModel(objectNode.ModelID);
                            if (objectModel == null)
                            {
                                CheckPointMessage msg3 = new CheckPointMessage(
                                                             CheckPointType.Error, "The object model associated with the label does not exist.", label.LabelName, "Label");
                                rslt.Add(msg3);
                            }
                            else
                            {
                                OOAGStateVariable sv = objectModel.FindStateVariable(label.StateVariableName);
                                if (sv == null)
                                {
                                    if (objectModel.FindQueue(label.StateVariableName) == null)
                                    {
                                        CheckPointMessage msg4 = new CheckPointMessage(
                                                                     CheckPointType.Error, "The state variable <" + label.StateVariableName + "> associated with the label does not exist.", label.LabelName, "Label");
                                        rslt.Add(msg4);
                                    }
                                }
                            }
                        }else if (objectNode.Type == ObjectNodeType.EventObject)
                        {
                            OOEGEventObjectModel objectModel = model.FindEventObjectModel(objectNode.ModelID);
                            if (objectModel == null)
                            {
                                CheckPointMessage msg3 = new CheckPointMessage(
                                                             CheckPointType.Error, "The object model associated with the label does not exist.", label.LabelName, "Label");
                                rslt.Add(msg3);
                            }
                            else
                            {
                                OOEGStateVariable sv = objectModel.GetStateVariable(label.StateVariableName);
                                if (sv == null)
                                {
                                    CheckPointMessage msg4 = new CheckPointMessage(
                                                                 CheckPointType.Error, "The state variable <" + label.StateVariableName + "> associated with the label does not exist.", label.LabelName, "Label");
                                    rslt.Add(msg4);
                                }
                            }
                        }
                        else if (objectNode.Type == ObjectNodeType.StateObject)
                        {
                            OOSGStateObjectModel objectModel = model.FindStateObjectModel(objectNode.ModelID);
                            if (objectModel == null)
                            {
                                CheckPointMessage msg3 = new CheckPointMessage(
                                                             CheckPointType.Error, "The object model associated with the label does not exist.", label.LabelName, "Label");
                                rslt.Add(msg3);
                            }
                            else
                            {
                                OOSGStateVariable sv = objectModel.FindStateVariable(label.StateVariableName);
                                if (sv == null)
                                {
                                    CheckPointMessage msg4 = new CheckPointMessage(
                                                                 CheckPointType.Error, "The state variable <" + label.StateVariableName + "> associated with the label does not exist.", label.LabelName, "Label");
                                    rslt.Add(msg4);
                                }
                            }
                        }
                    }
                }
            }

            return rslt;
        }
    }
}
