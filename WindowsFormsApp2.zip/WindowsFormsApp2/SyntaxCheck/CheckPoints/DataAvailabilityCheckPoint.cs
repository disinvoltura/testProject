﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.Model;
using System.IO;
using DHKANG.SEA.Model.Data;

namespace DHKANG.SEA.UI.SyntaxCheck
{
    public class DataAvailabilityCheckPoint : ICheckPoint
    {
        public List<CheckPointMessage> Check(OOMMModel model)
        {
            List<CheckPointMessage> rslt = new List<CheckPointMessage>();

            foreach(OOMMDataSource ds in model.DataSources)
            {
                if (ds.Type == OOMMDataSourceType.CSV ||
                    ds.Type == OOMMDataSourceType.EXCEL)
                {
                    if (!File.Exists(ds.FileName))
                    {
                        CheckPointMessage msg = new CheckPointMessage(CheckPointType.Error, "No file cannot be found in the corresponding path for the data source", ds.Name, "Data Source");
                        msg.ScopeId = ds.ID;
                        rslt.Add(msg);
                    }
                }
            }

            return rslt;
        }
    }
}
