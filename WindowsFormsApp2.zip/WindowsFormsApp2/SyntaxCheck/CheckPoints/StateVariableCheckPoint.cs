﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model.ActivityObjects;
using DHKANG.Foundation.RandomVariate;

namespace DHKANG.SEA.UI.SyntaxCheck
{
    public class StateVariableCheckPoint : ICheckPoint
    {
        public List<CheckPointMessage> Check(OOMMModel model)
        {
            List<CheckPointMessage> rslt = new List<CheckPointMessage>();

            foreach (OOSGStateObjectModel eoModel in model.StateObjectModels)
            {
                List<CheckPointMessage> eoMessages = new List<CheckPointMessage>();
                eoMessages = doCheck(model.Name, eoModel);
                if (eoMessages.Count > 0)
                    rslt.AddRange(eoMessages);
            }

            foreach (OOEGEventObjectModel eoModel in model.EventObjectModels)
            {
                List<CheckPointMessage> eoMessages = new List<CheckPointMessage>();
                eoMessages = doCheck(model.Name, eoModel);
                if (eoMessages.Count > 0)
                    rslt.AddRange(eoMessages);
            }

            foreach (OOAGActivityObjectModel eoModel in model.ActivityObjectModels)
            {
                List<CheckPointMessage> eoMessages = new List<CheckPointMessage>();
                eoMessages = doCheck(model.Name, eoModel);
                if (eoMessages.Count > 0)
                    rslt.AddRange(eoMessages);
            }
            return rslt;
        }

        private List<CheckPointMessage> doCheck(string modelName, OOAGActivityObjectModel model)
        {
            List<CheckPointMessage> rslt = new List<CheckPointMessage>();

            foreach(OOAGStateVariable sv in model.StateVariables)
            {
                if (sv.ValueType.Equals(OOMMStateVariableHelper.RANDOMVARIATE)){
                    if (string.IsNullOrEmpty(sv.InitialValue))
                    {
                        CheckPointMessage msg = new CheckPointMessage(CheckPointType.Warning,
                                                    "A state variable <" + sv.Name + ">, which is a type of Random Variate, does not specify a valid distribution", model.Name, modelName);
                        msg.ScopeId = model.ID;
                        rslt.Add(msg);
                    }

                    if (!RandomVariateGenerator.IsValid(sv.InitialValue))
                    {
                        CheckPointMessage msg = new CheckPointMessage(CheckPointType.Warning,
                                                    "Check the expression of a Random Variate type state variable <" + sv.Name + ">, which is not a valid for the probability distribution", model.Name, modelName);
                        msg.ScopeId = model.ID;
                        rslt.Add(msg);
                    }
                }
            }

            return rslt;
        }

        private List<CheckPointMessage> doCheck(string modelName, OOEGEventObjectModel model)
        {
            List<CheckPointMessage> rslt = new List<CheckPointMessage>();

            foreach (OOEGStateVariable sv in model.StateVariables)
            {
                if (sv.ValueType.Equals(OOMMStateVariableHelper.RANDOMVARIATE)){
                    if (string.IsNullOrEmpty(sv.InitialValue))
                    {
                        CheckPointMessage msg = new CheckPointMessage(CheckPointType.Warning,
                                                    "A state variable <" + sv.Name + ">, which is a type of Random Variate, does not specify a valid distribution", model.Name, modelName);
                        msg.ScopeId = model.ID;
                        rslt.Add(msg);
                    }

                    if (!RandomVariateGenerator.IsValid(sv.InitialValue))
                    {
                        CheckPointMessage msg = new CheckPointMessage(CheckPointType.Warning,
                                                    "Check the expression of a Random Variate type state variable <" + sv.Name + ">, which is not a valid for the probability distribution", model.Name, modelName);
                        msg.ScopeId = model.ID;
                        rslt.Add(msg);
                    }
                }
            }

            return rslt;
        }

        private List<CheckPointMessage> doCheck(string modelName, OOSGStateObjectModel model)
        {
            List<CheckPointMessage> rslt = new List<CheckPointMessage>();

            foreach (OOSGStateVariable sv in model.StateVariables)
            {
                if (sv.Type.Equals(OOMMStateVariableHelper.RANDOMVARIATE)){
                    if (string.IsNullOrEmpty(sv.InitialValue.ToString()))
                    {
                        CheckPointMessage msg = new CheckPointMessage(CheckPointType.Warning,
                                                    "A state variable <" + sv.Name + ">, which is a type of Random Variate, does not specify a valid distribution", model.Name, modelName);
                        msg.ScopeId = model.ID;
                        rslt.Add(msg);
                    }

                    if (!RandomVariateGenerator.IsValid(sv.InitialValue.ToString()))
                    {
                        CheckPointMessage msg = new CheckPointMessage(CheckPointType.Warning,
                                                    "Check the expression of a Random Variate type state variable <" + sv.Name + ">, which is not a valid for the probability distribution", model.Name, modelName);
                        msg.ScopeId = model.ID;
                        rslt.Add(msg);
                    }
                }
            }

            return rslt;
        }
    }
}
