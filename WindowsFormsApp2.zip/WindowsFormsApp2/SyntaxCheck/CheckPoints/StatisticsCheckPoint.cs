﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.Model;
using System.IO;
using DHKANG.SEA.Model.Data;
using DHKANG.SEA.Model.OID.Presentation;
using DHKANG.SEA.Model.OID;
using DHKANG.SEA.Model.ActivityObjects;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model.OID.Data;

namespace DHKANG.SEA.UI.SyntaxCheck
{
    public class StatisticsCheckPoint : ICheckPoint
    {
        private OOMMModel _Model;
        private string TARGET_TYPE = "Statistics";
        public List<CheckPointMessage> Check(OOMMModel model)
        {
            _Model = model;
            List<CheckPointMessage> rslt = new List<CheckPointMessage>();

            foreach (OOMMStatisticsNode node in model.ObjectInteractionDiagram.StatisticsNodes)
            {
                rslt.AddRange(checkAxisValue(node.NodeID, node.StatisticsName, "source", node.Source));
            }

            return rslt;
        }

        private List<CheckPointMessage> checkAxisValue(Guid nodeID, string datasetName, string type, string axisValue)
        {
            List<CheckPointMessage> rslt = new List<CheckPointMessage>();

            string[] stra = axisValue.Split(new string[] { "." }, StringSplitOptions.RemoveEmptyEntries);
            if (stra.Length == 0)
            {
                CheckPointMessage msg = new CheckPointMessage(
                                CheckPointType.Error, type + " is not valid.", datasetName, TARGET_TYPE);
                msg.ScopeId = nodeID;
                rslt.Add(msg);
            }else
            {
                string objectName = stra[0];
                string svName = stra[1];
                int arrayIndex = svName.IndexOf('[');
                if (arrayIndex > 0)
                {
                    svName = svName.Substring(0, arrayIndex);
                }

                OOMMObjectNode objectNode = _Model.ObjectInteractionDiagram.FindObjectNode(objectName);
                if (objectNode == null)
                {
                    CheckPointMessage msg = new CheckPointMessage(
                                                CheckPointType.Error, "The object node associated with the Statistics does not exist in the " + type + ".", datasetName, TARGET_TYPE);
                    msg.ScopeId = nodeID;
                    rslt.Add(msg);
                }
                else
                {
                    if (string.IsNullOrEmpty(svName))
                    {
                        CheckPointMessage msg2 = new CheckPointMessage(
                                                    CheckPointType.Error, "The state variable is not assigned to the " + type + " of the Statistics.", datasetName, TARGET_TYPE);
                        msg2.ScopeId = nodeID;
                        rslt.Add(msg2);
                    }else if (objectNode.Type == ObjectNodeType.ActivityObject)
                    {
                        OOAGActivityObjectModel objectModel = _Model.FindActivityObjectModel(objectNode.ModelID);
                        if (objectModel == null)
                        {
                            CheckPointMessage msg3 = new CheckPointMessage(
                                                         CheckPointType.Error, "The object model associated with the " + type + " of the Statistics does not exist.", datasetName, TARGET_TYPE);
                            msg3.ScopeId = nodeID;
                            rslt.Add(msg3);
                        }
                        else
                        {
                            OOAGStateVariable sv = objectModel.FindStateVariable(svName);
                            if (sv == null)
                            {
                                CheckPointMessage msg4 = new CheckPointMessage(
                                                             CheckPointType.Error, "The state variable <" + svName + "> associated with the " + type + " of the Statistics does not exist.", datasetName, TARGET_TYPE);
                                msg4.ScopeId = nodeID;
                                rslt.Add(msg4);
                            }
                        }
                    }
                    else if (objectNode.Type == ObjectNodeType.EventObject)
                    {
                        OOEGEventObjectModel objectModel = _Model.FindEventObjectModel(objectNode.ModelID);
                        if (objectModel == null)
                        {
                            CheckPointMessage msg3 = new CheckPointMessage(
                                                         CheckPointType.Error, "The object model associated with the " + type + " of the Statistics does not exist.", datasetName, TARGET_TYPE);
                            msg3.ScopeId = nodeID;
                            rslt.Add(msg3);
                        }
                        else
                        {
                            OOEGStateVariable sv = objectModel.GetStateVariable(svName);
                            if (sv == null)
                            {
                                CheckPointMessage msg4 = new CheckPointMessage(
                                                             CheckPointType.Error, "The state variable <" + svName+ "> associated with the " + type + " of the Statistics does not exist.", datasetName, TARGET_TYPE);
                                msg4.ScopeId = nodeID;
                                rslt.Add(msg4);
                            }
                        }
                    }
                    else if (objectNode.Type == ObjectNodeType.StateObject)
                    {
                        OOSGStateObjectModel objectModel = _Model.FindStateObjectModel(objectNode.ModelID);
                        if (objectModel == null)
                        {
                            CheckPointMessage msg3 = new CheckPointMessage(
                                                         CheckPointType.Error, "The object model associated with the " + type + " of the Statistics does not exist.", datasetName, TARGET_TYPE);
                            msg3.ScopeId = nodeID;
                            rslt.Add(msg3);
                        }
                        else
                        {
                            OOSGStateVariable sv = objectModel.FindStateVariable(svName);
                            if (sv == null)
                            {
                                CheckPointMessage msg4 = new CheckPointMessage(
                                                             CheckPointType.Error, "The state variable <" + svName + "> associated with the " + type + " of the Statistics does not exist.", datasetName, TARGET_TYPE);
                                msg4.ScopeId = nodeID;
                                rslt.Add(msg4);
                            }
                        }
                    }
                }
            }
            return rslt;
        }
    }
}
