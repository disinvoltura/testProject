﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DHKANG.SEA.UI.SyntaxCheck
{
    public enum CheckPointType { Warning, Error };

    public class CheckPointMessage
    {
        #region Member Variables
        private CheckPointType _Type;
        private string _Description;
        private string _Target;//Specific target name
        private string _Scope = string.Empty; //Atomic Model/Coupled Model
        private object _UserData;
        private Guid _ScopeId;
        private CompilerError _CompError;
        //scope, target?
        #endregion

        #region Properties
        public CheckPointType Type { get { return _Type; } }
        public string Description { get { return _Description; } }
        public string Target { get { return _Target; } }
        public string Scope { get { return _Scope; } }
        public object UserData { get { return _UserData; } set { _UserData = value; } }
        public Guid ScopeId { get { return _ScopeId; }set { _ScopeId = value; } }
        public CompilerError CompileError { get { return _CompError; } set { _CompError = value; } }
        #endregion

        #region Constructors
        public CheckPointMessage(CheckPointType type, string description, string target)
        {
            _Target = target;
            _Type = type;
            _Description = description;
        }

        public CheckPointMessage(CheckPointType type, string description, string target, string scope)
        {
            _Target = target;
            _Type = type;
            _Description = description;
            _Scope = scope;
        }
        #endregion
    }
}
