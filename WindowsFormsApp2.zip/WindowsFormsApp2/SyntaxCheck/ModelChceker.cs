﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;
using WindowsFormsApp2;

namespace DHKANG.SEA.UI.SyntaxCheck
{
    public class ModelChecker
    {
        #region Member Variables
        private List<ICheckPoint> _CheckPoints;
        private DataTable _DTError;

        private List<CheckPointMessage> _ErrorList;
        #endregion

        #region Properties
        //public DataTable Errors { get { return _DTError; } }
        public List<CheckPointMessage> Errors {  get { return _ErrorList; } }
        #endregion

        #region Constructors
        public ModelChecker()
        {
            initialize();
        }

        
        private void initialize()
        {
            _CheckPoints = new List<ICheckPoint>();
            //_CheckPoints.Add(new ObjectSchedulingRelationCheckPoint());
            //_CheckPoints.Add(new EventTransitionTableCheckPoint());
            //_CheckPoints.Add(new DataAvailabilityCheckPoint());
            //_CheckPoints.Add(new LabelCheckPoint());
            //_CheckPoints.Add(new DataSetCheckPoint());
            //_CheckPoints.Add(new StatisticsCheckPoint());
            //_CheckPoints.Add(new ChartCheckPoint());
            //_CheckPoints.Add(new StateVariableCheckPoint());
        }

        #endregion

        #region Method
        public bool Check(Model model)
        {
            bool rslt = false;
            _ErrorList = new List<CheckPointMessage>();

            foreach (ICheckPoint cp in _CheckPoints)
            {
                _ErrorList.AddRange(cp.Check(model));
            }

            ModelChecker dmc = new ModelChecker();
            _ErrorList.AddRange(dmc.Check(model));

            if (_ErrorList.Find(e => e.Type == CheckPointType.Error) != null)
                rslt = true;

            return rslt;
        }

        /*
        public bool Check(OOMMModel model)
        {
            bool rslt = false;
            _DTError.Rows.Clear();

            foreach (ICheckPoint cp in _CheckPoints)
            {
                List<CheckPointMessage> msglist = cp.Check(model);
                if (msglist.Count > 0)
                {
                    foreach (CheckPointMessage msg in msglist)
                    {
                        _DTError.Rows.Add(new string[] { msg.Type.ToString(), msg.Description, msg.Target, msg.Scope });
                        if (msg.Type == CheckPointType.Error)
                            rslt = true;
                    }
                }
            }

            DynamicModelChecker dmc = new DynamicModelChecker();
            List<CheckPointMessage> msgList = dmc.Check(model);
            string lastDesc = string.Empty;
            foreach (CheckPointMessage msg in msgList)
            {
                if (lastDesc.Equals(msg.Description))
                    continue;
                DataRow row = _DTError.Rows.Add(new string[] { msg.Type.ToString(), msg.Description, msg.Target, msg.Scope });
                //msg.UserData: CompilerError
                if (msg.Type == CheckPointType.Error)
                    rslt = true;
                lastDesc = msg.Description;
            }
            return rslt;
        }
        */
        #endregion
    }
}
