﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace WindowsFormsApp2
{
    public delegate void ObjectSelectedEventHandler(Model model, Object obj);

    public partial class ModelExplorerWindow : DockContent
    {
        #region Member Variables
        private Dictionary<Guid, TreeNode> _ProjectNodes; //Key: project name 
        private Dictionary<Guid, TreeNode> _ExperimentNodes;
        private Dictionary<Guid, bool> _IsChanged; //key: guid

        private MainUI _Parent;
        #endregion

        #region Events
        public event ObjectSelectedEventHandler ObjectSelected;
        #endregion

        #region Properties
        public List<Model> Projects
        {
            get
            {
                List<Model> rslt = new List<Model>();

                foreach (Guid projectid in _ProjectNodes.Keys)
                {
                    Model model = GetProject(projectid);
                    rslt.Add(model);
                }

                return rslt;
            }
        }
        #endregion

        #region Constructors
        public ModelExplorerWindow(MainUI parent)
        {
            _Parent = parent;
            _ProjectNodes = new Dictionary<Guid, TreeNode>();
            //_ExperimentNodes = new Dictionary<Guid, TreeNode>();
            _IsChanged = new Dictionary<Guid, bool>();

            InitializeComponent();
            initializeImageList();
            initializeNodeList();
        }
        #endregion

        #region Methods
        private void initializeImageList()
        {
            imageList1.Images.Clear();

            List<string> images = new List<string>();
            images.AddRange(new string[] {
                                ImageManager.IMAGE_DATA_OBJECT,
                                ImageManager.IMAGE_DATA_OBJECT_CSV,
                                ImageManager.IMAGE_DATA_OBJECT_EXCEL,
                                ImageManager.IMAGE_DATA_OBJECT_DB,
                                ImageManager.IMAGE_DATA_LIST,
                                ImageManager.IMAGE_ACTIVITY_OBJECT,
                                ImageManager.IMAGE_EVENT_OBJECT,
                                ImageManager.IMAGE_STATE_OBJECT,
                                ImageManager.IMAGE_ACTIVITY_NODE,
                                ImageManager.IMAGE_EVENT_NODE,
                                ImageManager.IMAGE_STATE_NODE,
                                ImageManager.IMAGE_STATEVARIABLE,
                                ImageManager.IMAGE_OBJECT_MODEL_LIST,
                                ImageManager.IMAGE_ACTIVITY_NODE_LIST,
                                ImageManager.IMAGE_QUEUE_NODE_LIST,
                                ImageManager.IMAGE_EVENT_NODE_LIST,
                                ImageManager.IMAGE_STATE_NODE_LIST,
                                ImageManager.IMAGE_STATEVARIABLE_LIST,
                                ImageManager.IMAGE_EXPERIMENT_LIST,
                                ImageManager.IMAGE_ENTITY,
                                ImageManager.IMAGE_ENTITY_LIST,
                                ImageManager.IMAGE_PROJECT,
                                ImageManager.IMAGE_SIMULATION_EXPERIMENT,
                                ImageManager.IMAGE_OUTPUTVIEW,
                                ImageManager.IMAGE_SIMULATION_OPTIMIZATION,
                                ImageManager.IMAGE_WHATIF_ANALYSIS,
                                ImageManager.IMAGE_SELECTED_NODE });

            foreach (string key in images)
            {
                Image image = ImageManager.find(key);
                if (image != null)
                    imageList1.Images.Add(key, image);
            }

            tvModel.SelectedImageKey = ImageManager.IMAGE_SELECTED_NODE;
        }

        private void initializeNodeList()
        {
            tvModel.Nodes.Clear();
        }

        public Model GetProject(string projectName)
        {
            TreeNode projectNode = null;
            foreach (TreeNode node in _ProjectNodes.Values)
            {
                if (node.Text.Equals(projectName))
                {
                    projectNode = node;
                    break;
                }
            }
            Model model = null;
            if (projectNode.Tag != null && projectNode.Tag is Model)
            {
                model = (Model)projectNode.Tag;

                //if (_Parent.DiagramWindows.ContainsKey(model.ID))
                //{
                //    OOMMDiagramWindow diagramWindow = _Parent.DiagramWindows[model.ID];
                //    OOMMObjectInteractionDiagram diagram = diagramWindow.ObjectInteractionDiagram;
                //    model.ObjectInteractionDiagram = diagram;

                //    model.SetProperty(OOMMObjectInteractionDiagram.ZOOM_SCALE, diagramWindow.ViewScale);
                //    model.SetProperty(OOMMObjectInteractionDiagram.GRID_VISIBILITY, diagramWindow.IsGridShown);
                //}

                //Experiments
                List<OOMMExperiment> experiments = GetExperiments(model.ID);
                model.Experiments = experiments;
            }

            return model;
        }

        public Model GetProject(Guid projectid)
        {
            TreeNode projectNode = _ProjectNodes[projectid];
            Model model = null;
            if (projectNode.Tag != null && projectNode.Tag is Model)
            {
                model = (Model)projectNode.Tag;

                //if (_Parent.DiagramWindows.ContainsKey(model.ID))
                //{
                //    OOMMDiagramWindow diagramWindow = _Parent.DiagramWindows[model.ID];
                //    OOMMObjectInteractionDiagram diagram = diagramWindow.ObjectInteractionDiagram;
                //    model.ObjectInteractionDiagram = diagram;

                //    model.SetProperty(OOMMObjectInteractionDiagram.ZOOM_SCALE, diagramWindow.ViewScale);
                //    model.SetProperty(OOMMObjectInteractionDiagram.GRID_VISIBILITY, diagramWindow.IsGridShown);
                //}

                ////Event Object Model
                //List<DHKANG.SEA.Model.EventObjects.OOEGEventObjectModel> eventObjects = GetEventObjects(projectid);
                //model.EventObjectModels = eventObjects;

                ////State Object models
                //List<OOSGStateObjectModel> stateObject = GetStateObjects(projectid);
                //model.StateObjectModels = stateObject;

                ////Activity Object Models
                //List<OOAGActivityObjectModel> activityObjects = GetActivityObjects(projectid);
                //model.ActivityObjectModels = activityObjects;
                ////Entities
                //List<OOMMEntity> entities = Modeling.EntityManager.GetEntities(projectid);
                //model.Entities = entities;

                ////Data Sources
                //List<OOMMDataSource> dataSources = GetDataSources(projectid);
                //model.DataSources = dataSources;

                ////Experiments
                //List<OOMMExperiment> experiments = GetExperiments(projectid);
                //model.Experiments = experiments;
            }

            return model;
        }

        public List<OOMMExperiment> GetExperiments(Guid projectid)
        {
            List<OOMMExperiment> rslt = new List<OOMMExperiment>();

            TreeNode expNode = _ExperimentNodes[projectid];
            if (expNode != null)
            {
                foreach (TreeNode node in expNode.Nodes)
                {
                    OOMMExperiment exp = (OOMMExperiment)node.Tag;
                    rslt.Add(exp);
                }
            }
            return rslt;
        }

        public Guid CurrentProject
        {
            get
            {
                Guid rslt = Guid.Empty;
                TreeNode projectNode = getCurrentProjectNode();
                if (projectNode != null)
                    rslt = ((Model)projectNode.Tag).ID;
                return rslt;
            }
        }

        public TreeNode getCurrentProjectNode()
        {
            TreeNode project = null;
            if (tvModel.SelectedNode != null)
            {
                TreeNode node = tvModel.SelectedNode;

                while (node.Level > 0)
                {
                    node = node.Parent;
                }

                project = node;
            }
            return project;
        }
        #endregion

        private void dataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addNewDataSource();

        }

        private void addNewDataSource()
        {
            NewDataDialog dialog = new NewDataDialog();
            DialogResult rslt = dialog.ShowDialog(this);

            if (rslt == DialogResult.OK)
            {
                OOMMModel model = getCurrentProjectModel();
                TreeNode dataNode = _DataNodes[model.ID];

                if (dialog.DataType == NewDataDialog.DATATYPE_CSV)
                {
                    OOMMDataSource ds = new OOMMDataSource(dialog.DataName, OOMMDataSourceType.CSV, dialog.FileName);
                    addDataSource(dataNode, ds);
                }
                else if (dialog.DataType == NewDataDialog.DATATYPE_EXCEL)
                {
                    OOMMDataSource ds = new OOMMDataSource(dialog.DataName, OOMMDataSourceType.EXCEL, dialog.FileName, dialog.Sheets);
                    addDataSource(dataNode, ds);
                }
                else if (dialog.DataType == NewDataDialog.DATATYPE_DB)
                {
                    OOMMDataSource ds = new OOMMDataSource(dialog.DataName, OOMMDataSourceType.DATABASE, dialog.DatabaseType, dialog.ConnectionString, dialog.Query);
                    addDataSource(dataNode, ds);
                }

                //if (!dataNode.IsExpanded)
                //    dataNode.Expand();

                SetChanged(model.ID, true);
            }
        }

        private void addDataSource(TreeNode dataNode, OOMMDataSource ds)
        {
            TreeNode node = new TreeNode(ds.Name);

            if (ds.Type == OOMMDataSourceType.CSV)
                node.ImageKey = ImageManager.IMAGE_DATA_OBJECT_CSV;
            else if (ds.Type == OOMMDataSourceType.EXCEL)
                node.ImageKey = ImageManager.IMAGE_DATA_OBJECT_EXCEL;
            else if (ds.Type == OOMMDataSourceType.DATABASE)
                node.ImageKey = ImageManager.IMAGE_DATA_OBJECT_DB;
            node.Tag = ds;

            if (dataNode.Nodes.Count == 0)
            {
                dataNode.Nodes.Add(node);
            }
            else
            {
                bool inserted = false;
                for (int i = 0; i < dataNode.Nodes.Count; i++)
                {
                    if (ds.Name.CompareTo(dataNode.Nodes[i].Name) < 0)
                    {
                        dataNode.Nodes.Insert(i, node);
                        inserted = true;
                        break;
                    }
                }
                if (!inserted)
                    dataNode.Nodes.Add(node);
            }

        }

        public void Update(OOMMModel model)
        {
            isUpdating = true;
            //initializeNodeList();
            TreeNode projectNode = null;

            bool isNewlyOpend = false;
            if (_ProjectNodes.ContainsKey(model.ID))
            {
                projectNode = _ProjectNodes[model.ID];
            }
            else
            {
                isNewlyOpend = true;
                projectNode = new TreeNode(model.Name);
                projectNode.ImageKey = ImageManager.IMAGE_PROJECT;
                projectNode.Tag = model;
                tvModel.Nodes.Add(projectNode);
                _ProjectNodes.Add(model.ID, projectNode);

                tvModel.SelectedNode = projectNode;
            }

            TreeNode objectModelsNode = UpdateObjectModels(projectNode, model);
            TreeNode entityNode = Update(projectNode, model.Entities);
            TreeNode dsNode = Update(projectNode, model.DataSources);
            TreeNode classNode = Update(projectNode, model.UserClasses);
            TreeNode expNode = Update(projectNode, model.Experiments);

            if (_IsChanged.ContainsKey(model.ID))
                _IsChanged[model.ID] = false;
            else
                _IsChanged.Add(model.ID, false);

            if (isNewlyOpend)
            {
                projectNode.Expand();
                objectModelsNode.Expand();
                entityNode.Expand();
                dsNode.Expand();
                expNode.Expand();
            }

            isUpdating = false;
        }

        private void tsbRefresh_Click(object sender, EventArgs e)
        {
            List<OOMMModel> projects = this.Projects;

            foreach (OOMMModel proj in projects)
                this.Update(proj);
        }

        private void tsbExpandAll_Click(object sender, EventArgs e)
        {
            tvModel.ExpandAll();

        }

        private void tsbCollapseAll_Click(object sender, EventArgs e)
        {
            tvModel.CollapseAll();

        }
    }
}
