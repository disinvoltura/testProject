﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace WindowsFormsApp2
{
    public static class FileOperation
    {
        private static Dictionary<Guid, string> _FileNames;

        static FileOperation()
        {
            _FileNames = new Dictionary<Guid, string>();
        }

        public static void Save(Model model, string fileName)
        {
            model.FileName = fileName;

            XmlSerializer serializer = new XmlSerializer(typeof(Model));
            using (TextWriter writer = new StreamWriter(fileName))
            {
                serializer.Serialize(writer, model);
            }

            MainUI.App.ModelExplorer.SetChanged(model.ID, false);

            ActionManager.Act("Model Explorer", "Project <" + model.Name + "> is saved successfully.");
        }

        public static void Save(Model model)
        {
            if (_FileNames.ContainsKey(model.ID))
            {
                Save(model, _FileNames[model.ID]);
                //MainUI.App.ErrorWindow.CheckSyntax(model);
            }
            else
            {
                SaveFileDialog sfd = new SaveFileDialog();
                sfd.Filter = "OOMM model files (*.xml)|*.xml|All files (*.*)|*.*";
                sfd.DefaultExt = "xml";

                sfd.FileName = model.Name.Replace("*", "") + ".xml";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    string loc = sfd.FileName;
                    //_Parent.ModelExplorer.Save(model, loc);
                    Save(model, loc);
                }
            }
        }

        public static void SaveAs(Model model)
        {
            string fileName = "";
            if (_FileNames.ContainsKey(model.ID))
                fileName = _FileNames[model.ID];

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "OOMM model files (*.xml)|*.xml|All files (*.*)|*.*";
            sfd.DefaultExt = "xml";

            if (string.IsNullOrEmpty(fileName))
                sfd.FileName = model.Name.Replace("*", "") + ".xml";
            else
                sfd.FileName = fileName;

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string loc = sfd.FileName;
                FileOperation.Save(model, loc);

                //MainUI.App.ErrorWindow.CheckSyntax(model);
                if (_FileNames.ContainsKey(model.ID))
                    _FileNames[model.ID] = loc;
                else
                    _FileNames.Add(model.ID, loc);
            }
        }

        public static void Close(Model model)
        {
            if (_FileNames.ContainsKey(model.ID))
                _FileNames.Remove(model.ID);
        }

        public static void OpenOOMMModelEditor(string fileName)
        {
            if (MainUI.App.ModelExplorer != null)
            {
                Model model = null;
                model = ModelFactory.Open(fileName);
                if (model == null)
                {
                    MessageBox.Show(MainUI.App, "Cannot read the model from the file", "Error");
                    return;
                }
                model.FileName = fileName;

                int rslt = 0; //0: not opened, 1: opened with the same Guid but different name, 2: opened with the same Guid and name.
                rslt = MainUI.App.ModelExplorer.IsModelOpened(model);
                if (rslt == 2)
                {
                    return;
                }
                else if (rslt == 1)
                {
                    model.ID = Guid.NewGuid();
                    model.FileName = fileName;

                    XmlSerializer serializer = new XmlSerializer(typeof(Model));
                    using (TextWriter writer = new StreamWriter(fileName))
                    {
                        serializer.Serialize(writer, model);
                    }
                }

                //MainUI.App.OpenDiagramEditor(model);
                //MainUI.App.ErrorWindow.CheckSyntax(model);
                //MainUI.App.ModelExplorer.Update(model);
                //Modeling.EntityManager.SetEntities(model.ID, model.Entities);

                if (!_FileNames.ContainsKey(model.ID))
                    _FileNames.Add(model.ID, fileName);
            }

            //if (MainUI.App.ModelExplorer.Projects.Count == 1)
            //    MainUI.App.ableMenu(true);
        }
    }
}
