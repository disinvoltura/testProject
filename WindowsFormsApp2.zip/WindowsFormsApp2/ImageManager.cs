﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    public static class ImageManager
    {
        public readonly static string IMAGE_OBJECT_MODEL_LIST = "EventCoupledModel";

        public readonly static string IMAGE_EVENT_OBJECT = "EventObject";
        public readonly static string IMAGE_STATE_OBJECT = "StateObject";
        public readonly static string IMAGE_ACTIVITY_OBJECT = "ActivityObject";

        public readonly static string IMAGE_EVENT_NODE = "EventNode";
        public readonly static string IMAGE_EVENT_NODE_LIST = "EventNodeList";

        public readonly static string IMAGE_STATE_NODE = "StateNode";
        public readonly static string IMAGE_STATE_NODE_LIST = "StateNodeList";

        public readonly static string IMAGE_ACTIVITY_NODE = "ActivityNode";
        public readonly static string IMAGE_ACTIVITY_NODE_LIST = "ActivityNodeList";
        public readonly static string IMAGE_QUEUE_NODE = "QueueNode";
        public readonly static string IMAGE_QUEUE_NODE_LIST = "QueueNodeList";

        public readonly static string IMAGE_DATA_LIST = "DataModel";
        public readonly static string IMAGE_USER_CLASS = "UserClass";
        public readonly static string IMAGE_USER_CLASS_LIST = "UserClassList";
        public readonly static string IMAGE_DATA_OBJECT = "DataObject";
        public readonly static string IMAGE_DATA_OBJECT_CSV = "DataObject_CSV";
        public readonly static string IMAGE_DATA_OBJECT_EXCEL = "DataObject_EXCEL";
        public readonly static string IMAGE_DATA_OBJECT_DB = "DataObject_DB";
        public readonly static string IMAGE_STATEVARIABLE = "StateVariable";
        public readonly static string IMAGE_STATEVARIABLE_LIST = "StateVariableList";
        public readonly static string IMAGE_OUTPUTVIEW = "OutputView";
        public readonly static string IMAGE_EXPERIMENT = "Experiment";
        public readonly static string IMAGE_SIMULATION_EXPERIMENT = "SimulationExperiment";
        public readonly static string IMAGE_WHATIF_ANALYSIS = "WhatIfAnalysis";
        public readonly static string IMAGE_SIMULATION_OPTIMIZATION = "SimulationOptimization";
        public readonly static string IMAGE_SELECTED_NODE = "selected";
        public readonly static string IMAGE_PROJECT = "Project";
        public readonly static string IMAGE_ENTITY_LIST = "EntityList";
        public readonly static string IMAGE_ENTITY = "Entity";
        public readonly static string IMAGE_EXPERIMENT_LIST = "ExperimentList";

        private static Dictionary<String, Image> _Images;

        private static void initialize()
        {
            _Images = new Dictionary<string, Image>();

            Dictionary<String, String> images = new Dictionary<string, string>();//key and url
            images.Add(IMAGE_OBJECT_MODEL_LIST, "coupledmodel.png");
            images.Add(IMAGE_STATEVARIABLE, "statevariable.png");

            images.Add(IMAGE_EVENT_OBJECT, "eventobject.png");
            images.Add(IMAGE_EVENT_NODE, "eventnode.png");

            images.Add(IMAGE_STATE_OBJECT, "stateobject.png");
            images.Add(IMAGE_STATE_NODE, "statenode.png");

            images.Add(IMAGE_ACTIVITY_OBJECT, "activityobject.png");
            images.Add(IMAGE_ACTIVITY_NODE, "activitynode.png");
            images.Add(IMAGE_QUEUE_NODE, "queuenode.png");

            images.Add(IMAGE_DATA_LIST, "datamodel.png");
            images.Add(IMAGE_DATA_OBJECT, "dataobject.png");
            images.Add(IMAGE_DATA_OBJECT_CSV, "dataobject_csv.png");
            images.Add(IMAGE_DATA_OBJECT_EXCEL, "dataobject_excel.png");
            images.Add(IMAGE_DATA_OBJECT_DB, "dataobject_db.png");

            images.Add(IMAGE_EVENT_NODE_LIST, "eventnodelist.png");
            images.Add(IMAGE_STATE_NODE_LIST, "eventnodelist.png");
            images.Add(IMAGE_ACTIVITY_NODE_LIST, "activitynodelist.png");
            images.Add(IMAGE_QUEUE_NODE_LIST, "queuenodelist.png");
            images.Add(IMAGE_STATEVARIABLE_LIST, "statevariablelist.png");
            images.Add(IMAGE_EXPERIMENT_LIST, "experiment.png");

            images.Add(IMAGE_PROJECT, "project.png");
            images.Add(IMAGE_EXPERIMENT, "experiment.png");
            images.Add(IMAGE_SIMULATION_EXPERIMENT, "experiment_simulation.png");
            images.Add(IMAGE_OUTPUTVIEW, "outputview.png");
            images.Add(IMAGE_SIMULATION_OPTIMIZATION, "experiment_optimization.png");
            images.Add(IMAGE_WHATIF_ANALYSIS, "experiment_whatif.png");
            images.Add(IMAGE_SELECTED_NODE, "selected.png");

            images.Add(IMAGE_ENTITY, "entity.png");
            images.Add(IMAGE_ENTITY_LIST, "entitylist.png");

            images.Add(IMAGE_USER_CLASS, "entity.png");
            images.Add(IMAGE_USER_CLASS_LIST, "entitylist.png");

            foreach (String key in images.Keys)
            {
                string path = "icons\\" + images[key];

                Image image = null;

                try
                {
                    image = Image.FromFile(path);
                }
                catch (Exception ex) { }

                if (image != null)
                {
                    //ImageInfo info = new ImageInfo(key, image);
                    _Images.Add(key, image);
                }
            }
        }

        public static Image find(string key)
        {
            if (_Images == null)
                initialize();

            Image rslt = null;

            if (_Images.ContainsKey(key))
                rslt = _Images[key];

            return rslt;
        }
    }

    public class ImageInfo
    {
        private string _ImageUrl;
        private string _ImageKey;
        private Image _Image;

        public string ImageUrl { get { return _ImageUrl; } }
        public string ImageKey { get { return _ImageKey; } }
        public Image Image { get { return _Image; } set { _Image = value; } }

        public ImageInfo(string key, string url)
        {
            _ImageUrl = url;
            _ImageKey = key;
        }

        public ImageInfo(string key, Image image)
        {
            _ImageKey = key;
            _Image = image;
        }

        public ImageInfo(string key, string url, Image image)
        {
            _ImageUrl = url;
            _ImageKey = key;
            _Image = image;
        }
    }
}
