﻿using DHKANG.SEA.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace WindowsFormsApp2
{
    public partial class MainUI : Form
    {
        public static MainUI App;

        private ModelExplorerWindow _ModelExplorerWindow;
        private OutputWindow _OutputWindow;
        private ErrorListWindow _ErrorWindow;
        private PropertiesWindow _PropertiesWindow;


        private WeifenLuo.WinFormsUI.Docking.VS2015LightTheme vS2015LightTheme1;
        
        #region Member Variables - Menu Handlers 
        private FileMenuEventHandler _FileMenuHandler;
        #endregion

        #region Properties
        public ModelExplorerWindow ModelExplorer { get { return _ModelExplorerWindow; } }
        public OutputWindow OutputWindow { get { return _OutputWindow; } }
        public ErrorListWindow ErrorWindow { get { return _ErrorWindow; } }
        public PropertiesWindow PropertiesWindow { get { return _PropertiesWindow; } }

        public FileMenuEventHandler FileMenuHandler { get { return _FileMenuHandler; } }
        #endregion

        #region Constructors
        public MainUI()
        {
            InitializeComponent();

            this.vS2015LightTheme1 = new WeifenLuo.WinFormsUI.Docking.VS2015LightTheme();
            dockPanel1.Theme = vS2015LightTheme1;

            createDockableWindows();

            _FileMenuHandler = new FileMenuEventHandler(this);

            MainUI.App = this;

            ActionManager.Added += new UserActionAddedEventHandler(OnUserActionAdded);

        }

        public MainUI(string path)
            : this()
        {
            //FileOperation.OpenOOMMModelEditor(path);
        }
        #endregion

        #region Methods
        private void createDockableWindows()
        {
            _ErrorWindow = new ErrorListWindow(this);
            _ErrorWindow.Show(dockPanel1, DockState.DockBottom);
            _ErrorWindow.DockHandler.CloseButtonVisible = false;
            _ErrorWindow.DockHandler.CloseButton = false;

            _OutputWindow = new OutputWindow();
            _OutputWindow.Show(_ErrorWindow.Pane, _ErrorWindow);
            _OutputWindow.DockHandler.CloseButtonVisible = false;
            _OutputWindow.DockHandler.CloseButton = false;


            _PropertiesWindow = new PropertiesWindow();
            _PropertiesWindow.Show(_OutputWindow.Pane, DockAlignment.Right, 0.56);
            _PropertiesWindow.DockHandler.CloseButtonVisible = false;
            _PropertiesWindow.DockHandler.CloseButton = false;

            _ModelExplorerWindow = new ModelExplorerWindow(this);
            _ModelExplorerWindow.DockHandler.CloseButtonVisible = false;
            _ModelExplorerWindow.DockHandler.CloseButton = false;
            _ModelExplorerWindow.Show(dockPanel1, DockState.DockLeft);

            _ModelExplorerWindow.ObjectSelected += new ObjectSelectedEventHandler(_PropertiesWindow.Update);
            //_ModelExplorerWindow.EditorOpenRequested += new EditorOpenRequestEventHandler(OnEditorOpenRequested);
          
            _ModelExplorerWindow.Show();

        }
        #endregion

        #region User Action Event Handler Methods
        private void OnUserActionAdded(UserAction action)
        {
            statusLabel.Text = action.Action;
        }
        #endregion

        public void OpenDiagramEditor(OOMMModel model)
        {
            if (_DiagramWindows.ContainsKey(model.ID))
            {
                OOMMDiagramWindow diagramWindow = _DiagramWindows[model.ID];
                //diagramWindow.Select();
                //diagramWindow.Focus();
                //diagramWindow.BringToFront();
                diagramWindow.Show();
            }
            else
            {
                OOMMDiagramWindow diagramWindow = new OOMMDiagramWindow();
                diagramWindow.Show(dockPanel1, DockState.Document);
                diagramWindow.DockHandler.AllowEndUserDocking = true;
                diagramWindow.DockHandler.CloseButtonVisible = true;
                diagramWindow.DockHandler.CloseButton = true;
                diagramWindow.SelectionChanged += new DiagramSelectionChangedEventHandler(_DiagramWindow_SelectionChanged);
                //_DiagramWindow.Changed += new DiagramChangedEvent(OnDiagramWindowChanged);
                diagramWindow.DiagramChanged += new DiagramChangedEventHandler(OnDiagramWindowChanged);
                diagramWindow.ObjectSelected += new DiagramObjectSelectedEventHandler(_PropertiesWindow.Update);
                diagramWindow.DiagramChanged += new DiagramChangedEventHandler(_ModelExplorerWindow.OnDiagramChanged);
                diagramWindow.FormClosed += new FormClosedEventHandler(OnDiagramWindowClosed);
                diagramWindow.Open(model);

                _DiagramWindows.Add(model.ID, diagramWindow);
            }
        }
    }
}
