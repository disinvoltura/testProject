﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    [Serializable()]
    public class ModelProperty : ISerializable
    {
        #region Member Variables
        private string _Name;
        private object _Value;
        #endregion

        #region Properties
        public string Name { get { return _Name; } set { _Name = value; } }
        public object Value { get { return _Value; } set { _Value = value; } }
        #endregion 

        #region constructors
        public ModelProperty()
        { }

        public ModelProperty(string name, object value)
        {
            _Name = name;
            _Value = value;
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            _Name = (string)info.GetValue("Name", typeof(string));
            _Value = (object)info.GetValue("Value", typeof(object));
        }

        #endregion

        #region Methods
        //void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        //{
        //    info.AddValue("Name", _Name);
        //    info.AddValue("Value", _Value);
        //}
        #endregion
    }
}
