﻿using DHKANG.OOEG.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DHKANG.OOEG.UI
{

    public class OOEGModelBuilder
    {
        #region Member Variables
        private MainUI _Parent;

        #endregion

        #region Constructors
        public OOEGModelBuilder(MainUI parent)
        {

            _Parent = parent;
        }
        #endregion

        public OOEGEventGraphModel BuildModel(string projectName)
        {
            TreeNode projectNode = _Parent.ModelExplorer.getProjectNode(projectName);
            OOEGEventGraphModel model = (OOEGEventGraphModel)projectNode.Tag;
            
            //Entities
            List<OOEGEntity> entities = Modeling.EntityManager.GetEntities(projectName);
            model.Entities = entities;

            //Data Sources
            List<OOEGDataSource> dataSources = _Parent.ModelExplorer.GetDataSources(projectName);
            model.DataSources = dataSources;

            //Experiments
            List<OOEGExperiment> experiments = _Parent.ModelExplorer.GetExperiments(projectName);
            model.Experiments = experiments;
            
            //model properties
            
            return model;
        }
    }
}
