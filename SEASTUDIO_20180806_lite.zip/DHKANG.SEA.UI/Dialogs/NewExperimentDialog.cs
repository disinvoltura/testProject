﻿using DHKANG.SEA.Model;
using DHKANG.SEA.Model.Experiments;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DHKANG.SEA.UI.Dialogs
{
    public partial class NewExperimentDialog : Form
    {
        #region Member Variables
        private OOMMExperimentType _Type = OOMMExperimentType.SIMULATION;
        private List<string> _ExistingExperiments;
        #endregion

        #region Properties
        public string ExperimentName { get { return txtName.Text; } }
        public OOMMExperimentType Type {  get { return _Type; } }
        #endregion

        #region Constructors
        public NewExperimentDialog(List<string> existingExperiments)
        {
            _ExistingExperiments = existingExperiments;
            InitializeComponent();
        }
        #endregion

        #region Event Handlers
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtName.Text))
                return;

            if (listBox1.SelectedItems.Count == 0)
                return;

            if (_ExistingExperiments.Contains(txtName.Text))
            {
                lblError.Visible = true;
                return;
            }else
                lblError.Visible = false;

            if (listBox1.SelectedIndex == 0)
                _Type = OOMMExperimentType.SIMULATION;
            else if (listBox1.SelectedIndex == 1)
                _Type = OOMMExperimentType.WHATIF;
            else if (listBox1.SelectedIndex == 2)
                _Type = OOMMExperimentType.OPTIMIZATION;

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
        #endregion
    }
}
