﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DHKANG.SEA.UI.Dialogs
{
    public partial class NewUserClassDialog : Form
    {
        #region Member Variables
        private List<string> _ExistingNames;
        #endregion

        #region Properties
        public string NewName { get { return txtName.Text; } }

        #endregion

        #region Constructors
        public NewUserClassDialog(List<string> existingNames)
        {
            InitializeComponent();

            _ExistingNames = existingNames;
            txtName.Text = "";
        }

        public NewUserClassDialog(string name, List<string> existingNames)
        {
            InitializeComponent();

            _ExistingNames = existingNames;
            txtName.Text = name;
        }
        #endregion

        #region Methods
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtName.Text.Trim()))
                return;

            if (_ExistingNames.Contains(txtName.Text))
            {
                lblError.Visible = true;
                return;
            }

            this.DialogResult = DialogResult.OK;
            this.Close();

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
        #endregion

        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Return)
            {
                btnOK_Click(sender, e);
            }
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtName.Text))
                return;

            if (_ExistingNames.Contains(txtName.Text))
                lblError.Visible = true;
            else
                lblError.Visible = false;
        }
    }
}
