﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using DHKANG.SEA.UI.Dialogs;
using DHKANG.SEA.UI.Simulation;
using DHKANG.SEA.UI.Modeling;
using System.IO;
using System.Xml.Serialization;
using DHKANG.SEA.UI.ETTEditor;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.OID;
using DHKANG.SEA.Model.Entities;
using DHKANG.SEA.Model.Data;
using DHKANG.SEA.Model.Experiments;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.UI.STTEditor;
using DHKANG.SEA.UI.OutputView;
using DHKANG.SEA.Model.ActivityObjects;
using DHKANG.SEA.UI.ATTEditor;
using DHKANG.SEA.UI.OutputView.Visualization;

namespace DHKANG.SEA.UI
{
    public delegate void GoToRequestedEventHandler(string eventObjectName);
    public delegate void EntitySelectedEventHandler(OOMMEntity entity);
    public delegate void ObjectSelectedEventHandler(OOMMModel model, Object obj);
    public delegate void EditorOpenRequestEventHandler(string objectName, object objectValue);

    public partial class ModelExplorerWindow : DockContent
    {
        #region Member Variables
        private Dictionary<Guid, TreeNode> _ProjectNodes; //Key: project name 
        private Dictionary<Guid, TreeNode> _ObjectModelNodes;
        private Dictionary<Guid, TreeNode> _DataNodes;
        private Dictionary<Guid, TreeNode> _EntityNodes;
        private Dictionary<Guid, TreeNode> _ExperimentNodes;
        private Dictionary<Guid, TreeNode> _ClassNodes;
        private Dictionary<Guid, bool> _IsChanged; //key: guid
        private MainUI _Parent;
        #endregion

        #region Events
        public event GoToRequestedEventHandler GoTo;
        public event EntitySelectedEventHandler EntitySelected;
        public event ObjectSelectedEventHandler ObjectSelected;
        public event EditorOpenRequestEventHandler EditorOpenRequested;
        #endregion

        #region Properties
        public Dictionary<Guid, bool> IsChanged
        {
            get { return _IsChanged; }
        }

        /*
        public List<OOEGEventGraphModel> Projects
        {
            get
            {
                List<OOEGEventGraphModel> rslt = new List<OOEGEventGraphModel>();

                foreach(Guid projectid in _ProjectNodes.Keys)
                {
                    OOEGEventGraphModel model = GetProject(projectid);
                    rslt.Add(model);
                }

                return rslt;
            }
        }

        public OOEGEventGraphModel GetProject(Guid projectid)
        {
            TreeNode projectNode = _ProjectNodes[projectid];
            OOEGEventGraphModel model = null;
            if (projectNode.Tag != null && projectNode.Tag is OOEGEventGraphModel)
            {
                model = (OOEGEventGraphModel)projectNode.Tag;

                if (_Parent.DiagramWindows.ContainsKey(model.ID))
                {
                    OOEGDiagramWindow diagramWindow = _Parent.DiagramWindows[model.ID];
                    OOEGObjectInteractionDiagram diagram = diagramWindow.ObjectInteractionDiagram;
                    model.ObjectInteractionDiagram = diagram;

                    model.SetProperty(OOEGObjectInteractionDiagram.ZOOM_SCALE, diagramWindow.ViewScale);
                    model.SetProperty(OOEGObjectInteractionDiagram.GRID_VISIBILITY, diagramWindow.IsGridShown);
                }

                //Event Object Model
                List<OOEGEventObjectModel> eventObjects = GetEventObjects(projectid);
                model.EventObjectModels = eventObjects;

                //Entities
                List<OOEGEntity> entities = Modeling.EntityManager.GetEntities(projectid);
                model.Entities = entities;

                //Data Sources
                List<OOEGDataSource> dataSources = GetDataSources(projectid);
                model.DataSources = dataSources;

                //Experiments
                List<OOEGExperiment> experiments = GetExperiments(projectid);
                model.Experiments = experiments;
            }

            return model;
        }

        public OOEGEventGraphModel GetProject(string projectName)
        {
            TreeNode projectNode = null;
            foreach(TreeNode node in _ProjectNodes.Values)
            {
                if (node.Text.Equals(projectName))
                {
                    projectNode = node;
                    break;
                }
            }
            OOEGEventGraphModel model = null;
            if (projectNode.Tag != null && projectNode.Tag is OOEGEventGraphModel)
            {
                model = (OOEGEventGraphModel)projectNode.Tag;

                if (_Parent.DiagramWindows.ContainsKey(model.ID))
                {
                    OOEGDiagramWindow diagramWindow = _Parent.DiagramWindows[model.ID];
                    OOEGObjectInteractionDiagram diagram = diagramWindow.ObjectInteractionDiagram;
                    model.ObjectInteractionDiagram = diagram;

                    model.SetProperty(OOEGObjectInteractionDiagram.ZOOM_SCALE, diagramWindow.ViewScale);
                    model.SetProperty(OOEGObjectInteractionDiagram.GRID_VISIBILITY, diagramWindow.IsGridShown);
                }

                //Event Object Model
                List<OOEGEventObjectModel> eventObjects = GetEventObjects(model.ID);
                model.EventObjectModels = eventObjects;

                //Entities
                List<OOEGEntity> entities = Modeling.EntityManager.GetEntities(model.ID);
                model.Entities = entities;

                //Data Sources
                List<OOEGDataSource> dataSources = GetDataSources(model.ID);
                model.DataSources = dataSources;

                //Experiments
                List<OOEGExperiment> experiments = GetExperiments(model.ID);
                model.Experiments = experiments;
            }

            return model;
        }
        */
        public List<OOMMModel> Projects
        {
            get
            {
                List<OOMMModel> rslt = new List<OOMMModel>();

                foreach (Guid projectid in _ProjectNodes.Keys)
                {
                    OOMMModel model = GetProject(projectid);
                    rslt.Add(model);
                }

                return rslt;
            }
        }

        public OOMMModel GetProject(Guid projectid)
        {
            TreeNode projectNode = _ProjectNodes[projectid];
            OOMMModel model = null;
            if (projectNode.Tag != null && projectNode.Tag is OOMMModel)
            {
                model = (OOMMModel)projectNode.Tag;

                if (_Parent.DiagramWindows.ContainsKey(model.ID))
                {
                    OOMMDiagramWindow diagramWindow = _Parent.DiagramWindows[model.ID];
                    OOMMObjectInteractionDiagram diagram = diagramWindow.ObjectInteractionDiagram;
                    model.ObjectInteractionDiagram = diagram;

                    model.SetProperty(OOMMObjectInteractionDiagram.ZOOM_SCALE, diagramWindow.ViewScale);
                    model.SetProperty(OOMMObjectInteractionDiagram.GRID_VISIBILITY, diagramWindow.IsGridShown);
                }

                //Event Object Model
                List<DHKANG.SEA.Model.EventObjects.OOEGEventObjectModel> eventObjects = GetEventObjects(projectid);
                model.EventObjectModels = eventObjects;

                //State Object models
                List<OOSGStateObjectModel> stateObject = GetStateObjects(projectid);
                model.StateObjectModels = stateObject;

                //Activity Object Models
                List<OOAGActivityObjectModel> activityObjects = GetActivityObjects(projectid);
                model.ActivityObjectModels = activityObjects;
                //Entities
                List<OOMMEntity> entities = Modeling.EntityManager.GetEntities(projectid);
                model.Entities = entities;

                //Data Sources
                List<OOMMDataSource> dataSources = GetDataSources(projectid);
                model.DataSources = dataSources;

                //Experiments
                List<OOMMExperiment> experiments = GetExperiments(projectid);
                model.Experiments = experiments;
            }

            return model;
        }

        public OOMMModel GetProject(string projectName)
        {
            TreeNode projectNode = null;
            foreach (TreeNode node in _ProjectNodes.Values)
            {
                if (node.Text.Equals(projectName))
                {
                    projectNode = node;
                    break;
                }
            }
            OOMMModel model = null;
            if (projectNode.Tag != null && projectNode.Tag is OOMMModel)
            {
                model = (OOMMModel)projectNode.Tag;

                if (_Parent.DiagramWindows.ContainsKey(model.ID))
                {
                    OOMMDiagramWindow diagramWindow = _Parent.DiagramWindows[model.ID];
                    OOMMObjectInteractionDiagram diagram = diagramWindow.ObjectInteractionDiagram;
                    model.ObjectInteractionDiagram = diagram;

                    model.SetProperty(OOMMObjectInteractionDiagram.ZOOM_SCALE, diagramWindow.ViewScale);
                    model.SetProperty(OOMMObjectInteractionDiagram.GRID_VISIBILITY, diagramWindow.IsGridShown);
                }

                //Event Object Model
                List<DHKANG.SEA.Model.EventObjects.OOEGEventObjectModel> eventObjects = GetEventObjects(model.ID);
                model.EventObjectModels = eventObjects;

                //Entities
                List<OOMMEntity> entities = Modeling.EntityManager.GetEntities(model.ID);
                model.Entities = entities;

                //Data Sources
                List<OOMMDataSource> dataSources = GetDataSources(model.ID);
                model.DataSources = dataSources;

                //Experiments
                List<OOMMExperiment> experiments = GetExperiments(model.ID);
                model.Experiments = experiments;
            }

            return model;
        }

        public List<DHKANG.SEA.Model.EventObjects.OOEGEventObjectModel> GetEventObjects(Guid projectid)
        {
            List<DHKANG.SEA.Model.EventObjects.OOEGEventObjectModel> rslt = new List<DHKANG.SEA.Model.EventObjects.OOEGEventObjectModel>();

            TreeNode eoNode = _ObjectModelNodes[projectid];
            if (eoNode != null)
            {
                foreach (TreeNode node in eoNode.Nodes)
                {
                    if (node.Tag != null && node.Tag is DHKANG.SEA.Model.EventObjects.OOEGEventObjectModel)
                    {
                        DHKANG.SEA.Model.EventObjects.OOEGEventObjectModel eo = (DHKANG.SEA.Model.EventObjects.OOEGEventObjectModel)node.Tag;
                        rslt.Add(eo);
                    }
                }
            }

            return rslt;
        }

        public List<OOSGStateObjectModel> GetStateObjects(Guid projectid)
        {
            List<OOSGStateObjectModel> rslt = new List<OOSGStateObjectModel>();

            TreeNode eoNode = _ObjectModelNodes[projectid];
            if (eoNode != null)
            {
                foreach (TreeNode node in eoNode.Nodes)
                {
                    if (node.Tag != null && node.Tag is OOSGStateObjectModel)
                    {
                        OOSGStateObjectModel so = (OOSGStateObjectModel)node.Tag;
                        rslt.Add(so);
                    }
                }
            }

            return rslt;
        }

        public List<OOAGActivityObjectModel> GetActivityObjects(Guid projectid)
        {
            List<OOAGActivityObjectModel> rslt = new List<OOAGActivityObjectModel>();

            TreeNode eoNode = _ObjectModelNodes[projectid];
            if (eoNode != null)
            {
                foreach (TreeNode node in eoNode.Nodes)
                {
                    if (node.Tag != null && node.Tag is OOAGActivityObjectModel)
                    {
                        OOAGActivityObjectModel so = (OOAGActivityObjectModel)node.Tag;
                        rslt.Add(so);
                    }
                }
            }

            return rslt;
        }

        public List<OOMMDataSource> GetDataSources(Guid projectid)
        {
            List<OOMMDataSource> rslt = new List<OOMMDataSource>();

            TreeNode dataNode = _DataNodes[projectid];
            if (dataNode != null)
            {
                foreach (TreeNode node in dataNode.Nodes)
                {
                    OOMMDataSource ds = (OOMMDataSource)node.Tag;
                    rslt.Add(ds);
                }
            }
            return rslt;
        }

        public List<OOMMEntity> GetEntities(Guid projectid)
        {
            List<OOMMEntity> rslt = new List<OOMMEntity>();

            TreeNode entitiesNode = _EntityNodes[projectid];
            if (entitiesNode != null)
            {
                foreach (TreeNode node in entitiesNode.Nodes)
                {
                    OOMMEntity ds = (OOMMEntity)node.Tag;
                    rslt.Add(ds);
                }
            }
            return rslt;
        }

        public List<OOMMExperiment> GetExperiments(Guid projectid)
        {
            List<OOMMExperiment> rslt = new List<OOMMExperiment>();

            TreeNode expNode = _ExperimentNodes[projectid];
            if (expNode != null)
            {
                foreach (TreeNode node in expNode.Nodes)
                {
                    OOMMExperiment exp = (OOMMExperiment)node.Tag;
                    rslt.Add(exp);
                }
            }
            return rslt;
        }

        public Guid CurrentProject
        {
            get
            {
                Guid rslt = Guid.Empty;
                TreeNode projectNode = getCurrentProjectNode();
                if (projectNode != null)
                    rslt = ((OOMMModel)projectNode.Tag).ID;
                return rslt;
            }
        }
        #endregion

        #region Constructors
        public ModelExplorerWindow(MainUI parent)
        {
            _Parent = parent;
            _ProjectNodes = new Dictionary<Guid, TreeNode>();
            _ObjectModelNodes = new Dictionary<Guid, TreeNode>();
            _DataNodes = new Dictionary<Guid, TreeNode>();
            _EntityNodes = new Dictionary<Guid, TreeNode>();
            _ExperimentNodes = new Dictionary<Guid, TreeNode>();
            _ClassNodes = new Dictionary<Guid, TreeNode>();
            _IsChanged = new Dictionary<Guid, bool>();

            InitializeComponent();
            initializeImageList();
            initializeNodeList();
        }
        #endregion

        #region Methods


        /// <summary>
        /// 
        /// </summary>
        /// <param name="pid">Project ID</param>
        /// <param name="value"></param>
        public void SetChanged(Guid pid, bool value)
        {
            if (_IsChanged.ContainsKey(pid))
            {
                _IsChanged[pid] = value;
            }
            else
            {
                _IsChanged.Add(pid, value);
            }

            TreeNode projectNode = _ProjectNodes[pid];
            if (value)
            {
                projectNode.NodeFont = new Font(projectNode.TreeView.Font.FontFamily, projectNode.TreeView.Font.Size, FontStyle.Bold);
            }
            else
            {
                projectNode.NodeFont = new Font(projectNode.TreeView.Font.FontFamily, projectNode.TreeView.Font.Size, FontStyle.Regular);
            }
        }

        private void ModelExplorerWindow_Load(object sender, EventArgs e)
        {
        }

        private void initializeNodeList()
        {
            tvModel.Nodes.Clear();

            /*
            _DataNode = tvModel.Nodes.Add("Data", "Data", ImageManager.IMAGE_DATA_MODEL);
            _EntityNode = tvModel.Nodes.Add("Entities", "Entities", ImageManager.IMAGE_ENTITY_LIST);
            _OOEGNode = tvModel.Nodes.Add("Model", "Model", ImageManager.IMAGE_EVENT_COUPLED_MODEL);
            _ExperimentNode = tvModel.Nodes.Add("Experiments", "Experiments", ImageManager.IMAGE_EXPERIMENT_LIST);
            */
        }

        private void initializeImageList()
        {
            imageList1.Images.Clear();

            List<string> images = new List<string>();
            images.AddRange(new string[] {
                                ImageManager.IMAGE_DATA_OBJECT,
                                ImageManager.IMAGE_DATA_OBJECT_CSV,
                                ImageManager.IMAGE_DATA_OBJECT_EXCEL,
                                ImageManager.IMAGE_DATA_OBJECT_DB,
                                ImageManager.IMAGE_DATA_LIST,
                                ImageManager.IMAGE_ACTIVITY_OBJECT,
                                ImageManager.IMAGE_EVENT_OBJECT,
                                ImageManager.IMAGE_STATE_OBJECT,
                                ImageManager.IMAGE_ACTIVITY_NODE,
                                ImageManager.IMAGE_EVENT_NODE,
                                ImageManager.IMAGE_STATE_NODE,
                                ImageManager.IMAGE_STATEVARIABLE,
                                ImageManager.IMAGE_OBJECT_MODEL_LIST,
                                ImageManager.IMAGE_ACTIVITY_NODE_LIST,
                                ImageManager.IMAGE_QUEUE_NODE_LIST,
                                ImageManager.IMAGE_EVENT_NODE_LIST,
                                ImageManager.IMAGE_STATE_NODE_LIST,
                                ImageManager.IMAGE_STATEVARIABLE_LIST,
                                ImageManager.IMAGE_EXPERIMENT_LIST,
                                ImageManager.IMAGE_ENTITY,
                                ImageManager.IMAGE_ENTITY_LIST,
                                ImageManager.IMAGE_PROJECT,
                                ImageManager.IMAGE_SIMULATION_EXPERIMENT,
                                ImageManager.IMAGE_OUTPUTVIEW,
                                ImageManager.IMAGE_SIMULATION_OPTIMIZATION,
                                ImageManager.IMAGE_WHATIF_ANALYSIS,
                                ImageManager.IMAGE_SELECTED_NODE });

            foreach (string key in images)
            {
                Image image = ImageManager.find(key);
                if (image != null)
                    imageList1.Images.Add(key, image);
            }

            tvModel.SelectedImageKey = ImageManager.IMAGE_SELECTED_NODE;
        }

        private TreeNode findNode(string projectName, string name)
        {
            TreeNode rslt = null;

            foreach (TreeNode projectNode in _ProjectNodes.Values)
            {
                if (projectNode.Text.Equals(projectName))
                {
                    rslt = findNode(name, projectNode.Nodes);
                    break;
                }
            }
            return rslt;
        }

        private TreeNode findNode(string projectName, Guid id)
        {
            TreeNode rslt = null;

            foreach (TreeNode projectNode in _ProjectNodes.Values)
            {
                if (projectNode.Text.Equals(projectName))
                {
                    rslt = findNode(id, projectNode.Nodes);
                    break;
                }
            }
            return rslt;
        }

        private TreeNode findNode(string name, TreeNodeCollection nodes)
        {
            TreeNode rslt = null;
            foreach (TreeNode node in nodes)
            {
                if (node.Text.Equals(name))
                {
                    rslt = node; break;
                }

                rslt = findNode(name, node.Nodes);
                if (rslt != null)
                    break;
            }

            return rslt;
        }

        private TreeNode findNode(Guid id, TreeNodeCollection nodes)
        {
            TreeNode rslt = null;
            foreach (TreeNode node in nodes)
            {
                if (node.Tag != null)
                {
                    if (node.Tag is OOEGEventObjectModel)
                    {
                        if (((OOEGEventObjectModel)node.Tag).ID.Equals(id))
                        {
                            rslt = node;
                            break;
                        }
                    }
                    else if (node.Tag is OOAGActivityObjectModel)
                    {
                        if (((OOAGActivityObjectModel)node.Tag).ID.Equals(id))
                        {
                            rslt = node;
                            break;
                        }
                    }
                    else if (node.Tag is OOSGStateObjectModel)
                    {
                        if (((OOSGStateObjectModel)node.Tag).ID.Equals(id))
                        {
                            rslt = node;
                            break;
                        }
                    }
                }

                rslt = findNode(id, node.Nodes);
                if (rslt != null)
                    break;
            }

            return rslt;
        }

        public OOEGEventObjectModel OpenEventTransitionTableEditor(Guid projectID, Guid eventObjectModelID)
        {
            TreeNode objectModelNodes = getObjectModelNodes(projectID);
            TreeNode eoNode = null;
            foreach (TreeNode node in objectModelNodes.Nodes)
            {
                if (node.Tag is OOEGEventObjectModel)
                {
                    if (((OOEGEventObjectModel)node.Tag).ID.Equals(eventObjectModelID))
                    {
                        eoNode = node;
                        break;
                    }
                }
            }
            OOEGEventObjectModel eoModel = null;
            if (eoNode != null)
            {
                eoModel = (OOEGEventObjectModel)eoNode.Tag;
                EventObjectModelEditor editor = new EventObjectModelEditor(eoModel);

                DialogResult rslt = editor.ShowDialog();
                if (rslt == DialogResult.OK)
                {
                    OOEGEventObjectModel updatedObjectModel = editor.EventObjectModel;
                    tvModel.SelectedNode.Tag = updatedObjectModel;

                    updateEventObjectNode(eoNode, updatedObjectModel);

                    SetChanged(projectID, true);
                }
            }

            return eoModel;
        }

        public OOSGStateObjectModel OpenStateTransitionTableEditor(Guid projectID, Guid stateObjectModelID)
        {
            TreeNode objectNodes = getObjectModelNodes(projectID);
            TreeNode soNode = null;
            foreach (TreeNode node in objectNodes.Nodes)
            {
                if (node.Tag is OOSGStateObjectModel)
                {
                    if (((OOEGEventObjectModel)node.Tag).ID.Equals(stateObjectModelID))
                    {
                        soNode = node;
                        break;
                    }
                }
            }
            OOSGStateObjectModel soModel = null;
            if (soNode != null)
            {
                soModel = (OOSGStateObjectModel)soNode.Tag;
                StateObjectModelEditor editor = new StateObjectModelEditor(soModel);

                DialogResult rslt = editor.ShowDialog();
                if (rslt == DialogResult.OK)
                {
                    OOSGStateObjectModel updatedObjectModel = editor.StateObjectModel;
                    tvModel.SelectedNode.Tag = updatedObjectModel;

                    updateStateObjectNode(soNode, updatedObjectModel);

                    SetChanged(projectID, true);
                }
            }

            return soModel;
        }

        public void OnDiagramChanged(DiagramChangeType type, Guid modelid, object changedObject, object oldObject)
        {
            if (isUpdating)
                return;

        }

        private void updateEventObjectNode(TreeNode eoNode, OOEGEventObjectModel eoModel)
        {
            eoNode.Nodes.Clear();
            TreeNode eventsNodes = eoNode.Nodes.Add("Events");
            eventsNodes.ImageKey = ImageManager.IMAGE_EVENT_NODE_LIST;
            TreeNode svNodes = eoNode.Nodes.Add("State Variables");
            svNodes.ImageKey = ImageManager.IMAGE_STATEVARIABLE_LIST;

            foreach (OOEGStateVariable sv in eoModel.StateVariables)
            {
                TreeNode svNode = svNodes.Nodes.Add(sv.Name + ": " + sv.ValueType);
                svNode.ImageKey = ImageManager.IMAGE_STATEVARIABLE;
            }

            foreach (OOEGEventTransition evt in eoModel.EventTransitions)
            {
                TreeNode eventNode = null;
                if (string.IsNullOrEmpty(evt.Event.Parameters))
                    eventNode = eventsNodes.Nodes.Add(evt.Event.Name);
                else
                    eventNode = eventsNodes.Nodes.Add(evt.Event.Name + "(" + evt.Event.Parameters + ")");

                if (eventNode != null)
                    eventNode.ImageKey = ImageManager.IMAGE_EVENT_NODE;
            }
        }

        private void updateActivityObjectNode(TreeNode objectNode, OOAGActivityObjectModel objectModel)
        {
            objectNode.Nodes.Clear();
            TreeNode activityNodes = objectNode.Nodes.Add("Activities");
            activityNodes.ImageKey = ImageManager.IMAGE_ACTIVITY_NODE_LIST;
            TreeNode queueNodes = objectNode.Nodes.Add("Queues");
            queueNodes.ImageKey = ImageManager.IMAGE_QUEUE_NODE_LIST;
            TreeNode svNodes = objectNode.Nodes.Add("State Variables");
            svNodes.ImageKey = ImageManager.IMAGE_STATEVARIABLE_LIST;

            foreach (OOAGStateVariable sv in objectModel.StateVariables)
            {
                TreeNode svNode = svNodes.Nodes.Add(sv.Name + ": " + sv.ValueType);
                svNode.ImageKey = ImageManager.IMAGE_STATEVARIABLE;
            }

            foreach (OOAGActivityTransition at in objectModel.ActivityTransitions)
            {
                TreeNode activityNode = null;
                if (string.IsNullOrEmpty(at.Activity.Parameters))
                    activityNode = activityNodes.Nodes.Add(at.Activity.Name);
                else
                    activityNode = activityNodes.Nodes.Add(at.Activity.Name + "(" + at.Activity.Parameters + ")");

                if (activityNode != null)
                    activityNode.ImageKey = ImageManager.IMAGE_ACTIVITY_NODE;
            }

            foreach (OOAGQueue q in objectModel.Queues)
            {
                TreeNode qNode = null;
                if (string.IsNullOrEmpty(q.Parameters))
                    qNode = queueNodes.Nodes.Add(q.Name);
                else
                    qNode = queueNodes.Nodes.Add(q.Name + "(" + q.Parameters + ")");
                qNode.ImageKey = ImageManager.IMAGE_QUEUE_NODE;
            }
        }

        private void updateStateObjectNode(TreeNode soNode, OOSGStateObjectModel soModel)
        {
            soNode.Nodes.Clear();
            TreeNode statesNodes = soNode.Nodes.Add("States");
            statesNodes.ImageKey = ImageManager.IMAGE_STATE_NODE_LIST;
            TreeNode svNodes = soNode.Nodes.Add("State Variables");
            svNodes.ImageKey = ImageManager.IMAGE_STATEVARIABLE_LIST;

            foreach (OOSGStateVariable sv in soModel.StateVariables)
            {
                TreeNode svNode = svNodes.Nodes.Add(sv.Name + ": " + sv.Type.ToString());
                svNode.ImageKey = ImageManager.IMAGE_STATEVARIABLE;
            }

            foreach (OOSGState state in soModel.States)
            {
                TreeNode stateNode = null;
                stateNode = statesNodes.Nodes.Add(state.Name);
                stateNode.ImageKey = ImageManager.IMAGE_STATE_NODE;
            }
        }

        private bool isUpdating = false;
        public void Update(ModelPropertyType type, Guid modelid, string oldValue, string newValue)
        {
            this.SetChanged(modelid, true);

            if (type != ModelPropertyType.Name)
                return;
            TreeNode projectNode = null;
            if (!_ProjectNodes.ContainsKey(modelid))
                return;

            projectNode = _ProjectNodes[modelid];

            projectNode.Text = newValue;


            _Parent.CheckSyntax();
        }


        public void Update(Guid modelId, object changedObject, string propertyName, object oldValue, object newValue)
        {
            this.SetChanged(modelId, true);
        }

        public void Update(OOMMModel model, AbstractChart chart)
        {
            this.SetChanged(model.ID, true);
        }


        private void sortObjectModels(Guid projectID, TreeNode targetNode)
        {
            TreeNode objectModelNodes = targetNode.Parent;
            objectModelNodes.Nodes.RemoveAt(targetNode.Index);
            
            bool isInserted = false;
            for (int i = 0; i < objectModelNodes.Nodes.Count; i++)
            {
                TreeNode node = objectModelNodes.Nodes[i];
                if (targetNode.Text.CompareTo(node.Text) < 0)
                {
                    objectModelNodes.Nodes.Insert(i, targetNode);
                    isInserted = true;
                    break;
                }
            }

            if (!isInserted)
                objectModelNodes.Nodes.Add(targetNode);

            tvModel.SelectedNode = targetNode;
        }
        //update the event object model: name change
        public void Update(Guid id, string propertyName, object oldValue, object newValue)
        {
            string projectName = getCurrentProjectName();
            TreeNode node = findNode(projectName, id);
            OOMMModel model = GetProject(projectName);
            if (node == null)
                return;
            if (node.Tag is OOEGEventObjectModel)
            {
                OOEGEventObjectModel objectModel = (OOEGEventObjectModel)node.Tag;
                if (objectModel.ID.Equals(id))
                {
                    if (propertyName.Equals("name"))
                    {
                        node.Text = (string)newValue;
                        objectModel.Name = (string)newValue;
                        _Parent.DiagramWindows[model.ID].Open(model);

                        sortObjectModels(model.ID, node);
                        this.SetChanged(model.ID, true);
                    }
                    else if (propertyName.Equals("description"))
                    {
                        node.ToolTipText = (string)newValue;
                        this.SetChanged(model.ID, true);
                    }
                    else if (propertyName.Equals("backgroundcolor"))
                    {
                        model.ObjectInteractionDiagram.ChangeBackgroundColor(objectModel.ID, (Color)newValue);
                        _Parent.DiagramWindows[model.ID].Open(model);
                        this.SetChanged(model.ID, true);
                    }
                }
            }
            else if (node.Tag is OOSGStateObjectModel)
            {
                OOSGStateObjectModel objectModel = (OOSGStateObjectModel)node.Tag;

                if (objectModel.ID.Equals(id))
                {
                    if (propertyName.Equals("name"))
                    {
                        node.Text = (string)newValue;
                        objectModel.Name = (string)newValue;
                        _Parent.DiagramWindows[model.ID].Open(model);
                        sortObjectModels(model.ID, node);
                        this.SetChanged(model.ID, true);
                    }
                    else if (propertyName.Equals("description"))
                    {
                        node.ToolTipText = (string)newValue;
                        this.SetChanged(model.ID, true);
                    }
                    else if (propertyName.Equals("backgroundcolor"))
                    {
                        model.ObjectInteractionDiagram.ChangeBackgroundColor(objectModel.ID, (Color)newValue);
                        _Parent.DiagramWindows[model.ID].Open(model);
                        this.SetChanged(model.ID, true);
                    }
                }
            }
            else if (node.Tag is OOAGActivityObjectModel)
            {
                OOAGActivityObjectModel objectModel = (OOAGActivityObjectModel)node.Tag;
                if (objectModel.ID.Equals(id))
                {
                    if (propertyName.Equals("name"))
                    {
                        node.Text = (string)newValue;
                        objectModel.Name = (string)newValue;
                        _Parent.DiagramWindows[model.ID].Open(model);
                        sortObjectModels(model.ID, node);
                        this.SetChanged(model.ID, true);
                    }
                    else if (propertyName.Equals("description"))
                    {
                        node.ToolTipText = (string)newValue;
                        this.SetChanged(model.ID, true);
                    }
                    else if (propertyName.Equals("backgroundcolor"))
                    {
                        model.ObjectInteractionDiagram.ChangeBackgroundColor(objectModel.ID, (Color)newValue);
                        _Parent.DiagramWindows[model.ID].Open(model);
                        this.SetChanged(model.ID, true);
                    }
                }
            }
        }

        public int IsModelOpened(OOMMModel model)
        {
            TreeNode projectNode = null;

            int rslt = 0; //0: not opened, 1: opened with the same Guid but different name, 2: opened with the same Guid and name.
            if (_ProjectNodes.ContainsKey(model.ID))
            {
                projectNode = _ProjectNodes[model.ID];

                OOMMModel openedModel = (OOMMModel)projectNode.Tag;

                if (openedModel.Name.Equals(model.Name))
                    rslt = 2;
                else
                    rslt = 1;
            }
            else
            {
                rslt = 0;
            }

            return rslt;
        }

        public void Update(OOMMModel model)
        {
            isUpdating = true;
            //initializeNodeList();
            TreeNode projectNode = null;

            bool isNewlyOpend = false;
            if (_ProjectNodes.ContainsKey(model.ID))
            {
                projectNode = _ProjectNodes[model.ID];
            }
            else
            {
                isNewlyOpend = true;
                projectNode = new TreeNode(model.Name);
                projectNode.ImageKey = ImageManager.IMAGE_PROJECT;
                projectNode.Tag = model;
                tvModel.Nodes.Add(projectNode);
                _ProjectNodes.Add(model.ID, projectNode);

                tvModel.SelectedNode = projectNode;
            }

            TreeNode objectModelsNode = UpdateObjectModels(projectNode, model);
            TreeNode entityNode = Update(projectNode, model.Entities);
            TreeNode dsNode = Update(projectNode, model.DataSources);
            TreeNode classNode = Update(projectNode, model.UserClasses);
            TreeNode expNode = Update(projectNode, model.Experiments);

            if (_IsChanged.ContainsKey(model.ID))
                _IsChanged[model.ID] = false;
            else
                _IsChanged.Add(model.ID, false);

            if (isNewlyOpend)
            {
                projectNode.Expand();
                objectModelsNode.Expand();
                entityNode.Expand();
                dsNode.Expand();
                expNode.Expand();
            }

            isUpdating = false;
        }

        public void Update(Guid modelID, OOMMObjectInteractionDiagram diagram, float viewScale)
        {
            if (_ProjectNodes.ContainsKey(modelID))
            {
                TreeNode projectNode = _ProjectNodes[modelID];
                OOMMModel model = (OOMMModel)projectNode.Tag;
                model.ObjectInteractionDiagram = diagram;
                model.SetProperty("ViewScale", viewScale);
                _ProjectNodes[modelID].Tag = model;
            }
        }

        private void tsbRefresh_Click(object sender, EventArgs e)
        {
            List<OOMMModel> projects = this.Projects;

            foreach (OOMMModel proj in projects)
                this.Update(proj);
        }

        private void tsbCollapseAll_Click(object sender, EventArgs e)
        {
            tvModel.CollapseAll();
        }

        private void tsbExpandAll_Click(object sender, EventArgs e)
        {
            tvModel.ExpandAll();
        }
        #endregion

        private void tvModel_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                string projectName = getCurrentProjectName();
                OOMMModel model = GetProject(projectName);
                if (model == null)
                    return;

                if (e.Node.ImageKey.Equals(ImageManager.IMAGE_ENTITY))
                {
                    if (ObjectSelected != null && ObjectSelected.GetInvocationList().Length > 0)
                        ObjectSelected(model, (OOMMEntity)e.Node.Tag);
                }
                else if (e.Node.ImageKey.Equals(ImageManager.IMAGE_DATA_OBJECT_CSV) ||
                         e.Node.ImageKey.Equals(ImageManager.IMAGE_DATA_OBJECT_EXCEL) ||
                         e.Node.ImageKey.Equals(ImageManager.IMAGE_DATA_OBJECT_DB))
                {
                    if (ObjectSelected != null && ObjectSelected.GetInvocationList().Length > 0)
                        ObjectSelected(model, (OOMMDataSource)e.Node.Tag);
                }
                else
                {
                    if (e.Node.Tag != null)
                    {
                        if (ObjectSelected != null && ObjectSelected.GetInvocationList().Length > 0)
                            ObjectSelected(model, e.Node.Tag);
                        //ObjectSelected(null);
                    }
                    else
                    {
                        if (ObjectSelected != null && ObjectSelected.GetInvocationList().Length > 0)
                            ObjectSelected(null, null);
                    }
                }

            }
            else if (e.Button == MouseButtons.Right)
            {
                if (e.Node.ImageKey.Equals(ImageManager.IMAGE_SIMULATION_EXPERIMENT))
                    contextMenuStrip2.Show(tvModel, e.Location);
                else if (e.Node.ImageKey.Equals(ImageManager.IMAGE_OBJECT_MODEL_LIST))
                {
                    omlPasteToolStripMenuItem.Visible = false;

                    if (_CopiedObject != null && 
                        (_CopiedObject is OOSGStateObjectModel || 
                         _CopiedObject is OOEGEventObjectModel || 
                         _CopiedObject is OOAGActivityObjectModel))
                    {
                        //omlPasteToolStripMenuItem.Enabled = true;
                        omlPasteToolStripMenuItem.Visible = true;
                    }
                 
                    contextMenuStrip3.Show(tvModel, e.Location);
                }
                else
                {
                    toolStripMenuItem2.Visible = false;

                    editToolStripMenuItem.Visible = false;
                    exportToTemplateToolstripMenuItem.Visible = false;

                    copyToolStripMenuItem.Enabled = false;
                    pasteToolStripMenuItem.Enabled = false;
                    deleteToolStripMenuItem.Enabled = false;

                    collapseAllToolStripMenuItem.Enabled = false;
                    expandAllToolStripMenuItem.Enabled = false;
                    closeToolStripMenuItem.Visible = false;
                    viewCodeToolStripMenuItem.Visible = false;
                    duplicateProjectToolStripMenuItem.Visible = false;

                    //New Menuitems
                    dataToolStripMenuItem.Visible = true;
                    entityToolStripMenuItem.Visible = true;
                    eventObjectToolStripMenuItem.Visible = true;
                    cClassToolStripMenuItem.Visible = true;
                    experimentToolStripMenuItem.Visible = true;

                    saveToolStripMenuItem.Visible = false;

                    toolStripSeparator3.Visible = true;
                    toolStripSeparator6.Visible = false;
                    toolStripSeparator7.Visible = false;

                    if (e.Node.ImageKey.Equals(ImageManager.IMAGE_DATA_LIST) ||
                        e.Node.ImageKey.Equals(ImageManager.IMAGE_OBJECT_MODEL_LIST) ||
                        e.Node.ImageKey.Equals(ImageManager.IMAGE_ENTITY_LIST) ||
                        e.Node.ImageKey.Equals(ImageManager.IMAGE_ACTIVITY_NODE_LIST) ||
                        e.Node.ImageKey.Equals(ImageManager.IMAGE_QUEUE_NODE_LIST) ||
                        e.Node.ImageKey.Equals(ImageManager.IMAGE_EVENT_NODE_LIST) ||
                        e.Node.ImageKey.Equals(ImageManager.IMAGE_STATE_NODE_LIST) ||
                        e.Node.ImageKey.Equals(ImageManager.IMAGE_STATEVARIABLE_LIST) ||
                        e.Node.ImageKey.Equals(ImageManager.IMAGE_PROJECT) ||
                        e.Node.ImageKey.Equals(ImageManager.IMAGE_EXPERIMENT_LIST))
                    {
                        collapseAllToolStripMenuItem.Enabled = true;
                        expandAllToolStripMenuItem.Enabled = true;
                    }

                    if (e.Node.ImageKey.Equals(ImageManager.IMAGE_DATA_LIST) ||
                        e.Node.ImageKey.Equals(ImageManager.IMAGE_OBJECT_MODEL_LIST) ||
                        e.Node.ImageKey.Equals(ImageManager.IMAGE_ENTITY_LIST) ||
                        e.Node.ImageKey.Equals(ImageManager.IMAGE_USER_CLASS_LIST) ||
                        e.Node.ImageKey.Equals(ImageManager.IMAGE_EXPERIMENT_LIST))
                    {
                        if (_CopiedObject != null)
                        {
                            if (e.Node.ImageKey.Equals(ImageManager.IMAGE_DATA_LIST) &&
                                _CopiedObject is OOMMDataSource)
                            {
                                pasteToolStripMenuItem.Visible = true;
                                pasteToolStripMenuItem.Enabled = true;
                            }else if (e.Node.ImageKey.Equals(ImageManager.IMAGE_OBJECT_MODEL_LIST) &&
                                (_CopiedObject is OOSGStateObjectModel ||
                                 _CopiedObject is OOEGEventObjectModel ||
                                 _CopiedObject is OOAGActivityObjectModel
                                ))
                            {
                                pasteToolStripMenuItem.Visible = true;
                                pasteToolStripMenuItem.Enabled = true;
                            }else if (e.Node.ImageKey.Equals(ImageManager.IMAGE_ENTITY_LIST) &&
                                _CopiedObject is OOMMEntity)
                            {
                                pasteToolStripMenuItem.Visible = true;
                                pasteToolStripMenuItem.Enabled = true;
                            }else if (e.Node.ImageKey.Equals(ImageManager.IMAGE_USER_CLASS_LIST) &&
                                _CopiedObject is OOMMUserClass)
                            {
                                pasteToolStripMenuItem.Visible = true;
                                pasteToolStripMenuItem.Enabled = true;
                            }
                            else if (e.Node.ImageKey.Equals(ImageManager.IMAGE_EXPERIMENT_LIST) &&
                               _CopiedObject is OOMMExperiment)
                            {
                                pasteToolStripMenuItem.Visible = true;
                                pasteToolStripMenuItem.Enabled = true;
                            }

                        }
                    }

                    if (e.Node.ImageKey.Equals(ImageManager.IMAGE_DATA_OBJECT_CSV) ||
                              e.Node.ImageKey.Equals(ImageManager.IMAGE_DATA_OBJECT_EXCEL) ||
                              e.Node.ImageKey.Equals(ImageManager.IMAGE_DATA_OBJECT_DB) ||
                              e.Node.ImageKey.Equals(ImageManager.IMAGE_ENTITY) ||
                              e.Node.ImageKey.Equals(ImageManager.IMAGE_USER_CLASS))

                    {
                        copyToolStripMenuItem.Enabled = true;
                        pasteToolStripMenuItem.Enabled = false;
                        if (_CopiedObject != null &&
                            ((_CopiedObject is OOMMEntity) || (_CopiedObject is OOMMDataSource) || (_CopiedObject is OOMMUserClass)))
                        {
                            pasteToolStripMenuItem.Enabled = true;
                        }
                        deleteToolStripMenuItem.Enabled = true;
                        duplicateProjectToolStripMenuItem.Visible = true;
                    }

                    if (e.Node.ImageKey.Equals(ImageManager.IMAGE_EVENT_OBJECT) ||
                             e.Node.ImageKey.Equals(ImageManager.IMAGE_ACTIVITY_OBJECT) ||
                             e.Node.ImageKey.Equals(ImageManager.IMAGE_STATE_OBJECT))
                    {
                        copyToolStripMenuItem.Enabled = true;
                        pasteToolStripMenuItem.Visible = false;
                        if (_CopiedObject != null &&
                            ((_CopiedObject is OOAGActivityObjectModel) || (_CopiedObject is OOSGStateObjectModel) || (_CopiedObject is OOEGEventObjectModel)))
                            pasteToolStripMenuItem.Enabled = true;
                        deleteToolStripMenuItem.Visible = true;
                        deleteToolStripMenuItem.Enabled = true;
                        editToolStripMenuItem.Visible = true;
                        exportToTemplateToolstripMenuItem.Visible = true;

                        collapseAllToolStripMenuItem.Enabled = true;
                        expandAllToolStripMenuItem.Enabled = true;

                        duplicateProjectToolStripMenuItem.Visible = true;
                    }


                    if (e.Node.ImageKey.Equals(ImageManager.IMAGE_PROJECT))
                    {
                        toolStripMenuItem2.Visible = true;

                        editToolStripMenuItem.Visible = true;
                        closeToolStripMenuItem.Visible = true;
                        viewCodeToolStripMenuItem.Visible = true;
                        duplicateProjectToolStripMenuItem.Visible = true;
                        saveToolStripMenuItem.Visible = true;

                        toolStripSeparator3.Visible = true;
                        toolStripSeparator6.Visible = true;
                        toolStripSeparator7.Visible = true;

                    }

                    if (saveToolStripMenuItem.Visible == false && closeToolStripMenuItem.Visible == false)
                        toolStripSeparator3.Visible = false;
                    else
                        toolStripSeparator3.Visible = true;
                    //if (!viewCodeToolStripMenuItem.Visible)
                    //    toolStripSeparator6.Visible = false;

                    //group nodes

                    //- Model

                    //- entities

                    //- data
                    //- class
                    //- Experiments
                    if (e.Node.ImageKey.Equals(ImageManager.IMAGE_EXPERIMENT_LIST))
                    {
                        toolStripMenuItem2.Visible = true;

                        dataToolStripMenuItem.Visible = false;
                        entityToolStripMenuItem.Visible = false;
                        eventObjectToolStripMenuItem.Visible = false;
                        cClassToolStripMenuItem.Visible = false;
                        experimentToolStripMenuItem.Visible = true;

                        toolStripSeparator3.Visible = false;
                        toolStripSeparator7.Visible = true;

                    }
                    else if (e.Node.ImageKey.Equals(ImageManager.IMAGE_ENTITY_LIST))
                    {
                        toolStripMenuItem2.Visible = true;

                        dataToolStripMenuItem.Visible = false;
                        entityToolStripMenuItem.Visible = true;
                        eventObjectToolStripMenuItem.Visible = false;
                        cClassToolStripMenuItem.Visible = false;
                        experimentToolStripMenuItem.Visible = false;

                        toolStripSeparator3.Visible = false;
                        toolStripSeparator7.Visible = true;
                    }
                    else if (e.Node.ImageKey.Equals(ImageManager.IMAGE_USER_CLASS_LIST))
                    {
                        toolStripMenuItem2.Visible = true;

                        dataToolStripMenuItem.Visible = false;
                        entityToolStripMenuItem.Visible = false;
                        eventObjectToolStripMenuItem.Visible = false;
                        cClassToolStripMenuItem.Visible = true;
                        experimentToolStripMenuItem.Visible = false;

                        toolStripSeparator3.Visible = false;
                        toolStripSeparator7.Visible = true;
                    }
                    else if (e.Node.ImageKey.Equals(ImageManager.IMAGE_DATA_LIST))
                    {
                        toolStripMenuItem2.Visible = true;

                        dataToolStripMenuItem.Visible = true;
                        entityToolStripMenuItem.Visible = false;
                        eventObjectToolStripMenuItem.Visible = false;
                        cClassToolStripMenuItem.Visible = false;
                        experimentToolStripMenuItem.Visible = false;

                        toolStripSeparator3.Visible = false;
                        toolStripSeparator7.Visible = true;
                    }

                    //toolStripSeparator7.Visible = toolStripMenuItem2.Visible;

                    contextMenuStrip1.Show(tvModel, e.Location);
                }
            }
        }

        private void tvModel_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if (e.Node.ImageKey == ImageManager.IMAGE_EVENT_OBJECT)
                {
                    if (GoTo != null && GoTo.GetInvocationList().Length > 0)
                        GoTo(e.Node.Text);
                }
                else if (e.Node.ImageKey == ImageManager.IMAGE_DATA_OBJECT_CSV ||
                         e.Node.ImageKey == ImageManager.IMAGE_DATA_OBJECT_EXCEL ||
                         e.Node.ImageKey == ImageManager.IMAGE_DATA_OBJECT_DB)
                {
                    if (EditorOpenRequested != null && EditorOpenRequested.GetInvocationList().Length > 0)
                        EditorOpenRequested(e.Node.Text, e.Node.Tag);
                }
                else if (e.Node.ImageKey == ImageManager.IMAGE_PROJECT)
                {
                    if (e.Node.Tag != null && e.Node.Tag is OOMMModel)
                    {
                        _Parent.OpenDiagramEditor((OOMMModel)e.Node.Tag);
                    }
                }
            }
        }

        #region Context Menu Handlers - New

        private void eventObjectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode projectNode = getCurrentProjectNode();
            OOMMModel model = getCurrentProjectModel();
            TreeNode ooegNode = null;
            if (_ObjectModelNodes.ContainsKey(model.ID))
            {
                ooegNode = _ObjectModelNodes[model.ID];
            }
            else
            {
                ooegNode = projectNode.Nodes.Add("Model", "Model", ImageManager.IMAGE_OBJECT_MODEL_LIST);
                _ObjectModelNodes.Add(model.ID, ooegNode);
            }

            List<OOEGEventObjectModel> eventObjects = new List<OOEGEventObjectModel>();
            List<string> eventObjectNames = new List<string>();
            foreach (TreeNode eoNode in ooegNode.Nodes)
            {
                if (eoNode.Tag != null && eoNode.Tag is OOEGEventObjectModel)
                {
                    eventObjects.Add((OOEGEventObjectModel)eoNode.Tag);
                    eventObjectNames.Add(((OOEGEventObjectModel)eoNode.Tag).Name);
                }
            }

            Dialogs.NewEventObjectModelDialog dialog = new Dialogs.NewEventObjectModelDialog(eventObjectNames);
            dialog.StartPosition = FormStartPosition.CenterParent;
            DialogResult rslt = dialog.ShowDialog(MainUI.App);
            if (rslt == DialogResult.OK)
            {
                OOEGEventObjectModel objectModel = new OOEGEventObjectModel(dialog.EventObjectName);

                TreeNode objectNode = null;
                for (int i = 0; i < ooegNode.Nodes.Count; i++)
                {
                    if (objectModel.Name.CompareTo(ooegNode.Nodes[i].Text) <= 0)
                    {
                        objectNode = ooegNode.Nodes.Insert(i, objectModel.Name, objectModel.Name, ImageManager.IMAGE_EVENT_OBJECT);
                        objectNode.Tag = objectModel;
                        break;
                    }
                }

                if (objectNode == null)
                {
                    objectNode = ooegNode.Nodes.Add(objectModel.Name, objectModel.Name, ImageManager.IMAGE_EVENT_OBJECT);
                    objectNode.Tag = objectModel;
                }

                updateEventObjectNode(objectNode, objectModel);

                SetChanged(model.ID, true);

                //if (!ooegNode.IsExpanded)
                //    ooegNode.Expand();
            }
        }

        private void stateObjectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode projectNode = getCurrentProjectNode();
            OOMMModel model = getCurrentProjectModel();
            TreeNode ooegNode = null;
            if (_ObjectModelNodes.ContainsKey(model.ID))
            {
                ooegNode = _ObjectModelNodes[model.ID];
            }
            else
            {
                ooegNode = projectNode.Nodes.Add("Model", "Model", ImageManager.IMAGE_OBJECT_MODEL_LIST);
                _ObjectModelNodes.Add(model.ID, ooegNode);
            }

            List<OOSGStateObjectModel> stateObjects = new List<OOSGStateObjectModel>();
            List<string> stateObjectNames = new List<string>();
            foreach (TreeNode node in ooegNode.Nodes)
            {
                if (node.Tag != null && node.Tag is OOSGStateObjectModel)
                {
                    stateObjects.Add((OOSGStateObjectModel)node.Tag);
                    stateObjectNames.Add(((OOSGStateObjectModel)node.Tag).Name);
                }
            }

            Dialogs.NewStateObjectModelDialog dialog = new Dialogs.NewStateObjectModelDialog(stateObjectNames);
            dialog.StartPosition = FormStartPosition.CenterParent;
            DialogResult rslt = dialog.ShowDialog(MainUI.App);
            if (rslt == DialogResult.OK)
            {
                OOSGStateObjectModel objectModel = new OOSGStateObjectModel(dialog.StateObjectName);

                TreeNode objectNode = null;
                for (int i = 0; i < ooegNode.Nodes.Count; i++)
                {
                    if (objectModel.Name.CompareTo(ooegNode.Nodes[i].Text) <= 0)
                    {
                        objectNode = ooegNode.Nodes.Insert(i, objectModel.Name, objectModel.Name, ImageManager.IMAGE_STATE_OBJECT);
                        objectNode.Tag = objectModel;
                        break;
                    }
                }
                if (objectNode == null)
                {
                    objectNode = ooegNode.Nodes.Add(objectModel.Name, objectModel.Name, ImageManager.IMAGE_STATE_OBJECT);
                    objectNode.Tag = objectModel;
                }
                updateStateObjectNode(objectNode, objectModel);

                SetChanged(model.ID, true);
            }
        }

        private void activityObjectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode projectNode = getCurrentProjectNode();
            OOMMModel model = getCurrentProjectModel();
            TreeNode ooegNode = null;
            if (_ObjectModelNodes.ContainsKey(model.ID))
            {
                ooegNode = _ObjectModelNodes[model.ID];
            }
            else
            {
                ooegNode = projectNode.Nodes.Add("Model", "Model", ImageManager.IMAGE_OBJECT_MODEL_LIST);
                _ObjectModelNodes.Add(model.ID, ooegNode);
            }

            List<OOAGActivityObjectModel> activityObjects = new List<OOAGActivityObjectModel>();
            List<string> objectNames = new List<string>();
            foreach (TreeNode node in ooegNode.Nodes)
            {
                if (node.Tag != null && node.Tag is OOSGStateObjectModel)
                {
                    activityObjects.Add((OOAGActivityObjectModel)node.Tag);
                    objectNames.Add(((OOAGActivityObjectModel)node.Tag).Name);
                }
            }

            Dialogs.NewActivityObjectModelDialog dialog = new Dialogs.NewActivityObjectModelDialog(objectNames);
            dialog.StartPosition = FormStartPosition.CenterParent;
            DialogResult rslt = dialog.ShowDialog(MainUI.App);
            if (rslt == DialogResult.OK)
            {
                OOAGActivityObjectModel objectModel = new OOAGActivityObjectModel(dialog.StateObjectName, string.Empty);

                TreeNode objectNode = null;
                for(int i = 0; i < ooegNode.Nodes.Count; i++)
                {
                    if (objectModel.Name.CompareTo(ooegNode.Nodes[i].Text) <= 0)
                    {
                        objectNode = ooegNode.Nodes.Insert(i, objectModel.Name, objectModel.Name, ImageManager.IMAGE_ACTIVITY_OBJECT);
                        objectNode.Tag = objectModel;
                        break;
                    }
                }
                if (objectNode == null)
                {
                    objectNode = ooegNode.Nodes.Add(objectModel.Name, objectModel.Name, ImageManager.IMAGE_ACTIVITY_OBJECT);
                    objectNode.Tag = objectModel;
                }

                updateActivityObjectNode(objectNode, objectModel);

                SetChanged(model.ID, true);

                //if (!ooegNode.IsExpanded)
                //    ooegNode.Expand();
            }
        }

        private void dataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addNewDataSource();
        }

        private void addNewDataSource()
        {
            NewDataDialog dialog = new NewDataDialog();
            DialogResult rslt = dialog.ShowDialog(this);

            if (rslt == DialogResult.OK)
            {
                OOMMModel model = getCurrentProjectModel();
                TreeNode dataNode = _DataNodes[model.ID];

                if (dialog.DataType == NewDataDialog.DATATYPE_CSV)
                {
                    OOMMDataSource ds = new OOMMDataSource(dialog.DataName, OOMMDataSourceType.CSV, dialog.FileName);
                    addDataSource(dataNode, ds);
                }
                else if (dialog.DataType == NewDataDialog.DATATYPE_EXCEL)
                {
                    OOMMDataSource ds = new OOMMDataSource(dialog.DataName, OOMMDataSourceType.EXCEL, dialog.FileName, dialog.Sheets);
                    addDataSource(dataNode, ds);
                }
                else if (dialog.DataType == NewDataDialog.DATATYPE_DB)
                {
                    OOMMDataSource ds = new OOMMDataSource(dialog.DataName, OOMMDataSourceType.DATABASE, dialog.DatabaseType, dialog.ConnectionString, dialog.Query);
                    addDataSource(dataNode, ds);
                }

                //if (!dataNode.IsExpanded)
                //    dataNode.Expand();

                SetChanged(model.ID, true);
            }
        }

        private void addDataSource(TreeNode dataNode, OOMMDataSource ds)
        {
            TreeNode node = new TreeNode(ds.Name);

            if (ds.Type == OOMMDataSourceType.CSV)
                node.ImageKey = ImageManager.IMAGE_DATA_OBJECT_CSV;
            else if (ds.Type == OOMMDataSourceType.EXCEL)
                node.ImageKey = ImageManager.IMAGE_DATA_OBJECT_EXCEL;
            else if (ds.Type == OOMMDataSourceType.DATABASE)
                node.ImageKey = ImageManager.IMAGE_DATA_OBJECT_DB;
            node.Tag = ds;

            if (dataNode.Nodes.Count == 0)
            {
                dataNode.Nodes.Add(node);
            }
            else
            {
                bool inserted = false;
                for (int i = 0; i < dataNode.Nodes.Count; i++)
                {
                    if (ds.Name.CompareTo(dataNode.Nodes[i].Name) < 0)
                    {
                        dataNode.Nodes.Insert(i, node);
                        inserted = true;
                        break;
                    }
                }
                if (!inserted)
                    dataNode.Nodes.Add(node);
            }

        }

        private void addUserClass(TreeNode classNode, OOMMUserClass uc)
        {
            TreeNode node = new TreeNode(uc.Name);

            node.ImageKey = ImageManager.IMAGE_USER_CLASS;
            node.Tag = uc;

            if (classNode.Nodes.Count == 0)
            {
                classNode.Nodes.Add(node);
            }
            else
            {
                bool inserted = false;
                for (int i = 0; i < classNode.Nodes.Count; i++)
                {
                    if (uc.Name.CompareTo(classNode.Nodes[i].Name) < 0)
                    {
                        classNode.Nodes.Insert(i, node);
                        inserted = true;
                        break;
                    }
                }
                if (!inserted)
                    classNode.Nodes.Add(node);
            }
        }

        private void entityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addNewEntity();

            TreeNode projectNode = getCurrentProjectNode();
            OOMMModel model = (OOMMModel)projectNode.Tag;
            TreeNode entityNode = _EntityNodes[model.ID];
        }

        private void addNewEntity() {
            TreeNode projectNode = getCurrentProjectNode();
            OOMMModel model = (OOMMModel)projectNode.Tag;
            Modeling.EntityManager.NewEntity(model.ID);
            List<OOMMEntity> entities = Modeling.EntityManager.GetEntities(model.ID);
            Update(projectNode, entities);

            TreeNode entityNode = _EntityNodes[model.ID];
            //if (!entityNode.IsExpanded)
            //    entityNode.Expand();

            SetChanged(model.ID, true);
        }

        private void experimentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tvModel.SelectedNode == null)
                return;

            TreeNode projectNode = getCurrentProjectNode();
            OOMMModel model = (OOMMModel)projectNode.Tag;
            TreeNode expNode = _ExperimentNodes[model.ID];
            List<string> existingExperiments = new List<string>();

            foreach (TreeNode childNode in expNode.Nodes)
            {
                existingExperiments.Add(childNode.Text);
            }

            NewExperimentDialog dialog = new NewExperimentDialog(existingExperiments);
            DialogResult rslt = dialog.ShowDialog(this);

            if (rslt == DialogResult.OK)
            {
                //create new experiment
                string name = dialog.ExperimentName;
                if (dialog.Type == OOMMExperimentType.SIMULATION)
                {
                    OOMMExperiment exp = new OOMMExperiment(dialog.ExperimentName, 3600, OOMMTimeUnit.Seconds, false, 0);
                    addExperiment(expNode, exp);
                }
                else if (dialog.Type == OOMMExperimentType.WHATIF)
                {
                    //TODO 
                }
                else if (dialog.Type == OOMMExperimentType.OPTIMIZATION)
                {
                    //TODO 
                }

                SetChanged(model.ID, true);
            }
        }

        private void addExperiment(TreeNode expNode, OOMMExperiment exp)
        {
            TreeNode node = new TreeNode(exp.Name);

            if (exp.Type == OOMMExperimentType.SIMULATION)
                node.ImageKey = ImageManager.IMAGE_SIMULATION_EXPERIMENT;
            else if (exp.Type == OOMMExperimentType.WHATIF)
                node.ImageKey = ImageManager.IMAGE_WHATIF_ANALYSIS;
            else if (exp.Type == OOMMExperimentType.OPTIMIZATION)
                node.ImageKey = ImageManager.IMAGE_SIMULATION_OPTIMIZATION;
            node.Tag = exp;

            if (expNode.Nodes.Count == 0)
            {
                expNode.Nodes.Add(node);
            }
            else
            {
                bool inserted = false;
                for (int i = 0; i < expNode.Nodes.Count; i++)
                {
                    int compRslt = exp.Name.CompareTo(expNode.Nodes[i].Name);
                    if (compRslt < 0)
                    {
                        expNode.Nodes.Insert(i, node);
                        inserted = true;
                        break;
                    }
                }
                if (!inserted)
                    expNode.Nodes.Add(node);
            }
        }

        private void cClassToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addNewUserClass();
        }

        private void addNewUserClass() { 
            if (tvModel.SelectedNode == null)
                return;

            TreeNode projectNode = getCurrentProjectNode();
            OOMMModel model = (OOMMModel)projectNode.Tag;
            TreeNode classNode = _ClassNodes[model.ID];
            List<string> existingClassList = new List<string>();

            foreach (TreeNode childNode in classNode.Nodes)
            {
                existingClassList.Add(childNode.Text);
            }

            NewUserClassDialog dialog = new NewUserClassDialog(existingClassList);
            DialogResult rslt = dialog.ShowDialog(this);

            if (rslt == DialogResult.OK)
            {
                if (string.IsNullOrEmpty(dialog.NewName))
                    return;
                //create new class
                string name = dialog.NewName;
                OOMMUserClass uc = new OOMMUserClass(name, string.Empty);
                addUserClass(classNode, uc);

                //if (!classNode.IsExpanded)
                //    classNode.Expand();

                SetChanged(model.ID, true);
            }
        }
        #endregion


        #region Context Menu Handlers
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tvModel.SelectedNode == null)
                return;

            if (tvModel.SelectedNode.ImageKey == ImageManager.IMAGE_PROJECT)
            {
                OOMMModel model = GetProject(tvModel.SelectedNode.Text);
                close(model);
            }
        }

        private void close(OOMMModel model)
        {
            if (_IsChanged[model.ID])
            {
                DialogResult rslt = MessageBox.Show(this, "Do you want to save the model before closing it?", "Warning", MessageBoxButtons.YesNoCancel);
                if (rslt == DialogResult.Cancel)
                    return;
                else if (rslt == DialogResult.Yes)
                    FileOperation.Save(model);
            }

            _ProjectNodes.Remove(model.ID);
            _ObjectModelNodes.Remove(model.ID);
            _DataNodes.Remove(model.ID);
            _EntityNodes.Remove(model.ID);
            _ExperimentNodes.Remove(model.ID);
            _IsChanged.Remove(model.ID);

            tvModel.SelectedNode.Remove();

            _Parent.CloseDiagramEditor(model.ID);

        }

        private void exportToTemplateToolstripMenuItem_Click(object sender, EventArgs e)
        {
            if (tvModel.SelectedNode == null)
                return;

            if (tvModel.SelectedNode.Tag == null)
                return;

            if (tvModel.SelectedNode.ImageKey == ImageManager.IMAGE_EVENT_OBJECT ||
                tvModel.SelectedNode.ImageKey == ImageManager.IMAGE_ACTIVITY_OBJECT ||
                tvModel.SelectedNode.ImageKey == ImageManager.IMAGE_STATE_OBJECT)
            {
                ObjectModelLibraryWindow libWin = _Parent.EventObjectLibraryWindow;
                ChooseTemplateDialog dialog = new ChooseTemplateDialog(libWin.Templates);
                DialogResult rslt = dialog.ShowDialog(_Parent);

                if (rslt == DialogResult.OK)
                {
                    TreeNode objectNode = tvModel.SelectedNode;
                    if (tvModel.SelectedNode.ImageKey == ImageManager.IMAGE_EVENT_OBJECT)
                    {
                        OOEGEventObjectModel objectModel = (OOEGEventObjectModel)objectNode.Tag;
                        libWin.ExportToLibrary(dialog.TemplateName, objectModel);
                    }
                    else if (tvModel.SelectedNode.ImageKey == ImageManager.IMAGE_STATE_OBJECT)
                    {
                        OOSGStateObjectModel objectModel = (OOSGStateObjectModel)objectNode.Tag;
                        libWin.ExportToLibrary(dialog.TemplateName, objectModel);
                    }
                    else if (tvModel.SelectedNode.ImageKey == ImageManager.IMAGE_ACTIVITY_OBJECT)
                    {
                        OOAGActivityObjectModel objectModel = (OOAGActivityObjectModel)objectNode.Tag;
                        libWin.ExportToLibrary(dialog.TemplateName, objectModel);
                    }
                }
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tvModel.SelectedNode == null)
                return;
            OOMMModel model = getCurrentProjectModel();

            if (tvModel.SelectedNode.ImageKey == ImageManager.IMAGE_EVENT_OBJECT)
            {
                if (tvModel.SelectedNode.Tag == null)
                    return;

                TreeNode eoNode = tvModel.SelectedNode;
                OOEGEventObjectModel eoModel = (OOEGEventObjectModel)eoNode.Tag;

                EventObjectModelEditor editor = new EventObjectModelEditor(eoModel);

                DialogResult rslt = editor.ShowDialog();
                if (rslt == DialogResult.OK)
                {
                    if (editor.IsModelChanged)
                    {
                        OOEGEventObjectModel updatedEventObject = editor.EventObjectModel;
                        eoNode.Tag = updatedEventObject;

                        updateEventObjectNode(eoNode, updatedEventObject);

                        SetChanged(model.ID, true);
                    }
                }
            }
            else if (tvModel.SelectedNode.ImageKey == ImageManager.IMAGE_STATE_OBJECT)
            {
                if (tvModel.SelectedNode.Tag == null)
                    return;

                TreeNode soNode = tvModel.SelectedNode;
                OOSGStateObjectModel soModel = (OOSGStateObjectModel)soNode.Tag;

                StateObjectModelEditor sttEditor = new StateObjectModelEditor(soModel);

                DialogResult result = sttEditor.ShowDialog();
                if (result == DialogResult.OK)
                {
                    if (sttEditor.IsModelChanged)
                    {
                        OOSGStateObjectModel updatedObject = sttEditor.StateObjectModel;
                        soNode.Tag = updatedObject;

                        updateStateObjectNode(soNode, updatedObject);

                        SetChanged(model.ID, true);
                    }
                }
            }
            else if (tvModel.SelectedNode.ImageKey == ImageManager.IMAGE_ACTIVITY_OBJECT)
            {
                if (tvModel.SelectedNode.Tag == null)
                    return;

                TreeNode soNode = tvModel.SelectedNode;
                OOAGActivityObjectModel aoModel = (OOAGActivityObjectModel)soNode.Tag;

                ActivityObjectModelEditor editor = new ActivityObjectModelEditor(aoModel);

                DialogResult result = editor.ShowDialog();
                if (result == DialogResult.OK)
                {
                    if (editor.IsModelChanged)
                    {
                        OOAGActivityObjectModel updatedObject = editor.ActivityObjectModel;
                        soNode.Tag = updatedObject;

                        updateActivityObjectNode(soNode, updatedObject);

                        SetChanged(model.ID, true);
                    }
                }
            }
            else if (tvModel.SelectedNode.ImageKey == ImageManager.IMAGE_PROJECT)
            {
                _Parent.OpenDiagramEditor(model);
            }
        }

        private void viewCodeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tvModel.SelectedNode == null)
                return;
            OOMMModel model = getCurrentProjectModel();

            if (tvModel.SelectedNode.ImageKey == ImageManager.IMAGE_PROJECT)
            {
                if (tvModel.SelectedNode.Tag == null)
                    return;

                CodeEditor.CodeEditorFrm dialog = new CodeEditor.CodeEditorFrm(model, Application.StartupPath);
                dialog.Show(this);

            }
        }

        private void collapseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tvModel.SelectedNode == null)
                return;

            tvModel.SelectedNode.Collapse();
        }

        private void expandAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tvModel.SelectedNode == null)
                return;

            tvModel.SelectedNode.ExpandAll();
        }

        private object _CopiedObject;
        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tvModel.SelectedNode == null)
                return;

            if (tvModel.SelectedNode.Tag != null)
            {
                _CopiedObject = tvModel.SelectedNode.Tag;
            }
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_CopiedObject == null)
                return;

            OOMMModel projectModel = this.getCurrentProjectModel();
            if (_CopiedObject is OOEGEventObjectModel)
            {
                OOEGEventObjectModel model = (OOEGEventObjectModel)_CopiedObject;
                if (projectModel.FindEventObjectModel(model.Name) != null)
                {
                    List<string> existingNameList = new List<string>();
                    projectModel.EventObjectModels.ForEach(aom => existingNameList.Add(aom.Name));
                    DHKANG.SEA.UI.Dialogs.RenameDialog dialog = new DHKANG.SEA.UI.Dialogs.RenameDialog(model.Name, existingNameList);
                    if (dialog.ShowDialog(this) == DialogResult.OK)
                    {
                        OOEGEventObjectModel pastedModel = model.Clone();
                        pastedModel.Name = dialog.NewName;
                        projectModel.EventObjectModels.Add(pastedModel);
                        Update(projectModel);
                    }
                }
                else
                {
                    projectModel.EventObjectModels.Add(model);
                    Update(projectModel);
                }
            }
            else if (_CopiedObject is OOAGActivityObjectModel)
            {
                OOAGActivityObjectModel model = (OOAGActivityObjectModel)_CopiedObject;

                if (projectModel.FindActivityObjectModel(model.Name) != null)
                {
                    List<string> existingNameList = new List<string>();
                    projectModel.ActivityObjectModels.ForEach(aom => existingNameList.Add(aom.Name));
                    DHKANG.SEA.UI.Dialogs.RenameDialog dialog = new DHKANG.SEA.UI.Dialogs.RenameDialog(model.Name, existingNameList);
                    if (dialog.ShowDialog(this) == DialogResult.OK)
                    {
                        OOAGActivityObjectModel pastedModel = model.Clone();
                        pastedModel.Name = dialog.NewName;
                        projectModel.ActivityObjectModels.Add(pastedModel);
                        Update(projectModel);
                    }
                }
                else
                {
                    projectModel.ActivityObjectModels.Add(model);
                    Update(projectModel);
                }
            }
            else if (_CopiedObject is OOSGStateObjectModel)
            {
                OOSGStateObjectModel model = (OOSGStateObjectModel)_CopiedObject;
                if (projectModel.FindActivityObjectModel(model.Name) != null)
                {
                    List<string> existingNameList = new List<string>();
                    projectModel.StateObjectModels.ForEach(aom => existingNameList.Add(aom.Name));
                    DHKANG.SEA.UI.Dialogs.RenameDialog dialog = new DHKANG.SEA.UI.Dialogs.RenameDialog(model.Name, existingNameList);
                    if (dialog.ShowDialog(this) == DialogResult.OK)
                    {
                        OOSGStateObjectModel pastedModel = model.Clone();
                        pastedModel.Name = dialog.NewName;
                        projectModel.StateObjectModels.Add(pastedModel);
                        Update(projectModel);
                    }
                }
                else
                {
                    projectModel.StateObjectModels.Add(model);
                    Update(projectModel);
                }
            }
            else if (_CopiedObject is OOMMExperiment)
            {
                OOMMExperiment model = (OOMMExperiment)_CopiedObject;
                if (projectModel.FindExperiment(model.Name) != null)
                {
                    List<string> existingNameList = new List<string>();
                    projectModel.Experiments.ForEach(aom => existingNameList.Add(aom.Name));
                    DHKANG.SEA.UI.Dialogs.RenameDialog dialog = new DHKANG.SEA.UI.Dialogs.RenameDialog(model.Name, existingNameList);
                    if (dialog.ShowDialog(this) == DialogResult.OK)
                    {
                        OOMMExperiment pastedModel = model.Clone();
                        pastedModel.Name = dialog.NewName;
                        projectModel.Experiments.Add(pastedModel);
                        Update(projectModel);
                    }
                }
                else
                {
                    projectModel.Experiments.Add(model);
                    Update(projectModel);
                }
            }else if (_CopiedObject is OOMMEntity)
            {
                OOMMEntity entity = (OOMMEntity)_CopiedObject;
                if (projectModel.FindEntity(entity.Name) != null)
                {
                    List<string> existingNameList = new List<string>();
                    projectModel.Entities.ForEach(aom => existingNameList.Add(aom.Name));
                    DHKANG.SEA.UI.Dialogs.RenameDialog dialog = new DHKANG.SEA.UI.Dialogs.RenameDialog(entity.Name, existingNameList);
                    if (dialog.ShowDialog(this) == DialogResult.OK)
                    {
                        OOMMEntity pastedEntity = entity.Clone();
                        pastedEntity.Name = dialog.NewName;
                        projectModel.Entities.Add(pastedEntity);
                        Update(projectModel);
                    }
                }
                else
                {
                    OOMMEntity pastedEntity = entity.Clone();
                    projectModel.Entities.Add(pastedEntity);
                    Update(projectModel);
                }
            }
            else if (_CopiedObject is OOMMUserClass){
                OOMMUserClass userClass = (OOMMUserClass)_CopiedObject;
                if (projectModel.FindUserClass(userClass.Name) != null)
                {
                    List<string> existingNameList = new List<string>();
                    projectModel.UserClasses.ForEach(aom => existingNameList.Add(aom.Name));
                    DHKANG.SEA.UI.Dialogs.RenameDialog dialog = 
                        new DHKANG.SEA.UI.Dialogs.RenameDialog(userClass.Name, existingNameList);
                    if (dialog.ShowDialog(this) == DialogResult.OK)
                    {
                        OOMMUserClass pastedUserClass = userClass.Clone();
                        pastedUserClass.Name = dialog.NewName;
                        projectModel.UserClasses.Add(pastedUserClass);
                        Update(projectModel);
                    }
                }
                else
                {
                    OOMMUserClass pastedUserClass = userClass.Clone();
                    projectModel.UserClasses.Add(pastedUserClass);
                    Update(projectModel);
                }
            }
            else if (_CopiedObject is OOMMDataSource){
                OOMMDataSource ds = (OOMMDataSource)_CopiedObject;
                if (projectModel.FindDataSource(ds.Name) != null)
                {
                    List<string> existingNameList = new List<string>();
                    projectModel.DataSources.ForEach(aom => existingNameList.Add(aom.Name));
                    DHKANG.SEA.UI.Dialogs.RenameDialog dialog = 
                        new DHKANG.SEA.UI.Dialogs.RenameDialog(ds.Name, existingNameList);
                    if (dialog.ShowDialog(this) == DialogResult.OK)
                    {
                        OOMMDataSource pastedDataSource = ds.Clone();
                        pastedDataSource.Name = dialog.NewName;
                        projectModel.DataSources.Add(pastedDataSource);
                        Update(projectModel);
                    }
                }
                else
                {
                    OOMMDataSource pastedDataSource = ds.Clone();
                    projectModel.DataSources.Add(pastedDataSource);
                    Update(projectModel);
                }
            }

 
            _CopiedObject = null;
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tvModel.SelectedNode == null)
                return;

            bool isRemoved = false;
            OOMMModel model = getCurrentProjectModel();

            TreeNode node = tvModel.SelectedNode;
            if (node.ImageKey == ImageManager.IMAGE_ENTITY)
            {
                if (node.Tag != null && node.Tag is OOMMEntity)
                {
                    OOMMEntity entity = (OOMMEntity)node.Tag;
                    Modeling.EntityManager.DeleteEntity(model.ID, entity.Name);

                    node.Remove();

                    isRemoved = true;
                }
            }
            else if (node.ImageKey == ImageManager.IMAGE_DATA_OBJECT_CSV ||
                     node.ImageKey == ImageManager.IMAGE_DATA_OBJECT_DB ||
                     node.ImageKey == ImageManager.IMAGE_DATA_OBJECT_EXCEL)
            {
                if (node.Tag != null && node.Tag is OOMMDataSource)
                {
                    OOMMDataSource ds = (OOMMDataSource)node.Tag;
                    node.Remove();
                    isRemoved = true;
                }
            }
            else if (node.ImageKey == ImageManager.IMAGE_USER_CLASS)
            {
                if (node.Tag != null && node.Tag is OOMMUserClass)
                {
                    OOMMUserClass uc = (OOMMUserClass)node.Tag;
                    node.Remove();
                    isRemoved = true;
                }
            }
            else if (node.ImageKey == ImageManager.IMAGE_EVENT_OBJECT)
            {
                if (node.Tag != null && node.Tag is OOEGEventObjectModel)
                {
                    OOEGEventObjectModel eo = (OOEGEventObjectModel)node.Tag;
                    node.Remove();
                    isRemoved = true;
                }
                //TODO
                //remove event object node and connected scheduing edge
            }
            else if (node.ImageKey == ImageManager.IMAGE_STATE_OBJECT)
            {
                if (node.Tag != null && node.Tag is OOSGStateObjectModel)
                {
                    OOSGStateObjectModel so = (OOSGStateObjectModel)node.Tag;
                    node.Remove();
                    isRemoved = true;
                }
            }
            else if (node.ImageKey == ImageManager.IMAGE_ACTIVITY_OBJECT)
            {
                if (node.Tag != null && node.Tag is OOAGActivityObjectModel)
                {
                    OOAGActivityObjectModel so = (OOAGActivityObjectModel)node.Tag;
                    node.Remove();
                    isRemoved = true;
                }
            }
            else if (node.ImageKey == ImageManager.IMAGE_EXPERIMENT ||
                      node.ImageKey == ImageManager.IMAGE_SIMULATION_EXPERIMENT ||
                      node.ImageKey == ImageManager.IMAGE_SIMULATION_OPTIMIZATION ||
                      node.ImageKey == ImageManager.IMAGE_WHATIF_ANALYSIS)
            {
                if (node.Tag != null && node.Tag is OOMMExperiment)
                {
                    OOMMExperiment exp = (OOMMExperiment)node.Tag;
                    node.Remove();
                    isRemoved = true;
                }
            }

            if (isRemoved)
            {
                SetChanged(model.ID, true);
            }
        }

        private void duplicate(OOMMModel projectModel, OOMMUserClass target)
        {
            if (projectModel.FindUserClass(target.Name) != null)
            {
                List<string> existingNameList = new List<string>();
                projectModel.UserClasses.ForEach(aom => existingNameList.Add(aom.Name));
                DHKANG.SEA.UI.Dialogs.RenameDialog dialog = new DHKANG.SEA.UI.Dialogs.RenameDialog(target.Name, existingNameList);
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    OOMMUserClass pastedObject = target.Clone();
                    pastedObject.Name = dialog.NewName;
                    projectModel.UserClasses.Add(pastedObject);
                    Update(projectModel);
                }
            }
            else
            {
                OOMMUserClass pastedObject = target.Clone();
                projectModel.UserClasses.Add(pastedObject);
                Update(projectModel);
            }
        }

        private void duplicate(OOMMModel projectModel, OOMMEntity target)
        {
            if (projectModel.FindEntity(target.Name) != null)
            {
                List<string> existingNameList = new List<string>();
                projectModel.Entities.ForEach(aom => existingNameList.Add(aom.Name));
                DHKANG.SEA.UI.Dialogs.RenameDialog dialog = new DHKANG.SEA.UI.Dialogs.RenameDialog(target.Name, existingNameList);
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    OOMMEntity pastedObject = target.Clone();
                    pastedObject.Name = dialog.NewName;
                    projectModel.Entities.Add(pastedObject);
                    Update(projectModel);
                }
            }
            else
            {
                OOMMEntity pastedObject = target.Clone();
                projectModel.Entities.Add(pastedObject);
                Update(projectModel);
            }
        }

        private void duplicate(OOMMModel projectModel, OOMMDataSource target)
        {
            if (projectModel.FindDataSource(target.Name) != null)
            {
                List<string> existingNameList = new List<string>();
                projectModel.DataSources.ForEach(aom => existingNameList.Add(aom.Name));
                DHKANG.SEA.UI.Dialogs.RenameDialog dialog = new DHKANG.SEA.UI.Dialogs.RenameDialog(target.Name, existingNameList);
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    OOMMDataSource pastedObject = target.Clone();
                    pastedObject.Name = dialog.NewName;
                    projectModel.DataSources.Add(pastedObject);
                    Update(projectModel);
                }
            }
            else
            {
                OOMMDataSource pastedObject = target.Clone();
                projectModel.DataSources.Add(pastedObject);
                Update(projectModel);
            }
        }
        
        private void duplicate(OOMMModel projectModel, OOEGEventObjectModel objectModel)
        {
            if (projectModel.FindEventObjectModel(objectModel.Name) != null)
            {
                List<string> existingNameList = new List<string>();
                projectModel.EventObjectModels.ForEach(aom => existingNameList.Add(aom.Name));
                DHKANG.SEA.UI.Dialogs.RenameDialog dialog = new DHKANG.SEA.UI.Dialogs.RenameDialog(objectModel.Name, existingNameList);
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    OOEGEventObjectModel pastedModel = objectModel.Clone();
                    pastedModel.Name = dialog.NewName;
                    projectModel.EventObjectModels.Add(pastedModel);
                    Update(projectModel);
                }
            }
            else
            {
                projectModel.EventObjectModels.Add(objectModel);
                Update(projectModel);
            }
        }

        private void duplicate(OOMMModel projectModel, OOAGActivityObjectModel objectModel)
        {
            if (projectModel.FindActivityObjectModel(objectModel.Name) != null)
            {
                List<string> existingNameList = new List<string>();
                projectModel.ActivityObjectModels.ForEach(aom => existingNameList.Add(aom.Name));
                DHKANG.SEA.UI.Dialogs.RenameDialog dialog = new DHKANG.SEA.UI.Dialogs.RenameDialog(objectModel.Name, existingNameList);
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    OOAGActivityObjectModel pastedModel = objectModel.Clone();
                    pastedModel.Name = dialog.NewName;
                    projectModel.ActivityObjectModels.Add(pastedModel);
                    Update(projectModel);
                }
            }
            else
            {
                projectModel.ActivityObjectModels.Add(objectModel);
                Update(projectModel);
            }
        }

        private void duplicate(OOMMModel projectModel, OOSGStateObjectModel objectModel)
        {
            if (projectModel.FindActivityObjectModel(objectModel.Name) != null)
            {
                List<string> existingNameList = new List<string>();
                projectModel.StateObjectModels.ForEach(aom => existingNameList.Add(aom.Name));
                DHKANG.SEA.UI.Dialogs.RenameDialog dialog = new DHKANG.SEA.UI.Dialogs.RenameDialog(objectModel.Name, existingNameList);
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    OOSGStateObjectModel pastedModel = objectModel.Clone();
                    pastedModel.Name = dialog.NewName;
                    projectModel.StateObjectModels.Add(pastedModel);
                    Update(projectModel);
                }
            }
            else
            {
                projectModel.StateObjectModels.Add(objectModel);
                Update(projectModel);
            }
        }

        private void duplicateProjectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tvModel.SelectedNode == null)
                return;

            OOMMModel projectModel = getCurrentProjectModel();

            TreeNode node = tvModel.SelectedNode;
            if (node.ImageKey == ImageManager.IMAGE_PROJECT)
            {
                duplicate(projectModel);
            }
            else if (node.ImageKey == ImageManager.IMAGE_EVENT_OBJECT)
            {
                if (node.Tag != null && node.Tag is OOEGEventObjectModel)
                {
                    OOEGEventObjectModel objectModel = (OOEGEventObjectModel)node.Tag;
                    duplicate(projectModel, objectModel);
                }
            }
            else if (node.ImageKey == ImageManager.IMAGE_STATE_OBJECT)
            {
                if (node.Tag != null && node.Tag is OOSGStateObjectModel)
                {
                    OOSGStateObjectModel objectModel = (OOSGStateObjectModel)node.Tag;
                    duplicate(projectModel, objectModel);
                }
            }
            else if (node.ImageKey == ImageManager.IMAGE_ACTIVITY_OBJECT)
            {
                if (node.Tag != null && node.Tag is OOAGActivityObjectModel)
                {
                    OOAGActivityObjectModel objectModel = (OOAGActivityObjectModel)node.Tag;
                    duplicate(projectModel, objectModel);
                }
            }
            else if (node.ImageKey == ImageManager.IMAGE_USER_CLASS)
            {
                if (node.Tag != null && node.Tag is OOMMUserClass)
                {
                    OOMMUserClass target = (OOMMUserClass)node.Tag;
                    duplicate(projectModel, target);
                }
            }
            else if (node.ImageKey == ImageManager.IMAGE_ENTITY)
            {
                if (node.Tag != null && node.Tag is OOMMEntity)
                {
                    OOMMEntity target = (OOMMEntity)node.Tag;
                    duplicate(projectModel, target);
                }
            }
            else if (node.ImageKey == ImageManager.IMAGE_DATA_OBJECT_CSV ||
                     node.ImageKey == ImageManager.IMAGE_DATA_OBJECT_EXCEL ||
                     node.ImageKey == ImageManager.IMAGE_DATA_OBJECT_DB)
            {
                if (node.Tag != null && node.Tag is OOMMDataSource)
                {
                    OOMMDataSource target = (OOMMDataSource)node.Tag;
                    duplicate(projectModel, target);
                }
            }
        }

        private void duplicate(OOMMModel model)
        {
            List<string> existingNameList = new List<string>();
            this.Projects.ForEach(p => existingNameList.Add(p.Name));

            DHKANG.SEA.UI.Dialogs.RenameDialog dialog = new DHKANG.SEA.UI.Dialogs.RenameDialog(model.Name, existingNameList);
            if (dialog.ShowDialog(this) == DialogResult.OK)
            {
                OOMMModel newModel = new OOMMModel(dialog.NewName, model.Description, model.Creator);

                model.ActivityObjectModels.ForEach(m => newModel.ActivityObjectModels.Add(m));
                model.BarCharts.ForEach(m => newModel.BarCharts.Add(m));
                model.Entities.ForEach(m => newModel.Entities.Add(m));
                model.EventObjectModels.ForEach(m => newModel.EventObjectModels.Add(m));
                model.Experiments.ForEach(m => newModel.Experiments.Add(m));
                model.Properties.ForEach(m => newModel.Properties.Add(m));
                model.StateObjectModels.ForEach(m => newModel.StateObjectModels.Add(m));
                model.UserClasses.ForEach(m => newModel.UserClasses.Add(m));

                newModel.ObjectInteractionDiagram = new OOMMObjectInteractionDiagram();
                model.ObjectInteractionDiagram.BarCharts.ForEach(m => newModel.ObjectInteractionDiagram.BarCharts.Add(m));
                model.ObjectInteractionDiagram.DataAssociations.ForEach(m => newModel.ObjectInteractionDiagram.DataAssociations.Add(m));
                model.ObjectInteractionDiagram.DataSetNodes.ForEach(m => newModel.ObjectInteractionDiagram.DataSetNodes.Add(m));
                model.ObjectInteractionDiagram.DataSourceNodes.ForEach(m => newModel.ObjectInteractionDiagram.DataSourceNodes.Add(m));
                model.ObjectInteractionDiagram.Labels.ForEach(m => newModel.ObjectInteractionDiagram.Labels.Add(m));
                model.ObjectInteractionDiagram.ObjectInteractionEdges.ForEach(m => newModel.ObjectInteractionDiagram.ObjectInteractionEdges.Add(m));
                model.ObjectInteractionDiagram.ObjectNodes.ForEach(m => newModel.ObjectInteractionDiagram.ObjectNodes.Add(m));
                model.ObjectInteractionDiagram.PieCharts.ForEach(m => newModel.ObjectInteractionDiagram.PieCharts.Add(m));
                model.ObjectInteractionDiagram.Plots.ForEach(m => newModel.ObjectInteractionDiagram.Plots.Add(m));
                model.ObjectInteractionDiagram.StateVariableUpdateEdges.ForEach(m => newModel.ObjectInteractionDiagram.StateVariableUpdateEdges.Add(m));
                model.ObjectInteractionDiagram.StatisticsNodes.ForEach(m => newModel.ObjectInteractionDiagram.StatisticsNodes.Add(m));
                model.ObjectInteractionDiagram.Texts.ForEach(m => newModel.ObjectInteractionDiagram.Texts.Add(m));
                model.ObjectInteractionDiagram.TimePlots.ForEach(m => newModel.ObjectInteractionDiagram.TimePlots.Add(m));

                model.ObjectInteractionDiagram.DonutCharts.ForEach(m => newModel.ObjectInteractionDiagram.DonutCharts.Add(m));
                model.ObjectInteractionDiagram.Histograms.ForEach(m => newModel.ObjectInteractionDiagram.Histograms.Add(m));
                model.ObjectInteractionDiagram.ScatterCharts.ForEach(m => newModel.ObjectInteractionDiagram.ScatterCharts.Add(m));
                model.ObjectInteractionDiagram.Tiles.ForEach(m => newModel.ObjectInteractionDiagram.Tiles.Add(m));
                Update(newModel);
            }

        }

        #endregion

        #region Context Menu Handlers - Simulation Experiment 
        private void runToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /*
            if (tvModel.SelectedNode == null ||
                !(tvModel.SelectedNode.Tag is OOEGExperiment))
                return;

            OOEGExperiment exp = (OOEGExperiment)tvModel.SelectedNode.Tag;

            OOEGEventGraphModel model = this.GetProject(this.CurrentProject);
            //check syntax of the model
            if (!_Parent.CheckSyntax(model))
            {
                SimulationEditor window = new SimulationEditor(model, exp);
                window.StartPosition = FormStartPosition.CenterParent;

                //window.MdiParent = this;
                //window.WindowState = FormWindowState.Maximized;
                window.Show();
            }
            */
        }

        private void removeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tvModel.SelectedNode == null)
                return;

            TreeNode node = tvModel.SelectedNode;
            OOMMModel model = getCurrentProjectModel();

            if (node.ImageKey == ImageManager.IMAGE_SIMULATION_EXPERIMENT ||
                node.ImageKey == ImageManager.IMAGE_WHATIF_ANALYSIS ||
                node.ImageKey == ImageManager.IMAGE_SIMULATION_OPTIMIZATION
                )
            {
                if (node.Tag != null && node.Tag is OOMMExperiment)
                {
                    OOMMExperiment exp = (OOMMExperiment)node.Tag;
                    node.Remove();
                    SetChanged(model.ID, true);
                }
            }
        }

        private string getNewName(TreeNode node, Guid id, string name)
        {
            int count = 1;
            string newName = name + "( " + count + ")";
            bool isSameName = false;
            do
            {
                isSameName = false;
                foreach (TreeNode siblingNode in node.Parent.Nodes)
                {
                    OOMMExperiment siblingExp = (OOMMExperiment)siblingNode.Tag;
                    if (siblingExp.ID == id)
                        continue;

                    if (siblingExp.Name == newName)
                    {
                        isSameName = true;
                        count++;
                        newName = name + "( " + count + ")";
                        break;
                    }
                }
            } while (isSameName);

            return newName;
        }

        private void duplicateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tvModel.SelectedNode == null)
                return;

            TreeNode projectNode = getCurrentProjectNode();

            TreeNode node = tvModel.SelectedNode;
            if (node.Tag != null && node.Tag is OOMMExperiment)
            {
                OOMMExperiment exp = (OOMMExperiment)node.Tag;
                OOMMExperiment newExp = null;

                string newName = getNewName(node, exp.ID, exp.Name);
                if (node.ImageKey == ImageManager.IMAGE_SIMULATION_EXPERIMENT)
                {
                    newExp = new OOMMExperiment(newName, exp.EOSTime, exp.EOSTimeUnit, exp.UseRandSeed, exp.RandSeed);
                }
                else if (node.ImageKey == ImageManager.IMAGE_WHATIF_ANALYSIS)
                {
                    //TODO
                }
                else if (node.ImageKey == ImageManager.IMAGE_SIMULATION_OPTIMIZATION)
                {
                    //TODO
                }

                if (newExp != null)
                    this.addExperiment(projectNode, newExp);
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tvModel.SelectedNode == null)
                return;

            TreeNode node = tvModel.SelectedNode;
            if (node.ImageKey == ImageManager.IMAGE_PROJECT)
            {
                OOMMModel projectModel = (OOMMModel)node.Tag;
                FileOperation.Save(projectModel);
                this.SetChanged(projectModel.ID, false);
            }
        }

        private void viewARecentResultToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        #endregion

        #region Getter Methods
        private OOMMModel getCurrentProjectModel()
        {
            OOMMModel rslt = null;
            TreeNode projectNode = this.getCurrentProjectNode();

            rslt = (OOMMModel)projectNode.Tag;

            return rslt;
        }


        private string getCurrentProjectName()
        {
            string project = string.Empty;
            if (tvModel.SelectedNode != null)
            {
                TreeNode node = tvModel.SelectedNode;

                while (node.Level > 0)
                {
                    node = node.Parent;
                }

                project = node.Text;
            }
            return project;
        }

        public TreeNode getProjectNode(Guid project)
        {
            return _ProjectNodes[project];
        }

        public TreeNode getObjectModelNodes(Guid project)
        {
            return _ObjectModelNodes[project];
        }

        public TreeNode getCurrentProjectNode()
        {
            TreeNode project = null;
            if (tvModel.SelectedNode != null)
            {
                TreeNode node = tvModel.SelectedNode;

                while (node.Level > 0)
                {
                    node = node.Parent;
                }

                project = node;
            }
            return project;
        }
        #endregion

        #region Update Methods

        private void sortEntities(Guid projectID, TreeNode targetNode)
        {            
            TreeNode entityNodes = _EntityNodes[projectID];
            entityNodes.Nodes.RemoveAt(targetNode.Index);

            bool isInserted = false;
            for(int i = 0; i < entityNodes.Nodes.Count;i++)
            {
                TreeNode node = entityNodes.Nodes[i];
                if (targetNode.Text.CompareTo(node.Text) < 0)
                {
                    entityNodes.Nodes.Insert(i, targetNode);
                    isInserted = true;
                    break;
                }
            }

            if (!isInserted)
                entityNodes.Nodes.Add(targetNode);

            tvModel.SelectedNode = targetNode;
        }

        public void Update(OOMMEntity changedEntity)
        {
            bool isNameChanged = false;
            TreeNode targetNode = null;
            foreach (Guid projectID in _EntityNodes.Keys)
            {
                TreeNode entityNodes = _EntityNodes[projectID];

                bool isUpdated = false;
                foreach (TreeNode node in entityNodes.Nodes)
                {
                    OOMMEntity targetEntity = (OOMMEntity)node.Tag;

                    if (targetEntity.ID.Equals(changedEntity.ID))
                    {
                        node.Tag = changedEntity;
                        isNameChanged = !(node.Text == changedEntity.Name);
                        node.Text = changedEntity.Name;
                        isUpdated = true;
                        targetNode = node;
                        break;
                    }

                }
                if (isUpdated)
                {
                    this.SetChanged(projectID, true);

                    if (isNameChanged)
                        sortEntities(projectID, targetNode);
                    break;
                }
            }           

            _Parent.CheckSyntax();
        }

        private void sortUserClasses(Guid projectID, TreeNode targetNode)
        {
            TreeNode classNodes = _ClassNodes[projectID];
            classNodes.Nodes.RemoveAt(targetNode.Index);

            bool isInserted = false;
            for (int i = 0; i < classNodes.Nodes.Count; i++)
            {
                TreeNode node = classNodes.Nodes[i];
                if (targetNode.Text.CompareTo(node.Text) < 0)
                {
                    classNodes.Nodes.Insert(i, targetNode);
                    isInserted = true;
                    break;
                }
            }

            if (!isInserted)
                classNodes.Nodes.Add(targetNode);

            tvModel.SelectedNode = targetNode;
        }

        public void Update(OOMMUserClass changedValue)
        {
            bool isNameChanged = false;
            TreeNode targetNode = null;
            foreach (Guid projectID in _ClassNodes.Keys)
            {
                TreeNode classNodes = _ClassNodes[projectID];

                bool isUpdated = false;
                foreach (TreeNode node in classNodes.Nodes)
                {
                    OOMMUserClass targetClass = (OOMMUserClass)node.Tag;

                    if (targetClass.ID.Equals(changedValue.ID))
                    {
                        node.Tag = changedValue;
                        isNameChanged = !(node.Text == changedValue.Name);
                        node.Text = changedValue.Name;
                        isUpdated = true;
                        targetNode = node;
                        break;
                    }

                }
                if (isUpdated)
                {
                    if (isNameChanged)
                        sortUserClasses(projectID, targetNode);

                    this.SetChanged(projectID, true);                    
                    break;
                }
            }

            _Parent.CheckSyntax();
        }

        private void sortDataSources(Guid projectID, TreeNode targetNode)
        {
            TreeNode dataNodes = _DataNodes[projectID];
            dataNodes.Nodes.RemoveAt(targetNode.Index);

            bool isInserted = false;
            for (int i = 0; i < dataNodes.Nodes.Count; i++)
            {
                TreeNode node = dataNodes.Nodes[i];
                if (targetNode.Text.CompareTo(node.Text) < 0)
                {
                    dataNodes.Nodes.Insert(i, targetNode);
                    isInserted = true;
                    break;
                }
            }

            if (!isInserted)
                dataNodes.Nodes.Add(targetNode);

            tvModel.SelectedNode = targetNode;
        }

        public void Update(OOMMDataSource changedValue)
        {
            bool isNameChanged = false;
            TreeNode targetNode = null;

            foreach (Guid projectID in _DataNodes.Keys)
            {
                TreeNode dataNodes = _DataNodes[projectID];

                bool isUpdated = false;
                foreach (TreeNode node in dataNodes.Nodes)
                {
                    OOMMDataSource target = (OOMMDataSource)node.Tag;

                    if (target.ID.Equals(changedValue.ID))
                    {
                        node.Tag = changedValue;
                        node.Text = changedValue.Name;
                        isUpdated = true;

                        isNameChanged = !(node.Text == changedValue.Name);
                        targetNode = node;
                        break;
                    }
                }
                if (isUpdated)
                {
                    if (isNameChanged)
                        sortDataSources(projectID, targetNode);

                    this.SetChanged(projectID, true);
                    break;
                }
            }

            _Parent.CheckSyntax();
        }

        private void sortExperiments(Guid projectID, TreeNode targetNode)
        {
            TreeNode expNodes = _ExperimentNodes[projectID];
            expNodes.Nodes.RemoveAt(targetNode.Index);

            bool isInserted = false;
            for (int i = 0; i < expNodes.Nodes.Count; i++)
            {
                TreeNode node = expNodes.Nodes[i];
                if (targetNode.Text.CompareTo(node.Text) < 0)
                {
                    expNodes.Nodes.Insert(i, targetNode);
                    isInserted = true;
                    break;
                }
            }

            if (!isInserted)
                expNodes.Nodes.Add(targetNode);

            tvModel.SelectedNode = targetNode;
        }

        public void Update(OOMMExperiment changedValue)
        {
            bool isNameChanged = false;
            TreeNode targetNode = null;

            foreach (Guid projectID in _ExperimentNodes.Keys)
            {
                TreeNode expNodes = _ExperimentNodes[projectID];

                bool isUpdated = false;
                foreach (TreeNode node in expNodes.Nodes)
                {
                    OOMMExperiment target = (OOMMExperiment)node.Tag;

                    if (target.ID.Equals(changedValue.ID))
                    {
                        node.Tag = changedValue;
                        node.Text = changedValue.Name;
                        isUpdated = true;

                        isNameChanged = !(node.Text == changedValue.Name);
                        targetNode = node;
                        break;
                    }
                }

                if (isUpdated)
                {
                    if (isNameChanged)
                        sortExperiments(projectID, targetNode);

                    SetChanged(projectID, true);
                    break;
                }

            }

            _Parent.CheckSyntax();
        }

        private TreeNode UpdateObjectModels(TreeNode projectNode, OOMMModel model)
        {
            TreeNode ooegNode = null;
            if (_ObjectModelNodes.ContainsKey(model.ID))
            {
                ooegNode = _ObjectModelNodes[model.ID];
                ooegNode.Nodes.Clear();
            }
            else
            {
                ooegNode = projectNode.Nodes.Add("Model", "Model", ImageManager.IMAGE_OBJECT_MODEL_LIST);
                _ObjectModelNodes.Add(model.ID, ooegNode);
            }

            List<string> objectNameList = new List<string>();
            Dictionary<string, OOMMObjectModel> objectModelList = new Dictionary<string, OOMMObjectModel>();

            foreach (OOEGEventObjectModel eoModel in model.EventObjectModels)
            {
                objectNameList.Add(eoModel.Name);
                objectModelList.Add(eoModel.Name, eoModel);
            }

            foreach (OOSGStateObjectModel soModel in model.StateObjectModels)
            {
                objectNameList.Add(soModel.Name);
                objectModelList.Add(soModel.Name, soModel);
            }

            foreach (OOAGActivityObjectModel aoModel in model.ActivityObjectModels)
            {
                objectNameList.Add(aoModel.Name);
                objectModelList.Add(aoModel.Name, aoModel);
            }

            objectNameList.Sort();
            foreach(string objectName in objectNameList)
            {
                OOMMObjectModel objectModel = objectModelList[objectName];
                TreeNode objectNode = null;

                objectNode = ooegNode.Nodes.Add(objectName, objectName, 4);
                objectNode.Tag = objectModel;

                if (objectModel is OOEGEventObjectModel)
                {
                    objectNode.ImageKey = ImageManager.IMAGE_EVENT_OBJECT;
                    updateEventObjectNode(objectNode, (OOEGEventObjectModel)objectModel);
                }
                else if (objectModel is OOSGStateObjectModel)
                {
                    objectNode.ImageKey = ImageManager.IMAGE_STATE_OBJECT;
                    updateStateObjectNode(objectNode, (OOSGStateObjectModel)objectModel);

                }
                else if (objectModel is OOAGActivityObjectModel)
                {
                    objectNode.ImageKey = ImageManager.IMAGE_ACTIVITY_OBJECT;
                    updateActivityObjectNode(objectNode, (OOAGActivityObjectModel)objectModel);
                }
            }

            /*
            foreach (OOEGEventObjectModel eoModel in model.EventObjectModels)
            {
                TreeNode eoNode = ooegNode.Nodes.Add(eoModel.Name, eoModel.Name, 4);
                eoNode.ImageKey = ImageManager.IMAGE_EVENT_OBJECT;
                eoNode.Tag = eoModel;

                updateEventObjectNode(eoNode, eoModel);
            }

            foreach (OOSGStateObjectModel soModel in model.StateObjectModels)
            {
                TreeNode soNode = ooegNode.Nodes.Add(soModel.Name, soModel.Name, 4);
                soNode.ImageKey = ImageManager.IMAGE_STATE_OBJECT;
                soNode.Tag = soModel;

                updateStateObjectNode(soNode, soModel);
            }

            foreach (OOAGActivityObjectModel aoModel in model.ActivityObjectModels)
            {
                TreeNode aoNode = ooegNode.Nodes.Add(aoModel.Name, aoModel.Name, 4);
                aoNode.ImageKey = ImageManager.IMAGE_ACTIVITY_OBJECT;
                aoNode.Tag = aoModel;

                updateActivityObjectNode(aoNode, aoModel);
            }
            */
            return ooegNode;
        }

        private TreeNode Update(TreeNode projectNode, List<OOMMEntity> entities)
        {
            TreeNode entityNode = null;
            OOMMModel model = (OOMMModel)projectNode.Tag;

            if (_EntityNodes.ContainsKey(model.ID))
            {
                entityNode = _EntityNodes[model.ID];
                entityNode.Nodes.Clear();
            }
            else
            {
                entityNode = projectNode.Nodes.Add("Entities", "Entities", ImageManager.IMAGE_ENTITY_LIST);
                _EntityNodes.Add(model.ID, entityNode);
            }

            entities.Sort(delegate (OOMMEntity x, OOMMEntity y)
            {
                return x.Name.CompareTo(y.Name);
            });

            foreach (OOMMEntity entity in entities)
            {
                TreeNode node = new TreeNode(entity.Name);
                node.ImageKey = ImageManager.IMAGE_ENTITY;
                node.Tag = entity;

                entityNode.Nodes.Add(node);
            }

            return entityNode;
        }

        private TreeNode Update(TreeNode projectNode, List<OOMMDataSource> dataSources)
        {
            TreeNode dataNode = null;
            OOMMModel model = (OOMMModel)projectNode.Tag;

            if (_DataNodes.ContainsKey(model.ID))
            {
                dataNode = _DataNodes[model.ID];
                dataNode.Nodes.Clear();
            }
            else
            {
                dataNode = projectNode.Nodes.Add("Data", "Data", ImageManager.IMAGE_DATA_LIST);
                _DataNodes.Add(model.ID, dataNode);
            }

            dataSources.Sort(delegate (OOMMDataSource x, OOMMDataSource y)
            {
                return x.Name.CompareTo(y.Name);
            });

            foreach (OOMMDataSource ds in dataSources)
            {
                addDataSource(dataNode, ds);
            }

            return dataNode;
        }

        private TreeNode Update(TreeNode projectNode, List<OOMMUserClass> classes)
        {
            TreeNode classNode = null;
            OOMMModel model = (OOMMModel)projectNode.Tag;

            if (_ClassNodes.ContainsKey(model.ID))
            {
                classNode = _ClassNodes[model.ID];
                classNode.Nodes.Clear();
            }
            else
            {
                classNode = projectNode.Nodes.Add("Classes", "Classes", ImageManager.IMAGE_USER_CLASS_LIST);
                classNode.ToolTipText = "User-defined C# classes";
                _ClassNodes.Add(model.ID, classNode);
            }

            classes.Sort(delegate (OOMMUserClass x, OOMMUserClass y)
            {
                return x.Name.CompareTo(y.Name);
            });

            foreach (OOMMUserClass uc in classes)
            {
                addUserClass(classNode, uc);
            }

            return classNode;
        }

        private TreeNode Update(TreeNode projectNode, List<OOMMExperiment> experiments)
        {
            TreeNode expNode = null;
            OOMMModel model = (OOMMModel)projectNode.Tag;

            if (_ExperimentNodes.ContainsKey(model.ID))
            {
                expNode = _ExperimentNodes[model.ID];
                expNode.Nodes.Clear();
            }
            else
            {
                expNode = projectNode.Nodes.Add("Experiments", "Experiments", ImageManager.IMAGE_EXPERIMENT_LIST);
                _ExperimentNodes.Add(model.ID, expNode);
            }

            experiments.Sort(delegate (OOMMExperiment x, OOMMExperiment y)
            {
                return x.Name.CompareTo(y.Name);
            });

            foreach (OOMMExperiment exp in experiments)
            {
                addExperiment(expNode, exp);
            }

            return expNode;
        }

        #endregion

        #region Drag & Drop Methods
        bool privateDrag;
        private void tvModel_ItemDrag(object sender, ItemDragEventArgs e)
        {
            privateDrag = true;
            DoDragDrop(e.Item, DragDropEffects.Copy);
            privateDrag = false;
        }

        private void tvModel_DragEnter(object sender, DragEventArgs e)
        {
            if (privateDrag) e.Effect = e.AllowedEffect;
        }
        #endregion

        #region Save Methods
        /// <summary>
        /// Save all the opened project
        /// </summary>
        public void SaveAll()
        {
            foreach (Guid projectID in _ProjectNodes.Keys)
            {
                OOMMModel model = GetProject(projectID);
                XmlSerializer serializer = new XmlSerializer(typeof(OOMMModel));
                using (TextWriter writer = new StreamWriter(model.FileName))
                {
                    serializer.Serialize(writer, model);
                }
                _Parent.ErrorWindow.CheckSyntax(model);
            }

            ActionManager.Act("Model Explorer", "All projects are saved successfully.");
        }

        /// <summary>
        /// Save the currently-selected project
        /// </summary>
        public void Save(string fileName)
        {
            string projectName = getCurrentProjectName();
            OOMMModel model = GetProject(projectName);
            model.FileName = fileName;

            XmlSerializer serializer = new XmlSerializer(typeof(OOMMModel));
            using (TextWriter writer = new StreamWriter(fileName))
            {
                serializer.Serialize(writer, model);
            }

            //setChange(false);

            _Parent.ErrorWindow.CheckSyntax(model);

            ActionManager.Act("Model Explorer", "Project <" + projectName + " is saved successfully.");
        }

        public void Save(string projectName, string fileName)
        {
            OOMMModel model = GetProject(projectName);
            model.FileName = fileName;

            XmlSerializer serializer = new XmlSerializer(typeof(OOMMModel));
            using (TextWriter writer = new StreamWriter(fileName))
            {
                serializer.Serialize(writer, model);
            }

            //setChange(false);

            _Parent.ErrorWindow.CheckSyntax(model);

            ActionManager.Act("Model Explorer", "Project <" + projectName + " is saved successfully.");
        }

        public void Save(OOMMModel model, string fileName)
        {
            model.FileName = fileName;

            XmlSerializer serializer = new XmlSerializer(typeof(OOMMModel));
            using (TextWriter writer = new StreamWriter(fileName))
            {
                serializer.Serialize(writer, model);
            }

            //setChange(false);

            _Parent.ErrorWindow.CheckSyntax(model);

            ActionManager.Act("Model Explorer", "Project <" + model.Name + " is saved successfully.");
        }

        /// <summary>
        /// Close the currently-seclted projects
        /// </summary>
        public void Close()
        {
            if (tvModel.SelectedNode == null)
                return;

            if (tvModel.SelectedNode.ImageKey == ImageManager.IMAGE_PROJECT)
            {
                OOMMModel model = GetProject(tvModel.SelectedNode.Text);
                close(model);
            }
        }


        #endregion

        #region Context Menu Handler - Simulation Run
        private void fastForwardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tvModel.SelectedNode == null ||
                !(tvModel.SelectedNode.Tag is OOMMExperiment))
                return;

            OOMMExperiment exp = (OOMMExperiment)tvModel.SelectedNode.Tag;
            exp.FastForward = true;
            exp.Parallel = false;

            showSimulationEditor(exp);
        }

        private void scaledRealTimeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tvModel.SelectedNode == null ||
                !(tvModel.SelectedNode.Tag is OOMMExperiment))
                return;

            OOMMExperiment exp = (OOMMExperiment)tvModel.SelectedNode.Tag;
            exp.FastForward = false;
            exp.Parallel = false;

            showSimulationEditor(exp);
        }

        private void parallelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tvModel.SelectedNode == null ||
                !(tvModel.SelectedNode.Tag is OOMMExperiment))
                return;

            OOMMExperiment exp = (OOMMExperiment)tvModel.SelectedNode.Tag;
            exp.Parallel = true;
            exp.FastForward = false;

            showSimulationEditor(exp);
        }

        private void showSimulationEditor(OOMMExperiment exp)
        {
            OOMMModel model = this.GetProject(this.CurrentProject);

            if (!_Parent.CheckSyntax(model))
            {
                SimulationEditor window = new SimulationEditor(model, exp);
                window.StartPosition = FormStartPosition.CenterParent;
                window.Show();
            }
        }
        #endregion

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// paste the object model into the project
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void omlPasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            handlePasteOperation();
        }

        private void handlePasteOperation()
        {
            if (_CopiedObject == null)
                return;

            OOMMModel projectModel = this.getCurrentProjectModel();
            if (_CopiedObject is OOEGEventObjectModel)
            {
                OOEGEventObjectModel model = (OOEGEventObjectModel)_CopiedObject;
                if (projectModel.FindEventObjectModel(model.Name) != null)
                {
                    List<string> existingNameList = new List<string>();
                    projectModel.EventObjectModels.ForEach(aom => existingNameList.Add(aom.Name));
                    DHKANG.SEA.UI.Dialogs.RenameDialog dialog = new DHKANG.SEA.UI.Dialogs.RenameDialog(model.Name, existingNameList);
                    if (dialog.ShowDialog(this) == DialogResult.OK)
                    {
                        OOEGEventObjectModel pastedModel = model.Clone();
                        pastedModel.Name = dialog.NewName;
                        projectModel.EventObjectModels.Add(pastedModel);
                        Update(projectModel);
                    }
                }
                else
                {
                    projectModel.EventObjectModels.Add(model);
                    Update(projectModel);
                }
            }
            else if (_CopiedObject is OOAGActivityObjectModel)
            {
                OOAGActivityObjectModel model = (OOAGActivityObjectModel)_CopiedObject;

                if (projectModel.FindActivityObjectModel(model.Name) != null)
                {
                    List<string> existingNameList = new List<string>();
                    projectModel.ActivityObjectModels.ForEach(aom => existingNameList.Add(aom.Name));
                    DHKANG.SEA.UI.Dialogs.RenameDialog dialog = new DHKANG.SEA.UI.Dialogs.RenameDialog(model.Name, existingNameList);
                    if (dialog.ShowDialog(this) == DialogResult.OK)
                    {
                        OOAGActivityObjectModel pastedModel = model.Clone();
                        pastedModel.Name = dialog.NewName;
                        projectModel.ActivityObjectModels.Add(pastedModel);
                        Update(projectModel);
                    }
                }
                else
                {
                    projectModel.ActivityObjectModels.Add(model);
                    Update(projectModel);
                }
            }
            else if (_CopiedObject is OOSGStateObjectModel)
            {
                OOSGStateObjectModel model = (OOSGStateObjectModel)_CopiedObject;
                if (projectModel.FindActivityObjectModel(model.Name) != null)
                {
                    List<string> existingNameList = new List<string>();
                    projectModel.StateObjectModels.ForEach(aom => existingNameList.Add(aom.Name));
                    DHKANG.SEA.UI.Dialogs.RenameDialog dialog = new DHKANG.SEA.UI.Dialogs.RenameDialog(model.Name, existingNameList);
                    if (dialog.ShowDialog(this) == DialogResult.OK)
                    {
                        OOSGStateObjectModel pastedModel = model.Clone();
                        pastedModel.Name = dialog.NewName;
                        projectModel.StateObjectModels.Add(pastedModel);
                        Update(projectModel);
                    }
                }
                else
                {
                    projectModel.StateObjectModels.Add(model);
                    Update(projectModel);
                }
            }
            else if (_CopiedObject is OOMMExperiment)
            {
                OOMMExperiment model = (OOMMExperiment)_CopiedObject;
                if (projectModel.FindExperiment(model.Name) != null)
                {
                    List<string> existingNameList = new List<string>();
                    projectModel.Experiments.ForEach(aom => existingNameList.Add(aom.Name));
                    DHKANG.SEA.UI.Dialogs.RenameDialog dialog = new DHKANG.SEA.UI.Dialogs.RenameDialog(model.Name, existingNameList);
                    if (dialog.ShowDialog(this) == DialogResult.OK)
                    {
                        OOMMExperiment pastedModel = model.Clone();
                        pastedModel.Name = dialog.NewName;
                        projectModel.Experiments.Add(pastedModel);
                        Update(projectModel);
                    }
                }
                else
                {
                    projectModel.Experiments.Add(model);
                    Update(projectModel);
                }
            }
            else if (_CopiedObject is OOMMEntity)
            {
                OOMMEntity entity = (OOMMEntity)_CopiedObject;
                if (projectModel.FindEntity(entity.Name) != null)
                {
                    List<string> existingNameList = new List<string>();
                    projectModel.Entities.ForEach(aom => existingNameList.Add(aom.Name));
                    DHKANG.SEA.UI.Dialogs.RenameDialog dialog = new DHKANG.SEA.UI.Dialogs.RenameDialog(entity.Name, existingNameList);
                    if (dialog.ShowDialog(this) == DialogResult.OK)
                    {
                        OOMMEntity pastedEntity = entity.Clone();
                        pastedEntity.Name = dialog.NewName;
                        projectModel.Entities.Add(pastedEntity);
                        Update(projectModel);
                    }
                }
                else
                {
                    OOMMEntity pastedEntity = entity.Clone();
                    projectModel.Entities.Add(pastedEntity);
                    Update(projectModel);
                }
            }
            else if (_CopiedObject is OOMMUserClass)
            {
                OOMMUserClass userClass = (OOMMUserClass)_CopiedObject;
                if (projectModel.FindUserClass(userClass.Name) != null)
                {
                    List<string> existingNameList = new List<string>();
                    projectModel.UserClasses.ForEach(aom => existingNameList.Add(aom.Name));
                    DHKANG.SEA.UI.Dialogs.RenameDialog dialog =
                        new DHKANG.SEA.UI.Dialogs.RenameDialog(userClass.Name, existingNameList);
                    if (dialog.ShowDialog(this) == DialogResult.OK)
                    {
                        OOMMUserClass pastedUserClass = userClass.Clone();
                        pastedUserClass.Name = dialog.NewName;
                        projectModel.UserClasses.Add(pastedUserClass);
                        Update(projectModel);
                    }
                }
                else
                {
                    OOMMUserClass pastedUserClass = userClass.Clone();
                    projectModel.UserClasses.Add(pastedUserClass);
                    Update(projectModel);
                }
            }
            else if (_CopiedObject is OOMMDataSource)
            {
                OOMMDataSource ds = (OOMMDataSource)_CopiedObject;
                if (projectModel.FindDataSource(ds.Name) != null)
                {
                    List<string> existingNameList = new List<string>();
                    projectModel.DataSources.ForEach(aom => existingNameList.Add(aom.Name));
                    DHKANG.SEA.UI.Dialogs.RenameDialog dialog =
                        new DHKANG.SEA.UI.Dialogs.RenameDialog(ds.Name, existingNameList);
                    if (dialog.ShowDialog(this) == DialogResult.OK)
                    {
                        OOMMDataSource pastedDataSource = ds.Clone();
                        pastedDataSource.Name = dialog.NewName;
                        projectModel.DataSources.Add(pastedDataSource);
                        Update(projectModel);
                    }
                }
                else
                {
                    OOMMDataSource pastedDataSource = ds.Clone();
                    projectModel.DataSources.Add(pastedDataSource);
                    Update(projectModel);
                }
            }


            _CopiedObject = null;
        }
    }
}
