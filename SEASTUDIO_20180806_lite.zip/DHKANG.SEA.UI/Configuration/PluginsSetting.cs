﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.UI.Configuration
{
    public class PluginsSetting
    {
        public List<string> PluginsNamespaces
        {
            get
            {
                List<string> rslt = new List<string>();

                //TODO read the types provided by the plugins from the configuration file
                rslt.Add("DHKANG.Plugins.JobShop");

                return rslt;
            }
        }

        /*
        public List<string> PluginsTypes
        {
            get
            {
                List<string> rslt = new List<string>();

                //TODO read the types provided by the plugins from the configuration file

                rslt.Add("DHKANG.Plugins.JobShop.Process");
                rslt.Add("DHKANG.Plugins.JobShop.ProcessStep");
                rslt.Add("DHKANG.Plugins.JobShop.ProcessFlow");
                rslt.Add("DHKANG.Plugins.JobShop.Resource");
                rslt.Add("DHKANG.Plugins.JobShop.Dispatcher");


                return rslt;
            }
        }
        */

        public List<string> PluginsDLLs
        {
            get
            {
                List<string> rslt = new List<string>();

                //TODO read the dlls provided by the plugins from the configuration file

                rslt.Add("DHKANG.Plugins.JobShop.dll");

                return rslt;
            }
        }
    }
    /*
    public class PluginsSetting : ApplicationSettingsBase
    {
        [UserScopedSetting()]
        [DefaultSettingValue("white")]
        public Color BackgroundColor
        {
            get
            {
                return ((Color)this["BackgroundColor"]);
            }
            set
            {
                this["BackgroundColor"] = (Color)value;
            }
        }

        [UserScopedSetting()]
        [DefaultSettingValue("white")]
        public Color ForegroundColor
        {
            get
            {
                return ((Color)this["ForegroundColor"]);
            }
            set
            {
                this["ForegroundColor"] = (Color)value;
            }
        }
    }
    */

}
