﻿using DHKANG.SEA.Model;
using DHKANG.SEA.UI.Simulation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DHKANG.SEA.UI.Menu
{
    public class SimulationMenuEventHandler
    {
        #region Member Variables
        private MainUI _Parent;
        #endregion

        #region Constructor
        public SimulationMenuEventHandler(MainUI parent)
        {
            _Parent = parent;
        }
        #endregion

        #region Methods
        public void OnMenuItemClick(object sender, EventArgs e)
        {
            ToolStripMenuItem menuItem = (ToolStripMenuItem)sender;

            string menuName = menuItem.Text.Replace("&", "").ToLower();

            //TODO
            //- Adopt the command design pattern for the flexiblity
            switch (menuName)
            {
                case "run": handleRunMenuItem(); break;
                
            }
        }

        private void handleRunMenuItem()
        {
            Guid projectID = _Parent.getCurrentProject();
            if (projectID.Equals(Guid.Empty))
                return;

            OOMMModel model = _Parent.ModelExplorer.GetProject(projectID);
            if (_Parent.CheckSyntax(model))
            {
                SimulationEditor window = new SimulationEditor(model);
                //window.MdiParent = this;
                //window.WindowState = FormWindowState.Maximized;
                window.Show();
            }            
        }
        #endregion
    }
}
