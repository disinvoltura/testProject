﻿using DHKANG.SEA.UI.Simulation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DHKANG.SEA.UI.Menu
{
    public class ViewMenuEventHandler
    {
        #region Member Variables
        private MainUI _Parent;
        #endregion

        #region Constructor
        public ViewMenuEventHandler(MainUI parent)
        {
            _Parent = parent;
        }
        #endregion

        #region Methods
        public void OnMenuItemClick(object sender, EventArgs e)
        {
            ToolStripMenuItem menuItem = (ToolStripMenuItem)sender;

            string menuName = menuItem.Text.Replace("&", "").ToLower();

            switch (menuName)
            {
                case "model explorer": handleModelExplorerMenuItem(); break;
                case "event object library": handleEventObjectLibraryMenuItem(); break;
                case "output view library": handleOutputViewLibraryMenuItem(); break;
                case "output": handleOutputMenuItem(); break;
                case "error list": handleErrorListMenuItem(); break;
                case "properties": handlePropertiesMenuItem(); break;

            }
        }

        private void handleModelExplorerMenuItem()
        {
            _Parent.ModelExplorer.Activate();
        }

        private void handleEventObjectLibraryMenuItem()
        {
            _Parent.EventObjectLibraryWindow.Activate();
        }

        private void handleOutputViewLibraryMenuItem()
        {
            _Parent.OutputViewLibraryWindow.Activate();
        }

        private void handleOutputMenuItem()
        {
            _Parent.OutputWindow.Activate();
        }

        private void handleErrorListMenuItem()
        {
            _Parent.ErrorWindow.Activate();
        }

        private void handlePropertiesMenuItem()
        {
            _Parent.PropertiesWindow.Activate();
        }
        #endregion
    }
}
