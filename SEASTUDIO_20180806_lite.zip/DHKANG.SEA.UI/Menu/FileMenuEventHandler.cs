﻿using DHKANG.SEA.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace DHKANG.SEA.UI.Menu
{
    public class FileMenuEventHandler
    {
        #region Member Variables
        private MainUI _Parent;
        private Dictionary<Guid, string> _FileNames;

        #endregion

        #region Constructor
        public FileMenuEventHandler(MainUI parent)
        {
            _Parent = parent;
            _FileNames = new Dictionary<Guid, string>();
        }
        #endregion

        #region Methods
        public void OnMenuItemClick(object sender, EventArgs e)
        {
            ToolStripMenuItem menuItem = (ToolStripMenuItem)sender;

            string menuName = menuItem.Text.Replace("&", "").ToLower();

            //TODO
            //- Adopt the command design pattern for the flexiblity
            switch (menuName)
            {
                case "new": handleNewMenuItem(); break;
                case "open": handleOpenMenuItem(); break;
                case "save": handleSaveMenuItem(); break;
                case "save all": handleSaveAllMenuItem(); break;
                case "save as": handleSaveAsMenuItem(); break;
                case "close": handleCloseMenuItem(); break;
                case "exit": handleExitMenuItem(); break;
            }
        }
        #endregion

        #region File Menu Handlers
        private void handleNewMenuItem()
        {
            D_Properties dialog = new D_Properties();

            DialogResult rslt = dialog.ShowDialog(_Parent);

            if (rslt == System.Windows.Forms.DialogResult.OK)
            {
                OOMMModel model =
                    new OOMMModel(
                        dialog.ModelName,
                        dialog.ModelDescription,
                        dialog.ModelCreator);

                _Parent.ModelExplorer.Update(model);

                _Parent.ableMenu(true);
            }
        }

        private void OnOOEGModelEditorClosed(object sender, FormClosedEventArgs e)
        {
            if (_Parent.MdiChildren.Length == 0)
            {
                _Parent.ableMenu(false);
            }
        }

        private void handleOpenMenuItem()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "OOMM Model Files (*.xml)|*.xml|All files (*.*)|*.*";
            ofd.DefaultExt = "xml";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                foreach (string loc in ofd.FileNames)
                {
                    FileOperation.OpenOOMMModelEditor(loc);
                }
            }

            _Parent.ableMenu(true);
        }

        private void handleSaveMenuItem()
        {
            if (_Parent.ModelExplorer != null)
            {
                Guid projectid = _Parent.ModelExplorer.CurrentProject;
                if (projectid == null)
                    return;

                OOMMModel model = _Parent.ModelExplorer.GetProject(projectid);

                FileOperation.Save(model);
                /*
                if (_FileNames.ContainsKey(model.ID))
                {
                    FileOperation.Save(model, _FileNames[model.ID]);
                    _Parent.ErrorWindow.CheckSyntax(model);
                }
                else
                    handleSaveAsMenuItem();
                */
            }
        }

        private void handleSaveAllMenuItem()
        {
            if (_Parent.ModelExplorer != null)
                _Parent.ModelExplorer.SaveAll();

            foreach (OOMMModel model in _Parent.ModelExplorer.Projects)
            {
                FileOperation.Save(model);
                /*
                if (_FileNames.ContainsKey(model.ID))
                {
                    _Parent.ModelExplorer.Save(model.Name);
                }
                else
                {
                    SaveFileDialog sfd = new SaveFileDialog();
                    sfd.Filter = "OOMM model files (*.xml)|*.xml|All files (*.*)|*.*";
                    sfd.DefaultExt = "xml";
                    sfd.FileName = model.Name.Replace("*", "") + ".xml";

                    if (sfd.ShowDialog() == DialogResult.OK)
                    {
                        string loc = sfd.FileName;
                        //_Parent.ModelExplorer.Save(model, loc);
                        FileOperation.Save(model, loc);

                        _Parent.ErrorWindow.CheckSyntax(model);

                        if (_FileNames.ContainsKey(model.ID))
                            _FileNames[model.ID] = loc;
                        else
                            _FileNames.Add(model.ID, loc);
                    }
                }
                */
            }
            ActionManager.Act("Model Explorer", "All projects are saved successfully.");
        }

        private void handleSaveAsMenuItem()
        {
            if (_Parent.ModelExplorer == null)
                return;

            Guid projectid = _Parent.ModelExplorer.CurrentProject;
            if (projectid == null || projectid == Guid.Empty)
                return;

            OOMMModel model = _Parent.ModelExplorer.GetProject(projectid);

            FileOperation.SaveAs(model);

            /*
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "OOMM model files (*.xml)|*.xml|All files (*.*)|*.*";
            sfd.DefaultExt = "xml";


            string fileName = "";
            if (_FileNames.ContainsKey(model.ID))
                fileName = _FileNames[model.ID];

            if (string.IsNullOrEmpty(fileName))
                sfd.FileName = model.Name.Replace("*", "") + ".xml";
            else
                sfd.FileName = fileName;

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string loc = sfd.FileName;
                FileOperation.Save(model, loc);

                _Parent.ErrorWindow.CheckSyntax(model);
                if (_FileNames.ContainsKey(model.ID))
                    _FileNames[model.ID] = loc;
                else
                    _FileNames.Add(model.ID, loc);
            }
            */
        }

        private void handleCloseMenuItem()
        {
            if (_Parent.ModelExplorer == null)
                return;

            Guid projectid = _Parent.ModelExplorer.CurrentProject;
            if (projectid == null || projectid == Guid.Empty)
                return;

            OOMMModel model = _Parent.ModelExplorer.GetProject(projectid);
            FileOperation.Close(model);

            _Parent.ModelExplorer.Close();

            //take care of the enable status of menu items when the MDI children is the last one.
            if (_Parent.ModelExplorer.Projects.Count == 0)
                _Parent.ableMenu(false);
        }

        private void handleExitMenuItem()
        {
            if (_Parent.ModelExplorer.Projects.Count > 0)
            {
                DialogResult rslt = MessageBox.Show("Do you want to exit this application?");

                if (rslt != System.Windows.Forms.DialogResult.Yes)
                    return;
            }

            Application.Exit();
        }
        #endregion
    }
}