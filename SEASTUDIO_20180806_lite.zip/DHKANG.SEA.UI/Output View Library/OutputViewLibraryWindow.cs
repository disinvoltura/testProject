﻿using DHKANG.SEA.UI.OutputView;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace DHKANG.SEA.UI.OutputViews
{
    public enum VisualElementType { DataSet, Statistics, HistogramData, BarChart, Plot, TimePlot, PieChart, Histogram, Text, Variable, DonutChart, Tile, BoxWhisker, HorizontalBarChart, StackedBarChart, StackedHorizontalBarChart, ScatterChart}

    public partial class OutputViewLibraryWindow : DockContent
    {
        public OutputViewLibraryWindow()
        {
            InitializeComponent();
        }

        private void initializeOutputViewLibrary()
        {
            System.Windows.Forms.ListViewGroup listViewGroup1 = new System.Windows.Forms.ListViewGroup("Data", System.Windows.Forms.HorizontalAlignment.Left);
            System.Windows.Forms.ListViewGroup listViewGroup2 = new System.Windows.Forms.ListViewGroup("Chart", System.Windows.Forms.HorizontalAlignment.Left);
            System.Windows.Forms.ListViewGroup listViewGroup3 = new System.Windows.Forms.ListViewGroup("Presentation", System.Windows.Forms.HorizontalAlignment.Left);

            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("Data Set", 6);
            listViewItem1.Tag = VisualElementType.DataSet;
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem("Statistics", 6);
            listViewItem2.Tag = VisualElementType.Statistics;
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem("Histogram Data", 6);
            listViewItem3.Tag = VisualElementType.HistogramData;

            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem("Bar Chart", 3);
            listViewItem4.Tag = VisualElementType.BarChart;
            System.Windows.Forms.ListViewItem listViewItem14 = new System.Windows.Forms.ListViewItem("Horizontal Bar Chart", 3);
            listViewItem14.Tag = VisualElementType.HorizontalBarChart;

            System.Windows.Forms.ListViewItem listViewItem15 = new System.Windows.Forms.ListViewItem("Stacked Bar Chart", 3);
            listViewItem15.Tag = VisualElementType.StackedBarChart;
            System.Windows.Forms.ListViewItem listViewItem16 = new System.Windows.Forms.ListViewItem("Stacked Horizontal Bar Chart", 3);
            listViewItem16.Tag = VisualElementType.StackedHorizontalBarChart;

            System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem("Plot", 4);
            listViewItem5.Tag = VisualElementType.Plot;
            System.Windows.Forms.ListViewItem listViewItem6 = new System.Windows.Forms.ListViewItem("Time Plot", 5);
            listViewItem6.Tag = VisualElementType.TimePlot; 

            System.Windows.Forms.ListViewItem listViewItem7 = new System.Windows.Forms.ListViewItem("Pie Chart", 2);
            listViewItem7.Tag = VisualElementType.PieChart;
            System.Windows.Forms.ListViewItem listViewItem11 = new System.Windows.Forms.ListViewItem("Donut Chart", 2);
            listViewItem11.Tag = VisualElementType.DonutChart;

            System.Windows.Forms.ListViewItem listViewItem12 = new System.Windows.Forms.ListViewItem("Scatter Chart", 5);
            listViewItem12.Tag = VisualElementType.ScatterChart;
            
            System.Windows.Forms.ListViewItem listViewItem17 = new System.Windows.Forms.ListViewItem("Box-Whisker Chart", 5);
            listViewItem17.Tag = VisualElementType.BoxWhisker;


            System.Windows.Forms.ListViewItem listViewItem8 = new System.Windows.Forms.ListViewItem("Histogram", 3);
            listViewItem8.Tag = VisualElementType.Histogram;

            System.Windows.Forms.ListViewItem listViewItem9 = new System.Windows.Forms.ListViewItem("Text", 7);
            listViewItem9.Tag = VisualElementType.Text;
            System.Windows.Forms.ListViewItem listViewItem10 = new System.Windows.Forms.ListViewItem("Variable", 8);
            listViewItem10.Tag = VisualElementType.Variable;

            System.Windows.Forms.ListViewItem listViewItem18 = new System.Windows.Forms.ListViewItem("Tile", 8);
            listViewItem18.Tag = VisualElementType.Tile;

            listViewGroup1.Header = "Data";
            listViewGroup1.Name = "lvGroupData";
            listViewGroup2.Header = "Chart";
            listViewGroup2.Name = "lvGroupChart";
            listViewGroup3.Header = "Presentation";
            listViewGroup3.Name = "lvGroupPresentation";
            this.lvLibrary.Groups.AddRange(new System.Windows.Forms.ListViewGroup[] {
            listViewGroup1,
            listViewGroup2,
            listViewGroup3});
            listViewItem1.Group = listViewGroup1;
            listViewItem2.Group = listViewGroup1;
            listViewItem3.Group = listViewGroup1;

            listViewItem4.Group = listViewGroup2;
            listViewItem5.Group = listViewGroup2;
            listViewItem6.Group = listViewGroup2;
            listViewItem7.Group = listViewGroup2;
            listViewItem8.Group = listViewGroup2;
            listViewItem11.Group = listViewGroup2;
            listViewItem12.Group = listViewGroup2;
            listViewItem14.Group = listViewGroup2;
            listViewItem15.Group = listViewGroup2;
            listViewItem16.Group = listViewGroup2;
            listViewItem17.Group = listViewGroup2;

            listViewItem9.Group = listViewGroup3;
            listViewItem10.Group = listViewGroup3;
            listViewItem18.Group = listViewGroup3;
            this.lvLibrary.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3,
            listViewItem4,
            listViewItem14,
            //listViewItem15,
            //listViewItem16,
            listViewItem5,
            listViewItem6,
            listViewItem7,
            listViewItem11,
            listViewItem8,
            listViewItem9,
            listViewItem10,
            listViewItem12,
            listViewItem17,
            listViewItem18
            });
        }

        private void smallIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lvLibrary.View = View.SmallIcon;
        }

        private void largeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lvLibrary.View = View.LargeIcon;
        }

        private void listToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lvLibrary.View = View.Tile;
        }

        bool privateDrag;
        private void lvLibrary_ItemDrag(object sender, ItemDragEventArgs e)
        {
            privateDrag = true;
            DoDragDrop(e.Item, DragDropEffects.Copy);
            privateDrag = false;
        }

        private void lvLibrary_DragEnter(object sender, DragEventArgs e)
        {
            if (privateDrag) e.Effect = e.AllowedEffect;
        }

        private void OutputViewLibraryWindow_Load(object sender, EventArgs e)
        {
            initializeOutputViewLibrary();
        }
    }
}
