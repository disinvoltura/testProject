﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.UI
{
    public delegate void UserActionAddedEventHandler(UserAction action);

    public static class ActionManager
    {
        private static List<UserAction> _Actions;

        public static event UserActionAddedEventHandler Added;

        static ActionManager()
        {
            _Actions = new List<UserAction>();
        }

        public static void Act(string targetObjectName, string action)
        {
            UserAction newAction = new UserAction(targetObjectName, action);
            _Actions.Add(newAction);

            if (Added != null && Added.GetInvocationList().Length>0)
                Added(newAction);
        }

    }

    public class UserAction
    {
        #region Member Variables
        private string _TargetObjectName;
        private string _Action;
        private DateTime _RecordedTime;//recorderd date time
        #endregion

        #region Properties
        public string TargetObjectName {  get { return _TargetObjectName; } }
        public string Action { get { return _Action; } }
        public DateTime RecordedTime {  get { return _RecordedTime; } }
        #endregion

        #region Constructors
        public UserAction(string targetObjectName, string action)
        {
            _TargetObjectName = targetObjectName;
            _Action = action;
            _RecordedTime = DateTime.Now;
        }
        #endregion
    }
}
