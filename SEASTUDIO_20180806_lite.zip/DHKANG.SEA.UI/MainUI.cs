﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using System.Xml.Serialization;
using System.IO;
using DHKANG.SEA.UI.OutputViews;
using DHKANG.SEA.UI.Modeling;
using DHKANG.SEA.UI.OutputView;
using DHKANG.SEA.UI.Menu;
using DHKANG.SEA.UI.Simulation;
using DHKANG.SEA.UI.Configuration;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.UI;
using DHKANG.SEA.Model.Entities;
using DHKANG.SEA.Model.Data;
using DHKANG.SEA.UI.OutputView.Visualization;

namespace DHKANG.SEA.UI
{
    public partial class MainUI : Form
    {
        private int _ModelNo = 1;
        public static MainUI App;
     
        #region Membe Variables - UI Components
        private Dictionary<string, DataEditorWindow> _DataEditorWindows;
        private OutputWindow _OutputWindow;
        private ErrorListWindow _ErrorWindow;
        private SpreadsheetWindow _SpreadsheetWindow;

        private ModelExplorerWindow _ModelExplorerWindow;
        private ObjectModelLibraryWindow _EventObjectLibraryWindow;
        //private DataSourceWindow _DataSourceWindow;
        private OutputViewLibraryWindow _OutputViewLibraryWindow;
        private PropertiesWindow _PropertiesWindow;
        private PropertyWindow _PropertyWindow;//for output view, late change to PropertiesView
        //private EntityWindow _EntityWindow;

        private Dictionary<Guid, OOMMDiagramWindow> _DiagramWindows;

        private WeifenLuo.WinFormsUI.Docking.VS2012LightTheme vS2012LightTheme1;
        private WeifenLuo.WinFormsUI.Docking.VS2015LightTheme vS2015LightTheme1;

        #endregion

        #region Member Variables - Menu Handlers 
        private FileMenuEventHandler _FileMenuHandler;
        private SimulationMenuEventHandler _SimMenuHandler;
        private ViewMenuEventHandler _ViewMenuHandler;
        #endregion

        #region Properties       
        //public List<OOMMEntity> CurrentEntities { get { return Modeling.EntityManager.GetEntities(CurrentModelName); } }

        public ModelExplorerWindow ModelExplorer { get { return _ModelExplorerWindow; } }

        public Dictionary<Guid, OOMMDiagramWindow> DiagramWindows { get { return _DiagramWindows; } }

        public FileMenuEventHandler FileMenuHandler { get { return _FileMenuHandler; } }
     
        public ErrorListWindow ErrorWindow { get { return _ErrorWindow; } }

        public ObjectModelLibraryWindow EventObjectLibraryWindow { get { return _EventObjectLibraryWindow; } }

        public OutputViewLibraryWindow OutputViewLibraryWindow { get { return _OutputViewLibraryWindow; } }

        public OutputWindow OutputWindow { get { return _OutputWindow; } }

        public PropertiesWindow PropertiesWindow { get { return _PropertiesWindow; } }
        #endregion

        #region Constructors
        public MainUI()
        {
            InitializeComponent();

            this.vS2012LightTheme1 = new WeifenLuo.WinFormsUI.Docking.VS2012LightTheme();
            this.vS2015LightTheme1 = new WeifenLuo.WinFormsUI.Docking.VS2015LightTheme();
            dockPanel1.Theme = vS2015LightTheme1;
            //dockPanel1.Theme = vS2012LightTheme1;

            _DiagramWindows = new Dictionary<Guid, OOMMDiagramWindow>();
            _DataEditorWindows = new Dictionary<string, DataEditorWindow>();
            createDockableWindows();

            _FileMenuHandler = new FileMenuEventHandler(this);
            _SimMenuHandler = new SimulationMenuEventHandler(this);
            _ViewMenuHandler = new ViewMenuEventHandler(this);
            
            MainUI.App = this;

            ActionManager.Added += new UserActionAddedEventHandler(OnUserActionAdded);
        }

        public MainUI(string path)
            : this()
        {
            FileOperation.OpenOOMMModelEditor(path);
        }

        #endregion

        #region Form Event Handlers
        private void OnMenuItemClick(object sender, EventArgs e)
        {
            _FileMenuHandler.OnMenuItemClick(sender, e);
        }

        private void OnSimMenuItemClick(object sender, EventArgs e)
        {
            _SimMenuHandler.OnMenuItemClick(sender, e);
        }

        private void OnViewMeuItemClick(object sender, EventArgs e)
        {
            _ViewMenuHandler.OnMenuItemClick(sender, e);
        }
        #endregion

        #region Methods

        /*
        public void GoTo(string eventObjectName)
        {
            _DiagramWindow.GoTo(eventObjectName);
        }
        */

        public bool CheckSyntax()
        {
            bool rslt = true;
            rslt = _ErrorWindow.CheckSyntax(_ModelExplorerWindow.Projects);
            return rslt;            
        }

        public bool CheckSyntax(OOMMModel model)
        {
            return _ErrorWindow.CheckSyntax(model);
        }

        public void OpenDiagramEditor(OOMMModel model)
        {
            if (_DiagramWindows.ContainsKey(model.ID))
            {
                OOMMDiagramWindow diagramWindow = _DiagramWindows[model.ID];
                //diagramWindow.Select();
                //diagramWindow.Focus();
                //diagramWindow.BringToFront();
                diagramWindow.Show();
            }
            else
            {
                OOMMDiagramWindow diagramWindow = new OOMMDiagramWindow();
                diagramWindow.Show(dockPanel1, DockState.Document);
                diagramWindow.DockHandler.AllowEndUserDocking = true;
                diagramWindow.DockHandler.CloseButtonVisible = true;
                diagramWindow.DockHandler.CloseButton = true;
                diagramWindow.SelectionChanged += new DiagramSelectionChangedEventHandler(_DiagramWindow_SelectionChanged);
                //_DiagramWindow.Changed += new DiagramChangedEvent(OnDiagramWindowChanged);
                diagramWindow.DiagramChanged += new DiagramChangedEventHandler(OnDiagramWindowChanged);
                diagramWindow.ObjectSelected += new DiagramObjectSelectedEventHandler(_PropertiesWindow.Update);
                diagramWindow.DiagramChanged += new DiagramChangedEventHandler(_ModelExplorerWindow.OnDiagramChanged);
                diagramWindow.FormClosed += new FormClosedEventHandler(OnDiagramWindowClosed);
                diagramWindow.Open(model);

                _DiagramWindows.Add(model.ID, diagramWindow);
            }
        }

        private void OnModelPropertyChanged(ModelPropertyType type, Guid modelid, string oldValue, string newValue)
        {
            if (type == ModelPropertyType.Name) {
                if (_DiagramWindows.ContainsKey(modelid))
                {
                    OOMMDiagramWindow diagramWindow = _DiagramWindows[modelid];
                    diagramWindow.Text = newValue;
                }
            }
        }

        public void CloseDiagramEditor(Guid id)
        {
            if (_DiagramWindows.ContainsKey(id))
            {
                OOMMDiagramWindow w = _DiagramWindows[id];
                _DiagramWindows.Remove(id);
                w.Close();
            }

            _PropertiesWindow.Update(null, null);
            this.CheckSyntax();
        }

        private void OnDiagramWindowClosed(object sender, FormClosedEventArgs e)
        {
            OOMMDiagramWindow diagramWindow = (OOMMDiagramWindow)sender;

            _ModelExplorerWindow.Update(diagramWindow.Model.ID, diagramWindow.ObjectInteractionDiagram, diagramWindow.ViewScale);

            if (_DiagramWindows.ContainsKey(diagramWindow.Model.ID))
                _DiagramWindows.Remove(diagramWindow.Model.ID);
        }

        private void createDockableWindows()
        {
            //_DiagramWindow = new OOMMDiagramWindow();
            //_DiagramWindow.Show(dockPanel1, DockState.Document);
            //_DiagramWindow.DockHandler.AllowEndUserDocking = false;
            //_DiagramWindow.DockHandler.CloseButtonVisible = false;
            //_DiagramWindow.DockHandler.CloseButton = false;
            //_DiagramWindow.SelectionChanged += new DiagramSelectionChangedEventHandler(_DiagramWindow_SelectionChanged);
            //_DiagramWindow.DiagramChanged += new DiagramChangedEventHandler(OnDiagramWindowChanged);

            _ErrorWindow = new ErrorListWindow(this);
            //_ErrorWindow.Show(_DiagramWindow.Pane, DockAlignment.Bottom, 0.20);
            _ErrorWindow.Show(dockPanel1, DockState.DockBottom);
            //_ErrorWindow.Show(_DiagramWindow.Pane, DockAlignment.Bottom, 0.20);
            //_ErrorWindow.Show(dockPanel1, DockState.DockBottom);
            //_ErrorWindow.Show(_DiagramWindow.Pane, DockAlignment.Bottom, 0.20);
            _ErrorWindow.DockHandler.CloseButtonVisible = false;
            _ErrorWindow.DockHandler.CloseButton = false;

            _OutputWindow = new OutputWindow();
            _OutputWindow.Show(_ErrorWindow.Pane, _ErrorWindow);
            _OutputWindow.DockHandler.CloseButtonVisible = false;
            _OutputWindow.DockHandler.CloseButton = false;


            _PropertiesWindow = new PropertiesWindow();
            //_PropertiesWindow.Show(_SpreadsheetWindow.Pane, _SpreadsheetWindow);
            _PropertiesWindow.Show(_OutputWindow.Pane, DockAlignment.Right, 0.56);
            _PropertiesWindow.DockHandler.CloseButtonVisible = false;
            _PropertiesWindow.DockHandler.CloseButton = false;
            /////////////////////////////////////////////////////////////////////////////////

            _ModelExplorerWindow = new ModelExplorerWindow(this);
            _ModelExplorerWindow.DockHandler.CloseButtonVisible = false;
            _ModelExplorerWindow.DockHandler.CloseButton = false;
            _ModelExplorerWindow.Show(dockPanel1, DockState.DockLeft);
            
            //_ModelExplorerWindow.GoTo += new GoToRequestedEventHandler(_DiagramWindow.GoTo);
            _ModelExplorerWindow.ObjectSelected += new ObjectSelectedEventHandler(_PropertiesWindow.Update);
            _ModelExplorerWindow.EditorOpenRequested += new EditorOpenRequestEventHandler(OnEditorOpenRequested);
            //_ModelExplorerWindow.EntitySelected += new EntitySelectedEventHandler(_EntityWindow.ShowEntity);
            _PropertiesWindow.EntityProperties.EntityChanged += new EntityChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.CSVDataSourceProperties.DataSourceChanged += new DataSourceChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.ExcelDataSourceProperties.DataSourceChanged += new DataSourceChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.DBDataSourceProperties.DataSourceChanged += new DataSourceChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.SimulationExperimentProperties.ExperimentChanged += new ExperimentChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.EventObjectModelProperties.PropertyValueChanged += new ObjectModelPropertyChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.StateObjectModelProperties.PropertyValueChanged += new ObjectModelPropertyChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.ActivityObjectModelProperties.PropertyValueChanged += new ObjectModelPropertyChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.BarChartProperties.PropertyChanged+= new ChartPropertyValueChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.PieChartProperties.PropertyChanged += new ChartPropertyValueChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.PlotProperties.PropertyChanged += new ChartPropertyValueChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.TimePlotProperties.PropertyChanged += new ChartPropertyValueChangedEventHandler(_ModelExplorerWindow.Update);
            //_PropertiesWindow.ModelProperties.PropertyChanged += new ModelPropertiesChangedEventHandler(OnModelPropertyChanged);
            _PropertiesWindow.ModelProperties.PropertyChanged += new ModelPropertiesChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.ModelProperties.PropertyChanged += new ModelPropertiesChangedEventHandler(OnModelPropertyChanged);
            _PropertiesWindow.DataSetProperties.PropertyValueChanged += new DHKANG.SEA.UI.Modeling.Properties.PropertyValueChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.StatisticsProperties.PropertyValueChanged += new DHKANG.SEA.UI.Modeling.Properties.PropertyValueChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.EventObjectNodeProperties.PropertyValueChanged += new DHKANG.SEA.UI.Modeling.Properties.PropertyValueChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.ObjectSchedulingLinkProperties.PropertyValueChanged += new DHKANG.SEA.UI.Modeling.Properties.PropertyValueChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.StateObjectNodeProperties.PropertyValueChanged += new DHKANG.SEA.UI.Modeling.Properties.PropertyValueChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.StateVariableUpdateLinkProperties.PropertyValueChanged += new DHKANG.SEA.UI.Modeling.Properties.PropertyValueChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.TextProperties.PropertyValueChanged += new DHKANG.SEA.UI.Modeling.Properties.PropertyValueChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.LabelProperties.PropertyValueChanged += new DHKANG.SEA.UI.Modeling.Properties.PropertyValueChangedEventHandler(_ModelExplorerWindow.Update);

            _EventObjectLibraryWindow = new ObjectModelLibraryWindow();
            _EventObjectLibraryWindow.Show(dockPanel1, DockState.DockLeft);
            _EventObjectLibraryWindow.DockHandler.CloseButtonVisible = false;
            _EventObjectLibraryWindow.DockHandler.CloseButton = false;

            _OutputViewLibraryWindow = new OutputViewLibraryWindow();
            _OutputViewLibraryWindow.Show(dockPanel1, DockState.DockLeft);
            _OutputViewLibraryWindow.DockHandler.CloseButtonVisible = false;
            _OutputViewLibraryWindow.DockHandler.CloseButton = false;

            _EventObjectLibraryWindow.Show();
            _ModelExplorerWindow.Show();
            
        }
                
        private void _DiagramWindow_SelectionChanged(string selectionType, string objectType)
        {
            //_SpreadsheetWindow.Update(selectionType, objectType);
        }

        private void OnSpreadsheetValueChanged(string type, int id, string propertyName, string newValue)
        {
            //모든 정보는 Diagram 에 가지고 있으므로, Diagram 내에서 수정하면 됨
            //_DiagramWindow.ChangeProperty(type, id, propertyName, newValue);
        }

        private void OnSpreadsheetObjectSelected(string type, int id)
        {
           // _DiagramWindow.GoTo(type, id);
        }
    
        private void OnDiagramWindowChanged(DiagramChangeType type, Guid modelid, object changedObject, object oldObject)
        {
            _ModelExplorerWindow.SetChanged(modelid, true);
        }

        private void OnEditorOpenRequested(string objectName, object objectValue)
        {
            if (objectValue is OOMMDataSource)
            {
                OOMMDataSource ds = (OOMMDataSource)objectValue;

                if (_DataEditorWindows.ContainsKey(ds.Name))
                {
                    DataEditorWindow window = _DataEditorWindows[ds.Name];
                    window.UpdateData();
                    window.Focus();
                    window.BringToFront();
                    window.Activate();
                }
                else
                {
                    //open Data Source Editor 
                    DataEditorWindow window = new DataEditorWindow(ds);

                    window.Show(dockPanel1, DockState.Document);
                    window.DockHandler.AllowEndUserDocking = false;
                    window.DockHandler.CloseButtonVisible = true;
                    window.DockHandler.CloseButton = true;
                    window.FormClosed += DataEditorWindow_FormClosed;

                    _DataEditorWindows.Add(ds.Name, window);
                }
            }
            else if (objectValue is OOEGEventObjectModel)
            {
                //TODO open ETT editor
            }
        }

        private void DataEditorWindow_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (sender is DataEditorWindow)
            {
                string dsName = ((DataEditorWindow)sender).Text;
                if (_DataEditorWindows.ContainsKey(dsName))
                    _DataEditorWindows.Remove(dsName);
            } 
        }

        private void OOEGModelEditor_FormClosing(object sender, FormClosingEventArgs e)
        {
            List<OOMMModel> projects = _ModelExplorerWindow.Projects;

            bool isChanged = false;
            foreach(bool value in _ModelExplorerWindow.IsChanged.Values)
            {
                if (value)
                {
                    isChanged = value;
                    break;
                }
            }
           
            if (isChanged)
            {
                DialogResult result = MessageBox.Show("Do you want to save the modified model before close the model?", "Confirm Message", MessageBoxButtons.YesNoCancel);
                if (result == DialogResult.Yes)
                {
                    _ModelExplorerWindow.SaveAll();
                    e.Cancel = false;
                }
                else if (result == DialogResult.Cancel)
                    e.Cancel = true;
                else
                    e.Cancel = false;
            }
        }
        #endregion

        #region Auxillary Methods
        public void ableMenu(bool enabled)
        {
            closeToolStripMenuItem.Enabled = enabled;
            saveAsToolStripMenuItem.Enabled = enabled;
            saveToolStripMenuItem.Enabled = enabled;
            runToolStripMenuItem.Enabled = enabled;
        }
        #endregion

        #region Utility Methods
        public Guid getCurrentProject()
        {
            return _ModelExplorerWindow.CurrentProject;
        }
        #endregion

        #region Simulation Methods

        #endregion

        #region Help Menu Handlers
        private void aboutOOMMSimulatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox dialog = new AboutBox();
            dialog.ShowDialog(this);
        }
        #endregion

        #region Plug-in Supports
        private PluginsSetting _PluginsSettings;

        public PluginsSetting PluginsSetting
        {
            get { return _PluginsSettings; }
        }
        private void MainUI_Load(object sender, EventArgs e)
        {
            _PluginsSettings = new PluginsSetting();
            //_PluginsSettings.BackgroundColor = Color.AliceBlue;
            //_PluginsSettings.ForegroundColor = Color.AliceBlue;
            //this.DataBindings.Add(new Binding("BackColor", _PluginsSettings, "BackgroundColor"));
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            //_PluginsSettings.Save();
        }
        #endregion

        #region User Action Event Handler Methods
        private void OnUserActionAdded(UserAction action)
        {
            statusLabel.Text = action.Action;
            //statusLabel.Text = "[" + action.TargetObjectName + "] " + action.Action;
        }
        #endregion
    }
}
