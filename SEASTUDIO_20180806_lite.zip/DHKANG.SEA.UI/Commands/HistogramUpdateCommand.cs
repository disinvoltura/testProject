﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.UI.Simulation;
using System.Collections;
using DHKANG.SEA.Simulation;
using DHKANG.SEA.UI.OutputView.Visualization;
using System.Windows.Forms;

namespace DHKANG.SEA.UI
{
    public class HistogramUpdateCommand : Command
    {
        #region Member Variables
        private string _StateVariableName;
        private object _StateVariableValue;
        private Histogram _Chart;
        private string _Expression;
        private double _Time;
        #endregion

        #region Properties
        public string StateVariableName { get { return _StateVariableName; } }
        public object StateVariableValue { get { return _StateVariableValue; } }
        public double Time { get { return _Time; } }
        public override Object TargetObject { get { return this._Chart; } }
        #endregion

        #region Constructors
        public HistogramUpdateCommand(Histogram chart, string objectName, string svName, object svValue, double time)
            : base(objectName)
        {
            _Chart = chart;
            _StateVariableName = svName;
            _StateVariableValue = svValue;
            _Expression = ObjectName + "." + StateVariableName;
            _Time = time;
        }
        #endregion

        #region Methods
        public override void Action(SimulationView view, bool update)
        {
            if (this._Chart == null)
                return;

            foreach (string sName in this._Chart.Series.SeriesNames)
            {
                Series s = this._Chart.Series[sName];
                if (s.Value.Equals(_Expression))
                {
                    double yValue = 0;
                    yValue = getValue(_StateVariableValue);

                    s.DataPoints.AddXY(this.Time, yValue);
                    break;
                }
            }

            if (!update)
                return;

        }
        #endregion
    }
}
