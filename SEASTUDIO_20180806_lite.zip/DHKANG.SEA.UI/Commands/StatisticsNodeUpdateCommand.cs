﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.UI.Simulation;
using System.Collections;
using DHKANG.SEA.Simulation;
using DHKANG.SEA.UI.OutputView;
using DHKANG.Foundation.DataCollection;
using DHKANG.SEA.Model.OID.Data;

namespace DHKANG.SEA.UI
{
    public class StatisticsNodeUpdateCommand : Command
    {
        #region Member Variables
        public string StateVariableName;
        public object StateVariableValue;
        public double Time;
        private string Expression;
        private StatisticsNode Node;
        #endregion

        #region Properties
        public override Object TargetObject {  get { return this.Node; } }
        #endregion

        #region Constructors
        public StatisticsNodeUpdateCommand(StatisticsNode node, string objectName, string svName, object svValue, double time)
            : base(objectName)
        {
            this.Node = node;
            this.ObjectName = objectName;
            this.StateVariableName = svName;
            this.StateVariableValue = svValue;
            this.Expression = ObjectName + "." + StateVariableName;
            this.Time = time;
        }
        #endregion

        #region Methods
        public override void Action(SimulationView view, bool update)
        {
            if (this.Node == null)
                return;

            if (this.Node.Type == StatisticsType.Counter)
            {
                ((CounterStatistics)this.Node.Statistics).Add(this.Time);
            }else if (this.Node.Type == StatisticsType.Tally)
            {
                double value = 0;                
                if (this.StateVariableValue is EntityQueue)
                {
                    value = ((EntityQueue)this.StateVariableValue).Count;
                    ((SampleStatistics)this.Node.Statistics).Add(this.Time, value);

                }
                else if (this.StateVariableValue is int ||
                         this.StateVariableValue is float ||
                         this.StateVariableValue is long ||
                         this.StateVariableValue is double)
                {
                    value = (double)this.StateVariableValue;
                    ((SampleStatistics)this.Node.Statistics).Add(this.Time, value);
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine("[StatisticsNodeUpdateComment.Action] unknown type: " + this.ObjectName + "." + this.StateVariableName + " = " + this.StateVariableValue.ToString());
                }
            }
            else if (this.Node.Type == StatisticsType.TimeDependent)
            {
                double value = 0;

                if (this.StateVariableValue is EntityQueue)
                {
                    value = ((EntityQueue)this.StateVariableValue).Count;
                    ((TimeDependentStatistics)this.Node.Statistics).Add(this.Time, value);

                } else if (this.StateVariableValue is int ||
                           this.StateVariableValue is float ||
                           this.StateVariableValue is long ||
                           this.StateVariableValue is double)                
                {
                    value = (double)this.StateVariableValue;
                    ((TimeDependentStatistics)this.Node.Statistics).Add(this.Time, value);
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine("[StatisticsNodeUpdateComment.Action] unknown type: " + this.ObjectName + "." + this.StateVariableName + " = " + this.StateVariableValue.ToString());
                }
            }

            if (!update)
                return;

            lock (this.Node)
            {
                this.Node.UpdateText();                
            }
        }
        #endregion
    }
}
