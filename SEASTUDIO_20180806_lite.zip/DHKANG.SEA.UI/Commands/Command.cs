﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.UI.Simulation;
using System.Collections;
using DHKANG.SEA.Simulation;

namespace DHKANG.SEA.UI
{
    public abstract class Command
    {
        public string ObjectName;
        public abstract object TargetObject { get; }
        public Command(string objectName)
        {
            this.ObjectName = objectName;
        }

        protected double getValue(object stateVariableValue)
        {
            double yValue = 0;
            if (stateVariableValue is ICollection)
            {
                yValue = ((ICollection)stateVariableValue).Count;
            }
            else if (stateVariableValue is EntityQueue)
            {
                yValue = ((EntityQueue)stateVariableValue).Count;
            }
            else if (stateVariableValue is ParameterVariable<object>)
            {
                yValue = ((ParameterVariable<object>)stateVariableValue).Count;
            }
            else if (stateVariableValue is Resource)
            {
                yValue = ((Resource)stateVariableValue).InUse;
            }
            else
                yValue = double.Parse(stateVariableValue.ToString());

            return yValue;
        }

        public abstract void Action(SimulationView view, bool update);
    }
}
