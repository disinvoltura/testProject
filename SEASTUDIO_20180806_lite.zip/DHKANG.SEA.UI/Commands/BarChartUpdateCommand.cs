﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.UI.Simulation;
using System.Collections;
using DHKANG.SEA.Simulation;
using DHKANG.SEA.UI.OutputView.Visualization;

namespace DHKANG.SEA.UI
{
    public class BarChartUpdateCommand : Command
    {
        #region Member Variables
        public string StateVariableName;
        public object StateVariableValue;
        private BarChart Chart;
        private string Expression;
        #endregion

        #region Properties
        public override Object TargetObject { get { return this.Chart; } }
        #endregion

        #region Constructors
        public BarChartUpdateCommand(BarChart chart, string objectName, string svName, object svValue)
            : base(objectName)
        {
            this.Chart = chart;
            this.ObjectName = objectName;
            this.StateVariableName = svName;
            this.StateVariableValue = svValue;
            this.Expression = ObjectName + "." + StateVariableName;
        }
        #endregion

        #region Methods
        public override void Action(SimulationView view, bool update)
        {
            if (this.Chart == null)
                return;

            foreach (string sName in this.Chart.Series.SeriesNames)
            {
                Series s = this.Chart.Series[sName];
                if (s.Value.Equals(Expression))
                {
                    double yValue = 0;
                    if (this.StateVariableValue == null)
                        continue;

                    if (this.StateVariableValue is ICollection)
                    {
                        yValue = ((ICollection)this.StateVariableValue).Count;
                    }
                    else if (this.StateVariableValue is EntityQueue)
                    {
                        yValue = ((EntityQueue)this.StateVariableValue).Count;
                    }
                    else if (this.StateVariableValue is ParameterVariable<object>)
                    {
                        yValue = ((ParameterVariable<object>)this.StateVariableValue).Count;
                    }
                    else if (this.StateVariableValue is Resource)
                    {
                        yValue = ((Resource)this.StateVariableValue).InUse;
                    }
                    else
                    {
                        yValue = double.Parse(this.StateVariableValue.ToString());
                    }

                    if (s.DataPoints.Count == 0)
                    {
                        s.DataPoints.Add(yValue);
                    }
                    else
                    {
                        //s.DataPoints[0].YValue = yValue;
                        s.DataPoints.Update(0, yValue);
                    }

                    //this.Chart.UpdateSeries(sName);
                    break;
                }
            }

            if (!update)
                return;

            lock (this.Chart) { 
                this.Chart.UpdateSeries();
            }
            //this.Chart.UpdateSeries();
        }
        #endregion
    }
}
