﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.UI.Simulation;
using System.Collections;
using DHKANG.SEA.Simulation;
using DHKANG.SEA.UI.OutputView.Visualization;

namespace DHKANG.SEA.UI
{
    public class StackedBarChartUpdateCommand : Command
    {
        #region Member Variables
        private string _StateVariableName;
        private object _StateVariableValue;
        private StackedBarChart _Chart;
        private string _Expression;
        #endregion

        #region Properties
        public override Object TargetObject { get { return this._Chart; } }
        public string StateVariableName { get { return _StateVariableName; } }
        public object StateVariableValue { get { return _StateVariableValue; } }

        #endregion

        #region Constructors
        public StackedBarChartUpdateCommand(StackedBarChart chart, string objectName, string svName, object svValue)
            : base(objectName)
        {
            _Chart = chart;
            _StateVariableName = svName;
            _StateVariableValue = svValue;
            _Expression = ObjectName + "." + _StateVariableName;
        }
        #endregion

        #region Methods
        public override void Action(SimulationView view, bool update)
        {
            if (this._Chart == null)
                return;

            foreach (string sName in this._Chart.Series.SeriesNames)
            {
                Series s = this._Chart.Series[sName];
                if (s.Value.Equals(_Expression))
                {
                    if (this._StateVariableValue == null)
                        continue;

                    double yValue = 0;
                    yValue = getValue(_StateVariableValue); 

                    if (s.DataPoints.Count == 0)
                    {
                        s.DataPoints.Add(yValue);
                    }
                    else
                    {
                        //s.DataPoints[0].YValue = yValue;
                        s.DataPoints.Update(0, yValue);
                    }

                    break;
                }
            }

            if (!update)
                return;

            lock (this._Chart) { 
                this._Chart.UpdateSeries();
            }
        }
        #endregion
    }
}
