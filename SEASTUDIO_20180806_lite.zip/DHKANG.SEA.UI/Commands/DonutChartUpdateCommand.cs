﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.UI.Simulation;
using System.Collections;
using DHKANG.SEA.Simulation;
using DHKANG.SEA.UI.OutputView.Visualization;

namespace DHKANG.SEA.UI
{
    public class DonutChartUpdateCommand : Command
    {
        #region Member Variables 
        private string _StateVariableName;
        private object _StateVariableValue;
        private DonutChart _Chart;
        private string _Expression;
        private Series _Series;
        private bool _IsArray = false;
        private int _RankValue = 0;
        private int _IndexValue = 0;
        private string _ActualStateVariableName; //only if value is array type

        #endregion

        #region Properties
        public string StateVariableName { get { return _StateVariableName; } }
        public object StateVariableValue { get { return _StateVariableValue; } }

        public override Object TargetObject
        {
            get { return this._Chart; }
        }
        #endregion

        #region Constructors
        public DonutChartUpdateCommand(DonutChart chart,  string objectName, string svName, object svValue)
            : base(objectName)
        {
            _Chart = chart;
            _StateVariableName = svName;
            _StateVariableValue = svValue;
            _Expression = ObjectName + "." + StateVariableName;
        }
        #endregion

        #region Methods
        public override void Action(SimulationView view, bool update)
        {
            if (this._Chart == null)
                return;

            foreach (string sName in this._Chart.Series.SeriesNames)
            {
                Series s = this._Chart.Series[sName];
                if (s.Value.Equals(_Expression))
                {
                    double yValue = 0;
                    if (this._StateVariableValue == null)
                        continue;

                    if (this.StateVariableValue is ICollection)
                    {
                        yValue = ((ICollection)this.StateVariableValue).Count;
                    }
                    else if (this.StateVariableValue is EntityQueue)
                    {
                        yValue = ((EntityQueue)this.StateVariableValue).Count;
                    }
                    else if (this.StateVariableValue is ParameterVariable<object>)
                    {
                        yValue = ((ParameterVariable<object>)this.StateVariableValue).Count;
                    }
                    else if (this.StateVariableValue is Resource)
                    {
                        yValue = ((Resource)this.StateVariableValue).InUse;
                    }else
                    {
                        yValue = double.Parse(this.StateVariableValue.ToString());
                    }

                    if (s.DataPoints.Count == 0)
                    {
                        s.DataPoints.Add(yValue);
                    }
                    else
                    {
                        s.DataPoints[0].YValue = yValue;
                    }
                    break;
                }
            }

            if (!update)
                return;

            lock (this._Chart)
            {
                this._Chart.UpdateSeries();
            }
        }
        #endregion
    }
}
