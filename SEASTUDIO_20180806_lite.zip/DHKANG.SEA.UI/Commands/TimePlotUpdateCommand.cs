﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.UI.Simulation;
using System.Collections;
using DHKANG.SEA.Simulation;
using DHKANG.SEA.UI.OutputView.Visualization;
using System.Windows.Forms;

namespace DHKANG.SEA.UI
{
    public class TimePlotUpdateCommand : Command
    {
        #region Member Variables
        public string StateVariableName;
        public object StateVariableValue;
        private TimePlot Chart;
        private string Expression;
        public double Time;
        #endregion

        #region Properties
        public override Object TargetObject { get { return this.Chart; } }
        #endregion

        #region Constructors
        public TimePlotUpdateCommand(TimePlot chart, string objectName, string svName, object svValue, double time)
            : base(objectName)
        {
            this.Chart = chart;
            this.ObjectName = objectName;
            this.StateVariableName = svName;
            this.StateVariableValue = svValue;
            this.Expression = ObjectName + "." + StateVariableName;
            this.Time = time;
        }
        #endregion

        #region Methods
        public override void Action(SimulationView view, bool update)
        {
            if (this.Chart == null)
                return;

            foreach (string sName in this.Chart.Series.SeriesNames)
            {
                Series s = this.Chart.Series[sName];
                if (s.Value.Equals(Expression))
                {
                    double yValue = 0;

                    if (this.StateVariableValue is ICollection)
                    {
                        yValue = ((ICollection)this.StateVariableValue).Count;
                    }
                    else if (this.StateVariableValue is EntityQueue)
                    {
                        yValue = ((EntityQueue)this.StateVariableValue).Count;
                    }
                    else if (this.StateVariableValue is ParameterVariable<object>)
                    {
                        yValue = ((ParameterVariable<object>)this.StateVariableValue).Count;
                    }
                    else if (this.StateVariableValue is Resource)
                    {
                        yValue = ((Resource)this.StateVariableValue).InUse;
                    }else if (this.StateVariableValue is TimeQueue)
                    {
                        yValue = ((TimeQueue)this.StateVariableValue).Count;
                    }
                    else
                    {
                        if (!double.TryParse(this.StateVariableValue.ToString(), out yValue))
                        {
                            System.Diagnostics.Debug.WriteLine("[TimePlotUpdateCommand.Action] Wrong formatted value: " + this.StateVariableName + "=" + this.StateVariableValue);
                        }
                        //yValue = double.Parse(this.StateVariableValue.ToString());
                    }

                    s.DataPoints.AddXY(this.Time, yValue);
                    break;
                }
            }

            if (!update)
                return;

            lock (this.Chart)
            {
                try
                {                    
                    this.Chart.UpdateSeriesIncremental();

                    //this.Chart.View.Invoke(new MethodInvoker(delegate () {
                    //    this.Chart.UpdateSeriesIncremental();
                    //}));


                }
                catch (Exception e) { System.Diagnostics.Debug.WriteLine(e.ToString()); }
            }
        }
        #endregion
    }
}
