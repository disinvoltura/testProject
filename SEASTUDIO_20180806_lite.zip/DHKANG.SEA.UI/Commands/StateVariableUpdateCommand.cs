﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.UI.Simulation;
using System.Collections;
using DHKANG.SEA.Simulation;

namespace DHKANG.SEA.UI
{
    public class StateVariableUpdateCommand : Command
    {
        public string StateVariableName;
        public object StateVariableValue;

        #region Properties
        public override Object TargetObject { get { return null; } }
        #endregion

        public StateVariableUpdateCommand(string objectName, string svName, object svValue)
            : base(objectName)
        {
            this.ObjectName = objectName;
            this.StateVariableName = svName;
            this.StateVariableValue = svValue;
        }

        private List<LabelNode> labelNodes = null;

        public override void Action(SimulationView view, bool update)
        {
            if (labelNodes == null)
                labelNodes = view.Doc.GetLabelNodes(this.ObjectName, this.StateVariableName);

            string strValue = "";
            string tooltip = "";
            bool isSizable = false;
            if (this.StateVariableValue is Array)
            {
                if (((Array)this.StateVariableValue).Rank == 1)
                {
                    Array va = (Array)this.StateVariableValue;
                    for (int i = 0; i < va.Length; i++)
                        strValue += this.StateVariableName + "[" + i + "] = " + va.GetValue(i) + "\r\n";
                }
                else if (((Array)this.StateVariableValue).Rank == 2)
                {
                    Array va = (Array)this.StateVariableValue;
                    for (int i = 0; i < va.Rank; i++)
                    {
                        for (int k = 0; k < va.Length; k++)
                            strValue += this.StateVariableName + "[" + i + "," + k + "] = " + va.GetValue(i, k) + "\r\n";
                    }
                }
                isSizable = true;
            }
            else if (this.StateVariableValue is ICollection)
            {
                strValue = ((ICollection)this.StateVariableValue).Count.ToString();
                foreach (object item in (ICollection)this.StateVariableValue)
                {
                    tooltip += item.ToString() + "\r\n";
                }
            }
            else if (this.StateVariableValue is EntityQueue)
            {
                EntityQueue eq = (EntityQueue)this.StateVariableValue;
                strValue = eq.Count.ToString();
                foreach(AbstractEntity entity in eq.Values)
                {
                    tooltip += entity.ToString() + "\r\n";
                }
            }
            else if (this.StateVariableValue is ParameterVariable<object>)
                strValue = ((ParameterVariable<object>)this.StateVariableValue).Count.ToString();
            else if (this.StateVariableValue is Resource)
                strValue = ((Resource)this.StateVariableValue).InUse.ToString();
            else if (this.StateVariableValue is TimeQueue)
                strValue = ((TimeQueue)this.StateVariableValue).Count.ToString();
            else
                strValue = this.StateVariableValue.ToString();

            if (!update)
                return;

            foreach (LabelNode ln in labelNodes)
            {
                ln.Text = strValue;
                ln.Tooltip = tooltip;
                if (isSizable)
                {
                    ln.Multiline = true;
                    ln.Resizable = true;
                    ln.Wrapping = false;
                }
            }
        }
    }
}
