﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.OOEG.UI.Simulation;
using System.Collections;
using DHKANG.OOEG.Simulation;
using DHKANG.OOEG.UI.OutputView;

namespace DHKANG.OOEG.UI
{
    public class BarChartUpdateCommand2 : Command
    {
        public string StateVariableName;
        public object StateVariableValue;
        private string Expression;
        public BarChartUpdateCommand2(string objectName, string svName, object svValue)
            : base(objectName)
        {
            this.ObjectName = objectName;
            this.StateVariableName = svName;
            this.StateVariableValue = svValue;
            this.Expression = ObjectName + "." + StateVariableName;
        }
        
        private List<BarChart> _BarCharts = null;

        public override void Action(SimulationView view, bool update)
        {
            if (_BarCharts == null)
                _BarCharts = view.Doc.GetBarCharts();
            //_BarCharts = view.Doc.GetBarCharts(this.ObjectName, this.StateVariableName);

            foreach (BarChart chart in _BarCharts)
            {
                foreach (string sName in chart.Series.SeriesNames)
                {
                    Series s = chart.Series[sName];
                    if (s.Value.Equals(Expression))
                    {
                        double yValue = 0;

                        if (this.StateVariableValue is ICollection)
                        {
                            yValue = ((ICollection)this.StateVariableValue).Count;
                        }
                        else if (this.StateVariableValue is EntityQueue)
                        {
                            yValue = ((EntityQueue)this.StateVariableValue).Count;
                        }
                        else if (this.StateVariableValue is ParameterVariable<object>)
                        {
                            yValue = ((ParameterVariable<object>)this.StateVariableValue).Count;
                        }
                        else if (this.StateVariableValue is Resource)
                        {
                            yValue = ((Resource)this.StateVariableValue).InUse;
                        }

                        if (s.DataPoints.Count == 0){
                            s.DataPoints.Add(yValue);
                        }else{
                            s.DataPoints[0].YValue = yValue;
                        }
                        break;
                    }
                }

                if (!update)
                    return;

                foreach (BarChart bc in _BarCharts)
                    bc.UpdateSeries();
            }
        }
    }
}
