﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.UI.Simulation;

namespace DHKANG.SEA.UI
{
    public class ClockUpdateCommand : Command
    {
        public double SimulationClock;

        public override object TargetObject
        {
            get
            {
                return null;
            }
        }
        public ClockUpdateCommand(string objectName, double clock)
            : base(objectName)
        {
            this.SimulationClock = clock;
        }

        public override void Action(SimulationView view, bool update)
        {
            //view.ClockNode.Text = string.Format("Clock : {0}", Math.Round(this.SimulationClock, 2));
        }
    }
}
