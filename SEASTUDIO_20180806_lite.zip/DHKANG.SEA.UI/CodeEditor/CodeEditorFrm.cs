﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Reflection;
using System.Windows.Forms;
using Microsoft.CSharp;
using DHKANG.SEA.Model;
using DHKANG.SEA.CodeGeneration;
using ICSharpCode.TextEditor.Document;
using DHKANG.SEA.UI.Simulation;
using DHKANG.SEA.Simulation;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model.ActivityObjects;
using DHKANG.SEA.Model.Entities;

namespace DHKANG.SEA.UI.CodeEditor
{
    public partial class CodeEditorFrm : Form
    {
        #region Member Variables
        private OOMMModel _Model;
        private List<DataTable> _dtModels;
        private string _ModelPath;
        private double _SimulationLength;

        private CompilerParameters cp = new CompilerParameters();
        private SimulationEngine _Simulator;
        private SortedList<string, AtomicObjectSimulator> _AtomicSimulators;
        //private List<SimObserver> _Observers;

        private TreeNode _OutputRootNode;
        private int _SimRunCount = 0; //추후 없애기

        private SimExperiment _CurrentExperiment;
        private SimExperiment _LastExperiment;
        //private List<ObserverInfo> _ObserverInfoList;

        private bool _LoggingOption = true;

        FindAndReplaceForm _findForm = new FindAndReplaceForm();
        #endregion

        #region Properties
        public ICSharpCode.TextEditor.TextEditorControl ActiveEditor
        {
            get
            {
                ICSharpCode.TextEditor.TextEditorControl txtEditor = null;

                if (tcCodes.SelectedTab != null)
                {
                    txtEditor = (ICSharpCode.TextEditor.TextEditorControl)tcCodes.SelectedTab.Controls[0];
                }

                return txtEditor;
            }
        }
        #endregion

        #region Constructors
        public CodeEditorFrm(OOMMModel model, string modelPath)
        {
            InitializeComponent();

            _Model = model;
            int atomicModelCount = _Model.EventObjectModels.Count + _Model.StateObjectModels.Count;

            _dtModels = new List<DataTable>(atomicModelCount);
            _ModelPath = modelPath;

            Form.CheckForIllegalCrossThreadCalls = false;
        }
        #endregion

        #region Methods for Model Loading
        private void loadModel()
        {
            if (_Model != null)
            {
                loadSourceCodes();

                loadModelStructure();

                compile();
            }
        }

        private void loadModelStructure()
        {
            TreeNode cmNode = new TreeNode(_Model.Name, 0, 0);
            cmNode.Tag = _Model;

            foreach (OOEGEventObjectModel am in _Model.EventObjectModels)
            {
                TreeNode amNode = new TreeNode(am.Name, 1, 1);

                TreeNode svlistNode = new TreeNode("State Variables", 2, 2);
                foreach (OOEGStateVariable sv in am.StateVariables)
                {
                    TreeNode svNode = new TreeNode(sv.Name + ":" + sv.ValueType.ToString());
                    svNode.Tag = sv;
                    svlistNode.Nodes.Add(svNode);
                }
                amNode.Nodes.Add(svlistNode);

                amNode.Tag = am;
                cmNode.Nodes.Add(amNode);
            }

            foreach (OOSGStateObjectModel am in _Model.StateObjectModels)
            {
                TreeNode amNode = new TreeNode(am.Name, 1, 1);

                TreeNode svlistNode = new TreeNode("State Variables", 2, 2);
                foreach (OOSGStateVariable sv in am.StateVariables)
                {
                    TreeNode svNode = new TreeNode(sv.Name + ":" + sv.Type.ToString());
                    svNode.Tag = sv;
                    svlistNode.Nodes.Add(svNode);
                }
                amNode.Nodes.Add(svlistNode);

                amNode.Tag = am;
                cmNode.Nodes.Add(amNode);
            }

            cmNode.Tag = _Model;

            tvModelView.Nodes.Add(cmNode);

            _OutputRootNode = new TreeNode("Simulation Runs");

            tvModelView.Nodes.Add(_OutputRootNode);

            tvModelView.ExpandAll();
        }

        private void loadSourceCodes()
        {
            EventCodeGenerator eventGen = new EventCodeGenerator(_Model);
            foreach (OOEGEventObjectModel am in _Model.EventObjectModels)
            {
                string code = eventGen.GenerateEventObjectSimulatorCode(am, true, true);
                addCodeTab(am.Name, code, am);
                /*
                string name = am.Name + ".cs";
                ICSharpCode.TextEditor.TextEditorControl tecAtomic = new ICSharpCode.TextEditor.TextEditorControl();
                tecAtomic.Document.HighlightingStrategy = HighlightingStrategyFactory.CreateHighlightingStrategy("C#");
                tecAtomic.Dock = DockStyle.Fill;
                tecAtomic.IsReadOnly = false;
                tecAtomic.Name = name;
                tecAtomic.Text = eventGen.GenerateEventObjectSimulatorCode(am, true, true);
                tecAtomic.ShowLineNumbers = true;
                tecAtomic.TextChanged += new EventHandler(OnCodeChanged);
                TabPage tp = new TabPage(name);
                tp.Tag = am;
                tp.Controls.Add(tecAtomic);
                tcCodes.TabPages.Add(tp);
                */
            }

            StateCodeGenerator stateGen = new StateCodeGenerator();
            foreach (OOSGStateObjectModel am in _Model.StateObjectModels)
            {
                string code  = stateGen.GenearteStateObjectSimulatorCode(am, _Model, true);
                addCodeTab(am.Name, code, am);
                /*
                string name = am.Name + ".cs";
                ICSharpCode.TextEditor.TextEditorControl tecAtomic = new ICSharpCode.TextEditor.TextEditorControl();
                tecAtomic.Document.HighlightingStrategy = HighlightingStrategyFactory.CreateHighlightingStrategy("C#");
                tecAtomic.Dock = DockStyle.Fill;
                tecAtomic.IsReadOnly = false;
                tecAtomic.Name = name;
                tecAtomic.Text = stateGen.GenearteStateObjectSimulatorCode(am, _Model, true);
                tecAtomic.ShowLineNumbers = true;
                tecAtomic.TextChanged += new EventHandler(OnCodeChanged);
                TabPage tp = new TabPage(name);
                tp.Tag = am;
                tp.Controls.Add(tecAtomic);
                tcCodes.TabPages.Add(tp);
                */
            }

            ActivityCodeGenerator activityGen = new ActivityCodeGenerator();
            foreach (OOAGActivityObjectModel am in _Model.ActivityObjectModels)
            {
                string code = activityGen.Generate(am, true);

                addCodeTab(am.Name, code, am);
                /*
                string name = am.Name + ".cs";
                ICSharpCode.TextEditor.TextEditorControl tecAtomic = new ICSharpCode.TextEditor.TextEditorControl();
                tecAtomic.Document.HighlightingStrategy = HighlightingStrategyFactory.CreateHighlightingStrategy("C#");
                tecAtomic.Dock = DockStyle.Fill;
                tecAtomic.IsReadOnly = false;
                tecAtomic.Name = name;
                tecAtomic.Text = activityGen.Generate(am, true);
                tecAtomic.ShowLineNumbers = true;
                tecAtomic.TextChanged += new EventHandler(OnCodeChanged);
                TabPage tp = new TabPage(name);
                tp.Tag = am;
                tp.Controls.Add(tecAtomic);
                tcCodes.TabPages.Add(tp);
                */
            }

            foreach(OOMMEntity entity in _Model.Entities){
                string code = eventGen.GenerateEntityCode(entity);
                addCodeTab(entity.Name, code, entity);
            }

        }

        private void addCodeTab(string name, string code, object target)
        {
            string fileName = name + ".cs";
            ICSharpCode.TextEditor.TextEditorControl tecAtomic = new ICSharpCode.TextEditor.TextEditorControl();
            tecAtomic.Document.HighlightingStrategy = HighlightingStrategyFactory.CreateHighlightingStrategy("C#");
            tecAtomic.Dock = DockStyle.Fill;
            tecAtomic.IsReadOnly = false;
            tecAtomic.Name = fileName;
            tecAtomic.Text = code;
            tecAtomic.ShowLineNumbers = true;
            tecAtomic.TextChanged += new EventHandler(OnCodeChanged);
            TabPage tp = new TabPage(fileName);
            tp.Tag = target;
            tp.Controls.Add(tecAtomic);
            tcCodes.TabPages.Add(tp);
        }

        private void generateMainSource()
        {
            /* comment out 2017.11.27
            string code = string.Empty;

            List<string> amList = new List<string>();
            foreach (AtomicModel am in _Model.CM.AtomicModels.Values)
                amList.Add(am.Name);
            code = _gen.GenerateMainCode(_Model, amList);

            ICSharpCode.TextEditor.TextEditorControl tecMain = new ICSharpCode.TextEditor.TextEditorControl();
            tecMain.Document.HighlightingStrategy = HighlightingStrategyFactory.CreateHighlightingStrategy("C#");
            tecMain.Dock = DockStyle.Fill;
            tecMain.IsReadOnly = false;
            tecMain.Name = _Model.ModelName + "Simulator.cs";
            tecMain.Text = code;
            tecMain.ShowLineNumbers = true;
            tecMain.TextChanged += new EventHandler(OnCodeChanged);
            TabPage tp = new TabPage(tecMain.Name);
            tp.Controls.Add(tecMain);
            tcCodes.TabPages.Add(tp);
            */
        }

        void OnCodeChanged(object sender, EventArgs e)
        {
            //System.Diagnostics.Debug.WriteLine(e.ToString());

            if (sender is ICSharpCode.TextEditor.TextEditorControl)
            {
                ICSharpCode.TextEditor.TextEditorControl editor = (ICSharpCode.TextEditor.TextEditorControl)sender;
                if (editor.Parent is TabPage)
                {
                    TabPage tp = (TabPage)editor.Parent;

                    if (tp.Tag is OOEGEventObjectModel)
                    {
                        tp.Text = ((OOEGEventObjectModel)tp.Tag).Name + ".cs*";
                    }
                    else if (tp.Tag is OOSGStateObjectModel)
                    {
                        tp.Text = ((OOSGStateObjectModel)tp.Tag).Name + ".cs*";
                    }
                }
            }
        }

        private string copyTerminatorFile(string simName)
        {
            string code = string.Empty;
            string path = Application.StartupPath;
            string openPath = path + @"\Terminator.cs";
            string savePath = path + @"\Models\" + _Model.Name + @"\";
            StreamReader sr = new StreamReader(openPath);
            code = sr.ReadToEnd();
            code = code.Replace("SimulationSystemName", simName);
            return code;
        }

        private void setMessage(string msg)
        {
            tssMsg.Text = msg;
        }
        #endregion

        #region Event Handlers
        private void D_Exec_Load(object sender, EventArgs e)
        {
            loadModel();
        }

        private void tvModelView_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            /* comment out 2017.11.27
            if (e.Node.Tag is AtomicModel)
            {
                AtomicModel am = (AtomicModel)e.Node.Tag;

                string fileName = am.Name + ".cs";

                foreach (TabPage tp in tcCodes.TabPages)
                {
                    if (tp.Text.Equals(fileName))
                    {
                        tcCodes.SelectedTab = tp;
                        break;
                    }
                }
            }
            else if (e.Node.Tag is AtomicObject)
            {
                AtomicObject ao = (AtomicObject)e.Node.Tag;
                if (e.Node.Parent.Text.StartsWith("Simulation Run"))
                {
                    SimExperiment exp = (SimExperiment)e.Node.Parent.Tag;
                    SimStateObserver so = exp.FindStateChangeObserver(ao.Name);

                    if (so != null)
                    {
                        //ChartASFrm dialog = new ChartASFrm(ao.Name, exp);
                        //dialog.Show(this);

                        D_Output dialog = new D_Output(ao.Name, exp);
                        dialog.Show(this);
                    }
                }
            }
            else if (e.Node.Tag is StateVariable)
            {
                if (e.Node.Parent.Parent.Parent.Tag is SimExperiment)
                {
                    SimExperiment exp = (SimExperiment)e.Node.Parent.Parent.Parent.Tag;

                    StateVariable sv = (StateVariable)e.Node.Tag;
                    SimStateVariableObserver observer =
                        exp.FindStateVariableObserver(e.Node.Parent.Parent.Text, sv.SVName);

                    ChartFrm dialog = new ChartFrm(observer);
                    dialog.Show(this);
                }
            }
            else if (e.Node.Tag is SimStateVariableObserver)
            {
                SimStateVariableObserver observer = (SimStateVariableObserver)e.Node.Tag;

                ChartFrm dialog = new ChartFrm(observer);
                dialog.Show(this);
            }
            else if (e.Node.Tag is SimExperiment)
            {
                SimExperiment exp = (SimExperiment)e.Node.Tag;

                D_ExpInfo dialog = new D_ExpInfo(exp);
                dialog.Show(this);
            }
            */
        }

        #endregion

        #region Methods for Simulation Execution
        private void run()
        {
            //First: Compile without no erros
            if (!compile())
            {
                MessageBox.Show(this, "There were build errors. Check and fix them first prior to run.", "TE-FSM Toolkit", MessageBoxButtons.OK);
                return;
            }

            /* comment out 2017.11.27
            D_ExecExpFrm dialog = null;
            if (_LastExperiment != null)
                dialog = new D_ExecExpFrm(_Model, _LastExperiment);
            else
                dialog = new D_ExecExpFrm(_Model);

            DialogResult rslt = dialog.ShowDialog();

            if (rslt == DialogResult.OK)
            {
                _CurrentExperiment = new SimExperiment();
                _CurrentExperiment.RunLength = dialog.SimulationLength;
                _CurrentExperiment.Parameters = dialog.Parameters;

                _ObserverInfoList = dialog.Observers;
                _LoggingOption = dialog.LoggingOption;

                doInit();
                doRun();
                doHandleOutput();

            }
            */
        }

        private bool compile()
        {
            CSharpCodeProvider codeProvider = new CSharpCodeProvider();

            ICodeCompiler icc = codeProvider.CreateCompiler();

            string Output = _Model.Name + ".dll";
            //string Output = _Model.TEFSMModelName + ".exe";
            //ToolStripButton ButtonObject = (ToolStripButton)sender;

            System.CodeDom.Compiler.CompilerParameters parameters = new CompilerParameters();
            //Make sure we generate an EXE, not a DLL
            parameters.GenerateExecutable = false;
            //parameters.GenerateExecutable = true;

            //parameters.OutputAssembly = Output;//dhkang 2011.04.25

            //parameters.TempFiles.KeepFiles = true;
            parameters.GenerateInMemory = true;

            parameters.ReferencedAssemblies.Add("system.dll");
            parameters.ReferencedAssemblies.Add("system.data.dll");
            parameters.ReferencedAssemblies.Add("system.xml.dll");
            parameters.ReferencedAssemblies.Add(Application.StartupPath + @"\" + "DHKANG.SEA.Model.dll");
            parameters.ReferencedAssemblies.Add(Application.StartupPath + @"\" + "DHKANG.SEA.Simulation.dll");
            parameters.ReferencedAssemblies.Add(Application.StartupPath + @"\" + "DHKANG.Foundation.Utility.dll");
            parameters.ReferencedAssemblies.Add(Application.StartupPath + @"\" + "DHKANG.Foundation.Logging.dll");
            parameters.ReferencedAssemblies.Add(Application.StartupPath + @"\" + "DHKANG.Foundation.DataCollection.dll");
            parameters.ReferencedAssemblies.Add(Application.StartupPath + @"\" + "DHKANG.Foundation.RandomVariate.dll");
            parameters.ReferencedAssemblies.Add(Application.StartupPath + @"\" + "Troschuetz.Random.dll");


            string[] codeNames = new string[tcCodes.TabPages.Count];
            string[] codes = new string[tcCodes.TabPages.Count];
            int count = 0;
            foreach (TabPage tp in tcCodes.TabPages)
            {
                //추후 rootPath 설정이후 저장 및 로딩
                codes[count] = ((ICSharpCode.TextEditor.TextEditorControl)tp.Controls[0]).Text;
                codeNames[count] = tp.Text;
                count++;
                //path + tp.Text
            }

            CompilerResults results = icc.CompileAssemblyFromSourceBatch(parameters, codes);

            lvOutput.Items.Clear();

            bool rslt = false;
            if (results.Errors.Count > 0)
            {
                //rtxtOutput.ForeColor = Color.Red;
                foreach (CompilerError CompErr in results.Errors)
                {

                    if (CompErr.IsWarning)
                        continue;

                    ListViewItem item = new ListViewItem(CompErr.ErrorText);

                    if (!string.IsNullOrEmpty(CompErr.FileName))
                    {
                        string tmpRFN = CompErr.FileName.Remove(0, parameters.TempFiles.BasePath.Length).Substring(1);
                        string tmpNum = tmpRFN.Substring(0, tmpRFN.IndexOf("."));
                        string tmpFN = codeNames[int.Parse(tmpNum)];
                        item.SubItems.Add(tmpFN);
                    }
                    else
                        item.SubItems.Add("");

                    item.SubItems.Add(CompErr.Line.ToString());
                    item.SubItems.Add(CompErr.Column.ToString());
                    item.SubItems.Add(CompErr.ErrorNumber);
                    item.Tag = CompErr;

                    lvOutput.Items.Add(item);
                }

                rslt = false;
            }
            else
            {
                rslt = true;
                setMessage("Ready.");
            }

            return rslt;
        }

        #endregion

        #region Toolbar Event Handlers
        private bool saveAllCodes()
        {
            foreach (TabPage tp in tcCodes.TabPages)
            {
                if (!saveCode(tp))
                    return false;
            }

            return true;
        }

        private bool saveCode(TabPage tp)
        {
            bool rslt = true;
            try
            {
                if (_ModelPath.EndsWith(".fsm"))
                    _ModelPath = _ModelPath.Substring(0, _ModelPath.LastIndexOf("\\"));

                string path = _ModelPath + "\\Sources\\";
                DirectoryInfo di = new DirectoryInfo(path);
                if (!di.Exists)
                    di.Create();

                path += tp.Text.Replace("*", "");

                string fileName = path;//_ModelPath+ "\Sources\\" + tp.Text;
                string code = ((ICSharpCode.TextEditor.TextEditorControl)tp.Controls[0]).Text;

                rslt = CodeWriter.CodeWrite(code, fileName);

                if (rslt)
                    tp.Text = tp.Text.Replace("*", "");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in saving a code for " + tp.Text + " : " + ex.Message);
                rslt = false;
            }

            return rslt;
        }

        private void tsbSave_Click(object sender, EventArgs e)
        {

            if (tcCodes.SelectedTab != null)
            {
                saveCode(tcCodes.SelectedTab);
            }
        }

        private void tsbSaveAll_Click(object sender, EventArgs e)
        {
            saveAllCodes();
        }

        private void tsbCompile_Click(object sender, EventArgs e)
        {
            compile();
        }

        private void tsbInit_Click(object sender, EventArgs e)
        {

        }


        private void tsbRun_Click(object sender, EventArgs e)
        {
            run();
        }

        private void tsbPause_Click(object sender, EventArgs e)
        {

        }

        private void tsbStop_Click(object sender, EventArgs e)
        {

        }
        #endregion

        #region Simulation Execution
        private void doInit()
        {
            txtOutput.Text = "";

            tsbRun.Enabled = false;
            tsbStop.Enabled = true;
        }

        /*
        private void doSetExpFrame()
        {
            //default: add all state variables to observation list
            _ObserverInfoList = new List<ObserverInfo>();
            foreach (AtomicModel am in _Model.AtomicModels.Values)
            {
                foreach (StateVariable sv in am.StateVariables.Values)
                {
                    ObserverInfo os1 = new ObserverInfo();
                    os1.AtomicModelName = am.AMName;
                    os1.StateVariableName = sv.SVName;
                    _ObserverInfoList.Add(os1);
                }
            }
        }*/

        private void doRun()
        {
            /* comment out 2017.11.27
            _SimRunCount++;
            _Simulator = new CoupledSimulator();
            _Observers = new List<SimObserver>();

            //
            cp.GenerateExecutable = false;
            cp.GenerateInMemory = true;
            cp.IncludeDebugInformation = false;

            CodeDomProvider cdp = new Microsoft.CSharp.CSharpCodeProvider();

            _AtomicSimulators = new SortedList<string, AtomicObjectSimulator>();

            SortedList<string, string> codes = new SortedList<string, string>();//key: amName, value: code

            foreach (TabPage tp in tcCodes.TabPages)
            {
                if (tp.Tag == null || !(tp.Tag is AtomicModel))
                    continue;

                AtomicModel am = (AtomicModel)tp.Tag;

                string code = string.Empty;
                code = ((ICSharpCode.TextEditor.TextEditorControl)tp.Controls[0]).Text;

                codes.Add(am.Name, code);
            }

            foreach (AtomicObject ao in _Model.CM.AtomicObjects)
            {
                string code = codes[ao.Type];
                AtomicModel am = _Model.CM.AtomicModels[ao.Type];
                Assembly asm = null;
                asm = compile(code, cdp);

                AtomicSimulator atomicSim = null;

                try
                {
                    atomicSim = GetAtomicSimulatorInterface(asm, ao, am);
                }
                catch (Exception exp)
                {
                    txtOutput.Text += "An error is captured.";
                    txtOutput.Text += exp.ToString();
                }

                if (atomicSim != null)
                {
                    foreach (ObserverInfo oi in _ObserverInfoList)
                    {
                        if (ao.Type.Equals(oi.AtomicModelName))
                        {
                            SimStateVariableObserver so = new SimStateVariableObserver(atomicSim, oi.StateVariableName);
                            _Observers.Add(so);
                            _CurrentExperiment.AddObserver(so);
                        }
                    }

                    SimStateObserver sco = new SimStateObserver(atomicSim);
                    _Observers.Add(sco);
                    _CurrentExperiment.AddObserver(sco);

                }
            }

            //Message Coupling Relations
            foreach (MessageCouplingRelation mcr in _Model.CM.MessageCouplingRelations)
            {
                _Simulator.AddCoupling(mcr.SourceID, mcr.SourceMsg, mcr.DestinationID, mcr.DestinationMsg);
            }

            //create terminator instance
            Terminator terminator = new Terminator(_CurrentExperiment.RunLength);
            _Simulator.AddModel(terminator);


            //add message coupling for termination
            if (_LoggingOption)
                _Simulator.Logged += new LogHandler(OnLogged);
            _Simulator.SimulationEnded += new SimulationEndEventHandler(OnSimulationEnded);

            _CurrentExperiment.RunStartTime = DateTime.Now;
            _Simulator.Start();
            */

        }

        //private void doRun()
        //{
        //    _SimRunCount++;
        //    _Simulator = new CoupledSimulator();
        //    _Observers = new List<SimObserver>();

        //    //SortedList<string, object> parameterValues = new SortedList<string,object>();
        //    //parameterValues.Add("tauta", 10.0);
        //    //parameterValues.Add("tauts", 10.0);
        //    //parameterValues.Add("tautq", 100.0);

        //    //
        //    cp.GenerateExecutable = false;
        //    cp.GenerateInMemory = true;
        //    cp.IncludeDebugInformation = false;


        //    CodeDomProvider cdp = new Microsoft.CSharp.CSharpCodeProvider();

        //    _AtomicSimulators = new SortedList<string, AtomicSimulator>();
        //    foreach (TabPage tp in tcCodes.TabPages)
        //    {
        //        if (tp.Tag == null || !(tp.Tag is AtomicModel))
        //            continue;

        //        AtomicModel am = (AtomicModel)tp.Tag;

        //        string code = string.Empty;
        //        code = ((ICSharpCode.TextEditor.TextEditorControl)tp.Controls[0]).Text;

        //        Assembly asm = null;
        //        asm = compile(code, cdp);

        //        SortedList<string, string> parameters = AtomicModelUtil.GetAtomicModelParameters(am);

        //        AtomicSimulator atomicSim = null;
        //        try
        //        {
        //            if (parameters.Count > 0)
        //                atomicSim = GetAtomicSimulatorInterface(am, asm, _CurrentExperiment.Parameters);
        //            else
        //                atomicSim = GetAtomicSimulatorInterface(asm);
        //        }
        //        catch (Exception exp)
        //        {
        //            txtOutput.Text += "An error is captured.";
        //            txtOutput.Text += exp.ToString();
        //        }

        //        if (atomicSim != null)
        //        {
        //            foreach (ObserverInfo oi in _ObserverInfoList)
        //            {
        //                if (atomicSim.ID.Equals(oi.AtomicModelName))
        //                {
        //                    SimStateVariableObserver so = new SimStateVariableObserver(atomicSim, oi.StateVariableName);
        //                    _Observers.Add(so);
        //                    _CurrentExperiment.AddObserver(so);
        //                }
        //            }
        //            atomicSim.StateChanged += new StateChangedEventHandler(OnStateChanged);
        //            _AtomicSimulators.Add(am.AMName, atomicSim);
        //            _Simulator.AddModel(atomicSim);

        //            SimStateObserver sco = new SimStateObserver(atomicSim);
        //            _Observers.Add(sco);
        //            _CurrentExperiment.AddObserver(sco);
        //        }
        //    }

        //    //create terminator instance
        //    Terminator terminator = new Terminator(_CurrentExperiment.RunLength);
        //    _Simulator.AddModel(terminator);

        //    _Simulator.Logged += new LogHandler(OnLogged);
        //    _Simulator.SimulationEnded += new SimulationEndEventHandler(OnSimulationEnded);

        //    _CurrentExperiment.RunStartTime = DateTime.Now;
        //    _Simulator.Start();
        //    _CurrentExperiment.RunFinishTime = DateTime.Now;
        //}

        /* COMMENT OUT 2017.11.27
        private void doHandleOutput()
        {
            TreeNode outputNode = new TreeNode(_CurrentExperiment.Name);
            outputNode.Tag = _CurrentExperiment;

            //TreeNode outputNode = new TreeNode("Simulation Run #" + _SimRunCount);

            foreach (AtomicObject ao in _Model.CM.AtomicObjects)
            {
                TreeNode aoNode = new TreeNode(ao.Name + ":" + ao.Type, 1, 1);
                aoNode.Tag = ao;

                TreeNode svListNode = new TreeNode("State Variables", 2, 2);
                foreach (ObserverInfo oi in _ObserverInfoList)
                {
                    if (oi.AtomicModelName.Equals(ao.Type))
                    {
                        TreeNode svNode = new TreeNode(oi.StateVariableName, 3, 3);

                        SimStateVariableObserver svo =
                            _CurrentExperiment.FindStateVariableObserver(ao.Name, oi.StateVariableName);

                        if (svo != null)
                            svNode.Tag = svo;

                        svListNode.Nodes.Add(svNode);
                    }
                }
                if (svListNode.Nodes.Count > 0)
                    aoNode.Nodes.Add(svListNode);

                outputNode.Nodes.Add(aoNode);
            }
            _OutputRootNode.Nodes.Add(outputNode);

            outputNode.ExpandAll();

            tsbRun.Enabled = true;
            tsbStop.Enabled = false;
        }
        */

        /* COMMENT OUT 2017.11.27
        private void doHandleOutput()
        {
            TreeNode outputNode = new TreeNode(_CurrentExperiment.Name);
            outputNode.Tag = _CurrentExperiment;

            //TreeNode outputNode = new TreeNode("Simulation Run #" + _SimRunCount);

            foreach (AtomicModel am in _Model.CM.AtomicModels.Values)
            {
                TreeNode amNode = new TreeNode(am.AMName, 1, 1);
                amNode.Tag = am;

                TreeNode svListNode = new TreeNode("State Variables", 2, 2);
                foreach (ObserverInfo oi in _ObserverInfoList)
                {
                    if (oi.AtomicModelName.Equals(am.AMName))
                    {
                        TreeNode svNode = new TreeNode(oi.StateVariableName, 3, 3);

                        SimStateVariableObserver svo =
                            _CurrentExperiment.FindStateVariableObserver(am.AMName, oi.StateVariableName);

                        if (svo != null)
                            svNode.Tag = svo;

                        svListNode.Nodes.Add(svNode);
                    }
                }
                if (svListNode.Nodes.Count > 0)
                    amNode.Nodes.Add(svListNode);

                outputNode.Nodes.Add(amNode);
            }
            _OutputRootNode.Nodes.Add(outputNode);

            outputNode.ExpandAll();

            tsbRun.Enabled = true;
            tsbStop.Enabled = false;



        }*/

        //private SimStateObserver findStateChageObserver(string amName)
        //{
        //    SimStateObserver rslt = null;

        //    foreach (SimObserver so in _Observers)
        //    {
        //        if (so is SimStateObserver)
        //        {
        //            SimStateObserver sco = (SimStateObserver)so;

        //            if (sco.AtomicSimulator.ID.Equals(amName))
        //            {
        //                rslt = sco;
        //                break;
        //            }
        //        }
        //    }

        //    return rslt;

        //}
        //private SimStateVariableObserver findStateVariableObserver(string amName, string svName)
        //{
        //    SimStateVariableObserver rslt = null;
        //    foreach (SimObserver so in _Observers)
        //    {
        //        if (so is SimStateVariableObserver)
        //        {
        //            SimStateVariableObserver svo = (SimStateVariableObserver)so;

        //            if (svo.AtomicSimulator.ID.Equals(amName) && svo.StateVariable.Equals(svName))
        //            {
        //                rslt = svo;
        //                break;
        //            }
        //        }
        //    }

        //    return rslt;
        //}

        /*
        private void doHandleOutput()
        {
            TreeNode outputNode = new TreeNode("Simulation Run #" + _SimRunCount);

            //구조 변경할 것!!!...
            //Atomic Model Node/State Variables의 hierarchy를 가지도록
            //atomi model node를 선택하면 통합 Chart View 출력
            TreeNode svNode = new TreeNode ("State Variables");

            foreach (SimObserver so in _Observers)
            {
                if (so is SimStateVariableObserver)
                {
                    SimStateVariableObserver svo = (SimStateVariableObserver)so;
                    TreeNode svoNode = new TreeNode(svo.AtomicSimulator.ID + "." + svo.StateVariable);
                    svoNode.Tag = svo;

                    svNode.Nodes.Add(svoNode);
                }
            }
            outputNode.Nodes.Add(svNode);

            _OutputRootNode.Nodes.Add(outputNode);
            //TODO
            //State Changes


            outputNode.ExpandAll();
        }
        */

        /*
        private void OnStateChanged(double time, AtomicSimulator sim)
        {
            SimStateChangedEvent evt = new SimStateChangedEvent(time, sim, sim.CurrentState);

            foreach (SimObserver so in _Observers)
            {
                so.Process(evt);
            }
        }
        */

        private void OnLogged(string sender, string msg, double time)
        {
            AppendTextToOutput("[" + time.ToString() + "] " + sender + "." + msg);
            //System.Diagnostics.Debug.WriteLine();

            //Search keys: Atomic Model Name, State Variable Name

        }

        /* COMMENT OUT 2017.11.27
        private void OnSimulationEnded()
        {
            _CurrentExperiment.RunFinishTime = DateTime.Now;
            _LastExperiment = _CurrentExperiment;
            double execTime = _CurrentExperiment.RunFinishTime.Subtract(_CurrentExperiment.RunStartTime).TotalSeconds;

            showOutput();

            AppendTextToOutput("Simulation ended (" + execTime + ").");
            setMessage("Simulation ended (" + execTime + " secs).");

            MessageBox.Show(this, "Simulation run ended.", "Simulation Execution");
        }
        */

        private void AppendTextToOutput(string msg)
        {
            txtOutput.Text += msg + "\r\n";
        }

        /* COMMENT OUT 2017.11.27
        private void showOutput()
        {
            foreach (SimObserver so in _Observers)
            {
                if (so is SimStateObserver)
                {
                    SimStateObserver sco = (SimStateObserver)so;

                    foreach (SimStateChangedEvent evt in sco.Events)
                    {

                    }
                }
                else if (so is SimStateVariableObserver)
                {
                    SimStateVariableObserver svo = (SimStateVariableObserver)so;

                    foreach (SimStateVariableValueChangedEvent evt in svo.Events)
                    {
                        //System.Diagnostics.Debug.WriteLine("[" + evt.Time + "] " + evt.AtomicSimulator.ID + "." + evt.StateVariableName + " = " + evt.StateVariableValue);
                    }
                }
            }
        }
        */

        private Assembly compile(string code, CodeDomProvider cdp)
        {
            cp.CompilerOptions = "/unsafe";
            cp.ReferencedAssemblies.Clear();
            cp.ReferencedAssemblies.Add(Application.StartupPath + @"\" + "VMS.StateGraph.Model.dll");
            cp.ReferencedAssemblies.Add(Application.StartupPath + @"\" + "VMS.StateGraph.Simulation.dll");
            cp.ReferencedAssemblies.Add(Application.StartupPath + @"\" + "Troschuetz.Random.dll");
            //cp.ReferencedAssemblies.Add("VMS.StateGraph.Model.dll");
            //cp.ReferencedAssemblies.Add("VMS.StateGraph.Simulation.dll");
            //cp.ReferencedAssemblies.Add("Troschuetz.Random.dll");

            CompilerResults cr = cdp.CompileAssemblyFromSource(cp, code);

            if (cr.Errors.HasErrors || cr.Errors.HasWarnings)
            {
                // Handle compiler errors
                StringBuilder error = new StringBuilder();
                foreach (CompilerError err in cr.Errors)
                {
                    string type = (err.IsWarning ? "Warning" : "Error");
                    if (error.Length > 0)
                        error.Append(Environment.NewLine);
                    error.AppendFormat("{0} {1}: Line {2} Column {3}: {4}", type, err.ErrorNumber, err.Line, err.Column, err.ErrorText);
                }
                System.Diagnostics.Debug.WriteLine(error.ToString());

                if (cr.Errors.HasErrors)
                    throw new Exception(error.ToString());
            }

            // Success, return our new assembly
            return cr.CompiledAssembly;
        }

        /* COMMENT OUT 2017.11.27
        private AtomicSimulator GetAtomicSimulatorInterface(AtomicModel am, Assembly asm, List<SimExperimentParameter> parameterValues)//SortedList<string, object> parameterValues)
        {
            foreach (Type t in asm.GetTypes())
            {
                if (!t.IsClass)
                    continue;

                if (!t.IsPublic)
                    continue;

                if (t.BaseType != typeof(AtomicSimulator))
                    continue;

                try
                {
                    AtomicSimulator simulatorInstance = null;

                    SortedList<string, string> parameters = new SortedList<string, string>();
                    parameters = AtomicModelUtil.GetAtomicModelParameters(am);

                    if (parameters.Count == 0)
                    {
                        simulatorInstance = (AtomicSimulator)asm.CreateInstance(t.ToString());

                    }
                    else
                    {
                        object[] args = new object[parameters.Count];
                        Type[] argTypes = new Type[parameters.Count];

                        int count = 0;
                        foreach (string key in parameters.Keys)
                        {
                            string parameterName = key;
                            string parameterType = parameters[key];
                            object parameterValue = null;

                            foreach (SimExperimentParameter pValue in parameterValues)
                            {
                                if (pValue.AtomicModelName.Equals(am.Name) && pValue.ParameterName.Equals(parameterName))
                                {
                                    if (parameterType == "double")
                                        parameterValue = double.Parse(pValue.ParameterValue);
                                    else if (parameterType == "int")
                                        parameterValue = int.Parse(pValue.ParameterValue);
                                    else if (parameterType == "float")
                                        parameterValue = float.Parse(pValue.ParameterValue);
                                    else if (parameterType == "System.Double")
                                        parameterValue = double.Parse(pValue.ParameterValue);
                                    else if (parameterType == "System.Int32")
                                        parameterValue = int.Parse(pValue.ParameterValue);
                                }
                            }
                            if (parameterValue == null)
                            {
                                txtOutput.Text += "Can't find parameter value of \"" + parameterName + "\".";
                                continue;
                            }
                            args[count] = parameterValue;
                            argTypes[count] = parameterValue.GetType();//Type.GetType(parameterValue);

                            count++;
                        }

                        object objInstance = ReflectionHelper.CreateObject(t, args, argTypes);
                        if (objInstance != null)
                            simulatorInstance = objInstance as AtomicSimulator;
                    }
                    return simulatorInstance;
                }
                catch (MissingMethodException)
                {
                    throw;
                }
                catch
                {
                    // Ignore exceptions during entry point search.
                }
            }

            throw new ArgumentException("Atomic Simulator does not derive from base class.");

        }

        static AtomicSimulator GetAtomicSimulatorInterface(Assembly asm, AtomicObject ao, AtomicModel am)
        {
            foreach (Type t in asm.GetTypes())
            {
                if (!t.IsClass)
                    continue;

                if (!t.IsPublic)
                    continue;

                if (t.BaseType != typeof(AtomicSimulator))
                    continue;

                try
                {
                    AtomicSimulator simulatorInstance = null;// (AtomicSimulator)asm.CreateInstance(t.ToString());

                    if (ao.Parameters.Count == 0)
                    {
                        object[] args = new object[1];
                        Type[] argTypes = new Type[1];

                        args[0] = ao.Name;
                        argTypes[0] = typeof(string);

                        object objInstance = ReflectionHelper.CreateObject(t, args, argTypes);
                        if (objInstance != null)
                            simulatorInstance = objInstance as AtomicSimulator;
                    }
                    else
                    {
                        object[] args = new object[ao.Parameters.Count + 1];
                        Type[] argTypes = new Type[ao.Parameters.Count + 1];

                        args[0] = ao.Name;
                        argTypes[0] = typeof(string);

                        SortedList<string, string> parameters = AtomicModelUtil.GetAtomicModelParameters(am);
                        int count = 1;
                        foreach (string key in ao.Parameters.Keys)
                        {
                            string parameterName = key;
                            string parameterType = parameters[key];
                            string sParamValue = ao.Parameters[parameterName].ToString();
                            object parameterValue = null;

                            if (parameterType == "double")
                                parameterValue = double.Parse(sParamValue);
                            else if (parameterType == "int")
                                parameterValue = int.Parse(sParamValue);
                            else if (parameterType == "float")
                                parameterValue = float.Parse(sParamValue);
                            else if (parameterType == "System.Double")
                                parameterValue = double.Parse(sParamValue);
                            else if (parameterType == "System.Int32")
                                parameterValue = int.Parse(sParamValue);

                            if (parameterValue == null)
                            {
                                //txtOutput.Text += "Can't find parameter value of \"" + parameterName + "\".";
                                continue;
                            }
                            args[count] = parameterValue;
                            argTypes[count] = parameterValue.GetType();//Type.GetType(parameterValue);

                            count++;
                        }

                        object objInstance = ReflectionHelper.CreateObject(t, args, argTypes);

                        if (objInstance != null)
                        {
                            foreach (StateVariable sv in ao.StateVariables.Values)
                            {
                                FieldInfo _FieldInfo = null;
                                MemberInfo _MemberInfo = null;
                                //PropertyInfo _PropertyInfo = null;
                                object _objValue = null;
                                if (sv.Type == StateVariableType.Boolean)
                                {
                                    _FieldInfo = t.GetField(sv.SVName);
                                    //_PropertyInfo = t.GetProperty(sv.SVName, typeof(bool));
                                    _objValue = bool.Parse(sv.InitialValue.ToString());
                                }
                                else if (sv.Type == StateVariableType.DateTime)
                                {
                                    _FieldInfo = t.GetField(sv.SVName);
                                    //_PropertyInfo = t.GetProperty(sv.SVName, typeof(DateTime));
                                    _objValue = DateTime.Parse(sv.InitialValue.ToString());
                                }
                                else if (sv.Type == StateVariableType.Double)
                                {
                                    _FieldInfo = t.GetField(sv.SVName);
                                    //_PropertyInfo = t.GetProperty(sv.SVName, typeof(double));
                                    _objValue = double.Parse(sv.InitialValue.ToString());
                                }
                                else if (sv.Type == StateVariableType.Integer)
                                {
                                    _FieldInfo = t.GetField(sv.SVName);
                                    //_PropertyInfo = t.GetProperty(sv.SVName, typeof(int));
                                    _objValue = int.Parse(sv.InitialValue.ToString());
                                }
                                else if (sv.Type == StateVariableType.String)
                                {
                                    _FieldInfo = t.GetField(sv.SVName);
                                    //_PropertyInfo = t.GetProperty(sv.SVName, typeof(string));
                                    _objValue = sv.InitialValue.ToString();
                                }
                                else if (sv.Type == StateVariableType.TimeQueue)
                                {
                                    _FieldInfo = t.GetField(sv.SVName);
                                    //_PropertyInfo = t.GetProperty(sv.SVName, typeof(TimeQueue));
                                    _objValue = sv.InitialValue;
                                }


                                _FieldInfo.SetValue(objInstance, _objValue);//
                            }
                            simulatorInstance = objInstance as AtomicSimulator;

                        }
                    }


                    return simulatorInstance;
                }
                catch (MissingMethodException)
                {
                    throw;
                }
                catch
                {
                    // Ignore exceptions during entry point search.
                }
            }

            throw new ArgumentException("Atomic Simulator does not derive from base class.");
        }

        static AtomicSimulator GetAtomicSimulatorInterface(Assembly asm)
        {
            foreach (Type t in asm.GetTypes())
            {
                if (!t.IsClass)
                    continue;

                if (!t.IsPublic)
                    continue;

                if (t.BaseType != typeof(AtomicSimulator))
                    continue;

                try
                {
                    AtomicSimulator simulatorInstance = (AtomicSimulator)asm.CreateInstance(t.ToString());
                    return simulatorInstance;
                }
                catch (MissingMethodException)
                {
                    throw;
                }
                catch
                {
                    // Ignore exceptions during entry point search.
                }
            }

            throw new ArgumentException("Atomic Simulator does not derive from base class.");
        }
        */

        /* COMMENT OUT 2017.11.27
        private AtomicSimulator GetInstance(string name)
        {
            //string typeName = string.Empty;
            Type typeinfo = null;
            //if (_TransitionTypes.ContainsKey(name))
            //    typeinfo = (Type)_TransitionTypes[name];
            typeinfo = Type.GetType(name);
            AtomicSimulator simulator = null;
            try
            {
                //Type typeinfo = Type.GetType(typeName, false, false);
                if (typeinfo != null)
                {
                    object[] args = new object[] { };// this.Target };
                    Type[] argsTypes = new Type[] { };//typeof(Performer) };

                    try
                    {
                        Object objInstance = ReflectionHelper.CreateObject(typeinfo, args, argsTypes); ;

                        if (objInstance != null)
                            simulator = objInstance as AtomicSimulator;
                    }
                    catch (Exception e)
                    {
                        System.Diagnostics.Trace.WriteLine(e.ToString());
                    }
                }

            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.ToString());
            }


            return simulator;
        }
        */
        #endregion

        private void lvOutput_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (lvOutput.SelectedItems.Count == 0)
                return;

            ListViewItem sItem = lvOutput.SelectedItems[0];

            string fileName = sItem.SubItems[1].Text;

            TabPage sTabPage = null;
            foreach (TabPage tp in tcCodes.TabPages)
            {
                if (tp.Text.Equals(fileName))
                {
                    sTabPage = tp;
                    break;
                }
            }

            if (sTabPage == null)
                return;

            tcCodes.SelectedTab = sTabPage;
            int line = int.Parse(sItem.SubItems[2].Text);
            int column = int.Parse(sItem.SubItems[3].Text);

            ICSharpCode.TextEditor.TextEditorControl txtEditor = (ICSharpCode.TextEditor.TextEditorControl)sTabPage.Controls[0];
            //txtEditor.ActiveTextAreaControl.SelectionManager.SetSelection(
            //    new ICSharpCode.TextEditor.TextLocation(line, column);
            txtEditor.Focus();
            txtEditor.ActiveTextAreaControl.Caret.Line = line - 1;
            txtEditor.ActiveTextAreaControl.Caret.Column = column;
            //txtEditor.ActiveTextAreaControl.TextArea.FoldMargin
        }

        private bool IsChanged()
        {
            bool isChanged = false;
            foreach (TabPage tp in tcCodes.TabPages)
            {
                if (tp.Text.Contains("*"))
                {
                    isChanged = true;
                    break;
                }
            }
            return isChanged;
        }

        private void D_Exec_FormClosing(object sender, FormClosingEventArgs e)
        {
            /* COMMENT OUT 2017.11.27
            if (IsChanged())
            {
                DialogResult rslt = MessageBox.Show(this, "Changes made are not saved. Do you want to save before closing?", "Warning", MessageBoxButtons.YesNoCancel);

                if (rslt == DialogResult.Yes)
                {
                    if (!saveAllCodes())
                        e.Cancel = true;
                }
                else if (rslt == DialogResult.No)
                {
                    //Do nothing
                }
                else if (rslt == DialogResult.Cancel)
                {
                    e.Cancel = true;
                }
            }
            else if (_Simulator != null && _Simulator.SyncManagerState != SMState.STOP)
            {
                DialogResult rslt = MessageBox.Show(this, "The simulation run is being executed. Do you really want to stop this?", "Warning", MessageBoxButtons.YesNo);

                if (rslt == DialogResult.Yes)
                {
                    if (!saveAllCodes())
                        e.Cancel = true;
                }
            }
            */
        }

        private void D_Exec_Enter(object sender, EventArgs e)
        {
            //MainFrm.App.ableSimExecMenuItems(true);
        }

        #region Source Code Finding

        public void Find()
        {
            ICSharpCode.TextEditor.TextEditorControl txtEditor = this.ActiveEditor;

            if (txtEditor != null)
            {
                _findForm.ShowFor(txtEditor, false);
            }

        }

        public void FindNReplace()
        {
            ICSharpCode.TextEditor.TextEditorControl txtEditor = this.ActiveEditor;

            if (txtEditor != null)
            {
                _findForm.ShowFor(txtEditor, true);
            }

        }

        public void FindAgain()
        {
            _findForm.FindNext(true, false,
                string.Format("Search text ?0}?not found.", _findForm.LookFor));
        }

        public void FindAgainReverse()
        {
            _findForm.FindNext(true, true,
                string.Format("Search text ?0}?not found.", _findForm.LookFor));
        }


        #endregion 

        private void tsbFind_Click(object sender, EventArgs e)
        {
            ICSharpCode.TextEditor.TextEditorControl txtEditor = this.ActiveEditor;

            if (txtEditor != null)
            {
                if (!string.IsNullOrEmpty(tscbFindText.Text))
                    _findForm.ShowFor(txtEditor, tscbFindText.Text, false);
            }
        }
    }
}
