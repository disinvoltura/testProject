﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.UI.CodeEditor
{
    public class CodeWriter
    {
        public static bool CodeWrite(string code, string filename)
        {
            try
            {
                StreamWriter sw = File.CreateText(filename);
                sw.Write(code);
                sw.Close();
                return true;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "- ERROR - " + ex.Message);
                return false;
            }
        }
    }
}
