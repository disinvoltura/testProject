﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI
{
    public static class OOMMModelFactory
    {
        public static OOMMModel Open(string filename)
        {
            OOMMModel model = null;

            try
            {
                XmlSerializer deserializer = new XmlSerializer(typeof(OOMMModel));
                TextReader reader = new StreamReader(filename);
                object obj = deserializer.Deserialize(reader);
                model = (OOMMModel)obj;
                reader.Close();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
            }

            return model;
        }

        public static bool Save(string filename, OOMMModel model)
        {
            if (string.IsNullOrEmpty(filename))
                return false;

            bool rslt = true;
            //Serialize using XML Serializer
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(OOMMModel));
                using (TextWriter writer = new StreamWriter(filename))
                {
                    serializer.Serialize(writer, model);
                }
            }catch(Exception ex)
            {
                rslt = false;
            }

            return rslt;
        }
    }
}
