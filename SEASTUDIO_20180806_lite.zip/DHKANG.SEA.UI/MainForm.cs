﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.OOEG.Model;
using DHKANG.OOEG.UI.Simulation;
using DHKANG.OOEG.UI.Menu;
using DHKANG.OOEG.Simulation.Data;
using System.Configuration;
using DHKANG.OOEG.UI.Configuration;

namespace DHKANG.OOEG.UI
{
    public partial class MainForm : Form
    {
        #region Member Variables
        private int _ModelNo = 1;
        public static MainForm App;
        #endregion
          
        #region Member Variables - Menu Handlers 
        private FileMenuEventHandler _FileMenuHandler;
        #endregion

        #region Constructors
        public MainForm()
        {
            InitializeComponent();

            _FileMenuHandler = new FileMenuEventHandler(this);

            MainForm.App = this;
        }

        public MainForm(string path)
            : this()
        {
            openOOEGModelEditor(path);
        }
        #endregion

        #region Form Event Handlers
        private void OnMenuItemClick(object sender, EventArgs e)
        {

            _FileMenuHandler.OnMenuItemClick(sender, e);

            /*
            ToolStripMenuItem menuItem = (ToolStripMenuItem) sender;

            string menuName = menuItem.Text.Replace("&", "").ToLower();
            //TODO
            //- Adopt the command design pattern for the flexiblity
            switch (menuName)
            {
                case "new": handleNewMenuItem(); break;
                case "open": handleOpenMenuItem(); break;
                case "save": handleSaveMenuItem(); break;
                case "save as": handleSaveAsMenuItem(); break;
                case "close": handleCloseMenuItem(); break;
                case "exit": handleExitMenuItem(); break;
            }
            */
        }
        #endregion

        #region File Menu Handlers
        private void handleNewMenuItem()
        {
            D_Properties dialog = new D_Properties();

            DialogResult rslt = dialog.ShowDialog(this);

            if (rslt == System.Windows.Forms.DialogResult.OK)
            {

                OOEGModelEditor w =
                    new OOEGModelEditor(
                        dialog.ModelName,
                        dialog.ModelDescription,
                        dialog.ModelCreator);

                w.MdiParent = this;
                w.WindowState = FormWindowState.Maximized;
                w.ShowIcon = false;
                w.Show();
                w.FormClosed += new FormClosedEventHandler(OnOOEGModelEditorClosed);
                
                ableMenu(true);
            }
        }

        private void OnOOEGModelEditorClosed(object sender, FormClosedEventArgs e)
        {
            if (this.MdiChildren.Length == 0)
            {
                ableMenu(false);
            }
        }

        private void handleOpenMenuItem()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "OOEG Model Files (*.xml)|*.xml|All files (*.*)|*.*";
            ofd.DefaultExt = "xml";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                foreach (string loc in ofd.FileNames)
                {
                    openOOEGModelEditor(loc);
                }
            }

            ableMenu(true);
        }

        private void openOOEGModelEditor(string fileName)
        {
            OOEGModelEditor w = new OOEGModelEditor();
            w.Open(fileName);

            w.MdiParent = this;
            w.WindowState = FormWindowState.Maximized;
            w.Show();
            w.WindowState = FormWindowState.Maximized;

            if (this.MdiChildren.Length == 1)
                ableMenu(true);
        }

        private void handleSaveMenuItem()
        {
            OOEGModelEditor w = getCurrentEditor();
            if (w != null)
                w.Save();
        }

        private void handleSaveAsMenuItem()
        {
            OOEGModelEditor w = getCurrentEditor();
            if (w == null)
                return;

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "OOEG model files (*.xml)|*.xml|All files (*.*)|*.*";
            sfd.DefaultExt = "xml";
            if (string.IsNullOrEmpty(w.FileName))
                sfd.FileName = w.Text.Replace("*", "");
            else
                sfd.FileName = w.FileName;

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string loc = sfd.FileName;

                w.SaveAs(loc);
            }
        }

        private void handleCloseMenuItem()
        {
            //close the active MDI Child with a warning when it is changed, but not saved.
            OOEGModelEditor w = getCurrentEditor();
            if (w != null)
                w.Close();
            
            //take care of the enable status of menu items when the MDI children is the last one.
            if (this.MdiChildren.Length == 0)
                ableMenu(false);

        }

        private void handleExitMenuItem()
        {
            if(this.MdiChildren.Length > 0)
            {
                DialogResult rslt  = MessageBox.Show("Do you want to exit this application?");

                if (rslt != System.Windows.Forms.DialogResult.Yes)
                    return;
            }

            Application.Exit();
        }
        #endregion

        #region Auxillary Methods
        public void ableMenu(bool enabled)
        {
            closeToolStripMenuItem.Enabled = enabled;
            saveAsToolStripMenuItem.Enabled = enabled;
            saveToolStripMenuItem.Enabled = enabled;
            runToolStripMenuItem.Enabled = enabled;
        }

        public OOEGModelEditor getCurrentEditor()
        {
            if (this.ActiveMdiChild != null)
                return this.ActiveMdiChild as OOEGModelEditor;
            else if (this.MdiChildren.Length > 0)
                return (OOEGModelEditor)this.MdiChildren[0];
            else
                return null;
        }
        #endregion

        #region Simulation Methods

        private void runToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            OOEGModelEditor editor = getCurrentEditor();
            if (editor == null)
                return;

            //check changed or not
            //editor.Store();
            OOEGEventGraphModel model = editor.BuildModel();

            //check syntax of the model
            if (!editor.CheckSyntax(model))
            {
                SimulationEditor window = new SimulationEditor(model);
                window.MdiParent = this;
                window.WindowState = FormWindowState.Maximized;
                window.Show();
            }

        }
        #endregion


        #region Help Menu Handlers
        private void aboutOOEGSimulatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox dialog = new AboutBox();
            dialog.ShowDialog(this);
        }
        #endregion

        #region Form Event Handlers
        private PluginsSetting _PluginsSettings;

        public PluginsSetting PluginsSetting
        {
            get { return _PluginsSettings; }
        }
        private void MainForm_Load(object sender, EventArgs e)
        {
            _PluginsSettings = new PluginsSetting();
            //_PluginsSettings.BackgroundColor = Color.AliceBlue;
            //_PluginsSettings.ForegroundColor = Color.AliceBlue;
            //this.DataBindings.Add(new Binding("BackColor", _PluginsSettings, "BackgroundColor"));

        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {            
            //_PluginsSettings.Save();
        } 
        #endregion
    }
}
