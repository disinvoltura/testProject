﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DHKANG.SEA.UI
{
    public partial class NewObjectModelDialog: Form
    {
        #region Member Variables
        private List<string> _Templates;
        private string _TemplateName;
        private string _EventObjectName;

        #endregion

        #region Properties
        public string EventObjectName
        {
            get { return _EventObjectName; }
        }

        public string TemplateName
        {
            get { return _TemplateName; }
            
        }
        public bool CreateNewTemplate
        {
            get { return checkBox1.Checked; }
        }
        #endregion

        #region Constructors
        public NewObjectModelDialog(List<string> templates)
        {
            _Templates = templates;
            InitializeComponent();
        }
        #endregion

        #region Methods
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtName.Text))
                return;
            if (checkBox1.Checked)
            {
                if (string.IsNullOrEmpty(txtNewTemplateName.Text))
                    return;

                if (_Templates.Contains(txtNewTemplateName.Text))
                    return;
            }

            if (!checkBox1.Checked && string.IsNullOrEmpty(cbTemplates.Text))
                return;

            _EventObjectName = txtName.Text;
            if (checkBox1.Checked)
                _TemplateName = txtNewTemplateName.Text;
            else
                _TemplateName = cbTemplates.Text;

            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        private void AddGroupDialog_Load(object sender, EventArgs e)
        {
            cbTemplates.Items.Clear();
            foreach(string templateName in _Templates)
            {
                cbTemplates.Items.Add(templateName);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                cbTemplates.Visible = false;
                txtNewTemplateName.Visible = true;
            }
            else
            {
                cbTemplates.Visible = true;
                txtNewTemplateName.Visible = false;
            }
        }
        #endregion
    }
}
