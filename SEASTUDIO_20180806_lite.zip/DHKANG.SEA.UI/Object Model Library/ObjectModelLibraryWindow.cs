﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;
using System.IO;
using System.Xml.Serialization;
using DHKANG.SEA.UI.ETTEditor;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model.ActivityObjects;
using DHKANG.SEA.UI.STTEditor;
using DHKANG.SEA.UI.ATTEditor;

namespace DHKANG.SEA.UI
{
    public partial class ObjectModelLibraryWindow : DockContent
    {
        #region Member Variables
        private ListViewGroup _GeneralGroup;
        #endregion

        #region Properties
        public List<OOEGEventObjectModel> EventObjects
        {
            get
            {
                List<OOEGEventObjectModel> rslt = new List<OOEGEventObjectModel>();

                foreach(ListViewItem item in lvObjectList.Items)
                {
                    if (item.Tag != null && item.Tag is OOEGEventObjectModel)
                    {
                        OOEGEventObjectModel eoModel = (OOEGEventObjectModel)item.Tag;
                        rslt.Add(eoModel);
                    }
                }

                return rslt;
            }
        }

        public List<OOSGStateObjectModel> StateObjects
        {
            get
            {
                List<OOSGStateObjectModel> rslt = new List<OOSGStateObjectModel>();

                foreach (ListViewItem item in lvObjectList.Items)
                {
                    if (item.Tag != null && item.Tag is OOSGStateObjectModel)
                    {
                        OOSGStateObjectModel soModel = (OOSGStateObjectModel)item.Tag;
                        rslt.Add(soModel);
                    }
                }

                return rslt;
            }
        }

        public List<OOAGActivityObjectModel> ActivityObjects
        {
            get
            {
                List<OOAGActivityObjectModel> rslt = new List<OOAGActivityObjectModel>();

                foreach (ListViewItem item in lvObjectList.Items)
                {
                    if (item.Tag != null && item.Tag is OOAGActivityObjectModel)
                    {
                        OOAGActivityObjectModel aoModel = (OOAGActivityObjectModel)item.Tag;
                        rslt.Add(aoModel);
                    }
                }

                return rslt;
            }
        }

        public List<OOMMTemplate> Templates
        {
            get
            {
                List<OOMMTemplate> rslt = new List<OOMMTemplate>();
                
                foreach(ListViewGroup group in lvObjectList.Groups)
                {
                    OOMMTemplate tem = new OOMMTemplate(group.Header, string.Empty, string.Empty);
                    
                    foreach(ListViewItem item in group.Items)
                    {
                        if (item.Tag == null)
                            continue;
                        if (item.Tag is OOEGEventObjectModel)
                        {
                            OOEGEventObjectModel eoModel = (OOEGEventObjectModel)item.Tag;
                            tem.EventObjectModels.Add(item.Text, eoModel.ID);
                        }else if (item.Tag is OOSGStateObjectModel)
                        {
                            OOSGStateObjectModel soModel = (OOSGStateObjectModel)item.Tag;
                            tem.StateObjectModels.Add(item.Text, soModel.ID);
                        }else if (item.Tag is OOAGActivityObjectModel)
                        {
                            OOAGActivityObjectModel aoModel = (OOAGActivityObjectModel)item.Tag;
                            tem.ActivityObjectModels.Add(item.Text, aoModel.ID);
                        }
                    }
                    rslt.Add(tem);
                }
                return rslt;
            }
        }
        #endregion

        #region Constructors
        public ObjectModelLibraryWindow()
        {
            InitializeComponent();
        }
        #endregion

        #region Open Methods       
        /*
        private void addTempate(OOMMTemplate template, OOMMModel model)
        {
            ListViewGroup targetGroup = _GeneralGroup;
            bool found = false;
            foreach (ListViewGroup group in lvObjectList.Groups)
            {
                if (group.Header == template.Name)
                {
                    targetGroup = group; found = true; break;
                }
            }

            if (!found){
                ListViewGroup newGroup = new ListViewGroup(template.Name);
                lvObjectList.Groups.Add(newGroup);
                targetGroup = newGroup;
            }

            foreach (string eoName in template.EventObjectModels.Keys)
            {
                Guid id = template.EventObjectModels[eoName];
                OOEGEventObjectModel eoModel = model.FindEventObjectModel(id);
                ListViewItem item = new ListViewItem(eoModel.Name, targetGroup);
                item.ImageIndex = 9;
                item.Tag = eoModel;
                lvObjectList.Items.Add(item);
            }
        }
        */
        #endregion

        #region Template Load and Unload
        private void tsbLoadTemplate_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Object Model Library Files (*.xml)|*.xml|All files (*.*)|*.*";
            ofd.DefaultExt = "xml";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                foreach (string loc in ofd.FileNames)
                {
                    loadTemplate(loc);
                }
            }
        }

        private void loadTemplate(string filename)
        {
            OOMMTemplateModel templateModel = null;

            try
            {
                XmlSerializer deserializer = new XmlSerializer(typeof(OOMMTemplateModel));
                TextReader reader = new StreamReader(filename);
                object obj = deserializer.Deserialize(reader);
                templateModel = (OOMMTemplateModel)obj;
                reader.Close();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
            }

            if (templateModel == null)
                return;

            ListViewGroup templateGroup = findTemplateViewGroup(templateModel.Name);
            if (templateGroup == null)
            {
                templateGroup = new ListViewGroup(templateModel.Name, HorizontalAlignment.Left);
                lvObjectList.Groups.Add(templateGroup);
            }

            foreach(OOEGEventObjectModel eoModel in templateModel.EventObjectModels)
            {
                insertEventObjectModel(eoModel, templateGroup);
            }

            foreach (OOSGStateObjectModel soModel in templateModel.StateObjectModels)
            {
                insertStateObjectModel(soModel, templateGroup);
            }

            foreach (OOAGActivityObjectModel aoModel in templateModel.ActivityObjectModels)
            {
                insertActivityObjectModel(aoModel, templateGroup);
            }

            templateModel.FileName = filename;
            templateGroup.Tag = templateModel;
        }

        private void insertEventObjectModel(OOEGEventObjectModel model, ListViewGroup templateGroup)
        {
            ListViewItem item = new ListViewItem(model.Name);
            item.ImageIndex = 9;
            item.Tag = model;
            item.Group = templateGroup;
            item.SubItems.Add("Event");
            item.ToolTipText = model.Description;
            lvObjectList.Items.Add(item);
        }

        private void insertActivityObjectModel(OOAGActivityObjectModel model, ListViewGroup templateGroup)
        {
            ListViewItem item = new ListViewItem(model.Name);
            item.ImageIndex = 8;
            item.Tag = model;
            item.Group = templateGroup;
            item.SubItems.Add("Activity");
            item.ToolTipText = model.Description;
            lvObjectList.Items.Add(item);
        }

        private void insertStateObjectModel(OOSGStateObjectModel model, ListViewGroup templateGroup)
        {
            ListViewItem item = new ListViewItem(model.Name, 1);
            item.ImageIndex = 10;
            item.Tag = model;
            item.Group = templateGroup;
            item.SubItems.Add("State");
            item.ToolTipText = model.Description;
            lvObjectList.Items.Add(item);
        }

        private void saveAllTemplates()
        {
            int successCount = 0;
            foreach (ListViewGroup templateGroup in lvObjectList.Groups)
            {
                if (saveTemplate(templateGroup.Header))
                    successCount++;                
            }
            System.Diagnostics.Debug.WriteLine(String.Format("{0} of {1} have been saved successfully.", successCount, lvObjectList.Groups.Count));
        }

        private bool saveTemplate(String name)
        {
            bool rslt = false;
            ListViewGroup targetTemplateGroup = findTemplateViewGroup(name);
            if (targetTemplateGroup == null)
                return rslt;

            OOMMTemplateModel templateModel = null;
            if (targetTemplateGroup.Tag != null && targetTemplateGroup.Tag is OOMMTemplateModel)
            {
                templateModel = (OOMMTemplateModel)targetTemplateGroup.Tag;
                templateModel.EventObjectModels.Clear();
                templateModel.StateObjectModels.Clear();
                templateModel.ActivityObjectModels.Clear();
            }
            else
                templateModel = new OOMMTemplateModel(name, "", "");

            foreach (ListViewItem item in targetTemplateGroup.Items) {
                if (item.Tag == null)
                    continue;

                if (item.Tag is OOEGEventObjectModel)
                    templateModel.EventObjectModels.Add((OOEGEventObjectModel)item.Tag);
                else if (item.Tag is OOSGStateObjectModel)
                    templateModel.StateObjectModels.Add((OOSGStateObjectModel)item.Tag);                
                else if (item.Tag is OOAGActivityObjectModel)
                    templateModel.ActivityObjectModels.Add((OOAGActivityObjectModel)item.Tag);                
            }

            string fileName = "";
            if (String.IsNullOrEmpty(templateModel.FileName))
            {
                fileName = SysUtil.ApplicationDataFolder + "\\" + templateModel.Name + ".xml";
            }
            else
                fileName = templateModel.FileName;

            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(OOMMTemplateModel));
                using (TextWriter writer = new StreamWriter(fileName))
                {
                    serializer.Serialize(writer, templateModel);
                }

                rslt = true;

            }catch(Exception ex)
            {
                rslt = false;
            }

            return rslt;
        }

        private void tsbUnloadTemplate_Click(object sender, EventArgs e)
        {

        }

        private void unloadTemplate(string templateName)
        {

        }
        #endregion

        #region Group Management
        private void addAGroupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddGroupDialog dialog = new AddGroupDialog();
            
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                lvObjectList.Groups.Add(new ListViewGroup(dialog.GroupName, HorizontalAlignment.Left));
            }
        }

        private void removeAGroupToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        #endregion
        
        #region View Methods
        private void iconToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lvObjectList.View = View.LargeIcon;
        }

        private void detailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lvObjectList.View = View.Details;

        }

        private void listToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lvObjectList.View = View.List;

        }

        private void tileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lvObjectList.View = View.Tile;

        }
        #endregion 

        private void tsbImportEventObjects_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "OOMM Model Files (*.xml)|*.xml|All files (*.*)|*.*";
            ofd.DefaultExt = "xml";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                foreach (string loc in ofd.FileNames)
                {
                    importObjectModels(loc);
                }
            }
        }

        private List<string> getTemplateList()
        {
            List<string> templatelist = new List<string>();
            foreach(ListViewGroup template in lvObjectList.Groups)
            {
                templatelist.Add(template.Header);
            }
            return templatelist;
        }

        /*
        private void addTempate(string templateName, List<OOEGEventObjectModel> eventObjects)
        {
            ListViewGroup targetGroup = _GeneralGroup;
            foreach (ListViewGroup template in lvObjectList.Groups)
            {
                if (template.Header == templateName)
                {
                    targetGroup = template; break;
                }
            }

            foreach (OOEGEventObjectModel eoModel in eventObjects)
            {
                ListViewItem item = new ListViewItem(eoModel.Name, targetGroup);
                item.ImageIndex = 7;
                item.Tag = eoModel;
                lvObjectList.Items.Add(item);
            }
        }
        */    

        private void importObjectModels(string filename)
        {
            OOMMModel model = OOMMModelFactory.Open(filename);

            List<string> templates = getTemplateList();

            ImportObjectModelDialog dialog = 
                new ImportObjectModelDialog(model, templates);

            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                ListViewGroup targetGroup = _GeneralGroup;

                if (dialog.CreateNewTemplate)
                {
                    targetGroup = new ListViewGroup(dialog.TemplateName, HorizontalAlignment.Left);
                    lvObjectList.Groups.Add(targetGroup);
                }else{
                    targetGroup = findTemplateViewGroup(dialog.TemplateName);
                }

                foreach(object objectModel in dialog.ObjectModelList)
                {
                    ListViewItem item = null;
                    if (objectModel is OOEGEventObjectModel)
                    {
                        OOEGEventObjectModel eoModel = (OOEGEventObjectModel)objectModel;
                        insertEventObjectModel(eoModel, targetGroup);
                    }else if (objectModel is OOSGStateObjectModel)
                    {
                        OOSGStateObjectModel soModel = (OOSGStateObjectModel)objectModel;
                        insertStateObjectModel(soModel, targetGroup);
                    }else if (objectModel is OOAGActivityObjectModel)
                    {
                        OOAGActivityObjectModel aoModel = (OOAGActivityObjectModel)objectModel;
                        insertActivityObjectModel(aoModel, targetGroup);
                    }
                    lvObjectList.Items.Add(item);
                }

                saveTemplate(dialog.TemplateName);
            }
        }

        private ListViewGroup findTemplateViewGroup(string templateName)
        {
            ListViewGroup rslt = null;// _GeneralGroup;

            foreach (ListViewGroup template in lvObjectList.Groups)
            {
                if (template.Header == templateName)
                {
                    rslt = template; break;
                }
            }
            return rslt;
        }

        public void ExportToLibrary(string templateName, OOEGEventObjectModel eoModel)
        {
            ListViewGroup targetGroup = findTemplateViewGroup(templateName);
            if (targetGroup == null)
            {
                targetGroup = new ListViewGroup(templateName, HorizontalAlignment.Left);
                lvObjectList.Groups.Add(targetGroup);
            }

            ListViewItem item = new ListViewItem(eoModel.Name, targetGroup);
            item.ImageIndex = 9;
            item.Tag = eoModel;
            lvObjectList.Items.Add(item);

            saveTemplate(templateName);

            ActionManager.Act("Event Object Library", "Event Object Model <" + eoModel.Name + "> is exported to the library successfully.");
        }

        public void ExportToLibrary(string templateName, OOSGStateObjectModel soModel)
        {
            ListViewGroup targetGroup = _GeneralGroup;
            foreach (ListViewGroup template in lvObjectList.Groups)
            {
                if (template.Header == templateName)
                {
                    targetGroup = template; break;
                }
            }

            if (targetGroup == null)
            {
                targetGroup = new ListViewGroup(templateName, HorizontalAlignment.Left);
                lvObjectList.Groups.Add(targetGroup);
            }

            ListViewItem item = new ListViewItem(soModel.Name, targetGroup);
            item.ImageIndex = 10;
            item.Tag = soModel;
            lvObjectList.Items.Add(item);

            saveTemplate(templateName);

            ActionManager.Act("Object Model Library", "State Object Model <" + soModel.Name + "> is exported to the library successfully.");
        }

        public void ExportToLibrary(string templateName, OOAGActivityObjectModel aoModel)
        {
            ListViewGroup targetGroup = _GeneralGroup;
            foreach (ListViewGroup template in lvObjectList.Groups)
            {
                if (template.Header == templateName)
                {
                    targetGroup = template; break;
                }
            }

            if (targetGroup == null)
            {
                targetGroup = new ListViewGroup(templateName, HorizontalAlignment.Left);
                lvObjectList.Groups.Add(targetGroup);
            }

            ListViewItem item = new ListViewItem(aoModel.Name, targetGroup);
            item.ImageIndex = 8;
            item.Tag = aoModel;
            lvObjectList.Items.Add(item);

            saveTemplate(templateName);

            ActionManager.Act("Object Model Library", "Activity Object Model <" + aoModel.Name + "> is exported to the library successfully.");
        }

        private void EventObjectTemplateWindow_Load(object sender, EventArgs e)
        {
           //lvObjectList.Groups.Add(new ListViewGroup("General", HorizontalAlignment.Left));
           //_GeneralGroup = lvObjectList.Groups[0];

           loadTemplates();
        }
        
        private void loadTemplates()
        {
            IEnumerable<string> files = Directory.EnumerateFiles(SysUtil.ApplicationDataFolder);
            foreach (string fileName in files)
            {
                loadTemplate(fileName);
            }

            if (lvObjectList.Groups.Count == 0)
            {
                lvObjectList.Groups.Add(new ListViewGroup("General", HorizontalAlignment.Left));
                _GeneralGroup = lvObjectList.Groups[0];
                saveTemplate("General");
            }
        }

        bool privateDrag;
        private void lvEventObject_ItemDrag(object sender, ItemDragEventArgs e)
        {
            privateDrag = true;
            DoDragDrop(e.Item, DragDropEffects.Copy);
            privateDrag = false;
        }

        private void lvEventObject_DragEnter(object sender, DragEventArgs e)
        {
            if (privateDrag) e.Effect = e.AllowedEffect;

        }

        private void lvEventObject_DragOver(object sender, DragEventArgs e)
        {
            
        }

        private void lvEventObject_DoubleClick(object sender, EventArgs e)
        {
            if (lvObjectList.SelectedItems.Count == 0)
                return;

            ListViewItem item = lvObjectList.SelectedItems[0];

            if (item.Tag == null)
                return;

            editObjectModel(item);
        }

        private void lvEventObject_DragDrop(object sender, DragEventArgs e)
        {
            var pos = lvObjectList.PointToClient(new Point(e.X, e.Y));
            var hit = lvObjectList.HitTest(pos);
            if (hit.Item != null && hit.Item.Tag != null)
            {
                var dragItem = (ListViewItem)e.Data.GetData(typeof(ListViewItem));
                
                //copy(dragItem, (string)hit.Item.Tag);
            }
        }

        private void tsbAddEventObject_Click(object sender, EventArgs e)
        {
            /*
            List<string> templates = getTemplateList();
            //if (templates.Count == 0)
            //    templates.Add("General");

            NewObjectModelDialog dialog = new NewObjectModelDialog(templates);
            if (dialog.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
            {
                ListViewGroup targetGroup = _GeneralGroup;

                if (dialog.CreateNewTemplate)
                {
                    targetGroup = new ListViewGroup(dialog.TemplateName, HorizontalAlignment.Left);
                    lvObjectList.Groups.Add(targetGroup);
                }else{
                    targetGroup = findTemplateViewGroup(dialog.TemplateName);
                }

                OOEGEventObjectModel model = null;
                model = new OOEGEventObjectModel();
                model.Name = dialog.EventObjectName;

                ListViewItem item = new ListViewItem(dialog.EventObjectName, targetGroup);
                item.Tag = model;
                item.ImageIndex = 7;

                //item.Tag = null;
                lvObjectList.Items.Add(item);

                saveTemplate(targetGroup.Header);
            }
            */
        }

        private void tsbRemoveEventObject_Click(object sender, EventArgs e)
        {
            if (lvObjectList.SelectedItems.Count == 0)
                return;

            string message = "Do you really want to remove the object model(s) from the template?";
            DialogResult rslt = MessageBox.Show(this, message, "Warning", MessageBoxButtons.YesNo);

            if (rslt == DialogResult.Yes)
            {
                ListViewItem item = lvObjectList.SelectedItems[0];

                if (item.Group != null)
                {
                    ListViewGroup targetGroup = item.Group;

                    lvObjectList.Items.Remove(item);
                    saveTemplate(targetGroup.Header);
                }
            }
        }

        private void editObjectModel(ListViewItem item)
        {
            if (item.Tag is OOEGEventObjectModel)
            {
                OOEGEventObjectModel model = (OOEGEventObjectModel)item.Tag;
                EventObjectModelEditor editor =
                    new EventObjectModelEditor(model);

                DialogResult rslt = editor.ShowDialog();
                if (rslt == DialogResult.OK)
                {
                    item.Tag = editor.EventObjectModel;
                    saveTemplate(item.Group.Header);
                }
            }
            else if (item.Tag is OOSGStateObjectModel)
            {
                OOSGStateObjectModel model = (OOSGStateObjectModel)item.Tag;
                StateObjectModelEditor editor =
                    new StateObjectModelEditor(model);

                DialogResult rslt = editor.ShowDialog();
                if (rslt == DialogResult.OK)
                {
                    item.Tag = editor.StateObjectModel;
                    saveTemplate(item.Group.Header);
                }
            }
            else if (item.Tag is OOAGActivityObjectModel)
            {
                OOAGActivityObjectModel model = (OOAGActivityObjectModel)item.Tag;
                ActivityObjectModelEditor editor =
                    new ActivityObjectModelEditor(model);

                DialogResult rslt = editor.ShowDialog();
                if (rslt == DialogResult.OK)
                {
                    item.Tag = editor.ActivityObjectModel;
                    saveTemplate(item.Group.Header);
                }
            }
        }

        private void tsbEditEventObject_Click(object sender, EventArgs e)
        {
            if (lvObjectList.SelectedItems.Count == 0)
                return;

            ListViewItem item = lvObjectList.SelectedItems[0];
            if (item.Tag == null)
                return;

            editObjectModel(item);
        }

        private void tsbRename_Click(object sender, EventArgs e)
        {
            if (lvObjectList.SelectedItems.Count == 0)
                return;

            ListViewItem item = lvObjectList.SelectedItems[0];
            if (item.Tag == null)
            {
                return;
            }

            if (item.Tag is OOEGEventObjectModel)
            {
                OOEGEventObjectModel model = (OOEGEventObjectModel)item.Tag;
                RenameDialog dialog = new RenameDialog(model.Name);
                DialogResult rslt = dialog.ShowDialog(this);
                if (rslt == DialogResult.OK)
                {
                    model.Name = dialog.EventObjectName;
                    item.Text = dialog.EventObjectName;
                }
            }else if (item.Tag is OOSGStateObjectModel)
            {
                OOSGStateObjectModel model = (OOSGStateObjectModel)item.Tag;
                RenameDialog dialog = new RenameDialog(model.Name);
                DialogResult rslt = dialog.ShowDialog(this);
                if (rslt == DialogResult.OK)
                {
                    model.Name = dialog.EventObjectName;
                    item.Text = dialog.EventObjectName;
                }
            }else if (item.Tag is OOAGActivityObjectModel)
            {
                OOAGActivityObjectModel model = (OOAGActivityObjectModel)item.Tag;
                RenameDialog dialog = new RenameDialog(model.Name);
                DialogResult rslt = dialog.ShowDialog(this);
                if (rslt == DialogResult.OK)
                {
                    model.Name = dialog.EventObjectName;
                    item.Text = dialog.EventObjectName;
                }
            }
            saveTemplate(item.Group.Header);
        }
    }
}