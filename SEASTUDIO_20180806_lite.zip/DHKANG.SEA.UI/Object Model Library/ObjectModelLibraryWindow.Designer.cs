﻿namespace DHKANG.SEA.UI
{
    partial class ObjectModelLibraryWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ObjectModelLibraryWindow));
            this.dockPanel1 = new WeifenLuo.WinFormsUI.Docking.DockPanel();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.lvObjectList = new System.Windows.Forms.ListView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addAGroupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeAGroupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbLoadTemplate = new System.Windows.Forms.ToolStripButton();
            this.tsbUnloadTemplate = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbAddEventObject = new System.Windows.Forms.ToolStripButton();
            this.tsbEditEventObject = new System.Windows.Forms.ToolStripButton();
            this.tsbRemoveEventObject = new System.Windows.Forms.ToolStripButton();
            this.tsbRename = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbViewCode = new System.Windows.Forms.ToolStripButton();
            this.tsbSort = new System.Windows.Forms.ToolStripButton();
            this.tsbImportEventObjects = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.iconToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.detailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dockPanel1
            // 
            this.dockPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dockPanel1.Location = new System.Drawing.Point(0, 0);
            this.dockPanel1.Name = "dockPanel1";
            this.dockPanel1.Size = new System.Drawing.Size(357, 474);
            this.dockPanel1.TabIndex = 0;
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this.lvObjectList);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.dockPanel1);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(357, 474);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(357, 499);
            this.toolStripContainer1.TabIndex = 2;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip1);
            // 
            // lvObjectList
            // 
            this.lvObjectList.AllowDrop = true;
            this.lvObjectList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lvObjectList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lvObjectList.ContextMenuStrip = this.contextMenuStrip1;
            this.lvObjectList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvObjectList.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvObjectList.LargeImageList = this.imageList1;
            this.lvObjectList.Location = new System.Drawing.Point(0, 0);
            this.lvObjectList.Name = "lvObjectList";
            this.lvObjectList.Size = new System.Drawing.Size(357, 474);
            this.lvObjectList.SmallImageList = this.imageList1;
            this.lvObjectList.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.lvObjectList.TabIndex = 2;
            this.lvObjectList.Tag = "\"ObjectModelLibrary\"";
            this.lvObjectList.UseCompatibleStateImageBehavior = false;
            this.lvObjectList.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.lvEventObject_ItemDrag);
            this.lvObjectList.DragDrop += new System.Windows.Forms.DragEventHandler(this.lvEventObject_DragDrop);
            this.lvObjectList.DragEnter += new System.Windows.Forms.DragEventHandler(this.lvEventObject_DragEnter);
            this.lvObjectList.DragOver += new System.Windows.Forms.DragEventHandler(this.lvEventObject_DragOver);
            this.lvObjectList.DoubleClick += new System.EventHandler(this.lvEventObject_DoubleClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addAGroupToolStripMenuItem,
            this.removeAGroupToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(163, 48);
            // 
            // addAGroupToolStripMenuItem
            // 
            this.addAGroupToolStripMenuItem.Name = "addAGroupToolStripMenuItem";
            this.addAGroupToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.addAGroupToolStripMenuItem.Text = "Add a Group";
            this.addAGroupToolStripMenuItem.Click += new System.EventHandler(this.addAGroupToolStripMenuItem_Click);
            // 
            // removeAGroupToolStripMenuItem
            // 
            this.removeAGroupToolStripMenuItem.Name = "removeAGroupToolStripMenuItem";
            this.removeAGroupToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.removeAGroupToolStripMenuItem.Text = "Remove a Group";
            this.removeAGroupToolStripMenuItem.Click += new System.EventHandler(this.removeAGroupToolStripMenuItem_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "flag_blue.png");
            this.imageList1.Images.SetKeyName(1, "flag_yellow.png");
            this.imageList1.Images.SetKeyName(2, "flag_pink.png");
            this.imageList1.Images.SetKeyName(3, "flag_purple.png");
            this.imageList1.Images.SetKeyName(4, "flag_red.png");
            this.imageList1.Images.SetKeyName(5, "flag_green.png");
            this.imageList1.Images.SetKeyName(6, "flag_orange.png");
            this.imageList1.Images.SetKeyName(7, "brick.png");
            this.imageList1.Images.SetKeyName(8, "activityobjectmodel.png");
            this.imageList1.Images.SetKeyName(9, "eventobjectmodel.png");
            this.imageList1.Images.SetKeyName(10, "stateobjectmodel.png");
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbLoadTemplate,
            this.tsbUnloadTemplate,
            this.toolStripSeparator2,
            this.tsbAddEventObject,
            this.tsbEditEventObject,
            this.tsbRemoveEventObject,
            this.tsbRename,
            this.toolStripSeparator1,
            this.tsbViewCode,
            this.tsbSort,
            this.tsbImportEventObjects,
            this.toolStripSeparator3,
            this.toolStripDropDownButton1});
            this.toolStrip1.Location = new System.Drawing.Point(3, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(259, 25);
            this.toolStrip1.TabIndex = 0;
            // 
            // tsbLoadTemplate
            // 
            this.tsbLoadTemplate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbLoadTemplate.Image = ((System.Drawing.Image)(resources.GetObject("tsbLoadTemplate.Image")));
            this.tsbLoadTemplate.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLoadTemplate.Name = "tsbLoadTemplate";
            this.tsbLoadTemplate.Size = new System.Drawing.Size(23, 22);
            this.tsbLoadTemplate.Text = "Load a Library";
            this.tsbLoadTemplate.Click += new System.EventHandler(this.tsbLoadTemplate_Click);
            // 
            // tsbUnloadTemplate
            // 
            this.tsbUnloadTemplate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbUnloadTemplate.Image = ((System.Drawing.Image)(resources.GetObject("tsbUnloadTemplate.Image")));
            this.tsbUnloadTemplate.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbUnloadTemplate.Name = "tsbUnloadTemplate";
            this.tsbUnloadTemplate.Size = new System.Drawing.Size(23, 22);
            this.tsbUnloadTemplate.Text = "Unload a Library";
            this.tsbUnloadTemplate.Click += new System.EventHandler(this.tsbUnloadTemplate_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbAddEventObject
            // 
            this.tsbAddEventObject.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAddEventObject.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddEventObject.Image")));
            this.tsbAddEventObject.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAddEventObject.Name = "tsbAddEventObject";
            this.tsbAddEventObject.Size = new System.Drawing.Size(23, 22);
            this.tsbAddEventObject.Text = "Add an Event Object";
            this.tsbAddEventObject.Visible = false;
            this.tsbAddEventObject.Click += new System.EventHandler(this.tsbAddEventObject_Click);
            // 
            // tsbEditEventObject
            // 
            this.tsbEditEventObject.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbEditEventObject.Image = ((System.Drawing.Image)(resources.GetObject("tsbEditEventObject.Image")));
            this.tsbEditEventObject.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEditEventObject.Name = "tsbEditEventObject";
            this.tsbEditEventObject.Size = new System.Drawing.Size(23, 22);
            this.tsbEditEventObject.Text = "Edit an Event Object ";
            this.tsbEditEventObject.ToolTipText = "Edit an Object Model";
            this.tsbEditEventObject.Click += new System.EventHandler(this.tsbEditEventObject_Click);
            // 
            // tsbRemoveEventObject
            // 
            this.tsbRemoveEventObject.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRemoveEventObject.Image = ((System.Drawing.Image)(resources.GetObject("tsbRemoveEventObject.Image")));
            this.tsbRemoveEventObject.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRemoveEventObject.Name = "tsbRemoveEventObject";
            this.tsbRemoveEventObject.Size = new System.Drawing.Size(23, 22);
            this.tsbRemoveEventObject.Text = "Remove an Object Model";
            this.tsbRemoveEventObject.Click += new System.EventHandler(this.tsbRemoveEventObject_Click);
            // 
            // tsbRename
            // 
            this.tsbRename.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRename.Image = ((System.Drawing.Image)(resources.GetObject("tsbRename.Image")));
            this.tsbRename.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRename.Name = "tsbRename";
            this.tsbRename.Size = new System.Drawing.Size(23, 22);
            this.tsbRename.Text = "Rename a Object Model";
            this.tsbRename.Click += new System.EventHandler(this.tsbRename_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbViewCode
            // 
            this.tsbViewCode.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbViewCode.Image = ((System.Drawing.Image)(resources.GetObject("tsbViewCode.Image")));
            this.tsbViewCode.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbViewCode.Name = "tsbViewCode";
            this.tsbViewCode.Size = new System.Drawing.Size(23, 22);
            this.tsbViewCode.Text = "View Code";
            // 
            // tsbSort
            // 
            this.tsbSort.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSort.Image = ((System.Drawing.Image)(resources.GetObject("tsbSort.Image")));
            this.tsbSort.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSort.Name = "tsbSort";
            this.tsbSort.Size = new System.Drawing.Size(23, 22);
            this.tsbSort.Text = "Sort items Alphabetically";
            // 
            // tsbImportEventObjects
            // 
            this.tsbImportEventObjects.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbImportEventObjects.Image = ((System.Drawing.Image)(resources.GetObject("tsbImportEventObjects.Image")));
            this.tsbImportEventObjects.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbImportEventObjects.Name = "tsbImportEventObjects";
            this.tsbImportEventObjects.Size = new System.Drawing.Size(23, 22);
            this.tsbImportEventObjects.Text = "Import";
            this.tsbImportEventObjects.Click += new System.EventHandler(this.tsbImportEventObjects_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iconToolStripMenuItem,
            this.detailsToolStripMenuItem,
            this.listToolStripMenuItem,
            this.tileToolStripMenuItem});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(45, 22);
            this.toolStripDropDownButton1.Text = "View";
            // 
            // iconToolStripMenuItem
            // 
            this.iconToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("iconToolStripMenuItem.Image")));
            this.iconToolStripMenuItem.Name = "iconToolStripMenuItem";
            this.iconToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.iconToolStripMenuItem.Text = "Icon";
            this.iconToolStripMenuItem.Click += new System.EventHandler(this.iconToolStripMenuItem_Click);
            // 
            // detailsToolStripMenuItem
            // 
            this.detailsToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("detailsToolStripMenuItem.Image")));
            this.detailsToolStripMenuItem.Name = "detailsToolStripMenuItem";
            this.detailsToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.detailsToolStripMenuItem.Text = "Details";
            this.detailsToolStripMenuItem.Click += new System.EventHandler(this.detailsToolStripMenuItem_Click);
            // 
            // listToolStripMenuItem
            // 
            this.listToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("listToolStripMenuItem.Image")));
            this.listToolStripMenuItem.Name = "listToolStripMenuItem";
            this.listToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.listToolStripMenuItem.Text = "List";
            this.listToolStripMenuItem.Click += new System.EventHandler(this.listToolStripMenuItem_Click);
            // 
            // tileToolStripMenuItem
            // 
            this.tileToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("tileToolStripMenuItem.Image")));
            this.tileToolStripMenuItem.Name = "tileToolStripMenuItem";
            this.tileToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.tileToolStripMenuItem.Text = "Tile";
            this.tileToolStripMenuItem.Click += new System.EventHandler(this.tileToolStripMenuItem_Click);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Name";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Type";
            // 
            // ObjectModelLibraryWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(357, 499);
            this.Controls.Add(this.toolStripContainer1);
            this.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "ObjectModelLibraryWindow";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Object Model Library";
            this.Load += new System.EventHandler(this.EventObjectTemplateWindow_Load);
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private WeifenLuo.WinFormsUI.Docking.DockPanel dockPanel1;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbEditEventObject;
        private System.Windows.Forms.ToolStripButton tsbViewCode;
        private System.Windows.Forms.ListView lvObjectList;
        private System.Windows.Forms.ToolStripButton tsbRemoveEventObject;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsbRename;
        private System.Windows.Forms.ToolStripButton tsbAddEventObject;
        private System.Windows.Forms.ToolStripButton tsbSort;
        private System.Windows.Forms.ToolStripButton tsbImportEventObjects;
        private System.Windows.Forms.ToolStripButton tsbLoadTemplate;
        private System.Windows.Forms.ToolStripButton tsbUnloadTemplate;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem addAGroupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeAGroupToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem iconToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem detailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tileToolStripMenuItem;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
    }
}