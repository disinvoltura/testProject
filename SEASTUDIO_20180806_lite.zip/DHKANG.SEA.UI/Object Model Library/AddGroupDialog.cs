﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DHKANG.SEA.UI
{
    public partial class AddGroupDialog : Form
    {
        private string _GroupName;

        public string GroupName
        {
            get { return _GroupName; }
        }

        public AddGroupDialog()
        {
            InitializeComponent();

        }

        public AddGroupDialog(string groupName)
        {
            InitializeComponent();

            this.Text = "Rename a Group";

            _GroupName = groupName;
            txtGroupName.Text = groupName;
        }

        

        private void btnAdd_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.OK;

            if (string.IsNullOrEmpty(txtGroupName.Text))
                return;

            _GroupName = txtGroupName.Text;

            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        private void AddGroupDialog_Load(object sender, EventArgs e)
        {
            txtGroupName.Focus();
        }
    }
}
