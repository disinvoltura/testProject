﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI
{
    public partial class ChooseTemplateDialog: Form
    {
        #region Member Variables
        private List<OOMMTemplate> _Templates;
        private string _TemplateName;
        #endregion

        #region Properties
        public string TemplateName { get { return _TemplateName; } }     
        #endregion

        #region Constructors
        public ChooseTemplateDialog(List<OOMMTemplate> templates)
        {
            _Templates = templates;
            InitializeComponent();
        }
        #endregion

        #region Methods
        private void btnAdd_Click(object sender, EventArgs e)
        {            
            if (string.IsNullOrEmpty(cbTemplates.Text))
                return;

            _TemplateName = cbTemplates.Text;
            
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        private void ChooseTemplateDialog_Load(object sender, EventArgs e)
        {
            cbTemplates.Items.Clear();
            foreach(OOMMTemplate template in _Templates)
            {
                cbTemplates.Items.Add(template.Name);
            }
        }
        #endregion
    }
}
