﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.ActivityObjects;
using DHKANG.SEA.Model.StateObjects;

namespace DHKANG.SEA.UI
{
    public partial class ImportObjectModelDialog: Form
    {
        #region Member Variables
        private OOMMModel _Model;
        private List<string> _Templates;

        private List<object> _ImportedObjectModels;
        #endregion

        #region Properties
        /// <summary>
        /// Names of Imported Object Models
        /// </summary>
        public List<object> ObjectModelList
        {
            get { return _ImportedObjectModels; }
        }

        public bool CreateNewTemplate
        {
            get { return checkBox1.Checked; }
        }

        public string TemplateName
        {
            get
            {
                if (checkBox1.Checked)
                    return txtNewTemplateName.Text;
                else
                    return cbTemplates.Text;
            }
        }
        #endregion

        #region Constructors
        public ImportObjectModelDialog(OOMMModel model, List<string> templates)
        {
            _Model = model;
            _Templates = templates;

            InitializeComponent();
        }
        #endregion

        #region Methods
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked && string.IsNullOrEmpty(txtNewTemplateName.Text))
                return;
            else if (!checkBox1.Checked &&
                string.IsNullOrEmpty(cbTemplates.Text))
                return;

            _ImportedObjectModels = new List<object>();
            foreach(ListViewItem item in lvObjectModeList.Items)
            {
                if (item.Checked)
                    _ImportedObjectModels.Add(item.Tag);
            }

            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        private void AddGroupDialog_Load(object sender, EventArgs e)
        {
            //Load Event objects
            txtName.Text = _Model.Name;

            foreach(OOEGEventObjectModel eoModel in _Model.EventObjectModels)
            {
                ListViewItem item = new ListViewItem(eoModel.Name);
                item.Tag = eoModel;
                lvObjectModeList.Items.Add(item);
            }
            foreach (OOSGStateObjectModel soModel in _Model.StateObjectModels)
            {
                ListViewItem item = new ListViewItem(soModel.Name);
                item.Tag = soModel;
                lvObjectModeList.Items.Add(item);
            }
            foreach (OOAGActivityObjectModel aoModel in _Model.ActivityObjectModels)
            {
                ListViewItem item = new ListViewItem(aoModel.Name);
                item.Tag = aoModel;
                lvObjectModeList.Items.Add(item);
            }

            //Load Templates
            foreach (string templateName in _Templates)
                cbTemplates.Items.Add(templateName);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                cbTemplates.Visible = false;
                txtNewTemplateName.Visible = true;
            }
            else
            {
                cbTemplates.Visible = true;
                txtNewTemplateName.Visible = false;
            }
        }
    
        //Select All
        private void button1_Click(object sender, EventArgs e)
        {
            foreach(ListViewItem item in lvObjectModeList.Items)
            {
                item.Checked = true;
            }
        }

        //Select None
        private void button2_Click(object sender, EventArgs e)
        {
            foreach(ListViewItem item in lvObjectModeList.Items)
            {
                item.Checked = false;
            }
        }
        #endregion
    }
}
