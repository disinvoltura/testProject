﻿using Opulos.Core.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DHKANG.SEA.UI
{
    public class AccordionPanel : Panel
    //public abstract class AccordionPanel : Panel
    {
        public Accordion acc = new Accordion();

        public AccordionPanel()
        {
            Dock = DockStyle.Fill;
            Controls.Add(acc);
        }
    }
}
