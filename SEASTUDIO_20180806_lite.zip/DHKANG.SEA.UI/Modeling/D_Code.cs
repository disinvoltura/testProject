﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ICSharpCode.TextEditor.Document;
using DHKANG.SEA.Model;
using DHKANG.SEA.UI.CodeGeneration;

namespace DHKANG.SEA.UI
{
    public partial class D_Code : Form
    {
        private OOMMModel _Model;
        private string _EventObjectName;

        public D_Code()
        {
            InitializeComponent();
        }

        public D_Code(string name, OOMMModel model)
        {
            _EventObjectName = name;
            _Model = model;

            InitializeComponent();
        }

        private void D_Code_Load(object sender, EventArgs e)
        {
            CodeGenerator generator = new CodeGenerator(null);

            string code = generator.GenerateEventObjectSimulatorCode(_EventObjectName, _Model, true);

            textEditorControl1.Document.HighlightingStrategy = HighlightingStrategyFactory.CreateHighlightingStrategy("C#");
            textEditorControl1.Dock = DockStyle.Fill;
            textEditorControl1.IsReadOnly = false;
            textEditorControl1.Name = _EventObjectName+".cs";
            textEditorControl1.Text = code;

            //textEditorControl1.PerformLayout();
        }
    }
}
