﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using DHKANG.SEA.UI.SyntaxCheck;
using DHKANG.SEA.Model;
using SourceGrid.Cells.Controllers;
using SourceGrid;

namespace DHKANG.SEA.UI
{
    public partial class ErrorListWindow : DockContent
    {
        private MainUI _Parent;
        //private RowSelectedEvent _RowSelectedController;
        private ModelChecker _Checker;
        private List<CheckPointMessage> _ErrorList;
        private int[] _ColWidthRatios;

        #region Properties
        #endregion

        #region Constructors
        public ErrorListWindow(MainUI parent)
        {
            _Parent = parent;
            InitializeComponent();

            //_RowSelectedController = new RowSelectedEvent(_Parent);
            //grid.Controller.AddController(_RowSelectedController);

            _Checker = new ModelChecker();

            _ErrorList = new List<CheckPointMessage>();
            _ColWidthRatios = new int[] { 10, 70, 10, 10 };

        }
        #endregion

        #region Methods
        public void Clear()
        {
            string[] columns = null;
            columns = new string[] { "Type", "Description", "Target", "Scope" };
            drawHeader(columns);

            _ErrorList = new List<CheckPointMessage>();
        }

        public bool CheckSyntax(List<OOMMModel> projectList)
        {
            bool rslt = false;
            this.Clear();

            _ErrorList = new List<CheckPointMessage>();
            foreach (OOMMModel project in projectList)
            {
                if (_Checker.Check(project))
                {
                    rslt = true;
                }

                _ErrorList.AddRange(_Checker.Errors);
            }

            string lastDesc = string.Empty;
            foreach (CheckPointMessage msg in _ErrorList)
            {
                if (lastDesc.Equals(msg.Description))
                    continue;

                insertToSpreadSheet(msg);
                lastDesc = msg.Description;
            }

            for (int i = 0; i < grid.Columns.Count; i++)
            {
                //grid.Columns[i].HeaderCell.View = titleModel;
                grid.Columns[i].Width = (int)((float)this.Width * ((float)_ColWidthRatios[i] / 100.0f));
            }

            int errors = 0;
            _ErrorList.ForEach(delegate (CheckPointMessage m)
            {
                if (m.Type == CheckPointType.Error)
                    errors++;
            });
            if (errors > 0)
                this.Text = "Error List (" + errors + ")";
            else
                this.Text = "Error List";

            return rslt;
        }


        private void insertToSpreadSheet(CheckPointMessage msg)
        {
            int rowIndex = grid.RowsCount;
            grid.Rows.Insert(rowIndex);

            SourceGrid.Cells.Views.Cell defaultView = new SourceGrid.Cells.Views.Cell();
            defaultView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            //columns = new string[] { "Type", "Description", "Target", "Scope" };

            //Type Column
            SourceGrid.Cells.Cell typeCell = new SourceGrid.Cells.Cell(msg.Type, typeof(CheckPointType));
            typeCell.View = defaultView;
            grid[rowIndex, 0] = typeCell;
            grid[rowIndex, 0].Editor.EnableEdit = false;

            //description column
            SourceGrid.Cells.Cell descCell = new SourceGrid.Cells.Cell(msg.Description, typeof(string));
            descCell.View = defaultView;
            grid[rowIndex, 1] = descCell;
            grid[rowIndex, 1].Editor.EnableEdit = false;

            SourceGrid.Cells.Controllers.ToolTipText toolTipController = new SourceGrid.Cells.Controllers.ToolTipText();
            //toolTipController.IsBalloon = true;
            grid[rowIndex, 1].ToolTipText = msg.Description;
            grid[rowIndex, 1].AddController(toolTipController);

            SourceGrid.Cells.Cell targetCell = new SourceGrid.Cells.Cell(msg.Target, typeof(string));
            targetCell.View = defaultView;
            grid[rowIndex, 2] = targetCell;
            grid[rowIndex, 2].Editor.EnableEdit = false;

            //Scope column
            SourceGrid.Cells.Cell scopeCell = new SourceGrid.Cells.Cell(msg.Scope, typeof(string));
            scopeCell.View = defaultView;
            grid[rowIndex, 3] = scopeCell;
            grid[rowIndex, 3].Editor.EnableEdit = false;
        }

        private void Update(List<CheckPointMessage> errorList)
        {
            Clear();

            foreach (CheckPointMessage msg in errorList)
            {
                insertToSpreadSheet(msg);
            }

            for (int i = 0; i < grid.Columns.Count; i++)
            {
                //grid.Columns[i].HeaderCell.View = titleModel;
                grid.Columns[i].Width = (int)((float)this.Width * ((float)_ColWidthRatios[i] / 100.0f));
            }

            int errors = 0;
            errorList.ForEach(delegate (CheckPointMessage m)
            {
                if (m.Type == CheckPointType.Error)
                    errors++;
            });
            if (errors > 0)
                this.Text = "Error List (" + errors + ")";
            else
                this.Text = "Error List";
        }
        
        public bool CheckSyntax(OOMMModel model)
        {
            bool rslt = _Checker.Check(model);

            if (_Checker.Errors.Count > 0)
            {
                _ErrorList.RemoveAll(e => e.Scope.Equals(model.Name));
                _ErrorList.AddRange(_Checker.Errors);
                Update(_ErrorList);
            }

            return rslt;
        }

        private void drawHeader(string[] columns)
        {
            grid.Rows.Clear();

            grid.BorderStyle = BorderStyle.FixedSingle;
            grid.Redim(1, columns.Length);
            grid.EnableSort = false;
            grid.CustomSort = false;
            grid.FixedRows = 1;

            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            grid.Font = new Font("Calibri", 10);

            for (int i = 0; i < columns.Length; i++)
            {
                SourceGrid.Cells.ColumnHeader header =
                new SourceGrid.Cells.ColumnHeader(columns[i]);
                header.View = titleModel;
                header.SortComparer = new SourceGrid.ValueCellComparer();
                grid[0, i] = header;
            }
        }
        #endregion
    }
    /*
    public class RowSelectedEvent : SourceGrid.Cells.Controllers.ControllerBase
    {
        private MainUI _Parent;
        public RowSelectedEvent(MainUI parent)
        {
            _Parent = parent;
        }

        public override void OnDoubleClick(SourceGrid.CellContext sender, EventArgs e)
        {
            base.OnDoubleClick(sender, e);

            SourceGrid.DataGrid grid = (SourceGrid.DataGrid)sender.Grid;

            if (grid.SelectedDataRows.Count() > 0)
            {
                DataRowView drView = (DataRowView)grid.SelectedDataRows[0];

                string target = drView[2].ToString();
                string scope = drView[3].ToString();

                string[] targetList = target.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
                int id = 0;
                // Commented out for future implementation
                //if (int.TryParse(targetList[0], out id))
                //    _Parent.GoToi(scope, id);
            }
        }
    }
    */
}
