﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DHKANG.SEA.UI
{
    public partial class ObjectNodeDialog : Form
    {
        #region Member Variables
        #endregion

        #region Properties
        public string ObjectNodeName
        {
            get
            {
                return txtName.Text;
            }
        }

        #endregion

        #region Constructors
        public ObjectNodeDialog(string eventObjectName)
        {
            InitializeComponent();

            txtName.Text = eventObjectName;
        }
        #endregion

        #region Methods
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtName.Text))
                return;

            this.DialogResult = DialogResult.OK;
            this.Close();

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
        #endregion

        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Return)
            {
                btnOK_Click(sender, e);
            }
        }
    }
}
