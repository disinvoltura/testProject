﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;

namespace DHKANG.SEA.UI
{
    public partial class ObjectSchedulingLinkDialog : Form
    {
        #region Member Variables
        private int _ID;
        private string _FromEventName;
        private string _ToEventName;
        private string _Parameters;
        private Guid _FromEventObject;
        private Guid _ToEventObject;
        #endregion

        #region Properties
        public int LinkID { get {return _ID;}}

        public string FromEventName { get { return _FromEventName;}}
        public string ToEventName { get { return _ToEventName; } }
        public string Parameters { get { return _Parameters; } }
        public Guid FromEventObject { get { return _FromEventObject; } }
        public Guid ToEventObject { get { return _ToEventObject; } }

        #endregion

        #region constructors
        public ObjectSchedulingLinkDialog()
        {
            InitializeComponent();
        }

        public ObjectSchedulingLinkDialog(
            int id, Guid fromEventObject, Guid toEventObject)
            : this()
        {
            _ID = id;
            _FromEventObject = fromEventObject;
            _ToEventObject = toEventObject;

            initializeLocalEvents(fromEventObject, toEventObject);
            
            this.Text = "Object Scheduling Edge Properties ::: " + _ID;
        }

        private void initializeLocalEvents(Guid fromEventObject, Guid toEventObject)
        {
            //OOEGModelEditor editor = MainForm.App.getCurrentEditor();
            OOMMModel eegModel = MainUI.App.ModelExplorer.GetProject(MainUI.App.ModelExplorer.CurrentProject);
            //editor.BuildModel();
            OOEGEventObjectModel fromEOM = eegModel.FindEventObjectModel(fromEventObject);
            OOEGEventObjectModel toEOM = eegModel.FindEventObjectModel(toEventObject);

            txtMirrorEventObject.Text = fromEOM.Name;
            txtBoundaryEventObject.Text = toEOM.Name;

            //Mirror Event: state change is not allowed
            foreach (OOEGEventTransition et in fromEOM.EventTransitions)
            {
                if (string.IsNullOrEmpty(et.Action))
                    cbMirroEvents.Items.Add(et.Event.Name);
            }

            foreach (OOEGEventTransition et in toEOM.EventTransitions)
            {
                cbBoundaryEvents.Items.Add(et.Event.Name);
            }

        }

        public ObjectSchedulingLinkDialog(
            int id, Guid fromEventObject, string fromEventName, string parameters, Guid toEventObject, string toEventName)
            : this()
        {
            _ID = id;
            _FromEventObject = fromEventObject;
            _FromEventName = fromEventName;
            _Parameters = parameters;
            _ToEventObject = toEventObject;
            _ToEventName = toEventName;

            initializeLocalEvents(fromEventObject, toEventObject);
            cbMirroEvents.Text = fromEventName;
            cbBoundaryEvents.Text = toEventName;
            txtParameters.Text = parameters;
            
            this.Text = "Object Scheduling Edge Properties ::: " + _ID;
        }
        #endregion

        #region Button Click Event Handlers
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbMirroEvents.Text) ||
                string.IsNullOrEmpty(cbBoundaryEvents.Text))
                return;

            _FromEventName = cbMirroEvents.Text;
            _ToEventName = cbBoundaryEvents.Text;

            if (string.IsNullOrEmpty(txtParameters.Text))
                _Parameters = string.Empty;
            else
                _Parameters = txtParameters.Text;
            
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }
        #endregion

        private void LaneLinkProperties_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                btnOK_Click(sender, new System.EventArgs());
            else if (e.KeyCode == Keys.Escape)
                btnClose_Click(sender, new System.EventArgs());
        }

        private void LaneLinkProperties_Load(object sender, EventArgs e)
        {
            cbMirroEvents.Focus();
        }
    }
}
