﻿namespace DHKANG.SEA.UI
{
    partial class OOMMDiagramWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OOMMDiagramWindow));
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.tsbZoomIn = new System.Windows.Forms.ToolStripButton();
            this.tsbZoomOut = new System.Windows.Forms.ToolStripButton();
            this.tsbZoomFit = new System.Windows.Forms.ToolStripButton();
            this.tscbZoom = new System.Windows.Forms.ToolStripComboBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbEventObjectNode = new System.Windows.Forms.ToolStripButton();
            this.tsbSchedulingLink = new System.Windows.Forms.ToolStripButton();
            this.tsbSVLink = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbAddLabel = new System.Windows.Forms.ToolStripButton();
            this.tsbAddText = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStrip4 = new System.Windows.Forms.ToolStrip();
            this.tsbLeft = new System.Windows.Forms.ToolStripButton();
            this.tsbCenter = new System.Windows.Forms.ToolStripButton();
            this.tsbRight = new System.Windows.Forms.ToolStripButton();
            this.tsbTop = new System.Windows.Forms.ToolStripButton();
            this.tsbMiddle = new System.Windows.Forms.ToolStripButton();
            this.tsbBottom = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbGrid = new System.Windows.Forms.ToolStripButton();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.toolStrip4.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(901, 728);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(901, 765);
            this.toolStripContainer1.TabIndex = 0;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip1);
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip4);
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip2);
            // 
            // toolStrip2
            // 
            this.toolStrip2.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip2.ImageScalingSize = new System.Drawing.Size(30, 30);
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbZoomIn,
            this.tsbZoomOut,
            this.tsbZoomFit,
            this.tscbZoom});
            this.toolStrip2.Location = new System.Drawing.Point(246, 0);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(191, 37);
            this.toolStrip2.TabIndex = 2;
            // 
            // tsbZoomIn
            // 
            this.tsbZoomIn.AutoSize = false;
            this.tsbZoomIn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbZoomIn.Image = ((System.Drawing.Image)(resources.GetObject("tsbZoomIn.Image")));
            this.tsbZoomIn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZoomIn.Name = "tsbZoomIn";
            this.tsbZoomIn.Size = new System.Drawing.Size(34, 34);
            this.tsbZoomIn.Text = "Zoom In";
            this.tsbZoomIn.Click += new System.EventHandler(this.tsbZoomIn_Click);
            // 
            // tsbZoomOut
            // 
            this.tsbZoomOut.AutoSize = false;
            this.tsbZoomOut.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbZoomOut.Image = ((System.Drawing.Image)(resources.GetObject("tsbZoomOut.Image")));
            this.tsbZoomOut.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZoomOut.Name = "tsbZoomOut";
            this.tsbZoomOut.Size = new System.Drawing.Size(34, 34);
            this.tsbZoomOut.Text = "Zoom Out";
            this.tsbZoomOut.Click += new System.EventHandler(this.tsbZoomOut_Click);
            // 
            // tsbZoomFit
            // 
            this.tsbZoomFit.AutoSize = false;
            this.tsbZoomFit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbZoomFit.Image = ((System.Drawing.Image)(resources.GetObject("tsbZoomFit.Image")));
            this.tsbZoomFit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZoomFit.Name = "tsbZoomFit";
            this.tsbZoomFit.Size = new System.Drawing.Size(34, 34);
            this.tsbZoomFit.Text = "Zoom to fit";
            this.tsbZoomFit.Click += new System.EventHandler(this.tsbZoomFit_Click);
            // 
            // tscbZoom
            // 
            this.tscbZoom.Items.AddRange(new object[] {
            "10%",
            "25%",
            "50%",
            "65%",
            "75%",
            "100%",
            "200%",
            "300%",
            "400%"});
            this.tscbZoom.Name = "tscbZoom";
            this.tscbZoom.Size = new System.Drawing.Size(75, 37);
            this.tscbZoom.Text = "100%";
            this.tscbZoom.SelectedIndexChanged += new System.EventHandler(this.tscbZoom_SelectedIndexChanged);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(30, 30);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbEventObjectNode,
            this.tsbSchedulingLink,
            this.tsbSVLink,
            this.toolStripSeparator1,
            this.tsbAddLabel,
            this.tsbAddText,
            this.toolStripButton2});
            this.toolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.toolStrip1.Location = new System.Drawing.Point(4, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(242, 37);
            this.toolStrip1.TabIndex = 0;
            // 
            // tsbEventObjectNode
            // 
            this.tsbEventObjectNode.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbEventObjectNode.Image = ((System.Drawing.Image)(resources.GetObject("tsbEventObjectNode.Image")));
            this.tsbEventObjectNode.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEventObjectNode.Name = "tsbEventObjectNode";
            this.tsbEventObjectNode.Size = new System.Drawing.Size(34, 34);
            this.tsbEventObjectNode.Text = "Add a New Event Object";
            this.tsbEventObjectNode.Visible = false;
            this.tsbEventObjectNode.Click += new System.EventHandler(this.tsbEventObjectNode_Click);
            // 
            // tsbSchedulingLink
            // 
            this.tsbSchedulingLink.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSchedulingLink.Image = ((System.Drawing.Image)(resources.GetObject("tsbSchedulingLink.Image")));
            this.tsbSchedulingLink.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSchedulingLink.Name = "tsbSchedulingLink";
            this.tsbSchedulingLink.Size = new System.Drawing.Size(34, 34);
            this.tsbSchedulingLink.Text = "Add an Object Scheduling Edge";
            this.tsbSchedulingLink.ToolTipText = "Lane Link";
            this.tsbSchedulingLink.Click += new System.EventHandler(this.tsbSchedulingLink_Click);
            // 
            // tsbSVLink
            // 
            this.tsbSVLink.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSVLink.Image = ((System.Drawing.Image)(resources.GetObject("tsbSVLink.Image")));
            this.tsbSVLink.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSVLink.Name = "tsbSVLink";
            this.tsbSVLink.Size = new System.Drawing.Size(34, 34);
            this.tsbSVLink.Text = "Add a State Variable Link";
            this.tsbSVLink.Click += new System.EventHandler(this.tsbSVLink_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 37);
            // 
            // tsbAddLabel
            // 
            this.tsbAddLabel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAddLabel.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddLabel.Image")));
            this.tsbAddLabel.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAddLabel.Name = "tsbAddLabel";
            this.tsbAddLabel.Size = new System.Drawing.Size(34, 34);
            this.tsbAddLabel.Text = "Add a Label";
            this.tsbAddLabel.Visible = false;
            this.tsbAddLabel.Click += new System.EventHandler(this.tsbAddLabel_Click);
            // 
            // tsbAddText
            // 
            this.tsbAddText.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAddText.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddText.Image")));
            this.tsbAddText.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAddText.Name = "tsbAddText";
            this.tsbAddText.Size = new System.Drawing.Size(34, 34);
            this.tsbAddText.Text = "Add a Text";
            this.tsbAddText.Visible = false;
            this.tsbAddText.Click += new System.EventHandler(this.tsbAddText_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(34, 34);
            this.toolStripButton2.Text = "Set Background Color";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStrip4
            // 
            this.toolStrip4.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip4.ImageScalingSize = new System.Drawing.Size(30, 30);
            this.toolStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbLeft,
            this.tsbCenter,
            this.tsbRight,
            this.tsbTop,
            this.tsbMiddle,
            this.tsbBottom,
            this.toolStripSeparator4,
            this.tsbGrid});
            this.toolStrip4.Location = new System.Drawing.Point(437, 0);
            this.toolStrip4.Name = "toolStrip4";
            this.toolStrip4.Size = new System.Drawing.Size(232, 37);
            this.toolStrip4.TabIndex = 4;
            // 
            // tsbLeft
            // 
            this.tsbLeft.AutoSize = false;
            this.tsbLeft.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbLeft.Image = ((System.Drawing.Image)(resources.GetObject("tsbLeft.Image")));
            this.tsbLeft.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLeft.Name = "tsbLeft";
            this.tsbLeft.Size = new System.Drawing.Size(30, 30);
            this.tsbLeft.Text = "Align Left";
            this.tsbLeft.Click += new System.EventHandler(this.tsbLeft_Click);
            // 
            // tsbCenter
            // 
            this.tsbCenter.AutoSize = false;
            this.tsbCenter.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCenter.Image = ((System.Drawing.Image)(resources.GetObject("tsbCenter.Image")));
            this.tsbCenter.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCenter.Name = "tsbCenter";
            this.tsbCenter.Size = new System.Drawing.Size(30, 30);
            this.tsbCenter.Text = "Align Center";
            this.tsbCenter.Click += new System.EventHandler(this.tsbCenter_Click);
            // 
            // tsbRight
            // 
            this.tsbRight.AutoSize = false;
            this.tsbRight.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRight.Image = ((System.Drawing.Image)(resources.GetObject("tsbRight.Image")));
            this.tsbRight.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRight.Name = "tsbRight";
            this.tsbRight.Size = new System.Drawing.Size(30, 30);
            this.tsbRight.Text = "Align Right";
            this.tsbRight.Click += new System.EventHandler(this.tsbRight_Click);
            // 
            // tsbTop
            // 
            this.tsbTop.AutoSize = false;
            this.tsbTop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbTop.Image = ((System.Drawing.Image)(resources.GetObject("tsbTop.Image")));
            this.tsbTop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTop.Name = "tsbTop";
            this.tsbTop.Size = new System.Drawing.Size(30, 30);
            this.tsbTop.Text = "Align Top";
            this.tsbTop.Click += new System.EventHandler(this.tsbTop_Click);
            // 
            // tsbMiddle
            // 
            this.tsbMiddle.AutoSize = false;
            this.tsbMiddle.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMiddle.Image = ((System.Drawing.Image)(resources.GetObject("tsbMiddle.Image")));
            this.tsbMiddle.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbMiddle.Name = "tsbMiddle";
            this.tsbMiddle.Size = new System.Drawing.Size(30, 30);
            this.tsbMiddle.Text = "Align Middle";
            this.tsbMiddle.Click += new System.EventHandler(this.tsbMiddle_Click);
            // 
            // tsbBottom
            // 
            this.tsbBottom.AutoSize = false;
            this.tsbBottom.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbBottom.Image = ((System.Drawing.Image)(resources.GetObject("tsbBottom.Image")));
            this.tsbBottom.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbBottom.Name = "tsbBottom";
            this.tsbBottom.Size = new System.Drawing.Size(30, 30);
            this.tsbBottom.Text = "Align Bottom";
            this.tsbBottom.Click += new System.EventHandler(this.tsbBottom_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 37);
            // 
            // tsbGrid
            // 
            this.tsbGrid.Checked = true;
            this.tsbGrid.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsbGrid.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbGrid.Image = ((System.Drawing.Image)(resources.GetObject("tsbGrid.Image")));
            this.tsbGrid.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbGrid.Name = "tsbGrid";
            this.tsbGrid.Size = new System.Drawing.Size(34, 34);
            this.tsbGrid.Text = "Grid";
            this.tsbGrid.Click += new System.EventHandler(this.tsbGrid_Click);
            // 
            // OOMMDiagramWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(901, 765);
            this.Controls.Add(this.toolStripContainer1);
            this.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "OOMMDiagramWindow";
            this.ShowIcon = false;
            this.Text = "SEA Diagram";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OOEGDiagramWindow_FormClosing);
            this.Load += new System.EventHandler(this.OOEGDiagramWindow_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OOEGDiagramWindow_KeyDown);
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.toolStrip4.ResumeLayout(false);
            this.toolStrip4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.ToolStrip toolStrip4;
        private System.Windows.Forms.ToolStripButton tsbLeft;
        private System.Windows.Forms.ToolStripButton tsbCenter;
        private System.Windows.Forms.ToolStripButton tsbRight;
        private System.Windows.Forms.ToolStripButton tsbTop;
        private System.Windows.Forms.ToolStripButton tsbMiddle;
        private System.Windows.Forms.ToolStripButton tsbBottom;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton tsbZoomIn;
        private System.Windows.Forms.ToolStripButton tsbZoomOut;
        private System.Windows.Forms.ToolStripButton tsbZoomFit;
        private System.Windows.Forms.ToolStripComboBox tscbZoom;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbEventObjectNode;
        private System.Windows.Forms.ToolStripButton tsbSchedulingLink;
        private System.Windows.Forms.ToolStripButton tsbGrid;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsbAddLabel;
        private System.Windows.Forms.ToolStripButton tsbAddText;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ToolStripButton tsbSVLink;
    }
}