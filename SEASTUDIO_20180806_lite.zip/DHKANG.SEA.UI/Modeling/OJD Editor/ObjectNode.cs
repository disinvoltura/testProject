﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using Northwoods.Go;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.UI.OutputView;
using DHKANG.SEA.UI.ETTEditor;
using System.Drawing.Drawing2D;

namespace DHKANG.SEA.UI
{
    public abstract class ObjectNode : Node
    {
        #region Member Variables
        private Guid _NodeGuid;
        private Dictionary<string, object> _StateVariables;
        #endregion
      
        #region Properties
        public Guid NodeGuid { get { return _NodeGuid; } set { _NodeGuid = value; } }
        public override Color BackgroundColor
        {
            get
            {
                MultiPortNode presentation = (MultiPortNode)_Presentation;
                return presentation.BackgroundColor;
            }
            set
            {
                MultiPortNode presentation = (MultiPortNode)_Presentation;

                Color oldValue = presentation.BackgroundColor;
                presentation.BackgroundColor = value;

                doChange("BackgroundColor", oldValue, value);
            }
        }

        public List<string> StateVariables
        {
            get { return _StateVariables.Keys.ToList<string>(); }
        }

        public object this [string svName]
        {
            get {
                object rslt = null;
                if (_StateVariables.ContainsKey(svName))
                    rslt = _StateVariables[svName];
                return rslt;
            }
            set
            {
                object oldValue = null;
                if (_StateVariables.ContainsKey(svName))
                {
                    oldValue = _StateVariables[svName];
                    _StateVariables[svName] = value;
                }
                else
                    _StateVariables.Add(svName, value);

                doChange(svName, oldValue, value);
            }
        }
        #endregion

        #region Constructors
        public ObjectNode(int id, string name, NodeType type)
            : base(id, name, type)
        {
            _NodeGuid = Guid.NewGuid();
            string strType = "";
            if (type == NodeType.ActivityObject)
                strType = "Activity Object";
            else if (type == NodeType.EventObject)
                strType = "Event Object";
            else if (type == NodeType.StateObject)
                strType = "State Object";
            MultiPortNode presentation = new MultiPortNode(name, strType);
            presentation.UserObject = this;
            _Presentation = presentation;

            _StateVariables = new Dictionary<string, object>();

            //initialize(presentation);
        }

        public ObjectNode(int id, Guid guid, string name, NodeType type)
            : base(id, name, type)
        {
            _NodeGuid = guid;
            string strType = "";
            if (type == NodeType.ActivityObject)
                strType = "Activity Object";
            else if (type == NodeType.EventObject)
                strType = "Event Object";
            else if (type == NodeType.StateObject)
                strType = "State Object";
            MultiPortNode presentation = new MultiPortNode(name, strType);
            presentation.UserObject = this;
            _Presentation = presentation;

            _StateVariables = new Dictionary<string, object>();
            
            //initialize(presentation);
        }
        #endregion

        #region Methods
        private void initialize(MultiPortNode node)
        {
            //alt 1
            /*
            LinearGradientBrush brush = new LinearGradientBrush(this.Bounds, Color.White, Color.LightBlue, 90.0f);
            this.Brush = brush;
            this.BorderPen = new Pen(Color.LightBlue);
            */

            //alt 2
            //LinearGradientBrush brush = new LinearGradientBrush(node.Bounds, Color.FromArgb(116, 116, 191), Color.FromArgb(52, 138, 199), 270.0f);
            LinearGradientBrush brush = new LinearGradientBrush(node.Bounds, Color.FromArgb(131,164,212),  Color.FromArgb(182,251,255), 270.0f);
            //LinearGradientBrush brush = new LinearGradientBrush(this.Bounds, Color.FromArgb(75, 108, 183),  Color.FromArgb(24, 40, 72), 270.0f);
            //LinearGradientBrush brush = new LinearGradientBrush(this.Bounds, Color.FromArgb(115,200,169),  Color.FromArgb(55, 59, 68), 90.0f);
            node.Brush = brush;
            node.BorderPen = new Pen(Color.FromArgb(131, 164, 212));


        }
        public override int FindPortIndex(IGoPort port)
        {
            return 0;
        }

        public override IGoPort FindShortestDistancePort(int x, int y)
        {
            return ((MultiPortNode)_Presentation).FindShortestDistancePort(x, y);
        }

        public override IGoPort FindPort(int portid)
        {
            return ((MultiPortNode)_Presentation).FindPort(portid);
            
        }
        #endregion
    }
}
