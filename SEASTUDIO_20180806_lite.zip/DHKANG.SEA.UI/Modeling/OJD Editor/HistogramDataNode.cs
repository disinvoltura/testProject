﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Northwoods.Go;
using System.Windows.Forms;
using DHKANG.SEA.UI.OutputView;
using DHKANG.SEA.Model;
using DHKANG.Foundation.DataCollection;

namespace DHKANG.SEA.UI
{
    public class HistogramDataNode : GoSimpleNode //GoText
    {
        private static int ICON_WIDTH = 20;
        private static int ICON_HEIGHT = 20;

        #region Member Variables
        private Guid _NodeID;
        private string _Name;
        private string _Value;
        private string _Description;
        private HistogramData _HistogramData;
        #endregion

        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Properties
        public string Name 
        {
            get { return _Name; }
            set {
                string oldValue = _Name;
                _Name = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Name", oldValue, value);
            }
        }

        public HistogramData HistogramData
        {
            get { return _HistogramData; }
            set { _HistogramData = value; }
        }
        
        public Guid NodeID 
        {
            get { return _NodeID; }
            set {
                Guid oldValue = _NodeID;
                _NodeID = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "NodeID", oldValue, value);
            }
        }

        public string Value
        {
            get { return _Value; }
            set {
                string oldValue = _Value;
                _Value = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Value", oldValue, value);
            }
        }

        public string Description
        {
            get { return _Description; }
            set {
                string oldValue = _Description;
                _Description = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Description", oldValue, value);
            }
        }
        #endregion

        #region Constructors
        public HistogramDataNode(string name, float x, float y)
        {
            _NodeID = Guid.NewGuid();
            _Name = name;

            initialize(x, y);
        }

        public HistogramDataNode(Guid nodeid, string name, string value, float x, float y)
        {
            _NodeID = nodeid;
            _Name = name;
            _Value= value;

            initialize(x, y);
        }

        private void initialize(float x, float y)
        {
            this.Initialize(null, null, _Name);
            this.Figure = GoFigure.MultiDocument;
            //this.Image.Name = “special.gif”
            this.Icon.Size = new SizeF(ICON_WIDTH, ICON_HEIGHT);
            this.Icon.Resizable = false;
            this.Shape.FillShapeGradient(Color.Orange);
            this.Orientation = Orientation.Vertical;
            this.InPort.Visible = false;
            this.OutPort.Visible = false;
            this.Editable = false;
            this.Left = x;
            this.Top = y;

            this.UpdateText();
        }
        #endregion

        #region Methods
        public void UpdateText()
        {
            this.Text = "   " + _Name;
        }

        public void Reset()
        {
        }

        public override string GetToolTip(GoView view)
        {
            string tooltip = string.Empty;
            if (_HistogramData != null)
            {
                tooltip = this.Name;
                tooltip += " Count: " + _HistogramData.Count;
                tooltip += " Value - minimum: " + _HistogramData.MinValue;
                tooltip += " Value - maximum: " + _HistogramData.MaxValue;
            }
            else
            {
                tooltip = _Name + "(" + _Value + "):\r\n" + _Description;
            }
            return tooltip;
        }
        #endregion
    }
}
