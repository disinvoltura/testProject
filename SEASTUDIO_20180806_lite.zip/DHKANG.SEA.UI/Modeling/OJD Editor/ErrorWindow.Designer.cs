﻿namespace DHKANG.SEA.UI
{
    partial class ErrorWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ErrorWindow));
            this.grid = new SourceGrid.DataGrid();
            this.SuspendLayout();
            // 
            // grid
            // 
            this.grid.DeleteQuestionMessage = "Are you sure to delete all the selected rows?";
            this.grid.DeleteRowsWithDeleteKey = false;
            this.grid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid.EnableSort = false;
            this.grid.FixedRows = 1;
            this.grid.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grid.Location = new System.Drawing.Point(0, 0);
            this.grid.Name = "grid";
            this.grid.SelectionMode = SourceGrid.GridSelectionMode.Row;
            this.grid.Size = new System.Drawing.Size(325, 413);
            this.grid.TabIndex = 3;
            this.grid.TabStop = true;
            this.grid.ToolTipText = "";
            // 
            // ErrorWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(325, 413);
            this.Controls.Add(this.grid);
            this.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "ErrorWindow";
            this.Text = "Error List";
            this.ResumeLayout(false);

        }

        #endregion

        private SourceGrid.DataGrid grid;
    }
}