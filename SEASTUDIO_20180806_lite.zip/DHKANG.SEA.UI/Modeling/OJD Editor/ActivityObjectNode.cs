﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using Northwoods.Go;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.UI.OutputView;
using DHKANG.SEA.UI.ETTEditor;
using DHKANG.SEA.Model.ActivityObjects;
using DHKANG.SEA.UI.ATTEditor;

namespace DHKANG.SEA.UI
{
    public class ActivityObjectNode : ObjectNode
    {
        #region Member Variables
        private OOAGActivityObjectModel _Model;
        #endregion
      
        #region Properties
        public OOAGActivityObjectModel Model { 
            get {
                //_Model.X = this.Presentation.Position.X;
                //_Model.Y = this.Presentation.Position.Y;
                //_Model.BackgroundColor = this.BackgroundColor.ToArgb();

                return _Model; }
            set { _Model = value; }
        }
        #endregion

        #region Constructors
        public ActivityObjectNode(int id, string name)
            : base(id, name, NodeType.ActivityObject)
        {
        }

        public ActivityObjectNode(int id, string name, OOAGActivityObjectModel model)
            : this(id, name)
        {
            _Model = model;
        }

        public ActivityObjectNode(int id, Guid guid, string name, OOAGActivityObjectModel model)
            : base(id, guid, name, NodeType.ActivityObject)
        {
            _Model = model;
        }
        #endregion

        #region Methods
        public override bool ShowDialog(bool read)
        {
            ActivityObjectModelEditor editor =
                new ActivityObjectModelEditor(_Model);

            DialogResult rslt = editor.ShowDialog(MainUI.App);
            if (rslt == DialogResult.OK)
            {
                _Model = editor.ActivityObjectModel;
            }

            return true;
        }
        #endregion
    }
}
