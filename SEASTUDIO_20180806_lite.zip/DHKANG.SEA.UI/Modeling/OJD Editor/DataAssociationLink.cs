﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using Northwoods.Go;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.OID;

namespace DHKANG.SEA.UI
{
    public class DataAssociationLink : Link
    {
        #region Member Variables
        private OOMMDataAssociationEdge _Edge;
        private List<OOMMDataMapper> _Mappers;        
        #endregion
        
        #region Properties
        public List<OOMMDataMapper> DataMappers
        {
            get { return _Mappers; }
        }

        public OOMMDataAssociationEdge DataAssociationEdge
        {
            get
            {
                Guid sourceObject = Guid.Empty;
                Guid targetObject = Guid.Empty;
                int sourcePort = 0;
                int targetPort = 0;
                if (this.FromNode is DataSourceNode)
                {
                    sourceObject = ((DataSourceNode)this.FromNode).DataSource.ID;
                    sourcePort = ((DataSourceNode)this.FromNode).FindPortIndex(this.FromPort);
                }
                if (this.ToNode is MultiPortNode)
                {
                    targetObject = ((ObjectNode)((MultiPortNode)this.ToNode).UserObject).NodeGuid;
                    targetPort = ((MultiPortNode)this.ToNode).FindPortIndex(this.ToPort);
                }

                _Edge = new OOMMDataAssociationEdge(0, sourceObject, sourcePort, targetObject, targetPort, (int)this.Style);
                foreach (OOMMDataMapper mapper in _Mappers)
                    _Edge.AddDataMapper(mapper);

                return _Edge;
            }set
            {
                _Edge = value;
            }
        }
        #endregion

        #region Constructors
        public DataAssociationLink(int id)
            : base(id)
        {
            _Edge = new OOMMDataAssociationEdge();
            _Mappers = new List<OOMMDataMapper>();
            _LinkType = LinkType.DataAssociationLink;

            drawLine();
        }

        public DataAssociationLink(int id, OOMMDataAssociationEdge edge)
        : base(id)
        {
            _Edge = edge;
            _Mappers = edge.DataMappers;
            _LinkType = LinkType.DataAssociationLink;

            drawLine();
        }
        #endregion  

        #region Methods
        public void AddDataMapper(OOMMDataMapper mapper)
        {
            _Mappers.Add(mapper);
        }

        public void RemoveDataMapper(OOMMDataMapper mapper)
        {
            _Mappers.Remove(mapper);
        }

        protected void drawLine()
        {
            this.AvoidsNodes = true;
            this.Brush = Brushes.Black;
            this.ToArrow = true;
            this.ToArrowFilled = true;
            this.ToArrowStyle = GoStrokeArrowheadStyle.Polygon;
            this.ToArrowWidth = 4.0f;
            this.ToArrowLength = 3.0f;
            this.ToArrowShaftLength = 2.0f;
            this.Style = GoStrokeStyle.Line;//GoStrokeStyle.Bezier;// GoStrokeStyle.Bezier;
            this.UserFlags = _LinkID;
            //link.Orthogonal = true;

            Pen p = new Pen(Brushes.DarkGray);
            p.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.Pen = p;

            //From Label
            GoText lblFrom = new GoText();
            lblFrom.Selectable = false;
            lblFrom.Editable = false;
            lblFrom.Text = "";
            //lblFrom.Font = new Font(FontFamily.GenericSansSerif, ObjectInteractionView.ARCATTRIBUTE_FONTSIZE, FontStyle.Italic);
            lblFrom.TextColor = Color.Black;// GraphView.ARCATTRIBUTE_COLOR;

            this.FromLabel = lblFrom;
            this.FromLabelCentered = true;

            //To Label
            GoText lblTo = new GoText();
            lblTo.Selectable = false;
            lblTo.Editable = false;
            lblTo.Text = "";
            //lblTo.Font = new Font(FontFamily.GenericSansSerif, ObjectInteractionView.ARCATTRIBUTE_FONTSIZE, FontStyle.Italic);
            lblTo.TextColor = Color.Black;// GraphView.ARCATTRIBUTE_COLOR;
            this.ToLabel = lblTo;
            this.ToLabelCentered = true;
        }

        public override bool ShowDialog(bool read)
        {
            return true;
            /*
            ObjectSchedulingLinkDialog dialog
                 = new ObjectSchedulingLinkDialog( 
                     this._LinkID,
                     ((EventObjectNode)((MultiPortNode)this.FromNode).UserObject).NodeGuid, //this.FromEventObjectID,
                     this.FromEventName,
                     this.Parameters,
                     ((EventObjectNode)((MultiPortNode)this.ToNode).UserObject).NodeGuid, //this.ToEventObjectID,
                     this.ToEventName
                     );

            DialogResult rslt = dialog.ShowDialog();

            bool success = false;
            if (!read)
            {
                if (rslt == DialogResult.OK)
                {
                    this.FromEventName = dialog.FromEventName;
                    this.ToEventName = dialog.ToEventName;
                    this.Parameters = dialog.Parameters;

                    success = true;
                }
            }
            return success;
            */
        }

        public override void DoResize(GoView view, RectangleF origRect, PointF newPoint,
                              int whichHandle, GoInputState evttype, SizeF min, SizeF max)
        {
            base.DoResize(view, origRect, newPoint, whichHandle, evttype, min, max);
            this.AdjustingStyle = GoLinkAdjustingStyle.Scale;
        }
        #endregion
    }
}
