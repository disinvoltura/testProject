﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Northwoods.Go;
using System.Windows.Forms;
using DHKANG.SEA.UI.OutputView;
using DHKANG.SEA.Model;
using DHKANG.Foundation.DataCollection;

namespace DHKANG.SEA.UI
{
    public class DataSetNode : GoSimpleNode //GoText
    {
        private static int ICON_WIDTH = 20;
        private static int ICON_HEIGHT = 20;

        #region Member Variables
        private Guid _NodeID;
        private string _DataSetName;
        private string _XAxisValue;
        private string _YAxisValue;
        private string _Description;
        private DataSet _DataSet;
        #endregion

        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Properties
        public string DataSetName 
        {
            get { return _DataSetName; }
            set {
                string oldValue = _DataSetName;
                _DataSetName = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "DataSetName", oldValue, value);
            }
        }

        public DataSet DataSet
        {
            get { return _DataSet; }
            set { _DataSet = value; }
        }
        
        public Guid NodeID 
        {
            get { return _NodeID; }
            set {
                Guid oldValue = _NodeID;
                _NodeID = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "NodeID", oldValue, value);
            }
        }

        public string XAxsisValue
        {
            get { return _XAxisValue; }
            set {
                string oldValue = _XAxisValue;
                _XAxisValue = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "XAxsisValue", oldValue, value);
            }
        }

        public string YAxisValue 
        {
            get { return _YAxisValue; }
            set {
                string oldValue = _YAxisValue;
                _YAxisValue = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "YAxisValue", oldValue, value);
            }
        }

        public string Description
        {
            get { return _Description; }
            set {
                string oldValue = _Description;
                _Description = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Description", oldValue, value);
            }
        }
        #endregion

        #region Constructors
        public DataSetNode(string name, float x, float y)
        {
            _NodeID = Guid.NewGuid();
            _DataSetName = name;

            initialize(x, y);
        }

        public DataSetNode(Guid nodeid, string name, string xaxisValue, string yaxisValue, float x, float y)
        {
            _NodeID = nodeid;
            _DataSetName = name;
            _XAxisValue= xaxisValue;
            _YAxisValue= yaxisValue;

            initialize(x, y);
        }

        private void initialize(float x, float y)
        {
            this.Initialize(null, null, _DataSetName);
            this.Figure = GoFigure.DiskStorage;
            //this.Image.Name = “special.gif”
            this.Icon.Size = new SizeF(ICON_WIDTH, ICON_HEIGHT);
            this.Icon.Resizable = false;
            this.Shape.FillShapeGradient(Color.Orange);
            this.Orientation = Orientation.Vertical;
            this.InPort.Visible = false;
            this.OutPort.Visible = false;
            this.Editable = false;
            this.Left = x;
            this.Top = y;

            this.UpdateText();
        }
        #endregion

        #region Methods
        public void UpdateText()
        {
            this.Text = "   " + _DataSetName;
        }

        public void Reset()
        {
        }

        public override string GetToolTip(GoView view)
        {
            string tooltip = string.Empty;
            if (_DataSet != null)
            {
                tooltip = this.DataSetName;
                tooltip += " Count: " + _DataSet.Count;
                tooltip += " X-axis Value - minimum: " + _DataSet.MinXValue;
                tooltip += " X-axis Value - maximum: " + _DataSet.MaxXValue;
                tooltip += " Y-axis Value - minimum: " + _DataSet.MinYValue;
                tooltip += " Y-axis Value - maximum: " + _DataSet.MaxYValue;
            }
            else
            {
                tooltip = _DataSetName + "(" + _XAxisValue + "," + YAxisValue + "):\r\n" + _Description;
            }
            return tooltip;
        }

        /*
        public bool ShowDialog()
        {
            bool rslt = false;

            OOEGEventGraphModel model = MainForm.App.getCurrentEditor().BuildModel();
            LabelNodeDialog dialog = new LabelNodeDialog(model, this);
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                OOEGEventObjectModel eoModel = model.FindEventObjectModel(dialog.EventObjectName);
                OOEGStateVariable sv = eoModel.GetStateVariable(dialog.StateVariableName);

                this.EventObjectID = eoModel.ID;
                this.EventObjectName = eoModel.Name;
                this.StateVariableName = sv.Name;
                this.InitialValue = sv.InitialValue;
                rslt = true;
            }
            return rslt;
        }
        */

        /*
        public bool ShowFontDialog()
        {
            bool rslt = false;

            FontDialog dialog = new FontDialog();
            dialog.Font = this.Font;
            dialog.ShowColor = true;
            dialog.ShowEffects = true;
            dialog.Color = this.TextColor;

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                this.Font = dialog.Font;
                this.TextColor = dialog.Color;
                rslt = true;
            }

            return rslt;
        }
        */
        #endregion
    }
}
