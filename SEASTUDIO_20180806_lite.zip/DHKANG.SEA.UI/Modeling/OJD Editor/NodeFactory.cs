﻿using DHKANG.SEA.UI.ETTEditor;
using DHKANG.SEA.UI.STTEditor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.UI
{
    public class NodeFactory
    {
        private Dictionary<string, int> _TypeIDList;
        private int _NodeID = 1;
        //private int _LastID = 1;
        private DiagramDocument _Document;

        public DiagramDocument Document
        {
            set { _Document = value; }
        }

        public NodeFactory()
        {
            _TypeIDList = new Dictionary<string, int>();

            string[] namelist = Enum.GetNames(typeof(NodeType));
            foreach (string name in namelist)
            {
                _TypeIDList.Add(name, 1);
            }
        }

        public int NextTypeID(NodeType type)
        {
            int typeID = _TypeIDList[type.ToString()];
            _TypeIDList[type.ToString()]++;

            return typeID;
        }

        public Node GetInstance(NodeType type)
        {
            Node rslt = null;

            //NodeID 는 Node Type 에 상관없이 Unique 해야 함
            int typeID = NextTypeID(type);

            string name = type.ToString() + " " + typeID;

            while (_Document.FindNode(name) != null)
            {
                typeID++;
                _TypeIDList[type.ToString()] = typeID;

                name = type.ToString() + " " + typeID;
            }

            while (_Document.FindNode(_NodeID) != null)
            {
                _NodeID++;
            }

            if (type == NodeType.EventObject)
            {
                rslt = new EventObjectNode(_NodeID, name);
            } else if (type == NodeType.StateObject)
            {
                rslt = new StateObjectNode(_NodeID, name);
            } else if (type == NodeType.EventVertex)
            {
                rslt = new EventVertexNode(_NodeID, name);
            } else if (type == NodeType.StateVertex)
                rslt = new StateVertexNode(_NodeID, name);
            else if (type == NodeType.ActivityObject)
            {
                rslt = new ActivityObjectNode(_NodeID, name);
            }
            //_LastID++;

            return rslt;
        }

        public Node GetInstance(NodeType type, string name)
        {
            Node rslt = null;

            if (type == NodeType.EventObject)
            {
                rslt = new EventObjectNode(_NodeID, name);
            } else if (type == NodeType.StateObject)
            {
                rslt = new StateObjectNode(_NodeID, name);
            }else if (type == NodeType.ActivityObject){
                rslt = new ActivityObjectNode(_NodeID, name);
            }
            else if (type == NodeType.EventVertex)
            {
                rslt = new EventVertexNode(_NodeID, name);
            }else if (type == NodeType.StateVertex)
                rslt = new StateVertexNode(_NodeID, name);

            return rslt;
        }

    }
}
