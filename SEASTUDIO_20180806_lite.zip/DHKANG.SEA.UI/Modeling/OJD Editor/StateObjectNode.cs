﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using Northwoods.Go;
using DHKANG.SEA.Model;
using DHKANG.SEA.UI.OutputView;
using DHKANG.SEA.UI.ETTEditor;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.UI.STTEditor;

namespace DHKANG.SEA.UI
{
    public class StateObjectNode : ObjectNode
    {
        #region Member Variables
        private OOSGStateObjectModel _Model;
        #endregion
      
        #region Properties
        public OOSGStateObjectModel Model { 
            get {
                _Model.BackgroundColor = this.BackgroundColor.ToArgb();

                return _Model; }
            set { _Model = value; }
        }
        #endregion

        #region Constructors
        public StateObjectNode(int id, string name)
            : base(id, name, NodeType.StateObject)
        {
        }

        public StateObjectNode(int id, string name, OOSGStateObjectModel model)
            : base(id, name, NodeType.StateObject)
        {
            _Model = model;
        }
        public StateObjectNode(int id, Guid guid, string name, OOSGStateObjectModel model)
            : base(id, guid, name, NodeType.StateObject)
        {
            _Model = model;
        }
        #endregion

        #region Methods
        public override bool ShowDialog(bool read)
        {
            /*
            StateObjectModelEditor editor =
                new StateObjectModelEditor(_Model);

            DialogResult rslt = editor.ShowDialog(MainUI.App);
            if (rslt == DialogResult.OK)
            {
                _Model = editor.StateObjectModel;
            }
            */
            return true;

        }
        #endregion
       
    }
}
