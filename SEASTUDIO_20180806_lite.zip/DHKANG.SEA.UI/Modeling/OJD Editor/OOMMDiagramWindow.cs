﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using Northwoods.Go;
using DHKANG.SEA.UI.OutputView.Visualization;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.OID;
using DHKANG.SEA.Model.Data;
using DHKANG.SEA.Model.OID.Presentation;
using DHKANG.SEA.Model.OID.Data;
using DHKANG.SEA.Model.OID.Charts;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model.ActivityObjects;

namespace DHKANG.SEA.UI
{
    public delegate void DiagramSelectionChangedEventHandler(string selectionType, string objectType);
    public delegate void DiagramObjectSelectedEventHandler(OOMMModel model, object target);
    //public delegate void DiagramChangedEvent();

    public partial class OOMMDiagramWindow : DockContent
    {
        #region Member Variables
        private OOMMDiagramView _View;
        private string _ModelName;
        private OOMMModel _Model;
        #endregion

        #region Properties
        public string ModelName { get { return _ModelName; } set { _ModelName = value; } }
        public float ViewScale
        {
            get { return _View.DocScale; }
        }

        public OOMMModel Model { get { return _Model; } }

        public OOMMObjectInteractionDiagram ObjectInteractionDiagram
        {
            get
            {
                OOMMObjectInteractionDiagram diagram = new OOMMObjectInteractionDiagram();

                //Event Object Nodes
                List<Node> nodelist = GetObjectNodes();
                List<OOMMObjectNode> objectNodes = new List<OOMMObjectNode>();
                foreach (Node n in nodelist)
                {
                    ObjectNodeType nodeType = ObjectNodeType.EventObject;
                    ObjectNode objectNode = (ObjectNode)n;
                    Guid modelid = Guid.Empty;
                    if (objectNode.ObjectType == NodeType.EventObject)
                    {
                        nodeType = ObjectNodeType.EventObject;
                        modelid = ((EventObjectNode)objectNode).Model.ID;
                    }
                    else if (objectNode.ObjectType == NodeType.StateObject)
                    {
                        nodeType = ObjectNodeType.StateObject;
                        modelid = ((StateObjectNode)objectNode).Model.ID;
                    }
                    else if (objectNode.ObjectType == NodeType.ActivityObject)
                    {
                        nodeType = ObjectNodeType.ActivityObject;
                        modelid = ((ActivityObjectNode)objectNode).Model.ID;
                    }
                    OOMMObjectNode node =
                        new OOMMObjectNode(
                                objectNode.NodeGuid,
                                objectNode.NodeName,
                                modelid,
                                nodeType,
                                objectNode.Presentation.Position.X,
                                objectNode.Presentation.Position.Y,
                                objectNode.BackgroundColor.ToArgb());

                    foreach (string svName in objectNode.StateVariables)
                    {
                        node.AddStateVariable(svName, objectNode[svName].ToString());
                    }

                    objectNodes.Add(node);
                }
                diagram.ObjectNodes = objectNodes;

                //Data Source Nodes
                List<DataSourceNode> dsNodeList = GetDataSourceNodes();
                foreach (DataSourceNode n in dsNodeList)
                {
                    OOMMDataSourceNode dsNode =
                        new OOMMDataSourceNode(n.DataSource.ID, n.DataSource.Name, n.Position.X, n.Position.Y);

                    diagram.DataSourceNodes.Add(dsNode);
                }

                //Text Node
                List<TextNode> textNodeList = GetTextNodes();
                foreach (TextNode n in textNodeList)
                {
                    OOMMTextNode tn = new OOMMTextNode(n.TextValue, n.Position.X, n.Position.Y);

                    OOMMFont font = new OOMMFont(n.Font.Name, n.TextColor.ToArgb(), n.Font.Size, n.Font.Bold, n.Font.Italic, n.Font.Underline, n.Font.Strikeout);
                    tn.Font = font;

                    diagram.Texts.Add(tn);
                }

                //Label Node
                List<LabelNode> labelNodeList = GetLabelNodes();
                foreach (LabelNode n in labelNodeList)
                {
                    OOMMLabelNode ln =
                        new OOMMLabelNode(
                            n.NodeID,
                            n.LabelName,
                            n.ObjectID,
                            n.StateVariableName,
                            n.Position.X,
                            n.Position.Y);

                    OOMMFont font = new OOMMFont(n.Font.Name, n.TextColor.ToArgb(), n.Font.Size, n.Font.Bold, n.Font.Italic, n.Font.Underline, n.Font.Strikeout);
                    ln.Font = font;

                    diagram.Labels.Add(ln);
                }

                //Data Set Node
                List<DataSetNode> datasetNodeList = GetDataSetNodes();
                foreach (DataSetNode n in datasetNodeList)
                {
                    OOMMDataSetNode ln =
                        new OOMMDataSetNode(
                            n.NodeID,
                            n.DataSetName,
                            n.XAxsisValue,
                            n.YAxisValue,
                            n.Description,
                            n.Position.X,
                            n.Position.Y);

                    diagram.DataSetNodes.Add(ln);
                }

                //Histogram Data Node
                List<HistogramDataNode> histogramDataNodeList = GetHistogramDataNodes();
                foreach (HistogramDataNode n in histogramDataNodeList)
                {
                    OOMMHistogramDataNode ln =
                        new OOMMHistogramDataNode(
                            n.NodeID,
                            n.Name,
                            n.Value,
                            n.Description,
                            n.Position.X,
                            n.Position.Y);

                    diagram.HistogramDataNodes.Add(ln);
                }

                //Statistics Node
                List<StatisticsNode> statisticsNodeList = GetStatisticsNodes();
                foreach (StatisticsNode n in statisticsNodeList)
                {
                    OOMMStatisticsNode ln =
                        new OOMMStatisticsNode(
                            n.NodeID,
                            n.StatisticsName,
                            n.Source,
                            n.Type,
                            n.Description,
                            n.Position.X,
                            n.Position.Y);

                    diagram.StatisticsNodes.Add(ln);
                }

                //Bar Charts
                List<BarChart> barchartList = GetBarChartNodes();
                foreach (BarChart n in barchartList)
                {
                    OOMMSeriesCollection col = new OOMMSeriesCollection();

                    foreach (string seriesName in n.Series.SeriesNames)
                    {
                        Series s = n.Series[seriesName];

                        OOMMSeriesChartType scType = OOMMSeriesChartType.Bar;
                        OOMMMarkerType mType = OOMMMarkerType.None;
                        OOMMSeriesAppearance app =
                            new OOMMSeriesAppearance(s.LineWidth, s.BackgroundColor, s.MarkerColor, s.LineColor, mType);
                        OOMMSeries ns = new OOMMSeries(s.Name, s.Value, scType, app);

                        col.Add(ns);
                    }

                    OOMMBarChart ln = new OOMMBarChart(n.ChartTitle, n.Descrition, col, n.Left, n.Top, n.Width, n.Height);
                    ln.Direction = OOMMChartDirection.Vertical;
                    ln.IsStacked = false;
                    ln.Appearance = new OOMMChartAppearance(n.BackgroundColor, n.NameColor, n.DescriptionColor, n.BorderColor, n.BorderWeight);

                    diagram.BarCharts.Add(ln);
                }

                //Stacked Bar Charts
                List<StackedBarChart> stackedBCList = GetStackedBarChartNodes();
                foreach (StackedBarChart n in stackedBCList)
                {
                    OOMMSeriesCollection col = new OOMMSeriesCollection();

                    foreach (string seriesName in n.Series.SeriesNames)
                    {
                        Series s = n.Series[seriesName];

                        OOMMSeriesChartType scType = OOMMSeriesChartType.Bar;
                        OOMMMarkerType mType = OOMMMarkerType.None;
                        OOMMSeriesAppearance app =
                            new OOMMSeriesAppearance(s.LineWidth, s.BackgroundColor, s.MarkerColor, s.LineColor, mType);
                        OOMMSeries ns = new OOMMSeries(s.Name, s.Value, scType, app);

                        col.Add(ns);
                    }

                    OOMMBarChart ln = new OOMMBarChart(n.ChartTitle, n.Descrition, col, n.Left, n.Top, n.Width, n.Height);
                    ln.Direction = OOMMChartDirection.Vertical;
                    ln.IsStacked = true;
                    ln.Appearance = new OOMMChartAppearance(n.BackgroundColor, n.NameColor, n.DescriptionColor, n.BorderColor, n.BorderWeight);

                    diagram.BarCharts.Add(ln);
                }

                //Horizontal Bar Charts
                List<HorizontalBarChart> horizontalBCList = GetHorizontalBarChartNodes();
                foreach (HorizontalBarChart n in horizontalBCList)
                {
                    OOMMSeriesCollection col = new OOMMSeriesCollection();

                    foreach (string seriesName in n.Series.SeriesNames)
                    {
                        Series s = n.Series[seriesName];

                        OOMMSeriesChartType scType = OOMMSeriesChartType.Bar;
                        OOMMMarkerType mType = OOMMMarkerType.None;
                        OOMMSeriesAppearance app =
                            new OOMMSeriesAppearance(s.LineWidth, s.BackgroundColor, s.MarkerColor, s.LineColor, mType);
                        OOMMSeries ns = new OOMMSeries(s.Name, s.Value, scType, app);

                        col.Add(ns);
                    }

                    OOMMBarChart ln = new OOMMBarChart(n.ChartTitle, n.Descrition, col, n.Left, n.Top, n.Width, n.Height);
                    ln.Direction = OOMMChartDirection.Horizontal;
                    ln.IsStacked = false;
                    ln.Appearance = new OOMMChartAppearance(n.BackgroundColor, n.NameColor, n.DescriptionColor, n.BorderColor, n.BorderWeight);

                    diagram.BarCharts.Add(ln);
                }

                //Stacked Horizontal Bar Charts
                List<StackedHorizontalBarChart> stackedHorizontalBCList = GetStackedHorizontalBarChartNodes();
                foreach (StackedHorizontalBarChart n in stackedHorizontalBCList)
                {
                    OOMMSeriesCollection col = new OOMMSeriesCollection();

                    foreach (string seriesName in n.Series.SeriesNames)
                    {
                        Series s = n.Series[seriesName];

                        OOMMSeriesChartType scType = OOMMSeriesChartType.Bar;
                        OOMMMarkerType mType = OOMMMarkerType.None;
                        OOMMSeriesAppearance app =
                            new OOMMSeriesAppearance(s.LineWidth, s.BackgroundColor, s.MarkerColor, s.LineColor, mType);
                        OOMMSeries ns = new OOMMSeries(s.Name, s.Value, scType, app);

                        col.Add(ns);
                    }

                    OOMMBarChart ln = new OOMMBarChart(n.ChartTitle, n.Descrition, col, n.Left, n.Top, n.Width, n.Height);
                    ln.Direction = OOMMChartDirection.Horizontal;
                    ln.IsStacked = true;
                    ln.Appearance = new OOMMChartAppearance(n.BackgroundColor, n.NameColor, n.DescriptionColor, n.BorderColor, n.BorderWeight);

                    diagram.BarCharts.Add(ln);
                }

                //tile
                List<Tile> tileList = GetTileNodes();
                foreach (Tile n in tileList)
                {

                    OOMMTile tile = new OOMMTile(n.TileName, n.TileValue, n.BackgroundColor, n.NameColor, n.ValueColor, n.BorderColor, n.Left, n.Top, n.Width, n.Height);
                    tile.TargetObjectId = n.TargetObjectId;
                    tile.TargetObject = n.TargetObject;
                    tile.TargetVariable = n.TargetVariable;
                    tile.InitialValue = n.InitialValue;
                    tile.BackgroundColor = n.BackgroundColor.ToArgb();
                    tile.NameColor = n.NameColor.ToArgb();
                    tile.ValueColor = n.ValueColor.ToArgb();
                    tile.BorderColor = n.BorderColor.ToArgb();
                    diagram.Tiles.Add(tile);
                }

                //Pie Charts
                List<PieChart> piechartList = GetPieChartNodes();
                foreach (PieChart n in piechartList)
                {
                    OOMMSeriesCollection col = new OOMMSeriesCollection();

                    foreach (string seriesName in n.Series.SeriesNames)
                    {
                        Series s = n.Series[seriesName];

                        OOMMSeriesChartType scType = OOMMSeriesChartType.Bar;
                        OOMMMarkerType mType = OOMMMarkerType.None;
                        OOMMSeriesAppearance app =
                            new OOMMSeriesAppearance(s.LineWidth, s.BackgroundColor, s.MarkerColor, s.LineColor, mType);
                        OOMMSeries ns = new OOMMSeries(s.Name, s.Value, scType, app);

                        col.Add(ns);
                    }

                    OOMMPieChart ln = new OOMMPieChart(n.ChartTitle, n.Descrition, col, n.Left, n.Top, n.Width, n.Height);
                    ln.Appearance = new OOMMChartAppearance(n.BackgroundColor, n.NameColor, n.DescriptionColor, n.BorderColor, n.BorderWeight);

                    diagram.PieCharts.Add(ln);
                }

                //Donut Charts
                List<DonutChart> donutChartList = GetDonutChartNodes();
                foreach (DonutChart n in donutChartList)
                {
                    OOMMSeriesCollection col = new OOMMSeriesCollection();

                    foreach (string seriesName in n.Series.SeriesNames)
                    {
                        Series s = n.Series[seriesName];
                        OOMMSeriesChartType scType = OOMMSeriesChartType.Donut;
                        OOMMMarkerType mType = OOMMMarkerType.None;
                        OOMMSeriesAppearance app =
                            new OOMMSeriesAppearance(s.LineWidth, s.BackgroundColor, s.MarkerColor, s.LineColor, mType);
                        OOMMSeries ns = new OOMMSeries(s.Name, s.Value, scType, app);
                        col.Add(ns);
                    }

                    OOMMDonutChart ln = new OOMMDonutChart(n.ChartTitle, n.Descrition, col, n.Left, n.Top, n.Width, n.Height);
                    ln.Appearance = new OOMMChartAppearance(n.BackgroundColor, n.NameColor, n.DescriptionColor, n.BorderColor, n.BorderWeight);

                    diagram.DonutCharts.Add(ln);
                }

                //Histogram
                List<Histogram> histogramList = GetHistogramNodes();
                foreach (Histogram n in histogramList)
                {
                    OOMMSeriesCollection col = new OOMMSeriesCollection();

                    foreach (string seriesName in n.Series.SeriesNames)
                    {
                        Series s = n.Series[seriesName];
                        OOMMSeriesChartType scType = OOMMSeriesChartType.Histogram;
                        OOMMMarkerType mType = OOMMMarkerType.None;
                        OOMMSeriesAppearance app =
                            new OOMMSeriesAppearance(s.LineWidth, s.BackgroundColor, s.MarkerColor, s.LineColor, mType);
                        OOMMSeries ns = new OOMMSeries(s.Name, s.Value, scType, app);
                        col.Add(ns);
                    }

                    OOMMHistogram ln = new OOMMHistogram(n.ChartTitle, n.Descrition, col, n.Left, n.Top, n.Width, n.Height);
                    ln.Appearance = new OOMMChartAppearance(n.BackgroundColor, n.NameColor, n.DescriptionColor, n.BorderColor, n.BorderWeight);

                    diagram.Histograms.Add(ln);
                }

                //Scatter Chart
                List<ScatterChart> scatterList = GetScatterChartNodes();
                foreach (ScatterChart n in scatterList)
                {
                    OOMMSeriesCollection col = new OOMMSeriesCollection();

                    foreach (string seriesName in n.Series.SeriesNames)
                    {
                        Series s = n.Series[seriesName];
                        OOMMSeriesChartType scType = OOMMSeriesChartType.Scatter;
                        OOMMMarkerType mType = OOMMMarkerType.None;
                        OOMMSeriesAppearance app =
                            new OOMMSeriesAppearance(s.LineWidth, s.BackgroundColor, s.MarkerColor, s.LineColor, mType);
                        OOMMSeries ns = new OOMMSeries(s.Name, s.Value, scType, app);
                        col.Add(ns);
                    }

                    OOMMScatterChart ln = new OOMMScatterChart(n.ChartTitle, n.Descrition, col, n.Left, n.Top, n.Width, n.Height);
                    ln.Appearance = new OOMMChartAppearance(n.BackgroundColor, n.NameColor, n.DescriptionColor, n.BorderColor, n.BorderWeight);

                    diagram.ScatterCharts.Add(ln);
                }

                //Box-Whisker Chart
                List<BoxWhiskerChart> bwChartList = GetBoxWhiskerChartNodes();
                foreach (BoxWhiskerChart n in bwChartList)
                {
                    OOMMSeriesCollection col = new OOMMSeriesCollection();

                    foreach (string seriesName in n.Series.SeriesNames)
                    {
                        Series s = n.Series[seriesName];
                        OOMMSeriesChartType scType = OOMMSeriesChartType.BoxWhisker;
                        OOMMMarkerType mType = OOMMMarkerType.None;
                        OOMMSeriesAppearance app =
                            new OOMMSeriesAppearance(s.LineWidth, s.BackgroundColor, s.MarkerColor, s.LineColor, mType);
                        OOMMSeries ns = new OOMMSeries(s.Name, s.Value, scType, app);
                        col.Add(ns);
                    }

                    OOMMBoxWhiskerChart ln = new OOMMBoxWhiskerChart(n.ChartTitle, n.Descrition, col, n.Left, n.Top, n.Width, n.Height);
                    ln.Appearance = new OOMMChartAppearance(n.BackgroundColor, n.NameColor, n.DescriptionColor, n.BorderColor, n.BorderWeight);

                    diagram.BoxWhiskerCharts.Add(ln);
                }

                //Tile
                List<RectangleTile> recTileList = GetRectangleTileNodes();
                foreach (RectangleTile n in recTileList)
                {
                    OOMMTile ln = new OOMMTile(n.TileName, n.TileValue, n.BackgroundColor, n.NameColor, n.ValueColor, n.BorderColor, n.Left, n.Top, n.Width, n.Height);
                    ln.Shape = TileShape.Rectangle;
                    diagram.Tiles.Add(ln);
                }

                List<CircularTile> cirTileList = GetCircularTileNodes();
                foreach (CircularTile n in cirTileList)
                {
                    OOMMTile ln = new OOMMTile(n.TileName, n.ValueExpression, n.BackgroundColor, n.NameColor, n.ValueColor, n.BorderColor, n.Left, n.Top, n.Width, n.Height);
                    ln.MaxValue = n.MaxValue;

                    ln.Shape = TileShape.Circle;
                    diagram.Tiles.Add(ln);
                }


                //Plots
                List<Plot> plotList = GetPlotNodes();
                foreach (Plot n in plotList)
                {
                    OOMMSeriesCollection col = new OOMMSeriesCollection();

                    foreach (string seriesName in n.Series.SeriesNames)
                    {
                        Series s = n.Series[seriesName];

                        OOMMSeriesChartType scType = OOMMSeriesChartType.Bar;
                        if (s.ChartType == SeriesChartType.Line)
                            scType = OOMMSeriesChartType.Line;
                        else if (s.ChartType == SeriesChartType.Spline)
                            scType = OOMMSeriesChartType.Spline;
                        else if (s.ChartType == SeriesChartType.StepLine)
                            scType = OOMMSeriesChartType.StepLine;

                        OOMMMarkerType mType = OOMMMarkerType.None;
                        if (s.MarkerType == MarkerType.Diamond)
                            mType = OOMMMarkerType.Diamond;
                        else if (s.MarkerType == MarkerType.Oval)
                            mType = OOMMMarkerType.Oval;
                        else if (s.MarkerType == MarkerType.Rectangle)
                            mType = OOMMMarkerType.Rectangle;
                        else if (s.MarkerType == MarkerType.Triangle)
                            mType = OOMMMarkerType.Triangle;
                        OOMMSeriesAppearance app =
                            new OOMMSeriesAppearance(
                                    s.LineWidth, s.BackgroundColor,
                                    s.MarkerColor, s.LineColor, mType);
                        OOMMSeries ns = new OOMMSeries(s.Name, s.Value, scType, app);

                        col.Add(ns);
                    }

                    OOMMPlot ln = new OOMMPlot(n.ChartTitle, n.Descrition, col, n.Left, n.Top, n.Width, n.Height);
                    ln.Appearance = new OOMMChartAppearance(n.BackgroundColor, n.BorderColor, n.BorderWeight);

                    diagram.Plots.Add(ln);
                }

                //Time Plots
                List<TimePlot> timePlotList = GetTimePlotNodes();
                foreach (TimePlot n in timePlotList)
                {
                    OOMMSeriesCollection col = new OOMMSeriesCollection();

                    foreach (string seriesName in n.Series.SeriesNames)
                    {
                        Series s = n.Series[seriesName];

                        OOMMSeriesChartType scType = OOMMSeriesChartType.Bar;
                        if (s.ChartType == SeriesChartType.Line)
                            scType = OOMMSeriesChartType.Line;
                        else if (s.ChartType == SeriesChartType.Spline)
                            scType = OOMMSeriesChartType.Spline;
                        else if (s.ChartType == SeriesChartType.StepLine)
                            scType = OOMMSeriesChartType.StepLine;

                        OOMMMarkerType mType = OOMMMarkerType.None;
                        if (s.MarkerType == MarkerType.Diamond)
                            mType = OOMMMarkerType.Diamond;
                        else if (s.MarkerType == MarkerType.Oval)
                            mType = OOMMMarkerType.Oval;
                        else if (s.MarkerType == MarkerType.Rectangle)
                            mType = OOMMMarkerType.Rectangle;
                        else if (s.MarkerType == MarkerType.Triangle)
                            mType = OOMMMarkerType.Triangle;
                        OOMMSeriesAppearance app =
                            new OOMMSeriesAppearance(
                                    s.LineWidth, s.BackgroundColor,
                                    s.MarkerColor, s.LineColor, mType);
                        OOMMSeries ns = new OOMMSeries(s.Name, s.Value, scType, app);

                        col.Add(ns);
                    }

                    OOMMTimePlot ln = new OOMMTimePlot(n.ChartTitle, n.Descrition, col, n.Left, n.Top, n.Width, n.Height);
                    ln.Appearance = new OOMMChartAppearance(n.BackgroundColor, n.BorderColor, n.BorderWeight);

                    diagram.TimePlots.Add(ln);
                }

                //Edges
                List<Link> linklist = GetLinks();
                foreach (Link n in linklist)
                {
                    if (n.LinkType == LinkType.SchedulingLink)
                    {
                        OOMMObjectInteractionEdge link =
                        new OOMMObjectInteractionEdge();

                        ObjectSchedulingLink osl = (ObjectSchedulingLink)n;

                        link.ID = osl.LinkID;

                        link.MirrorObject = ((ObjectNode)((MultiPortNode)osl.FromNode).UserObject).NodeGuid;
                        link.MirrorTriggerName = osl.FromTriggerName;
                        link.MirrorPort = ((MultiPortNode)n.FromNode).FindPortIndex(n.FromPort);

                        link.BoundaryObject = ((ObjectNode)((MultiPortNode)osl.ToNode).UserObject).NodeGuid;
                        link.BoundaryTriggerName = osl.ToTriggerName;
                        link.BoundaryPort = ((MultiPortNode)n.ToNode).FindPortIndex(n.ToPort);

                        link.Parameters = osl.Parameters;
                        link.StrokeStyle = (int)n.Style;

                        diagram.ObjectInteractionEdges.Add(link);
                    }
                    else if (n.LinkType == LinkType.DataAssociationLink)
                    {
                        OOMMDataAssociationEdge link = new OOMMDataAssociationEdge();

                        DataAssociationLink dal = (DataAssociationLink)n;

                        link.ID = dal.LinkID;

                        link.SourceDataSource = ((DataSourceNode)dal.FromNode).DataSource.ID;
                        link.SourcePort = ((DataSourceNode)dal.FromNode).FindPortIndex(dal.FromPort);

                        link.TargetEventObject = ((ObjectNode)((MultiPortNode)dal.ToNode).UserObject).NodeGuid;
                        link.TargetPort = ((MultiPortNode)n.ToNode).FindPortIndex(n.ToPort);

                        link.StrokeStyle = (int)n.Style;

                        foreach (OOMMDataMapper mapper in dal.DataMappers)
                        {
                            link.AddDataMapper(mapper);
                        }

                        diagram.DataAssociations.Add(link);
                    }
                    else if (n.LinkType == LinkType.StateVariableUpdateLink)
                    {
                        StateVariableUpdateLink dal = (StateVariableUpdateLink)n;
                        OOMMStateVariableUpdateEdge link = new OOMMStateVariableUpdateEdge(
                                                               dal.LinkID,
                                                               dal.FromTriggerName,
                                                               ((ObjectNode)((MultiPortNode)dal.FromNode).UserObject).NodeGuid,
                                                               ((MultiPortNode)dal.FromNode).FindPortIndex(dal.FromPort),
                                                               dal.ToTriggerName,
                                                               ((ObjectNode)((MultiPortNode)dal.ToNode).UserObject).NodeGuid,
                                                               ((MultiPortNode)n.ToNode).FindPortIndex(n.ToPort),
                                                               (int)n.Style);

                        diagram.StateVariableUpdateEdges.Add(link);
                    }
                }
                return diagram;
            }
        }
        #endregion 

        #region Events
        //public event DiagramChangedEvent Changed;//position changes are included, to be removed....
        public event DiagramChangedEventHandler DiagramChanged;
        public event DiagramSelectionChangedEventHandler SelectionChanged;
        public event DiagramObjectSelectedEventHandler ObjectSelected;
        #endregion

        #region Constructors
        public OOMMDiagramWindow()
        {
            InitializeComponent();

            _View = new OOMMDiagramView(this);
            toolStripContainer1.ContentPanel.Controls.Add(_View);
            _View.Dock = DockStyle.Fill;

            _View.ObjectLostSelection += new GoSelectionEventHandler(_View_ObjectLostClicked);
            _View.ObjectSingleClicked += new GoObjectEventHandler(_View_ObjectSingleClicked);
            _View.LinkCreated += new GoSelectionEventHandler(_View_LinkCreated);
            _View.DocumentChanged += new GoChangedEventHandler(_View_DocumentChanged);
            _View.ScaleChanged += new DocumentScaleChangedEventHandler(OnViewScaleChanged);
            _View.DiagramChanged += _View_DiagramChanged;
            //_View.ObjectEdited += _View_ObjectEdited;

            //_View.ObjectGotSelection += new GoSelectionEventHandler(OnViewObjectGotSelection);
            //_View.ObjectLostSelection += new GoSelectionEventHandler(OnViewObjectLostSelection);

            _View.SelectionFinished += new EventHandler(OnViewSelection);

            //tsbSchedulingLink.Checked = true;

            _View.BackColor = Color.FromArgb(238, 246, 249);

        }

        private void _View_DiagramChanged(DiagramChangeType type, Guid modelid, object changedObject, object oldObject)
        {
            if (_IsUpdating)
                return;

            if (DiagramChanged != null && DiagramChanged.GetInvocationList().Length > 0)
                DiagramChanged(type, _Model.ID, changedObject, oldObject);
        }

        private void _View_ObjectEdited(object sender, GoSelectionEventArgs e)
        {
            //if (Changed.GetInvocationList().Length > 0)
            //Changed();
        }
        #endregion

        #region Event Handlers for Toolbars - Drawing Components
        private void tsbEventObjectNode_Click(object sender, EventArgs e)
        {
            tsbEventObjectNode.Checked = !tsbEventObjectNode.Checked;

            if (tsbEventObjectNode.Checked)
            {
                _View.InsertionMode = InsertionMode.EventObject;
                _View.AllowLink = false;

                tsbAddLabel.Checked = false;
                tsbAddText.Checked = false;
                tsbSchedulingLink.Checked = false;
                tsbSVLink.Checked = false;
            }
            else
                _View.InsertionMode = InsertionMode.None;
        }

        private void tsbSchedulingLink_Click(object sender, EventArgs e)
        {
            tsbSchedulingLink.Checked = !tsbSchedulingLink.Checked;

            if (tsbSchedulingLink.Checked)
            {
                _View.InsertionMode = InsertionMode.SchedulingEdge;
                _View.AllowLink = true;

                tsbAddLabel.Checked = false;
                tsbAddText.Checked = false;
                tsbEventObjectNode.Checked = false;
                tsbSVLink.Checked = false;
            }
            else
            {
                _View.InsertionMode = InsertionMode.None;
                _View.AllowLink = false;
            }
        }

        private void tsbSVLink_Click(object sender, EventArgs e)
        {
            tsbSVLink.Checked = !tsbSVLink.Checked;

            if (tsbSVLink.Checked)
            {
                _View.InsertionMode = InsertionMode.StateVariableUpdateEdge;
                _View.AllowLink = true;

                tsbAddLabel.Checked = false;
                tsbAddText.Checked = false;
                tsbEventObjectNode.Checked = false;
                tsbSchedulingLink.Checked = false;
            }
            else
            {
                _View.InsertionMode = InsertionMode.None;
                _View.AllowLink = false;
            }
        }
        #endregion

        #region Event Handlers for Toolbar Menu - Alignments
        private void tsbLeft_Click(object sender, EventArgs e)
        {
            AlignLeftSides();
        }

        private void tsbCenter_Click(object sender, EventArgs e)
        {
            AlignHorizontalCenters();
        }

        private void tsbRight_Click(object sender, EventArgs e)
        {
            AlignRightSides();
        }

        private void tsbTop_Click(object sender, EventArgs e)
        {
            AlignTops();
        }

        private void tsbMiddle_Click(object sender, EventArgs e)
        {
            AlignVerticalCenters();
        }

        private void tsbBottom_Click(object sender, EventArgs e)
        {
            AlignBottoms();
        }
        #endregion

        #region Event Handlers for Toolstrip Menu - Zoom Control
        private void tsbGrid_Click(object sender, EventArgs e)
        {
            tsbGrid.Checked = !tsbGrid.Checked;
            _View.Grid.Visible = tsbGrid.Checked;
        }

        private void tsbZoomIn_Click(object sender, EventArgs e)
        {
            ZoomIn();
        }

        private void tsbZoomOut_Click(object sender, EventArgs e)
        {
            ZoomOut();
        }

        private void tsbZoomFit_Click(object sender, EventArgs e)
        {
            ZoomToFit();
        }

        private void tscbZoom_SelectedIndexChanged(object sender, EventArgs e)
        {
            string zoomScale = tscbZoom.Text;

            Zoom(zoomScale);
        }

        private void OnViewScaleChanged(double scale)
        {
            tscbZoom.Text = Math.Round(scale * 100, 0).ToString() + "%";
        }

        #endregion

        #region Zoom Control Methods
        public void Zoom(string zoomScale)
        {
            float scale = 1.0f;
            if (zoomScale.Contains("%"))
                zoomScale = zoomScale.Substring(0, zoomScale.Length - 1);
            scale = float.Parse(zoomScale) / 100;

            _View.Zoom(scale);
        }

        public void SetZoomScale(float scale)
        {
            tscbZoom.Text = Math.Round(scale * 100, 0).ToString() + "%";
        }

        public void ZoomIn()
        {
            _View.ZoomIn();

            tscbZoom.Text = Math.Round(_View.DocScale * 100, 0).ToString() + "%";
        }

        public void ZoomToFit()
        {
            _View.ZoomToFit();
            tscbZoom.Text = Math.Round(_View.DocScale * 100, 0).ToString() + "%";
        }

        public void ZoomOut()
        {
            _View.ZoomOut();
            tscbZoom.Text = Math.Round(_View.DocScale * 100, 0).ToString() + "%";
        }

        #endregion

        #region Alignment Methods

        public void AlignLeftSides()
        {
            _View.AlignLeftSides();
        }

        public void AlignHorizontalCenters()
        {
            _View.AlignHorizontalCenters();
        }

        public void AlignRightSides()
        {
            _View.AlignRightSides();
        }

        public void AlignTops()
        {
            _View.AlignTops();
        }

        public void AlignVerticalCenters()
        {
            _View.AlignVerticalCenters();
        }

        public void AlignBottoms()
        {
            _View.AlignBottoms();
        }
        #endregion

        #region Event Handlers for Form Events
        private void OOEGDiagramWindow_Load(object sender, EventArgs e)
        {

        }

        private void OOEGDiagramWindow_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                tsbEventObjectNode.Checked = false;
                tsbSchedulingLink.Checked = false;

                _View.AllowLink = false;
                _View.InsertionMode = InsertionMode.None;
            }
            else if (e.KeyCode == Keys.Add && e.Control)
            {
                ZoomIn();
            }
            else if (e.KeyCode == Keys.Subtract && e.Control)
            {
                ZoomOut();
            }
            else if (e.KeyCode == Keys.OemMinus && e.Control)
            {
                ZoomOut();
            }
            else if (e.KeyCode == Keys.Oemplus && e.Control)
            {
                ZoomIn();
            }
        }
        #endregion

        #region Event Handlers for GoView
        private void OnViewSelection(object sender, EventArgs e)
        {
            GoView view = (GoView)sender;
            if (myPrimary != view.Selection.Primary)
            {
                UpdateHighlighting();
            }
        }

        private void _View_DocumentChanged(object sender, GoChangedEventArgs e)
        {
            if (_IsUpdating)
                return;

            if (e.Hint == GoLayer.InsertedObject)
            {
                UpdateHighlighting();

                if (e.GoObject is MultiPortNode)
                {
                    if (DiagramChanged != null && DiagramChanged.GetInvocationList().Length > 0)
                        DiagramChanged(DiagramChangeType.Insert, _Model.ID, e.GoObject, null);
                }
            }
            else if (e.Hint == GoLayer.RemovedObject)
            {
                if (e.GoObject is MultiPortNode)
                {
                    if (DiagramChanged != null && DiagramChanged.GetInvocationList().Length > 0)
                        DiagramChanged(DiagramChangeType.Remove, _Model.ID, e.GoObject, null);
                }
            }
            else if (e.Hint == GoLayer.ChangedObject)
            {
                if (DiagramChanged != null && DiagramChanged.GetInvocationList().Length > 0)
                    DiagramChanged(DiagramChangeType.Move, _Model.ID, e.GoObject, null);

            }

            /*
            if (e.Hint == GoLayer.RemovedObject || 
                e.Hint == GoLayer.InsertedObject 
                )
            {

                //ae.GoObject
                if (Changed.GetInvocationList().Length > 0)
                    Changed();
            }
            */
        }

        private void _View_ObjectLostClicked(object sender, GoSelectionEventArgs e)
        {
            if (this.ObjectSelected != null &&
                       this.ObjectSelected.GetInvocationList().Length > 0)
                this.ObjectSelected(null, null);
        }

        private void _View_ObjectSingleClicked(object sender, GoObjectEventArgs e)
        {
            _Model.ObjectInteractionDiagram = this.ObjectInteractionDiagram;
            string objectType = "";
            if (e.GoObject.ParentNode is MultiPortNode)
            {
                MultiPortNode n = (MultiPortNode)e.GoObject.ParentNode;
                ObjectNode objectNode = null;
                if (n.UserObject is ObjectNode)
                {
                    objectNode = (ObjectNode)n.UserObject;
                    if (objectNode.ObjectType == NodeType.EventObject)
                        objectType = ((EventObjectNode)objectNode).Model.Name;
                    else if (objectNode.ObjectType == NodeType.StateObject)
                        objectType = ((StateObjectNode)objectNode).Model.Name;
                }

                if (!string.IsNullOrEmpty(objectType))
                {
                    if (this.SelectionChanged != null &&
                        this.SelectionChanged.GetInvocationList().Length > 0)
                        if (objectNode.ObjectType == NodeType.EventObject)
                            this.SelectionChanged("eventobject", objectType);
                        else if (objectNode.ObjectType == NodeType.StateObject)
                            this.SelectionChanged("stateobject", objectType);
                }

                if (this.ObjectSelected != null &&
                        this.ObjectSelected.GetInvocationList().Length > 0)
                    this.ObjectSelected(_Model, objectNode);
            }
            else if (e.GoObject.ParentNode is DataSourceNode)
            {
                DataSourceNode n = (DataSourceNode)e.GoObject.ParentNode;
                if (this.ObjectSelected != null &&
                         this.ObjectSelected.GetInvocationList().Length > 0)
                    this.ObjectSelected(_Model, n.DataSource);
            }
            else if (e.GoObject.ParentNode is DataSetNode)
            {
                DataSetNode n = (DataSetNode)e.GoObject.ParentNode;
                if (this.ObjectSelected != null &&
                         this.ObjectSelected.GetInvocationList().Length > 0)
                    this.ObjectSelected(_Model, n);
            }
            else if (e.GoObject.ParentNode is StatisticsNode)
            {
                StatisticsNode n = (StatisticsNode)e.GoObject.ParentNode;
                if (this.ObjectSelected != null &&
                         this.ObjectSelected.GetInvocationList().Length > 0)
                    this.ObjectSelected(_Model, n);
            }
            else if (e.GoObject.ParentNode is HistogramDataNode)
            {
                HistogramDataNode n = (HistogramDataNode)e.GoObject.ParentNode;
                if (this.ObjectSelected != null &&
                         this.ObjectSelected.GetInvocationList().Length > 0)
                    this.ObjectSelected(_Model, n);
            }
            else if (e.GoObject.Parent is GoLabeledLink)
            {
                Link l = (Link)e.GoObject.Parent;
                objectType = l.LinkType.ToString();

                if (!string.IsNullOrEmpty(objectType))
                {
                    if (this.SelectionChanged != null &&
                        this.SelectionChanged.GetInvocationList().Length > 0)
                        this.SelectionChanged("link", objectType);
                }

                if (this.ObjectSelected != null &&
                    this.ObjectSelected.GetInvocationList().Length > 0)
                    this.ObjectSelected(_Model, e.GoObject.Parent);
            }
            else if (e.GoObject.Parent is BarChart)
            {
                BarChart bc = (BarChart)e.GoObject.Parent;
                if (this.ObjectSelected != null &&
                         this.ObjectSelected.GetInvocationList().Length > 0)
                    this.ObjectSelected(_Model, bc);

            }
            else if (e.GoObject.Parent is HorizontalBarChart)
            {
                HorizontalBarChart bc = (HorizontalBarChart)e.GoObject.Parent;
                if (this.ObjectSelected != null &&
                         this.ObjectSelected.GetInvocationList().Length > 0)
                    this.ObjectSelected(_Model, bc);
            }
            else if (e.GoObject.Parent is StackedBarChart)
            {
                StackedBarChart bc = (StackedBarChart)e.GoObject.Parent;
                if (this.ObjectSelected != null &&
                         this.ObjectSelected.GetInvocationList().Length > 0)
                    this.ObjectSelected(_Model, bc);
            }
            else if (e.GoObject.Parent is StackedHorizontalBarChart)
            {
                StackedHorizontalBarChart bc = (StackedHorizontalBarChart)e.GoObject.Parent;
                if (this.ObjectSelected != null &&
                         this.ObjectSelected.GetInvocationList().Length > 0)
                    this.ObjectSelected(_Model, bc);
            }
            else if (e.GoObject.Parent is PieChart)
            {
                PieChart pc = (PieChart)e.GoObject.Parent;
                if (this.ObjectSelected != null &&
                         this.ObjectSelected.GetInvocationList().Length > 0)
                    this.ObjectSelected(_Model, pc);
            }
            else if (e.GoObject.Parent is DonutChart)
            {
                DonutChart pc = (DonutChart)e.GoObject.Parent;
                if (this.ObjectSelected != null &&
                         this.ObjectSelected.GetInvocationList().Length > 0)
                    this.ObjectSelected(_Model, pc);
            }
            else if (e.GoObject.Parent is ScatterChart)
            {
                ScatterChart pc = (ScatterChart)e.GoObject.Parent;
                if (this.ObjectSelected != null &&
                         this.ObjectSelected.GetInvocationList().Length > 0)
                    this.ObjectSelected(_Model, pc);
            }
            else if (e.GoObject.Parent is BoxWhiskerChart)
            {
                BoxWhiskerChart pc = (BoxWhiskerChart)e.GoObject.Parent;
                if (this.ObjectSelected != null &&
                         this.ObjectSelected.GetInvocationList().Length > 0)
                    this.ObjectSelected(_Model, pc);
            }
            else if (e.GoObject.Parent is Histogram)
            {
                Histogram pc = (Histogram)e.GoObject.Parent;
                if (this.ObjectSelected != null &&
                         this.ObjectSelected.GetInvocationList().Length > 0)
                    this.ObjectSelected(_Model, pc);
            }
            else if (e.GoObject.Parent is Tile)
            {
                Tile pc = (Tile)e.GoObject.Parent;
                if (this.ObjectSelected != null &&
                         this.ObjectSelected.GetInvocationList().Length > 0)
                    this.ObjectSelected(_Model, pc);
            }
            else if (e.GoObject.Parent is Plot)
            {
                Plot target = (Plot)e.GoObject.Parent;
                if (this.ObjectSelected != null &&
                         this.ObjectSelected.GetInvocationList().Length > 0)
                    this.ObjectSelected(_Model, target);
            }
            else if (e.GoObject.Parent is TimePlot)
            {
                TimePlot target = (TimePlot)e.GoObject.Parent;
                if (this.ObjectSelected != null &&
                         this.ObjectSelected.GetInvocationList().Length > 0)
                    this.ObjectSelected(_Model, target);
            }
            else
            {
                if (this.ObjectSelected != null &&
                    this.ObjectSelected.GetInvocationList().Length > 0)
                    this.ObjectSelected(_Model, e.GoObject);
            }
        }

        private void _View_LinkCreated(object sender, GoSelectionEventArgs e)
        {
            if (e.GoObject is Link)
            {
                Link l = (Link)e.GoObject;

                if (l.LinkType == LinkType.SchedulingLink)
                {
                    while (_View.Doc.FindLink(OOMMDiagramView.LastID) != null)
                    {
                        OOMMDiagramView.LastID++;
                    }
                    l.LinkID = OOMMDiagramView.LinkCount;
                    OOMMDiagramView.LastID++;
                    OOMMDiagramView.LinkCount++;
                }
            }
            else
            {

            }
        }
        #endregion

        #region Methods for Highlights
        private List<GoObject> mySelection = null;
        private GoObject myPrimary = null;
        private void UpdateHighlighting()
        {
            if (myPrimary != null)
            {
                //disableHighlight(myPrimary);
                foreach (GoObject obj in mySelection)
                    disableHighlight(obj);
                //highlight(myPrimary, Color.Black, 1);
            }

            myPrimary = _View.Selection.Primary;
            mySelection = _View.Selection.ToList<GoObject>();
            foreach (GoObject obj in mySelection)
                enableHighlight(obj);
        }

        private void enableHighlight(GoObject obj)
        {
            highlight(obj, Color.Red, 2);
        }


        private void disableHighlight(GoObject obj)
        {
            /*
            if (obj is Node)
            {
                Node n = (Node)obj;

                n.BorderPen = new Pen(Color.Black, 1);
                //n.Pen = new Pen(Color.Black, 1);
            }
            else
                highlight(obj, Color.Black, 1);
             * */
        }

        private void highlight(GoObject obj, Color c, float w)
        {
            /*            
            if (obj is GoNode)
            {
                GoNode n = (GoNode)obj;
                n.BorderPen = new Pen(c, w);
                //n.Pen = new Pen(c, w);

            }
            else if (obj is ObjectSchedulingLink)
            {
                ObjectSchedulingLink l = (ObjectSchedulingLink)obj;
                l.Highlight = true;
                l.HighlightPen = new Pen(c, w);
            }
             * */
        }
        #endregion

        #region Methods
        public List<Node> GetObjectNodes()
        {
            List<Node> rslt = new List<Node>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is MultiPortNode)
                {
                    MultiPortNode n = (MultiPortNode)obj;
                    if (n.UserObject != null)
                        rslt.Add((Node)n.UserObject);
                }
            }

            return rslt;
        }

        public List<Node> GetEventObjectNodes()
        {
            List<Node> rslt = new List<Node>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is MultiPortNode)
                {
                    MultiPortNode n = (MultiPortNode)obj;
                    if (n.UserObject is EventObjectNode)
                        rslt.Add((EventObjectNode)n.UserObject);
                }
            }
            return rslt;
        }

        public List<Node> GetStateObjectNodes()
        {
            List<Node> rslt = new List<Node>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is MultiPortNode)
                {
                    MultiPortNode n = (MultiPortNode)obj;
                    if (n.UserObject is StateObjectNode)
                        rslt.Add((StateObjectNode)n.UserObject);
                }
            }
            return rslt;
        }

        public List<Node> GetActivityObjectNodes()
        {
            List<Node> rslt = new List<Node>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is MultiPortNode)
                {
                    MultiPortNode n = (MultiPortNode)obj;
                    if (n.UserObject is ActivityObjectNode)
                        rslt.Add((ActivityObjectNode)n.UserObject);
                }
            }
            return rslt;
        }

        public List<DataSourceNode> GetDataSourceNodes()
        {
            List<DataSourceNode> rslt = new List<DataSourceNode>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is DataSourceNode)
                {
                    DataSourceNode n = (DataSourceNode)obj;
                    rslt.Add(n);
                    //rslt.Add((DataSourceNode)n.UserObject);
                }
            }

            return rslt;
        }

        public List<DataSetNode> GetDataSetNodes()
        {
            List<DataSetNode> rslt = new List<DataSetNode>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is DataSetNode)
                {
                    DataSetNode n = (DataSetNode)obj;
                    rslt.Add(n);
                }
            }

            return rslt;
        }

        public List<HistogramDataNode> GetHistogramDataNodes()
        {
            List<HistogramDataNode> rslt = new List<HistogramDataNode>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is HistogramDataNode)
                {
                    HistogramDataNode n = (HistogramDataNode)obj;
                    rslt.Add(n);
                }
            }

            return rslt;
        }

        public List<StatisticsNode> GetStatisticsNodes()
        {
            List<StatisticsNode> rslt = new List<StatisticsNode>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is StatisticsNode)
                {
                    StatisticsNode n = (StatisticsNode)obj;
                    rslt.Add(n);
                }
            }

            return rslt;
        }

        public List<BarChart> GetBarChartNodes()
        {
            List<BarChart> rslt = new List<BarChart>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is BarChart)
                {
                    BarChart n = (BarChart)obj;
                    rslt.Add(n);
                }
            }

            return rslt;
        }

        public List<HorizontalBarChart> GetHorizontalBarChartNodes()
        {
            List<HorizontalBarChart> rslt = new List<HorizontalBarChart>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is HorizontalBarChart)
                {
                    HorizontalBarChart n = (HorizontalBarChart)obj;
                    rslt.Add(n);
                }
            }

            return rslt;
        }

        public List<StackedBarChart> GetStackedBarChartNodes()
        {
            List<StackedBarChart> rslt = new List<StackedBarChart>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is StackedBarChart)
                {
                    StackedBarChart n = (StackedBarChart)obj;
                    rslt.Add(n);
                }
            }

            return rslt;
        }

        public List<StackedHorizontalBarChart> GetStackedHorizontalBarChartNodes()
        {
            List<StackedHorizontalBarChart> rslt = new List<StackedHorizontalBarChart>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is StackedHorizontalBarChart)
                {
                    StackedHorizontalBarChart n = (StackedHorizontalBarChart)obj;
                    rslt.Add(n);
                }
            }

            return rslt;
        }


        public List<PieChart> GetPieChartNodes()
        {
            List<PieChart> rslt = new List<PieChart>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is PieChart)
                {
                    PieChart n = (PieChart)obj;
                    rslt.Add(n);
                }
            }
            return rslt;
        }

        public List<DonutChart> GetDonutChartNodes()
        {
            List<DonutChart> rslt = new List<DonutChart>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is DonutChart)
                {
                    DonutChart n = (DonutChart)obj;
                    rslt.Add(n);
                }
            }
            return rslt;
        }

        public List<Histogram> GetHistogramNodes()
        {
            List<Histogram> rslt = new List<Histogram>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is Histogram)
                {
                    Histogram n = (Histogram)obj;
                    rslt.Add(n);
                }
            }
            return rslt;
        }

        public List<ScatterChart> GetScatterChartNodes()
        {
            List<ScatterChart> rslt = new List<ScatterChart>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is ScatterChart)
                {
                    ScatterChart n = (ScatterChart)obj;
                    rslt.Add(n);
                }
            }
            return rslt;
        }

        public List<BoxWhiskerChart> GetBoxWhiskerChartNodes()
        {
            List<BoxWhiskerChart> rslt = new List<BoxWhiskerChart>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is BoxWhiskerChart)
                {
                    BoxWhiskerChart n = (BoxWhiskerChart)obj;
                    rslt.Add(n);
                }
            }
            return rslt;
        }

        public List<Tile> GetTileNodes()
        {
            List<Tile> rslt = new List<Tile>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is Tile)
                {
                    Tile n = (Tile)obj;
                    rslt.Add(n);
                }
            }
            return rslt;
        }

        public List<RectangleTile> GetRectangleTileNodes()
        {
            List<RectangleTile> rslt = new List<RectangleTile>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is RectangleTile)
                {
                    RectangleTile n = (RectangleTile)obj;
                    rslt.Add(n);
                }
            }
            return rslt;
        }

        public List<CircularTile> GetCircularTileNodes()
        {
            List<CircularTile> rslt = new List<CircularTile>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is CircularTile)
                {
                    CircularTile n = (CircularTile)obj;
                    rslt.Add(n);
                }
            }
            return rslt;
        }

        public List<Plot> GetPlotNodes()
        {
            List<Plot> rslt = new List<Plot>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is Plot)
                {
                    Plot n = (Plot)obj;
                    rslt.Add(n);
                }
            }
            return rslt;
        }

        public List<TimePlot> GetTimePlotNodes()
        {
            List<TimePlot> rslt = new List<TimePlot>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is TimePlot)
                {
                    TimePlot n = (TimePlot)obj;
                    rslt.Add(n);
                }
            }
            return rslt;
        }

        public List<TextNode> GetTextNodes()
        {
            List<TextNode> rslt = new List<TextNode>();
            foreach (GoObject obj in _View.Doc)
            {
                if (obj is TextNode)
                {
                    TextNode n = (TextNode)obj;
                    rslt.Add(n);
                }
            }
            return rslt;
        }

        public List<LabelNode> GetLabelNodes()
        {
            List<LabelNode> rslt = new List<LabelNode>();
            foreach (GoObject obj in _View.Doc)
            {
                if (obj is LabelNode)
                {
                    LabelNode n = (LabelNode)obj;
                    rslt.Add(n);
                }
            }
            return rslt;
        }

        public List<Node> GetNodes(NodeType type)
        {
            List<Node> rslt = new List<Node>();

            foreach (GoObject obj in this._View.Doc)
            {
                if (obj.ParentNode is MultiPortNode)
                {
                    MultiPortNode n = (MultiPortNode)obj.ParentNode;

                    ObjectNode objectNode = null;
                    if (type == NodeType.EventObject)
                    {
                        if (n.UserObject is EventObjectNode)
                            objectNode = (EventObjectNode)n.UserObject;
                    }
                    else if (type == NodeType.ActivityObject)
                    {
                        if (n.UserObject is ActivityObjectNode)
                            objectNode = (ActivityObjectNode)n.UserObject;
                    }
                    else if (type == NodeType.StateObject)
                    {
                        if (n.UserObject is StateObjectNode)
                            objectNode = (StateObjectNode)n.UserObject;
                    }
                    rslt.Add(objectNode);
                }
            }
            return rslt;
        }

        public List<Link> GetLinks()
        {
            List<Link> rslt = new List<Link>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is Link)
                {
                    Link n = (Link)obj;
                    rslt.Add(n);
                }
            }

            return rslt;
        }

        public List<Link> GetLinks(LinkType type)
        {
            List<Link> rslt = new List<Link>();
            foreach (GoObject obj in this._View.Doc)
            {
                if (obj is Link)
                {
                    Link n = (Link)obj;
                    if (n.LinkType == type)
                        rslt.Add(n);
                }
            }

            return rslt;
        }

        public bool IsGridShown { get { return tsbGrid.Checked; } }

        public void FlipGrid()
        {
            tsbGrid.Checked = !tsbGrid.Checked;
            _View.Grid.Visible = tsbGrid.Checked;
        }

        private void OnPropertyChanged(object target, string propertyName, object oldValue, object newValue)
        {
            if (DiagramChanged != null && DiagramChanged.GetInvocationList().Length > 0)
            {
                //System.Diagnostics.Debug.WriteLine("[PropertyChanged] target: " + target + ", propertyName: " + propertyName + ", value:" + newValue);
                DiagramChanged(DiagramChangeType.Edit, _Model.ID, target, oldValue);
            }
        }

        private bool _IsUpdating = false;
        public void Open(OOMMModel model)
        {
            _IsUpdating = true;
            _Model = model;
            _ModelName = model.Name;
            _View.Doc.Clear();
            //Nodes
            Dictionary<Guid, Node> nodelist = new Dictionary<Guid, Node>();

            Dictionary<Guid, DataSourceNode> dsNodeList = new Dictionary<Guid, DataSourceNode>();
            OOMMObjectInteractionDiagram diagram = model.ObjectInteractionDiagram;
            foreach (OOMMObjectNode objectNode in diagram.ObjectNodes)
            {
                ObjectNode node = null;
                if (objectNode.Type == ObjectNodeType.EventObject)
                {
                    OOEGEventObjectModel eoModel = model.FindEventObjectModel(objectNode.ModelID);
                    if (eoModel == null)
                        continue;
                    node = _View.Doc.InsertEventObjectNode(objectNode, eoModel);
                }
                else if (objectNode.Type == ObjectNodeType.StateObject)
                {
                    OOSGStateObjectModel soModel = model.FindStateObjectModel(objectNode.ModelID);
                    if (soModel == null)
                        continue;
                    node = _View.Doc.InsertStateObjectNode(objectNode, soModel);
                }
                else if (objectNode.Type == ObjectNodeType.ActivityObject)
                {
                    OOAGActivityObjectModel aoModel = model.FindActivityObjectModel(objectNode.ModelID);
                    if (aoModel == null)
                        continue;
                    node = _View.Doc.InsertActivityObjectNode(objectNode, aoModel);
                }
                nodelist.Add(objectNode.NodeID, node);
                foreach (OOMMObjectStateVariable sv in objectNode.StateVariables)
                {
                    if (sv.Value != null)
                    {
                        node[sv.Name] = sv.Value;
                    }
                }
                node.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
            }

            foreach (OOMMTextNode node in diagram.Texts)
            {
                TextNode textNode = _View.Doc.InsertTextNode(node);
                textNode.BackgroundColor = _View.BackColor;
                if (textNode != null)
                    textNode.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
            }

            foreach (OOMMDataSourceNode node in diagram.DataSourceNodes)
            {
                DataSourceNode dsNode = _View.Doc.InsertDataSourceNode(model, node);
                if (dsNode != null)
                {
                    dsNodeList.Add(node.ID, dsNode);
                    dsNode.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
                }
            }

            foreach (OOMMDataSetNode node in diagram.DataSetNodes)
            {
                DataSetNode dsNode = _View.Doc.InsertDataSetNode(node);
                if (dsNode != null)
                {
                    dsNode.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
                }
            }

            foreach (OOMMHistogramDataNode node in diagram.HistogramDataNodes)
            {
                HistogramDataNode dsNode = _View.Doc.InsertHistogramDataNode(node);
                if (dsNode != null)
                {
                    dsNode.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
                }
            }

            foreach (OOMMStatisticsNode node in diagram.StatisticsNodes)
            {
                StatisticsNode statNode = _View.Doc.InsertStatisticsNode(node);
                if (statNode != null)
                {
                    statNode.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
                }
            }

            foreach (OOMMLabelNode node in diagram.Labels)
            {
                LabelNode lblNode = _View.Doc.InsertLabelNode(model, node);
                lblNode.BackgroundColor = _View.BackColor;
                if (lblNode != null)
                {
                    lblNode.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
                }
            }

            foreach (OOMMTile node in diagram.Tiles)
            {
                Tile tile = _View.Doc.InsertTile(model, node);
                if (tile != null)
                    tile.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
            }

            foreach (OOMMBarChart node in diagram.BarCharts)
            {
                AbstractChart chart = null;
                if (node.IsStacked)
                {
                    if (node.Direction == OOMMChartDirection.Vertical)
                        chart = _View.Doc.InsertStackedBarChart(model, node);
                    else
                        chart = _View.Doc.InsertStackedHorizontalBarChart(model, node);
                }else
                {
                    if (node.Direction == OOMMChartDirection.Vertical)
                        chart = _View.Doc.InsertBarChart(model, node);
                    else
                        chart = _View.Doc.InsertHorizontalBarChart(model, node);
                }
                chart.UpdateSeries();

                if (chart != null)
                    chart.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
            }

            foreach (OOMMPieChart node in diagram.PieCharts)
            {
                PieChart chart = _View.Doc.InsertPieChart(model, node);
                chart.UpdateSeries();

                if (chart != null)
                    chart.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
            }

            foreach (OOMMDonutChart node in diagram.DonutCharts)
            {
                DonutChart chart = _View.Doc.InsertDonutChart(model, node);
                chart.UpdateSeries();

                if (chart != null)
                    chart.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
            }

            foreach (OOMMPlot node in diagram.Plots)
            {
                Plot plot = _View.Doc.InsertPlot(model, node);
                if (plot != null)
                    plot.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
            }

            foreach (OOMMTimePlot node in diagram.TimePlots)
            {
                TimePlot plot = _View.Doc.InsertTimePlot(model, node);

                plot.Height = node.Dimension.Height;
                plot.Width = node.Dimension.Width;
                plot.UpdateSeries();

                if (plot != null)
                    plot.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
            }

            foreach (OOMMHistogram node in diagram.Histograms)
            {
                Histogram chart = _View.Doc.InsertHistogram(model, node);

                chart.Height = node.Dimension.Height;
                chart.Width = node.Dimension.Width;
                chart.UpdateSeries();

                if (chart != null)
                    chart.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
            }

            foreach (OOMMBoxWhiskerChart node in diagram.BoxWhiskerCharts)
            {
                BoxWhiskerChart chart = _View.Doc.InsertBoxWhiskerChart(model, node);
                chart.Height = node.Dimension.Height;
                chart.Width = node.Dimension.Width;
                chart.UpdateSeries();

                if (chart != null)
                    chart.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
            }

            foreach (OOMMScatterChart node in diagram.ScatterCharts)
            {
                ScatterChart chart = _View.Doc.InsertScatterChart(model, node);
                chart.Height = node.Dimension.Height;
                chart.Width = node.Dimension.Width;
                chart.UpdateSeries();

                if (chart != null)
                    chart.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
            }

            //Links
            int maxLinkID = int.MinValue;

            foreach (OOMMObjectInteractionEdge l in diagram.ObjectInteractionEdges)
            {
                IGoPort srcPort = null;
                IGoPort destPort = null;

                if (nodelist.ContainsKey(l.MirrorObject))
                    srcPort = nodelist[l.MirrorObject].FindPort(l.MirrorPort);

                if (nodelist.ContainsKey(l.BoundaryObject))
                    destPort = nodelist[l.BoundaryObject].FindPort(l.BoundaryPort);

                if (srcPort == null || destPort == null)
                    continue;

                if (l.Type == LinkType.SchedulingLink)
                {
                    ObjectSchedulingLink link = new ObjectSchedulingLink(0);

                    //ObjectSchedulingLink link = (ObjectSchedulingLink)
                    //    OOEGDiagramView.MakeLink(InsertionMode.SchedulingEdge);
                    link.LinkID = l.ID;
                    link.FromObjectID = l.MirrorObject;
                    link.FromTriggerName = l.MirrorTriggerName;
                    link.ToObjectID = l.BoundaryObject;
                    link.ToTriggerName = l.BoundaryTriggerName;
                    link.Parameters = l.Parameters;

                    link.FromPort = srcPort;
                    link.ToPort = destPort;

                    /*
                    GoText fromLabel = new GoText();
                    fromLabel.FontSize = 8;
                    fromLabel.Editable = false;
                    fromLabel.EditableWhenSelected = false;
                    fromLabel.Selectable = false;
                    fromLabel.Deletable = false;
                    fromLabel.Text = l.MirrorTriggerName;
                    link.FromLabel = fromLabel;

                    GoText toLabel = new GoText();
                    toLabel.FontSize = 8;
                    toLabel.Editable = false;
                    toLabel.EditableWhenSelected = false;
                    toLabel.Text = l.BoundaryTriggerName;
                    toLabel.Selectable = false;
                    toLabel.Deletable = false;
                    link.ToLabel = toLabel;
                    */

                    link.Style = (GoStrokeStyle)Enum.GetValues(typeof(GoStrokeStyle)).GetValue(l.StrokeStyle);
                    if (link.Style == GoStrokeStyle.RoundedLine)
                        link.Orthogonal = true;

                    _View.Doc.LinksLayer.Add(link);
                    link.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
                }

                if (l.ID > maxLinkID)
                    maxLinkID = l.ID;
            }

            foreach (OOMMDataAssociationEdge l in diagram.DataAssociations)
            {
                IGoPort srcPort = null;
                IGoPort destPort = null;

                if (dsNodeList.ContainsKey(l.SourceDataSource))
                    srcPort = dsNodeList[l.SourceDataSource].FindPort(l.SourcePort);

                if (nodelist.ContainsKey(l.TargetEventObject))
                    destPort = nodelist[l.TargetEventObject].FindPort(l.TargetPort);

                if (srcPort == null || destPort == null)
                    continue;

                if (l.Type == DataAssociationType.Input)
                {
                    DataAssociationLink link = new DataAssociationLink(maxLinkID++, l);

                    link.FromPort = srcPort;
                    link.ToPort = destPort;
                    link.Style = (GoStrokeStyle)Enum.GetValues(typeof(GoStrokeStyle)).GetValue(l.StrokeStyle);
                    if (link.Style == GoStrokeStyle.RoundedLine)
                        link.Orthogonal = true;

                    _View.Doc.LinksLayer.Add(link);

                    link.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
                }

                if (l.ID > maxLinkID)
                    maxLinkID = l.ID;
            }

            foreach (OOMMStateVariableUpdateEdge l in diagram.StateVariableUpdateEdges)
            {
                IGoPort srcPort = null;
                IGoPort destPort = null;

                if (nodelist.ContainsKey(l.SourceEventObject))
                    srcPort = nodelist[l.SourceEventObject].FindPort(l.SourceEventPort);

                if (nodelist.ContainsKey(l.DestinationEventObject))
                    destPort = nodelist[l.DestinationEventObject].FindPort(l.DestinationEventPort);

                if (srcPort == null || destPort == null)
                    continue;

                StateVariableUpdateLink link = (StateVariableUpdateLink)
                    OOMMDiagramView.MakeLink(InsertionMode.StateVariableUpdateEdge);
                link.LinkID = l.ID;
                link.FromObjectID = l.SourceEventObject;
                link.FromTriggerName = l.SourceStateVariable;
                link.ToObjectID = l.DestinationEventObject;
                link.ToTriggerName = l.DestinationStateVariable;

                link.FromPort = srcPort;
                link.ToPort = destPort;

                link.Style = (GoStrokeStyle)Enum.GetValues(typeof(GoStrokeStyle)).GetValue(l.StrokeStyle);
                if (link.Style == GoStrokeStyle.RoundedLine)
                    link.Orthogonal = true;

                _View.Doc.LinksLayer.Add(link);
                link.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);

                if (l.ID > maxLinkID)
                    maxLinkID = l.ID;
            }

            maxLinkID++;
            OOMMDiagramView.LinkCount = maxLinkID;

            //Properties
            object objViewScale = model.FindProperty(OOMMObjectInteractionDiagram.ZOOM_SCALE);
            if (objViewScale != null)
            {
                float viewScale = (float)model.FindProperty(OOMMObjectInteractionDiagram.ZOOM_SCALE);
                _View.Zoom(viewScale);
                SetZoomScale(viewScale);
            }

            object objShowGrid = model.FindProperty(OOMMObjectInteractionDiagram.GRID_VISIBILITY);
            if (objShowGrid != null)
            {
                bool showGrid = (bool)model.FindProperty(OOMMObjectInteractionDiagram.GRID_VISIBILITY);
                _View.Grid.Visible = showGrid;
                tsbGrid.Checked = showGrid;
            }

            _View.AllowLink = false;
            //_View.ZoomToFit();

            updateTitle();
            _IsUpdating = false;
        }


        private void updateTitle()
        {
            this.Text = _ModelName;
        }

        public void GoTo(string name)
        {
            MultiPortNode node = _View.FindNode(name);
            _View.Selection.Clear();
            _View.Selection.Add(node);
            _View.Selection.Focused = true;

            _View.RescaleWithCenter(_View.DocScale, node.Position);
        }

        public void GoTo(string type, int id)
        {
            /*
            if (type.Contains("Node"))
            {
                Node node = _View.FindNode(id);
                _View.RescaleWithCenter(_View.DocScale, node.Center);
                _View.Selection.Clear();
                _View.Selection.Add(node);
                //
            }
            else if (type.Equals("Link"))
            {
                Link link = _View.Doc.FindLink(id);
                _View.RescaleWithCenter(_View.DocScale, link.Center);
                _View.Selection.Clear();
                _View.Selection.Add(link);
                UpdateHighlighting();
            }
             */
        }

        public void ChangeProperty(
            string type, int id, string propertyName, string newValue)
        {
            if (type.Equals("Node"))
            {
                Node node = _View.FindNode(id);

                if (propertyName.Equals("Node Name"))
                {
                    node.NodeName = newValue;
                    return;
                }

                /*
                if (node.NodeType == NodeType.Source)
                {
                    //columns = new string[] { "Node ID", "Node Name", "Inter-arriving Time" };
                    SourceNode sNode = (SourceNode)node;

                    if (propertyName.Equals("Inter-arriving Time"))
                    {
                        try
                        {
                            sNode.InterArrivingTime = float.Parse(newValue);
                        }
                        catch { }
                    }
                }
                */

            }
            else if (type.Equals("SchedulingLink"))
            {
                ObjectSchedulingLink link = _View.FindLink(id);

                //string[] columns = new string[] { "Link ID", "Link Name", "Link Length", "Speed Factor", "Speed Limit" };
                if (propertyName.Equals("Mirror Event Name"))
                {
                    link.FromTriggerName = newValue;
                }
                else if (propertyName.Equals("Boundary Event Name"))
                {
                    link.ToTriggerName = newValue;
                }
            }
        }

        #endregion

        private void tsbAddLabel_Click(object sender, EventArgs e)
        {
            tsbAddLabel.Checked = !tsbAddLabel.Checked;

            if (tsbAddLabel.Checked)
            {
                _View.InsertionMode = InsertionMode.Label;

                _View.AllowLink = false;

                tsbEventObjectNode.Checked = false;
                tsbAddText.Checked = false;
                tsbSchedulingLink.Checked = false;
            }
            else
                _View.InsertionMode = InsertionMode.None;
        }

        private void tsbAddText_Click(object sender, EventArgs e)
        {
            tsbAddText.Checked = !tsbAddText.Checked;

            if (tsbAddText.Checked)
            {
                _View.InsertionMode = InsertionMode.Text;

                _View.AllowLink = false;

                tsbEventObjectNode.Checked = false;
                tsbAddLabel.Checked = false;
                tsbSchedulingLink.Checked = false;
            }
            else
                _View.InsertionMode = InsertionMode.None;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            DialogResult rslt = colorDialog1.ShowDialog();

            if (rslt == DialogResult.OK)
            {
                Color c = colorDialog1.Color;

                foreach (GoNode node in _View.Selection)
                {
                    if (node is MultiPortNode)
                    {
                        MultiPortNode eoNode = (MultiPortNode)node;
                        eoNode.BackgroundColor = c;
                    }
                }

            }
        }

        private void OOEGDiagramWindow_FormClosing(object sender, FormClosingEventArgs e)
        {

        }


    }
}
