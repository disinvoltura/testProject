﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Northwoods.Go;
using System.Windows.Forms;
using DHKANG.SEA.UI.OutputView;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;

namespace DHKANG.SEA.UI
{
    public class LabelNode : GoText
    {
        #region Member Variables
        private Guid _NodeId;
        private string _LabelName;

        private Guid _EventObjectID;
        private string _EventObjectName;
        private string _StateVariableName;
        private string _InitialValue;
        private string _Tooltip;

        #endregion

        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Properties
        public Guid NodeID {  get { return _NodeId; } set { _NodeId = value; } }

        public string LabelName 
        {
            get { return _LabelName; }
            set {
                string oldValue = _LabelName;
                _LabelName = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "LabelName", oldValue, value);
            }
        }
 
        public string ObjectName
        {
            get { return _EventObjectName; }
            set {
                string oldValue = _EventObjectName;
                _EventObjectName = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "EventObjectName", oldValue, value);
            }
        }
        
        public Guid ObjectID
        {
            get { return _EventObjectID; }
            set
            {
                Guid oldValue = _EventObjectID;
                _EventObjectID = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "EventObjectID", oldValue, value);
            }
        }

        public string StateVariableName
        {
            get { return _StateVariableName; }
            set
            {
                string oldValue = _StateVariableName;
                _StateVariableName = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "StateVariableName", oldValue, value);
            }
        }

        public string InitialValue
        {
            get { return _InitialValue; }
            set {
                string oldValue = _InitialValue;
                _InitialValue = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "InitialValue", oldValue, value);
            }
        }

        public string Tooltip
        {
            get { return _Tooltip; }
            set { _Tooltip = value; }
        }
        #endregion

        #region Constructors
        public LabelNode(string name, float x, float y)
        {
            _NodeId = Guid.NewGuid();
            _LabelName = name;

             this.Left = x;
            this.Top = y;
            this.Font = new Font(
                FontFamily.GenericSansSerif, 
                12, FontStyle.Italic);
            this.FontSize = 6;

            this.UpdateText();

        }

        public LabelNode(Guid nodeId, string name, Guid eventObjectID, string eventObjectName, string svName, string initialValue, float x, float y)
        {
            _NodeId = nodeId;
            _LabelName = name;

            _EventObjectID = eventObjectID;
            _EventObjectName = eventObjectName;
            _StateVariableName = svName;
            _InitialValue = initialValue;

            this.Left = x;
            this.Top = y;
            this.Font = new Font(
                FontFamily.GenericSansSerif, 
                12, FontStyle.Italic);
            this.FontSize = 6;

            this.UpdateText();
        }
        #endregion

        #region Methods
        public void UpdateText()
        {
            this.Text = _LabelName;
            //this.Text = _EventObjectName + "." + _StateVariableName;
        }

        public void Reset()
        {
            this.Text = _InitialValue;
        }

        public override string GetToolTip(GoView view)
        {
            if (string.IsNullOrEmpty(_Tooltip))
                return _EventObjectName + "." + _StateVariableName;
            else
                return _EventObjectName + "." + _StateVariableName + ":\r\n" + _Tooltip;
        }

        public bool ShowDialog()
        {
            bool rslt = false;

            Guid projectID = MainUI.App.ModelExplorer.CurrentProject;
            OOMMModel model = MainUI.App.ModelExplorer.GetProject(projectID);
            //OOEGEventGraphModel model = MainForm.App.getCurrentEditor().BuildModel();
            LabelNodeDialog dialog = new LabelNodeDialog(model, this);
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                OOEGEventObjectModel eoModel = model.FindEventObjectModel(dialog.EventObjectName);
                OOEGStateVariable sv = eoModel.GetStateVariable(dialog.StateVariableName);

                this.ObjectID = eoModel.ID;
                this.ObjectName = eoModel.Name;
                this.StateVariableName = sv.Name;
                this.InitialValue = sv.InitialValue;
                rslt = true;
            }
            return rslt;
        }

        public bool ShowFontDialog()
        {
            bool rslt = false;

            FontDialog dialog = new FontDialog();
            dialog.Font = this.Font;
            dialog.ShowColor = true;
            dialog.ShowEffects = true;
            dialog.Color = this.TextColor;

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                this.Font = dialog.Font;
                this.TextColor = dialog.Color;
                rslt = true;
            }

            return rslt;
        }
        #endregion
    }
}
