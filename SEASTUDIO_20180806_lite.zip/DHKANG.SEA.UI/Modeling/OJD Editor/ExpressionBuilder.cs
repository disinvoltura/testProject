﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model.OID;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.ActivityObjects;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI
{
    public partial class ExpressionBuilder : Form
    {
        #region Member Variables
        private OOMMModel _Model;
        #endregion

        #region Properties
        public string EventObjectName { get { return lbEventObjects.Text; } }

        public string StateVariableName { get { return lbStateVariables.Text; } }

        public string Expression { get { return txtExpr.Text; } }
        #endregion

        #region Constructors
        public ExpressionBuilder(OOMMModel model)
        {
            _Model = model;
            InitializeComponent();

            initializeEventObjects();
        }

        public ExpressionBuilder(OOMMModel model, string expr)
        {
            _Model = model;

            InitializeComponent();

            initializeEventObjects(expr);

            txtExpr.Text = expr;
        }
        #endregion

        #region Methods
        private void btnOK_Click(object sender, EventArgs e)
        {
            /*
            if (string.IsNullOrEmpty(lbEventObjects.Text) ||
               string.IsNullOrEmpty(lbStateVariables.Text))
            {
                return;
            }
            */
            if (string.IsNullOrEmpty(txtExpr.Text))
                return;

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void LabelNodeDialog_Load(object sender, EventArgs e)
        {

        }

        private void initializeEventObjects()
        {
            foreach(OOMMObjectNode eoNode in _Model.ObjectInteractionDiagram.ObjectNodes)
            {
                lbEventObjects.Items.Add(eoNode.Name);
            }
        }

        private bool isUpdating = false;
        private void initializeEventObjects(string expr)
        {
            isUpdating = true;
            string[] stra = expr.Split(new string[] { "." }, StringSplitOptions.RemoveEmptyEntries);
            if (stra.Length == 0)
                return;
            lbEventObjects.SelectedItem = stra[0];

            OOEGEventObjectModel targetModel = null; 
            foreach (OOMMObjectNode eoNode in _Model.ObjectInteractionDiagram.ObjectNodes)
            {
                lbEventObjects.Items.Add(eoNode.Name);
                if (eoNode.Name.Equals(stra[0]))
                {
                    targetModel = _Model.FindEventObjectModel(eoNode.ModelID);                    
                }
            }
            if (targetModel != null)
            {
                List<string> namelist = new List<string>();
                foreach (OOEGStateVariable sv in targetModel.StateVariables)
                {
                    namelist.Add(sv.Name);
                }
                namelist.Sort();

                lbStateVariables.Items.Clear();
                lbStateVariables.Items.AddRange(namelist.ToArray());

                lbStateVariables.SelectedValue = stra[1];
            }
            isUpdating = false; 
        }

        #endregion

        private void lbEventObjects_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            if (string.IsNullOrEmpty(lbEventObjects.Text))
                return;

            OOMMObjectNode objectNode = _Model.ObjectInteractionDiagram.FindObjectNode(lbEventObjects.Text);
            List<string> namelist = new List<string>();

            if (objectNode.Type == ObjectNodeType.EventObject)
            {
                OOEGEventObjectModel eoModel = _Model.FindEventObjectModel(objectNode.ModelID);
                foreach (OOEGStateVariable sv in eoModel.StateVariables)
                {
                    namelist.Add(sv.Name);
                }
            }else if (objectNode.Type == ObjectNodeType.StateObject)
            {
                OOSGStateObjectModel eoModel = _Model.FindStateObjectModel(objectNode.ModelID);
                if (eoModel == null)
                    return;
                foreach (OOSGStateVariable sv in eoModel.StateVariables)
                {
                    namelist.Add(sv.Name);
                }
            }
            else if (objectNode.Type == ObjectNodeType.ActivityObject)
            {
                OOAGActivityObjectModel aoModel = _Model.FindActivityObjectModel(objectNode.ModelID);
                if (aoModel == null)
                    return;
                foreach (OOAGStateVariable sv in aoModel.StateVariables)
                {
                    namelist.Add(sv.Name);
                }
                foreach(OOAGQueue q in aoModel.Queues)
                {
                    namelist.Add(q.Name);
                }
            }
            namelist.Sort();

            lbStateVariables.Items.Clear();
            lbStateVariables.Items.AddRange(namelist.ToArray());
        }

        private void lbStateVariables_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtExpr.Text = string.Format("{0}.{1}", lbEventObjects.Text, lbStateVariables.Text);
        }
    }
}
