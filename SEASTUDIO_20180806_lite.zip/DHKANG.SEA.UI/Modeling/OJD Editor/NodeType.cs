﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.UI
{
    public enum NodeType { ActivityObject, EventObject, StateObject, ActivityVertex, EventVertex, StateVertex, QueueVertex, DataSource, Text, Label, Variable, Schedule, Message, Parameter};

    //TODO remove "Label"
}
