﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using DHKANG.SEA.Model.OID;

namespace DHKANG.SEA.UI
{
    public partial class ObjectSchedulingTableWindow : DockContent //Form
    {
        private SpreadsheetDoubleClickEventController _ObjectSelectedController;
        private SpreadsheetValueChangedEvent _ValueChangedController;
        public SpreadsheetObjectSelectedEvent ObjectSelected;


        private OOMMDiagramWindow _DiagramWindow;

        public OOMMDiagramWindow DiagramWindow
        {
            set { _DiagramWindow = value; }
        }

        public SpreadsheetValueChangedEvent ValueChangeController
        {
            get { return _ValueChangedController; }
        }
        
        public string[] Columns;

        public ObjectSchedulingTableWindow()
        {
            InitializeComponent();

            //_ValueChangedController = new SpreadsheetValueChangedEvent(this);

            _ObjectSelectedController = new SpreadsheetDoubleClickEventController();
            _ObjectSelectedController.SelectedEvent += new SpreadsheetObjectSelectedEvent(OnObjectSelected);
        }

        private void OnObjectSelected(string type, int id)
        {
            if (ObjectSelected != null && ObjectSelected.GetInvocationList().Length > 0)
                ObjectSelected(type, id);
        }        

        public void Update(string selectionType, string objectType)
        {
            if (_DiagramWindow == null)
                return;

            if (selectionType.Equals("eventobject"))
            {
                List<Node> nodes = _DiagramWindow.GetNodes(NodeType.EventObject);
                updateNodes(NodeType.EventObject, nodes);

            }
            else if (selectionType.Equals("link"))
            {
                List<Link> links = _DiagramWindow.GetLinks(LinkType.SchedulingLink);
                updateLinks(LinkType.SchedulingLink, links);
            }

            /*
            NodeType nType = NodeType.EventObject;
            LinkType lType = LinkType.SchedulingLink;

            if (!Enum.TryParse<NodeType>(objectType, out nType))
            {
                lType = (LinkType)Enum.Parse(typeof(LinkType), objectType);

                List<Link> links = _DiagramWindow.GetLinks(lType);
                updateLinks(lType, links);                
            }else{
                List<Node> nodes = _DiagramWindow.GetNodes(nType);
                updateNodes(nType, nodes);
            }
            */
        }

        private void updateNodes(NodeType type, List<Node> nodes)
        {
            if (nodes == null || nodes.Count == 0)
                return;

            drawHeaderforNodes(type);

            foreach (Node n in nodes)
            {
                insertToSpreadSheet(type, n);
            }

            spreadSheet.AutoSizeCells();
        }

        
        private void drawHeaderforNodes(NodeType type)
        {
            string[] columns = null;
            if (type == NodeType.EventObject)
            {
                columns = new string[] { "Node ID", "Node Name", "Number of Events", "Number of State Variables" };
            }

            drawHeader(columns);
        }

        private void insertToSpreadSheet(NodeType type, Node n)
        {
            int rowIndex = spreadSheet.RowsCount;
            spreadSheet.Rows.Insert(rowIndex);

            SourceGrid.Cells.Views.Cell defaultView = new SourceGrid.Cells.Views.Cell();
            defaultView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            spreadSheet[rowIndex, 0] = new SourceGrid.Cells.RowHeader(null);
            spreadSheet[rowIndex, 0].AddController(_ObjectSelectedController);

            //ID Column
            SourceGrid.Cells.Cell idCell = new SourceGrid.Cells.Cell(n.NodeID, typeof(int));
            idCell.View = defaultView;
            spreadSheet[rowIndex, 1] = idCell;
            spreadSheet[rowIndex, 1].Tag = n;
            //spreadSheet[rowIndex, 1].AddController(_ValueChangedController);

            //name column
            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(n.NodeName, typeof(string));
            nameCell.View = defaultView;
            spreadSheet[rowIndex, 2] = nameCell;
            spreadSheet[rowIndex, 2].Tag = n;
            spreadSheet[rowIndex, 2].AddController(_ValueChangedController);

            if (type == NodeType.EventObject)
            {
                EventObjectNode eoNode = (EventObjectNode ) n;
                
                SourceGrid.Cells.Cell noEventsCell = 
                    new SourceGrid.Cells.Cell(eoNode.Model.EventTransitions.Count, typeof(int));
                noEventsCell.View = defaultView;
                spreadSheet[rowIndex, 3] = noEventsCell;
                spreadSheet[rowIndex, 3].Tag = n;
                //spreadSheet[rowIndex, 3].AddController(_ValueChangedController);

                SourceGrid.Cells.Cell noSVsCell = 
                    new SourceGrid.Cells.Cell(eoNode.Model.StateVariables.Count, typeof(int));
                noSVsCell.View = defaultView;
                spreadSheet[rowIndex, 4] = noSVsCell;
                spreadSheet[rowIndex, 4].Tag = n;
            }
        }

        private void updateLinks(LinkType type, List<Link> links)
        {
            if (links == null || links.Count == 0)
                return;

            if (type == LinkType.SchedulingLink)
            {
                string[] columns = new string[] { "Link ID", "Mirror Event Object", "Mirror Event Name", "Boundary Event Object", "Boundary Event Name" };
                drawHeader(columns);

                foreach (Link l in links)
                {
                    insertToSpreadSheet((ObjectSchedulingLink)l);
                }
            }

            spreadSheet.AutoSizeCells();
        }

        private void insertToSpreadSheet(ObjectSchedulingLink link)
        {
            int rowIndex = spreadSheet.RowsCount;// -1;
            spreadSheet.Rows.Insert(rowIndex);

            SourceGrid.Cells.Views.Cell defaultView = new SourceGrid.Cells.Views.Cell();
            defaultView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            spreadSheet[rowIndex, 0] = new SourceGrid.Cells.RowHeader(null);
            spreadSheet[rowIndex, 0].AddController(_ObjectSelectedController);

            //ID Column
            SourceGrid.Cells.Cell idCell = new SourceGrid.Cells.Cell(link.LinkID, typeof(int));
            idCell.View = defaultView;
            spreadSheet[rowIndex, 1] = idCell;
            spreadSheet[rowIndex, 1].Tag = link;
            spreadSheet[rowIndex, 1].AddController(_ValueChangedController);

            //length column
            SourceGrid.Cells.Cell lengthCell = 
                new SourceGrid.Cells.Cell(link.FromObjectID, typeof(int));
            lengthCell.View = defaultView;
            spreadSheet[rowIndex, 2] = lengthCell;
            spreadSheet[rowIndex, 2].Tag = link;
            //spreadSheet[rowIndex, 2].AddController(_ValueChangedController);

            //speed factor column
            SourceGrid.Cells.Cell speedCell = 
                new SourceGrid.Cells.Cell(link.FromTriggerName, typeof(string));
            speedCell.View = defaultView;
            spreadSheet[rowIndex, 3] = speedCell;
            spreadSheet[rowIndex, 3].Tag = link;
            spreadSheet[rowIndex, 3].AddController(_ValueChangedController);
            //TODO
            //Change to ComboBox

            //speed limit column
            SourceGrid.Cells.Cell limitCell = 
                new SourceGrid.Cells.Cell(link.ToObjectID, typeof(int));
            limitCell.View = defaultView;
            spreadSheet[rowIndex, 4] = limitCell;
            spreadSheet[rowIndex, 4].Tag = link;
            //spreadSheet[rowIndex, 4].AddController(_ValueChangedController);
           

            //speed factor column
            SourceGrid.Cells.Cell toEventNameCell = 
                new SourceGrid.Cells.Cell(link.ToTriggerName, typeof(string));
            toEventNameCell.View = defaultView;
            spreadSheet[rowIndex, 5] = toEventNameCell;
            spreadSheet[rowIndex, 5].Tag = link;
            spreadSheet[rowIndex, 5].AddController(_ValueChangedController);
            //TODO
            //Change to ComboBox
        }
        
        private void drawHeader(string[] columns)
        {
            spreadSheet.Rows.Clear();

            spreadSheet.BorderStyle = BorderStyle.FixedSingle;
            spreadSheet.Redim(1, columns.Length + 1);
            spreadSheet.EnableSort = false;
            spreadSheet.CustomSort = false;
            spreadSheet.FixedRows = 1;

            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            spreadSheet.Font = new Font("Calibri", 11);
            //spreadSheet.AutoStretchColumnsToFitWidth = 
            //    _ModelControl.Configuration.SpreadSheet.TableStretch;

            spreadSheet.Columns[0].AutoSizeMode = SourceGrid.AutoSizeMode.None;
            spreadSheet.Columns[0].Width = 25;
            SourceGrid.Cells.RowHeader l_00Header1 = new SourceGrid.Cells.RowHeader(null);
            spreadSheet[0, 0] = l_00Header1;

            for (int i = 0; i < columns.Length; i++)
            {
                SourceGrid.Cells.ColumnHeader header =
                new SourceGrid.Cells.ColumnHeader(columns[i]);
                header.View = titleModel;
                header.SortComparer = new SourceGrid.ValueCellComparer();
                spreadSheet[0, i + 1] = header;
            }

            this.Columns = columns;
        }
    }    
}
