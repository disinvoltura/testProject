﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI
{
    public partial class LabelNodeDialog : Form
    {
        #region Member Variables
        private OOMMModel _Model;
        private LabelNode _Node;
        #endregion

        #region Properties
        public string EventObjectName
        {
            get
            {
                return cbEOList.Text;
            }
        }

        public string StateVariableName
        {
            get
            {
                return cbSVList.Text;
            }
        }

        #endregion

        #region Constructors
        public LabelNodeDialog(OOMMModel model)
        {
            _Model = model;
            InitializeComponent();
        }

        public LabelNodeDialog(OOMMModel model, LabelNode node)
        {
            _Model = model;
            _Node = node;

            InitializeComponent();
        }
        #endregion

        #region Methods
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbEOList.Text) ||
               string.IsNullOrEmpty(cbSVList.Text))
            {
                return;
            }

            this.DialogResult = DialogResult.OK;
            this.Close();

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void LabelNodeDialog_Load(object sender, EventArgs e)
        {
            foreach(OOEGEventObjectModel eoModel in _Model.EventObjectModels)
            {
                cbEOList.Items.Add(eoModel.Name);
            }


            if (_Node != null)
            {
                cbEOList.SelectedItem = _Node.ObjectName;
            }
        }

        private void cbEOList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbEOList.Text))
                return;

            OOEGEventObjectModel eoModel = _Model.FindEventObjectModel(cbEOList.Text);
            List<string> namelist = new List<string>();
            foreach(OOEGStateVariable sv in eoModel.StateVariables)
            {
                namelist.Add(sv.Name);
            }
            namelist.Sort();

            cbSVList.Items.Clear();
            cbSVList.Items.AddRange(namelist.ToArray());

            if (_Node != null)
            {
                cbSVList.SelectedText = _Node.StateVariableName;
                _Node = null;
            }
        }
        #endregion
    }
}
