﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using Northwoods.Go;
using DHKANG.SEA.Model;
using DHKANG.SEA.UI.OutputView.Visualization;
using DHKANG.SEA.Model.OID.Charts;
using DHKANG.SEA.Model.OID;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.Data;
using DHKANG.SEA.Model.OID.Presentation;
using DHKANG.SEA.Model.OID.Data;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model.ActivityObjects;

namespace DHKANG.SEA.UI
{
    public class OOMMDiagramDocument : GoDocument, DiagramDocument
    {
        #region Member Variables
        private int _nodeCounter = 0;
        public static float NodeWidth = 60;
        public static float NodeHeight = 60;

        private NodeFactory _Factory;
        #endregion

        #region Constructors
        public OOMMDiagramDocument()
            : base()
        {
            this.Name = "1";

            _Factory = new NodeFactory();
            _Factory.Document = this;
        }

        public OOMMDiagramDocument(string name)
            : this()
        {
            this.Name = name;
        }
        #endregion

        #region Initialization Methods
        public void Initialize()
        {
            _Factory = new NodeFactory();
            //_Objects = new Dictionary<string, GoObject>();
            _Factory.Document = this;


        }
        #endregion

        #region Insertion Methods
        public BarChart InsertBarChart(string title, float x, float y, float width, float height)
        {
            this.StartTransaction();

            BarChart chart = new BarChart(title, "no description is available", x, y, width, height);

            this.Add(chart);
            this.FinishTransaction("Bar Chart is inserted.");

            return chart;
        }

        public BarChart InsertBarChart(OOMMModel model, OOMMBarChart node)
        {
            this.StartTransaction();

            BarChart chart = new BarChart(node.Title, node.Description, node.Dimension.X, node.Dimension.Y, node.Dimension.Width, node.Dimension.Height);
            foreach (OOMMSeries s in node.Series.Values)
            {
                SeriesChartType type = SeriesChartType.Bar;
                if (s.Type == OOMMSeriesChartType.Line)
                    type = SeriesChartType.Line;
                else if (s.Type == OOMMSeriesChartType.Spline)
                    type = SeriesChartType.Spline;
                if (s.Type == OOMMSeriesChartType.StepLine)
                    type = SeriesChartType.StepLine;

                MarkerType mType = MarkerType.None;
                if (s.Appearance.MarkerType == OOMMMarkerType.Diamond)
                    mType = MarkerType.Diamond;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Oval)
                    mType = MarkerType.Oval;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Rectangle)
                    mType = MarkerType.Rectangle;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Triangle)
                    mType = MarkerType.Triangle;
                Series ns = new Series(s.Name, ColorTranslator.FromHtml(s.Appearance.LineColor), ColorTranslator.FromHtml(s.Appearance.MarkerColor), ColorTranslator.FromHtml(s.Appearance.BackgroundColor), s.Value, s.Appearance.LineWidth, mType);
                ns.ChartType = type;
                //ns.MarkerColor = ColorTranslator.FromHtml(s.Appearance.MarkerColor);
                //ns.BackgroundColor = ColorTranslator.FromHtml(s.Appearance.BackgroundColor);

                chart.AddSeries(ns);
            }
            chart.BackgroundColor = ColorTranslator.FromHtml(node.Appearance.BackgroundColor);
            chart.BorderColor = ColorTranslator.FromHtml(node.Appearance.BorderColor);
            chart.BorderWeight = node.Appearance.BorderWeight;


            this.Add(chart);
            this.FinishTransaction("Bar Chart is inserted.");

            return chart;
        }

        public StackedBarChart InsertStackedBarChart(string title, float x, float y, float width, float height)
        {
            this.StartTransaction();

            StackedBarChart chart = new StackedBarChart(title, "no description is available", x, y, width, height);

            this.Add(chart);
            this.FinishTransaction("Stacked Bar Chart is inserted.");

            return chart;
        }

        public StackedBarChart InsertStackedBarChart(OOMMModel model, OOMMBarChart node)
        {
            this.StartTransaction();

            StackedBarChart chart = new StackedBarChart(node.Title, node.Description, node.Dimension.X, node.Dimension.Y, node.Dimension.Width, node.Dimension.Height);
            foreach (OOMMSeries s in node.Series.Values)
            {
                SeriesChartType type = SeriesChartType.Bar;
                if (s.Type == OOMMSeriesChartType.Line)
                    type = SeriesChartType.Line;
                else if (s.Type == OOMMSeriesChartType.Spline)
                    type = SeriesChartType.Spline;
                if (s.Type == OOMMSeriesChartType.StepLine)
                    type = SeriesChartType.StepLine;

                MarkerType mType = MarkerType.None;
                if (s.Appearance.MarkerType == OOMMMarkerType.Diamond)
                    mType = MarkerType.Diamond;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Oval)
                    mType = MarkerType.Oval;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Rectangle)
                    mType = MarkerType.Rectangle;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Triangle)
                    mType = MarkerType.Triangle;
                Series ns = new Series(s.Name, ColorTranslator.FromHtml(s.Appearance.LineColor), ColorTranslator.FromHtml(s.Appearance.MarkerColor), ColorTranslator.FromHtml(s.Appearance.BackgroundColor), s.Value, s.Appearance.LineWidth, mType);
                ns.ChartType = type;
                chart.AddSeries(ns);
            }
            chart.BackgroundColor = ColorTranslator.FromHtml(node.Appearance.BackgroundColor);
            chart.BorderColor = ColorTranslator.FromHtml(node.Appearance.BorderColor);
            chart.BorderWeight = node.Appearance.BorderWeight;

            this.Add(chart);
            this.FinishTransaction("Stacked Bar Chart is inserted.");

            return chart;
        }

        public HorizontalBarChart InsertHorizontalBarChart(string title, float x, float y, float width, float height)
        {
            this.StartTransaction();

            HorizontalBarChart chart = new HorizontalBarChart(title, "no description is available", x, y, width, height);

            this.Add(chart);
            this.FinishTransaction("Horizontal Bar Chart is inserted.");

            return chart;
        }

        public HorizontalBarChart InsertHorizontalBarChart(OOMMModel model, OOMMBarChart node)
        {
            this.StartTransaction();

            HorizontalBarChart chart = new HorizontalBarChart(node.Title, node.Description, node.Dimension.X, node.Dimension.Y, node.Dimension.Width, node.Dimension.Height);
            foreach (OOMMSeries s in node.Series.Values)
            {
                SeriesChartType type = SeriesChartType.Bar;
                if (s.Type == OOMMSeriesChartType.Line)
                    type = SeriesChartType.Line;
                else if (s.Type == OOMMSeriesChartType.Spline)
                    type = SeriesChartType.Spline;
                if (s.Type == OOMMSeriesChartType.StepLine)
                    type = SeriesChartType.StepLine;

                MarkerType mType = MarkerType.None;
                if (s.Appearance.MarkerType == OOMMMarkerType.Diamond)
                    mType = MarkerType.Diamond;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Oval)
                    mType = MarkerType.Oval;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Rectangle)
                    mType = MarkerType.Rectangle;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Triangle)
                    mType = MarkerType.Triangle;
                Series ns = new Series(s.Name, ColorTranslator.FromHtml(s.Appearance.LineColor), ColorTranslator.FromHtml(s.Appearance.MarkerColor), ColorTranslator.FromHtml(s.Appearance.BackgroundColor), s.Value, s.Appearance.LineWidth, mType);
                ns.ChartType = type;
                chart.AddSeries(ns);
            }
            chart.BackgroundColor = ColorTranslator.FromHtml(node.Appearance.BackgroundColor);
            chart.BorderColor = ColorTranslator.FromHtml(node.Appearance.BorderColor);
            chart.BorderWeight = node.Appearance.BorderWeight;

            this.Add(chart);
            this.FinishTransaction("Horizontal Bar Chart is inserted.");

            return chart;
        }

        public StackedHorizontalBarChart InsertStackedHorizontalBarChart(string title, float x, float y, float width, float height)
        {
            this.StartTransaction();

            StackedHorizontalBarChart chart = new StackedHorizontalBarChart(title, "no description is available", x, y, width, height);

            this.Add(chart);
            this.FinishTransaction("Stacked Horizontal Bar Chart is inserted.");

            return chart;
        }

        public StackedHorizontalBarChart InsertStackedHorizontalBarChart(OOMMModel model, OOMMBarChart node)
        {
            this.StartTransaction();

            StackedHorizontalBarChart chart = new StackedHorizontalBarChart(node.Title, node.Description, node.Dimension.X, node.Dimension.Y, node.Dimension.Width, node.Dimension.Height);
            foreach (OOMMSeries s in node.Series.Values)
            {
                SeriesChartType type = SeriesChartType.Bar;
                if (s.Type == OOMMSeriesChartType.Line)
                    type = SeriesChartType.Line;
                else if (s.Type == OOMMSeriesChartType.Spline)
                    type = SeriesChartType.Spline;
                if (s.Type == OOMMSeriesChartType.StepLine)
                    type = SeriesChartType.StepLine;

                MarkerType mType = MarkerType.None;
                if (s.Appearance.MarkerType == OOMMMarkerType.Diamond)
                    mType = MarkerType.Diamond;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Oval)
                    mType = MarkerType.Oval;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Rectangle)
                    mType = MarkerType.Rectangle;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Triangle)
                    mType = MarkerType.Triangle;
                Series ns = new Series(s.Name, ColorTranslator.FromHtml(s.Appearance.LineColor), ColorTranslator.FromHtml(s.Appearance.MarkerColor), ColorTranslator.FromHtml(s.Appearance.BackgroundColor), s.Value, s.Appearance.LineWidth, mType);
                ns.ChartType = type;
                chart.AddSeries(ns);
            }
            chart.BackgroundColor = ColorTranslator.FromHtml(node.Appearance.BackgroundColor);
            chart.BorderColor = ColorTranslator.FromHtml(node.Appearance.BorderColor);
            chart.BorderWeight = node.Appearance.BorderWeight;

            this.Add(chart);
            this.FinishTransaction("Stacked Horizontal Bar Chart is inserted.");

            return chart;
        }

        public PieChart InsertPieChart(string title, float x, float y, float width, float height)
        {
            this.StartTransaction();

            PieChart chart = new PieChart(title, "no description is available", x, y, width, height);

            this.Add(chart);
            this.FinishTransaction("Pie Chart is inserted.");

            return chart;
        }

        public PieChart InsertPieChart(OOMMModel model, OOMMPieChart node)
        {
            this.StartTransaction();

            PieChart chart = new PieChart(node.Title, node.Description, node.Dimension.X, node.Dimension.Y, node.Dimension.Width, node.Dimension.Height);
            foreach (OOMMSeries s in node.Series.Values)
            {
                SeriesChartType type = SeriesChartType.Bar;
                MarkerType mType = MarkerType.None;
                Series ns = new Series(s.Name, ColorTranslator.FromHtml(s.Appearance.LineColor), ColorTranslator.FromHtml(s.Appearance.MarkerColor), ColorTranslator.FromHtml(s.Appearance.BackgroundColor), s.Value, s.Appearance.LineWidth, mType);
                ns.ChartType = type;
                //ns.MarkerColor = ColorTranslator.FromHtml(s.Appearance.MarkerColor);
                //ns.BackgroundColor = ColorTranslator.FromHtml(s.Appearance.BackgroundColor);

                chart.AddSeries(ns);
            }
            chart.BackgroundColor = ColorTranslator.FromHtml(node.Appearance.BackgroundColor);
            chart.BorderColor = ColorTranslator.FromHtml(node.Appearance.BorderColor);
            chart.BorderWeight = node.Appearance.BorderWeight;

            this.Add(chart);
            this.FinishTransaction("Pie Chart is inserted.");

            return chart;
        }

        public DonutChart InsertDonutChart(string title, float x, float y, float width, float height)
        {
            this.StartTransaction();

            DonutChart chart = new DonutChart(title, "no description is available", x, y, width, height);

            this.Add(chart);
            this.FinishTransaction("Donut Chart is inserted.");

            return chart;
        }

        public Tile InsertTile(float x, float y, float width, float height)
        {
            this.StartTransaction();

            Tile tile = new Tile("", "", x, y, width, height);

            this.Add(tile);
            this.FinishTransaction("Tile is inserted.");

            return tile;
        }

        public Tile InsertTile(OOMMModel model, OOMMTile node)
        {
            this.StartTransaction();

            Tile tile = new Tile(node.Name, node.Value, node.Dimension.X, node.Dimension.Y, node.Dimension.Width, node.Dimension.Height);
            tile.TargetObjectId = node.TargetObjectId;
            tile.TargetObject = node.TargetObject;
            tile.TargetVariable = node.TargetVariable;
            tile.InitialValue = node.InitialValue;

            this.Add(tile);
            this.FinishTransaction("Tile is inserted.");

            return tile;
        }

        public DonutChart InsertDonutChart(OOMMModel model, OOMMDonutChart node)
        {
            this.StartTransaction();

            DonutChart chart = new DonutChart(node.Title, node.Description, node.Dimension.X, node.Dimension.Y, node.Dimension.Width, node.Dimension.Height);
            foreach (OOMMSeries s in node.Series.Values)
            {
                SeriesChartType type = SeriesChartType.Bar;
                MarkerType mType = MarkerType.None;
                Series ns = new Series(s.Name, ColorTranslator.FromHtml(s.Appearance.LineColor), ColorTranslator.FromHtml(s.Appearance.MarkerColor), ColorTranslator.FromHtml(s.Appearance.BackgroundColor), s.Value, s.Appearance.LineWidth, mType);
                ns.ChartType = type;
                //ns.MarkerColor = ColorTranslator.FromHtml(s.Appearance.MarkerColor);
                //ns.BackgroundColor = ColorTranslator.FromHtml(s.Appearance.BackgroundColor);

                chart.AddSeries(ns);
            }
            chart.BackgroundColor = ColorTranslator.FromHtml(node.Appearance.BackgroundColor);
            chart.BorderColor = ColorTranslator.FromHtml(node.Appearance.BorderColor);
            chart.BorderWeight = node.Appearance.BorderWeight;

            this.Add(chart);
            this.FinishTransaction("Pie Chart is inserted.");

            return chart;
        }

        public BoxWhiskerChart InsertBoxWhiskerChart(string title, float x, float y, float width, float height)
        {
            this.StartTransaction();

            BoxWhiskerChart chart = new BoxWhiskerChart(title, "no description is available", x, y, width, height);

            this.Add(chart);
            this.FinishTransaction("Box-Whisker Chart is inserted.");

            return chart;
        }

        public BoxWhiskerChart InsertBoxWhiskerChart(OOMMModel model, OOMMBoxWhiskerChart node)
        {
            this.StartTransaction();

            BoxWhiskerChart chart = new BoxWhiskerChart(node.Title, node.Description, node.Dimension.X, node.Dimension.Y, node.Dimension.Width, node.Dimension.Height);
            foreach (OOMMSeries s in node.Series.Values)
            {
                SeriesChartType type = SeriesChartType.Bar;
                if (s.Type == OOMMSeriesChartType.Line)
                    type = SeriesChartType.Line;
                else if (s.Type == OOMMSeriesChartType.Spline)
                    type = SeriesChartType.Spline;
                if (s.Type == OOMMSeriesChartType.StepLine)
                    type = SeriesChartType.StepLine;

                MarkerType mType = MarkerType.None;
                if (s.Appearance.MarkerType == OOMMMarkerType.Diamond)
                    mType = MarkerType.Diamond;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Oval)
                    mType = MarkerType.Oval;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Rectangle)
                    mType = MarkerType.Rectangle;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Triangle)
                    mType = MarkerType.Triangle;
                Series ns = new Series(s.Name, ColorTranslator.FromHtml(s.Appearance.LineColor), ColorTranslator.FromHtml(s.Appearance.MarkerColor), ColorTranslator.FromHtml(s.Appearance.BackgroundColor), s.Value, s.Appearance.LineWidth, mType);
                ns.ChartType = type;
                //ns.MarkerColor = ColorTranslator.FromHtml(s.Appearance.MarkerColor);
                //ns.BackgroundColor = ColorTranslator.FromHtml(s.Appearance.BackgroundColor);

                chart.AddSeries(ns);
            }
            chart.BackgroundColor = ColorTranslator.FromHtml(node.Appearance.BackgroundColor);
            chart.BorderColor = ColorTranslator.FromHtml(node.Appearance.BorderColor);
            chart.BorderWeight = node.Appearance.BorderWeight;


            this.Add(chart);
            this.FinishTransaction("Box-Whisker Chart is inserted.");

            return chart;
        }

        public Plot InsertPlot(string title, float x, float y, float width, float height)
        {
            this.StartTransaction();

            Plot chart = new Plot(title, "no description is available", x, y, width, height);

            this.Add(chart);
            this.FinishTransaction("Plot is inserted.");

            return chart;
        }

        public Plot InsertPlot(OOMMModel model, OOMMPlot node)
        {
            this.StartTransaction();

            Plot chart = new Plot(node.Title,  node.Description, node.Dimension.X, node.Dimension.Y, node.Dimension.Width, node.Dimension.Height);
            foreach (OOMMSeries s in node.Series.Values)
            {
                SeriesChartType type = SeriesChartType.Bar;
                if (s.Type == OOMMSeriesChartType.Line)
                    type = SeriesChartType.Line;
                else if (s.Type == OOMMSeriesChartType.Spline)
                    type = SeriesChartType.Spline;
                if (s.Type == OOMMSeriesChartType.StepLine)
                    type = SeriesChartType.StepLine;

                MarkerType mType = MarkerType.None;
                if (s.Appearance.MarkerType == OOMMMarkerType.Diamond)
                    mType = MarkerType.Diamond;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Oval)
                    mType = MarkerType.Oval;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Rectangle)
                    mType = MarkerType.Rectangle;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Triangle)
                    mType = MarkerType.Triangle;

                Series ns = new Series(s.Name, ColorTranslator.FromHtml(s.Appearance.LineColor), ColorTranslator.FromHtml(s.Appearance.MarkerColor), ColorTranslator.FromHtml(s.Appearance.BackgroundColor), s.Value, s.Appearance.LineWidth, mType);
                ns.ChartType = type;
                //ns.MarkerColor = ColorTranslator.FromHtml(s.Appearance.MarkerColor);
                //ns.BackgroundColor = ColorTranslator.FromHtml(s.Appearance.BackgroundColor);

                chart.AddSeries(ns);
            }

            chart.BackgroundColor = ColorTranslator.FromHtml(node.Appearance.BackgroundColor);
            chart.BorderColor = ColorTranslator.FromHtml(node.Appearance.BorderColor);
            chart.BorderWeight = (int)node.Appearance.BorderWeight;

            this.Add(chart);
            this.FinishTransaction("Plot is inserted.");

            return chart;
        }

        public TimePlot InsertTimePlot(string title, float x, float y, float width, float height)
        {
            this.StartTransaction();

            TimePlot chart = new TimePlot(title, "no description is available",  x, y, width, height);

            this.Add(chart);
            this.FinishTransaction("Time Plot is inserted.");

            return chart;
        }

        public TimePlot InsertTimePlot(OOMMModel model, OOMMTimePlot node)
        {
            this.StartTransaction();

            TimePlot chart = new TimePlot(node.Title, node.Description, node.Dimension.X, node.Dimension.Y, node.Dimension.Width, node.Dimension.Height);
            foreach (OOMMSeries s in node.Series.Values)
            {
                SeriesChartType type = SeriesChartType.Bar;
                if (s.Type == OOMMSeriesChartType.Line)
                    type = SeriesChartType.Line;
                else if (s.Type == OOMMSeriesChartType.Spline)
                    type = SeriesChartType.Spline;
                if (s.Type == OOMMSeriesChartType.StepLine)
                    type = SeriesChartType.StepLine;

                MarkerType mType = MarkerType.None;
                if (s.Appearance.MarkerType == OOMMMarkerType.Diamond)
                    mType = MarkerType.Diamond;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Oval)
                    mType = MarkerType.Oval;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Rectangle)
                    mType = MarkerType.Rectangle;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Triangle)
                    mType = MarkerType.Triangle;

                Series ns = new Series(s.Name, ColorTranslator.FromHtml(s.Appearance.LineColor), ColorTranslator.FromHtml(s.Appearance.MarkerColor), ColorTranslator.FromHtml(s.Appearance.BackgroundColor), s.Value, s.Appearance.LineWidth, mType);
                ns.ChartType = type;

                chart.AddSeries(ns);
            }

            chart.BackgroundColor = ColorTranslator.FromHtml(node.Appearance.BackgroundColor);
            chart.BorderColor = ColorTranslator.FromHtml(node.Appearance.BorderColor);
            chart.BorderWeight = node.Appearance.BorderWeight;

            this.Add(chart);

            chart.Width = node.Dimension.Width;
            chart.Height = node.Dimension.Height;

            this.FinishTransaction("Time Plot is inserted.");

            return chart;
        }

        public Histogram InsertHistogram(string title, float x, float y, float width, float height)
        {
            this.StartTransaction();

            Histogram chart = new Histogram(title, "no description is available", x, y, width, height);

            this.Add(chart);
            this.FinishTransaction("Histogram is inserted.");

            return chart;
        }

        public Histogram InsertHistogram(OOMMModel model, OOMMHistogram node)
        {
            this.StartTransaction();

            Histogram chart = new Histogram(node.Title, node.Description, node.Dimension.X, node.Dimension.Y, node.Dimension.Width, node.Dimension.Height);
            foreach (OOMMSeries s in node.Series.Values)
            {
                SeriesChartType type = SeriesChartType.Bar;
                if (s.Type == OOMMSeriesChartType.Line)
                    type = SeriesChartType.Line;
                else if (s.Type == OOMMSeriesChartType.Spline)
                    type = SeriesChartType.Spline;
                if (s.Type == OOMMSeriesChartType.StepLine)
                    type = SeriesChartType.StepLine;

                MarkerType mType = MarkerType.None;
                if (s.Appearance.MarkerType == OOMMMarkerType.Diamond)
                    mType = MarkerType.Diamond;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Oval)
                    mType = MarkerType.Oval;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Rectangle)
                    mType = MarkerType.Rectangle;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Triangle)
                    mType = MarkerType.Triangle;

                Series ns = new Series(s.Name, ColorTranslator.FromHtml(s.Appearance.LineColor), ColorTranslator.FromHtml(s.Appearance.MarkerColor), ColorTranslator.FromHtml(s.Appearance.BackgroundColor), s.Value, s.Appearance.LineWidth, mType);
                ns.ChartType = type;

                chart.AddSeries(ns);
            }

            chart.BackgroundColor = ColorTranslator.FromHtml(node.Appearance.BackgroundColor);
            chart.BorderColor = ColorTranslator.FromHtml(node.Appearance.BorderColor);
            chart.BorderWeight = node.Appearance.BorderWeight;

            this.Add(chart);

            chart.Width = node.Dimension.Width;
            chart.Height = node.Dimension.Height;

            this.FinishTransaction("Histogram is inserted.");

            return chart;
        }

        public ScatterChart InsertScatterChart(string title, float x, float y, float width, float height)
        {
            this.StartTransaction();

            ScatterChart chart = new ScatterChart(title, "no description is available", x, y, width, height);

            this.Add(chart);
            this.FinishTransaction("ScatterChart is inserted.");

            return chart;
        }

        public ScatterChart InsertScatterChart(OOMMModel model, OOMMScatterChart node)
        {
            this.StartTransaction();

            ScatterChart chart = new ScatterChart(node.Title, node.Description, node.Dimension.X, node.Dimension.Y, node.Dimension.Width, node.Dimension.Height);
            foreach (OOMMSeries s in node.Series.Values)
            {
                SeriesChartType type = SeriesChartType.Bar;
                if (s.Type == OOMMSeriesChartType.Line)
                    type = SeriesChartType.Line;
                else if (s.Type == OOMMSeriesChartType.Spline)
                    type = SeriesChartType.Spline;
                if (s.Type == OOMMSeriesChartType.StepLine)
                    type = SeriesChartType.StepLine;

                MarkerType mType = MarkerType.None;
                if (s.Appearance.MarkerType == OOMMMarkerType.Diamond)
                    mType = MarkerType.Diamond;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Oval)
                    mType = MarkerType.Oval;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Rectangle)
                    mType = MarkerType.Rectangle;
                else if (s.Appearance.MarkerType == OOMMMarkerType.Triangle)
                    mType = MarkerType.Triangle;

                Series ns = new Series(s.Name, ColorTranslator.FromHtml(s.Appearance.LineColor), ColorTranslator.FromHtml(s.Appearance.MarkerColor), ColorTranslator.FromHtml(s.Appearance.BackgroundColor), s.Value, s.Appearance.LineWidth, mType);
                ns.ChartType = type;

                chart.AddSeries(ns);
            }

            chart.BackgroundColor = ColorTranslator.FromHtml(node.Appearance.BackgroundColor);
            chart.BorderColor = ColorTranslator.FromHtml(node.Appearance.BorderColor);
            chart.BorderWeight = node.Appearance.BorderWeight;

            this.Add(chart);

            chart.Width = node.Dimension.Width;
            chart.Height = node.Dimension.Height;

            this.FinishTransaction("ScatterChart is inserted.");

            return chart;
        }

        public GoTextNode InsertClockNode()
        {
            this.StartTransaction();

            GoTextNode node = new GoTextNode();
            node.Center = new PointF(15, 15);
            node.Text = "Clock: 0";
            this.Add(node);
            this.FinishTransaction("Clock Node is inserted.");
            return node;
        }

        public Node InsertActivityObjectNode(float x, float y)
        {
            this.StartTransaction();

            ActivityObjectNode node =
                (ActivityObjectNode)_Factory.GetInstance(NodeType.ActivityObject);
            node.Position = new PointF(x, y);
            node.NodeGuid = Guid.NewGuid();

            this.Add(node.Presentation);

            this.FinishTransaction("ActivityObject Node is inserted.");

            return node;
        }

        public Node InsertEventObjectNode(float x, float y)
        {
            this.StartTransaction();

            EventObjectNode node =
                (EventObjectNode)_Factory.GetInstance(NodeType.EventObject);
            node.Position = new PointF(x, y);
            node.NodeGuid = Guid.NewGuid();

            this.Add(node.Presentation);

            this.FinishTransaction("EventObject Node is inserted.");

            return node;
        }

        public Node InsertStateObjectNode(float x, float y)
        {
            this.StartTransaction();

            StateObjectNode node =
                (StateObjectNode)_Factory.GetInstance(NodeType.StateObject);
            node.Position = new PointF(x, y);
            node.NodeGuid = Guid.NewGuid();

            this.Add(node.Presentation);

            this.FinishTransaction("StateObject Node is inserted.");

            return node;
        }

        public DataSourceNode InsertDataSourceNode(OOMMModel model, OOMMDataSourceNode dsNode)
        {
            this.StartTransaction();
            OOMMDataSource ds = model.FindDataSource(dsNode.ID);
            if (ds == null)
                return null;

            DataSourceNode node = new DataSourceNode(ds, dsNode.X, dsNode.Y);
            node.Position = new PointF(dsNode.X, dsNode.Y);

            this.Add(node);

            this.FinishTransaction("DataSource Node is inserted.");

            return node;
        }

        public DataSourceNode InsertDataSourceNode(OOMMDataSource ds, float x, float y)
        {
            this.StartTransaction();

            DataSourceNode node = new DataSourceNode(ds, x, y);
            node.Position = new PointF(x, y);

            this.Add(node);

            this.FinishTransaction("DataSource Node is inserted.");

            return node;
        }

        public EventObjectNode InsertEventObjectNode(OOMMObjectNode n, OOEGEventObjectModel m)
        {
            this.StartTransaction();

            EventObjectNode node =
                (EventObjectNode)_Factory.GetInstance(NodeType.EventObject);
            node.Model = m;
            node.NodeGuid = n.NodeID;
            node.NodeName = n.Name;
            node.Position = new PointF(n.X, n.Y);
            node.BackgroundColor = Color.FromArgb(n.BackgroundColor);
            ((MultiPortNode)node.Presentation).NodeName = n.Name;
            ((MultiPortNode)node.Presentation).NodeType = m.Name;
            this.Add(node.Presentation);
            this.FinishTransaction("EventObject Node is inserted.");

            return node;
        }

        public ActivityObjectNode InsertActivityObjectNode(OOMMObjectNode n, OOAGActivityObjectModel m)
        {
            this.StartTransaction();

            ActivityObjectNode node =
                (ActivityObjectNode)_Factory.GetInstance(NodeType.ActivityObject);
            node.Model = m;
            node.NodeGuid = n.NodeID;
            node.NodeName = n.Name;
            node.Position = new PointF(n.X, n.Y);
            node.BackgroundColor = Color.FromArgb(n.BackgroundColor);
            ((MultiPortNode)node.Presentation).NodeName = n.Name;
            ((MultiPortNode)node.Presentation).NodeType = m.Name;
            this.Add(node.Presentation);
            this.FinishTransaction("ActivityObjectNode is inserted.");

            return node;
        }

        public StateObjectNode InsertStateObjectNode(OOMMObjectNode n, OOSGStateObjectModel m)
        {
            this.StartTransaction();

            StateObjectNode node =
                (StateObjectNode)_Factory.GetInstance(NodeType.StateObject);
            node.Model = m;
            node.NodeGuid = n.NodeID;
            node.NodeName = n.Name;
            node.Position = new PointF(n.X, n.Y);
            node.BackgroundColor = Color.FromArgb(n.BackgroundColor);
            ((MultiPortNode)node.Presentation).NodeName = n.Name;
            ((MultiPortNode)node.Presentation).NodeType = m.Name;
            this.Add(node.Presentation);
            this.FinishTransaction("StateObject Node is inserted.");

            return node;
        }

        private int _TextNodeCounter = 1;
        public TextNode InsertTextNode(float x, float y)
        {
            this.StartTransaction();

            string nextName = "Text " + _TextNodeCounter++;
            while (FindNode(nextName) != null)
            {
                nextName = "Text " + _TextNodeCounter++;
            }
            TextNode node = new TextNode(nextName, x, y);
            this.Add(node);
            this.FinishTransaction("Text Node is inserted.");

            return node;

        }

        public TextNode InsertTextNode(OOMMTextNode lt)
        {
            this.StartTransaction();

            TextNode n = new TextNode(lt.Text, lt.X, lt.Y);

            FontStyle fs = new FontStyle();
            if (lt.Font.Bold)
                fs = fs | FontStyle.Bold;
            if (lt.Font.Italic)
                fs = fs | FontStyle.Italic;
            if (lt.Font.Underline)
                fs = fs | FontStyle.Underline;
            if (lt.Font.Strikeout)
                fs = fs | FontStyle.Strikeout;
            n.Font = new Font(lt.Font.Name, lt.Font.Size, fs);
            n.TextColor = Color.FromArgb(lt.Font.Color);
            n.BackgroundColor = Color.FromArgb(lt.BackColor);
            n.TransparentBackground = lt.TransparentBackground;
            n.Position = new PointF(lt.X, lt.Y);
            //n.Center = new PointF(lt.X, lt.Y);

            this.Add(n);
            this.FinishTransaction("Text Node is inserted.");

            return n;
        }

        private int _LabelNodeCounter = 1;
        public LabelNode InsertLabelNode(float x, float y)
        {
            this.StartTransaction();

            string nextName = "Variable " + _LabelNodeCounter++;
            while (FindLabelNode(nextName) != null)
            {
                nextName = "Variable " + _LabelNodeCounter++;
            }
            LabelNode node = new LabelNode(nextName, x, y);
            this.Add(node);
            this.FinishTransaction("Label Node is inserted.");
            return node;
        }

        public LabelNode InsertLabelNode(Guid eventObjectID, string eventObjectName, string stateVariableName, string initialValue, float x, float y)
        {
            this.StartTransaction();

            string nextName = "Variable " + _LabelNodeCounter++;
            while (FindNode(nextName) != null)
            {
                nextName = "Variable " + _LabelNodeCounter++;
            }
            LabelNode n = new LabelNode(Guid.NewGuid(), nextName, eventObjectID, eventObjectName, stateVariableName, initialValue, x, y);
            n.Position = new PointF(x, y);

            this.Add(n);
            this.FinishTransaction("Label Node is inserted.");

            return n;
        }

        public LabelNode InsertLabelNode(Guid nodeid, string name, Guid eventObjectID, string eventObjectName, string stateVariableName, string initialValue, float x, float y)
        {
            this.StartTransaction();

            LabelNode n = new LabelNode(nodeid, name, eventObjectID, eventObjectName, stateVariableName, initialValue, x, y);
            n.Position = new PointF(x, y);

            this.Add(n);
            this.FinishTransaction("Label Node is inserted.");

            return n;
        }

        public LabelNode InsertLabelNode(OOMMModel model, OOMMLabelNode lt)
        {

            OOMMObjectNode objectNode = model.ObjectInteractionDiagram.FindObjectNode(lt.ObjectID);
            if (objectNode == null)
                return null;

            string svInitialValue = string.Empty;
            if (objectNode.Type == ObjectNodeType.EventObject)
            {
                OOEGEventObjectModel eoModel = model.FindEventObjectModel(objectNode.ModelID);
                if (eoModel == null)
                    return null;
                OOEGStateVariable sv = eoModel.GetStateVariable(lt.StateVariableName);
                svInitialValue = sv.InitialValue;
            }
            else if (objectNode.Type == ObjectNodeType.StateObject)
            {
                OOSGStateObjectModel soModel = model.FindStateObjectModel(objectNode.ModelID);
                if (soModel == null)
                    return null;
                OOSGStateVariable sv = soModel.FindStateVariable(lt.StateVariableName);
                if (sv.InitialValue != null)
                    svInitialValue = sv.InitialValue.ToString();
            }

            this.StartTransaction();

            LabelNode n = new LabelNode(lt.NodeID, lt.LabelName, lt.ObjectID, objectNode.Name, lt.StateVariableName, svInitialValue, lt.X, lt.Y);

            FontStyle fs = new FontStyle();
            if (lt.Font.Bold)
                fs = fs | FontStyle.Bold;
            if (lt.Font.Italic)
                fs = fs | FontStyle.Italic;
            if (lt.Font.Underline)
                fs = fs | FontStyle.Underline;
            if (lt.Font.Strikeout)
                fs = fs | FontStyle.Strikeout;
            n.Font = new Font(lt.Font.Name, lt.Font.Size, fs);
            n.TextColor = Color.FromArgb(lt.Font.Color);
            n.BackgroundColor = Color.FromArgb(lt.BackColor);
            n.TransparentBackground = lt.TransparentBackground;
            n.Position = new PointF(lt.X, lt.Y);
            //n.Center = new PointF(lt.X, lt.Y);

            this.Add(n);
            this.FinishTransaction("Text Node is inserted.");

            return n;
        }

        private int _DataSetNodeCounter = 1;
        public DataSetNode InsertDataSetNode(float x, float y)
        {
            this.StartTransaction();

            string nextName = "Data Set " + _DataSetNodeCounter++;
            while (FindDataSetNode(nextName) != null)
            {
                nextName = "Data Set " + _DataSetNodeCounter++;
            }

            DataSetNode node = new DataSetNode(nextName, x, y);

            this.Add(node);
            this.FinishTransaction("DataSet Node is inserted.");

            return node;
        }

        public DataSetNode InsertDataSetNode(OOMMDataSetNode lt)
        {
            this.StartTransaction();

            DataSetNode n = new DataSetNode(lt.NodeID, lt.DataSetName, lt.XAxisValue, lt.YAxisValue, lt.X, lt.Y);

            this.Add(n);
            this.FinishTransaction("DataSet Node is inserted.");

            return n;
        }

        private int _HistogramDataNodeCounter = 1;
        public HistogramDataNode InsertHistogramDataNode(float x, float y)
        {
            this.StartTransaction();

            string nextName = "Histogram Data " + _HistogramDataNodeCounter++;
            while (FindHistogramDataNode(nextName) != null)
            {
                nextName = "Histogram Data " + _HistogramDataNodeCounter++;
            }

            HistogramDataNode node = new HistogramDataNode(nextName, x, y);

            this.Add(node);
            this.FinishTransaction("Histogram Data Node is inserted.");

            return node;
        }

        public HistogramDataNode InsertHistogramDataNode(OOMMHistogramDataNode lt)
        {
            this.StartTransaction();

            HistogramDataNode n = new HistogramDataNode(lt.NodeID, lt.Name, lt.Value, lt.X, lt.Y);

            this.Add(n);
            this.FinishTransaction("Histogram Data Node is inserted.");

            return n;
        }

        private int _StatisticsNodeCounter = 1;
        public StatisticsNode InsertStatisticsNode(float x, float y)
        {
            this.StartTransaction();

            string nextName = "Statistics " + _StatisticsNodeCounter++;
            while (FindStatisticsNode(nextName) != null)
            {
                nextName = "Statistics " + _StatisticsNodeCounter++;
            }

            StatisticsNode node = new StatisticsNode(nextName, x, y);

            this.Add(node);
            this.FinishTransaction("Statistics Node is inserted.");

            return node;
        }

        public StatisticsNode InsertStatisticsNode(OOMMStatisticsNode lt)
        {
            this.StartTransaction();

            StatisticsNode n = new StatisticsNode(lt.NodeID, lt.StatisticsName, lt.Source, lt.Type, lt.Description, lt.X, lt.Y);

            this.Add(n);
            this.FinishTransaction("Statistics Node is inserted.");

            return n;
        }
        #endregion

        #region Find Methods
        private Dictionary<string, List<LabelNode>> _LabelNodes;
        private Dictionary<string, List<Tile>> _TileNodes;
        public List<LabelNode> GetLabelNodes(string eventObjectName, string stateVariableName)
        {
            List<LabelNode> rslt = new List<LabelNode>();
            if (_LabelNodes == null)
            {
                _LabelNodes = new Dictionary<string, List<LabelNode>>();
                foreach (GoObject obj in this)
                {
                    if (obj is LabelNode)
                    {
                        LabelNode ln = (LabelNode)obj;
                        string key = string.Format("{0}.{1}", ln.ObjectName, ln.StateVariableName);

                        if (_LabelNodes.ContainsKey(key))
                        {
                            List<LabelNode> elements = _LabelNodes[key];
                            elements.Add(ln);
                            _LabelNodes[key] = elements;
                        }
                        else
                        {
                            List<LabelNode> elements = new List<LabelNode>();
                            elements.Add(ln);
                            _LabelNodes.Add(key, elements);
                        }
                    }
                }
            }

            string targetKey = string.Format("{0}.{1}", eventObjectName, stateVariableName);
            if (_LabelNodes.ContainsKey(targetKey))
                rslt = _LabelNodes[targetKey];
            return rslt;
            /*
                foreach (GoObject obj in this)
                {
                    if (obj is LabelNode)
                    {
                        LabelNode ln = (LabelNode)obj;
                        if (ln.EventObjectName == eventObjectName &&
                            ln.StateVariableName == stateVariableName)
                        {
                            rslt.Add(ln);
                        }
                    }
                }
            */
        }

        public List<Tile> GetTileNodes(string objectName, string stateVariableName)
        {
            List<Tile> rslt = new List<Tile>();
            if (_TileNodes == null)
            {
                _TileNodes = new Dictionary<string, List<Tile>>();
                foreach (GoObject obj in this)
                {
                    if (obj is Tile)
                    {
                        Tile tile = (Tile)obj;
                        string key = string.Format("{0}.{1}", tile.TargetObject, tile.TargetVariable);

                        if (_TileNodes.ContainsKey(key))
                        {
                            List<Tile> elements = _TileNodes[key];
                            elements.Add(tile);
                            _TileNodes[key] = elements;
                        }
                        else
                        {
                            List<Tile> elements = new List<Tile>();
                            elements.Add(tile);
                            _TileNodes.Add(key, elements);
                        }
                    }
                }
            }

            string targetKey = string.Format("{0}.{1}", objectName, stateVariableName);
            if (_TileNodes.ContainsKey(targetKey))
                rslt = _TileNodes[targetKey];
            return rslt;
        }

        public List<LabelNode> GetLabelNodes()
        {
            List<LabelNode> rslt = new List<LabelNode>();

            foreach (GoObject obj in this)
            {
                if (obj is LabelNode)
                {
                    rslt.Add((LabelNode)obj);
                }
            }

            return rslt;
        }

        public List<BarChart> BarCharts
        {
            get
            {
                List<BarChart> rslt = new List<BarChart>();

                foreach (GoObject obj in this)
                {
                    if (obj is BarChart)
                    {
                        rslt.Add((BarChart)obj);
                    }
                }

                return rslt;
            }
        }

        public List<HorizontalBarChart> HorizontalBarCharts
        {
            get
            {
                List<HorizontalBarChart> rslt = new List<HorizontalBarChart>();

                foreach (GoObject obj in this)
                {
                    if (obj is HorizontalBarChart)
                    {
                        rslt.Add((HorizontalBarChart)obj);
                    }
                }

                return rslt;
            }
        }

        public List<StackedBarChart> StackedBarCharts
        {
            get
            {
                List<StackedBarChart> rslt = new List<StackedBarChart>();

                foreach (GoObject obj in this)
                {
                    if (obj is StackedBarChart)
                    {
                        rslt.Add((StackedBarChart)obj);
                    }
                }

                return rslt;
            }
        }

        public List<StackedHorizontalBarChart> StackedHorizontalBarCharts
        {
            get
            {
                List<StackedHorizontalBarChart> rslt = new List<StackedHorizontalBarChart>();

                foreach (GoObject obj in this)
                {
                    if (obj is StackedHorizontalBarChart)
                    {
                        rslt.Add((StackedHorizontalBarChart)obj);
                    }
                }

                return rslt;
            }
        }

        public List<BarChart> GetBarCharts()
        {
            List<BarChart> rslt = new List<BarChart>();

            foreach (GoObject obj in this)
            {
                if (obj is BarChart)
                {
                    rslt.Add((BarChart)obj);
                }
            }

            return rslt;
        }

        public List<PieChart> PieCharts
        {
            get
            {
                List<PieChart> rslt = new List<PieChart>();

                foreach (GoObject obj in this)
                {
                    if (obj is PieChart)
                    {
                        rslt.Add((PieChart)obj);
                    }
                }

                return rslt;
            }
        }

        public List<DonutChart> DonutCharts 
        {
            get
            {
                List<DonutChart> rslt = new List<DonutChart>();

                foreach (GoObject obj in this)
                {
                    if (obj is DonutChart)
                    {
                        rslt.Add((DonutChart)obj);
                    }
                }

                return rslt;
            }
        }

        public List<PieChart> GetPieCharts()
        {
            List<PieChart> rslt = new List<PieChart>();

            foreach (GoObject obj in this)
            {
                if (obj is PieChart)
                {
                    rslt.Add((PieChart)obj);
                }
            }

            return rslt;
        }

        public List<Plot> Plots
        {
            get
            {
                List<Plot> rslt = new List<Plot>();

                foreach (GoObject obj in this)
                {
                    if (obj is Plot)
                    {
                        rslt.Add((Plot)obj);
                    }
                }

                return rslt;
            }
        }

        public List<Plot> GetPlots()
        {
            List<Plot> rslt = new List<Plot>();

            foreach (GoObject obj in this)
            {
                if (obj is Plot)
                {
                    rslt.Add((Plot)obj);
                }
            }

            return rslt;
        }

        public List<TimePlot> GetTimePlots()
        {
            List<TimePlot> rslt = new List<TimePlot>();

            foreach (GoObject obj in this)
            {
                if (obj is TimePlot)
                {
                    rslt.Add((TimePlot)obj);
                }
            }

            return rslt;
        }

        public List<TimePlot> TimePlots
        {
            get
            {
                List<TimePlot> rslt = new List<TimePlot>();

                foreach (GoObject obj in this)
                {
                    if (obj is TimePlot)
                    {
                        rslt.Add((TimePlot)obj);
                    }
                }

                return rslt;
            }
        }

        public List<ScatterChart> ScatterCharts
        {
            get
            {
                List<ScatterChart> rslt = new List<ScatterChart>();

                foreach (GoObject obj in this)
                {
                    if (obj is ScatterChart)
                    {
                        rslt.Add((ScatterChart)obj);
                    }
                }

                return rslt;
            }
        }

        public List<BoxWhiskerChart> BoxWhiskerCharts
        {
            get
            {
                List<BoxWhiskerChart> rslt = new List<BoxWhiskerChart>();

                foreach (GoObject obj in this)
                {
                    if (obj is BoxWhiskerChart)
                    {
                        rslt.Add((BoxWhiskerChart)obj);
                    }
                }

                return rslt;
            }
        }

        public List<Tile> Tiles 
        {
            get
            {
                List<Tile> rslt = new List<Tile>();

                foreach (GoObject obj in this)
                {
                    if (obj is Tile)
                    {
                        rslt.Add((Tile)obj);
                    }
                }

                return rslt;
            }
        }

        public List<Histogram> Histograms
        {
            get
            {
                List<Histogram> rslt = new List<Histogram>();

                foreach (GoObject obj in this)
                {
                    if (obj is Histogram)
                    {
                        rslt.Add((Histogram)obj);
                    }
                }

                return rslt;
            }
        }

        public List<DataSetNode> DataSetNodes
        {
            get
            {
                List<DataSetNode> rslt = new List<DataSetNode>();

                foreach (GoObject obj in this)
                {
                    if (obj is DataSetNode)
                    {
                        rslt.Add((DataSetNode)obj);
                    }
                }

                return rslt;
            }
        }

        public List<DataSetNode> GetDataSetNodes()
        {
            List<DataSetNode> rslt = new List<DataSetNode>();

            foreach (GoObject obj in this)
            {
                if (obj is DataSetNode)
                {
                    rslt.Add((DataSetNode)obj);
                }
            }

            return rslt;
        }

        public List<HistogramDataNode> HistogramDataNodes
        {
            get
            {
                List<HistogramDataNode> rslt = new List<HistogramDataNode>();

                foreach (GoObject obj in this)
                {
                    if (obj is HistogramDataNode)
                    {
                        rslt.Add((HistogramDataNode)obj);
                    }
                }

                return rslt;
            }
        }

        public List<StatisticsNode> StatisticsNodes
        {
            get
            {
                List<StatisticsNode> rslt = new List<StatisticsNode>();

                foreach (GoObject obj in this)
                {
                    if (obj is StatisticsNode)
                    {
                        rslt.Add((StatisticsNode)obj);
                    }
                }

                return rslt;
            }
        }

        public List<StatisticsNode> GetStatisticsNodes()
        {
            List<StatisticsNode> rslt = new List<StatisticsNode>();

            foreach (GoObject obj in this)
            {
                if (obj is StatisticsNode)
                {
                    rslt.Add((StatisticsNode)obj);
                }
            }

            return rslt;
        }

        public LabelNode FindLabelNode(string name)
        {
            LabelNode rslt = null;
            foreach (GoObject obj in this)
            {
                if (obj is LabelNode)
                {
                    LabelNode node = (LabelNode)obj;
                    if (node.LabelName.Equals(name))
                    {
                        rslt = node;
                        break;
                    }
                }
            }
            return rslt;
        }

        public StatisticsNode FindStatisticsNode(string name)
        {
            StatisticsNode rslt = null;
            foreach (GoObject obj in this)
            {
                if (obj is StatisticsNode)
                {
                    StatisticsNode node = (StatisticsNode)obj;
                    if (node.StatisticsName.Equals(name))
                    {
                        rslt = node;
                        break;
                    }
                }
            }
            return rslt;
        }

        public DataSetNode FindDataSetNode(string name)
        {
            DataSetNode rslt = null;
            foreach (GoObject obj in this)
            {
                if (obj is DataSetNode)
                {
                    DataSetNode node = (DataSetNode)obj;
                    if (node.DataSetName.Equals(name))
                    {
                        rslt = node;
                        break;
                    }
                }
            }
            return rslt;
        }

        public HistogramDataNode FindHistogramDataNode(string name)
        {
            HistogramDataNode rslt = null;
            foreach (GoObject obj in this)
            {
                if (obj is HistogramDataNode)
                {
                    HistogramDataNode node = (HistogramDataNode)obj;
                    if (node.Name.Equals(name))
                    {
                        rslt = node;
                        break;
                    }
                }
            }
            return rslt;
        }

        public BarChart FindBarChart(string name)
        {
            BarChart rslt = null;
            foreach (GoObject obj in this)
            {
                if (obj is BarChart)
                {
                    BarChart node = (BarChart)obj;
                    if (node.ChartTitle.Equals(name))
                    {
                        rslt = node;
                        break;
                    }
                }
            }
            return rslt;
        }

        public PieChart FindPieChart(string name)
        {
            PieChart rslt = null;
            foreach (GoObject obj in this)
            {
                if (obj is PieChart)
                {
                    PieChart node = (PieChart)obj;
                    if (node.ChartTitle.Equals(name))
                    {
                        rslt = node;
                        break;
                    }
                }
            }
            return rslt;
        }

        public TimePlot FindTimePlot(string name)
        {
            TimePlot rslt = null;
            foreach (GoObject obj in this)
            {
                if (obj is TimePlot)
                {
                    TimePlot node = (TimePlot)obj;
                    if (node.ChartTitle.Equals(name))
                    {
                        rslt = node;
                        break;
                    }
                }
            }
            return rslt;
        }

        public new object FindNode(string name)
        {
            Node rslt = null;

            /*
            foreach (GoObject obj in this)
            {
                if (obj is Node)
                {
                    Node node = (Node)obj;
                    if (node.NodeName.Equals(name))
                    {
                        rslt = node;
                        break;
                    }
                }
            }
             * */
            return rslt;
        }

        public object FindNode(int id)
        {
            Node rslt = null;

            /*
            foreach (GoObject obj in this)
            {
                if (obj is Node)
                {
                    Node ll = (Node)obj;
                    if (ll.NodeID == id)
                    {
                        rslt = ll;
                        break;
                    }
                }
            }
            */
            return rslt;
        }

        public Link FindLink(int id)
        {
            Link rslt = null;
            foreach (GoObject obj in this)
            {
                if (obj is Link)
                {
                    Link l = (Link)obj;
                    if (l.LinkID == id)
                    {
                        rslt = l;
                        break;
                    }
                }
            }

            return rslt;

        }
        #endregion
    }

    public interface DiagramDocument
    {
        object FindNode(string name);
        object FindNode(int id);
    }
}