﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Northwoods.Go;
using System.Drawing;

namespace DHKANG.SEA.UI
{
    public class MultiPortNode : GoMultiTextNode
    {
        #region Member Variables
        private GoText _Header;
        private GoText _Middle;
        private GoText _Tail;
        private GoText _Blank;

        private string _NodeName;
        private string _NodeType;

        public const int AddedPort = GoObject.LastChangedHint + 1765;
        public const int RemovedPort = GoObject.LastChangedHint + 1766;

        private ArrayList _Ports = new ArrayList();
        #endregion

        #region Properties

        public ArrayList MultiPorts
        {
            get { return _Ports; }  // an unordered list of MultiPortSubGraphPorts
        }

        public string NodeName
        {
            get { return _NodeName; }
            set
            {
                _NodeName = value;
                _Header.Text = value;
            }
        }

        public string NodeType
        {
            get { return _NodeType; }
            set
            {
                _NodeType = value;
                _Tail.Text = value;
            }
        }

        private Color _BackgroundColor = Color.White;

        public Color BackgroundColor
        {
            get { return _BackgroundColor; }
            set
            {
                _BackgroundColor = value;

                this.Brush =
                    new SolidBrush(_BackgroundColor);
            }
        }

        #endregion

        #region Constructors
        public MultiPortNode()
        {
        }

        public MultiPortNode(string name, string type, float x, float y, float w, float h)
        {
            this.TopPort.Remove();
            this.BottomPort.Remove();

            _NodeName = name;
            _NodeType = type;

            this.AutoRescales = false;
            this.Reshapable = false;
            this.Resizable = false;
            this.ResizesRealtime = false;
            this.Width = w;

            //positioning
            _Header = CreateText(name, 0);
            this.LinePen = new Pen(Color.Transparent);
            this.Spacing = 0.0f;
            if (_Header != null)
            {
                _Header.FontSize =
                    ToolkitConfiguration.Diagram.NodeName.Size;
                _Header.Bold =
                    ToolkitConfiguration.Diagram.NodeName.Bold;
                _Header.BackgroundColor = _BackgroundColor;
                _Header.TextColor =
                    Color.FromName(ToolkitConfiguration.Diagram.NodeName.Color);

                _Header.Bordered = false;
                _Header.Alignment = GoText.MiddleCenter;
                _Header.Multiline = false;
                _Header.Wrapping = false;
                _Header.StringTrimming = StringTrimming.EllipsisCharacter;
                _Header.AutoRescales = false;
                _Header.AutoResizes = false;
                _Header.Reshapable = false;
                _Header.Resizable = false;
                _Header.Height = 15;
                _Header.Width = w;
                AddItem(_Header, null, null);
            }

            _Middle = CreateText("", 1);
            if (_Middle != null)
            {
                _Middle.Height = 0;
                _Middle.AutoRescales = true;
                _Middle.Resizable = true;
                _Middle.Multiline = false;
                _Middle.Bordered = false;
                _Middle.Wrapping = false;

                _Middle.Height = 4;
                _Middle.Width = w;
                AddItem(_Middle, null, null);
            }
            _Tail = CreateText("", 2);

            if (_Tail != null)
            {
                _Tail.Bold = false;
                _Tail.FontSize =
                    ToolkitConfiguration.Diagram.NodeType.Size;
                _Tail.BackgroundColor = _BackgroundColor;
                _Tail.TextColor =
                    Color.FromName(ToolkitConfiguration.Diagram.NodeType.Color);
                _Tail.Bordered = false;
                _Tail.Height = 10;
                _Tail.Multiline = false;
                _Tail.Wrapping = false;
                _Tail.AutoRescales = false;
                _Tail.Resizable = true;
                _Tail.Reshapable = false;
                _Tail.AutoResizes = false;

                _Tail.StringTrimming = StringTrimming.EllipsisCharacter;
                _Tail.Alignment = GoText.MiddleCenter;
                _Tail.Width = w;
                AddItem(_Tail, null, null);
            }
            _Blank = CreateText("", 3);
            if (_Blank != null)
            {
                _Blank.Height = 5;
                _Blank.Width = w;
                _Blank.AutoRescales = false;
                _Blank.AutoResizes = false;
                AddItem(_Blank, null, null);
            }

            _Header.WrappingWidth = 60;
            _Header.Wrapping = true;
            _Header.Text = _NodeName;
            _Tail.Text = _NodeType;


            this.Brush =
                new SolidBrush(Color.FromName(ToolkitConfiguration.Diagram.NodeColor));

            float initHeight = this.Height;
            float incrHeight = (h - initHeight) / 2;
            _Middle.Height += incrHeight;
            _Blank.Height += incrHeight;

            InitializePorts();

            RectangleF bound = new RectangleF(x, y, w, h);
            base.OnBoundsChanged(bound);

            LayoutAllPorts();
        }

        public MultiPortNode(string name, string type)
        {
            this.TopPort.Remove();
            this.BottomPort.Remove();

            _NodeName = name;
            _NodeType = type;
            this.Size = new SizeF(550, 500); //150, 250
            this.AutoRescales = false;
            this.Reshapable = false;
            this.Resizable = false;
            this.ResizesRealtime = true;
            this.Width = 50;

            //positioning
            _Header = CreateText(name, 0);
            this.LinePen = new Pen(Color.Transparent);
            this.Spacing = 0.0f;
            if (_Header != null)
            {
                _Header.FontSize =
                    ToolkitConfiguration.Diagram.NodeName.Size;
                _Header.Bold =
                    ToolkitConfiguration.Diagram.NodeName.Bold;
                _Header.BackgroundColor = _BackgroundColor;
                _Header.TextColor =
                    Color.FromName(ToolkitConfiguration.Diagram.NodeName.Color);

                _Header.Bordered = false;
                _Header.Alignment = GoText.MiddleCenter;
                _Header.Multiline = false;
                _Header.Wrapping = false;
                _Header.StringTrimming = StringTrimming.EllipsisCharacter;
                _Header.AutoRescales = true;
                _Header.AutoResizes = true;
                _Header.Reshapable = true;
                _Header.Resizable = true;
                _Header.Height = 15;
                AddItem(_Header, null, null);
            }

            _Middle = CreateText("", 1);
            if (_Middle != null)
            {
                _Middle.Height = 0;
                _Middle.AutoRescales = true;
                _Middle.Resizable = true;
                _Middle.Multiline = false;
                _Middle.Bordered = false;
                _Middle.Wrapping = false;

                _Middle.Height = 11;
                AddItem(_Middle, null, null);
            }
            _Tail = CreateText("", 2);

            if (_Tail != null)
            {
                _Tail.Bold = false;
                _Tail.FontSize =
                    ToolkitConfiguration.Diagram.NodeType.Size;
                _Tail.BackgroundColor = _BackgroundColor;
                _Tail.TextColor =
                    Color.FromName(ToolkitConfiguration.Diagram.NodeType.Color);
                _Tail.Bordered = false;
                _Tail.Height = 10;
                _Tail.Multiline = false;
                _Tail.Wrapping = false;
                _Tail.AutoRescales = true;
                _Tail.Resizable = true;
                _Tail.Reshapable = true;
                _Tail.AutoResizes = true;
                _Tail.StringTrimming = StringTrimming.EllipsisCharacter;
                _Tail.Alignment = GoText.MiddleCenter;

                AddItem(_Tail, null, null);
            }
            _Blank = CreateText("", 3);
            if (_Blank != null)
            {
                _Blank.Height = 12;
                _Blank.AutoRescales = true;
                _Blank.AutoResizes = true;
                AddItem(_Blank, null, null);
            }
            //System.Diagnostics.Debug.WriteLine("[MultiPortNode.1] height: " + this.Height + ", width: " + this.Width);

            _Header.Text = _NodeName;
            _Tail.Text = _NodeType;

            _Header.Width = 80;
            _Middle.Width = 80;
            _Tail.Width = 80;
            _Blank.Width = 80;
            this.Brush =
                new SolidBrush(Color.FromName(ToolkitConfiguration.Diagram.NodeColor));

            //System.Diagnostics.Debug.WriteLine("[MultiPortNode.2] height: " + this.Height + ", width: " + this.Width);
            InitializePorts();
            base.OnBoundsChanged(ComputeBounds());
            //System.Diagnostics.Debug.WriteLine("[MultiPortNode.3] height: " + this.Height + ", width: " + this.Width);
        }
        #endregion

        public void ApplyConfiguration(ToolkitConfiguration.DiagramConfiguration config)
        {
            _Header.FamilyName = config.NodeName.FontName;
            _Header.FontSize = config.NodeName.Size;
            _Header.Bold = config.NodeName.Bold;
            _Header.TextColor = Color.FromName(config.NodeName.Color);

            _Tail.FamilyName = config.NodeType.FontName;
            _Tail.FontSize = config.NodeType.Size;
            _Tail.Bold = config.NodeType.Bold;
            _Tail.TextColor = Color.FromName(config.NodeType.Color);
        }

        private void InitializePorts()
        {
            int myLastSpot = GoObject.MiddleLeft;

            for (int i = 0; i < 6; i++)
            {
                this.MakePort(GoObject.MiddleTop);
                this.MakePort(GoObject.MiddleBottom);
            }

            for (int i = 0; i < 5; i++)
            {
                this.MakePort(GoObject.MiddleLeft);
                this.MakePort(GoObject.MiddleRight);
            }

            HidePorts();

            LayoutAllPorts();
        }

        public override void Changed(int subhint, int oldI, object oldVal, RectangleF oldRect, int newI, object newVal, RectangleF newRect)
        {
            if (_Header != null && _Tail != null & _Middle != null && _Blank != null)
            {
                float minWidth = _Header.Width < _Tail.Width ? _Header.Width : _Tail.Width;

                if (_Middle.Width < minWidth)
                {
                    _Middle.Width = minWidth;
                }
                if (_Blank.Width < minWidth)
                {
                    _Blank.Width = minWidth;
                }
            }
            if (_Header != null)
            {
                _Header.FontSize =
                   ToolkitConfiguration.Diagram.NodeName.Size;
            }

            if (_Tail != null)
            {
                _Tail.FontSize =
                   ToolkitConfiguration.Diagram.NodeType.Size;
            }

            base.Changed(subhint, oldI, oldVal, oldRect, newI, newVal, newRect);
        }

        protected override void OnBoundsChanged(RectangleF old)
        {
            base.OnBoundsChanged(old);

            LayoutAllPorts();

            if (_Middle != null && _Blank != null)
            {
                float initHeight = old.Height;
                float incrHeight = (this.Height - initHeight) / 2;
                _Middle.Height += incrHeight;
                _Blank.Height += incrHeight;
            }
        }

        public override void OnGotSelection(GoSelection sel)
        {
            LayoutAllPorts();

            base.OnBoundsChanged(ComputeBounds());

            base.OnGotSelection(sel);

            RectangleF bound = ComputeBounds();
        }

        #region Methods
        public void ShowPorts()
        {
            Pen p = new Pen(Brushes.Black, 0.5f);
            p.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;

            int count = 0;
            foreach (MultiPortNodePort port in _Ports)
            {
                if ((count % 2) == 0)
                {
                    port.Style = GoPortStyle.Ellipse;
                }
                else
                {
                    port.Style = GoPortStyle.Rectangle;
                }

                port.Pen = p;
                port.BrushStyle = GoBrushStyle.Solid;
                port.BrushColor = Color.White;
            }

            LayoutAllPorts();
        }

        public void HidePorts()
        {
            foreach (MultiPortNodePort port in _Ports)
            {
                port.Style = GoPortStyle.None;
            }
        }

        #endregion

        #region Multiport Methods
        public IGoPort FindPort(int idx)
        {
            if (idx < _Ports.Count)
                return (IGoPort)_Ports[idx];
            else
                return null;
        }

        public IGoPort FindShortestDistancePort(int x, int y)
        {
            IGoPort rslt = null;

            float minDistance = float.MaxValue;
            IGoPort minPort = null;
            foreach(IGoPort port in _Ports)
            {
                if (port.GoObject == null)
                    continue;

                float distance = 
                    getDistance(port.GoObject.Center.X, port.GoObject.Center.Y, x, y);

                if (distance < minDistance)
                {
                    minDistance = distance;
                    minPort = port;
                }
            }

            if (minPort != null)
                rslt = minPort;

            return rslt;
        }

        private float getDistance(float x1, float y1, float x2, float y2)
        {
            float distance = 0;
            distance = (float)Math.Sqrt((x2 - x1) * (x2 - x1) * (y2 - y1) * (y2 - y1));

            return distance;
        }

        public int FindPortIndex(IGoPort port)
        {
            int rslt = 0;
            for (int i = 0; i < _Ports.Count; i++)
            {
                MultiPortNodePort p = (MultiPortNodePort)_Ports[i];
                if (p.Equals(port))
                {
                    rslt = i;
                    break;
                }

            }
            return rslt;
        }

        // create a new MultiPortSubGraphPort and add it to the MultiPorts list
        public virtual MultiPortNodePort MakePort(int spot)
        {
            MultiPortNodePort p = new MultiPortNodePort();
            p.Side = spot;
            _Ports.Add(p);
            Add(p);
            Changed(AddedPort, 0, null, NullRect, 0, p, NullRect);
            LayoutAllPorts();
            return p;
        }

        public override bool Remove(GoObject obj)
        {
            bool rslt = base.Remove(obj);

            if (_Ports.Contains(obj))
            {
                _Ports.Remove(obj);
                Changed(RemovedPort, 0, obj, NullRect, 0, null, NullRect);
                LayoutAllPorts();
            }
            return rslt;
        }

        public override void LayoutChildren(GoObject childchanged)
        {
            // implementations of LayoutChildren shouldn't do anything when Initializing is true
            if (this.Initializing) return;
            base.LayoutChildren(childchanged);
            // don't call LayoutAllPorts when the child whose bounds were changed was a port
            if (childchanged == null || !this.MultiPorts.Contains(childchanged))
                LayoutAllPorts();
        }

        public virtual void LayoutAllPorts()
        {
            if (this.MultiPorts.Count == 0) return;
            this.Initializing = false;
            // recalculate border, in case base.LayoutChildren caused changes
            // Note that ComputeInsideMarginsSkip skips all ports in its determination
            // of what to ignore when computing the border
            RectangleF rect = this.Bounds;
            //RectangleF rect = new RectangleF(this.Top, this.Left, this.Width, this.Height);
            this.Initializing = true;
            // compute corners

            float minLeft1 = _Header.Left < _Middle.Left ? _Header.Left : _Middle.Left;
            float minLeft2 = _Tail.Left < _Blank.Left ? _Tail.Left : _Blank.Left;
            float maxRight1 = _Header.Right > _Middle.Right ? _Header.Right : _Middle.Right;
            float maxRight2 = _Tail.Right > _Blank.Right ? _Tail.Right : _Blank.Right;

            float top = _Header.Top - 3 - 0.3f;
            float left = Math.Min(minLeft1, minLeft2) - 3 - 0.3f;
            float right = Math.Max(maxRight1, maxRight2) + 3 + 0.3f;
            float bottom = top + _Header.Height + _Middle.Height + _Tail.Height + _Blank.Height + 9 + 0.3f;

            //float top = _Header.Top - 3;
            //float left = _Middle.Left - 3;
            //float right = _Middle.Right + 3;
            //float bottom = top + _Header.Height + _Middle.Height + _Tail.Height + _Blank.Height + 9;

            PointF tl = new PointF(left, top);
            PointF tr = new PointF(right, top);
            PointF br = new PointF(right, bottom);
            PointF bl = new PointF(left, bottom);

            //PointF tl = new PointF(rect.X, rect.Y);
            //PointF tr = new PointF(rect.X + rect.Width, rect.Y);
            //PointF br = new PointF(rect.X + rect.Width, rect.Y + rect.Height);
            //PointF bl = new PointF(rect.X, rect.Y + rect.Height);

            /*
            RectangleF rect = ComputeBounds();// ComputeBorder();
            this.Initializing = true;
            // compute corners
            PointF tl = new PointF(rect.X, rect.Y);
            PointF tr = new PointF(rect.X + rect.Width, rect.Y);
            PointF br = new PointF(rect.X + rect.Width, rect.Y + rect.Height);
            PointF bl = new PointF(rect.X, rect.Y + rect.Height);
            */
            // now layout each set of ports between the corners
            LayoutPorts(MiddleLeft, tl, bl);
            LayoutPorts(MiddleTop, tl, tr);
            LayoutPorts(MiddleRight, tr, br);
            LayoutPorts(MiddleBottom, bl, br);
            this.Initializing = false;
        }

        private void LayoutPorts(int spot, PointF a, PointF b)
        {
            // count how many there are on a particular side (as specified by SPOT)
            int count = 0;
            foreach (MultiPortNodePort port in this.MultiPorts)
            {
                if (port.Side == spot)
                {
                    count++;
                }
            }
            // now position them evenly along that side
            float c = 1;
            foreach (MultiPortNodePort port in this.MultiPorts)
            {
                if (port.Side == spot)
                {
                    float nX = a.X + (c / (count + 1)) * (b.X - a.X);
                    float nY = a.Y + (c / (count + 1)) * (b.Y - a.Y);
                    PointF p = new PointF(nX, nY);
                    port.SetSpotLocation(spot, p);
                    c++;
                    port.Size = new SizeF(3, 3);
                }
            }
        }

        public override void ChangeValue(GoChangedEventArgs e, bool undo)
        {
            switch (e.SubHint)
            {
                case AddedPort:
                    if (undo)
                        _Ports.Remove((GoObject)e.NewValue);
                    else
                        _Ports.Add((GoObject)e.NewValue);
                    return;
                case RemovedPort:
                    if (undo)
                        _Ports.Add((GoObject)e.NewValue);
                    else
                        _Ports.Remove((GoObject)e.NewValue);
                    return;
                //case AddedChildName:
                //    if (undo)
                //case RemovedChildName:
                default:
                    base.ChangeValue(e, undo);
                    return;
            }
        }

        #endregion

        public override string GetToolTip(GoView view)
        {
            string tooltip = _NodeName + "<" + _NodeType + ">";
            if (this.UserObject != null)
            {
                if (this.UserObject is Node)
                {
                    Node n = (Node)this.UserObject;
                    if (n.ObjectType == UI.NodeType.ActivityObject)
                        tooltip += " : Activity";
                    else if (n.ObjectType == UI.NodeType.EventObject)
                        tooltip += " : Event";
                    if (n.ObjectType == UI.NodeType.StateObject)
                        tooltip += " : State";
                }
            }

            return tooltip;
        }
    }

    public class MultiPortNodePort : GoPort
    {
        public const int ChangedSide = GoObject.LastChangedHint + 2323;
        private int _Side = Middle;

        public int Side
        {
            get { return _Side; }
            set
            {
                int old = _Side;
                if (old != value && (value == MiddleLeft || value == MiddleTop || value == MiddleRight || value == MiddleBottom))
                {
                    _Side = value;
                    Changed(ChangedSide, old, null, NullRect, value, null, NullRect);
                    switch (value)
                    {
                        case MiddleLeft:
                            //this.PortObject = myLeftHexagon;
                            this.FromSpot = MiddleLeft;
                            this.ToSpot = MiddleLeft;

                            break;
                        case MiddleTop:
                            //this.PortObject = myTopHexagon;
                            this.FromSpot = MiddleTop;
                            this.ToSpot = MiddleTop;

                            break;
                        default:
                        case MiddleRight:
                            //this.PortObject = myRightHexagon;
                            this.FromSpot = MiddleRight;
                            this.ToSpot = MiddleRight;

                            break;
                        case MiddleBottom:
                            //this.PortObject = myBottomHexagon;
                            this.FromSpot = MiddleBottom;
                            this.ToSpot = MiddleBottom;
                            break;
                    }
                }
            }
        }

        public virtual bool IsInput
        {
            get { return (this.Side == GoObject.MiddleLeft || this.Side == GoObject.MiddleTop); }
        }

        public MultiPortNodePort()
            : base()
        {
            this.Width = 0.3f;
            this.Size = new SizeF(3, 3);
            this.Resizable = false;
            this.Reshapable = false;
        }

        public override bool CanLinkTo()
        {
            return true;
        }

        public override void ChangeValue(GoChangedEventArgs e, bool undo)
        {
            switch (e.SubHint)
            {
                case ChangedSide:
                    this.Side = e.GetInt(undo);
                    return;
                default:
                    base.ChangeValue(e, undo);
                    return;
            }
        }

        public override void Changing(int subhint)
        {
            base.Changing(subhint);
        }

        public override void OnGotSelection(GoSelection sel)
        {
            base.OnGotSelection(sel);
        }
    }
}
