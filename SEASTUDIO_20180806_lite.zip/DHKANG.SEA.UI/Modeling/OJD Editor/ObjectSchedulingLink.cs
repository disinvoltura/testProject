﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using Northwoods.Go;
using System.Windows.Forms;
using DHKANG.SEA.UI.OutputView;
using DHKANG.SEA.Model.OID;

namespace DHKANG.SEA.UI
{
    public class ObjectSchedulingLink : Link
    {
        #region Member Variables
        #endregion

        #region Properties
        public OOMMObjectInteractionEdge ObjectScheduleEdge
        {
            get
            {
                OOMMObjectInteractionEdge rslt =
                    new OOMMObjectInteractionEdge(
                        this.LinkID,
                        this.FromTriggerName,
                        this.FromObjectID,
                        this.FromTriggerPort,
                        this.Parameters,
                        this.ToTriggerName,
                        this.ToObjectID,
                        this.ToTriggerPort,
                        (int)this.Style);
                return rslt;
            }
        }

        public new string FromTriggerName{
            set
            {
                _FromTriggerName = value;
                ((GoText)this.FromLabel).Text = value;
            }
            get
            {
                return _FromTriggerName;
            }
        }

        public new string ToTriggerName
        {
            set
            {
                _ToTriggerName = value;
                ((GoText)this.ToLabel).Text = value;
            }
            get
            {
                return _ToTriggerName;
            }
        }

        #endregion

        #region Constructors
        public ObjectSchedulingLink(int id)
            : base(id)
        {
            GoText fromLabel = createLabel();
            this.FromLabel = fromLabel;

            GoText toLabel = createLabel();
            this.ToLabel = toLabel;

            this.AvoidsNodes = true;
            this.Brush = Brushes.Black;
            this.ToArrow = true;
            this.ToArrowFilled = true;
            this.ToArrowStyle = GoStrokeArrowheadStyle.Polygon;
            this.ToArrowWidth = 4.0f;
            this.ToArrowLength = 3.0f;
            this.ToArrowShaftLength = 2.0f;
            this.Style = GoStrokeStyle.Line;//GoStrokeStyle.Bezier;// GoStrokeStyle.Bezier;

        }

        private GoText createLabel()
        {
            GoText label = new GoText();
            label.FontSize = 8;
            label.Italic = true;
            label.Editable = false;
            label.EditableWhenSelected = false;
            label.Selectable = false;
            label.Deletable = false;            

            return label;
        }

        public ObjectSchedulingLink(int id, OOMMObjectInteractionEdge edge)
        : base(id)
        {
            this.FromTriggerName = edge.MirrorTriggerName;
            this.FromObjectID = edge.MirrorObject;
            this.FromTriggerPort = edge.MirrorPort;
            this.ToTriggerName = edge.BoundaryTriggerName;
            this.ToObjectID = edge.BoundaryObject;
            this.ToTriggerPort = edge.BoundaryPort;
            this.Parameters = edge.Parameters;
        }
        #endregion 

        #region Methods
        protected void drawLine()
        {
            this.AvoidsNodes = true;
            this.Brush = Brushes.Black;
            this.ToArrow = true;
            this.ToArrowFilled = true;
            this.ToArrowStyle = GoStrokeArrowheadStyle.Polygon;
            this.ToArrowWidth = 4.0f;
            this.ToArrowLength = 3.0f;
            this.ToArrowShaftLength = 2.0f;
            this.Style = GoStrokeStyle.Line;//GoStrokeStyle.Bezier;// GoStrokeStyle.Bezier;
            this.UserFlags = _LinkID;
            //link.Orthogonal = true;

            Pen p = new Pen(Brushes.DarkGray);
            p.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.Pen = p;

            //From Label
            GoText lblFrom = new GoText();
            lblFrom.Selectable = false;
            lblFrom.Deletable = false;
            lblFrom.Movable = false;
            lblFrom.Editable = false;
            lblFrom.Text = "";
            //lblFrom.Font = new Font(FontFamily.GenericSansSerif, ObjectInteractionView.ARCATTRIBUTE_FONTSIZE, FontStyle.Italic);
            lblFrom.TextColor = Color.Black;// GraphView.ARCATTRIBUTE_COLOR;
            lblFrom.Selectable = false;
            this.FromLabel = lblFrom;
            this.FromLabelCentered = true;

            //To Label
            GoText lblTo = new GoText();
            lblTo.Selectable = false;
            lblTo.Deletable = false;
            lblTo.Movable = false;
            lblTo.Editable = false;
            lblTo.Text = "";
            //lblTo.Font = new Font(FontFamily.GenericSansSerif, ObjectInteractionView.ARCATTRIBUTE_FONTSIZE, FontStyle.Italic);
            lblTo.TextColor = Color.Black;// GraphView.ARCATTRIBUTE_COLOR;
            this.ToLabel = lblTo;
            this.ToLabelCentered = true;
        }

        public override bool ShowDialog(bool read)
        {
            ObjectSchedulingLinkDialog dialog
                 = new ObjectSchedulingLinkDialog( 
                     this._LinkID,
                     ((ObjectNode)((MultiPortNode)this.FromNode).UserObject).NodeGuid, 
                     this.FromTriggerName,
                     this.Parameters,
                     ((ObjectNode)((MultiPortNode)this.ToNode).UserObject).NodeGuid,
                     this.ToTriggerName
                     );

            DialogResult rslt = dialog.ShowDialog();

            bool success = false;
            if (!read)
            {
                if (rslt == DialogResult.OK)
                {
                    this.FromTriggerName = dialog.FromEventName;
                    this.ToTriggerName = dialog.ToEventName;
                    this.Parameters = dialog.Parameters;

                    success = true;
                }
            }
            return success;
        }

        public override void DoResize(GoView view, RectangleF origRect, PointF newPoint,
                              int whichHandle, GoInputState evttype, SizeF min, SizeF max)
        {
            base.DoResize(view, origRect, newPoint, whichHandle, evttype, min, max);
            this.AdjustingStyle = GoLinkAdjustingStyle.Scale;
        }

        #endregion
    }
}
