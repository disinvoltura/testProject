﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using Northwoods.Go;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using DHKANG.SEA.UI.OutputView;
using DHKANG.SEA.Model.OID;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI
{
    public abstract class Link : GoLabeledLink
    {
        #region Member Variables
        protected int _LinkID;
        protected LinkType _LinkType;

        protected Guid _FromObjectID;
        protected string _FromTriggerName;
        protected int _FromPort;
        protected string _Parameters; //{P1:P2}, {P2:P3}
        protected Guid _ToObjectID;
        protected string _ToTriggerName;
        protected int _ToPort;
        protected bool _HasParameterMatch; 
        //private Dictionary<string, string> _ParameterMatch;
        #endregion

        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Properties
        public int LinkID
        {
            set { _LinkID = value; }
            get { return _LinkID; }
        }

        public LinkType LinkType
        {
            get { return _LinkType; }
        }

        public Guid ToObjectID
        {

            get { return _ToObjectID; }
            set {
                Guid oldValue = _ToObjectID;
                _ToObjectID = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "ToEventObjectID", oldValue, value);
            }
        }

        public Guid FromObjectID
        {
            get { return _FromObjectID; }
            set {
                Guid oldValue = _FromObjectID;
                _FromObjectID = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "FromEventObjectID", oldValue, value);
            }
        }

        public string FromTriggerName
        {
            get { return _FromTriggerName; }
            set {
                string oldValue = _FromTriggerName;
                _FromTriggerName = value;
                GoText fromLabel = null;
                if (this.FromLabel == null)
                    fromLabel = new GoText();
                else
                    fromLabel = (GoText)this.FromLabel;
                fromLabel.Text = _FromTriggerName;
                fromLabel.Font = new Font(ToolkitConfiguration.Diagram.SV.FontName, ToolkitConfiguration.Diagram.SV.Size, FontStyle.Italic);
                //fromLabel.Font = new Font(FontFamily.GenericSansSerif, 7, FontStyle.Italic);
                //fromLabel.TextColor = Color.DarkGray;
                fromLabel.TextColor = Color.FromName(ToolkitConfiguration.Diagram.SV.Color);
                this.FromLabel = fromLabel;
                //this.ToolTipText = _LinkName; 

                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "FromEventName", oldValue, value);
            }
        }

        public string ToTriggerName
        {
            get { return _ToTriggerName; }
            set
            {
                string oldValue = _ToTriggerName;
                _ToTriggerName = value;
                GoText toLabel = null;
                if (this.ToLabel == null)
                    toLabel = new GoText();
                else
                    toLabel = (GoText)this.ToLabel;
                toLabel.Text = _ToTriggerName;
                toLabel.Font = new Font(ToolkitConfiguration.Diagram.SV.FontName, ToolkitConfiguration.Diagram.SV.Size, FontStyle.Italic);
                //toLabel.Font = new Font(FontFamily.GenericSansSerif, 7, FontStyle.Italic);
                toLabel.TextColor = Color.FromName(ToolkitConfiguration.Diagram.SV.Color);
                this.ToLabel= toLabel;

                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "ToEventName", oldValue, value);
            }
        }

        public string Parameters
        {
            get { return _Parameters; }
            set {
                string oldValue = _Parameters;
                _Parameters = value;

                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Parameters", oldValue, value);
            }
        }

        public bool HasParameterMatch
        {
            get { return !string.IsNullOrEmpty(_Parameters); }
        }


        public int FromTriggerPort
        {
            get { return _FromPort; }
            set {
                int oldValue = _FromPort;
                _FromPort = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "FromEventPort", oldValue, value);
            }
        }

        public int ToTriggerPort
        {
            get { return _ToPort; }
            set {
                int oldValue = _ToPort;
                _ToPort = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "ToEventPort", oldValue, value);
            }
        }
        #endregion

        #region Constructors
        public Link(int id)
        {
            _LinkID = id;

            //this.ToolTipText = _LinkName;
        }
        #endregion

        public abstract bool ShowDialog(bool read);
    }

}
