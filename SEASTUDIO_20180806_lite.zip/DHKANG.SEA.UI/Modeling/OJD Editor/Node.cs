﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Northwoods.Go;
using System.Threading.Tasks;
using DHKANG.SEA.UI.OutputView;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI
{
    public abstract class Node //:  GoBasicNode //MultiPortNode
    {
        #region Member Variables
        protected int _NodeID;//for naming
        //protected Guid _NodeGuid;
        protected string _NodeName;
        protected NodeType _Type;
        protected GoNode _Presentation;
        protected Dictionary<string, string> _Properties;
        #endregion

        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Properties
        public int NodeID
        {
            get { return _NodeID; }
        }
        //public Guid NodeGuid
        //{
        //    get { return _NodeGuid; }
        //}
        public string NodeName
        {
            get { return _NodeName; }
            set {
                string oldValue = _NodeName;
                _NodeName = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Name", oldValue, value);
            }
        }
        public NodeType ObjectType
        {
            get { return _Type; }
        }
        public GoNode Presentation
        {
            get { return _Presentation; }
        }
        public System.Drawing.PointF Position
        {
            get { return _Presentation.Position; }
            set { _Presentation.Position = value; }
        }
        public abstract System.Drawing.Color BackgroundColor {get;set;}
        #endregion

        #region Constructors
        public Node(int id, string name, NodeType type)
        {
            _NodeID = id;
            _Type = type;
            _NodeName = name;
            _Properties = new Dictionary<string, string>();
        }

        #endregion

        protected void doChange(string propertyName, object oldValue, object newValue)
        {
            if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                this.PropertyChanged(this, propertyName, oldValue, newValue);
        }

        public abstract bool ShowDialog(bool read);

        public abstract int FindPortIndex(IGoPort port);
        public abstract IGoPort FindShortestDistancePort(int x, int y);
        public abstract IGoPort FindPort(int portid);

    }
}
