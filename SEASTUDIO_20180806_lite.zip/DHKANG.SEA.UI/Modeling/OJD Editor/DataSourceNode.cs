﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Northwoods.Go;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using DHKANG.SEA.UI.OutputView;
using DHKANG.SEA.Model.Data;

namespace DHKANG.SEA.UI
{
    public class DataSourceNode : GoTextNode
    {
        #region Member Variables
        private OOMMDataSource _DS;
        #endregion

        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Properties
        public OOMMDataSource DataSource
        {
            get { return _DS; }
            set {
                OOMMDataSource oldValue = _DS;
                _DS = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "DataSource", oldValue, value);
            }
        }
        #endregion

        #region Constructors
        public DataSourceNode(OOMMDataSource ds, float x, float y)
        {
            _DS = ds;
            this.Left = x;
            this.Top = y;
            this.Label.Font = new Font(
                FontFamily.GenericSansSerif, 
                12, FontStyle.Italic);
            this.Label.FontSize = 12;
            this.UpdateText();
        }
        #endregion

        #region Methods
        public int FindPortIndex(IGoPort port)
        {
            int rslt = 0;
            IGoPort [] ports = this.Ports.ToArray<IGoPort>();
            for (int i = 0; i < ports.Length; i++)
            {
                IGoPort p = ports[i];
                if (p.Equals(port))
                {
                    rslt = i;
                    break;
                }

            }
            return rslt;
        }

        public IGoPort FindPort(int idx)
        {
            IGoPort[] ports = this.Ports.ToArray<IGoPort>();

            if (idx < this.Ports.Count)
                return ports[idx];
            else
                return null;
        }

        protected override GoObject CreateBackground()
        {
            GoRoundedRectangle r = new GoRoundedRectangle();
            r.Selectable = false;
            r.PenColor = Color.Blue;
            r.BrushColor = Color.LightBlue;
            r.Shadowed = false;
            return r;
        }

        public void UpdateText()
        {
            this.Text = "   " + _DS.Name;
        }

        public void Reset()
        {
        }

        public override string GetToolTip(GoView view)
        {
            return _DS.Name;
        }

        public bool ShowDialog()
        {
            bool rslt = false;
            return rslt;
        }

        public bool ShowFontDialog()
        {
            bool rslt = false;

            FontDialog dialog = new FontDialog();
            dialog.Font = this.Label.Font;
            dialog.ShowColor = true;
            dialog.ShowEffects = true;
            dialog.Color = this.Label.TextColor;

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                this.Label.Font = dialog.Font;
                this.Label.TextColor = dialog.Color;
                rslt = true;
            }

            return rslt;
        }
        #endregion
    }
}
