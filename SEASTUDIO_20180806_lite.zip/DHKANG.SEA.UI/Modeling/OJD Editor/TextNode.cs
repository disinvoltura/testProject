﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Northwoods.Go;
using System.Drawing;
using System.Windows.Forms;
using DHKANG.SEA.UI.OutputView;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI
{
    public class TextNode : GoText
    {
        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Properties 
        public string TextValue
        {
            get { return this.Text; }
            set
            {
                string oldValue = this.Text;
                this.Text = value;

                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "TextValue", oldValue, value);
            }
        }
        #endregion

        #region Constructors
        public TextNode(string text, float x, float y)
        {
            this.Text = text;
            this.Editable = true;
            this.EditableWhenSelected = true;
            this.Font = new Font(FontFamily.GenericSansSerif, 8, FontStyle.Regular);
            this.FontSize = 8;
            this.Center = new PointF(x, y);
        }
        #endregion

        #region Methods
        public override string GetToolTip(GoView view)
        {
            return this.Text;
        }

        public bool ShowDialog()
        {
            bool rslt = false;

            FontDialog dialog = new FontDialog();
            dialog.Font = this.Font;
            dialog.ShowColor = true;
            dialog.ShowEffects = true;
            dialog.Color = this.TextColor;

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                this.Font = dialog.Font;
                this.TextColor = dialog.Color;
                rslt = true;
            }

            return rslt;
        }
        #endregion
    }
}
