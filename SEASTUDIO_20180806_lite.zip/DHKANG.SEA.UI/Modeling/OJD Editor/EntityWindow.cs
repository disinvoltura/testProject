﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using DHKANG.OOEG.Model;
using System.Text.RegularExpressions;

namespace DHKANG.OOEG.UI
{
    public delegate void EntityChangedEventHandler(OOEGEntity changedEntity);

    public partial class EntityWindow : DockContent
    {
        #region Member Variables
        private List<OOEGEntity> _Entities;
        private OOEGModelEditor _ModelEditor;
        private string[] Columns = new string[] { "Name", "Type", "Initial Value" };
        private OOEGEntity _CurrentEntity;
        #endregion

        #region Events
        public event EntityChangedEventHandler EntityChanged;
        #endregion

        #region Properties
        public OOEGModelEditor ModelEditor { set { _ModelEditor = value; } }

        public List<OOEGEntity> Entities { get { return _Entities; } }
        #endregion

        #region Constructors
        public EntityWindow()
        {
            InitializeComponent();
        }
        #endregion

        #region ToolStrip Event Handlers
        public void NewEntity()
        {
            string name = getNextEntityName();
            OOEGEntity entity = new OOEGEntity(name);
            TreeNode node = new TreeNode(name);
            node.Tag = entity;

            _Entities.Add(entity);
        }
       
        public OOEGEntity FindEntity(string name)
        {
            OOEGEntity rslt = null;
            rslt = _Entities.Find(e => e.Name.Equals(name));

            return rslt;
        } 

        public void DeleteEntity(string name)
        {
            OOEGEntity entity = FindEntity(name);

            _Entities.Remove(entity);
        }
        #endregion

        #region Methods
        private void EntityWindow_Load(object sender, EventArgs e)
        {
            drawHeader(Columns);
        }

        public void Update(OOEGEventGraphModel model)
        {
            _Entities = model.Entities;
        }

        private List<OOEGEntityAttribute> getAttributes()
        {
            List<OOEGEntityAttribute> attributes = new List<OOEGEntityAttribute>();
            if (spreadSheet.RowsCount == 0)
                return attributes;

            for(int i = 1; i < spreadSheet.RowsCount; i++)
            {
                SourceGrid.Cells.ICellVirtual[] cells = spreadSheet.GetCellsAtRow(i);
                int nullCount = 0;
                for (int p = 0; p < 4; p++)
                {
                    if (spreadSheet[i, p] == null || spreadSheet[i, p].Value == null)
                        nullCount++;
                }

                if (nullCount < 4)
                {
                    string name = spreadSheet[i, 1].DisplayText;
                    string type = spreadSheet[i, 2].DisplayText;
                    string initialValue = spreadSheet[i, 3].DisplayText;

                    OOEGEntityAttribute attr = new OOEGEntityAttribute(name, type, initialValue);
                    attributes.Add(attr);
                }
            }

            return attributes; 
        }

        private string getNextAttributeName()
        {
            string rslt = "Attribute 1";

            string expr = @"Attribute[\s]*([0-9\-]*)";

            int nextNumber = 0;

            List<OOEGEntityAttribute> attributes = getAttributes();
            foreach (OOEGEntityAttribute attr in attributes)
            {
                int number = 0;
                if (Regex.IsMatch(attr.Name, expr))
                {
                    Match m = Regex.Match(attr.Name, @"\d+");
                    if (int.TryParse(m.Value, out number))
                    {
                        if (number > nextNumber)
                            nextNumber = number;
                    }
                }
            }

            nextNumber++;
            rslt = "Attribute " + nextNumber;

            return rslt;
 
        }

        private string getNextEntityName()
        {
            string rslt = "Entity 1";

            string expr = @"Entity[\s]*([0-9\-]*)";

            int nextNumber = 0;
            foreach (OOEGEntity entity in _Entities)
            {
                int number = 0;
                if (Regex.IsMatch(entity.Name, expr))
                {
                    Match m = Regex.Match(entity.Name, @"\d+");
                    if (int.TryParse(m.Value, out number))
                    {
                        if (number > nextNumber)
                            nextNumber = number;
                    }
                }
            }

            nextNumber++;
            rslt = "Entity " + nextNumber;

            return rslt;
        }

        public void UpdateCurrentEntity()
        {
            _CurrentEntity.Name = txtName.Text;
            _CurrentEntity.Attributes = getAttributes();

            if (EntityChanged != null && EntityChanged.GetInvocationList().Length > 0)
                EntityChanged(_CurrentEntity);
        }

        public void ShowEntity(string entityName)
        {
            OOEGEntity entity = FindEntity(entityName);
            if (entity != null)
                showEntity(entity);
        }

        private void showEntity(OOEGEntity entity)
        {
            _CurrentEntity = entity;

            txtName.Text = entity.Name;
            if (spreadSheet.RowsCount > 1)
                spreadSheet.Rows.RemoveRange(1, spreadSheet.RowsCount-1);
            spreadSheet.Update();
            //spreadSheet.Rows.Clear();
            //drawHeader(Columns);

            List<string> attributes = new List<string>();
            foreach (OOEGEntityAttribute attr in entity.Attributes)
            {
                attributes.Add(attr.Name);
            }
            attributes.Sort();

            foreach (string name in attributes)
            {
                insertAttribute(entity[name]);
            }

            spreadSheet.AutoStretchColumnsToFitWidth = false;
            spreadSheet.AutoStretchRowsToFitHeight = false;
            spreadSheet.AutoSizeCells();
        }

        private void insertAttribute(OOEGEntityAttribute attr)
        {
            int rowIndex = spreadSheet.RowsCount;
            spreadSheet.Rows.Insert(rowIndex);

            CellValueChangeController cvc = new CellValueChangeController(this);

            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(attr.Name, typeof(string));
            nameCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.Editors.TextBox editorString = new SourceGrid.Cells.Editors.TextBox(typeof(string));
            nameCell.Editor = editorString;
            nameCell.AddController(cvc);

            SourceGrid.Cells.Cell valueCell = new SourceGrid.Cells.Cell(attr.InitialValue, typeof(string));
            valueCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            valueCell.AddController(cvc);

            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            cbEditor.StandardValues = new string[] { "int", "float", "double", "string" };
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;

            SourceGrid.Cells.Cell typeCell = new SourceGrid.Cells.Cell(attr.Type, cbEditor);
            typeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            typeCell.View = SourceGrid.Cells.Views.ComboBox.Default;
            typeCell.AddController(cvc);

            spreadSheet[rowIndex, 1] = nameCell;
            spreadSheet[rowIndex, 2] = typeCell;
            spreadSheet[rowIndex, 3] = valueCell;
        }

        private void OnNameCell_Changed(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("[OnNameCell changed...");
        }
        #endregion

        #region Table
        private void drawHeader(string[] columns)
        {
            spreadSheet.Rows.Clear();

            spreadSheet.BorderStyle = BorderStyle.FixedSingle;
            spreadSheet.Redim(1, columns.Length + 1);
            spreadSheet.EnableSort = false;
            spreadSheet.CustomSort = false;
            spreadSheet.FixedRows = 1;

            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            spreadSheet.Font = new Font("Calibri", 10);

            spreadSheet.Columns[0].AutoSizeMode = SourceGrid.AutoSizeMode.None;
            spreadSheet.Columns[0].Width = 25;
            SourceGrid.Cells.RowHeader l_00Header1 = new SourceGrid.Cells.RowHeader(null);
            spreadSheet[0, 0] = l_00Header1;

            for (int i = 0; i < columns.Length; i++)
            {
                SourceGrid.Cells.ColumnHeader header =
                new SourceGrid.Cells.ColumnHeader(columns[i]);
                header.View = titleModel;
                header.SortComparer = new SourceGrid.ValueCellComparer();
                spreadSheet[0, i + 1] = header;
            }
        }
        #endregion

        private void btnAdd_Click(object sender, EventArgs e)
        {
            InsertEmptyAttribute();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            int sRow = spreadSheet.Selection.ActivePosition.Row;
            if (sRow < 0 || spreadSheet[sRow, 0] == null)
                return;

            spreadSheet.Rows.Remove(sRow);
        }

        public void InsertEmptyAttribute()
        {
            int rowIndex = spreadSheet.RowsCount;
            //int rowIndex = spreadSheet.RowsCount - 1;
            spreadSheet.Rows.Insert(rowIndex);

            CellValueChangeController cvc = new CellValueChangeController(this);
            SourceGrid.Cells.RowHeader l_00Header1 = new SourceGrid.Cells.RowHeader(null);
            spreadSheet[rowIndex, 0] = l_00Header1;

            string newName = getNextAttributeName();
            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(newName, typeof(string));
            nameCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.Editors.TextBox editorString = new SourceGrid.Cells.Editors.TextBox(typeof(string));
            nameCell.Editor = editorString;
            nameCell.AddController(cvc);

            SourceGrid.Cells.Cell valueCell = new SourceGrid.Cells.Cell("0", typeof(string));
            valueCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            valueCell.AddController(cvc);

            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            cbEditor.StandardValues = new string[] { "int", "float", "double", "string" };
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;

            SourceGrid.Cells.Cell typeCell = new SourceGrid.Cells.Cell("int", cbEditor);
            typeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            typeCell.View = SourceGrid.Cells.Views.ComboBox.Default;
            typeCell.AddController(cvc);

            spreadSheet[rowIndex, 1] = nameCell;
            spreadSheet[rowIndex, 2] = typeCell;
            spreadSheet[rowIndex, 3] = valueCell;

            //nameCell.Editor.Changed += new EventHandler(OnNameCell_Changed);
            spreadSheet.AutoSizeCells();

            UpdateCurrentEntity();
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            string oldValue = _CurrentEntity.Name;
            string newValue = txtName.Text;

            _CurrentEntity.Name = newValue;

            if (EntityChanged != null && EntityChanged.GetInvocationList().Length > 0)
                EntityChanged(_CurrentEntity);
        }

    }

    public class CellValueChangeController : SourceGrid.Cells.Controllers.ControllerBase
    {
        private EntityWindow _ParentWindow;

        public CellValueChangeController(EntityWindow parent)
        {
            _ParentWindow = parent;
        }

        public override void OnValueChanged(SourceGrid.CellContext sender, EventArgs e)
        {
            base.OnValueChanged(sender, e);

            _ParentWindow.UpdateCurrentEntity();
        }
    }
}
