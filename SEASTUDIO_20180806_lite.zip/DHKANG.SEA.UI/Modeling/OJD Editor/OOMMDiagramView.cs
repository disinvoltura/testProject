﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Windows.Forms;
using Northwoods.Go;
using System.ComponentModel;
using DHKANG.SEA.UI.OutputViews;
using DHKANG.SEA.Model.OID;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.Data;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model.ActivityObjects;
using DHKANG.SEA.UI.OutputView.Visualization;

namespace DHKANG.SEA.UI
{
    public enum InsertionMode { None, Label, Text, ActivityObject, ActivityVertex, QueueVertex, EventObject, EventVertex, Schedule, SchedulingEdge, CancelingEdge, TransitionEdge, DataAssociationEdge, StateVariableUpdateEdge, Message, Parameter, EntityArc, ResourceArc, EntityQueue }
    public enum DiagramChangeType { Rename, Edit, Insert, Remove, Move }
    public delegate void DocumentScaleChangedEventHandler(double scale);
    public delegate void DiagramChangedEventHandler(DiagramChangeType type, Guid modelid, object changedObject, object oldObject);
    public class OOMMDiagramView : GoView
    {
        #region Events
        public event DocumentScaleChangedEventHandler ScaleChanged;
        public event DiagramChangedEventHandler DiagramChanged;
        public bool AutoConnect = true;
        #endregion

        #region Member Variables
        private OOMMDiagramWindow _Parent;
        private PointF myOriginalDocPosition = new PointF();
        private float myOriginalDocScale = 1.0f;
        private bool myOriginalScale = true;
        private InsertionMode _CurrentMode = InsertionMode.None;


        public static readonly float ARCATTRIBUTE_FONTSIZE = 6.0f;
        public static readonly Color ARCATTRIBUTE_COLOR = Color.Blue;
        public bool ShowLinkLength = true;
        #endregion

        #region Properties
        public InsertionMode InsertionMode
        {
            get { return _CurrentMode; }
            set { _CurrentMode = value; }
        }

        /// <summary>
        /// A convenience property for getting the view's GoDocument as a GraphDoc.
        /// </summary>
        public OOMMDiagramDocument Doc
        {
            get { return this.Document as OOMMDiagramDocument; }
        }

        #endregion

        #region Constructors
        public OOMMDiagramView(OOMMDiagramWindow parent)
            : base()
        {
            _Parent = parent;

            this.GridSnapDrag = GoViewSnapStyle.Jump;
            this.GridStyle = GoViewGridStyle.Line;
            this.GridCellSize = new SizeF(10, 10);
            this.GridLineWidth = 0.1f;
        }
        #endregion

        #region Methods
        /// <summary>
        /// A new GraphView will have a GraphDoc as its document.
        /// </summary>
        /// <returns>A <see cref="NodeLinkDiagramDocument"/></returns>
        public override GoDocument CreateDocument()
        {
            GoDocument doc = new OOMMDiagramDocument();
            doc.UndoManager = new GoUndoManager();
            return doc;
        }

        public static GoText CreateLabel(string textValue)
        {
            GoText fromLabel = new GoText();
            fromLabel.FontSize = 8;
            fromLabel.EditableWhenSelected = false;
            fromLabel.Editable = false;
            fromLabel.Text = textValue;

            return fromLabel;
        }

        public static int LastID = 0;
        public static int LinkCount = 0;
        public static Link MakeLink(InsertionMode mode)
        {
            Link rslt = null;

            if (mode == InsertionMode.SchedulingEdge)
            {
                rslt = new ObjectSchedulingLink(0);

                //rslt.FromLabel = CreateLabel("");
                //rslt.ToLabel = CreateLabel("");

                rslt.AvoidsNodes = true;
                rslt.Brush = Brushes.Black;
                rslt.ToArrow = true;
                rslt.ToArrowFilled = true;
                rslt.ToArrowStyle = GoStrokeArrowheadStyle.Polygon;
                rslt.ToArrowWidth = 4.0f;
                rslt.ToArrowLength = 3.0f;
                rslt.ToArrowShaftLength = 2.0f;
                rslt.Style = GoStrokeStyle.Line;//GoStrokeStyle.Bezier;// GoStrokeStyle.Bezier;
            }
            else if (mode == InsertionMode.DataAssociationEdge)
            {
                rslt = new DataAssociationLink(0);
            }
            else if (mode == InsertionMode.StateVariableUpdateEdge)
            {
                rslt = new StateVariableUpdateLink(0);
                rslt.FromLabel = CreateLabel("");
                rslt.ToLabel = CreateLabel("");
                rslt.AvoidsNodes = true;
                /*
                rslt.Brush = Brushes.Black;
                rslt.ToArrow = true;
                rslt.ToArrowFilled = true;
                rslt.ToArrowStyle = GoStrokeArrowheadStyle.Circle;
                rslt.ToArrowWidth = 4.0f;
                rslt.ToArrowLength = 3.0f;
                rslt.ToArrowShaftLength = 2.0f;
                rslt.Style = GoStrokeStyle.Line;//GoStrokeStyle.Bezier;// GoStrokeStyle.Bezier;
                */
            }
            return rslt;
        }

        public bool AllowLink
        {
            get
            {
                return base.AllowLink;
            }

            set
            {
                //change to straight line
                base.AllowLink = value;
                if (value)
                {
                    //GoLabeledLink link = OOEGDiagramView.MakeLink(_CurrentMode);
                    //link.ToArrowWidth = 2.0f;
                    //this.NewGoLabeledLink = link;
                    if (this.Selection.Primary is MultiPortNode)
                    {
                        GoLabeledLink link = OOMMDiagramView.MakeLink(_CurrentMode);
                        this.NewGoLabeledLink = link;
                    }
                    else if (this.Selection.Primary is DataSourceNode)
                    {
                        GoLabeledLink link = OOMMDiagramView.MakeLink(InsertionMode.DataAssociationEdge);
                        this.NewGoLabeledLink = link;
                    }
                    else
                    {
                        GoLabeledLink link = OOMMDiagramView.MakeLink(_CurrentMode);
                        this.NewGoLabeledLink = link;

                    }

                }
            }
        }

        #endregion

        #region Node Arrange methods
        //align all object's left sides to the left side of the primary selection
        public virtual void AlignLeftSides()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float X = obj.SelectionObject.Left;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Left = X;
                }
                FinishTransaction("Align Left Sides");
            }
            else
            {
                //MessageBox.Show("Alignment failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        //align all object's horizontal centers to the horizontal center of the primary selection
        public virtual void AlignHorizontalCenters()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float X = obj.SelectionObject.Center.X;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Center = new PointF(X, t.Center.Y);
                }
                FinishTransaction("Align Horizontal Centers");
            }
            else
            {
                // MessageBox.Show("Alignment failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        //align all object's right sides to the right side of the primary selection
        public virtual void AlignRightSides()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float X = obj.SelectionObject.Right;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Right = X;
                }
                FinishTransaction("Align Right Sides");
            }
            else
            {
                //MessageBox.Show("Alignment failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        //align all object's tops to the top of the primary selection
        public virtual void AlignTops()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float Y = obj.SelectionObject.Top;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Top = Y;
                }
                FinishTransaction("Align Tops");
            }
            else
            {
                // MessageBox.Show("Alignment failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        //align all object's vertical centers to the vertical center of the primary selection
        public virtual void AlignVerticalCenters()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float Y = obj.SelectionObject.Center.Y;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Center = new PointF(t.Center.X, Y);
                }
                FinishTransaction("Align Vertical Centers");
            }
            else
            {
                //MessageBox.Show("Alignment failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        //align all object's bottoms to the bottom of the primary selection
        public virtual void AlignBottoms()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float Y = obj.SelectionObject.Bottom;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Bottom = Y;
                }
                FinishTransaction("Align Bottoms");
            }
            else
            {
                //MessageBox.Show("Alignment failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        // this makes the widths of all objects equal to the width of the main selection.
        public virtual void MakeWidthsSame()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float W = obj.SelectionObject.Width;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Width = W;
                }
                FinishTransaction("Same Widths");
            }
            else
            {
                //MessageBox.Show("Sizing failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        // this makes the heights of all objects equal to the height of the main selection.
        public virtual void MakeHeightsSame()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {

                StartTransaction();
                float H = obj.SelectionObject.Height;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Height = H;
                }
                FinishTransaction("Same Heights");
            }
            else
            {
                // MessageBox.Show("Sizing failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        // this makes the heights and widths of all objects equal to the height and
        //width of the main selection.
        public virtual void MakeSizesSame()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                SizeF S = obj.SelectionObject.Size;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Size = S;
                }
                FinishTransaction("Same Sizes");
            }
            else
            {
                //MessageBox.Show("Sizing failure: Primary Selection is empty or a link instead of a node.");
            }
        }
        #endregion

        #region Zoom Control methods
        public virtual void ZoomIn()
        {
            myOriginalScale = true;
            float newscale = (float)(Math.Round(this.DocScale / 0.9f * 100) / 100);
            this.DocScale = newscale;
        }

        public virtual void ZoomOut()
        {
            myOriginalScale = true;
            float newscale = (float)(Math.Round(this.DocScale * 0.9f * 100) / 100);
            this.DocScale = newscale;
        }

        public virtual void ZoomNormal()
        {
            myOriginalScale = true;
            this.DocScale = 1;
        }

        public virtual void Zoom(float scale)
        {
            myOriginalScale = true;
            this.DocScale = scale;
        }

        public virtual void ZoomToFit()
        {
            if (myOriginalScale)
            {
                myOriginalDocPosition = this.DocPosition;
                myOriginalDocScale = this.DocScale;
                RescaleToFit();
            }
            else
            {
                this.DocPosition = myOriginalDocPosition;
                this.DocScale = myOriginalDocScale;
            }
            myOriginalScale = !myOriginalScale;
        }
        #endregion

        #region OnBackgroundSingleClicked....
        private Node doCreateEventObjectNode(GoInputEventArgs evt)
        {
            OOMMDiagramDocument doc = (OOMMDiagramDocument)this.Document;

            Node node = (Node)doc.InsertEventObjectNode(evt.DocPoint.X, evt.DocPoint.Y);
            this.Update();
            this.UpdateView();

            return node;
        }

        private TextNode doCreateTextNode(GoInputEventArgs evt)
        {
            OOMMDiagramDocument doc = (OOMMDiagramDocument)this.Document;

            TextNode node = (TextNode)doc.InsertTextNode(evt.DocPoint.X, evt.DocPoint.Y);
            node.BackgroundColor = this.BackColor;

            this.Update();
            this.UpdateView();

            return node;
        }

        private LabelNode doCreateLabelNode(GoInputEventArgs evt)
        {
            OOMMDiagramDocument doc = (OOMMDiagramDocument)this.Document;

            OOMMModel model = MainUI.App.ModelExplorer.GetProject(MainUI.App.ModelExplorer.CurrentProject);
            //MainForm.App.getCurrentEditor().BuildModel();

            LabelNodeDialog dialog = new LabelNodeDialog(model);
            DialogResult rslt = dialog.ShowDialog();

            LabelNode node = null;
            if (rslt == DialogResult.OK)
            {
                OOEGEventObjectModel eoModel = model.FindEventObjectModel(dialog.EventObjectName);
                OOEGStateVariable sv = eoModel.GetStateVariable(dialog.StateVariableName);

                node = (LabelNode)doc.InsertLabelNode(
                    eoModel.ID, eoModel.Name,
                    sv.Name, sv.InitialValue,
                    evt.DocPoint.X, evt.DocPoint.Y);
                node.BackgroundColor = this.BackColor;

                this.Update();
                this.UpdateView();
            }
            return node;
        }

        #endregion

        #region Selection Methods
        private bool _IsSelectionDeletion = false;
        protected override void OnSelectionDeleting(CancelEventArgs evt)
        {
            _IsSelectionDeletion = true;
            base.OnSelectionDeleting(evt);
        }

        protected override void OnSelectionDeleted(EventArgs evt)
        {
            base.OnSelectionDeleted(evt);

            _IsSelectionDeletion = false;

            //if (DiagramChanged != null && DiagramChanged.GetInvocationList().Length > 0)
            //    DiagramChanged();
        }

        protected override void OnObjectLostSelection(GoSelectionEventArgs evt)
        {
            if (evt.GoObject is MultiPortNode)
            {
                MultiPortNode n = (MultiPortNode)evt.GoObject;
                n.HidePorts();
            }

            base.OnObjectLostSelection(evt);

        }
        #endregion

        #region OnBackground...
        protected override void OnBackgroundDoubleClicked(GoInputEventArgs evt)
        {
            base.OnBackgroundDoubleClicked(evt);
        }

        private Node _PrimaryNode = null;
        protected override void OnMouseDown(MouseEventArgs evt)
        {
            /*
            if (this.Selection.Primary != null && this.Selection.Primary is Node)
                _PrimaryNode = (Node)this.Selection.Primary;
            */

            base.OnMouseDown(evt);
        }

        protected override void OnBackgroundSingleClicked(GoInputEventArgs evt)
        {
            base.OnBackgroundSingleClicked(evt);

            Node newNode = null;
            switch (_CurrentMode)
            {
                case UI.InsertionMode.EventObject:
                    {
                        newNode = doCreateEventObjectNode(evt); break;
                    }
                case UI.InsertionMode.Text:
                    {
                        doCreateTextNode(evt); break;
                    }
                case UI.InsertionMode.Label:
                    {
                        doCreateLabelNode(evt); break;
                    }
            }

            if (this.AutoConnect && _PrimaryNode != null && newNode != null)
            {
                Node node = _PrimaryNode;

                ObjectSchedulingLink newLink = null;

                newLink = (ObjectSchedulingLink)OOMMDiagramView.MakeLink(UI.InsertionMode.SchedulingEdge);

                //find shortest-distance port 
                IGoPort fromPort = node.FindShortestDistancePort(evt.ViewPoint.X, evt.ViewPoint.Y);
                IGoPort toPort = newNode.FindShortestDistancePort(evt.ViewPoint.X, evt.ViewPoint.Y);
                newLink.FromPort = fromPort;
                newLink.ToPort = toPort;
                //newLink.FromPort = node.Port;
                //newLink.ToPort = newNode.Port;

                //Link ID
                while (this.Doc.FindLink(OOMMDiagramView.LastID) != null)
                {
                    OOMMDiagramView.LastID++;
                }
                newLink.LinkID = OOMMDiagramView.LinkCount;
                OOMMDiagramView.LastID++;
                OOMMDiagramView.LinkCount++;

                newLink.FromLabel = CreateLabel("");
                newLink.ToLabel = CreateLabel("");

                this.Doc.LinksLayer.Add(newLink);

                //_DistanceNode.Visible = false;

                _PrimaryNode = null;
                this.Selection.Clear();
                this.Selection.Add(newNode.Presentation);
            }

        }
        #endregion

        #region Drag and Drop...
        private void createEventObjectNode(OOMMModel parentModel, OOEGEventObjectModel model, float x, float y)
        {
            StartTransaction();
            this.Selection.Clear();
            this.Selection.HotSpot = new SizeF(0, 0);

            EventObjectNode newNode = (EventObjectNode)this.Doc.InsertEventObjectNode(x, y);
            newNode.Model = model;
            newNode.NodeName = ((MultiPortNode)newNode.Presentation).NodeName;
            ((MultiPortNode)newNode.Presentation).NodeType = model.Name;

            foreach (OOEGStateVariable sv in model.StateVariables)
            {
                newNode[sv.Name] = sv.InitialValue;
            }

            this.Selection.Add(newNode.Presentation);
            FinishTransaction("Insert Event Object Node from ListView");

            //copy the dropped event object model into the parent model
            if (parentModel != null && parentModel.FindEventObjectModel(model.Name) == null)
            {
                parentModel.EventObjectModels.Add(model);
                MainUI.App.ModelExplorer.Update(parentModel);
            }
        }

        private void createStateObjectNode(OOMMModel parentModel, OOSGStateObjectModel model, float x, float y)
        {
            if (model != null)
            {
                StartTransaction();
                this.Selection.Clear();
                this.Selection.HotSpot = new SizeF(0, 0);
                StateObjectNode newNode = (StateObjectNode)this.Doc.InsertStateObjectNode(x, y);
                newNode.Model = model;
                newNode.NodeName = ((MultiPortNode)newNode.Presentation).NodeName;
                ((MultiPortNode)newNode.Presentation).NodeType = model.Name;

                foreach (OOSGStateVariable sv in model.StateVariables)
                {
                    newNode[sv.Name] = sv.InitialValue;
                }

                this.Selection.Add(newNode.Presentation);
                FinishTransaction("Insert State Object Node from ListView");

                //copy the dropped state object model into the parent model
                if (parentModel != null && parentModel.FindStateObjectModel(model.Name) == null)
                {
                    parentModel.StateObjectModels.Add(model);
                    MainUI.App.ModelExplorer.Update(parentModel);
                }
            }
        }

        private void createActivityObjectNode(OOMMModel parentModel, OOAGActivityObjectModel model, float x, float y)
        {
            StartTransaction();
            this.Selection.Clear();
            this.Selection.HotSpot = new SizeF(0, 0);
            ActivityObjectNode newNode = (ActivityObjectNode)this.Doc.InsertActivityObjectNode(x, y);
            newNode.Model = model;
            newNode.NodeName = ((MultiPortNode)newNode.Presentation).NodeName;
            ((MultiPortNode)newNode.Presentation).NodeType = model.Name;

            foreach (OOAGStateVariable sv in model.StateVariables)
            {
                newNode[sv.Name] = sv.InitialValue;
            }

            this.Selection.Add(newNode.Presentation);
            FinishTransaction("Insert Activity Object Node from ListView");

            //copy the dropped activity object model into the parent model
            if (parentModel != null && parentModel.FindActivityObjectModel(model.Name) == null)
            {
                parentModel.ActivityObjectModels.Add(model);
                MainUI.App.ModelExplorer.Update(parentModel);
            }
        }

        protected override IGoCollection DoExternalDrop(DragEventArgs evt)
        {
            IDataObject data = evt.Data;
            Object treenodeobj = data.GetData(typeof(ListViewItem));
            if (treenodeobj != null && treenodeobj is ListViewItem)
            {
                //from object model library
                ListViewItem item = (ListViewItem)treenodeobj;
                Point screenPnt = new Point(evt.X, evt.Y);
                Point viewPnt = PointToClient(screenPnt);
                PointF docPnt = ConvertViewToDoc(viewPnt);
                if (item.Tag != null)
                {
                    OOMMModel parentModel = MainUI.App.ModelExplorer.GetProject(_Parent.Model.ID);
                    if (item.Tag is OOEGEventObjectModel)
                    {
                        OOEGEventObjectModel model = item.Tag as OOEGEventObjectModel;
                        if (model != null)
                        {
                            createEventObjectNode(parentModel, model, docPnt.X, docPnt.Y);
                            return this.Selection;
                        }
                    }
                    else if (item.Tag is OOSGStateObjectModel)
                    {
                        OOSGStateObjectModel model = item.Tag as OOSGStateObjectModel;
                        if (model != null)
                        {
                            createStateObjectNode(parentModel, model, docPnt.X, docPnt.Y);
                            return this.Selection;
                        }
                    }
                    else if (item.Tag is OOAGActivityObjectModel)
                    {
                        OOAGActivityObjectModel model = item.Tag as OOAGActivityObjectModel;
                        if (model != null)
                        {
                            createActivityObjectNode(parentModel, model, docPnt.X, docPnt.Y);
                            return this.Selection;
                        }
                    }
                    else if (item.Tag is VisualElementType)
                    {
                        VisualElementType veType = (VisualElementType)item.Tag;
                        this.Selection.Clear();
                        this.Selection.HotSpot = new SizeF(0, 0);

                        this.Selection.Add(createVisualElement(veType, docPnt.X, docPnt.Y));
                        return this.Selection;
                    }
                }
            }
            else
            {
                //from model explorer
                Object tvObject = data.GetData(typeof(TreeNode));
                if (tvObject != null && tvObject is TreeNode)
                {
                    TreeNode node = (TreeNode)tvObject;
                    Point screenPnt = new Point(evt.X, evt.Y);
                    Point viewPnt = PointToClient(screenPnt);
                    PointF docPnt = ConvertViewToDoc(viewPnt);

                    if (node.Tag is OOMMDataSource)
                    {
                        OOMMDataSource ds = node.Tag as OOMMDataSource;
                        if (ds != null)
                        {
                            StartTransaction();
                            this.Selection.Clear();
                            this.Selection.HotSpot = new SizeF(0, 0);

                            DataSourceNode newNode = this.Doc.InsertDataSourceNode(ds, docPnt.X, docPnt.Y);
                            this.Selection.Add(newNode);
                            FinishTransaction("Insert from TreeView");
                            return this.Selection;
                        }
                    }
                    else if (node.Tag is OOEGEventObjectModel)
                    {
                        OOEGEventObjectModel model = node.Tag as OOEGEventObjectModel;
                        if (model != null)
                        {
                            createEventObjectNode(null, model, docPnt.X, docPnt.Y);
                            return this.Selection;
                        }
                    }
                    else if (node.Tag is OOAGActivityObjectModel)
                    {
                        OOAGActivityObjectModel model = node.Tag as OOAGActivityObjectModel;
                        if (model != null)
                        {
                            createActivityObjectNode(null, model, docPnt.X, docPnt.Y);
                            return this.Selection;
                        }
                    }
                    else if (node.Tag is OOSGStateObjectModel)
                    {
                        OOSGStateObjectModel model = node.Tag as OOSGStateObjectModel;
                        if (model != null)
                        {
                            createStateObjectNode(null, model, docPnt.X, docPnt.Y);
                            return this.Selection;
                        }
                    }
                }
            }
            return base.DoExternalDrop(evt);
        }

        private string nextTitle(string type, AbstractChart[] chartList)
        {
            string title = "";
            bool found = false;
            int nextID = 1;
            do
            {
                found = false;
                title = type + " " + nextID++;
                foreach (AbstractChart chart in chartList)
                {
                    if (chart.ChartTitle.Equals(title))
                    {
                        found = true; break;
                    }
                }
            } while (found);

            return title;
        } 

        private GoObject createVisualElement(VisualElementType type, float x, float y)
        {
            GoObject rslt = null;

            if (type == VisualElementType.BarChart)
            {
                StartTransaction();

                //set the title
                string title = nextTitle("Bar Chart", this.Doc.BarCharts.ToArray());
                rslt = this.Doc.InsertBarChart(title, x, y, BarChart.CHART_DEFAULT_WIDTH, BarChart.CHART_DEFAULT_HEIGHT);

                FinishTransaction("Insert BarChart from Output View Library");
            }
            else if (type == VisualElementType.Histogram)
            {
                StartTransaction();

                //set the title
                string title = nextTitle("Histogram", this.Doc.Histograms.ToArray());
                rslt = this.Doc.InsertHistogram(title, x, y, AbstractChart.CHART_DEFAULT_WIDTH, AbstractChart.CHART_DEFAULT_HEIGHT);

                FinishTransaction("Insert Histogram from Output View Library");
            }
            else if (type == VisualElementType.DataSet)
            {
                StartTransaction();
                rslt = this.Doc.InsertDataSetNode(x, y);
                FinishTransaction("Insert DataSet from Output View Library");
            }
            else if (type == VisualElementType.HistogramData)
            {
                StartTransaction();
                rslt = this.Doc.InsertHistogramDataNode(x, y);
                FinishTransaction("Insert Histogram Data from Output View Library");
            }
            else if (type == VisualElementType.PieChart)
            {
                StartTransaction();
                string title = nextTitle("Pie Chart", this.Doc.BarCharts.ToArray());

                rslt = this.Doc.InsertPieChart(title, x, y, PieChart.CHART_DEFAULT_WIDTH, PieChart.CHART_DEFAULT_HEIGHT);
                FinishTransaction("Insert PieChart from Output View Library");
            }
            else if (type == VisualElementType.Plot)
            {
                StartTransaction();
                string title = nextTitle("Plot", this.Doc.BarCharts.ToArray());

                rslt = this.Doc.InsertPlot(title, x, y, Plot.CHART_DEFAULT_WIDTH, Plot.CHART_DEFAULT_HEIGHT);
                FinishTransaction("Insert Plot from Output View Library");
            }
            else if (type == VisualElementType.Statistics)
            {
                StartTransaction();
                rslt = this.Doc.InsertStatisticsNode(x, y);
                FinishTransaction("Insert Statistics from Output View Library");
            }
            else if (type == VisualElementType.Text)
            {
                StartTransaction();
                rslt = this.Doc.InsertTextNode(x, y);
                ((TextNode)rslt).BackgroundColor = this.BackColor;
                FinishTransaction("Insert Text from Output View Library");
            }
            else if (type == VisualElementType.TimePlot)
            {
                StartTransaction();
                string title = nextTitle("Time Plot", this.Doc.BarCharts.ToArray());

                rslt = this.Doc.InsertTimePlot(title, x, y, TimePlot.CHART_DEFAULT_WIDTH, TimePlot.CHART_DEFAULT_HEIGHT);
                FinishTransaction("Insert TimePlot from Output View Library");
            }
            else if (type == VisualElementType.Variable)
            {
                StartTransaction();
                rslt = this.Doc.InsertLabelNode(x, y);
                ((LabelNode)rslt).BackgroundColor = this.BackColor;
                FinishTransaction("Insert Variable from Output View Library");
            }
            else if (type == VisualElementType.BoxWhisker)
            {
                StartTransaction();
                string title = nextTitle("BoxWhisker Chart", this.Doc.BoxWhiskerCharts.ToArray());
                rslt = this.Doc.InsertBoxWhiskerChart(title, x, y, AbstractChart.CHART_DEFAULT_WIDTH, AbstractChart.CHART_DEFAULT_HEIGHT);
                FinishTransaction("Insert BoxWhisker Chart from Output View Library");
            }
            else if (type == VisualElementType.ScatterChart)
            {
                StartTransaction();
                string title = nextTitle("Scatter Chart", this.Doc.ScatterCharts.ToArray());
                rslt = this.Doc.InsertScatterChart(title, x, y, AbstractChart.CHART_DEFAULT_WIDTH, AbstractChart.CHART_DEFAULT_HEIGHT);
                FinishTransaction("Insert ScatterChart from Output View Library");
            }
            else if (type == VisualElementType.HorizontalBarChart)
            {
                StartTransaction();
                string title = nextTitle("Horizontal Bar Chart", this.Doc.HorizontalBarCharts.ToArray());
                rslt = this.Doc.InsertHorizontalBarChart(title, x, y, AbstractChart.CHART_DEFAULT_WIDTH, AbstractChart.CHART_DEFAULT_HEIGHT);
                FinishTransaction("Insert HorizontalBarChart from Output View Library");
            }
            else if (type == VisualElementType.StackedBarChart)
            {
                StartTransaction();
                string title = nextTitle("Stacked Bar Chart", this.Doc.StackedBarCharts.ToArray());
                rslt = this.Doc.InsertStackedBarChart(title, x, y, AbstractChart.CHART_DEFAULT_WIDTH, AbstractChart.CHART_DEFAULT_HEIGHT);
                FinishTransaction("Insert StackedBarChart from Output View Library");
            }
            else if (type == VisualElementType.StackedHorizontalBarChart)
            {
                StartTransaction();
                string title = nextTitle("Stacked Horizontal Bar Chart", this.Doc.StackedHorizontalBarCharts.ToArray());
                rslt = this.Doc.InsertStackedHorizontalBarChart(title, x, y, AbstractChart.CHART_DEFAULT_WIDTH, AbstractChart.CHART_DEFAULT_HEIGHT);
                FinishTransaction("Insert StackedHorizontalBarChart from Output View Library");
            }
            else if (type == VisualElementType.DonutChart)
            {
                StartTransaction();
                string title = nextTitle("Donut Chart", this.Doc.DonutCharts.ToArray());
                rslt = this.Doc.InsertDonutChart(title, x, y, AbstractChart.CHART_DEFAULT_WIDTH, AbstractChart.CHART_DEFAULT_HEIGHT);
                FinishTransaction("Insert Donut Chart from Output View Library");
            }
            else if (type == VisualElementType.Tile)
            {
                StartTransaction();
                rslt = this.Doc.InsertTile(x, y, Tile.TILE_DEFAULT_WIDTH, Tile.TILE_DEFAULT_HEIGHT);
                FinishTransaction("Insert Donut Chart from Output View Library");
            }

            return rslt;
        }
        #endregion

        #region Object Clicked ...

        protected override void OnObjectSingleClicked(GoObjectEventArgs evt)
        {
            if (evt.GoObject.ParentNode is MultiPortNode)
            {
                MultiPortNode n = (MultiPortNode)evt.GoObject.ParentNode;
                n.ShowPorts();

            }
            base.OnObjectSingleClicked(evt);
        }

        protected override void OnObjectDoubleClicked(GoObjectEventArgs evt)
        {
            base.OnObjectDoubleClicked(evt);
            /*
            if (evt.GoObject.ParentNode is GoNode)
            {
                GoNode n = (GoNode)evt.GoObject.ParentNode;
                Node pn = (Node)n.UserObject;
                if (pn.ShowDialog(false))
                {
                    base.OnObjectSingleClicked(evt);

                    if (DiagramChanged != null && DiagramChanged.GetInvocationList().Length > 0)
                        DiagramChanged(DiagramChangeType.Edit, "", pn, null);
                    //base.OnObjectEdited(new GoSelectionEventArgs(n));
                }
            }
            else if (evt.GoObject.ParentNode is Link)
            {
                Link l = (Link)evt.GoObject.ParentNode;
                if (l.ShowDialog(false))
                {
                    base.OnObjectSingleClicked(evt);
                }
            }
            else if (evt.GoObject.ParentNode is LabelNode)
            {
                LabelNode n = (LabelNode)evt.GoObject.ParentNode;
                if (n.ShowDialog())
                {
                    base.OnObjectSingleClicked(evt);
                }
            }
            */

            /*
            else if (evt.GoObject.ParentNode is TextNode)
            {
                TextNode n = (TextNode)evt.GoObject.ParentNode;
                if (n.ShowDialog())
                {
                    base.OnObjectSingleClicked(evt);
                }
            }
            */
        }
        #endregion

        #region Context MenuItem Handlers
        protected override void OnObjectContextClicked(GoObjectEventArgs evt)
        {
            base.OnObjectContextClicked(evt);
            if (evt.MouseEventArgs.Button == MouseButtons.Right)
            {
                ContextMenu m = new ContextMenu();

                if (evt.GoObject is GoLink)
                {
                    MenuItem m0 = m.MenuItems.Add("Edit Properties", new EventHandler(OnEditLinkPropertiesMenuItemClicked));
                    m.MenuItems.Add("-");
                    MenuItem m1 = m.MenuItems.Add("Straight Line", new EventHandler(OnStraightLineMenuItemClicked));
                    MenuItem m2 = m.MenuItems.Add("Broken Line", new EventHandler(OnBrokenLineMenuItemClicked));
                    MenuItem m3 = m.MenuItems.Add("Curved Line", new EventHandler(OnCurvedLineMenuItemClicked));
                    //MenuItem m4 = m.MenuItems.Add("-");

                    //m3.Checked = true;
                    m.Tag = evt.GoObject;
                }
                else if (evt.GoObject.ParentNode is MultiPortNode)
                {
                    MultiPortNode gNode = (MultiPortNode)evt.GoObject.ParentNode;

                    ObjectNode objectNode = (ObjectNode)gNode.UserObject;
                    MenuItem m1 = null;
                    if (objectNode.ObjectType == NodeType.EventObject)
                        m1 = m.MenuItems.Add("Edit Event Transition Table", new EventHandler(OnEditEventTransitionTableMenuItemClicked));
                    else if (objectNode.ObjectType == NodeType.StateObject)
                        m1 = m.MenuItems.Add("Edit State Transition Table", new EventHandler(OnEditStateTransitionTableMenuItemClicked));
                    else if (objectNode.ObjectType == NodeType.ActivityObject)
                        m1 = m.MenuItems.Add("Edit Activity Transition Table", new EventHandler(OnEditStateTransitionTableMenuItemClicked));
                    MenuItem m2 = m.MenuItems.Add("Rename", new EventHandler(OnRenameMenuItemClicked));

                    if (objectNode.ObjectType == NodeType.EventObject)
                    {
                        OOEGEventObjectModel eoModel = ((EventObjectNode)objectNode).Model;
                        if (eoModel.StateVariables.Count > 0)
                        {
                            m.MenuItems.Add("-");
                            MenuItem m3 = m.MenuItems.Add("Add Label of");
                            List<string> svNameList = new List<string>();
                            Dictionary<string, OOEGStateVariable> svlist = new Dictionary<string, OOEGStateVariable>();
                            foreach (OOEGStateVariable sv in eoModel.StateVariables)
                            {
                                svlist.Add(sv.Name, sv);
                                svNameList.Add(sv.Name);
                            }
                            svNameList.Sort();
                            foreach (string svName in svNameList)
                            {
                                OOEGStateVariable sv = svlist[svName];
                                MenuItem m5 = m3.MenuItems.Add(svName + ": " + sv.ValueType, new EventHandler(OnAddLabelMenuItemClicked));
                                m5.Tag = sv;
                            }
                            m3.Tag = objectNode;// evt.GoObject.ParentNode;
                        }
                    }
                    else if (objectNode.ObjectType == NodeType.StateObject)
                    {
                        OOSGStateObjectModel soModel = ((StateObjectNode)objectNode).Model;
                        if (soModel.StateVariables.Count > 0)
                        {
                            m.MenuItems.Add("-");
                            MenuItem m3 = m.MenuItems.Add("Add Label of");
                            List<string> svNameList = new List<string>();
                            Dictionary<string, OOSGStateVariable> svlist = new Dictionary<string, OOSGStateVariable>();
                            foreach (OOSGStateVariable sv in soModel.StateVariables)
                            {
                                svlist.Add(sv.Name, sv);
                                svNameList.Add(sv.Name);
                            }
                            svNameList.Sort();
                            foreach (string svName in svNameList)
                            {
                                OOSGStateVariable sv = svlist[svName];
                                MenuItem m5 = m3.MenuItems.Add(svName + ": " + sv.Type, new EventHandler(OnAddLabelMenuItemClicked));
                                m5.Tag = sv;
                            }
                            m3.Tag = objectNode;// evt.GoObject.ParentNode;
                        }
                    }
                    else if (objectNode.ObjectType == NodeType.ActivityObject)
                    {
                        OOAGActivityObjectModel aoModel = ((ActivityObjectNode)objectNode).Model;
                        if (aoModel.StateVariables.Count > 0)
                        {
                            m.MenuItems.Add("-");
                            MenuItem m3 = m.MenuItems.Add("Add Label of");
                            List<string> svNameList = new List<string>();
                            Dictionary<string, OOAGStateVariable> svlist = new Dictionary<string, OOAGStateVariable>();
                            foreach (OOAGStateVariable sv in aoModel.StateVariables)
                            {
                                svlist.Add(sv.Name, sv);
                                svNameList.Add(sv.Name);
                            }
                            svNameList.Sort();
                            foreach (string svName in svNameList)
                            {
                                OOAGStateVariable sv = svlist[svName];
                                MenuItem m5 = m3.MenuItems.Add(svName + ": " + sv.ValueType, new EventHandler(OnAddLabelMenuItemClicked));
                                m5.Tag = sv;
                            }
                            m3.Tag = objectNode;// evt.GoObject.ParentNode;
                        }
                    }
                    m.MenuItems.Add("-");
                    MenuItem m4 = m.MenuItems.Add("View Code", new EventHandler(OnViewCodeMenuItemClicked));
                    m.Tag = evt.GoObject.ParentNode;
                }
                else if (evt.GoObject.ParentNode is LabelNode)
                {
                    MenuItem m0 = m.MenuItems.Add("Edit Label", new EventHandler(OnEditLabelPropertiesMenuItemClicked));
                    MenuItem m1 = m.MenuItems.Add("Font", new EventHandler(OnEditFontPropertiesMenuItemClicked));
                    m.Tag = evt.GoObject.ParentNode;
                    m1.Tag = evt.GoObject.ParentNode;
                }
                else if (evt.GoObject.ParentNode is TextNode)
                {
                    MenuItem m0 = m.MenuItems.Add("Font", new EventHandler(OnEditFontPropertiesMenuItemClicked));
                    m.Tag = evt.GoObject.ParentNode;
                    m0.Tag = evt.GoObject.ParentNode;
                }

                if (m.MenuItems.Count > 0)
                    m.MenuItems.Add("-");

                MenuItem mCut = m.MenuItems.Add("Cu&t", new EventHandler(OnCutMenuItemClicked));
                MenuItem mCopy = m.MenuItems.Add("&Copy", new EventHandler(OnCopyMenuItemClicked));
                MenuItem mPaste = m.MenuItems.Add("&Paste", new EventHandler(OnPasteMenuItemClicked));
                MenuItem mDel = m.MenuItems.Add("&Delete", new EventHandler(OnDeleteMenuItemClicked));

                m.Show(this, evt.ViewPoint);
            }
        }

        private void OnEditLabelPropertiesMenuItemClicked(object obj, EventArgs args)
        {
            MenuItem item = (MenuItem)obj;
            LabelNode node = (LabelNode)item.Tag;

            OOMMModel model = MainUI.App.ModelExplorer.GetProject(MainUI.App.ModelExplorer.CurrentProject);
            //MainForm.App.getCurrentEditor().BuildModel();
            LabelNodeDialog dialog = new LabelNodeDialog(model, node);
            DialogResult rslt = dialog.ShowDialog();

            if (rslt == DialogResult.OK)
            {
                OOEGEventObjectModel eoModel = model.FindEventObjectModel(dialog.EventObjectName);
                OOEGStateVariable sv = eoModel.GetStateVariable(dialog.StateVariableName);

                node.ObjectID = eoModel.ID;
                node.ObjectName = eoModel.Name;
                node.StateVariableName = sv.Name;
                node.InitialValue = sv.InitialValue;

                this.Update();
                this.UpdateView();
            }
        }

        private void OnEditFontPropertiesMenuItemClicked(object obj, EventArgs args)
        {
            MenuItem item = (MenuItem)obj;

            if (item.Tag is TextNode)
            {
                TextNode txtNode = (TextNode)item.Tag;
                txtNode.ShowDialog();
            }
            else if (item.Tag is LabelNode)
            {
                LabelNode labelNode = (LabelNode)item.Tag;
                labelNode.ShowFontDialog();
            }
        }

        private void OnAddLabelMenuItemClicked(object obj, EventArgs args)
        {
            MenuItem item = (MenuItem)obj;
            MultiPortNode gNode = (MultiPortNode)item.Parent.Tag;
            ObjectNode node = (ObjectNode)gNode.UserObject;

            string svName = "";
            string svValue = "";
            string modelName = "";
            Guid modelID = Guid.Empty;
            if (item.Tag is OOEGStateVariable)
            {
                modelID = ((EventObjectNode)node).Model.ID;
                modelName = ((EventObjectNode)node).Model.Name;
                svName = ((OOEGStateVariable)item.Tag).Name;
                svValue = ((OOEGStateVariable)item.Tag).InitialValue;
            }
            else if (item.Tag is OOSGStateVariable)
            {
                modelID = ((StateObjectNode)node).Model.ID;
                modelName = ((StateObjectNode)node).Model.Name;
                svName = ((OOSGStateVariable)item.Tag).Name;
                svValue = ((OOSGStateVariable)item.Tag).InitialValue.ToString();
            }
            else if (item.Tag is OOAGStateVariable)
            {
                modelID = ((ActivityObjectNode)node).Model.ID;
                modelName = ((ActivityObjectNode)node).Model.Name;
                svName = ((OOAGStateVariable)item.Tag).Name;
                svValue = ((OOAGStateVariable)item.Tag).InitialValue.ToString();
            }
            OOMMDiagramDocument doc = (OOMMDiagramDocument)this.Document;
            OOMMModel model = MainUI.App.ModelExplorer.GetProject(MainUI.App.ModelExplorer.CurrentProject);

            LabelNode lblNode = doc.InsertLabelNode(
                    modelID, modelName,
                    svName, svValue,
                    node.Position.X, node.Position.Y + 80);
            lblNode.BackgroundColor = this.BackColor;

            this.Update();
            this.UpdateView();
        }

        private void OnRenameMenuItemClicked(object obj, EventArgs args)
        {
            MenuItem item = (MenuItem)obj;
            MultiPortNode gNode = (MultiPortNode)item.Parent.Tag;
            ObjectNode objectNode = (ObjectNode)gNode.UserObject;

            ObjectNodeDialog dialog = new ObjectNodeDialog(objectNode.NodeName);
            DialogResult rslt = dialog.ShowDialog(this);
            if (rslt == DialogResult.OK)
            {
                string oldName = objectNode.NodeName;
                objectNode.NodeName = dialog.ObjectNodeName;
                ((MultiPortNode)objectNode.Presentation).NodeName = dialog.ObjectNodeName;

                if (DiagramChanged != null && DiagramChanged.GetInvocationList().Length > 0)
                    DiagramChanged(DiagramChangeType.Rename, _Parent.Model.ID, dialog.ObjectNodeName, oldName);
            }
        }

        private void OnEditEventTransitionTableMenuItemClicked(object obj, EventArgs args)
        {
            MenuItem item = (MenuItem)obj;
            string projectName = _Parent.Model.Name;
            MultiPortNode gNode = (MultiPortNode)item.Parent.Tag;
            EventObjectNode node = (EventObjectNode)gNode.UserObject;

            OOEGEventObjectModel eoModel = MainUI.App.ModelExplorer.OpenEventTransitionTableEditor(_Parent.Model.ID, node.Model.ID);
            if (eoModel != null)
                node.Model = eoModel;
        }

        private void OnEditStateTransitionTableMenuItemClicked(object obj, EventArgs args)
        {
            MenuItem item = (MenuItem)obj;
            string projectName = _Parent.Model.Name;
            MultiPortNode gNode = (MultiPortNode)item.Parent.Tag;
            StateObjectNode node = (StateObjectNode)gNode.UserObject;

            OOSGStateObjectModel soModel = MainUI.App.ModelExplorer.OpenStateTransitionTableEditor(_Parent.Model.ID, node.Model.ID);
            if (soModel != null)
                node.Model = soModel;
        }

        private void OnViewCodeMenuItemClicked(object obj, EventArgs args)
        {
            MenuItem item = (MenuItem)obj;
            MultiPortNode gNode = (MultiPortNode)item.Parent.Tag;
            EventObjectNode node = (EventObjectNode)gNode.UserObject;

            OOMMModel model = new OOMMModel();
            //model.EventObjectModels.Add(node.Model);

            foreach (GoObject goobj in this.Doc)
            {
                if (goobj is GoNode)
                {
                    GoNode tNode = (GoNode)goobj;
                    EventObjectNode eoNode = (EventObjectNode)tNode.UserObject;
                    model.EventObjectModels.Add(eoNode.Model);
                }
            }

            foreach (Link n in node.Presentation.DestinationLinks)
            {
                OOMMObjectInteractionEdge link =
                    new OOMMObjectInteractionEdge();

                if (n.LinkType == LinkType.SchedulingLink)
                {
                    ObjectSchedulingLink osl = (ObjectSchedulingLink)n;

                    link.ID = osl.LinkID;
                    link.MirrorObject = ((EventObjectNode)((MultiPortNode)osl.FromNode).UserObject).NodeGuid;
                    //link.MirrorEventObject = ((EventObjectNode)osl.FromNode).NodeGuid;
                    //link.MirrorEventObject = osl.FromEventObjectID;
                    link.MirrorTriggerName = osl.FromTriggerName;
                    link.BoundaryObject = ((EventObjectNode)((MultiPortNode)osl.ToNode).UserObject).NodeGuid;
                    //link.BoundaryEventObject = ((EventObjectNode)osl.ToNode).NodeGuid;
                    //link.BoundaryEventObject = osl.ToEventObjectID;
                    link.BoundaryTriggerName = osl.ToTriggerName;
                }
                model.EventObjectSchedulingEdges.Add(link);
            }

            D_Code dialog = new D_Code(node.Model.Name, model);
            dialog.ShowDialog(this.Parent);

        }
        private void OnEditLinkPropertiesMenuItemClicked(object obj, EventArgs args)
        {
            MenuItem item = (MenuItem)obj;

            GoLink originalLink = (GoLink)item.Parent.Tag;

            ObjectSchedulingLink link = null;
            if (originalLink.AbstractLink is ObjectSchedulingLink)
                link = (ObjectSchedulingLink)originalLink.AbstractLink;

            //ObjectSchedulingLink link = (ObjectSchedulingLink)((GoLink)item.Parent.Tag).AbstractLink;

            if (link != null)
                link.ShowDialog(false);

        }

        private void OnDeleteMenuItemClicked(object obj, EventArgs args)
        {
            MenuItem item = (MenuItem)obj;
            GoObject goobj = (GoObject)item.Parent.Tag;

            goobj.Remove();
        }

        private void OnCutMenuItemClicked(object obj, EventArgs args)
        {
            //Node 만 복사 지원하고 복사된 노드 간의 연결관계는 유지한다
        }

        private void OnCopyMenuItemClicked(object obj, EventArgs args)
        {
        }

        private void OnPasteMenuItemClicked(object obj, EventArgs args)
        {

        }

        private void OnStraightLineMenuItemClicked(object obj, EventArgs args)
        {
            MenuItem m = (MenuItem)obj;

            if (m.Parent.Tag is GoLabeledLink)
            {
                GoLabeledLink link = (GoLabeledLink)m.Parent.Tag;
                link.Style = GoStrokeStyle.Line;
                link.Orthogonal = false;
                link.CalculateStroke();
            }
            else if (m.Parent.Tag is GoLink)
            {
                GoLink link = (GoLink)m.Parent.Tag;
                link.Style = GoStrokeStyle.Line;
                link.Orthogonal = false;
                link.CalculateStroke();
            }
        }

        protected override void OnPropertyChanged(PropertyChangedEventArgs evt)
        {
            base.OnPropertyChanged(evt);
            if (evt.PropertyName == "DocScale")
            {
                if (ScaleChanged != null && ScaleChanged.GetInvocationList().Length > 0)
                    ScaleChanged(this.DocScale);
            }
        }

        private void OnBrokenLineMenuItemClicked(object obj, EventArgs args)
        {
            MenuItem m = (MenuItem)obj;

            if (m.Parent.Tag is GoLabeledLink)
            {
                GoLabeledLink link = (GoLabeledLink)m.Parent.Tag;
                link.Style = GoStrokeStyle.RoundedLine;
                link.Orthogonal = true;
            }
            else if (m.Parent.Tag is GoLink)
            {
                GoLink link = (GoLink)m.Parent.Tag;
                link.Style = GoStrokeStyle.RoundedLine;
                link.Orthogonal = true;
            }
        }

        private void OnCurvedLineMenuItemClicked(object obj, EventArgs args)
        {
            MenuItem m = (MenuItem)obj;

            if (m.Parent.Tag is GoLabeledLink)
            {
                GoLabeledLink link = (GoLabeledLink)m.Parent.Tag;
                link.Style = GoStrokeStyle.Bezier;
            }
            else if (m.Parent.Tag is GoLink)
            {
                GoLink link = (GoLink)m.Parent.Tag;
                link.Style = GoStrokeStyle.Bezier;
            }
        }

        #endregion

        #region Object Visibility
        public void setGrid(GoViewGridStyle ggstyle)
        {
            this.GridStyle = ggstyle;
            this.Grid.LineColor = Color.DarkGray;
            this.GridCellSize = new SizeF((float)20, (float)20);
            //this.GridPenDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.Grid.LineWidth = (float).25;
            this.GridSnapDrag = GoViewSnapStyle.After;
        }

        #endregion

        #region Highliht Methods


        #endregion

        #region FindObject Methods
        public MultiPortNode FindNode(string nodeName)
        {
            MultiPortNode rslt = null;

            foreach (GoObject obj in this.Doc)
            {
                if (obj is MultiPortNode)
                {
                    MultiPortNode node = (MultiPortNode)obj;
                    if (node.Text == nodeName)
                    {
                        rslt = node;
                        break;
                    }
                }
            }

            return rslt;
        }

        public Node FindNode(int nodeID)
        {
            Node rslt = null;

            /*
            foreach (GoObject obj in this.Doc)
            {
                if (obj is Node)
                {
                    Node node = (Node)obj;
                    if (node.NodeID == nodeID)
                    {
                        rslt = node;
                        break;
                    }
                }
            }
            */
            return rslt;
        }

        public ObjectSchedulingLink FindLink(int linkID)
        {
            ObjectSchedulingLink rslt = null;
            foreach (GoObject obj in this.Doc)
            {
                if (obj is ObjectSchedulingLink)
                {
                    ObjectSchedulingLink link = (ObjectSchedulingLink)obj;
                    if (link.LinkID == linkID)
                    {
                        rslt = link;
                        break;
                    }
                }
            }
            return rslt;
        }

        #endregion

        #region Key Methods
        private Keys _LastTimeDowned = Keys.None;
        private int _PasteTimes = 0;
        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Z && _LastTimeDowned == Keys.ControlKey)
                return;

            base.OnKeyDown(e);

            if (e.KeyCode == Keys.OemMinus || e.KeyCode == Keys.Add)
            {
                if (_LastTimeDowned == Keys.ControlKey)
                    ZoomIn();
            }
            else if (e.KeyCode == Keys.Oemplus || e.KeyCode == Keys.Subtract)
            {
                if (_LastTimeDowned == Keys.ControlKey)
                    ZoomOut();
            }
            else if (e.KeyCode == Keys.C)
            {
                if (_LastTimeDowned == Keys.ControlKey)
                {
                    CopySelection();

                    _LastTimeDowned = Keys.None;
                    _PasteTimes = 0;
                }
            }
            else if (e.KeyCode == Keys.V)
            {
                if (_LastTimeDowned == Keys.ControlKey)
                {
                    PasteSelection();

                    _LastTimeDowned = Keys.None;
                    _PasteTimes++;
                }
            }
            else
            {
                _LastTimeDowned = e.KeyCode;
            }
        }

        private GoObject[] _CopiedObjects;
        private void CopySelection()
        {
            _CopiedObjects = this.Selection.CopyArray();
        }

        private int _BarChartCounter = 1;
        private int _PieChartCounter = 1;
        private int _TimePlotCounter = 1;

        private void PasteSelection()
        {
            if (_CopiedObjects == null || _CopiedObjects.Length == 0)
                return;

            this.Selection.Clear();

            int discX = 30, discY = 30;

            foreach (GoObject obj in _CopiedObjects)
            {
                if (obj is MultiPortNode)
                {
                    MultiPortNode node = (MultiPortNode)obj;
                    EventObjectNode oldNode = (EventObjectNode)node.UserObject;
                    EventObjectNode newNode = (EventObjectNode)this.Doc.InsertEventObjectNode(node.Left + discX, node.Top + discY);
                    newNode.Model = oldNode.Model;
                    newNode.NodeName = node.NodeName;
                    newNode.BackgroundColor = node.BackgroundColor;
                    ((MultiPortNode)newNode.Presentation).NodeName = newNode.NodeName;
                    ((MultiPortNode)newNode.Presentation).NodeType = newNode.Model.Name;
                    newNode.Position = new PointF(node.Left + discX, node.Top + discY);

                    this.Selection.Add(newNode.Presentation);
                }
                else if (obj is TextNode)
                {
                    TextNode node = (TextNode)obj;
                    TextNode newNode = this.Doc.InsertTextNode(node.Left + discX, node.Top + discY);
                    newNode.Text = node.Text;

                    FontStyle fs = new FontStyle();
                    if (node.Font.Bold)
                        fs = fs | FontStyle.Bold;
                    if (node.Font.Italic)
                        fs = fs | FontStyle.Italic;
                    if (node.Font.Underline)
                        fs = fs | FontStyle.Underline;
                    if (node.Font.Strikeout)
                        fs = fs | FontStyle.Strikeout;

                    newNode.Font = new Font(node.Font.Name, node.Font.Size, fs);
                    newNode.TextColor = node.TextColor;
                    newNode.BackgroundColor = node.BackgroundColor;
                    newNode.TransparentBackground = node.TransparentBackground;
                    newNode.Position = new PointF(node.Left + discX, node.Top + discY);
                    this.Selection.Add(newNode);
                }
                else if (obj is LabelNode)
                {
                    LabelNode node = (LabelNode)obj;
                    LabelNode newNode = this.Doc.InsertLabelNode(node.Left + discX, node.Top + discY);
                    newNode.BackgroundColor = this.BackColor;
                    //newNode.LabelName = node.LabelName;
                    newNode.ObjectID = node.ObjectID;
                    newNode.ObjectName = node.ObjectName;
                    newNode.StateVariableName = node.StateVariableName;
                    newNode.InitialValue = node.InitialValue;

                    FontStyle fs = new FontStyle();
                    if (node.Font.Bold)
                        fs = fs | FontStyle.Bold;
                    if (node.Font.Italic)
                        fs = fs | FontStyle.Italic;
                    if (node.Font.Underline)
                        fs = fs | FontStyle.Underline;
                    if (node.Font.Strikeout)
                        fs = fs | FontStyle.Strikeout;

                    newNode.Font = new Font(node.Font.Name, node.Font.Size, fs);
                    newNode.TextColor = node.TextColor;
                    newNode.BackgroundColor = node.BackgroundColor;
                    newNode.TransparentBackground = node.TransparentBackground;
                    newNode.Position = new PointF(node.Left + discX, node.Top + discY);
                    this.Selection.Add(newNode);
                }
                else if (obj is StatisticsNode)
                {
                    StatisticsNode node = (StatisticsNode)obj;
                    StatisticsNode newNode = this.Doc.InsertStatisticsNode(node.Left + discX, node.Top + discY);

                    newNode.StatisticsName = node.StatisticsName;
                    newNode.Source = node.Source;
                    newNode.Type = node.Type;
                    newNode.Description = node.Description;
                    newNode.Position = new PointF(node.Left + discX, node.Top + discY);

                    this.Selection.Add(newNode);
                }
                else if (obj is DataSetNode)
                {
                    DataSetNode node = (DataSetNode)obj;
                    DataSetNode newNode = this.Doc.InsertDataSetNode(node.Left + discX, node.Top + discY);

                    newNode.DataSetName = node.DataSetName;
                    newNode.XAxsisValue = node.XAxsisValue;
                    newNode.YAxisValue = node.YAxisValue;
                    newNode.Position = new PointF(node.Left + discX, node.Top + discY);

                    this.Selection.Add(newNode);
                }
                else if (obj is DataSourceNode)
                {
                    DataSourceNode node = (DataSourceNode)obj;
                    DataSourceNode newNode = this.Doc.InsertDataSourceNode(node.DataSource, node.Left + discX, node.Top + discY);
                    newNode.Position = new PointF(node.Left + discX, node.Top + discY);

                    this.Selection.Add(newNode);
                }
                else if (obj is BarChart)
                {
                    BarChart node = null;
                    if (obj is BarChart)
                        node = (BarChart)obj;

                    string nextName = "Bar Chart " + _BarChartCounter++;
                    while (this.Doc.FindBarChart(nextName) != null)
                    {
                        nextName = "Bar Chart " + _BarChartCounter++;
                    }

                    BarChart newNode = this.Doc.InsertBarChart(nextName, node.Left + discX, node.Top + discY, node.Width, node.Height);

                    foreach (string seriesName in node.Series.SeriesNames)
                    {
                        Series s = node.Series[seriesName];
                        Series newSeries = new Series(s.Name, s.LineColor, s.MarkerColor, s.BackgroundColor, s.Value, s.LineWidth, s.MarkerType);
                        newSeries.ChartType = s.ChartType;
                        newSeries.ShowMarker = s.ShowMarker;
                        newSeries.ShowValue = s.ShowValue;

                        newNode.AddSeries(newSeries);
                    }

                    newNode.BackgroundColor = node.BackgroundColor;
                    newNode.BorderColor = node.BorderColor;
                    newNode.BorderWeight = node.BorderWeight;
                    newNode.Position = new PointF(node.Left + discX, node.Top + discY);

                    this.Selection.Add(newNode);
                }
                else if (obj is PieChart)
                {
                    PieChart node = null;
                    if (obj is PieChart)
                        node = (PieChart)obj;

                    string nextName = "Pie Chart " + _PieChartCounter++;
                    while (this.Doc.FindPieChart(nextName) != null)
                    {
                        nextName = "Pie Chart " + _PieChartCounter++;
                    }

                    PieChart newNode = this.Doc.InsertPieChart(nextName, node.Left + discX, node.Top + discY, node.Width, node.Height);

                    foreach (string seriesName in node.Series.SeriesNames)
                    {
                        Series s = node.Series[seriesName];
                        Series newSeries = new Series(s.Name, s.LineColor, s.MarkerColor, s.BackgroundColor, s.Value, s.LineWidth, s.MarkerType);
                        newSeries.ChartType = s.ChartType;
                        newSeries.ShowMarker = s.ShowMarker;
                        newSeries.ShowValue = s.ShowValue;

                        newNode.AddSeries(newSeries);
                    }

                    newNode.BackgroundColor = node.BackgroundColor;
                    newNode.BorderColor = node.BorderColor;
                    newNode.BorderWeight = node.BorderWeight;
                    newNode.Position = new PointF(node.Left + discX, node.Top + discY);

                    this.Selection.Add(newNode);
                }
                else if (obj is TimePlot)
                {
                    TimePlot node = null;
                    if (obj is TimePlot)
                        node = (TimePlot)obj;

                    string nextName = "Time Plot " + _TimePlotCounter++;
                    while (this.Doc.FindTimePlot(nextName) != null)
                    {
                        nextName = "Time Plot " + _TimePlotCounter++;
                    }

                    TimePlot newNode = this.Doc.InsertTimePlot(nextName, node.Left + discX, node.Top + discY, node.Width, node.Height);

                    foreach (string seriesName in node.Series.SeriesNames)
                    {
                        Series s = node.Series[seriesName];
                        Series newSeries = new Series(s.Name, s.LineColor, s.MarkerColor, s.BackgroundColor, s.Value, s.LineWidth, s.MarkerType);
                        newSeries.ChartType = s.ChartType;
                        newSeries.ShowMarker = s.ShowMarker;
                        newSeries.ShowValue = s.ShowValue;

                        newNode.AddSeries(newSeries);
                    }

                    newNode.BackgroundColor = node.BackgroundColor;
                    newNode.BorderColor = node.BorderColor;
                    newNode.BorderWeight = node.BorderWeight;
                    newNode.Position = new PointF(node.Left + discX, node.Top + discY);

                    this.Selection.Add(newNode);
                }
            }
        }
        #endregion
    }
}
