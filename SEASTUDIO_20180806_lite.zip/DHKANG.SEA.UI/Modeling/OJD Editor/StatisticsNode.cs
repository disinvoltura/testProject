﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Northwoods.Go;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using DHKANG.Foundation.DataCollection;
using DHKANG.SEA.UI.OutputView;
using DHKANG.SEA.Model.OID.Data;

namespace DHKANG.SEA.UI
{
    public class StatisticsNode : GoSimpleNode // GoText 
    {
        private static int ICON_WIDTH = 20;
        private static int ICON_HEIGHT = 20;

        #region Member Variables
        private Guid _NodeID;
        private string _Name;
        private string _Source;
        private string _Description;
        private StatisticsType _Type = StatisticsType.Tally;
        private Statistics _Statistics;
        #endregion

        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Properties
        public string StatisticsName
        {
            get { return _Name; }
            set
            {
                string oldValue = _Name;
                _Name = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "StatisticsName", oldValue, value);
            }
        }

        public Guid NodeID
        {
            get { return _NodeID; }
            set
            {
                Guid oldValue = _NodeID;
                _NodeID = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "NodeID", oldValue, value);
            }
        }

        public string Source
        {
            get { return _Source; }
            set
            {
                string oldValue = _Source;
                _Source = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Source", oldValue, value);
            }
        }

        public StatisticsType Type
        {
            get { return _Type; }
            set
            {
                StatisticsType oldValue = _Type;
                _Type = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Type", oldValue, value);
            }
        }

        public string Description
        {
            get { return _Description; }
            set
            {
                string oldValue = _Description;
                _Description = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Description", oldValue, value);
            }
        }

        public Statistics Statistics
        {
            get { return _Statistics; }
            set { _Statistics = value; }
        }
        #endregion

        #region Constructors
        public StatisticsNode(string name, float x, float y)
        {
            _NodeID = Guid.NewGuid();
            _Name = name;

            initialize(x, y);
        }

        public StatisticsNode(Guid nodeid, string name, string source, StatisticsType type, string description, float x, float y)
        {
            _NodeID = nodeid;
            _Name = name;
            _Source = source;
            _Type = type;
            _Description = description;

            if (type == StatisticsType.Counter)
            {
                _Statistics = new CounterStatistics(name);
            }
            else if (type == StatisticsType.Tally)
            {
                _Statistics = new SampleStatistics(name);
            }
            else if (type == StatisticsType.TimeDependent)
            {
                _Statistics = new TimeDependentStatistics(name);
            }

            initialize(x, y);
        }

        private void initialize(float x, float y)
        {
            this.Initialize(null, null, _Name);
            this.Figure = GoFigure.DiskStorage;
            //this.Image.Name = “special.gif”
            this.Icon.Size = new SizeF(ICON_WIDTH, ICON_HEIGHT);
            this.Icon.Resizable = false;
            this.Shape.FillShapeGradient(Color.CornflowerBlue);
            this.Orientation = Orientation.Vertical;
            this.InPort.Visible = false;
            this.OutPort.Visible = false;
            this.Editable = false;
            this.Left = x;
            this.Top = y;

            this.UpdateText();
        }
        #endregion

        #region Methods
        public void UpdateText()
        {
            this.Label.Text = "   " + _Name;
        }

        public void UpdateValue()
        {
            if (_Type == StatisticsType.Counter)
            {
                this.Label.Text = "   " + _Statistics.Count.ToString();
            }
            else if (_Type == StatisticsType.Tally)
            {
                this.Label.Text = "   " + ((SampleStatistics)_Statistics).Mean.ToString();
            }
            else if (_Type == StatisticsType.TimeDependent)
            {
                this.Label.Text = "   " + ((TimeDependentStatistics)_Statistics).Mean.ToString();
            }
        }

        public void Reset()
        {
            this.Label.Text = "   " + _Name;
            //this.Text = _Name;
        }

        public override string GetToolTip(GoView view)
        {
            string tooltip = _Name;
            if (_Statistics != null)
            {
                if (_Statistics.Count > 0)
                {
                    if (_Type == StatisticsType.Counter)
                    {
                        tooltip += "\r\n";
                        tooltip += " Count: " + ((CounterStatistics)_Statistics).Count;
                    }
                    else if (_Type == StatisticsType.Tally)
                    {
                        tooltip += "\r\n";
                        tooltip += " Mean: " + ((SampleStatistics)_Statistics).Mean + "\r\n";
                        tooltip += " Minimum: " + ((SampleStatistics)_Statistics).Minimum + "\r\n";
                        tooltip += " Maximum: " + ((SampleStatistics)_Statistics).Maximum + "\r\n";
                        tooltip += " S/D: " + ((SampleStatistics)_Statistics).StandarDeviation;
                    }
                    else if (_Type == StatisticsType.TimeDependent)
                    {
                        tooltip += "\r\n";
                        tooltip += " Mean: " + ((TimeDependentStatistics)_Statistics).Mean + "\r\n";
                        tooltip += " Minimum: " + ((TimeDependentStatistics)_Statistics).Minimum + "\r\n";
                        tooltip += " Maximum: " + ((TimeDependentStatistics)_Statistics).Maximum + "\r\n";
                        tooltip += " S/D: " + ((TimeDependentStatistics)_Statistics).StandarDeviation;
                    }
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(_Description))
                    tooltip += " : " + _Description;
            }
            return tooltip;
        }

        /*
        public bool ShowDialog()
        {
            bool rslt = false;

            OOEGEventGraphModel model = MainForm.App.getCurrentEditor().BuildModel();
            LabelNodeDialog dialog = new LabelNodeDialog(model, this);
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                OOEGEventObjectModel eoModel = model.FindEventObjectModel(dialog.EventObjectName);
                OOEGStateVariable sv = eoModel.GetStateVariable(dialog.StateVariableName);

                this.EventObjectID = eoModel.ID;
                this.EventObjectName = eoModel.Name;
                this.StateVariableName = sv.Name;
                this.InitialValue = sv.InitialValue;
                rslt = true;
            }
            return rslt;
        }

        public bool ShowFontDialog()
        {
            bool rslt = false;

            FontDialog dialog = new FontDialog();
            dialog.Font = this.Font;
            dialog.ShowColor = true;
            dialog.ShowEffects = true;
            dialog.Color = this.TextColor;

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                this.Font = dialog.Font;
                this.TextColor = dialog.Color;
                rslt = true;
            }

            return rslt;
        }
        */
        #endregion
    }
}
