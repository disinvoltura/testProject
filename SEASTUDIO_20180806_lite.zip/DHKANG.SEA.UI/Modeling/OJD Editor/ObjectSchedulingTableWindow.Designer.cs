﻿namespace DHKANG.SEA.UI
{
    partial class ObjectSchedulingTableWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.spreadSheet = new SourceGrid.Grid();
            this.SuspendLayout();
            // 
            // spreadSheet
            // 
            this.spreadSheet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spreadSheet.EnableSort = true;
            this.spreadSheet.Location = new System.Drawing.Point(0, 0);
            this.spreadSheet.Name = "spreadSheet";
            this.spreadSheet.OptimizeMode = SourceGrid.CellOptimizeMode.ForRows;
            this.spreadSheet.SelectionMode = SourceGrid.GridSelectionMode.Cell;
            this.spreadSheet.Size = new System.Drawing.Size(544, 278);
            this.spreadSheet.TabIndex = 0;
            this.spreadSheet.TabStop = true;
            this.spreadSheet.ToolTipText = "";
            // 
            // SpreadsheetWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(544, 278);
            this.Controls.Add(this.spreadSheet);
            this.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "SpreadsheetWindow";
            this.ShowIcon = false;
            this.Text = "Spreadsheet Window";
            this.ResumeLayout(false);

        }

        #endregion

        private SourceGrid.Grid spreadSheet;
    }
}