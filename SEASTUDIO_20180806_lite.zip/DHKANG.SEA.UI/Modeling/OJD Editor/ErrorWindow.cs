﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using DHKANG.SEA.UI.SyntaxCheck;
using DHKANG.SEA.Model;
using SourceGrid.Cells.Controllers;

namespace DHKANG.SEA.UI
{
    public partial class ErrorWindow : DockContent
    {
        private MainUI _Parent;
        private RowSelectedEvent _RowSelectedController;
        private ModelChecker _Checker;
        private DataTable _ErrorTable;
        private List<CheckPointMessage> _ErrorList;
        private int[] _ColWidthRatios;

        #region Properties
        /*
        public OOEGModelEditor Editor
        {
            set { _Editor = value; }
        }
        */

        public DataTable Errors
        {
            get { return _ErrorTable; }
        }
        #endregion

        #region Constructors
        public ErrorWindow(MainUI parent)
        {
            _Parent = parent;
            InitializeComponent();

            _RowSelectedController = new RowSelectedEvent(_Parent);
            grid.Controller.AddController(_RowSelectedController);
            _Checker = new ModelChecker();

            _ErrorList = new List<CheckPointMessage>();
            //CheckSyntax(_Editor.BuildModel());


            _ColWidthRatios = new int[] { 10, 70, 10, 10 };

        }
        #endregion

        #region Methods
        public void Clear()
        {
            _ErrorTable = getEmptyTable();
            _ErrorList = new List<CheckPointMessage>();
            
            grid.DataSource = new DevAge.ComponentModel.BoundDataView(_ErrorTable.DefaultView);
        }

        private DataTable getEmptyTable()
        {
            DataTable emptyTable = new DataTable();
            emptyTable.Columns.Add("Type");
            emptyTable.Columns.Add("Description");
            emptyTable.Columns.Add("Target");
            emptyTable.Columns.Add("Scope");

            return emptyTable;
        }


        public bool CheckSyntax(List<OOMMModel> projectList)
        {
            bool rslt = false;
            this.Clear();

            _ErrorList = new List<CheckPointMessage>();
            foreach (OOMMModel project in projectList)
            {
                if (_Checker.Check(project))
                {
                    rslt = true;
                }

                _ErrorList.AddRange(_Checker.Errors);
            }

            _ErrorTable = getEmptyTable();
            string lastDesc = string.Empty;
            foreach (CheckPointMessage msg in _ErrorList)
            {
                if (lastDesc.Equals(msg.Description))
                    continue;
                DataRow row = _ErrorTable.Rows.Add(new string[] { msg.Type.ToString(), msg.Description, msg.Target, msg.Scope });
                lastDesc = msg.Description;
            }

            Update(_ErrorTable.DefaultView);

            return rslt;
        }


        private DataTable getErrorTable(List<CheckPointMessage> msgList)
        {
            DataTable dt = getEmptyTable();
            string lastDesc = string.Empty;
            foreach (CheckPointMessage msg in msgList)
            {
                if (lastDesc.Equals(msg.Description))
                    continue;
                DataRow row = dt.Rows.Add(new string[] { msg.Type.ToString(), msg.Description, msg.Target, msg.Scope });
                lastDesc = msg.Description;
            }

            return dt;
        }

        private void Update(DataView view)
        {
            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            grid.DataSource = new DevAge.ComponentModel.BoundDataView(view);
            //grid.Controller.AddController(valueChangedController);

            
            for (int i = 0; i < grid.Columns.Count; i++)
            {
                grid.Columns[i].HeaderCell.View = titleModel;
                grid.Columns[i].MinimalWidth = (grid.Columns[i].PropertyName.Length + 5) * (int)grid.Font.Size;
                //grid.Columns[i].AutoSizeMode = SourceGrid.AutoSizeMode.

                grid.Columns[i].DataCell.Editor.EditableMode = SourceGrid.EditableMode.None;
                grid.Columns[i].Width = (int)((float)this.Width * ((float)_ColWidthRatios[i] / 100.0f));
            }

            for(int i = 1; i < grid.Rows.Count; i++) {
            }

            grid.MinimumHeight = 20;
            //grid.AutoStretchColumnsToFitWidth = true;
            //grid.AutoSizeCells();

            int errors = 0;
            _ErrorList.ForEach(delegate (CheckPointMessage m)
            {
                if (m.Type == CheckPointType.Error)
                    errors++;
            });
            if (errors > 0)
                this.Text = "Error List (" + errors + ")";
            else
                this.Text = "Error List";
        }
        
        public bool CheckSyntax(OOMMModel model)
        {
            bool rslt = _Checker.Check(model);

            _ErrorList.RemoveAll(e => e.Scope.Equals(model.Name));
            _ErrorList.AddRange(_Checker.Errors);

            _ErrorTable = getErrorTable(_ErrorList);
            Update(_ErrorTable.DefaultView);

            return rslt;
            /*
            if (_ErrorTable != null)
            {
                List<DataRow> rows = new List<DataRow>();
                foreach (DataRow dr in _ErrorTable.Rows)
                {
                    string scope = (string)dr[3];
                    if (scope.Equals(model.Name))
                    {
                        rows.Add(dr);
                    }
                }
                rows.ForEach(r => _ErrorTable.Rows.Remove(r));
            }

            if (_ErrorTable == null)
            {
                _ErrorTable = _Checker.Errors;
            }
            else { 
                _ErrorTable.Rows.Add(_Checker.Errors);
            }
            //Update(_Checker.Errors.DefaultView);
            Update(_ErrorTable.DefaultView);
            return rslt;
            */
        }

        

        /*
        private List<ListViewItem> doCheckSyntax(UTSModel model)
        {
            bool flag = true;//error가 하나라도 있으면 false
            int idx = 1;

            List<ListViewItem> msgItems = new List<ListViewItem>();

            ModelChecker checker =
                new ModelChecker();

            List<CheckPointMessage> msglist = checker.Run(model);

            foreach (CheckPointMessage msg in msglist)
            {
                if (msg.Type == CheckPointType.Error)
                    flag = false;

                ListViewItem item = new ListViewItem(idx.ToString());
                item.SubItems.Add(msg.Scope);
                item.SubItems.Add(msg.Target);
                item.SubItems.Add(msg.Type.ToString());
                item.SubItems.Add(msg.Description);
                msgItems.Add(item);
                idx++;
            }

            return msgItems;
        }
        */
        #endregion
    }

    public class RowSelectedEvent : SourceGrid.Cells.Controllers.ControllerBase
    {
        private MainUI _Parent;
        public RowSelectedEvent(MainUI parent)
        {
            _Parent = parent;
        }

        public override void OnDoubleClick(SourceGrid.CellContext sender, EventArgs e)
        {
            base.OnDoubleClick(sender, e);

            SourceGrid.DataGrid grid = (SourceGrid.DataGrid)sender.Grid;

            if (grid.SelectedDataRows.Count() > 0)
            {
                DataRowView drView = (DataRowView)grid.SelectedDataRows[0];

                string target = drView[2].ToString();
                string scope = drView[3].ToString();

                string[] targetList = target.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
                int id = 0;
                /* Commented out for future implementation
                if (int.TryParse(targetList[0], out id))
                    _Parent.GoToi(scope, id);
            
                 */
            }
        }
    }
}
