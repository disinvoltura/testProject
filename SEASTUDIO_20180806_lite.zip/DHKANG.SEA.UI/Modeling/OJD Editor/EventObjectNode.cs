﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using Northwoods.Go;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.UI.OutputView;
using DHKANG.SEA.UI.ETTEditor;

namespace DHKANG.SEA.UI
{
    public class EventObjectNode : ObjectNode
    {
        #region Member Variables
        private OOEGEventObjectModel _Model;
        #endregion
      
        #region Properties
        public OOEGEventObjectModel Model { 
            get {
                _Model.X = this.Presentation.Position.X;
                _Model.Y = this.Presentation.Position.Y;
                _Model.BackgroundColor = this.BackgroundColor.ToArgb();

                return _Model; }
            set { _Model = value; }
        }
        #endregion

        #region Constructors
        public EventObjectNode(int id, string name)
            : base(id, name, NodeType.EventObject)
        {
        }

        public EventObjectNode(int id, string name, OOEGEventObjectModel model)
            : base(id, name, NodeType.EventObject)
        {
            _Model = model;
        }

        public EventObjectNode(int id, Guid guid, string name, OOEGEventObjectModel model)
            : base(id, guid, name, NodeType.EventObject)
        {
            _Model = model;
        }
        #endregion

        #region Methods
        public override bool ShowDialog(bool read)
        {
            EventObjectModelEditor editor =
                new EventObjectModelEditor(this, _Model);

            DialogResult rslt = editor.ShowDialog(MainUI.App);
            if (rslt == DialogResult.OK)
            {
                _Model = editor.EventObjectModel;
            }

            return true;
        }
        #endregion
        
        
    }
}
