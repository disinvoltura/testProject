﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using Northwoods.Go;
using System.Windows.Forms;
using DHKANG.SEA.Model.OID;

namespace DHKANG.SEA.UI
{
    public class StateVariableUpdateLink: Link
    {
        #region Member Variables
        private OOMMStateVariableUpdateEdge _Edge;
        #endregion
        
        #region Properties
        public OOMMStateVariableUpdateEdge StateVariableUpdateEdge
        {
            get
            {
                OOMMStateVariableUpdateEdge rslt =
                      new OOMMStateVariableUpdateEdge(
                          this.LinkID,
                          this.FromTriggerName,
                          this.FromObjectID,
                          this.FromTriggerPort,
                          this.ToTriggerName,
                          this.ToObjectID,
                          this.ToTriggerPort,
                          (int)this.Style);
                return rslt;
            }
            set
            {
                _Edge = value;
            }
        }
        #endregion

        #region Constructors
        public StateVariableUpdateLink(int id)
            : base(id)
        {
            _LinkType = LinkType.StateVariableUpdateLink;
            drawLine();
        }

        public StateVariableUpdateLink(int id, OOMMStateVariableUpdateEdge edge)
        : base(id)
        {
            _LinkType = LinkType.StateVariableUpdateLink;

            _Edge = edge;

            this.FromTriggerName = edge.SourceStateVariable;
            this.FromObjectID = edge.SourceEventObject;
            this.FromTriggerPort = edge.SourceEventPort;
            this.ToTriggerName = edge.DestinationStateVariable;
            this.ToObjectID = edge.DestinationEventObject;
            this.ToTriggerPort = edge.DestinationEventPort;

            drawLine();
        }
        #endregion  

        #region Methods
        protected void drawLine()
        {
            this.AvoidsNodes = true;
            this.Brush = Brushes.DarkGray;

            Pen p = new Pen(Brushes.DarkGray);
            p.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.Pen = p;

            //To Arrow
            this.ToArrow = true;
            this.ToArrowFilled = true;
            this.ToArrowStyle = GoStrokeArrowheadStyle.Polygon;
            this.ToArrowWidth = 4.0f;
            this.ToArrowLength = 3.0f;
            this.ToArrowShaftLength = 2.0f;

            //From Arrow
            this.FromArrow = true;
            this.FromArrowFilled = true;
            this.FromArrowStyle = GoStrokeArrowheadStyle.Circle;
            this.FromArrowWidth = 7.0f;
            this.FromArrowLength = 7.0f;
            this.FromArrowShaftLength = 7.0f;

            this.Style = GoStrokeStyle.Line;//GoStrokeStyle.Bezier;// GoStrokeStyle.Bezier;
            this.UserFlags = _LinkID;
            //link.Orthogonal = true;

            //From Label
            GoText lblFrom = new GoText();
            lblFrom.Selectable = false;
            lblFrom.Editable = false;
            lblFrom.Text = "";
            lblFrom.Font = new Font(FontFamily.GenericSansSerif, 8, FontStyle.Italic);
            //lblFrom.Font = new Font(FontFamily.GenericSansSerif, ObjectInteractionView.ARCATTRIBUTE_FONTSIZE, FontStyle.Italic);
            lblFrom.TextColor = Color.Black;// GraphView.ARCATTRIBUTE_COLOR;

            this.FromLabel = lblFrom;
            this.FromLabelCentered = false;

            //To Label
            GoText lblTo = new GoText();
            lblTo.Selectable = false;
            lblTo.Editable = false;
            lblTo.Text = "";
            lblTo.Font = new Font(FontFamily.GenericSansSerif, 8, FontStyle.Italic);
            //lblTo.Font = new Font(FontFamily.GenericSansSerif, ObjectInteractionView.ARCATTRIBUTE_FONTSIZE, FontStyle.Italic);
            lblTo.TextColor = Color.Black;// GraphView.ARCATTRIBUTE_COLOR;
            this.ToLabel = lblTo;
            this.ToLabelCentered = false;
        }

        public override bool ShowDialog(bool read)
        {
            return true;
        }

        public override void DoResize(GoView view, RectangleF origRect, PointF newPoint,
                              int whichHandle, GoInputState evttype, SizeF min, SizeF max)
        {
            base.DoResize(view, origRect, newPoint, whichHandle, evttype, min, max);
            this.AdjustingStyle = GoLinkAdjustingStyle.Scale;
        }
        #endregion
    }
}
