﻿using System.Drawing;
using System.Windows.Forms;
using DHKANG.SEA.UI.OutputView;
using Opulos.Core.UI;
using DHKANG.SEA.Model;
using System;
using DHKANG.SEA.UI.Modeling.Properties.DataCollection;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public class StatisticsProperties: AbstractDataCollectionProperties
    {
        //private StatisticsNode _Node;
        //private OOMMModel _Model;

        private StatisticsPropertiesSection section0;
        private DescriptionPropertiesSection section1;

        //public event PropertyValueChangedEventHandler PropertyValueChanged;

        public StatisticsProperties() : base()
        {
            section0 = new StatisticsPropertiesSection();
            section0.PropertyValueChanged += notifyPropertyChange;
            addCollapsiblePanel(section0, "Statistics");

            section1 = new DescriptionPropertiesSection();
            section1.PropertyValueChanged += notifyPropertyChange;
            addCollapsiblePanel(section1, "Description");
            //UserControl panel1 = new UserControl { Margin = Padding.Empty, Padding = Padding.Empty, Dock = DockStyle.Fill };
        }

        //private void OnPropertyValueChanged(Guid modelId, object changedObject, string propertyName, object oldValue, object newValue)
        //{
        //    if (this.PropertyValueChanged != null && this.PropertyValueChanged.GetInvocationList().Length> 0)
        //        this.PropertyValueChanged(modelId, changedObject, propertyName, oldValue, newValue);
        //}

        //public void Update(OOMMModel model, StatisticsNode node)
        //{
        //    _Model = model;
        //    _Node = node;

        //    showProperties();
        //}

        private bool isUpdating = false;
        protected override void showProperties()
        {
            //_Model = MainUI.App.ModelExplorer.GetProject(MainUI.App.ModelExplorer.CurrentProject);
            //MainForm.App.getCurrentEditor().BuildModel();

            isUpdating = true;

            section0.Update(_Model, _Node as StatisticsNode);
            section1.Update(_Model, _Node as StatisticsNode);

            isUpdating = false;
        }
 
    }
}
