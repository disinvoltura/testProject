﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using Northwoods.Go;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public delegate void PropertyValueChangedEventHandler(Guid modelId, object changedObject, string propertyName, object oldValue, object newValue);
    public partial class DataSetPropertiesSection: UserControl
    {
        private OOMMModel _Model;
        private DataSetNode _Node;

        public event PropertyValueChangedEventHandler PropertyValueChanged;

        public DataSetPropertiesSection()
        {
            InitializeComponent();
        }

        public void Update(OOMMModel model, DataSetNode node)
        {
            _Model = model;
            _Node = node;

            showProperties();
        }

        private bool isUpdating = false;
        private void showProperties()
        {
            //_Model = MainUI.App.ModelExplorer.GetProject(MainUI.App.ModelExplorer.CurrentProject);
            //MainForm.App.getCurrentEditor().BuildModel();

            isUpdating = true;

            txtName.Text = _Node.DataSetName;
            txtXAxisValue.Text = _Node.XAxsisValue;
            txtYAxisValue.Text = _Node.YAxisValue;

            isUpdating = false;
        }

        private void btnChoose1_Click(object sender, EventArgs e)
        {
            if (_Model == null)
                return;

            ExpressionBuilder dialog = null;
            if (string.IsNullOrEmpty(txtXAxisValue.Text))
                dialog = new ExpressionBuilder(_Model);
            else
                dialog = new ExpressionBuilder(_Model, txtXAxisValue.Text);

            DialogResult rslt = dialog.ShowDialog(this);
            if (rslt == DialogResult.OK)
            {
                string oldValue = _Node.XAxsisValue;
                _Node.XAxsisValue = dialog.Expression;
                //_Node.XAxsisValue = dialog.EventObjectName + "." + dialog.StateVariableName;
                txtXAxisValue.Text = _Node.XAxsisValue;

                if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                    PropertyValueChanged(_Model.ID, _Node, "XAxisValue", oldValue, dialog.Expression);
            }
        }

        private void btnChoose2_Click(object sender, EventArgs e)
        {
            if (_Model == null)
                return;

            ExpressionBuilder dialog = null;
            if (string.IsNullOrEmpty(txtYAxisValue.Text))
                dialog = new ExpressionBuilder(_Model);
            else
                dialog = new ExpressionBuilder(_Model, txtYAxisValue.Text);

            DialogResult rslt = dialog.ShowDialog(this);
            if (rslt == DialogResult.OK)
            {
                string oldValue = _Node.YAxisValue;
                _Node.YAxisValue = dialog.Expression;
                //_Node.YAxisValue = dialog.EventObjectName + "." + dialog.StateVariableName;
                txtYAxisValue.Text = _Node.YAxisValue;

                if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                    PropertyValueChanged(_Model.ID, _Node, "YAxisValue", oldValue, dialog.Expression);
            }
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
                handleNameChanged();
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            handleNameChanged();
        }

        private void handleNameChanged()
        {
            if (string.IsNullOrEmpty(txtName.Text))
                return;

            string oldValue = _Node.DataSetName;
            _Node.DataSetName = txtName.Text;
            _Node.UpdateText();

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Node, "Name", oldValue, txtName.Text);
        }
    }
}
