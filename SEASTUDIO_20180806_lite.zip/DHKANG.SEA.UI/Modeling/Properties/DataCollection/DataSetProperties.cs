﻿using System.Drawing;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using DHKANG.SEA.UI.OutputView;
using Opulos.Core.UI;
using System;
using DHKANG.SEA.UI.Modeling.Properties.DataCollection;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public class DataSetProperties: AbstractDataCollectionProperties
    {
        #region Member Variables
        //private DataSetNode _DataSetNode;
        //private OOMMModel _Model;

        private DataSetPropertiesSection _Section0;
        private DescriptionPropertiesSection _Section1;

        private bool isUpdating = false;
        #endregion

        //#region Events
        //public event PropertyValueChangedEventHandler PropertyValueChanged;
        //#endregion

        #region Constructors
        public DataSetProperties()
            : base()
        {
            _Section0 = new DataSetPropertiesSection();
            addCollapsiblePanel(_Section0, "Data Set");
            _Section0.PropertyValueChanged += notifyPropertyChange;

            _Section1 = new DescriptionPropertiesSection();
            _Section1.PropertyValueChanged += notifyPropertyChange;
            addCollapsiblePanel(_Section1, "Description");

            /*
            AppearancePropertiesSection section1 = new AppearancePropertiesSection();
            section1.Dock = DockStyle.Fill;
            section1.Padding = Padding.Empty;
            section1.Margin = Padding.Empty;
            acc.Add(section1, "Appearance", "Appearance", 0, true);
            */

            //UserControl panel1 = new UserControl { Margin = Padding.Empty, Padding = Padding.Empty, Dock = DockStyle.Fill };
        }

        //private void OnPropertyValueChanged(Guid modelId, object changedObject, string propertyName, object oldValue, object newValue)
        //{
        //    if (this.PropertyValueChanged != null && this.PropertyValueChanged.GetInvocationList().Length > 0)
        //        this.PropertyValueChanged(modelId, changedObject, propertyName, oldValue, newValue); 
        //}
        #endregion

        #region Methods
        //public void Update(OOMMModel model, DataSetNode ds)
        //{
        //    _Model = model;
        //    _DataSetNode = ds;

        //    isUpdating = true;
        //    showProperties();
        //    isUpdating = false;
        //}

        protected override void showProperties()
        {
            //_Model = MainUI.App.ModelExplorer.GetProject(MainUI.App.ModelExplorer.CurrentProject);
            //MainForm.App.getCurrentEditor().BuildModel();
            if (_Node is DataSetNode)
            {
                _Section0.Update(_Model, _Node as DataSetNode);
                _Section1.Update(_Model, _Node as DataSetNode);
            }
        }
        #endregion
    }
}
