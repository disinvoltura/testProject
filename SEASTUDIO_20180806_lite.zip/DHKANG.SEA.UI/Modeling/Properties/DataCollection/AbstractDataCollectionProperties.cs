﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.UI.OutputView.Visualization;
using DHKANG.SEA.Model;
using OVT.CustomControls;
using Northwoods.Go;

namespace DHKANG.SEA.UI.Modeling.Properties.DataCollection
{
    public abstract class AbstractDataCollectionProperties : UserControl
    {
        #region Member Variables
        protected GoNode _Node;
        protected OOMMModel _Model;

        private List<CollapsiblePanel> _Panels = new List<CollapsiblePanel>();
        private List<UserControl> _Sections = new List<UserControl>();
        #endregion

        #region Events
        public event PropertyValueChangedEventHandler PropertyValueChanged;
        #endregion

        #region Constructors
        public AbstractDataCollectionProperties()
        {
            InitializeComponent();
        }
        #endregion

        private void addSectionProperties(UserControl section)
        {
            section.Padding = Padding.Empty;
            section.Margin = Padding.Empty;

            //section.PropertyChanged += OnPropertyChanged;
            _Sections.Add(section);
        }

        protected void addCollapsiblePanel(UserControl ctl, string title)
        {
            addSectionProperties(ctl);

            ctl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | AnchorStyles.Right))));
            CollapsiblePanel p1 = new CollapsiblePanel();
            p1.HeaderBackColor1 = Color.FromArgb(109, 50, 144);
            p1.HeaderBackColor2 = Color.FromArgb(163, 96, 201);
            p1.HeaderTextColor = Color.WhiteSmoke;

            p1.Controls.Add(ctl);
            p1.Width = flPanel.Width;
            p1.AutoSize = false;
            ctl.SendToBack();
            ctl.Top = 30;
            ctl.Left = 0;
            ctl.Width = p1.Width;
            p1.Height = 30 + ctl.Height;
            p1.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            p1.HeaderText = title;// "Donut Chart";
            //p1.HeaderTextColor = System.Drawing.Color.Black;
            p1.ShowHeaderSeparator = false;
            flPanel.Controls.Add(p1);

            _Panels.Add(p1);
        }

        protected abstract void showProperties();

        protected void notifyPropertyChange(Guid modelId, object changedObject, string propertyName, object oldValue, object newValue)
        {
            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(modelId, changedObject, propertyName, oldValue, newValue);
        }

        private void flPanel_SizeChanged(object sender, System.EventArgs e)
        {
            _Panels.ForEach(p => p.Width = flPanel.Width);
        }

        public void Update(OOMMModel model, GoNode node)
        {
            _Model = model;
            _Node = node;

            showProperties();
        }


        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.SuspendLayout();
            // 
            // flPanel
            // 
            this.flPanel.AutoScroll = true;
            this.flPanel.AutoScrollMargin = new System.Drawing.Size(10, 10);
            this.flPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flPanel.Location = new System.Drawing.Point(0, 0);
            this.flPanel.Name = "flPanel";
            this.flPanel.Size = new System.Drawing.Size(642, 340);
            this.flPanel.TabIndex = 1;
            this.flPanel.SizeChanged += new System.EventHandler(this.flPanel_SizeChanged);
            // 
            // AbstractChartProperties
            // 
            this.Controls.Add(this.flPanel);
            this.Name = "AbstractChartProperties";
            this.Size = new System.Drawing.Size(642, 340);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flPanel;
    }
}
