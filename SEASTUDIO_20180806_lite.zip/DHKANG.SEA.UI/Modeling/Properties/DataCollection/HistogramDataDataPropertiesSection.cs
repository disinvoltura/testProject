﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using Northwoods.Go;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public partial class HistogramDataDataPropertiesSection : UserControl
    {
        private OOMMModel _Model;
        private HistogramDataNode _Node;

        public event PropertyValueChangedEventHandler PropertyValueChanged;

        public HistogramDataDataPropertiesSection()
        {
            InitializeComponent();
        }

        public void Update(OOMMModel model, HistogramDataNode node)
        {
            _Model = model;
            _Node = node;

            showProperties();
        }

        private bool isUpdating = false;
        private void showProperties()
        {
            //_Model = MainUI.App.ModelExplorer.GetProject(MainUI.App.ModelExplorer.CurrentProject);
            //MainForm.App.getCurrentEditor().BuildModel();

            isUpdating = true;

            txtName.Text = _Node.Name;
            txtXAxisValue.Text = _Node.Value;

            isUpdating = false;
        }

        private void btnChoose1_Click(object sender, EventArgs e)
        {
            if (_Model == null)
                return;

            ExpressionBuilder dialog = null;
            if (string.IsNullOrEmpty(txtXAxisValue.Text))
                dialog = new ExpressionBuilder(_Model);
            else
                dialog = new ExpressionBuilder(_Model, txtXAxisValue.Text);

            DialogResult rslt = dialog.ShowDialog(this);
            if (rslt == DialogResult.OK)
            {
                string oldValue = _Node.Value;
                _Node.Value = dialog.Expression;
                //_Node.XAxsisValue = dialog.EventObjectName + "." + dialog.StateVariableName;
                txtXAxisValue.Text = _Node.Value;

                if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                    PropertyValueChanged(_Model.ID, _Node, "Value", oldValue, dialog.Expression);
            }
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
                handleNameChanged();
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            handleNameChanged();
        }

        private void handleNameChanged()
        {
            if (string.IsNullOrEmpty(txtName.Text))
                return;

            string oldValue = _Node.Name;
            _Node.Name = txtName.Text;
            _Node.UpdateText();

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Node, "Name", oldValue, txtName.Text);
        }
    }
}
