﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Northwoods.Go;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.OID.Data;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public partial class StatisticsPropertiesSection : UserControl
    {
        #region Member Variables
        private OOMMModel _Model;
        private StatisticsNode _Node;
        #endregion

        #region Events
        public event PropertyValueChangedEventHandler PropertyValueChanged;
        #endregion

        #region Constructors
        public StatisticsPropertiesSection()
        {
            InitializeComponent();
        }
        #endregion

        #region Methods
        private bool isUpdating = false;
        public void Update(OOMMModel model, StatisticsNode node)
        {
            _Model = model;
            _Node = node;

            isUpdating = true;
            showProperties();
            isUpdating = false;
        }

        private void showProperties()
        {
            txtName.Text = _Node.StatisticsName;
            txtSource.Text = _Node.Source;

            rb1.Checked = false;
            rb2.Checked = false;
            rb3.Checked = false;
            if (_Node.Type == StatisticsType.Tally)
            {
                rb1.Checked = true;
            }else if (_Node.Type == StatisticsType.TimeDependent)
            {
                rb2.Checked = true;
            }
            else if (_Node.Type == StatisticsType.Counter)
            {
                rb3.Checked = true;
            }

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnChoose1_Click(object sender, EventArgs e)
        {
            if (_Model == null)
                return;

            string oldValue = _Node.Source;
            ExpressionBuilder dialog = null;
            if (string.IsNullOrEmpty(txtSource.Text))
                dialog = new ExpressionBuilder(_Model);
            else
                dialog = new ExpressionBuilder(_Model, txtSource.Text);

            DialogResult rslt = dialog.ShowDialog(this);
            if (rslt == DialogResult.OK)
            {
                _Node.Source = dialog.Expression;
                //_Node.Source = dialog.EventObjectName + "." + dialog.StateVariableName;
                txtSource.Text = _Node.Source;

                if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                    PropertyValueChanged(_Model.ID, _Node, "Source", oldValue, dialog.Expression);
            }
        }

        private void rb1_CheckedChanged(object sender, EventArgs e)
        {
            if (rb1.Checked)
            {
                StatisticsType oldValue = _Node.Type;
                _Node.Type = StatisticsType.Tally;

                if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                    PropertyValueChanged(_Model.ID, _Node, "Type", oldValue, _Node.Type);
            }
        }

        private void rb2_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2.Checked)
            {
                StatisticsType oldValue = _Node.Type;
                _Node.Type = StatisticsType.TimeDependent;

                if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                    PropertyValueChanged(_Model.ID, _Node, "Type", oldValue, _Node.Type);
            }
        }

        private void rb3_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3.Checked)
            {
                StatisticsType oldValue = _Node.Type;
                _Node.Type = StatisticsType.Counter;

                if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                    PropertyValueChanged(_Model.ID, _Node, "Type", oldValue, _Node.Type);
            }
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            handleNameChanged();
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
                handleNameChanged();
        }

        private void handleNameChanged()
        {
            if (isUpdating)
                return;

            if (string.IsNullOrEmpty(txtName.Text))
                return;

            string oldValue = _Node.StatisticsName;
            _Node.StatisticsName = txtName.Text;
            _Node.UpdateText();

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Node, "Name", oldValue, txtName.Text);
        }
        #endregion
    }
}
