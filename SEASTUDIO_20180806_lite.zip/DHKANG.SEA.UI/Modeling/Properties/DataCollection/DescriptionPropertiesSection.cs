﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using Northwoods.Go;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public partial class DescriptionPropertiesSection: UserControl
    {
        #region Member Variables
        private OOMMModel _Model;
        private GoObject _Node;
        #endregion

        #region Events
        public event PropertyValueChangedEventHandler PropertyValueChanged;
        #endregion

        #region Constructors
        public DescriptionPropertiesSection()
        {
            InitializeComponent();
        }
        #endregion

        #region Methods
        public void Update(OOMMModel model, GoObject node)
        {
            _Model = model;
            _Node = node;

            showProperties();
        }

        private bool isUpdating = false;
        private void showProperties()
        {
            if (_Node == null)
                return;

            isUpdating = true;

            if (_Node is DataSetNode)
            {
                txtDesc.Text = ((DataSetNode)_Node).Description;
            }else if (_Node is StatisticsNode)
            {
                txtDesc.Text = ((StatisticsNode)_Node).Description;
            }

            isUpdating = false;
        }

        private void txtDesc_TextChanged(object sender, EventArgs e)
        {
            if (_Node == null)
                return;

            string oldValue = "";
            if (_Node is DataSetNode)
            {
                oldValue = ((DataSetNode)_Node).Description;
                ((DataSetNode)_Node).Description = txtDesc.Text;
            }
            else if (_Node is StatisticsNode)
            {
                oldValue = ((StatisticsNode)_Node).Description;
                ((StatisticsNode)_Node).Description = txtDesc.Text;
            }

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Node, "Description", oldValue, txtDesc.Text);
        }
        #endregion
    }
}
