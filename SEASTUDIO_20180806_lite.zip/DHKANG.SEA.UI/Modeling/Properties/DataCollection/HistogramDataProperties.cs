﻿using System.Drawing;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using DHKANG.SEA.UI.OutputView;
using Opulos.Core.UI;
using System;
using DHKANG.SEA.UI.Modeling.Properties.DataCollection;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public class HistogramDataProperties: AbstractDataCollectionProperties
    {
        #region Member Variables
        //private HistogramDataNode _Node;
        //private OOMMModel _Model;

        private HistogramDataDataPropertiesSection _Section0;
        private DescriptionPropertiesSection _Section1;

        private bool isUpdating = false;
        #endregion

        //#region Events
        //public event PropertyValueChangedEventHandler PropertyValueChanged;
        //#endregion

        #region Constructors
        public HistogramDataProperties() : base()
        {
            _Section0 = new HistogramDataDataPropertiesSection();
            _Section0.PropertyValueChanged += notifyPropertyChange;
            addCollapsiblePanel(_Section0, "Histogram Data");

            _Section1 = new DescriptionPropertiesSection();
            _Section1.PropertyValueChanged += notifyPropertyChange;
            addCollapsiblePanel(_Section1, "Description");
        }

        //private void OnPropertyValueChanged(Guid modelId, object changedObject, string propertyName, object oldValue, object newValue)
        //{
        //    if (this.PropertyValueChanged != null && this.PropertyValueChanged.GetInvocationList().Length > 0)
        //        this.PropertyValueChanged(modelId, changedObject, propertyName, oldValue, newValue); 
        //}
        #endregion

        #region Methods
        //public void Update(OOMMModel model, HistogramDataNode ds)
        //{
        //    _Model = model;
        //    _Node = ds;

        //    isUpdating = true;
        //    showProperties();
        //    isUpdating = false;
        //}

        protected override void showProperties()
        {
            //_Model = MainUI.App.ModelExplorer.GetProject(MainUI.App.ModelExplorer.CurrentProject);
            //MainForm.App.getCurrentEditor().BuildModel();

            _Section0.Update(_Model, _Node as HistogramDataNode);
            _Section1.Update(_Model, _Node as HistogramDataNode);
        }
        #endregion
    }
}
