﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using DHKANG.SEA.Model.Experiments;

namespace DHKANG.SEA.UI.Modeling
{
    public delegate void ExperimentChangedEventHandler(OOMMExperiment experiment);

    public partial class SimulationExperimentProperties: UserControl
    {
        #region Member Variables
        private OOMMExperiment _Experiment;
        private bool _IsUpdating = false;
        #endregion

        #region Events
        public event ExperimentChangedEventHandler ExperimentChanged;
        #endregion

        #region Properties
        public OOMMExperiment Experiment { get { return _Experiment; } }
        #endregion

        public SimulationExperimentProperties()
        {
            InitializeComponent();
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            //handleNameChanged();
        }

        public void Update(OOMMExperiment exp)
        {
            if (exp.Type != OOMMExperimentType.SIMULATION)
                return;

            _IsUpdating = true;

            _Experiment = exp;

            txtName.Text = _Experiment.Name;
            txtEOSTime.Text = _Experiment.EOSTime.ToString();

            cbTimeUnit.SelectedIndex = (int)_Experiment.EOSTimeUnit;
            cbUseRandSeed.Checked = _Experiment.UseRandSeed;

            if (_Experiment.UseRandSeed)
            {
                txtFixedSeed.Enabled = true;
                txtFixedSeed.Text = exp.RandSeed.ToString();
            }
            else
            {
                txtFixedSeed.Enabled = false;
                txtFixedSeed.Text = "";
            }

            _IsUpdating = false;
        }

        private void cbUseRandSeed_CheckedChanged(object sender, EventArgs e)
        {
            if (_IsUpdating)
                return;

            if (cbUseRandSeed.Checked)
                txtFixedSeed.Enabled = true;
            else
                txtFixedSeed.Enabled = false;

            _Experiment.UseRandSeed = cbUseRandSeed.Checked;

            if (ExperimentChanged != null && ExperimentChanged.GetInvocationList().Length > 0)
                ExperimentChanged(_Experiment);
        }

        private void txtEOSTime_TextChanged(object sender, EventArgs e)
        {
            //handleEOSTimeChanged();
        }

        private void txtFixedSeed_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void handleNameChanged() {
            if (_IsUpdating)
                return;

            if (string.IsNullOrEmpty(txtName.Text))
                return;

            string oldValue = _Experiment.Name;
            string newValue = txtName.Text;

            _Experiment.Name = newValue;

            if (ExperimentChanged != null && ExperimentChanged.GetInvocationList().Length > 0)
                ExperimentChanged(_Experiment);
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            if (_IsUpdating)
                return;

            handleNameChanged();
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (_IsUpdating)
                return;

            if (e.KeyData == Keys.Enter)
            {
                handleNameChanged();
            }
        }

        private void txtEOSTime_KeyDown(object sender, KeyEventArgs e)
        {
            if (_IsUpdating)
                return;

            if (e.KeyData == Keys.Enter)
            {
                handleEOSTimeChanged();
            }
        }

        private void txtEOSTime_Leave(object sender, EventArgs e)
        {
            if (_IsUpdating)
                return;

            handleEOSTimeChanged();
        }

        private void handleEOSTimeChanged()
        {
            if (_IsUpdating)
                return;

            if (string.IsNullOrEmpty(txtEOSTime.Text))
                return;
            float eosTime = 0;
            if (float.TryParse(txtEOSTime.Text, out eosTime))
            {
                _Experiment.EOSTime = eosTime;

                if (eosTime == 0)
                    lblError1.Visible = true;
                else
                    lblError1.Visible = false;

                if (ExperimentChanged != null && ExperimentChanged.GetInvocationList().Length > 0)
                    ExperimentChanged(_Experiment);
            }
        }

        private void txtFixedSeed_Leave(object sender, EventArgs e)
        {
            if (_IsUpdating)
                return;

            handleFixedSeedChanged();
        }

        private void txtFixedSeed_KeyDown(object sender, KeyEventArgs e)
        {
            if (_IsUpdating)
                return;

            if (e.KeyData == Keys.Enter)
            {
                handleFixedSeedChanged();
            }
        }

        private void handleFixedSeedChanged()
        {
            if (_IsUpdating)
                return;

            if (string.IsNullOrEmpty(txtFixedSeed.Text))
                return;
            int seed = 0;
            if (int.TryParse(txtFixedSeed.Text, out seed))
            {
                _Experiment.RandSeed = seed;

                if (seed == 0)
                    lblError2.Visible = true;
                else
                    lblError2.Visible = false;

                if (ExperimentChanged != null && ExperimentChanged.GetInvocationList().Length > 0)
                    ExperimentChanged(_Experiment);
            }
        }

        private void cbTimeUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_IsUpdating)
                return;

            _Experiment.EOSTimeUnit = (OOMMTimeUnit)Enum.ToObject(typeof(OOMMTimeUnit), cbTimeUnit.SelectedIndex);

            if (ExperimentChanged != null && ExperimentChanged.GetInvocationList().Length > 0)
                ExperimentChanged(_Experiment);

        }
    }
}
