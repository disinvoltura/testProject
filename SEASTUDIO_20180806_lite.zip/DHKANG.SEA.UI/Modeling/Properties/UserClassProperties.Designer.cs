﻿namespace DHKANG.SEA.UI.Modeling
{
    partial class UserClassProperties
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbSuperClasses = new System.Windows.Forms.ComboBox();
            this.properties = new SourceGrid.Grid();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnRemoveProperty = new System.Windows.Forms.Button();
            this.btnAddProperty = new System.Windows.Forms.Button();
            this.collapsiblePanel1 = new OVT.CustomControls.CollapsiblePanel();
            this.collapsiblePanel2 = new OVT.CustomControls.CollapsiblePanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnRemoveMethod = new System.Windows.Forms.Button();
            this.btnAddMethod = new System.Windows.Forms.Button();
            this.methods = new SourceGrid.Grid();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.collapsiblePanel1.SuspendLayout();
            this.collapsiblePanel2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtName
            // 
            this.txtName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtName.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(96, 47);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(512, 23);
            this.txtName.TabIndex = 43;
            this.txtName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtName_KeyDown);
            this.txtName.Leave += new System.EventHandler(this.txtName_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 14);
            this.label2.TabIndex = 41;
            this.label2.Text = "Name:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(114)))), ((int)(((byte)(198)))));
            this.panel1.Controls.Add(this.label8);
            this.panel1.Location = new System.Drawing.Point(-3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(636, 25);
            this.panel1.TabIndex = 46;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(16, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 19);
            this.label8.TabIndex = 0;
            this.label8.Text = "User Class";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(14, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 14);
            this.label4.TabIndex = 47;
            this.label4.Text = "Superclass:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbSuperClasses
            // 
            this.cbSuperClasses.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbSuperClasses.FormattingEnabled = true;
            this.cbSuperClasses.Location = new System.Drawing.Point(96, 85);
            this.cbSuperClasses.Name = "cbSuperClasses";
            this.cbSuperClasses.Size = new System.Drawing.Size(512, 20);
            this.cbSuperClasses.TabIndex = 48;
            this.cbSuperClasses.SelectedIndexChanged += new System.EventHandler(this.cbSuperClasses_SelectedIndexChanged);
            // 
            // properties
            // 
            this.properties.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.properties.EnableSort = true;
            this.properties.FixedRows = 1;
            this.properties.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.properties.Location = new System.Drawing.Point(16, 41);
            this.properties.Name = "properties";
            this.properties.OptimizeMode = SourceGrid.CellOptimizeMode.ForRows;
            this.properties.SelectionMode = SourceGrid.GridSelectionMode.Cell;
            this.properties.Size = new System.Drawing.Size(588, 120);
            this.properties.TabIndex = 49;
            this.properties.TabStop = true;
            this.properties.ToolTipText = "";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.btnRemoveProperty);
            this.panel3.Controls.Add(this.btnAddProperty);
            this.panel3.Location = new System.Drawing.Point(16, 166);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(588, 32);
            this.panel3.TabIndex = 46;
            // 
            // btnRemoveProperty
            // 
            this.btnRemoveProperty.Location = new System.Drawing.Point(38, 5);
            this.btnRemoveProperty.Name = "btnRemoveProperty";
            this.btnRemoveProperty.Size = new System.Drawing.Size(25, 23);
            this.btnRemoveProperty.TabIndex = 1;
            this.btnRemoveProperty.Text = "-";
            this.btnRemoveProperty.UseVisualStyleBackColor = true;
            this.btnRemoveProperty.Click += new System.EventHandler(this.btnRemoveProperty_Click);
            // 
            // btnAddProperty
            // 
            this.btnAddProperty.Location = new System.Drawing.Point(7, 5);
            this.btnAddProperty.Name = "btnAddProperty";
            this.btnAddProperty.Size = new System.Drawing.Size(25, 23);
            this.btnAddProperty.TabIndex = 0;
            this.btnAddProperty.Text = "+";
            this.btnAddProperty.UseVisualStyleBackColor = true;
            this.btnAddProperty.Click += new System.EventHandler(this.btnAddProperty_Click);
            // 
            // collapsiblePanel1
            // 
            this.collapsiblePanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.collapsiblePanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.collapsiblePanel1.BackColor = System.Drawing.Color.Transparent;
            this.collapsiblePanel1.Controls.Add(this.panel3);
            this.collapsiblePanel1.Controls.Add(this.properties);
            this.collapsiblePanel1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.collapsiblePanel1.HeaderBackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(114)))), ((int)(((byte)(198)))));
            this.collapsiblePanel1.HeaderBackColor2 = System.Drawing.Color.Magenta;
            this.collapsiblePanel1.HeaderBackgroundGradientAngle = 90;
            this.collapsiblePanel1.HeaderFont = new System.Drawing.Font("Calibri", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.collapsiblePanel1.HeaderImage = null;
            this.collapsiblePanel1.HeaderText = "Properties";
            this.collapsiblePanel1.HeaderTextColor = System.Drawing.Color.BlanchedAlmond;
            this.collapsiblePanel1.Location = new System.Drawing.Point(2, 130);
            this.collapsiblePanel1.Name = "collapsiblePanel1";
            this.collapsiblePanel1.ShowHeaderSeparator = false;
            this.collapsiblePanel1.Size = new System.Drawing.Size(625, 203);
            this.collapsiblePanel1.TabIndex = 51;
            this.collapsiblePanel1.UseAnimation = true;
            // 
            // collapsiblePanel2
            // 
            this.collapsiblePanel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.collapsiblePanel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.collapsiblePanel2.BackColor = System.Drawing.Color.Transparent;
            this.collapsiblePanel2.Controls.Add(this.panel2);
            this.collapsiblePanel2.Controls.Add(this.methods);
            this.collapsiblePanel2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.collapsiblePanel2.HeaderBackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(114)))), ((int)(((byte)(198)))));
            this.collapsiblePanel2.HeaderBackColor2 = System.Drawing.Color.Magenta;
            this.collapsiblePanel2.HeaderBackgroundGradientAngle = 90;
            this.collapsiblePanel2.HeaderFont = new System.Drawing.Font("Calibri", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.collapsiblePanel2.HeaderImage = null;
            this.collapsiblePanel2.HeaderText = "Methods";
            this.collapsiblePanel2.HeaderTextColor = System.Drawing.Color.BlanchedAlmond;
            this.collapsiblePanel2.Location = new System.Drawing.Point(2, 342);
            this.collapsiblePanel2.Name = "collapsiblePanel2";
            this.collapsiblePanel2.ShowHeaderSeparator = false;
            this.collapsiblePanel2.Size = new System.Drawing.Size(625, 200);
            this.collapsiblePanel2.TabIndex = 52;
            this.collapsiblePanel2.UseAnimation = true;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.btnRemoveMethod);
            this.panel2.Controls.Add(this.btnAddMethod);
            this.panel2.Location = new System.Drawing.Point(16, 165);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(588, 32);
            this.panel2.TabIndex = 46;
            // 
            // btnRemoveMethod
            // 
            this.btnRemoveMethod.Location = new System.Drawing.Point(38, 5);
            this.btnRemoveMethod.Name = "btnRemoveMethod";
            this.btnRemoveMethod.Size = new System.Drawing.Size(25, 23);
            this.btnRemoveMethod.TabIndex = 1;
            this.btnRemoveMethod.Text = "-";
            this.btnRemoveMethod.UseVisualStyleBackColor = true;
            this.btnRemoveMethod.Click += new System.EventHandler(this.btnRemoveMethod_Click);
            // 
            // btnAddMethod
            // 
            this.btnAddMethod.Location = new System.Drawing.Point(7, 5);
            this.btnAddMethod.Name = "btnAddMethod";
            this.btnAddMethod.Size = new System.Drawing.Size(25, 23);
            this.btnAddMethod.TabIndex = 0;
            this.btnAddMethod.Text = "+";
            this.btnAddMethod.UseVisualStyleBackColor = true;
            this.btnAddMethod.Click += new System.EventHandler(this.btnAddMethod_Click);
            // 
            // methods
            // 
            this.methods.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.methods.EnableSort = true;
            this.methods.FixedRows = 1;
            this.methods.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.methods.Location = new System.Drawing.Point(16, 41);
            this.methods.Name = "methods";
            this.methods.OptimizeMode = SourceGrid.CellOptimizeMode.ForRows;
            this.methods.SelectionMode = SourceGrid.GridSelectionMode.Cell;
            this.methods.Size = new System.Drawing.Size(588, 120);
            this.methods.TabIndex = 49;
            this.methods.TabStop = true;
            this.methods.ToolTipText = "";
            // 
            // UserClassProperties
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.collapsiblePanel2);
            this.Controls.Add(this.collapsiblePanel1);
            this.Controls.Add(this.cbSuperClasses);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label2);
            this.Name = "UserClassProperties";
            this.Size = new System.Drawing.Size(629, 649);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.collapsiblePanel1.ResumeLayout(false);
            this.collapsiblePanel2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbSuperClasses;
        private SourceGrid.Grid properties;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnRemoveProperty;
        private System.Windows.Forms.Button btnAddProperty;
        private OVT.CustomControls.CollapsiblePanel collapsiblePanel1;
        private OVT.CustomControls.CollapsiblePanel collapsiblePanel2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnRemoveMethod;
        private System.Windows.Forms.Button btnAddMethod;
        private SourceGrid.Grid methods;
    }
}
