﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.UI.ETTEditor;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model;
using DHKANG.SEA.UI.STTEditor;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public partial class EntityQueueProperties: UserControl
    {
        #region Member Variables
        private EntityQueueNode _Node;

        private bool isUpdating = false;
        #endregion

        #region Constructors
        public EntityQueueProperties()
        {
            InitializeComponent();
        }
        #endregion

        #region Methods
        public void Update(EntityQueueNode node)
        {
            _Node = node;

            showProperties();
        }

        private void showProperties()
        {
            isUpdating = true;

            txtName.Text = _Node.EntityQueueName;

            cbType.SelectedIndex = 0;
            if (_Node.Rule == SelectionRule.LIFO)
                cbType.SelectedIndex = 1;

            isUpdating = false;
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            handleNameChanged();
        }

        private void handleNameChanged()
        {
            if (isUpdating)
                return;

            if (_Node.EntityQueueName!= txtName.Text)
            {
                _Node.EntityQueueName = txtName.Text;
                _Node.UpdateText();
            }
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleNameChanged();
            }
        }

        private void cbType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            if (cbType.SelectedIndex == 0)
                _Node.Rule = SelectionRule.FIFO;
            else if (cbType.SelectedIndex == 1)
                _Node.Rule = SelectionRule.LIFO;
        }
        #endregion
    }
}
