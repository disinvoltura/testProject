﻿using DHKANG.SEA.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public class MethodBodyEditorDialog : SourceGrid.Cells.Editors.TextBoxButton
    {
        public MethodBodyEditorDialog()
            : base(typeof(string))
        {
            this.Control.TextBox.Multiline = true;
            Control.DialogOpen += new EventHandler(Control_DialogOpen);
        }

        void Control_DialogOpen(object sender, EventArgs e)
        {
            OOMMUserClassMethod action = (OOMMUserClassMethod)Control.Value;
            MethodBodyEditor editor = new MethodBodyEditor(action);
            DialogResult rslt = editor.ShowDialog();
            if (rslt == DialogResult.OK)
            {
                Control.Value = editor.Action;
            }
        }
    }
}
