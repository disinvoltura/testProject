﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Northwoods.Go;
using DHKANG.SEA.UI.OutputView.Visualization;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public delegate void ChartDimensionPropertyChangedEventHandler(OOMMModel model, AbstractChart chart);

    public partial class ChartDimensionPropertiesSection: UserControl
    {
        #region Member Variables
        private OOMMModel _Model;
        private AbstractChart _Chart;
        #endregion

        #region Events
        public event ChartAppearancePropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Constructors
        public ChartDimensionPropertiesSection()
        {
            InitializeComponent();

            numericUpDown1.Maximum = decimal.MaxValue;
            numericUpDown2.Maximum = decimal.MaxValue;
            numericUpDown3.Maximum = decimal.MaxValue;
            numericUpDown4.Maximum = decimal.MaxValue;
        }
        #endregion

        #region Methods
        public void Update(OOMMModel model, AbstractChart chart)
        {
            _Model = model; 
            _Chart = chart;

            showProperties();
        }

        private bool isUpdating = false;
        private void showProperties()
        {
            isUpdating = true;

            numericUpDown1.Value = (int)_Chart.Width;
            numericUpDown2.Value = (int)_Chart.Height;
            numericUpDown3.Value = (int)_Chart.Left;
            numericUpDown4.Value = (int)_Chart.Top;

            isUpdating = false;
        }
      
        private void notifyPropertyChangedEvent()
        {
            _Chart.UpdateSeries();

            //if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
            //    PropertyChanged(_Model, _Chart);
        }
        #endregion

        /// <summary>
        /// Left
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            _Chart.Left = (int)numericUpDown3.Value;

            notifyPropertyChangedEvent();
        }

        /// <summary>
        /// height
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            _Chart.Height = (int)numericUpDown2.Value;

            notifyPropertyChangedEvent();
        }

        /// <summary>
        /// width
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void numericUpDown1_ValueChanged_1(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            _Chart.Width = (int)numericUpDown1.Value;

            notifyPropertyChangedEvent();
        }

        /// <summary>
        /// top
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void numericUpDown4_ValueChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            _Chart.Top = (int)numericUpDown4.Value;

            notifyPropertyChangedEvent();
        }
    }
}
