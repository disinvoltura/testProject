﻿using System.Drawing;
using System.Windows.Forms;
using DHKANG.SEA.UI.OutputView.Visualization;
using Opulos.Core.UI;
using DHKANG.SEA.Model;
using DHKANG.SEA.UI.Modeling.Properties.Charts;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public class ScatterChartProperties : AbstractChartProperties
    {
        #region Member Variables
        private ChartTitlePropertiesSection section0;
        private AdvancedDataPropertiesSection section1;
        //private DataPropertiesSection section1;
        private ChartAppearancePropertiesSection section2;
        private ChartDimensionPropertiesSection section3;
        #endregion

        #region Constructors
        public ScatterChartProperties() : base()
        {
            section0 = new ChartTitlePropertiesSection();
            addCollapsiblePanel(section0, "Scatter Chart");       

            section1 = new AdvancedDataPropertiesSection();
            addCollapsiblePanel(section1, "Data");       

            section2 = new ChartAppearancePropertiesSection();
            addCollapsiblePanel(section2, "Appearance");

            section3 = new ChartDimensionPropertiesSection();
            addCollapsiblePanel(section3, "Dimension");

            section0.PropertyChanged += notifyPropertyChange;
            section1.PropertyChanged += notifyPropertyChange;       
            section2.PropertyChanged += notifyPropertyChange;       
            section3.PropertyChanged += notifyPropertyChange;       
        }
        #endregion

        private bool isUpdating = false;
        protected override void showProperties()
        {
            isUpdating = true;

            section0.Update(_Model, _Chart);
            section1.Update(_Model, _Chart);
            section2.Update(_Model, _Chart);
            section3.Update(_Model, _Chart);

            isUpdating = false;

        }
    }
}
