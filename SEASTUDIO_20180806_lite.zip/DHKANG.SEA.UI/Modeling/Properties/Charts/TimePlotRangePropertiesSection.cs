﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Northwoods.Go;
using DHKANG.SEA.UI.OutputView.Visualization;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public partial class TimePlotRangePropertiesSection: UserControl
    {
        private OOMMModel _Model;
        private TimePlot _Chart;

        public TimePlotRangePropertiesSection()
        {
            InitializeComponent();
        }

        public void Update(OOMMModel model, AbstractChart chart)
        {
            _Model = model;
            _Chart = chart as TimePlot;

            showProperties();
        }

        private bool isUpdating = false;
        private void showProperties()
        {
            //_Model = MainUI.App.ModelExplorer.GetProject(MainUI.App.ModelExplorer.CurrentProject);
            //MainForm.App.getCurrentEditor().BuildModel();

            isUpdating = true;

            xFrom.Value = (decimal) _Chart.Range.XValueFrom;
            xTo.Value = (decimal)_Chart.Range.XValueTo;
            yFrom.Value = (decimal)_Chart.Range.YValueFrom;
            yTo.Value = (decimal)_Chart.Range.YValueTo;
            
            isUpdating = false;
        }
        
        private void btnApply_Click(object sender, EventArgs e)
        {
            _Chart.UpdateRange((double)xFrom.Value, (double)xTo.Value, (double)yFrom.Value, (double)yTo.Value);
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            _Chart.ResetRange();
        }
    }
}
