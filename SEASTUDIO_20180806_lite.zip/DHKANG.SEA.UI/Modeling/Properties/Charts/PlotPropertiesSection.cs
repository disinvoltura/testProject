﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Northwoods.Go;
using DHKANG.SEA.Model;
using DHKANG.SEA.UI.OutputView.Visualization;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public delegate void PlotPropertyChangedEventHandler(OOMMModel model, AbstractChart chart);

    public partial class PlotPropertiesSection: UserControl
    {
        #region Member Variables
        private OOMMModel _Model;
        private Plot _Chart;
        #endregion

        #region Events
        public event PlotPropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Constructors
        public PlotPropertiesSection()
        {
            InitializeComponent();
        }
        #endregion

        #region Methods
        public void Update(OOMMModel model, Plot chart)
        {
            _Model = model;
            _Chart = chart;

            showProperties();
        }

        private bool isUpdating = false;
        private void showProperties()
        {
            //_Model = MainUI.App.ModelExplorer.GetProject(MainUI.App.ModelExplorer.CurrentProject);
            //MainForm.App.getCurrentEditor().BuildModel();

            isUpdating = true;

            txtTitle.Text = _Chart.ChartTitle;

            isUpdating = false;
        }

        private void txtTitle_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtTitle_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
                handleTitleChanged();
        }

        private void txtTitle_Leave(object sender, EventArgs e)
        {
            handleTitleChanged();
        }

        private void handleTitleChanged()
        {
            if (isUpdating)
                return;

            if (string.IsNullOrEmpty(txtTitle.Text))
                return;

            _Chart.ChartTitle = txtTitle.Text;

            notifyPropertyChangedEvent();

        }

        private void notifyPropertyChangedEvent()
        {
            if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                PropertyChanged(_Model, _Chart);
        }
        #endregion


    }
}
