﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Northwoods.Go;
using DHKANG.SEA.UI.OutputView.Visualization;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public delegate void ChartAppearancePropertyChangedEventHandler(OOMMModel model, AbstractChart chart);

    public partial class ChartAppearancePropertiesSection: UserControl
    {
        #region Member Variables
        private OOMMModel _Model;
        private AbstractChart _Chart;
        #endregion

        #region Events
        public event ChartAppearancePropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Constructors
        public ChartAppearancePropertiesSection()
        {
            InitializeComponent();
        }
        #endregion

        #region Methods
        public void Update(OOMMModel model, AbstractChart chart)
        {
            _Model = model; 
            _Chart = chart;

            showProperties();
        }

        private bool isUpdating = false;
        private void showProperties()
        {
            //_Model = MainUI.App.ModelExplorer.GetProject(MainUI.App.ModelExplorer.CurrentProject);
            //MainForm.App.getCurrentEditor().BuildModel();

            isUpdating = true;

            //txtBGColor.BackColor = _Chart.Appearance.BackgroundColor;
            //txtBorderColor.BackColor = _Chart.Appearance.BorderColor;
            //numWeight.Value = _Chart.Appearance.BorderWeight;

            txtBGColor.BackColor = _Chart.BackgroundColor;
            txtBorderColor.BackColor = _Chart.BorderColor;
            numWeight.Value = (int)_Chart.BorderWeight;

            isUpdating = false;
        }

        private void btnColor_Click(object sender, EventArgs e)
        {
            ColorDialog dialog = new ColorDialog();
            dialog.Color = txtBGColor.BackColor;

            DialogResult rslt = dialog.ShowDialog(this);
            if (rslt == DialogResult.OK)
            {
                txtBGColor.BackColor = dialog.Color;
                _Chart.BackgroundColor = dialog.Color;
                //_Chart.Appearance.BackgroundColor = dialog.Color;
                notifyPropertyChangedEvent();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ColorDialog dialog = new ColorDialog();
            dialog.Color = txtBorderColor.BackColor;
            DialogResult rslt = dialog.ShowDialog(this);
            if (rslt == DialogResult.OK)
            {
                txtBorderColor.BackColor = dialog.Color;
                _Chart.BorderColor = dialog.Color;
                //_Chart.Appearance.BorderColor = dialog.Color;

                notifyPropertyChangedEvent();
            }
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            _Chart.BorderWeight = (int) numWeight.Value;

            notifyPropertyChangedEvent();
        }

        private void notifyPropertyChangedEvent()
        {
            if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                PropertyChanged(_Model, _Chart);
        }
        #endregion
    }
}
