﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Northwoods.Go;
using DHKANG.SEA.UI.OutputView.Visualization;
using System.Text.RegularExpressions;
using SourceGrid.Cells.Editors;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public delegate void TimePlotDataPropertyChangedEventHandler(OOMMModel model, AbstractChart chart);
    public partial class TimePlotDataPropertiesSection: UserControl
    {
        #region Member Variables
        private OOMMModel _Model;
        private AbstractChart _Chart;

        private NameValueChangedEventController _NameValueChangeController;
        private ColorValueChangedEventController _ColorValueChangeController;
        private SeriesValueChangedEventController _SeriesValueChangeController;
        private LineWidthValueChangedEventController _LineWidthValueChangeController;
        private MarkerValueChangedEventController _MarkerValueChangeController;
        private ColorValueChangedEventController _MarkerColorValueChangeController;
        private CheckBoxValueChangedEventController _MarkerVisibleValueChangeController;

        #endregion

        #region Events
        public event DataPropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Constructors
        public TimePlotDataPropertiesSection()
        {
            InitializeComponent();

            drawHeaders();
        }
        #endregion

        /*
        private void drawHeaders()
        {
            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Snow;
            backHeader.Border = DevAge.Drawing.RectangleBorder.NoBorder;
            titleModel.Background = backHeader;
            //titleModel.BackColor = Color.SteelBlue;
            //titleModel.ForeColor = Color.White;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            gridData.BorderStyle = BorderStyle.FixedSingle;
            gridData.Redim(1, 4);
            gridData.FixedRows = 1;
            gridData.Font = new Font("Calibe", 10);
            //1st Header Row
            gridData.Rows.Insert(0);

            SourceGrid.Cells.ColumnHeader titleHeader = new SourceGrid.Cells.ColumnHeader("Title");
            titleHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.ColumnHeader colorHeader = new SourceGrid.Cells.ColumnHeader("Color");
            colorHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.ColumnHeader valueHeader = new SourceGrid.Cells.ColumnHeader("Value");
            valueHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            titleHeader.AutomaticSortEnabled = true;
            colorHeader.AutomaticSortEnabled = false;
            valueHeader.AutomaticSortEnabled = false;

            //gridData[0, 0] = valueHeader;
            gridData[0, 1] = titleHeader;
            gridData[0, 2] = colorHeader;
            gridData[0, 3] = valueHeader;

            gridData.Columns[3].Width = 200;

            _NameValueChangeController = new NameValueChangedEventController();
            _NameValueChangeController.ValueChanged +=
                new NameValueChangedEventHandler(OnNameValueChange);

            _ColorValueChangeController = new ColorValueChangedEventController();
            _ColorValueChangeController.ValueChanged +=
                new ColorValueChangedEventHandler(OnColorValueChange);

            _SeriesValueChangeController = new SeriesValueChangedEventController();
            _SeriesValueChangeController.ValueChanged +=
                new SeriesValueChangedEventHandler(OnSeriesValueChange);
        }
        */

        private void drawHeaders()
        {
            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Snow;
            backHeader.Border = DevAge.Drawing.RectangleBorder.NoBorder;
            titleModel.Background = backHeader;
            //titleModel.BackColor = Color.SteelBlue;
            //titleModel.ForeColor = Color.White;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            gridData.BorderStyle = BorderStyle.FixedSingle;
            gridData.Redim(1, 8);
            gridData.FixedRows = 1;
            gridData.Font = new Font("Calibe", 10);
            //1st Header Row
            gridData.Rows.Insert(0);

            SourceGrid.Cells.ColumnHeader titleHeader = new SourceGrid.Cells.ColumnHeader("Title");
            titleHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.ColumnHeader valueHeader = new SourceGrid.Cells.ColumnHeader("Value");
            valueHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.ColumnHeader colorHeader = new SourceGrid.Cells.ColumnHeader("Color");
            colorHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.ColumnHeader linewidthHeader = new SourceGrid.Cells.ColumnHeader("Line Width");
            linewidthHeader.View = titleModel;

            SourceGrid.Cells.ColumnHeader markerTypeHeader = new SourceGrid.Cells.ColumnHeader("Marker Type");
            markerTypeHeader.View = titleModel;

            SourceGrid.Cells.ColumnHeader markerColorHeader = new SourceGrid.Cells.ColumnHeader("Marker Color");
            markerColorHeader.View = titleModel;

            SourceGrid.Cells.ColumnHeader markerVisibleHeader = new SourceGrid.Cells.ColumnHeader("Show Marker");
            markerVisibleHeader.View = titleModel;

            titleHeader.AutomaticSortEnabled = true;
            colorHeader.AutomaticSortEnabled = false;
            valueHeader.AutomaticSortEnabled = false;
            linewidthHeader.AutomaticSortEnabled = false;
            markerTypeHeader.AutomaticSortEnabled = false;
            markerColorHeader.AutomaticSortEnabled = false;
            markerVisibleHeader.AutomaticSortEnabled = false;

            //gridData[0, 0] = valueHeader;
            gridData[0, 1] = titleHeader;
            gridData[0, 2] = valueHeader;
            gridData[0, 3] = colorHeader;
            gridData[0, 4] = linewidthHeader;
            gridData[0, 5] = markerTypeHeader;
            gridData[0, 6] = markerColorHeader;
            gridData[0, 7] = markerVisibleHeader;

            gridData.Columns[2].Width = 200;
            gridData.Columns[4].MinimalWidth = 60;
            gridData.Columns[4].Width = 100;
            gridData.Columns[5].MinimalWidth = 60;
            gridData.Columns[5].Width = 100;
            gridData.Columns[6].MinimalWidth = 60;
            gridData.Columns[6].Width = 100;
            gridData.Columns[7].MinimalWidth = 60;
            gridData.Columns[7].Width = 100;

            _NameValueChangeController = new NameValueChangedEventController();
            _NameValueChangeController.ValueChanged +=
                new NameValueChangedEventHandler(OnNameValueChange);

            _SeriesValueChangeController = new SeriesValueChangedEventController();
            _SeriesValueChangeController.ValueChanged +=
                new SeriesValueChangedEventHandler(OnSeriesValueChange);


            _ColorValueChangeController = new ColorValueChangedEventController();
            _ColorValueChangeController.ValueChanged +=
                new ColorValueChangedEventHandler(OnColorValueChange);


            _MarkerVisibleValueChangeController = new CheckBoxValueChangedEventController();
            _MarkerVisibleValueChangeController.ValueChanged +=
                new CheckBoxValueChangedEventHandler(OnMarkerVisibleValueChanged);

            //_CheckBoxValueChangeController = new CheckBoxValueChangedEventController();
            //_CheckBoxValueChangeController.ValueChanged +=
            //    new CheckBoxValueChangedEventHandler(OnCheckBoxValueChanged);

            _ColorValueChangeController = new ColorValueChangedEventController();
            _ColorValueChangeController.ValueChanged +=
                new ColorValueChangedEventHandler(OnColorValueChange);

            _LineWidthValueChangeController = new LineWidthValueChangedEventController();
            _LineWidthValueChangeController.ValueChanged +=
                new LineWidthValueChangedEventHandler(OnLineWidthValueChange);

            _MarkerValueChangeController = new MarkerValueChangedEventController();
            _MarkerValueChangeController.ValueChanged +=
                new MarkerValueChangedEventHandler(OnMarkerValueChange);

            _MarkerColorValueChangeController = new ColorValueChangedEventController();
            _MarkerColorValueChangeController.ValueChanged +=
                new ColorValueChangedEventHandler(OnMarkerColorValueChange);
        }

        private void OnNameValueChange(int row, string oldName, string newName)
        {
            if (_Chart.Series[oldName] != null)
            {
                Series s = _Chart.Series[oldName];
                _Chart.Series.Remove(oldName);
                s.Name = newName;
                //_Chart.Series.Add(s);
                _Chart.AddSeries(s);

                notityPropertyChangedEvent();
            }

            /*
            updateNextEventEditor(oldEventName, newEventName);

            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
                this.Changed("eventvertex", "changed", oldEventName, newEventName);
            */
        }

        private void OnColorValueChange(int row, Color oldValue, Color newValue)
        {
            string seriesName = (string)gridData[row, 1].Value;

            if (_Chart.Series[seriesName] != null)
            {
                //Series s = _Chart.Series[seriesName];
                _Chart.SetLineColor(seriesName, newValue);
                //s.LineColor = newValue;// Color.FromName(newValue);                

                gridData[row, 3].View.BackColor = newValue;

                notityPropertyChangedEvent();
            }
        }

        private void OnSeriesValueChange(int row, string oldValue, string newValue)
        {
            string seriesName = (string)gridData[row, 1].Value;

            if (_Chart.Series[seriesName] != null)
            {
                Series s = _Chart.Series[seriesName];
                s.Value = newValue;

                notityPropertyChangedEvent();
            }
        }

        private void OnMarkerVisibleValueChanged(int row, bool oldValue, bool newValue)
        {
            string seriesName = (string)gridData[row, 1].Value;

            if (_Chart.Series[seriesName] != null)
            {
                //Series s = _Chart.Series[seriesName];
                //s.ShowMarker = newValue;

                if (_Chart is TimePlot)
                {
                    //((TimePlot)_Chart).InvalidateViews();
                    //((TimePlot)_Chart).UpdateSeries();
                    ((TimePlot)_Chart).SetMarkerVisible(seriesName, newValue);
                }
            }
        }

        private void OnMarkerColorValueChange(int row, Color oldValue, Color newValue)
        {
            string seriesName = (string)gridData[row, 1].Value;

            if (_Chart.Series[seriesName] != null)
            {
                //Series s = _Chart.Series[seriesName];
                //s.MarkerColor = newValue;// Color.FromName(newValue);                

                gridData[row, 6].View.BackColor = newValue;
                if (_Chart is TimePlot)
                {
                    ((TimePlot)_Chart).SetMarkerColor(seriesName, newValue);
                }
            }
        }

        private void OnLineWidthValueChange(int row, int oldValue, int newValue)
        {
            string seriesName = (string)gridData[row, 1].Value;

            if (_Chart.Series[seriesName] != null)
            {
                //Series s = _Chart.Series[seriesName];
                //s.LineWidth = newValue;

                if (_Chart is TimePlot)
                {
                    ((TimePlot)_Chart).SetLineWidth(seriesName, newValue);
                }
            }
        }

        private void OnMarkerValueChange(int row, string oldValue, string newValue)
        {
            string seriesName = (string)gridData[row, 1].Value;

            if (_Chart.Series[seriesName] != null)
            {
                //Series s = _Chart.Series[seriesName];
                //s.MarkerType = (MarkerType)Enum.Parse(typeof(MarkerType), newValue);

                if (_Chart is TimePlot)
                {
                    ((TimePlot)_Chart).SetMarkerType(seriesName, (MarkerType)Enum.Parse(typeof(MarkerType), newValue));
                    //((TimePlot)_Chart).SetMarkerType(seriesName, s.MarkerType);
                }
            }
        }

        public void InsertData(Series dataSeries)
        {
            int rowIndex = gridData.RowsCount;
            //int rowIndex = gridData.RowsCount - 1;
            gridData.Rows.Insert(rowIndex);

            SourceGrid.Cells.CheckBox cbCell = new SourceGrid.Cells.CheckBox("", false);
            cbCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            
            SourceGrid.Cells.Cell titleCell = new SourceGrid.Cells.Cell(dataSeries.Name, typeof(string));
            titleCell.View = getCellView();
            //titleCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            titleCell.AddController(_NameValueChangeController);

            SourceGrid.Cells.Cell colorCell = new SourceGrid.Cells.Cell(dataSeries.LineColor, typeof(Color));
            colorCell.View = getCellView();
            colorCell.View.BackColor = dataSeries.LineColor;
            //colorCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            colorCell.AddController(_ColorValueChangeController);

            SourceGrid.Cells.Cell valueCell = new SourceGrid.Cells.Cell(dataSeries.Value, typeof(string));
            valueCell.View = getCellView();
            //valueCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.Editors.TextBoxButton button = new SourceGrid.Cells.Editors.TextBoxButton(typeof(string));
            valueCell.Editor = button;
            button.Control.Button.Click += Button_Click;
            valueCell.AddController(_SeriesValueChangeController);

            SourceGrid.Cells.Editors.NumericUpDown nudEditor = new SourceGrid.Cells.Editors.NumericUpDown(typeof(int), 10, 1, 1);
            SourceGrid.Cells.Cell lineWidthCell = new SourceGrid.Cells.Cell(dataSeries.LineWidth, nudEditor);
            lineWidthCell.View = getCellView();
            lineWidthCell.AddController(_LineWidthValueChangeController);

            SourceGrid.Cells.Editors.ComboBox cbEditor2 = getMarkerComboBoxEditor();
            SourceGrid.Cells.Cell markerCell = new SourceGrid.Cells.Cell(dataSeries.MarkerType, cbEditor2);
            markerCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            markerCell.View = SourceGrid.Cells.Views.ComboBox.Default;
            markerCell.AddController(_MarkerValueChangeController);

            SourceGrid.Cells.Cell markerColorCell = new SourceGrid.Cells.Cell(dataSeries.MarkerColor, typeof(Color));
            markerColorCell.View = getCellView();
            markerColorCell.View.BackColor = dataSeries.MarkerColor;
            markerColorCell.AddController(_MarkerColorValueChangeController);

            SourceGrid.Cells.CheckBox cbMarkerVisibleCell = null;
            if (dataSeries.ShowMarker)
                cbMarkerVisibleCell = new SourceGrid.Cells.CheckBox("", true);
            else
                cbMarkerVisibleCell = new SourceGrid.Cells.CheckBox("", false);

            cbMarkerVisibleCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            cbMarkerVisibleCell.AddController(_MarkerVisibleValueChangeController);

            gridData[rowIndex, 0] = cbCell;
            gridData[rowIndex, 1] = titleCell;
            gridData[rowIndex, 2] = valueCell;
            gridData[rowIndex, 3] = colorCell;
            gridData[rowIndex, 4] = lineWidthCell;
            gridData[rowIndex, 5] = markerCell;
            gridData[rowIndex, 6] = markerColorCell;
            gridData[rowIndex, 7] = cbMarkerVisibleCell;

        }

        private SourceGrid.Cells.Editors.ComboBox getMarkerComboBoxEditor()
        {
            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));

            List<string> types = new List<string>();

            foreach (MarkerType type in Enum.GetValues(typeof(MarkerType)))
            {
                types.Add(type.ToString());
            }
            types.Sort();

            cbEditor.StandardValues = types.ToArray<string>();
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;
            return cbEditor;
        }

        private SourceGrid.Cells.Views.Cell getCellView()
        {
            SourceGrid.Cells.Views.Cell cellModel = new SourceGrid.Cells.Views.Cell();
            DevAge.Drawing.VisualElements.BackgroundSolid bg = new DevAge.Drawing.VisualElements.BackgroundSolid();
            bg.BackColor = Color.White;
            cellModel.Background = bg;
            cellModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            return cellModel;
        }

        Random r = new Random();
        private Color getNextColor()
        {
            KnownColor[] colorList = (KnownColor[])KnownColor.GetValues(typeof(KnownColor));
            KnownColor kc = colorList[r.Next(0, colorList.Length)];
            return Color.FromKnownColor(kc);
        }

        public void InsertNewData()
        {
            string newName = getNextDataName();

            int rowIndex = gridData.RowsCount ;
            //int rowIndex = gridData.RowsCount - 1;
            gridData.Rows.Insert(rowIndex);

            SourceGrid.Cells.CheckBox cbCell = new SourceGrid.Cells.CheckBox("", false);
            cbCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.Cell titleCell = new SourceGrid.Cells.Cell(newName, typeof(string));
            titleCell.View = getCellView();
            //titleCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            titleCell.AddController(_NameValueChangeController);

            Color lineColor = getNextColor();
            SourceGrid.Cells.Cell colorCell = new SourceGrid.Cells.Cell(lineColor, typeof(Color));
            colorCell.View = getCellView();
            colorCell.View.BackColor = lineColor;
            //colorCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            colorCell.AddController(_ColorValueChangeController);

            SourceGrid.Cells.Cell valueCell = new SourceGrid.Cells.Cell("", typeof(string));
            valueCell.View = getCellView();
            //valueCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            valueCell.AddController(_SeriesValueChangeController);

            SourceGrid.Cells.Editors.TextBoxButton button = new SourceGrid.Cells.Editors.TextBoxButton(typeof(string));            
            valueCell.Editor = button;
            button.Control.Button.Click += Button_Click;

            SourceGrid.Cells.Editors.NumericUpDown nudEditor = new SourceGrid.Cells.Editors.NumericUpDown(typeof(int), 10, 1, 1);
            SourceGrid.Cells.Cell lineWidthCell = new SourceGrid.Cells.Cell(1, nudEditor);
            lineWidthCell.View = getCellView();
            lineWidthCell.AddController(_LineWidthValueChangeController);

            SourceGrid.Cells.Editors.ComboBox cbEditor2 = getMarkerComboBoxEditor();
            SourceGrid.Cells.Cell markerCell = new SourceGrid.Cells.Cell(MarkerType.Diamond, cbEditor2);
            markerCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            markerCell.View = SourceGrid.Cells.Views.ComboBox.Default;
            markerCell.AddController(_MarkerValueChangeController);

            Color markerColor = getNextColor();
            SourceGrid.Cells.Cell markerColorCell = new SourceGrid.Cells.Cell(markerColor, typeof(Color));
            markerColorCell.View = getCellView();
            markerColorCell.View.BackColor = markerColor;
            markerColorCell.AddController(_MarkerColorValueChangeController);

            SourceGrid.Cells.CheckBox cbMarkerVisibleCell = null;
            cbMarkerVisibleCell = new SourceGrid.Cells.CheckBox("", true);

            cbMarkerVisibleCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            cbMarkerVisibleCell.AddController(_MarkerVisibleValueChangeController);

            gridData[rowIndex, 0] = cbCell;
            gridData[rowIndex, 1] = titleCell;
            gridData[rowIndex, 2] = valueCell;
            gridData[rowIndex, 3] = colorCell;
            gridData[rowIndex, 4] = lineWidthCell;
            gridData[rowIndex, 5] = markerCell;
            gridData[rowIndex, 6] = markerColorCell;
            gridData[rowIndex, 7] = cbMarkerVisibleCell;

            Series newSeries = new Series(newName);
            _Chart.Series.Add(newSeries);
        }

        private void Button_Click(object sender, EventArgs e)
        {
            DevAge.Windows.Forms.DevAgeTextBoxButton btn = 
                (DevAge.Windows.Forms.DevAgeTextBoxButton)((Button)sender).Parent;
            
            string strValue = (string)btn.TextBox.Text;

            ExpressionBuilder builder = null;
            if (string.IsNullOrEmpty(strValue))
                builder = new ExpressionBuilder(_Model);
            else
                builder = new ExpressionBuilder(_Model, strValue);

            builder.ShowDialog();

            strValue = builder.Expression;
            //strValue = builder.EventObjectName + "." + builder.StateVariableName;
            btn.TextBox.Text = strValue;
        }

        private string getNextDataName()
        {
            string rslt = "Data 1";
            string expr = @"Data[\s]*([0-9\-]*)";
            if (gridData.Rows.Count == 1)
                return rslt;

            int nextNumber = 0;
            for(int i = 1; i < gridData.Rows.Count; i++)
            {
                string name = (string)gridData[i, 1].Value;
                int number = 0;
                if (Regex.IsMatch(name, expr))
                {
                    Match m = Regex.Match(name, @"\d+");
                    if (int.TryParse(m.Value, out number))
                    {
                        if (number > nextNumber)
                            nextNumber = number;
                    }
                }
            }
            nextNumber++;
            rslt = "Data " + nextNumber;

            return rslt;
        }

        private void CellButton_Click(object sender, EventArgs e)
        {
            SourceGrid.CellContext context = (SourceGrid.CellContext)sender;
            SourceGrid.Cells.Button btnCell = (SourceGrid.Cells.Button)context.Cell;

            string strValue = (string)btnCell.Value;

            ExpressionBuilder builder = null;
            if (string.IsNullOrEmpty(strValue))
                builder = new ExpressionBuilder(_Model);
            else
                builder = new ExpressionBuilder(_Model, strValue);

            builder.ShowDialog();

            strValue = builder.Expression;
            //strValue = builder.EventObjectName + "." + builder.StateVariableName;
            btnCell.Value = strValue;
        }
        
        public void Update(OOMMModel model, AbstractChart chart)
        {
            isUpdating = true;

            _Model = model;
            _Chart = chart;

            showProperties();

            isUpdating = false;
        }

        private bool isUpdating = false;
        private void showProperties()
        {
            //_Model = MainUI.App.ModelExplorer.GetProject(MainUI.App.ModelExplorer.CurrentProject);
            //MainForm.App.getCurrentEditor().BuildModel();

            while(gridData.Rows.Count > 1)
                gridData.Rows.Remove(gridData.Rows.Count - 1) ;
            //drawHeaders();

            List<string> nameList = new List<string>();
            foreach (string name in _Chart.Series.SeriesNames)
            {
                nameList.Add(name);
            }

            nameList.Sort();

            foreach(string name in nameList)
            {
                Series s = _Chart.Series[name];

                InsertData(s);   
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertNewData();

            notityPropertyChangedEvent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (gridData.Rows.Count == 1)
                return;

            int count = 0;
            for(int i = gridData.Rows.Count - 1; i >= 1; i--)
            {
                if (((SourceGrid.Cells.CheckBox)gridData[i, 0]).Checked.GetValueOrDefault())
                {
                    string seriesName = gridData[i, 1].DisplayText;
                    if (!string.IsNullOrEmpty(seriesName))
                        _Chart.Series.Remove(seriesName);
                    gridData.Rows.Remove(i);

                    count++;
                }
            }
            if (count > 0)
                notityPropertyChangedEvent();
        }

        private void notityPropertyChangedEvent()
        {
            if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                PropertyChanged(_Model, _Chart);
        }
    }
    /*
    public delegate void NameValueChangedEventHandler(int row, string oldName, string newName);
    public class NameValueChangedEventController : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event NameValueChangedEventHandler ValueChanged;

        public NameValueChangedEventController()
        {
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

            ValueChanged(sender.Position.Row, e.OldValue == null ? "" : e.OldValue.ToString(), e.NewValue.ToString());
        }
    }

    public delegate void ColorValueChangedEventHandler(int row, Color oldColor, Color newColor);
    public class ColorValueChangedEventController : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event ColorValueChangedEventHandler ValueChanged;

        public ColorValueChangedEventController()
        {
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

            ValueChanged(sender.Position.Row, e.OldValue == null ? Color.Black : (Color)e.OldValue, (Color)e.NewValue);
        }
    }

    public delegate void SeriesValueChangedEventHandler(int row, string oldName, string newName);
    public class SeriesValueChangedEventController : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event SeriesValueChangedEventHandler ValueChanged;

        public SeriesValueChangedEventController()
        {
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

            ValueChanged(sender.Position.Row, e.OldValue == null ? "" : e.OldValue.ToString(), e.NewValue.ToString());
        }
    }
    */
}
