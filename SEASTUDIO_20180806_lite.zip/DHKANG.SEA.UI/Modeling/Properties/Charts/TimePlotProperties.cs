﻿using System.Drawing;
using System.Windows.Forms;
using DHKANG.SEA.UI.OutputView.Visualization;
using Opulos.Core.UI;
using DHKANG.SEA.Model;
using DHKANG.SEA.UI.Modeling.Properties.Charts;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public class TimePlotProperties: AbstractChartProperties
    {
        #region Member Variable
        private ChartTitlePropertiesSection section0;
        private TimePlotDataPropertiesSection section1;
        //private DataPropertiesSection section1;
        private ChartAppearancePropertiesSection section2;
        private TimePlotRangePropertiesSection section3;
        private ChartDimensionPropertiesSection section4;
        #endregion

        //#region Events
        //public event ChartPropertyValueChangedEventHandler PropertyChanged;
        //#endregion

        #region Constructors
        public TimePlotProperties()
            : base()
        {
            section0 = new ChartTitlePropertiesSection();
            addCollapsiblePanel(section0, "Time Plot");

            section1 = new TimePlotDataPropertiesSection();
            addCollapsiblePanel(section1, "Data");

            /*
            section1 = new DataPropertiesSection();
            section1.Dock = DockStyle.Fill;
            section1.Padding = Padding.Empty;
            section1.Margin = Padding.Empty;
            section1.Height = 200;
            acc.Add(section1, "Data", "Data", 0, true);
            */

            section2 = new ChartAppearancePropertiesSection();
            addCollapsiblePanel(section2, "Appearance");

            section3 = new TimePlotRangePropertiesSection();
            addCollapsiblePanel(section3, "Data Range");

            section4 = new ChartDimensionPropertiesSection();
            addCollapsiblePanel(section4, "Dimension");

            section0.PropertyChanged += notifyPropertyChange;
            section1.PropertyChanged += notifyPropertyChange;       
            section2.PropertyChanged += notifyPropertyChange;       
            section4.PropertyChanged += notifyPropertyChange;       
        }
        #endregion

        private bool isUpdating = false;
        protected override void showProperties()
        {
            //string projectName = MainUI.App.ModelExplorer.getCurrentProjectNode().Text;
            //_Model = MainUI.App.ModelExplorer.GetProject(projectName);
            //MainForm.App.getCurrentEditor().BuildModel();
            isUpdating = true;

            section0.Update(_Model, _Chart);
            section1.Update(_Model, _Chart);
            section2.Update(_Model, _Chart);
            section3.Update(_Model, _Chart);
            section4.Update(_Model, _Chart);

            isUpdating = false;
        }
    }
}
