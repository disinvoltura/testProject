﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Northwoods.Go;
using DHKANG.SEA.UI.OutputView;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public partial class AppearancePropertiesSection: UserControl
    {
        private OOMMModel _Model;
        private LabelNode _Node;

        public AppearancePropertiesSection()
        {
            InitializeComponent();
        }

        public void Update(LabelNode node)            
        {
            _Node = node;

            showProperties();
        }

        private bool isUpdating = false;
        private void showProperties()
        {
            _Model = MainUI.App.ModelExplorer.GetProject(MainUI.App.ModelExplorer.CurrentProject);
            //MainForm.App.getCurrentEditor().BuildModel();

            isUpdating = true;
            txtColor.BackColor = _Node.BackgroundColor;

            //TODO Text Alignment
            cbFont.Text = _Node.Font.Name;
            cbFontSize.Text = _Node.FontSize.ToString();
            this.ckBold.Checked = _Node.Bold;
            this.ckItalic.Checked = _Node.Italic;
            this.ckUnderline.Checked = _Node.Underline;

            isUpdating = false;
        }

        private void btnColor_Click(object sender, EventArgs e)
        {
            ColorDialog dialog = new ColorDialog();

            DialogResult rslt = dialog.ShowDialog(this);
            if (rslt == DialogResult.OK)
            {
                txtColor.BackColor = dialog.Color;
            }
        }

        private void pbLeftAlign_Click(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            pbLeftAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_left;
            pbCenterAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_center_disabled;
            pbRightAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_right_disabled;

            pbLeftAlign.Tag = true;
            pbCenterAlign.Tag = false;
            pbRightAlign.Tag = false;

            _Node.Alignment = GoObject.MiddleLeft;
        }

        private void pbCenterAlign_Click(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            pbLeftAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_left_disabled;
            pbCenterAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_center;
            pbRightAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_right_disabled;

            pbLeftAlign.Tag = false;
            pbCenterAlign.Tag = true;
            pbRightAlign.Tag = false;

            _Node.Alignment = GoObject.MiddleCenter;
        }

        private void pbRightAlign_Click(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            pbLeftAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_left_disabled;
            pbCenterAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_center_disabled;
            pbRightAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_right;

            pbLeftAlign.Tag = false;
            pbCenterAlign.Tag = false;
            pbRightAlign.Tag = true;

            _Node.Alignment = GoObject.MiddleRight;
        }

        private void txtColor_BackColorChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;
            _Node.BackgroundColor = txtColor.BackColor;
        }

        private void cbFont_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            //System.Diagnostics.Debug.WriteLine("font:" + cbFont.Text);

            FontStyle fs = FontStyle.Regular;

            if (this.Bold)
                fs = fs | FontStyle.Bold;
            if (this.Italic)
                fs = fs | FontStyle.Italic;
            if (this.Underline)
                fs = fs | FontStyle.Underline;

            _Node.Font = new Font(this.FontName, this.FontSize, fs);
        }

        private string FontName { get { return cbFont.Text; } }

        private float FontSize
        {
            get {
                float size = 10;
                float.TryParse(cbFontSize.Text, out size);
                
                return size;
            }
        }

        private bool Bold {  get { return ckBold.Checked; } }
        private bool Italic {  get { return ckItalic.Checked; } }
        private bool Underline {  get { return ckUnderline.Checked; } }

        private void cbFontSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;
            //System.Diagnostics.Debug.WriteLine("font size:" + cbFontSize.Text);

            _Node.FontSize = this.FontSize;

        }

        private void ckBold_CheckedChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;
            _Node.Bold = ckBold.Checked;
        }

        private void ckItalic_CheckedChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;
            _Node.Italic = ckItalic.Checked;
        }

        private void ckUnderline_CheckedChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;
            _Node.Underline = ckUnderline.Checked;
        }
    }
}
