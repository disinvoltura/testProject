﻿using System.Drawing;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using DHKANG.SEA.UI.OutputView.Visualization;
using Opulos.Core.UI;
using DHKANG.SEA.UI.Modeling.Properties.Charts;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public class BarChartProperties: AbstractChartProperties
    {
        #region Member Variables
        private ChartTitlePropertiesSection section0;
        private DataPropertiesSection section1;
        private ChartAppearancePropertiesSection section2;
        private ChartDimensionPropertiesSection section3;
        #endregion

        #region Constructors
        public BarChartProperties() : base()
        {
            section0 = new ChartTitlePropertiesSection();
            addCollapsiblePanel(section0, "Bar Chart");

            section1 = new DataPropertiesSection();
            addCollapsiblePanel(section1, "Data");

            section2 = new ChartAppearancePropertiesSection();
            addCollapsiblePanel(section2, "Appearance");

            section3 = new ChartDimensionPropertiesSection();
            addCollapsiblePanel(section3, "Dimension");

            section0.PropertyChanged += notifyPropertyChange;
            section1.PropertyChanged += notifyPropertyChange;
            section2.PropertyChanged += notifyPropertyChange;
            section3.PropertyChanged += notifyPropertyChange;
            /*
            section2 = new AppearancePropertiesSection();
            section2.Dock = DockStyle.Fill;
            section2.Padding = Padding.Empty;
            section2.Margin = Padding.Empty;
            acc.Add(section2, "Appearance", "Appearance", 0, true);
            */

            //UserControl panel1 = new UserControl { Margin = Padding.Empty, Padding = Padding.Empty, Dock = DockStyle.Fill };
        }
        #endregion

        private bool isUpdating = false;
        protected override void showProperties()
        {
            //_Model = MainUI.App.ModelExplorer.GetProject(MainUI.App.ModelExplorer.CurrentProject);
            //MainForm.App.getCurrentEditor().BuildModel();
            isUpdating = true;

            section0.Update(_Model, _Chart);
            section1.Update(_Model, _Chart);
            section2.Update(_Model, _Chart);
            section3.Update(_Model, _Chart);

            isUpdating = false;

        }
    }
}
