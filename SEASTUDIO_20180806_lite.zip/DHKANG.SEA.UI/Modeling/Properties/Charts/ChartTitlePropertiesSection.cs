﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Northwoods.Go;
using DHKANG.SEA.UI.OutputView.Visualization;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public delegate void ChartTitlePropertyChangedEventHandler(OOMMModel model, AbstractChart chart);

    public partial class ChartTitlePropertiesSection: UserControl
    {
        #region Member Variables
        private OOMMModel _Model;
        private AbstractChart _Chart;
        #endregion

        #region Events
        public event ChartTitlePropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Constructors
        public ChartTitlePropertiesSection()
        {
            InitializeComponent();
        }
        #endregion

        #region Methods
        public void Update(OOMMModel model, AbstractChart chart)
        {
            _Model = model;
            _Chart = chart;

            showProperties();
        }

        private bool isUpdating = false;
        private void showProperties()
        {
            isUpdating = true;

            txtTitle.Text = _Chart.ChartTitle;
            txtDesc.Text = _Chart.Descrition;

            isUpdating = false;
        }

        private void txtTitle_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTitle_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
                handleTitleChanged();
        }

        private void txtTitle_Leave(object sender, EventArgs e)
        {
            handleTitleChanged();
        }

        private void handleTitleChanged()
        {
            if (isUpdating)
                return;

            if (string.IsNullOrEmpty(txtTitle.Text))
                return;

            _Chart.ChartTitle = txtTitle.Text;

            notifyPropertyChangedEvent();
        }

        private void notifyPropertyChangedEvent()
        {
            if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                PropertyChanged(_Model, _Chart);
        }
        #endregion

        private void ChartTitlePropertiesSection_Load(object sender, EventArgs e)
        {

        }

        private void txtDesc_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDesc_Leave(object sender, EventArgs e)
        {
            handleDescriptionChanged();
        }

        private void txtDesc_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
                handleDescriptionChanged();
        }


        private void handleDescriptionChanged()
        {
            if (isUpdating)
                return;

            if (string.IsNullOrEmpty(txtDesc.Text))
                return;

            _Chart.Descrition = txtDesc.Text;

            notifyPropertyChangedEvent();
        }

    }
}
