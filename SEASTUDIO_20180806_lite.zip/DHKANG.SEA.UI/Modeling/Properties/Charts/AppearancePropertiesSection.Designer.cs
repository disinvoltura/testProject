﻿namespace DHKANG.SEA.UI.Modeling.Properties
{
    partial class AppearancePropertiesSection
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.process1 = new System.Diagnostics.Process();
            this.label2 = new System.Windows.Forms.Label();
            this.txtColor = new System.Windows.Forms.TextBox();
            this.btnColor = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbFont = new System.Windows.Forms.ComboBox();
            this.cbFontSize = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.ckBold = new System.Windows.Forms.CheckBox();
            this.ckItalic = new System.Windows.Forms.CheckBox();
            this.ckUnderline = new System.Windows.Forms.CheckBox();
            this.pbRightAlign = new System.Windows.Forms.PictureBox();
            this.pbCenterAlign = new System.Windows.Forms.PictureBox();
            this.pbLeftAlign = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbRightAlign)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCenterAlign)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLeftAlign)).BeginInit();
            this.SuspendLayout();
            // 
            // process1
            // 
            this.process1.StartInfo.Domain = "";
            this.process1.StartInfo.LoadUserProfile = false;
            this.process1.StartInfo.Password = null;
            this.process1.StartInfo.StandardErrorEncoding = null;
            this.process1.StartInfo.StandardOutputEncoding = null;
            this.process1.StartInfo.UserName = "";
            this.process1.SynchronizingObject = this;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 14);
            this.label2.TabIndex = 0;
            this.label2.Text = "Color:";
            // 
            // txtColor
            // 
            this.txtColor.BackColor = System.Drawing.Color.Black;
            this.txtColor.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtColor.Cursor = System.Windows.Forms.Cursors.No;
            this.txtColor.Location = new System.Drawing.Point(105, 6);
            this.txtColor.Multiline = true;
            this.txtColor.Name = "txtColor";
            this.txtColor.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtColor.Size = new System.Drawing.Size(70, 23);
            this.txtColor.TabIndex = 3;
            this.txtColor.BackColorChanged += new System.EventHandler(this.txtColor_BackColorChanged);
            // 
            // btnColor
            // 
            this.btnColor.Location = new System.Drawing.Point(181, 6);
            this.btnColor.Name = "btnColor";
            this.btnColor.Size = new System.Drawing.Size(34, 23);
            this.btnColor.TabIndex = 4;
            this.btnColor.Text = "...";
            this.btnColor.UseVisualStyleBackColor = true;
            this.btnColor.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 14);
            this.label3.TabIndex = 0;
            this.label3.Text = "Alignment:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 14);
            this.label4.TabIndex = 8;
            this.label4.Text = "Font:";
            // 
            // cbFont
            // 
            this.cbFont.FormattingEnabled = true;
            this.cbFont.Items.AddRange(new object[] {
            "Arial",
            "Calibri",
            "Comic Sans MS",
            "Consolas",
            "Courier New",
            "Georgia",
            "Microsoft Sans Serif",
            "Tahoma",
            "Times New Roman",
            "Verdana"});
            this.cbFont.Location = new System.Drawing.Point(104, 88);
            this.cbFont.Name = "cbFont";
            this.cbFont.Size = new System.Drawing.Size(112, 22);
            this.cbFont.TabIndex = 9;
            this.cbFont.Text = "Arial";
            this.cbFont.SelectedIndexChanged += new System.EventHandler(this.cbFont_SelectedIndexChanged);
            // 
            // cbFontSize
            // 
            this.cbFontSize.FormattingEnabled = true;
            this.cbFontSize.Items.AddRange(new object[] {
            "6",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "16",
            "18",
            "20",
            "24",
            "28",
            "32"});
            this.cbFontSize.Location = new System.Drawing.Point(224, 88);
            this.cbFontSize.Name = "cbFontSize";
            this.cbFontSize.Size = new System.Drawing.Size(39, 22);
            this.cbFontSize.TabIndex = 9;
            this.cbFontSize.Text = "10";
            this.cbFontSize.SelectedIndexChanged += new System.EventHandler(this.cbFontSize_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(269, 92);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 14);
            this.label5.TabIndex = 10;
            this.label5.Text = "pt";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 129);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 14);
            this.label6.TabIndex = 11;
            this.label6.Text = "Style:";
            // 
            // ckBold
            // 
            this.ckBold.AutoSize = true;
            this.ckBold.Location = new System.Drawing.Point(104, 127);
            this.ckBold.Name = "ckBold";
            this.ckBold.Size = new System.Drawing.Size(51, 18);
            this.ckBold.TabIndex = 12;
            this.ckBold.Text = "Bold";
            this.ckBold.UseVisualStyleBackColor = true;
            this.ckBold.CheckedChanged += new System.EventHandler(this.ckBold_CheckedChanged);
            // 
            // ckItalic
            // 
            this.ckItalic.AutoSize = true;
            this.ckItalic.Location = new System.Drawing.Point(162, 127);
            this.ckItalic.Name = "ckItalic";
            this.ckItalic.Size = new System.Drawing.Size(54, 18);
            this.ckItalic.TabIndex = 12;
            this.ckItalic.Text = "Italic";
            this.ckItalic.UseVisualStyleBackColor = true;
            this.ckItalic.CheckedChanged += new System.EventHandler(this.ckItalic_CheckedChanged);
            // 
            // ckUnderline
            // 
            this.ckUnderline.AutoSize = true;
            this.ckUnderline.Location = new System.Drawing.Point(223, 127);
            this.ckUnderline.Name = "ckUnderline";
            this.ckUnderline.Size = new System.Drawing.Size(81, 18);
            this.ckUnderline.TabIndex = 12;
            this.ckUnderline.Text = "Underline";
            this.ckUnderline.UseVisualStyleBackColor = true;
            this.ckUnderline.CheckedChanged += new System.EventHandler(this.ckUnderline_CheckedChanged);
            // 
            // pbRightAlign
            // 
            this.pbRightAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_right_disabled;
            this.pbRightAlign.Location = new System.Drawing.Point(176, 46);
            this.pbRightAlign.Name = "pbRightAlign";
            this.pbRightAlign.Size = new System.Drawing.Size(23, 23);
            this.pbRightAlign.TabIndex = 7;
            this.pbRightAlign.TabStop = false;
            this.pbRightAlign.Click += new System.EventHandler(this.pbRightAlign_Click);
            // 
            // pbCenterAlign
            // 
            this.pbCenterAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_center_disabled;
            this.pbCenterAlign.Location = new System.Drawing.Point(141, 46);
            this.pbCenterAlign.Name = "pbCenterAlign";
            this.pbCenterAlign.Size = new System.Drawing.Size(23, 23);
            this.pbCenterAlign.TabIndex = 6;
            this.pbCenterAlign.TabStop = false;
            this.pbCenterAlign.Click += new System.EventHandler(this.pbCenterAlign_Click);
            // 
            // pbLeftAlign
            // 
            this.pbLeftAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_left;
            this.pbLeftAlign.Location = new System.Drawing.Point(105, 46);
            this.pbLeftAlign.Name = "pbLeftAlign";
            this.pbLeftAlign.Size = new System.Drawing.Size(23, 23);
            this.pbLeftAlign.TabIndex = 5;
            this.pbLeftAlign.TabStop = false;
            this.pbLeftAlign.Click += new System.EventHandler(this.pbLeftAlign_Click);
            // 
            // AppearancePropertiesSection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ckUnderline);
            this.Controls.Add(this.ckItalic);
            this.Controls.Add(this.ckBold);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cbFontSize);
            this.Controls.Add(this.cbFont);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pbRightAlign);
            this.Controls.Add(this.pbCenterAlign);
            this.Controls.Add(this.pbLeftAlign);
            this.Controls.Add(this.btnColor);
            this.Controls.Add(this.txtColor);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "AppearancePropertiesSection";
            this.Size = new System.Drawing.Size(318, 159);
            ((System.ComponentModel.ISupportInitialize)(this.pbRightAlign)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCenterAlign)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLeftAlign)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Diagnostics.Process process1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtColor;
        private System.Windows.Forms.Button btnColor;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pbLeftAlign;
        private System.Windows.Forms.PictureBox pbRightAlign;
        private System.Windows.Forms.PictureBox pbCenterAlign;
        private System.Windows.Forms.ComboBox cbFont;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbFontSize;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox ckBold;
        private System.Windows.Forms.CheckBox ckUnderline;
        private System.Windows.Forms.CheckBox ckItalic;
    }
}
