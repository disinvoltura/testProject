﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Northwoods.Go;
using DHKANG.SEA.UI.OutputView.Visualization;
using System.Text.RegularExpressions;
using SourceGrid.Cells.Editors;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public delegate void DataPropertyChangedEventHandler(OOMMModel model, AbstractChart chart);
    public partial class DataPropertiesSection: UserControl
    {
        #region Member Variables
        private OOMMModel _Model;
        private AbstractChart _Chart;

        private NameValueChangedEventController _NameValueChangeController;
        private ColorValueChangedEventController _ColorValueChangeController;
        private SeriesValueChangedEventController _SeriesValueChangeController;
        #endregion

        #region Events
        public event DataPropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Constructors
        public DataPropertiesSection()
        {
            InitializeComponent();

            drawHeaders();
        }
        #endregion

        private void drawHeaders()
        {
            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Snow;
            backHeader.Border = DevAge.Drawing.RectangleBorder.NoBorder;
            titleModel.Background = backHeader;
            //titleModel.BackColor = Color.SteelBlue;
            //titleModel.ForeColor = Color.White;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            gridData.BorderStyle = BorderStyle.FixedSingle;
            gridData.Redim(1, 4);
            gridData.FixedRows = 1;
            gridData.Font = new Font("Calibe", 10);
            //1st Header Row
            gridData.Rows.Insert(0);

            SourceGrid.Cells.ColumnHeader titleHeader = new SourceGrid.Cells.ColumnHeader("Title");
            titleHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.ColumnHeader colorHeader = new SourceGrid.Cells.ColumnHeader("Color");
            colorHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.ColumnHeader valueHeader = new SourceGrid.Cells.ColumnHeader("Value");
            valueHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            titleHeader.AutomaticSortEnabled = true;
            colorHeader.AutomaticSortEnabled = false;
            valueHeader.AutomaticSortEnabled = false;

            //gridData[0, 0] = valueHeader;
            gridData[0, 1] = titleHeader;
            gridData[0, 2] = colorHeader;
            gridData[0, 3] = valueHeader;

            gridData.Columns[3].Width = 200;

            _NameValueChangeController = new NameValueChangedEventController();
            _NameValueChangeController.ValueChanged +=
                new NameValueChangedEventHandler(OnNameValueChange);

            _ColorValueChangeController = new ColorValueChangedEventController();
            _ColorValueChangeController.ValueChanged +=
                new ColorValueChangedEventHandler(OnColorValueChange);

            _SeriesValueChangeController = new SeriesValueChangedEventController();
            _SeriesValueChangeController.ValueChanged +=
                new SeriesValueChangedEventHandler(OnSeriesValueChange);
        }

        private void OnNameValueChange(int row, string oldName, string newName)
        {
            if (_Chart.Series[oldName] != null)
            {
                Series s = _Chart.Series[oldName];
                _Chart.Series.Remove(oldName);
                s.Name = newName;
                _Chart.Series.Add(s);

                notityPropertyChangedEvent();
            }

            /*
            updateNextEventEditor(oldEventName, newEventName);

            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
                this.Changed("eventvertex", "changed", oldEventName, newEventName);
            */
        }

        private void OnColorValueChange(int row, Color oldValue, Color newValue)
        {
            string seriesName = (string)gridData[row, 1].Value;

            if (_Chart.Series[seriesName] != null)
            {
                Series s = _Chart.Series[seriesName];
                s.LineColor = newValue;// Color.FromName(newValue);                

                gridData[row, 2].View.BackColor = newValue;

                notityPropertyChangedEvent();
            }
        }

        private void OnSeriesValueChange(int row, string oldValue, string newValue)
        {
            string seriesName = (string)gridData[row, 1].Value;

            if (_Chart.Series[seriesName] != null)
            {
                Series s = _Chart.Series[seriesName];
                s.Value = newValue;

                notityPropertyChangedEvent();
            }
        }

        public void InsertData(Series dataSeries)
        {
            int rowIndex = gridData.RowsCount;
            //int rowIndex = gridData.RowsCount - 1;
            gridData.Rows.Insert(rowIndex);

            SourceGrid.Cells.CheckBox cbCell = new SourceGrid.Cells.CheckBox("", false);
            cbCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            
            SourceGrid.Cells.Cell titleCell = new SourceGrid.Cells.Cell(dataSeries.Name, typeof(string));
            titleCell.View = getCellView();
            //titleCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            titleCell.AddController(_NameValueChangeController);

            SourceGrid.Cells.Cell colorCell = new SourceGrid.Cells.Cell(dataSeries.LineColor, typeof(Color));
            colorCell.View = getCellView();
            colorCell.View.BackColor = dataSeries.LineColor;
            //colorCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            colorCell.AddController(_ColorValueChangeController);

            SourceGrid.Cells.Cell valueCell = new SourceGrid.Cells.Cell(dataSeries.Value, typeof(string));
            valueCell.View = getCellView();
            //valueCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.Editors.TextBoxButton button = new SourceGrid.Cells.Editors.TextBoxButton(typeof(string));
            valueCell.Editor = button;
            button.Control.Button.Click += Button_Click;
            valueCell.AddController(_SeriesValueChangeController);

            /*
            SourceGrid.Cells.Button valueCell = new SourceGrid.Cells.Button(dataSeries.Value);
            SourceGrid.Cells.Controllers.Button buttonClickEvent = new SourceGrid.Cells.Controllers.Button();
            buttonClickEvent.Executed += new EventHandler(CellButton_Click);
            //valueCell.Tag = variable.InitialValue;
            valueCell.Controller.AddController(buttonClickEvent);
            valueCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            //SourceGrid.Cells.Cell valueCell = new SourceGrid.Cells.Cell(variable.InitialValue, typeof(string));
            //valueCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            */

            gridData[rowIndex, 0] = cbCell;
            gridData[rowIndex, 1] = titleCell;
            gridData[rowIndex, 2] = colorCell;
            gridData[rowIndex, 3] = valueCell;            
        }

        private SourceGrid.Cells.Views.Cell getCellView()
        {
            SourceGrid.Cells.Views.Cell cellModel = new SourceGrid.Cells.Views.Cell();
            DevAge.Drawing.VisualElements.BackgroundSolid bg = new DevAge.Drawing.VisualElements.BackgroundSolid();
            bg.BackColor = Color.White;
            cellModel.Background = bg;
            cellModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            return cellModel;
        }

        Random r = new Random();
        private Color getNextColor()
        {
            KnownColor[] colorList = (KnownColor[])KnownColor.GetValues(typeof(KnownColor));
            KnownColor kc = colorList[r.Next(0, colorList.Length)];
            return Color.FromKnownColor(kc);
        }

        public void InsertNewData()
        {
            string newName = getNextDataName();

            int rowIndex = gridData.RowsCount ;
            //int rowIndex = gridData.RowsCount - 1;
            gridData.Rows.Insert(rowIndex);

            SourceGrid.Cells.CheckBox cbCell = new SourceGrid.Cells.CheckBox("", false);
            cbCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.Cell titleCell = new SourceGrid.Cells.Cell(newName, typeof(string));
            titleCell.View = getCellView();
            //titleCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            titleCell.AddController(_NameValueChangeController);

            Color lineColor = getNextColor();
            SourceGrid.Cells.Cell colorCell = new SourceGrid.Cells.Cell(lineColor, typeof(Color));
            colorCell.View = getCellView();
            colorCell.View.BackColor = lineColor;
            //colorCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            colorCell.AddController(_ColorValueChangeController);

            SourceGrid.Cells.Cell valueCell = new SourceGrid.Cells.Cell("", typeof(string));
            valueCell.View = getCellView();
            //valueCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            valueCell.AddController(_SeriesValueChangeController);

            SourceGrid.Cells.Editors.TextBoxButton button = new SourceGrid.Cells.Editors.TextBoxButton(typeof(string));            
            valueCell.Editor = button;
            button.Control.Button.Click += Button_Click;

            //SourceGrid.Cells.Controllers.Button buttonClickEvent = new SourceGrid.Cells.Controllers.Button();
            //buttonClickEvent.Executed += new EventHandler(CellButton_Click);


            /*
            SourceGrid.Cells.Button valueCell = new SourceGrid.Cells.Button("");            
            SourceGrid.Cells.Controllers.Button buttonClickEvent = new SourceGrid.Cells.Controllers.Button();
            buttonClickEvent.Executed += new EventHandler(CellButton_Click);
            valueCell.Controller.AddController(buttonClickEvent);
            valueCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            */
            gridData[rowIndex, 0] = cbCell;
            gridData[rowIndex, 1] = titleCell;
            gridData[rowIndex, 2] = colorCell;
            gridData[rowIndex, 3] = valueCell;

            Series newSeries = new Series(newName);
            _Chart.Series.Add(newSeries);
        }

        private void Button_Click(object sender, EventArgs e)
        {
            DevAge.Windows.Forms.DevAgeTextBoxButton btn = 
                (DevAge.Windows.Forms.DevAgeTextBoxButton)((Button)sender).Parent;
            
            string strValue = (string)btn.TextBox.Text;

            ExpressionBuilder builder = null;
            if (string.IsNullOrEmpty(strValue))
                builder = new ExpressionBuilder(_Model);
            else
                builder = new ExpressionBuilder(_Model, strValue);

            builder.ShowDialog();

            strValue = builder.Expression;
            //strValue = builder.EventObjectName + "." + builder.StateVariableName;
            btn.TextBox.Text = strValue;
        }

        private string getNextDataName()
        {
            string rslt = "Data 1";
            string expr = @"Data[\s]*([0-9\-]*)";
            if (gridData.Rows.Count == 1)
                return rslt;

            int nextNumber = 0;
            for(int i = 1; i < gridData.Rows.Count; i++)
            {
                string name = (string)gridData[i, 1].Value;
                int number = 0;
                if (Regex.IsMatch(name, expr))
                {
                    Match m = Regex.Match(name, @"\d+");
                    if (int.TryParse(m.Value, out number))
                    {
                        if (number > nextNumber)
                            nextNumber = number;
                    }
                }
            }
            nextNumber++;
            rslt = "Data " + nextNumber;

            return rslt;
        }

        private void CellButton_Click(object sender, EventArgs e)
        {
            SourceGrid.CellContext context = (SourceGrid.CellContext)sender;
            SourceGrid.Cells.Button btnCell = (SourceGrid.Cells.Button)context.Cell;

            string strValue = (string)btnCell.Value;

            ExpressionBuilder builder = null;
            if (string.IsNullOrEmpty(strValue))
                builder = new ExpressionBuilder(_Model);
            else
                builder = new ExpressionBuilder(_Model, strValue);

            builder.ShowDialog();

            strValue = builder.Expression;
            //strValue = builder.EventObjectName + "." + builder.StateVariableName;
            btnCell.Value = strValue;
        }
        
        public void Update(OOMMModel model, AbstractChart chart)
        {
            isUpdating = true;

            _Model = model;
            _Chart = chart;

            showProperties();

            isUpdating = false;
        }

        private bool isUpdating = false;
        private void showProperties()
        {
            //_Model = MainUI.App.ModelExplorer.GetProject(MainUI.App.ModelExplorer.CurrentProject);
            //MainForm.App.getCurrentEditor().BuildModel();

            while(gridData.Rows.Count > 1)
                gridData.Rows.Remove(gridData.Rows.Count - 1) ;
            //drawHeaders();

            List<string> nameList = new List<string>();
            foreach (string name in _Chart.Series.SeriesNames)
            {
                nameList.Add(name);
            }

            nameList.Sort();

            foreach(string name in nameList)
            {
                Series s = _Chart.Series[name];

                InsertData(s);   
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertNewData();

            notityPropertyChangedEvent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (gridData.Rows.Count == 1)
                return;

            int count = 0;
            for(int i = gridData.Rows.Count - 1; i >= 1; i--)
            {
                if (((SourceGrid.Cells.CheckBox)gridData[i, 0]).Checked.GetValueOrDefault())
                {
                    string seriesName = gridData[i, 1].DisplayText;
                    if (!string.IsNullOrEmpty(seriesName))
                        _Chart.Series.Remove(seriesName);
                    gridData.Rows.Remove(i);

                    count++;
                }
            }
            if (count > 0)
                notityPropertyChangedEvent();
        }

        private void notityPropertyChangedEvent()
        {
            if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                PropertyChanged(_Model, _Chart);
        }
    }

    public delegate void NameValueChangedEventHandler(int row, string oldName, string newName);
    public class NameValueChangedEventController : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event NameValueChangedEventHandler ValueChanged;

        public NameValueChangedEventController()
        {
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

            ValueChanged(sender.Position.Row, e.OldValue == null ? "" : e.OldValue.ToString(), e.NewValue.ToString());
        }
    }

    public delegate void ColorValueChangedEventHandler(int row, Color oldColor, Color newColor);
    public class ColorValueChangedEventController : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event ColorValueChangedEventHandler ValueChanged;

        public ColorValueChangedEventController()
        {
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

            ValueChanged(sender.Position.Row, e.OldValue == null ? Color.Black : (Color)e.OldValue, (Color)e.NewValue);
        }
    }

    public delegate void SeriesValueChangedEventHandler(int row, string oldName, string newName);
    public class SeriesValueChangedEventController : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event SeriesValueChangedEventHandler ValueChanged;

        public SeriesValueChangedEventController()
        {
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

            ValueChanged(sender.Position.Row, e.OldValue == null ? "" : e.OldValue.ToString(), e.NewValue.ToString());
        }
    }
}
