﻿using System.Drawing;
using System.Windows.Forms;
using DHKANG.SEA.UI.OutputView.Visualization;
using Opulos.Core.UI;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public class PlotProperties: AccordionPanel
    {
        #region Member Variables
        private Plot _Plot;
        private OOMMModel _Model;

        private PlotPropertiesSection section0;
        private AdvancedDataPropertiesSection section1;
        private ChartAppearancePropertiesSection section2;
        private ChartDimensionPropertiesSection section3;
        #endregion

        #region Events
        public event ChartPropertyValueChangedEventHandler PropertyChanged;
        #endregion

        #region Constructors
        public PlotProperties()
        {
            acc.Insets = new Padding(10);
            acc.ContentPadding = new Padding(10);
            acc.ContentMargin = new Padding(2);
            acc.CheckBoxMargin = new Padding(2);

            section0 = new PlotPropertiesSection();
            section0.Dock = DockStyle.Fill;
            section0.Padding = Padding.Empty;
            section0.Margin = Padding.Empty;
            acc.Add(section0, "Plot", "Plot", 0, true);

            section1 = new AdvancedDataPropertiesSection();
            section1.Dock = DockStyle.Fill;
            section1.Padding = Padding.Empty;
            section1.Margin = Padding.Empty;
            section1.Height = 200;
            acc.Add(section1, "Advanced Data", "Advanced Data", 0, true);

            section2 = new ChartAppearancePropertiesSection();
            section2.Dock = DockStyle.Fill;
            section2.Padding = Padding.Empty;
            section2.Margin = Padding.Empty;
            acc.Add(section2, "Appearance", "Appearance", 0, true);

            section0.PropertyChanged += OnPropertyChanged;
            section1.PropertyChanged += OnPropertyChanged;
            section2.PropertyChanged += OnPropertyChanged;
        }
        #endregion

        private void OnPropertyChanged(OOMMModel model, AbstractChart chart)
        {
            if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                PropertyChanged(model, chart);
        }

        public void Update(OOMMModel model, Plot plot)
        {
            _Model = model;
            _Plot = plot;
            
            showProperties();
        }

        private bool isUpdating = false;
        private void showProperties()
        {
            //_Model = MainUI.App.ModelExplorer.GetProject(MainUI.App.ModelExplorer.CurrentProject);
            //MainForm.App.getCurrentEditor().BuildModel();
            isUpdating = true;

            section0.Update(_Model, _Plot);
            section1.Update(_Model, _Plot);
            section2.Update(_Model, _Plot);

            isUpdating = false;
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.ResumeLayout(false);
        }
    }
}
