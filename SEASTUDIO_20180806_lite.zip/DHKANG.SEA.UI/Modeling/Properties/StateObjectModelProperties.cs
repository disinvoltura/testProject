﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.StateObjects;

namespace DHKANG.SEA.UI.Modeling
{
    public delegate void ObjectModelPropertyChangedEventHandler(Guid id, string propertyName, object oldValue, object newValue);

    public partial class StateObjectModelProperties : UserControl
    {
        #region Member Variables
        private OOSGStateObjectModel _OM;
        private bool _IsUpdating = false;
        #endregion

        #region Events
        public event ObjectModelPropertyChangedEventHandler PropertyValueChanged;
        #endregion

        #region Properties
        #endregion

        public StateObjectModelProperties()
        {
            InitializeComponent();
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            
        }
   
        public void Update(OOSGStateObjectModel om)
        {
            _IsUpdating = true;

            _OM = om;
            txtName.Text = _OM.Name;
            txtDesc.Text = _OM.Description;

            if (_OM.BackgroundColor == 0)
                _OM.BackgroundColor = Color.White.ToArgb();

            txtColor.BackColor = Color.FromArgb(_OM.BackgroundColor);

            _IsUpdating = false;
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            handleNameChanged();
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleNameChanged();
            }
        }

        private void handleNameChanged()
        {
            if (_IsUpdating)
                return;

            if (string.IsNullOrEmpty(txtName.Text))
                return;

            string oldValue = _OM.Name;
            string newValue = txtName.Text;

            if (!newValue.Equals(oldValue))
            {
                _OM.Name = newValue;

                if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                    PropertyValueChanged(_OM.ID, "name", oldValue, newValue);
            }
        }

        private void txtDesc_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleDescChanged();
            }
        }

        private void txtDesc_Leave(object sender, EventArgs e)
        {
            handleDescChanged();
        }

        private void handleDescChanged()
        {
            if (_IsUpdating)
                return;

            if (string.IsNullOrEmpty(txtDesc.Text))
                return;

            string oldValue = _OM.Description;
            string newValue = txtDesc.Text;

            if (!newValue.Equals(oldValue))
            {
                _OM.Description = newValue;

                if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                    PropertyValueChanged(_OM.ID, "description", oldValue, newValue);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            colorDialog1.Color = txtColor.BackColor;
            DialogResult rslt = colorDialog1.ShowDialog(this);

            if (rslt == DialogResult.OK)
            {
                Color oldValue = txtColor.BackColor;

                txtColor.BackColor = colorDialog1.Color;
                _OM.BackgroundColor = txtColor.BackColor.ToArgb();

                if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                    PropertyValueChanged(_OM.ID, "backgroundcolor", oldValue, colorDialog1.Color);

            }

        }
    }
}
