﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using System.Text.RegularExpressions;
using ICSharpCode.TextEditor.Document;
using DHKANG.SEA.Model.Data;
using DHKANG.SEA.UI.STTEditor;

namespace DHKANG.SEA.UI.Modeling
{
    public partial class DBDataSourceProperties : UserControl
    {
        #region Member Variables
        private MainUI _Parent;
        //private OOEGModelEditor _ModelEditor;
        private OOMMDataSource _CurrentDataSource;
        private OOMMModel _Model;
        #endregion

        #region Events
        public event DataSourceChangedEventHandler DataSourceChanged;
        #endregion

        #region Properties

        #endregion

        public DBDataSourceProperties()
        {
            InitializeComponent();

            HighlightingManager.Manager.AddSyntaxModeFileProvider(
                 new AppSyntaxModeProvider());

            queryEditor.SetHighlighting("SQL");
        }

        public void UpdateCurrentDataSource()
        {
            _CurrentDataSource.Name = txtName.Text;
            _CurrentDataSource.DatabaseType = OOMMDatabaseType.SQLSERVER;
            if (cbDBType.SelectedIndex == 1)
                _CurrentDataSource.DatabaseType = OOMMDatabaseType.MYSQL;
            else if (cbDBType.SelectedIndex == 2)
                _CurrentDataSource.DatabaseType = OOMMDatabaseType.ORACLE;

            _CurrentDataSource.ConnectionString = txtConnStr.Text;
            _CurrentDataSource.Query = queryEditor.Text;

            if (DataSourceChanged != null && DataSourceChanged.GetInvocationList().Length > 0)
                DataSourceChanged(_CurrentDataSource);
        }

        public void ShowDataSource(OOMMModel model, OOMMDataSource ds)
        {
            _Model = model;
            _CurrentDataSource = ds;

            txtName.Text = ds.Name;

            if (ds.DatabaseType == OOMMDatabaseType.SQLSERVER)
            {
                cbDBType.SelectedIndex = 0;
            } else if (ds.DatabaseType == OOMMDatabaseType.MYSQL)
            {
                cbDBType.SelectedIndex = 1;
            } else if (ds.DatabaseType == OOMMDatabaseType.ORACLE)
            {
                cbDBType.SelectedIndex = 2;
            }

            txtConnStr.Text = ds.ConnectionString;
            queryEditor.Text = ds.Query;

        }

        private void cbDBType_SelectedIndexChanged(object sender, EventArgs e)
        {
            OOMMDatabaseType oldValue = _CurrentDataSource.DatabaseType;
            OOMMDatabaseType newValue = OOMMDatabaseType.SQLSERVER;
            if (cbDBType.SelectedIndex == 1)
                newValue= OOMMDatabaseType.MYSQL;
            else if (cbDBType.SelectedIndex == 2)
                newValue = OOMMDatabaseType.ORACLE;

            _CurrentDataSource.DatabaseType = newValue;

            if (DataSourceChanged != null && DataSourceChanged.GetInvocationList().Length > 0)
                DataSourceChanged(_CurrentDataSource);
        }

        private void txtConnStr_TextChanged(object sender, EventArgs e)
        {
            string oldValue = _CurrentDataSource.ConnectionString;
            string newValue = txtConnStr.Text;

            _CurrentDataSource.ConnectionString = newValue;

            if (DataSourceChanged != null && DataSourceChanged.GetInvocationList().Length > 0)
                DataSourceChanged(_CurrentDataSource);
        }

        private void queryEditor_TextChanged(object sender, EventArgs e)
        {
            string oldValue = _CurrentDataSource.Query;
            string newValue = queryEditor.Text;

            _CurrentDataSource.Query = newValue;

            if (DataSourceChanged != null && DataSourceChanged.GetInvocationList().Length > 0)
                DataSourceChanged(_CurrentDataSource);
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleNameChanged();
            }
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            handleNameChanged();
        }

        private void handleNameChanged()
        {
            string oldValue = _CurrentDataSource.Name;
            string newValue = txtName.Text;

            _CurrentDataSource.Name = newValue;

            if (DataSourceChanged != null && DataSourceChanged.GetInvocationList().Length > 0)
                DataSourceChanged(_CurrentDataSource);
        }
    }
}