﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using DHKANG.SEA.Model.Data;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI.Modeling
{
    public delegate void DataSourceChangedEventHandler(OOMMDataSource changedValue);

    public partial class CSVDataSourceProperties : UserControl
    {
        #region Member Variables
        private MainUI _Parent;        
        private OOMMDataSource _CurrentDataSource;
        private OOMMModel _Model;
        #endregion

        #region Events
        public event DataSourceChangedEventHandler DataSourceChanged;
        #endregion

        #region Properties
        
        #endregion

        public CSVDataSourceProperties()
        {
            InitializeComponent();
        }
        
       

        public void UpdateCurrentDataSources()
        {
            _CurrentDataSource.Name = txtName.Text;
            _CurrentDataSource.FileName = txtFileName.Text;
            
            if (DataSourceChanged != null && DataSourceChanged.GetInvocationList().Length > 0)
                DataSourceChanged(_CurrentDataSource);
        }

        public void ShowDataSource(OOMMModel model, OOMMDataSource ds)
        {
            _Model = model;
            _CurrentDataSource = ds;

            txtName.Text = ds.Name;
            txtFileName.Text = ds.FileName;
        }

        private void btnChooseCSV_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "CSV Files (*.csv)|*.csv|All files (*.*)|*.*";
            ofd.DefaultExt = "xls";

            if (string.IsNullOrEmpty(txtFileName.Text))
            {
                ofd.FileName = txtFileName.Text;
            }

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                txtFileName.Text = ofd.FileName;
            }

        }

        private void txtFileName_TextChanged(object sender, EventArgs e)
        {
            string oldValue = _CurrentDataSource.FileName;
            string newValue = txtFileName.Text;

            _CurrentDataSource.FileName = newValue;

            if (DataSourceChanged != null && DataSourceChanged.GetInvocationList().Length > 0)
                DataSourceChanged(_CurrentDataSource);

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {            
        }

        private void handleNameChanged()
        {
            string oldValue = _CurrentDataSource.Name;
            string newValue = txtName.Text;

            _CurrentDataSource.Name = newValue;

            if (DataSourceChanged != null && DataSourceChanged.GetInvocationList().Length > 0)
                DataSourceChanged(_CurrentDataSource);
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleNameChanged();
            }
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            handleNameChanged();
        }
    }    
}
