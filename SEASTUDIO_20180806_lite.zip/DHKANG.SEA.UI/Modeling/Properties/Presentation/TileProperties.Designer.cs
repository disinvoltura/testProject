﻿namespace DHKANG.SEA.UI.Modeling.Properties
{
    partial class TileProperties
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.process1 = new System.Diagnostics.Process();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.bgColor = new System.Windows.Forms.TextBox();
            this.btnColor = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbFont = new System.Windows.Forms.ComboBox();
            this.cbFontSize = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.ckBold = new System.Windows.Forms.CheckBox();
            this.ckItalic = new System.Windows.Forms.CheckBox();
            this.ckUnderline = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.cbStateVariables = new System.Windows.Forms.ComboBox();
            this.cbObjects = new System.Windows.Forms.ComboBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtExpr = new System.Windows.Forms.TextBox();
            this.lblExpr = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.rbSV = new System.Windows.Forms.RadioButton();
            this.rbExpr = new System.Windows.Forms.RadioButton();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.btnNameColor = new System.Windows.Forms.Button();
            this.nameColor = new System.Windows.Forms.TextBox();
            this.btnValueColor = new System.Windows.Forms.Button();
            this.valueColor = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.borderColor = new System.Windows.Forms.TextBox();
            this.btnBorderColor = new System.Windows.Forms.Button();
            this.pbRightAlign = new System.Windows.Forms.PictureBox();
            this.pbCenterAlign = new System.Windows.Forms.PictureBox();
            this.pbLeftAlign = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbRightAlign)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCenterAlign)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLeftAlign)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // process1
            // 
            this.process1.StartInfo.Domain = "";
            this.process1.StartInfo.LoadUserProfile = false;
            this.process1.StartInfo.Password = null;
            this.process1.StartInfo.StandardErrorEncoding = null;
            this.process1.StartInfo.StandardOutputEncoding = null;
            this.process1.StartInfo.UserName = "";
            this.process1.SynchronizingObject = this;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 151);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "Object:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 300);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 14);
            this.label2.TabIndex = 0;
            this.label2.Text = "Background Color:";
            // 
            // bgColor
            // 
            this.bgColor.BackColor = System.Drawing.Color.Black;
            this.bgColor.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bgColor.Cursor = System.Windows.Forms.Cursors.No;
            this.bgColor.Location = new System.Drawing.Point(129, 296);
            this.bgColor.Multiline = true;
            this.bgColor.Name = "bgColor";
            this.bgColor.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bgColor.Size = new System.Drawing.Size(70, 23);
            this.bgColor.TabIndex = 3;
            this.bgColor.BackColorChanged += new System.EventHandler(this.txtColor_BackColorChanged);
            // 
            // btnColor
            // 
            this.btnColor.Location = new System.Drawing.Point(205, 296);
            this.btnColor.Name = "btnColor";
            this.btnColor.Size = new System.Drawing.Size(34, 23);
            this.btnColor.TabIndex = 4;
            this.btnColor.Text = "...";
            this.btnColor.UseVisualStyleBackColor = true;
            this.btnColor.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(256, 300);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 14);
            this.label3.TabIndex = 0;
            this.label3.Text = "Alignment:";
            this.label3.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(256, 342);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 14);
            this.label4.TabIndex = 8;
            this.label4.Text = "Font:";
            this.label4.Visible = false;
            // 
            // cbFont
            // 
            this.cbFont.FormattingEnabled = true;
            this.cbFont.Items.AddRange(new object[] {
            "Arial",
            "Calibri",
            "Comic Sans MS",
            "Consolas",
            "Courier New",
            "Georgia",
            "Microsoft Sans Serif",
            "Tahoma",
            "Times New Roman",
            "Verdana"});
            this.cbFont.Location = new System.Drawing.Point(333, 338);
            this.cbFont.Name = "cbFont";
            this.cbFont.Size = new System.Drawing.Size(112, 22);
            this.cbFont.TabIndex = 9;
            this.cbFont.Text = "Arial";
            this.cbFont.Visible = false;
            this.cbFont.SelectedIndexChanged += new System.EventHandler(this.cbFont_SelectedIndexChanged);
            // 
            // cbFontSize
            // 
            this.cbFontSize.FormattingEnabled = true;
            this.cbFontSize.Items.AddRange(new object[] {
            "6",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "16",
            "18",
            "20",
            "24",
            "28",
            "32"});
            this.cbFontSize.Location = new System.Drawing.Point(453, 338);
            this.cbFontSize.Name = "cbFontSize";
            this.cbFontSize.Size = new System.Drawing.Size(39, 22);
            this.cbFontSize.TabIndex = 9;
            this.cbFontSize.Text = "10";
            this.cbFontSize.Visible = false;
            this.cbFontSize.SelectedIndexChanged += new System.EventHandler(this.cbFontSize_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(498, 342);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 14);
            this.label5.TabIndex = 10;
            this.label5.Text = "pt";
            this.label5.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(256, 379);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 14);
            this.label6.TabIndex = 11;
            this.label6.Text = "Style:";
            this.label6.Visible = false;
            // 
            // ckBold
            // 
            this.ckBold.AutoSize = true;
            this.ckBold.Location = new System.Drawing.Point(333, 377);
            this.ckBold.Name = "ckBold";
            this.ckBold.Size = new System.Drawing.Size(51, 18);
            this.ckBold.TabIndex = 12;
            this.ckBold.Text = "Bold";
            this.ckBold.UseVisualStyleBackColor = true;
            this.ckBold.Visible = false;
            this.ckBold.CheckedChanged += new System.EventHandler(this.ckBold_CheckedChanged);
            // 
            // ckItalic
            // 
            this.ckItalic.AutoSize = true;
            this.ckItalic.Location = new System.Drawing.Point(391, 377);
            this.ckItalic.Name = "ckItalic";
            this.ckItalic.Size = new System.Drawing.Size(54, 18);
            this.ckItalic.TabIndex = 12;
            this.ckItalic.Text = "Italic";
            this.ckItalic.UseVisualStyleBackColor = true;
            this.ckItalic.Visible = false;
            this.ckItalic.CheckedChanged += new System.EventHandler(this.ckItalic_CheckedChanged);
            // 
            // ckUnderline
            // 
            this.ckUnderline.AutoSize = true;
            this.ckUnderline.Location = new System.Drawing.Point(452, 377);
            this.ckUnderline.Name = "ckUnderline";
            this.ckUnderline.Size = new System.Drawing.Size(81, 18);
            this.ckUnderline.TabIndex = 12;
            this.ckUnderline.Text = "Underline";
            this.ckUnderline.UseVisualStyleBackColor = true;
            this.ckUnderline.Visible = false;
            this.ckUnderline.CheckedChanged += new System.EventHandler(this.ckUnderline_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(114)))), ((int)(((byte)(198)))));
            this.panel1.Controls.Add(this.label8);
            this.panel1.Location = new System.Drawing.Point(0, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(578, 25);
            this.panel1.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(16, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(33, 19);
            this.label8.TabIndex = 0;
            this.label8.Text = "Tile";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(16, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 19);
            this.label9.TabIndex = 0;
            this.label9.Text = "Appearance";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(114)))), ((int)(((byte)(198)))));
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(0, 253);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(578, 25);
            this.panel2.TabIndex = 16;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Location = new System.Drawing.Point(2, 587);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(575, 20);
            this.panel3.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(33, 187);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 14);
            this.label7.TabIndex = 0;
            this.label7.Text = "State Variable:";
            // 
            // cbStateVariables
            // 
            this.cbStateVariables.FormattingEnabled = true;
            this.cbStateVariables.Location = new System.Drawing.Point(129, 183);
            this.cbStateVariables.Name = "cbStateVariables";
            this.cbStateVariables.Size = new System.Drawing.Size(164, 22);
            this.cbStateVariables.TabIndex = 13;
            this.cbStateVariables.SelectedIndexChanged += new System.EventHandler(this.cbStateVariables_SelectedIndexChanged);
            // 
            // cbObjects
            // 
            this.cbObjects.FormattingEnabled = true;
            this.cbObjects.Location = new System.Drawing.Point(129, 147);
            this.cbObjects.Name = "cbObjects";
            this.cbObjects.Size = new System.Drawing.Size(164, 22);
            this.cbObjects.TabIndex = 13;
            this.cbObjects.SelectedIndexChanged += new System.EventHandler(this.cbEventObjects_SelectedIndexChanged);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(112, 40);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(181, 22);
            this.txtName.TabIndex = 21;
            this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            this.txtName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtName_KeyDown);
            this.txtName.Leave += new System.EventHandler(this.txtName_Leave);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(17, 44);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 14);
            this.label10.TabIndex = 20;
            this.label10.Text = "Name:";
            // 
            // btnAdd
            // 
            this.btnAdd.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnAdd.Location = new System.Drawing.Point(299, 183);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(23, 23);
            this.btnAdd.TabIndex = 22;
            this.btnAdd.Text = "+";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Visible = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtExpr
            // 
            this.txtExpr.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtExpr.Location = new System.Drawing.Point(129, 218);
            this.txtExpr.Name = "txtExpr";
            this.txtExpr.Size = new System.Drawing.Size(345, 22);
            this.txtExpr.TabIndex = 23;
            this.txtExpr.Visible = false;
            // 
            // lblExpr
            // 
            this.lblExpr.AutoSize = true;
            this.lblExpr.Location = new System.Drawing.Point(33, 222);
            this.lblExpr.Name = "lblExpr";
            this.lblExpr.Size = new System.Drawing.Size(69, 14);
            this.lblExpr.TabIndex = 24;
            this.lblExpr.Text = "Expression:";
            this.lblExpr.Visible = false;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(114)))), ((int)(((byte)(198)))));
            this.panel4.Controls.Add(this.label12);
            this.panel4.Location = new System.Drawing.Point(0, 78);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(578, 25);
            this.panel4.TabIndex = 25;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(16, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 19);
            this.label12.TabIndex = 0;
            this.label12.Text = "Value";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rbSV
            // 
            this.rbSV.AutoSize = true;
            this.rbSV.Checked = true;
            this.rbSV.Location = new System.Drawing.Point(19, 116);
            this.rbSV.Name = "rbSV";
            this.rbSV.Size = new System.Drawing.Size(102, 18);
            this.rbSV.TabIndex = 26;
            this.rbSV.TabStop = true;
            this.rbSV.Text = "State Variable";
            this.rbSV.UseVisualStyleBackColor = true;
            this.rbSV.CheckedChanged += new System.EventHandler(this.rbSV_CheckedChanged);
            // 
            // rbExpr
            // 
            this.rbExpr.AutoSize = true;
            this.rbExpr.Location = new System.Drawing.Point(139, 116);
            this.rbExpr.Name = "rbExpr";
            this.rbExpr.Size = new System.Drawing.Size(84, 18);
            this.rbExpr.TabIndex = 26;
            this.rbExpr.Text = "Expression";
            this.rbExpr.UseVisualStyleBackColor = true;
            this.rbExpr.CheckedChanged += new System.EventHandler(this.rbExpr_CheckedChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(16, 334);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(73, 14);
            this.label11.TabIndex = 0;
            this.label11.Text = "Name Color:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(16, 367);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(72, 14);
            this.label13.TabIndex = 0;
            this.label13.Text = "Value Color:";
            // 
            // btnNameColor
            // 
            this.btnNameColor.Location = new System.Drawing.Point(205, 330);
            this.btnNameColor.Name = "btnNameColor";
            this.btnNameColor.Size = new System.Drawing.Size(34, 23);
            this.btnNameColor.TabIndex = 28;
            this.btnNameColor.Text = "...";
            this.btnNameColor.UseVisualStyleBackColor = true;
            this.btnNameColor.Click += new System.EventHandler(this.btnNameColor_Click);
            // 
            // nameColor
            // 
            this.nameColor.BackColor = System.Drawing.Color.Black;
            this.nameColor.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nameColor.Cursor = System.Windows.Forms.Cursors.No;
            this.nameColor.Location = new System.Drawing.Point(129, 330);
            this.nameColor.Multiline = true;
            this.nameColor.Name = "nameColor";
            this.nameColor.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.nameColor.Size = new System.Drawing.Size(70, 23);
            this.nameColor.TabIndex = 27;
            // 
            // btnValueColor
            // 
            this.btnValueColor.Location = new System.Drawing.Point(205, 363);
            this.btnValueColor.Name = "btnValueColor";
            this.btnValueColor.Size = new System.Drawing.Size(34, 23);
            this.btnValueColor.TabIndex = 30;
            this.btnValueColor.Text = "...";
            this.btnValueColor.UseVisualStyleBackColor = true;
            this.btnValueColor.Click += new System.EventHandler(this.btnValueColor_Click);
            // 
            // valueColor
            // 
            this.valueColor.BackColor = System.Drawing.Color.Black;
            this.valueColor.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.valueColor.Cursor = System.Windows.Forms.Cursors.No;
            this.valueColor.Location = new System.Drawing.Point(129, 363);
            this.valueColor.Multiline = true;
            this.valueColor.Name = "valueColor";
            this.valueColor.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.valueColor.Size = new System.Drawing.Size(70, 23);
            this.valueColor.TabIndex = 29;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(16, 401);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(77, 14);
            this.label14.TabIndex = 0;
            this.label14.Text = "Border Color:";
            // 
            // borderColor
            // 
            this.borderColor.BackColor = System.Drawing.Color.Black;
            this.borderColor.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.borderColor.Cursor = System.Windows.Forms.Cursors.No;
            this.borderColor.Location = new System.Drawing.Point(129, 397);
            this.borderColor.Multiline = true;
            this.borderColor.Name = "borderColor";
            this.borderColor.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.borderColor.Size = new System.Drawing.Size(70, 23);
            this.borderColor.TabIndex = 29;
            // 
            // btnBorderColor
            // 
            this.btnBorderColor.Location = new System.Drawing.Point(205, 397);
            this.btnBorderColor.Name = "btnBorderColor";
            this.btnBorderColor.Size = new System.Drawing.Size(34, 23);
            this.btnBorderColor.TabIndex = 30;
            this.btnBorderColor.Text = "...";
            this.btnBorderColor.UseVisualStyleBackColor = true;
            this.btnBorderColor.Click += new System.EventHandler(this.btnBorderColor_Click);
            // 
            // pbRightAlign
            // 
            this.pbRightAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_right_disabled;
            this.pbRightAlign.Location = new System.Drawing.Point(405, 296);
            this.pbRightAlign.Name = "pbRightAlign";
            this.pbRightAlign.Size = new System.Drawing.Size(23, 23);
            this.pbRightAlign.TabIndex = 7;
            this.pbRightAlign.TabStop = false;
            this.pbRightAlign.Visible = false;
            this.pbRightAlign.Click += new System.EventHandler(this.pbRightAlign_Click);
            // 
            // pbCenterAlign
            // 
            this.pbCenterAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_center_disabled;
            this.pbCenterAlign.Location = new System.Drawing.Point(370, 296);
            this.pbCenterAlign.Name = "pbCenterAlign";
            this.pbCenterAlign.Size = new System.Drawing.Size(23, 23);
            this.pbCenterAlign.TabIndex = 6;
            this.pbCenterAlign.TabStop = false;
            this.pbCenterAlign.Visible = false;
            this.pbCenterAlign.Click += new System.EventHandler(this.pbCenterAlign_Click);
            // 
            // pbLeftAlign
            // 
            this.pbLeftAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_left;
            this.pbLeftAlign.Location = new System.Drawing.Point(334, 296);
            this.pbLeftAlign.Name = "pbLeftAlign";
            this.pbLeftAlign.Size = new System.Drawing.Size(23, 23);
            this.pbLeftAlign.TabIndex = 5;
            this.pbLeftAlign.TabStop = false;
            this.pbLeftAlign.Visible = false;
            this.pbLeftAlign.Click += new System.EventHandler(this.pbLeftAlign_Click);
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(114)))), ((int)(((byte)(198)))));
            this.panel5.Controls.Add(this.label15);
            this.panel5.Location = new System.Drawing.Point(0, 441);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(578, 25);
            this.panel5.TabIndex = 31;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(16, 3);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(79, 19);
            this.label15.TabIndex = 0;
            this.label15.Text = "Dimension";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(16, 485);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(30, 14);
            this.label16.TabIndex = 40;
            this.label16.Text = "Size:";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(216, 485);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(51, 14);
            this.label17.TabIndex = 41;
            this.label17.Text = "Location:";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Location = new System.Drawing.Point(294, 543);
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(90, 22);
            this.numericUpDown4.TabIndex = 35;
            this.numericUpDown4.ValueChanged += new System.EventHandler(this.numericUpDown4_ValueChanged);
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Location = new System.Drawing.Point(294, 509);
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(90, 22);
            this.numericUpDown3.TabIndex = 34;
            this.numericUpDown3.ValueChanged += new System.EventHandler(this.numericUpDown3_ValueChanged);
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(97, 543);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(90, 22);
            this.numericUpDown2.TabIndex = 33;
            this.numericUpDown2.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(97, 509);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(90, 22);
            this.numericUpDown1.TabIndex = 32;
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(242, 547);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 14);
            this.label18.TabIndex = 39;
            this.label18.Text = "Top:";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(242, 513);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 14);
            this.label19.TabIndex = 38;
            this.label19.Text = "Left:";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(36, 547);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(46, 14);
            this.label20.TabIndex = 37;
            this.label20.Text = "Height:";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(36, 513);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(43, 14);
            this.label21.TabIndex = 36;
            this.label21.Text = "Width:";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TileProperties
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.numericUpDown4);
            this.Controls.Add(this.numericUpDown3);
            this.Controls.Add(this.numericUpDown2);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.btnBorderColor);
            this.Controls.Add(this.btnValueColor);
            this.Controls.Add(this.borderColor);
            this.Controls.Add(this.valueColor);
            this.Controls.Add(this.btnNameColor);
            this.Controls.Add(this.nameColor);
            this.Controls.Add(this.rbExpr);
            this.Controls.Add(this.rbSV);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.lblExpr);
            this.Controls.Add(this.txtExpr);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.cbStateVariables);
            this.Controls.Add(this.cbObjects);
            this.Controls.Add(this.ckUnderline);
            this.Controls.Add(this.ckItalic);
            this.Controls.Add(this.ckBold);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cbFontSize);
            this.Controls.Add(this.cbFont);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pbRightAlign);
            this.Controls.Add(this.pbCenterAlign);
            this.Controls.Add(this.pbLeftAlign);
            this.Controls.Add(this.btnColor);
            this.Controls.Add(this.bgColor);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "TileProperties";
            this.Size = new System.Drawing.Size(578, 614);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbRightAlign)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCenterAlign)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLeftAlign)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Diagnostics.Process process1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox bgColor;
        private System.Windows.Forms.Button btnColor;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pbLeftAlign;
        private System.Windows.Forms.PictureBox pbRightAlign;
        private System.Windows.Forms.PictureBox pbCenterAlign;
        private System.Windows.Forms.ComboBox cbFont;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbFontSize;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox ckBold;
        private System.Windows.Forms.CheckBox ckUnderline;
        private System.Windows.Forms.CheckBox ckItalic;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox cbStateVariables;
        private System.Windows.Forms.ComboBox cbObjects;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtExpr;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblExpr;
        private System.Windows.Forms.RadioButton rbExpr;
        private System.Windows.Forms.RadioButton rbSV;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnValueColor;
        private System.Windows.Forms.TextBox valueColor;
        private System.Windows.Forms.Button btnNameColor;
        private System.Windows.Forms.TextBox nameColor;
        private System.Windows.Forms.Button btnBorderColor;
        private System.Windows.Forms.TextBox borderColor;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
    }
}
