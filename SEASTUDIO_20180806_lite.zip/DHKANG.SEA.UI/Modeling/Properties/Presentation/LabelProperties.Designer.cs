﻿namespace DHKANG.SEA.UI.Modeling.Properties
{
    partial class LabelProperties 
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.process1 = new System.Diagnostics.Process();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtColor = new System.Windows.Forms.TextBox();
            this.btnColor = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbFont = new System.Windows.Forms.ComboBox();
            this.cbFontSize = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.ckBold = new System.Windows.Forms.CheckBox();
            this.ckItalic = new System.Windows.Forms.CheckBox();
            this.ckUnderline = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.cbStateVariables = new System.Windows.Forms.ComboBox();
            this.cbObjects = new System.Windows.Forms.ComboBox();
            this.pbRightAlign = new System.Windows.Forms.PictureBox();
            this.pbCenterAlign = new System.Windows.Forms.PictureBox();
            this.pbLeftAlign = new System.Windows.Forms.PictureBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtExpr = new System.Windows.Forms.TextBox();
            this.lblExpr = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.rbSV = new System.Windows.Forms.RadioButton();
            this.rbExpr = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbRightAlign)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCenterAlign)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLeftAlign)).BeginInit();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // process1
            // 
            this.process1.StartInfo.Domain = "";
            this.process1.StartInfo.LoadUserProfile = false;
            this.process1.StartInfo.Password = null;
            this.process1.StartInfo.StandardErrorEncoding = null;
            this.process1.StartInfo.StandardOutputEncoding = null;
            this.process1.StartInfo.UserName = "";
            this.process1.SynchronizingObject = this;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 151);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "Object:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 306);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 14);
            this.label2.TabIndex = 0;
            this.label2.Text = "Color:";
            // 
            // txtColor
            // 
            this.txtColor.BackColor = System.Drawing.Color.Black;
            this.txtColor.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtColor.Cursor = System.Windows.Forms.Cursors.No;
            this.txtColor.Location = new System.Drawing.Point(113, 302);
            this.txtColor.Multiline = true;
            this.txtColor.Name = "txtColor";
            this.txtColor.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtColor.Size = new System.Drawing.Size(70, 23);
            this.txtColor.TabIndex = 3;
            this.txtColor.BackColorChanged += new System.EventHandler(this.txtColor_BackColorChanged);
            // 
            // btnColor
            // 
            this.btnColor.Location = new System.Drawing.Point(189, 302);
            this.btnColor.Name = "btnColor";
            this.btnColor.Size = new System.Drawing.Size(34, 23);
            this.btnColor.TabIndex = 4;
            this.btnColor.Text = "...";
            this.btnColor.UseVisualStyleBackColor = true;
            this.btnColor.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 346);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 14);
            this.label3.TabIndex = 0;
            this.label3.Text = "Alignment:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 388);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 14);
            this.label4.TabIndex = 8;
            this.label4.Text = "Font:";
            // 
            // cbFont
            // 
            this.cbFont.FormattingEnabled = true;
            this.cbFont.Items.AddRange(new object[] {
            "Arial",
            "Calibri",
            "Comic Sans MS",
            "Consolas",
            "Courier New",
            "Georgia",
            "Microsoft Sans Serif",
            "Tahoma",
            "Times New Roman",
            "Verdana"});
            this.cbFont.Location = new System.Drawing.Point(112, 384);
            this.cbFont.Name = "cbFont";
            this.cbFont.Size = new System.Drawing.Size(112, 22);
            this.cbFont.TabIndex = 9;
            this.cbFont.Text = "Arial";
            this.cbFont.SelectedIndexChanged += new System.EventHandler(this.cbFont_SelectedIndexChanged);
            // 
            // cbFontSize
            // 
            this.cbFontSize.FormattingEnabled = true;
            this.cbFontSize.Items.AddRange(new object[] {
            "6",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "16",
            "18",
            "20",
            "24",
            "28",
            "32"});
            this.cbFontSize.Location = new System.Drawing.Point(232, 384);
            this.cbFontSize.Name = "cbFontSize";
            this.cbFontSize.Size = new System.Drawing.Size(39, 22);
            this.cbFontSize.TabIndex = 9;
            this.cbFontSize.Text = "10";
            this.cbFontSize.SelectedIndexChanged += new System.EventHandler(this.cbFontSize_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(277, 388);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 14);
            this.label5.TabIndex = 10;
            this.label5.Text = "pt";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 425);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 14);
            this.label6.TabIndex = 11;
            this.label6.Text = "Style:";
            // 
            // ckBold
            // 
            this.ckBold.AutoSize = true;
            this.ckBold.Location = new System.Drawing.Point(112, 423);
            this.ckBold.Name = "ckBold";
            this.ckBold.Size = new System.Drawing.Size(51, 18);
            this.ckBold.TabIndex = 12;
            this.ckBold.Text = "Bold";
            this.ckBold.UseVisualStyleBackColor = true;
            this.ckBold.CheckedChanged += new System.EventHandler(this.ckBold_CheckedChanged);
            // 
            // ckItalic
            // 
            this.ckItalic.AutoSize = true;
            this.ckItalic.Location = new System.Drawing.Point(170, 423);
            this.ckItalic.Name = "ckItalic";
            this.ckItalic.Size = new System.Drawing.Size(54, 18);
            this.ckItalic.TabIndex = 12;
            this.ckItalic.Text = "Italic";
            this.ckItalic.UseVisualStyleBackColor = true;
            this.ckItalic.CheckedChanged += new System.EventHandler(this.ckItalic_CheckedChanged);
            // 
            // ckUnderline
            // 
            this.ckUnderline.AutoSize = true;
            this.ckUnderline.Location = new System.Drawing.Point(231, 423);
            this.ckUnderline.Name = "ckUnderline";
            this.ckUnderline.Size = new System.Drawing.Size(81, 18);
            this.ckUnderline.TabIndex = 12;
            this.ckUnderline.Text = "Underline";
            this.ckUnderline.UseVisualStyleBackColor = true;
            this.ckUnderline.CheckedChanged += new System.EventHandler(this.ckUnderline_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(114)))), ((int)(((byte)(198)))));
            this.panel1.Controls.Add(this.label8);
            this.panel1.Location = new System.Drawing.Point(0, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(406, 25);
            this.panel1.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(16, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 19);
            this.label8.TabIndex = 0;
            this.label8.Text = "Label";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(16, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 19);
            this.label9.TabIndex = 0;
            this.label9.Text = "Appearance";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(114)))), ((int)(((byte)(198)))));
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(0, 258);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(406, 25);
            this.panel2.TabIndex = 16;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Location = new System.Drawing.Point(3, 449);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(403, 20);
            this.panel3.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(33, 187);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 14);
            this.label7.TabIndex = 0;
            this.label7.Text = "State Variable:";
            // 
            // cbStateVariables
            // 
            this.cbStateVariables.FormattingEnabled = true;
            this.cbStateVariables.Location = new System.Drawing.Point(129, 183);
            this.cbStateVariables.Name = "cbStateVariables";
            this.cbStateVariables.Size = new System.Drawing.Size(164, 22);
            this.cbStateVariables.TabIndex = 13;
            this.cbStateVariables.SelectedIndexChanged += new System.EventHandler(this.cbStateVariables_SelectedIndexChanged);
            // 
            // cbEventObjects
            // 
            this.cbObjects.FormattingEnabled = true;
            this.cbObjects.Location = new System.Drawing.Point(129, 147);
            this.cbObjects.Name = "cbEventObjects";
            this.cbObjects.Size = new System.Drawing.Size(164, 22);
            this.cbObjects.TabIndex = 13;
            this.cbObjects.SelectedIndexChanged += new System.EventHandler(this.cbEventObjects_SelectedIndexChanged);
            // 
            // pbRightAlign
            // 
            this.pbRightAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_right_disabled;
            this.pbRightAlign.Location = new System.Drawing.Point(184, 342);
            this.pbRightAlign.Name = "pbRightAlign";
            this.pbRightAlign.Size = new System.Drawing.Size(23, 23);
            this.pbRightAlign.TabIndex = 7;
            this.pbRightAlign.TabStop = false;
            this.pbRightAlign.Click += new System.EventHandler(this.pbRightAlign_Click);
            // 
            // pbCenterAlign
            // 
            this.pbCenterAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_center_disabled;
            this.pbCenterAlign.Location = new System.Drawing.Point(149, 342);
            this.pbCenterAlign.Name = "pbCenterAlign";
            this.pbCenterAlign.Size = new System.Drawing.Size(23, 23);
            this.pbCenterAlign.TabIndex = 6;
            this.pbCenterAlign.TabStop = false;
            this.pbCenterAlign.Click += new System.EventHandler(this.pbCenterAlign_Click);
            // 
            // pbLeftAlign
            // 
            this.pbLeftAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_left;
            this.pbLeftAlign.Location = new System.Drawing.Point(113, 342);
            this.pbLeftAlign.Name = "pbLeftAlign";
            this.pbLeftAlign.Size = new System.Drawing.Size(23, 23);
            this.pbLeftAlign.TabIndex = 5;
            this.pbLeftAlign.TabStop = false;
            this.pbLeftAlign.Click += new System.EventHandler(this.pbLeftAlign_Click);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(112, 40);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(181, 22);
            this.txtName.TabIndex = 21;
            this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            this.txtName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtName_KeyDown);
            this.txtName.Leave += new System.EventHandler(this.txtName_Leave);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(17, 44);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 14);
            this.label10.TabIndex = 20;
            this.label10.Text = "Name:";
            // 
            // btnAdd
            // 
            this.btnAdd.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnAdd.Location = new System.Drawing.Point(299, 183);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(23, 23);
            this.btnAdd.TabIndex = 22;
            this.btnAdd.Text = "+";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Visible = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtExpr
            // 
            this.txtExpr.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtExpr.Location = new System.Drawing.Point(129, 218);
            this.txtExpr.Name = "txtExpr";
            this.txtExpr.Size = new System.Drawing.Size(211, 22);
            this.txtExpr.TabIndex = 23;
            this.txtExpr.Visible = false;
            // 
            // lblExpr
            // 
            this.lblExpr.AutoSize = true;
            this.lblExpr.Location = new System.Drawing.Point(33, 222);
            this.lblExpr.Name = "lblExpr";
            this.lblExpr.Size = new System.Drawing.Size(69, 14);
            this.lblExpr.TabIndex = 24;
            this.lblExpr.Text = "Expression:";
            this.lblExpr.Visible = false;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(114)))), ((int)(((byte)(198)))));
            this.panel4.Controls.Add(this.label12);
            this.panel4.Location = new System.Drawing.Point(0, 78);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(406, 25);
            this.panel4.TabIndex = 25;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(16, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 19);
            this.label12.TabIndex = 0;
            this.label12.Text = "Value";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rbSV
            // 
            this.rbSV.AutoSize = true;
            this.rbSV.Checked = true;
            this.rbSV.Location = new System.Drawing.Point(19, 116);
            this.rbSV.Name = "rbSV";
            this.rbSV.Size = new System.Drawing.Size(102, 18);
            this.rbSV.TabIndex = 26;
            this.rbSV.TabStop = true;
            this.rbSV.Text = "State Variable";
            this.rbSV.UseVisualStyleBackColor = true;
            this.rbSV.CheckedChanged += new System.EventHandler(this.rbSV_CheckedChanged);
            // 
            // rbExpr
            // 
            this.rbExpr.AutoSize = true;
            this.rbExpr.Location = new System.Drawing.Point(139, 116);
            this.rbExpr.Name = "rbExpr";
            this.rbExpr.Size = new System.Drawing.Size(84, 18);
            this.rbExpr.TabIndex = 26;
            this.rbExpr.Text = "Expression";
            this.rbExpr.UseVisualStyleBackColor = true;
            this.rbExpr.CheckedChanged += new System.EventHandler(this.rbExpr_CheckedChanged);
            // 
            // LabelProperties
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.rbExpr);
            this.Controls.Add(this.rbSV);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.lblExpr);
            this.Controls.Add(this.txtExpr);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.cbStateVariables);
            this.Controls.Add(this.cbObjects);
            this.Controls.Add(this.ckUnderline);
            this.Controls.Add(this.ckItalic);
            this.Controls.Add(this.ckBold);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cbFontSize);
            this.Controls.Add(this.cbFont);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pbRightAlign);
            this.Controls.Add(this.pbCenterAlign);
            this.Controls.Add(this.pbLeftAlign);
            this.Controls.Add(this.btnColor);
            this.Controls.Add(this.txtColor);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "LabelProperties";
            this.Size = new System.Drawing.Size(406, 478);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbRightAlign)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCenterAlign)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLeftAlign)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Diagnostics.Process process1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtColor;
        private System.Windows.Forms.Button btnColor;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pbLeftAlign;
        private System.Windows.Forms.PictureBox pbRightAlign;
        private System.Windows.Forms.PictureBox pbCenterAlign;
        private System.Windows.Forms.ComboBox cbFont;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbFontSize;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox ckBold;
        private System.Windows.Forms.CheckBox ckUnderline;
        private System.Windows.Forms.CheckBox ckItalic;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox cbStateVariables;
        private System.Windows.Forms.ComboBox cbObjects;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtExpr;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblExpr;
        private System.Windows.Forms.RadioButton rbExpr;
        private System.Windows.Forms.RadioButton rbSV;
    }
}
