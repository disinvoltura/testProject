﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public partial class TextProperties : UserControl
    {
        private OOMMModel _Model;
        private TextNode _Node;
        private bool isUpdating = false;

        #region Events
        public event PropertyValueChangedEventHandler PropertyValueChanged;
        #endregion

        public TextProperties()
        {
            InitializeComponent();
        }

        public void Update(OOMMModel model, TextNode node)
        {
            _Model = model;
            _Node = node;

            showProperties();
        }

        private void showProperties()
        {
            isUpdating = true;

            txtValue.Text = _Node.Text;

            //Color
            txtColor.BackColor = _Node.BackgroundColor;

            //TODO Text Alignment

            //Font
            cbFont.Text = _Node.Font.Name;
            cbFontSize.Text = _Node.FontSize.ToString();
            this.ckBold.Checked = _Node.Bold;
            this.ckItalic.Checked = _Node.Italic;
            this.ckUnderline.Checked = _Node.Underline;

            isUpdating = false;
        }

        private void btnColor_Click(object sender, EventArgs e)
        {
            ColorDialog dialog = new ColorDialog();

            DialogResult rslt = dialog.ShowDialog(this);
            if (rslt == DialogResult.OK)
            {
                Color oldValue = txtColor.BackColor;
                txtColor.BackColor = dialog.Color;

                if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                    PropertyValueChanged(_Model.ID, _Node, "BackColor", oldValue, dialog.Color);
            }
        }

        private void pbLeftAlign_Click(object sender, EventArgs e)
        {
            pbLeftAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_left;
            pbCenterAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_center_disabled;
            pbRightAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_right_disabled;

            pbLeftAlign.Tag = true;
            pbCenterAlign.Tag = false;
            pbRightAlign.Tag = false;
        }

        private void pbCenterAlign_Click(object sender, EventArgs e)
        {
            pbLeftAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_left_disabled;
            pbCenterAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_center;
            pbRightAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_right_disabled;

            pbLeftAlign.Tag = false;
            pbCenterAlign.Tag = true;
            pbRightAlign.Tag = false;
        }

        private void pbRightAlign_Click(object sender, EventArgs e)
        {
            pbLeftAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_left_disabled;
            pbCenterAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_center_disabled;
            pbRightAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_right;

            pbLeftAlign.Tag = false;
            pbCenterAlign.Tag = false;
            pbRightAlign.Tag = true;
        }

        private void cbFont_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            //System.Diagnostics.Debug.WriteLine("font:" + cbFont.Text);

            FontStyle fs = FontStyle.Regular;

            if (this.Bold)
                fs = fs | FontStyle.Bold;
            if (this.Italic)
                fs = fs | FontStyle.Italic;
            if (this.Underline)
                fs = fs | FontStyle.Underline;

            string oldValue = _Node.Font.Name;
            _Node.Font = new Font(cbFont.SelectedText, this.FontSize, fs);

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Node, "FontName", oldValue, cbFont.SelectedText);
        }

        private string FontName { get { return cbFont.Text; } }

        private float FontSize
        {
            get
            {
                float size = 10;
                float.TryParse(cbFontSize.Text, out size);

                return size;
            }
        }

        private bool Bold { get { return ckBold.Checked; } }
        private bool Italic { get { return ckItalic.Checked; } }
        private bool Underline { get { return ckUnderline.Checked; } }

        private void cbFontSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;
            //System.Diagnostics.Debug.WriteLine("font size:" + cbFontSize.Text);

            float oldValue = _Node.FontSize;
            _Node.FontSize = int.Parse(cbFontSize.Text);// this.FontSize;

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Node, "FontSize", oldValue, _Node.FontSize);
        }

        private void ckBold_CheckedChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            bool oldValue = _Node.Bold;
            _Node.Bold = ckBold.Checked;

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Node, "Bold", oldValue, _Node.Bold);
        }

        private void ckItalic_CheckedChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            bool oldValue = _Node.Italic;
            _Node.Italic = ckItalic.Checked;

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Node, "Italic", oldValue, _Node.Italic);
        }

        private void ckUnderline_CheckedChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            bool oldValue = _Node.Underline;
            _Node.Underline = ckUnderline.Checked;

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Node, "Underline", oldValue, _Node.Underline);
        }

        private void txtColor_BackColorChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            Color oldValue = _Node.TextColor;
            _Node.TextColor = txtColor.BackColor;

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Node, "TextColor", oldValue, _Node.TextColor);
        }

        private void txtValue_TextChanged(object sender, EventArgs e)
        {
        }

        private void handleNameChanged() {
            if (isUpdating)
                return;

            if (string.IsNullOrEmpty(txtValue.Text))
                return;

            string oldValue = _Node.Text;
            _Node.Text = txtValue.Text;

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Node, "Name", oldValue, _Node.Text);
        }

        private void txtValue_Leave(object sender, EventArgs e)
        {
            handleNameChanged();
        }

        private void txtValue_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleNameChanged();
            }
        }
    }
}
