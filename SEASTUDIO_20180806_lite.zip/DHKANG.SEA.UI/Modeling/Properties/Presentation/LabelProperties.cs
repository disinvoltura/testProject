﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using Northwoods.Go;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.OID;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model.ActivityObjects;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public partial class LabelProperties : UserControl
    {
        private OOMMModel _Model;
        private LabelNode _Node;

        #region Events
        public event PropertyValueChangedEventHandler PropertyValueChanged;
        #endregion

        public LabelProperties()
        {
            InitializeComponent();
        }

        public void Update(OOMMModel model, LabelNode node)
        {
            _Node = node;
            _Model = model;
            showProperties();
        }

        private bool isUpdating = false;
        private void showProperties()
        {
            isUpdating = true;

            txtName.Text = _Node.LabelName;
            cbObjects.Items.Clear();

            OOMMObjectInteractionDiagram diagram = _Model.ObjectInteractionDiagram;
            List<string> objectNodeList = new List<string>();
            foreach (OOMMObjectNode objectNode in diagram.ObjectNodes)
            {
                objectNodeList.Add(objectNode.Name);
            }
            objectNodeList.Sort();
            cbObjects.Items.AddRange(objectNodeList.ToArray<string>());

            if (_Node != null)
            {
                cbObjects.SelectedItem = _Node.ObjectName;
            }

            updateStateVariables(_Node.ObjectName);
            if (_Node != null)
            {
                cbStateVariables.SelectedText = _Node.StateVariableName;
                cbStateVariables.SelectedValue = _Node.StateVariableName;
                cbStateVariables.SelectedItem = _Node.StateVariableName;
            }

            txtColor.BackColor = _Node.BackgroundColor;

            //TODO Text Alignment
            cbFont.Text = _Node.Font.Name;
            cbFontSize.Text = _Node.FontSize.ToString();
            this.ckBold.Checked = _Node.Bold;
            this.ckItalic.Checked = _Node.Italic;
            this.ckUnderline.Checked = _Node.Underline;

            isUpdating = false;
        }

        private void btnColor_Click(object sender, EventArgs e)
        {
            ColorDialog dialog = new ColorDialog();

            Color oldValue = txtColor.BackColor;
            DialogResult rslt = dialog.ShowDialog(this);
            if (rslt == DialogResult.OK)
            {
                txtColor.BackColor = dialog.Color;

                if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                    PropertyValueChanged(_Model.ID, _Node, "TextColor", oldValue, dialog.Color);
            }
        }

        private void pbLeftAlign_Click(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            pbLeftAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_left;
            pbCenterAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_center_disabled;
            pbRightAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_right_disabled;

            pbLeftAlign.Tag = true;
            pbCenterAlign.Tag = false;
            pbRightAlign.Tag = false;

            _Node.Alignment = GoObject.MiddleLeft;
        }

        private void pbCenterAlign_Click(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            pbLeftAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_left_disabled;
            pbCenterAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_center;
            pbRightAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_right_disabled;

            pbLeftAlign.Tag = false;
            pbCenterAlign.Tag = true;
            pbRightAlign.Tag = false;

            _Node.Alignment = GoObject.MiddleCenter;
        }

        private void pbRightAlign_Click(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            pbLeftAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_left_disabled;
            pbCenterAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_center_disabled;
            pbRightAlign.Image = global::DHKANG.SEA.UI.Properties.Resources.align_right;

            pbLeftAlign.Tag = false;
            pbCenterAlign.Tag = false;
            pbRightAlign.Tag = true;

            _Node.Alignment = GoObject.MiddleRight;
        }

        private void cbEventObjects_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbObjects.Text))
                return;

            if (isUpdating)
                return;

            updateStateVariables(cbObjects.Text);
        }

        private void updateStateVariables(string objectName)
        {
            if (string.IsNullOrEmpty(objectName))
                return;

            OOMMObjectInteractionDiagram diagram = _Model.ObjectInteractionDiagram;
            OOMMObjectNode objectNode = diagram.FindObjectNode(objectName);
            if (objectNode == null)
                return;
            if (objectNode.Type == ObjectNodeType.EventObject)
            {
                OOEGEventObjectModel eoModel = null;
                eoModel = _Model.FindEventObjectModel(objectNode.ModelID);
                if (eoModel == null)
                    return;

                List<string> namelist = new List<string>();
                foreach (OOEGStateVariable sv in eoModel.StateVariables)
                {
                    namelist.Add(sv.Name);
                }
                namelist.Sort();

                cbStateVariables.Items.Clear();
                cbStateVariables.Items.AddRange(namelist.ToArray());
            }
            else if (objectNode.Type == ObjectNodeType.StateObject)
            {
                OOSGStateObjectModel soModel = null;
                soModel = _Model.FindStateObjectModel(objectNode.ModelID);
                if (soModel == null)
                    return;

                List<string> namelist = new List<string>();
                foreach (OOSGStateVariable sv in soModel.StateVariables)
                {
                    namelist.Add(sv.Name);
                }
                namelist.Sort();

                cbStateVariables.Items.Clear();
                cbStateVariables.Items.AddRange(namelist.ToArray());
            }
            else if (objectNode.Type == ObjectNodeType.ActivityObject)
            {
                OOAGActivityObjectModel aoModel = null;
                aoModel = _Model.FindActivityObjectModel(objectNode.ModelID);
                if (aoModel == null)
                    return;

                List<string> namelist = new List<string>();
                aoModel.StateVariables.ForEach(sv => namelist.Add(sv.Name));
                aoModel.Queues.ForEach(q => namelist.Add(q.Name));

                namelist.Sort();

                cbStateVariables.Items.Clear();
                cbStateVariables.Items.AddRange(namelist.ToArray());
            }
        }

        private void txtColor_BackColorChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;


            _Node.BackgroundColor = txtColor.BackColor;
        }

        private void cbFont_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            //System.Diagnostics.Debug.WriteLine("font:" + cbFont.Text);

            FontStyle fs = FontStyle.Regular;

            if (this.Bold)
                fs = fs | FontStyle.Bold;
            if (this.Italic)
                fs = fs | FontStyle.Italic;
            if (this.Underline)
                fs = fs | FontStyle.Underline;

            string oldValue = _Node.Font.Name;

            _Node.Font = new Font(cbFont.SelectedText, this.FontSize, fs);
            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Node, "FontName", oldValue, cbFont.SelectedText);
        }

        private string FontName { get { return cbFont.Text; } }

        private float FontSize
        {
            get
            {
                float size = 10;
                float.TryParse(cbFontSize.Text, out size);

                return size;
            }
        }

        private bool Bold { get { return ckBold.Checked; } }
        private bool Italic { get { return ckItalic.Checked; } }
        private bool Underline { get { return ckUnderline.Checked; } }

        private void cbFontSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;
            //System.Diagnostics.Debug.WriteLine("font size:" + cbFontSize.Text);

            float oldValue = _Node.FontSize;
            _Node.FontSize = int.Parse(cbFontSize.Text);// this.FontSize;

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Node, "FontSize", oldValue, _Node.FontSize);

        }

        private void ckBold_CheckedChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;
            bool oldValue = _Node.Bold;
            _Node.Bold = ckBold.Checked;

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Node, "Bold", oldValue, _Node.Bold);
        }

        private void ckItalic_CheckedChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;
            bool oldValue = _Node.Italic;
            _Node.Italic = ckItalic.Checked;

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Node, "Italic", oldValue, _Node.Italic);
        }

        private void ckUnderline_CheckedChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;
            bool oldValue = _Node.Underline;
            _Node.Underline = ckUnderline.Checked;

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Node, "Underline", oldValue, _Node.Underline);
        }

        private void cbStateVariables_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            if (string.IsNullOrEmpty(cbObjects.Text) ||
                string.IsNullOrEmpty(cbStateVariables.Text))
                return;

            if (_Model == null)
                return;

            string oldValue = _Node.StateVariableName;

            OOMMObjectInteractionDiagram diagram = _Model.ObjectInteractionDiagram;
            OOMMObjectNode objectNode = diagram.FindObjectNode(cbObjects.Text);
            if (objectNode == null)
                return;

            _Node.ObjectID = objectNode.NodeID;
            _Node.ObjectName = cbObjects.Text;

            if (objectNode.Type == ObjectNodeType.EventObject)
            {
                OOEGEventObjectModel eoModel = _Model.FindEventObjectModel(objectNode.ModelID);
                OOEGStateVariable sv = eoModel.GetStateVariable(cbStateVariables.Text);

                _Node.StateVariableName = sv.Name;
                _Node.InitialValue = sv.InitialValue;
            }
            else if (objectNode.Type == ObjectNodeType.StateObject)
            {
                OOSGStateObjectModel soModel = _Model.FindStateObjectModel(objectNode.ModelID);
                OOSGStateVariable sv = soModel.FindStateVariable(cbStateVariables.Text);

                _Node.StateVariableName = sv.Name;
                _Node.InitialValue = sv.InitialValue.ToString();
            }
            else if (objectNode.Type == ObjectNodeType.ActivityObject)
            {
                OOAGActivityObjectModel aoModel = _Model.FindActivityObjectModel(objectNode.ModelID);
                OOAGStateVariable sv = aoModel.FindStateVariable(cbStateVariables.Text);
                if (sv != null)
                {
                    _Node.StateVariableName = sv.Name;
                    _Node.InitialValue = sv.InitialValue.ToString();
                }else
                {
                    OOAGQueue q = aoModel.FindQueue(cbStateVariables.Text);
                    if (q != null)
                    {
                        _Node.StateVariableName = q.Name;
                        _Node.InitialValue = q.InitialValue.ToString();
                    }
                }
            }
            _Node.UpdateText();

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Node, "StateVariable", oldValue, _Node.StateVariableName);
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
        }

        private void handleNameChanged()
        {
            if (isUpdating)
                return;

            if (string.IsNullOrEmpty(txtName.Text))
                return;

            string oldValue = _Node.LabelName;
            _Node.LabelName = txtName.Text;
            _Node.UpdateText();

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Node, "Name", oldValue, _Node.Text);
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            handleNameChanged();
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleNameChanged();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbObjects.Text) ||
                string.IsNullOrEmpty(cbStateVariables.Text))
                return;

            string sv = cbObjects.Text + "." + cbStateVariables.Text;
            txtExpr.Text += sv;
        }

        private void rbSV_CheckedChanged(object sender, EventArgs e)
        {
            btnAdd.Visible = false;
            lblExpr.Visible = false;
            txtExpr.Visible = false;
        }

        private void rbExpr_CheckedChanged(object sender, EventArgs e)
        {
            btnAdd.Visible = true;
            lblExpr.Visible = true;
            txtExpr.Visible = true;
        }
    }
}
