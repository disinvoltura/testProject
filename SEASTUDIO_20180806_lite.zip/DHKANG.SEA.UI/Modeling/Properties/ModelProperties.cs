﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI.Modeling
{
    public enum ModelPropertyType { Name, Description, Creator };

    public delegate void ModelPropertiesChangedEventHandler(ModelPropertyType type, Guid modelid, string oldValue, string newValue);

    public partial class ModelProperties : UserControl
    {
        #region Member Variables
        private OOMMModel _Model;
        #endregion

        #region Events
        public event ModelPropertiesChangedEventHandler PropertyChanged;
        #endregion

        #region Properties
        #endregion

        public ModelProperties()
        {
            InitializeComponent();
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            /*
            if (string.IsNullOrEmpty(txtName.Text))
                return;

            string oldValue = _Model.Name;
            string newValue = txtName.Text;

            _Model.Name = newValue;

            if (PropertyChanged!= null && PropertyChanged.GetInvocationList().Length > 0)
                PropertyChanged(ModelPropertyType.Name, oldValue, newValue);
            */
        }

        public void Update(OOMMModel model)
        {
            _Model = model;

            txtName.Text = _Model.Name;
            txtDesc.Text = _Model.Description;
            txtCreator.Text = _Model.Creator;
        }

        private void txtDesc_TextChanged(object sender, EventArgs e)
        {
            /*
            if (string.IsNullOrEmpty(txtDesc.Text))
                return;

            string oldValue = _Model.Description;
            string newValue = txtDesc.Text;

            _Model.Description = newValue;
            */
        }

        private void txtCreator_TextChanged(object sender, EventArgs e)
        {
            /*
            if (string.IsNullOrEmpty(txtCreator.Text))
                return;

            string oldValue = _Model.Creator;
            string newValue = txtCreator.Text;

            _Model.Creator = newValue;
            */
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtName.Text))
                return;

            string oldValue = _Model.Name;
            string newValue = txtName.Text;

            if (oldValue.Trim().Equals(newValue.Trim()))
                return;

            _Model.Name = newValue;

            if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                PropertyChanged(ModelPropertyType.Name, _Model.ID, oldValue, newValue);
        }

        private void txtDesc_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtDesc.Text))
                return;

            string oldValue = _Model.Description;
            string newValue = txtDesc.Text;

            if (oldValue.Trim().Equals(newValue.Trim()))
                return;
            
            _Model.Description = newValue;

            if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                PropertyChanged(ModelPropertyType.Description, _Model.ID, oldValue, newValue);
        }

        private void txtCreator_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCreator.Text))
                return;

            string oldValue = _Model.Creator;
            string newValue = txtCreator.Text;

            if (oldValue.Trim().Equals(newValue.Trim()))
                return;

            _Model.Creator = newValue;

            if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                PropertyChanged(ModelPropertyType.Creator, _Model.ID, oldValue, newValue);
        }
    }
}
