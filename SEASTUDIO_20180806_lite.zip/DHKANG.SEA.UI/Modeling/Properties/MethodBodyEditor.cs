﻿using DHKANG.SEA.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DHKANG.SEA.UI.Modeling
{
    public partial class MethodBodyEditor : Form
    {
        public string Action
        {
            get { return this.tecAction.Text; }
        }

        public int NumberOfLines
        {
            get { return tecAction.Document.TotalNumberOfLines; }
        }
        public MethodBodyEditor(OOMMUserClassMethod method)
        {
            InitializeComponent();

            string accessor = method.Accessor.ToString().ToLower();

            lblMethodPrototype.Text = accessor + " " + method.ReturnType + " " + method.Name + "(" + method.Parameters + ") {";
            tecAction.Text = method.MethodBody;
        }

        private void ActionEditor_FormClosing(object sender, FormClosingEventArgs e)
        {
            //base.OnFormClosing(e);
            System.Diagnostics.Trace.WriteLine(tecAction.Document.TotalNumberOfLines);
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void btnApply_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
