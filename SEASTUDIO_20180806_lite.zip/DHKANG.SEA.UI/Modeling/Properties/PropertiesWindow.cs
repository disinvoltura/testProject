﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using System.Text.RegularExpressions;
using DHKANG.SEA.UI.Modeling;
using DHKANG.SEA.UI.Modeling.Properties;
using DHKANG.SEA.UI.OutputView.Visualization;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.Entities;
using DHKANG.SEA.Model.Data;
using DHKANG.SEA.Model.Experiments;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model.ActivityObjects;
using DHKANG.SEA.UI.Modeling.Properties.Charts;

namespace DHKANG.SEA.UI
{
    public delegate void ChartPropertyValueChangedEventHandler(OOMMModel model, AbstractChart chart);

    public partial class PropertiesWindow : DockContent
    {
        #region Member Variables
        private MainUI _Parent;
        //private OOEGModelEditor _ModelEditor;

        private EntityProperties _EntityProperties;

        private LabelProperties _LabelProperties;
        private TextProperties _TextProperties;

        private ActivityObjectNodeProperties _ActivityObjectNodeProperties;
        private EventObjectNodeProperties _EventObjectNodeProperties;
        private StateObjectNodeProperties _StateObjectNodeProperties;
        private ObjectSchedulingLinkProperties _ObjectSchedulingLinkProperties;
        private DataAssociationLinkProperties _DataAssociationProperties;
        private StateVariableUpdateLinkProperties _StateVariableUpdateProperties;

        private CSVDataSourceProperties _CSVDataSourceProperties;
        private ExcelDataSourceProperties _ExcelDataSourceProperties;
        private DBDataSourceProperties _DBDataSourceProperties;

        private UserClassProperties _UserClassProperties;

        //private BarChartProperties _BarChartProperties;
        private AbstractBarChartProperties _BarChartProperties;
        private BoxWhiskerChartProperties _BoxWhiskerChartProperties;
        private PieChartProperties _PieChartProperties;
        private DonutChartProperties _DonutChartProperties;
        private PlotProperties _PlotProperties;
        private TimePlotProperties _TimePlotProperties;
        private ScatterChartProperties _ScatterChartProperties;
        private HistogramProperties _HistogramProperties;
        private TileProperties _TileProperties;

        private DataSetProperties _DataSetProperties;
        private HistogramDataProperties _HistogramDataProperties;
        private StatisticsProperties _StatisticsProperties;

        private SimulationExperimentProperties _SimulationExperimentProperties;
        private ModelProperties _ModelProperties;

        private EventObjectModelProperties _EOMProperties;
        private StateObjectModelProperties _SOMProperties;
        private ActivityObjectModelProperties _AOMProperties;
        #endregion

        #region Properties
        public EntityProperties EntityProperties { get { return _EntityProperties; } }

        public CSVDataSourceProperties CSVDataSourceProperties { get { return _CSVDataSourceProperties; } }
        public ExcelDataSourceProperties ExcelDataSourceProperties { get { return _ExcelDataSourceProperties; } }

        public UserClassProperties UserClassProperties {  get { return _UserClassProperties; } }

        public DBDataSourceProperties DBDataSourceProperties { get { return _DBDataSourceProperties; } }
        public DataSetProperties DataSetProperties { get { return _DataSetProperties; } }
        public HistogramDataProperties HistogramDataProperties { get { return _HistogramDataProperties; } }
        public StatisticsProperties StatisticsProperties { get { return _StatisticsProperties; } }

        public SimulationExperimentProperties SimulationExperimentProperties { get { return _SimulationExperimentProperties; } }
        public ActivityObjectNodeProperties ActivityObjectNodeProperties { get { return _ActivityObjectNodeProperties; } }
        public EventObjectNodeProperties EventObjectNodeProperties { get { return _EventObjectNodeProperties; } }
        public ObjectSchedulingLinkProperties ObjectSchedulingLinkProperties { get { return _ObjectSchedulingLinkProperties; } }
        public StateObjectNodeProperties StateObjectNodeProperties {  get { return _StateObjectNodeProperties; } }
        public StateVariableUpdateLinkProperties StateVariableUpdateLinkProperties {  get { return _StateVariableUpdateProperties; } }
        public ModelProperties ModelProperties { get { return _ModelProperties; } }
        public EventObjectModelProperties EventObjectModelProperties { get { return _EOMProperties; } }
        public StateObjectModelProperties StateObjectModelProperties { get { return _SOMProperties; } }
        public ActivityObjectModelProperties ActivityObjectModelProperties { get { return _AOMProperties; } }

        public AbstractBarChartProperties BarChartProperties { get { return _BarChartProperties; } }
        public PieChartProperties PieChartProperties { get { return _PieChartProperties; } }
        public DonutChartProperties DonutChartProperties { get { return _DonutChartProperties; } }
        public ScatterChartProperties ScatterChartProperties { get { return _ScatterChartProperties; } }
        public HistogramProperties HistogramProperties { get { return _HistogramProperties; } }
        public BoxWhiskerChartProperties BoxWhiskerChartProperties { get { return _BoxWhiskerChartProperties; } }
        public TileProperties TileProperties { get { return _TileProperties; } }
        public PlotProperties PlotProperties { get { return _PlotProperties; } }
        public TimePlotProperties TimePlotProperties { get { return _TimePlotProperties; } }
        public TextProperties TextProperties { get { return _TextProperties; } }
        public LabelProperties LabelProperties { get { return _LabelProperties; } }

        #endregion

        #region Constructors
        public PropertiesWindow()
        {
            InitializeComponent();

            _EntityProperties = new EntityProperties();
            _EntityProperties.Dock = DockStyle.Fill;
            _EntityProperties.Visible = false;
            this.Controls.Add(_EntityProperties);

            _LabelProperties = new LabelProperties();
            _LabelProperties.Dock = DockStyle.Fill;
            _LabelProperties.Visible = false;
            this.Controls.Add(_LabelProperties);

            _TextProperties = new TextProperties();
            _TextProperties.Dock = DockStyle.Fill;
            _TextProperties.Visible = false;
            this.Controls.Add(_TextProperties);

            _ObjectSchedulingLinkProperties = new ObjectSchedulingLinkProperties();
            _ObjectSchedulingLinkProperties.Dock = DockStyle.Fill;
            _ObjectSchedulingLinkProperties.Visible = false;
            this.Controls.Add(_ObjectSchedulingLinkProperties);

            _DataAssociationProperties = new DataAssociationLinkProperties();
            _DataAssociationProperties.Dock = DockStyle.Fill;
            _DataAssociationProperties.Visible = false;
            this.Controls.Add(_DataAssociationProperties);

            _StateVariableUpdateProperties = new StateVariableUpdateLinkProperties();
            _StateVariableUpdateProperties.Dock = DockStyle.Fill;
            _StateVariableUpdateProperties.Visible = false;
            this.Controls.Add(_StateVariableUpdateProperties);

            _CSVDataSourceProperties = new CSVDataSourceProperties();
            _CSVDataSourceProperties.Dock = DockStyle.Fill;
            _CSVDataSourceProperties.Visible = false;
            this.Controls.Add(_CSVDataSourceProperties);

            _ExcelDataSourceProperties = new ExcelDataSourceProperties();
            _ExcelDataSourceProperties.Dock = DockStyle.Fill;
            _ExcelDataSourceProperties.Visible = false;
            this.Controls.Add(_ExcelDataSourceProperties);

            _DBDataSourceProperties = new DBDataSourceProperties();
            _DBDataSourceProperties.Dock = DockStyle.Fill;
            _DBDataSourceProperties.Visible = false;
            this.Controls.Add(_DBDataSourceProperties);

            _UserClassProperties = new UserClassProperties();
            _UserClassProperties.Dock = DockStyle.Fill;
            _UserClassProperties.Visible = false;
            this.Controls.Add(_UserClassProperties);

            _BarChartProperties = new AbstractBarChartProperties();
            _BarChartProperties.Dock = DockStyle.Fill;
            _BarChartProperties.Visible = false;
            this.Controls.Add(_BarChartProperties);

            _PieChartProperties = new PieChartProperties();
            _PieChartProperties.Dock = DockStyle.Fill;
            _PieChartProperties.Visible = false;
            this.Controls.Add(_PieChartProperties);

            _DonutChartProperties = new DonutChartProperties();
            _DonutChartProperties.Dock = DockStyle.Fill;
            _DonutChartProperties.Visible = false;
            this.Controls.Add(_DonutChartProperties);

            _BoxWhiskerChartProperties = new BoxWhiskerChartProperties();
            _BoxWhiskerChartProperties.Dock = DockStyle.Fill;
            _BoxWhiskerChartProperties.Visible = false;
            this.Controls.Add(_BoxWhiskerChartProperties);

            _ScatterChartProperties = new ScatterChartProperties();
            _ScatterChartProperties.Dock = DockStyle.Fill;
            _ScatterChartProperties.Visible = false;
            this.Controls.Add(_ScatterChartProperties);

            _HistogramProperties = new HistogramProperties();
            _HistogramProperties.Dock = DockStyle.Fill;
            _HistogramProperties.Visible = false;
            this.Controls.Add(_HistogramProperties);

            _TileProperties = new TileProperties();
            _TileProperties.Dock = DockStyle.Fill;
            _TileProperties.Visible = false;
            this.Controls.Add(_TileProperties);

            _PlotProperties = new PlotProperties();
            _PlotProperties.Dock = DockStyle.Fill;
            _PlotProperties.Visible = false;
            this.Controls.Add(_PlotProperties);

            _TimePlotProperties = new TimePlotProperties();
            _TimePlotProperties.Dock = DockStyle.Fill;
            _TimePlotProperties.Visible = false;
            this.Controls.Add(_TimePlotProperties);

            _DataSetProperties = new DataSetProperties();
            _DataSetProperties.Dock = DockStyle.Fill;
            _DataSetProperties.Visible = false;
            this.Controls.Add(_DataSetProperties);

            _HistogramDataProperties = new HistogramDataProperties();
            _HistogramDataProperties.Dock = DockStyle.Fill;
            _HistogramDataProperties.Visible = false;
            this.Controls.Add(_HistogramDataProperties);

            _StatisticsProperties = new StatisticsProperties();
            _StatisticsProperties.Dock = DockStyle.Fill;
            _StatisticsProperties.Visible = false;
            this.Controls.Add(_StatisticsProperties);

            _SimulationExperimentProperties = new SimulationExperimentProperties();
            _SimulationExperimentProperties.Dock = DockStyle.Fill;
            _SimulationExperimentProperties.Visible = false;
            this.Controls.Add(_SimulationExperimentProperties);

            _ActivityObjectNodeProperties = new ActivityObjectNodeProperties();
            _ActivityObjectNodeProperties.Dock = DockStyle.Fill;
            _ActivityObjectNodeProperties.Visible = false;
            this.Controls.Add(_ActivityObjectNodeProperties);

            _EventObjectNodeProperties = new EventObjectNodeProperties();
            _EventObjectNodeProperties.Dock = DockStyle.Fill;
            _EventObjectNodeProperties.Visible = false;
            this.Controls.Add(_EventObjectNodeProperties);

            _StateObjectNodeProperties = new StateObjectNodeProperties();
            _StateObjectNodeProperties.Dock = DockStyle.Fill;
            _StateObjectNodeProperties.Visible = false;
            this.Controls.Add(_StateObjectNodeProperties);

            _ModelProperties = new ModelProperties();
            _ModelProperties.Dock = DockStyle.Fill;
            _ModelProperties.Visible = false;
            this.Controls.Add(_ModelProperties);

            _EOMProperties = new EventObjectModelProperties();
            _EOMProperties.Dock = DockStyle.Fill;
            _EOMProperties.Visible = false;
            this.Controls.Add(_EOMProperties);

            _SOMProperties = new StateObjectModelProperties();
            _SOMProperties.Dock = DockStyle.Fill;
            _SOMProperties.Visible = false;
            this.Controls.Add(_SOMProperties);

            _AOMProperties = new ActivityObjectModelProperties();
            _AOMProperties.Dock = DockStyle.Fill;
            _AOMProperties.Visible = false;
            this.Controls.Add(_AOMProperties);
        }
        #endregion

        #region Methods
        public void Update(OOMMModel model, Object target)
        {
            _EntityProperties.Visible = false;
            _LabelProperties.Visible = false;
            _TextProperties.Visible = false;
            _ObjectSchedulingLinkProperties.Visible = false;
            _DataAssociationProperties.Visible = false;
            _StateVariableUpdateProperties.Visible = false;
            _CSVDataSourceProperties.Visible = false;
            _ExcelDataSourceProperties.Visible = false;
            _DBDataSourceProperties.Visible = false;
            _BarChartProperties.Visible = false;
            _PieChartProperties.Visible = false;
            _DonutChartProperties.Visible = false;
            _HistogramProperties.Visible = false;
            _BoxWhiskerChartProperties.Visible = false;
            _ScatterChartProperties.Visible = false;
            _PlotProperties.Visible = false;
            _TimePlotProperties.Visible = false;
            _DataSetProperties.Visible = false;
            _HistogramDataProperties.Visible = false;
            _StatisticsProperties.Visible = false;
            _SimulationExperimentProperties.Visible = false;
            _ModelProperties.Visible = false;
            _ActivityObjectNodeProperties.Visible = false;
            _EventObjectNodeProperties.Visible = false;
            _StateObjectNodeProperties.Visible = false;
            _EOMProperties.Visible = false;
            _SOMProperties.Visible = false;
            _AOMProperties.Visible = false;
            _UserClassProperties.Visible = false;

            if (target == null)
            {
                return;
            }
            else if (target is OOMMEntity)
            {
                _EntityProperties.Visible = true;
                _EntityProperties.BringToFront();
                OOMMEntity entity = (OOMMEntity)target;
                _EntityProperties.ShowEntity(model, entity);
            }
            else if (target is OOMMUserClass)
            {
                _UserClassProperties.Visible = true;
                _UserClassProperties.BringToFront();
                OOMMUserClass userclass = (OOMMUserClass)target;
                _UserClassProperties.Update(model, userclass);
            }
            else if (target is OOMMDataSource)
            {
                OOMMDataSource ds = (OOMMDataSource)target;

                if (((OOMMDataSource)target).Type == OOMMDataSourceType.CSV)
                {
                    _CSVDataSourceProperties.Visible = true;

                    _CSVDataSourceProperties.Visible = true;
                    _CSVDataSourceProperties.BringToFront();
                    _CSVDataSourceProperties.ShowDataSource(model, ds);
                }
                else if (((OOMMDataSource)target).Type == OOMMDataSourceType.EXCEL)
                {
                    _ExcelDataSourceProperties.Visible = true;
                    _ExcelDataSourceProperties.Visible = true;
                    _ExcelDataSourceProperties.BringToFront();
                    _ExcelDataSourceProperties.ShowDataSource(model, ds);
                }
                else if (((OOMMDataSource)target).Type == OOMMDataSourceType.DATABASE)
                {
                    _DBDataSourceProperties.Visible = true;
                    _DBDataSourceProperties.Visible = true;
                    _DBDataSourceProperties.BringToFront();
                    _DBDataSourceProperties.ShowDataSource(model, ds);
                }
            }
            else if (target is DataSetNode)
            {
                _DataSetProperties.Visible = true;
                _DataSetProperties.BringToFront();
                DataSetNode node = (DataSetNode)target;
                _DataSetProperties.Update(model, node);
            }
            else if (target is HistogramDataNode)
            {
                _HistogramDataProperties.Visible = true;
                _HistogramDataProperties.BringToFront();
                HistogramDataNode node = (HistogramDataNode)target;
                _HistogramDataProperties.Update(model, node);
            }
            else if (target is StatisticsNode)
            {
                _StatisticsProperties.Visible = true;
                _StatisticsProperties.BringToFront();
                StatisticsNode node = (StatisticsNode)target;
                _StatisticsProperties.Update(model, node);
            }
            else if (target is LabelNode)
            {
                _LabelProperties.Visible = true;
                _LabelProperties.BringToFront();
                LabelNode node = (LabelNode)target;
                _LabelProperties.Update(model, node);
            }
            else if (target is TextNode)
            {
                _TextProperties.Visible = true;
                _TextProperties.BringToFront();
                TextNode node = (TextNode)target;
                _TextProperties.Update(model, node);
            }
            else if (target is ObjectSchedulingLink)
            {
                _ObjectSchedulingLinkProperties.Visible = true;
                _ObjectSchedulingLinkProperties.BringToFront();
                ObjectSchedulingLink link = (ObjectSchedulingLink)target;
                _ObjectSchedulingLinkProperties.Update(model, link);
            }
            else if (target is DataAssociationLink)
            {
                _DataAssociationProperties.Visible = true;
                _DataAssociationProperties.BringToFront();
                DataAssociationLink link = (DataAssociationLink)target;
                _DataAssociationProperties.Update(model, link);
            }
            else if (target is StateVariableUpdateLink)
            {
                _StateVariableUpdateProperties.Visible = true;
                _StateVariableUpdateProperties.BringToFront();
                StateVariableUpdateLink link = (StateVariableUpdateLink)target;
                _StateVariableUpdateProperties.Update(model, link);
            }
            else if (target is EventObjectNode)
            {
                _EventObjectNodeProperties.Visible = true;
                _EventObjectNodeProperties.BringToFront();
                EventObjectNode node = (EventObjectNode)target;
                _EventObjectNodeProperties.Update(model, node);
            }
            else if (target is StateObjectNode)
            {
                _StateObjectNodeProperties.Visible = true;
                _StateObjectNodeProperties.BringToFront();
                StateObjectNode node = (StateObjectNode)target;
                _StateObjectNodeProperties.Update(model, node);
            }
            else if (target is ActivityObjectNode)
            {
                _ActivityObjectNodeProperties.Visible = true;
                _ActivityObjectNodeProperties.BringToFront();
                ActivityObjectNode node = (ActivityObjectNode)target;
                _ActivityObjectNodeProperties.Update(model, node);
            }
            else if (target is BarChart || target is HorizontalBarChart || target is StackedBarChart || target is StackedHorizontalBarChart)
            {
                _BarChartProperties.Visible = true;
                _BarChartProperties.BringToFront();
                AbstractChart bc = (AbstractChart)target;
                _BarChartProperties.Update(model, bc);
            }
            else if (target is PieChart)
            {
                _PieChartProperties.Visible = true;
                _PieChartProperties.BringToFront();
                PieChart bc = (PieChart)target;
                _PieChartProperties.Update(model, bc);
            }
            else if (target is DonutChart)
            {
                _DonutChartProperties.Visible = true;
                _DonutChartProperties.BringToFront();
                DonutChart bc = (DonutChart)target;
                _DonutChartProperties.Update(model, bc);
            }
            //else if (target is Pie)
            //{
            //    _PieChartProperties.Visible = true;
            //    _PieChartProperties.BringToFront();
            //    PieChart bc = (PieChart)((Pie)target).ParentNode;
            //    _PieChartProperties.Update(model, bc);
            //}
            else if (target is Plot)
            {
                _PlotProperties.Visible = true;
                _PlotProperties.BringToFront();
                Plot bc = (Plot)target;
                _PlotProperties.Update(model, bc);
            }
            else if (target is TimePlot)
            {
                _TimePlotProperties.Visible = true;
                _TimePlotProperties.BringToFront();
                TimePlot bc = (TimePlot)target;
                _TimePlotProperties.Update(model, bc);
            }
            else if (target is Histogram)
            {
                _HistogramProperties.Visible = true;
                _HistogramProperties.BringToFront();
                Histogram bc = (Histogram)target;
                _HistogramProperties.Update(model, bc);
            }
            else if (target is ScatterChart)
            {
                _ScatterChartProperties.Visible = true;
                _ScatterChartProperties.BringToFront();
                ScatterChart bc = (ScatterChart)target;
                _ScatterChartProperties.Update(model, bc);
            }
            else if (target is BoxWhiskerChart)
            {
                _BoxWhiskerChartProperties.Visible = true;
                _BoxWhiskerChartProperties.BringToFront();
                BoxWhiskerChart bc = (BoxWhiskerChart)target;
                _BoxWhiskerChartProperties.Update(model, bc);
            }
            else if (target is Tile)
            {
                _TileProperties.Visible = true;
                _TileProperties.BringToFront();
                Tile bc = (Tile)target;
                _TileProperties.Update(model, bc);
            }

            else if (target is OOMMExperiment)
            {
                _SimulationExperimentProperties.Visible = true;
                _SimulationExperimentProperties.BringToFront();
                OOMMExperiment exp = (OOMMExperiment)target;
                _SimulationExperimentProperties.Update(exp);
            }
            else if (target is OOMMModel)
            {
                _ModelProperties.Visible = true;
                _ModelProperties.BringToFront();
                OOMMModel m = (OOMMModel)target;
                _ModelProperties.Update(m);
            }
            else if (target is OOEGEventObjectModel)
            {
                _EOMProperties.Visible = true;
                _EOMProperties.BringToFront();
                OOEGEventObjectModel eoModel = (OOEGEventObjectModel)target;
                _EOMProperties.Update(eoModel);
            }
            else if (target is OOSGStateObjectModel)
            {
                _SOMProperties.Visible = true;
                _SOMProperties.BringToFront();
                OOSGStateObjectModel soModel = (OOSGStateObjectModel)target;
                _SOMProperties.Update(soModel);
            }
            else if (target is OOAGActivityObjectModel)
            {
                _AOMProperties.Visible = true;
                _AOMProperties.BringToFront();
                OOAGActivityObjectModel aoModel = (OOAGActivityObjectModel)target;
                _AOMProperties.Update(aoModel);
            }
        }
        #endregion
    }
}