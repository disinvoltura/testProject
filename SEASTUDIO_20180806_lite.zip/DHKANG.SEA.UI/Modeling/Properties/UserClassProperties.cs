﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using DHKANG.SEA.Model.Entities;
using DHKANG.SEA.Model;
using DHKANG.SEA.UI.Modeling.Properties;

namespace DHKANG.SEA.UI.Modeling
{
    public delegate void UserClassChangedEventHandler(OOMMUserClass changedValue);

    public partial class UserClassProperties : UserControl
    {
        #region Member Variables
        private List<OOMMUserClass> _UserClasses;
        private string[] Columns = new string[] { "Name", "Type", "Initial Value" };
        private OOMMUserClass _CurrentUserClass;
        private OOMMModel _Model;


        private PropertyCellValueChangedEventController _PropertyCellValueChangeController;
        private MethodCellValueChangedEventController _MethodCellValueChangeController;

        #endregion

        #region Events
        public event UserClassChangedEventHandler UserClassChanged;
        #endregion

        #region Properties
        public List<OOMMUserClass> UserClasses { get { return _UserClasses; } }


        #endregion

        public UserClassProperties()
        {
            InitializeComponent();

            setupPropertiesSection();
            setupMethodsSection();
        }

        private void setupPropertiesSection()
        {
            properties.Rows.Clear();

            properties.BorderStyle = BorderStyle.FixedSingle;
            properties.Redim(1, 5);
            properties.EnableSort = false;
            properties.CustomSort = false;
            properties.FixedRows = 1;

            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            properties.Font = new Font("Calibri", 10);

            properties.Columns[0].AutoSizeMode = SourceGrid.AutoSizeMode.None;
            properties.Columns[0].Width = 25;
            SourceGrid.Cells.RowHeader l_00Header1 = new SourceGrid.Cells.RowHeader(null);
            properties[0, 0] = l_00Header1;

            string[] columns = new string[] { "Name", "Type", "Access", "Initial Value" };
            for (int i = 0; i < columns.Length; i++)
            {
                SourceGrid.Cells.ColumnHeader header = new SourceGrid.Cells.ColumnHeader(columns[i]);
                header.View = titleModel;
                header.SortComparer = new SourceGrid.ValueCellComparer();
                properties[0, i + 1] = header;
            }

            properties.Columns[1].Width = 100;
            properties.Columns[2].Width = 100;
            properties.Columns[3].Width = 100;
            properties.Columns[4].Width = 100;

            //properties.AutoSizeCells();

            _PropertyCellValueChangeController = new PropertyCellValueChangedEventController();
            _PropertyCellValueChangeController.ValueChanged +=
                new PropertyCellValueChangedEventHandler(OnPropertyCellValueChanged);

        }

        private void OnPropertyCellValueChanged(int row, int col, string oldValue, string newValue)
        {
            //change the respective attribute of a property
            OOMMUserClassProperty property = (OOMMUserClassProperty)properties[row, 0].Tag;
            if (col == 1)
            {
                //string name = properties[row, 1].DisplayText;
                property.Name = newValue;
            }else if (col == 2)
            {
                property.ValueType = newValue;
            }else if (col == 3)
            {
                string newAccessor = newValue.ToLower();
                if (newAccessor == "private")
                    property.Accessor = AccessorType.Private;
                else if (newAccessor == "public")
                    property.Accessor = AccessorType.Public;
                else
                    property.Accessor = AccessorType.Protected;
            }else if (col == 4)
            {
                property.InitialValue = newValue;
            }

            this.notityPropertyChangedEvent();
        }

        private SourceGrid.Cells.Views.Cell getCellView()
        {
            SourceGrid.Cells.Views.Cell cellModel = new SourceGrid.Cells.Views.Cell();
            DevAge.Drawing.VisualElements.BackgroundSolid bg = new DevAge.Drawing.VisualElements.BackgroundSolid();
            bg.BackColor = Color.White;
            cellModel.Background = bg;
            cellModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            return cellModel;
        }

        private SourceGrid.Cells.Editors.ComboBox getTypeComboxBoxEditor()
        {
            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));

            List<string> types = new List<string>();
            //add basic value types
            OOMMStateVariableHelper.ValueType().ForEach(vt => types.Add(vt));
            //add entity types
            _Model.Entities.ForEach(e => types.Add(e.Name));
            //add exisitng user class
            _Model.UserClasses.ForEach(uc => types.Add(uc.Name));
            types.Sort();
            cbEditor.StandardValues = types.ToArray<string>();
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;

            return cbEditor;
        }

        private SourceGrid.Cells.Editors.ComboBox getReturningTypeComboxBoxEditor()
        {
            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));

            List<string> types = new List<string>();
            //add basic value types
            OOMMStateVariableHelper.ValueType().ForEach(vt => types.Add(vt));
            //add entity types
            _Model.Entities.ForEach(e => types.Add(e.Name));
            //add exisitng user class
            _Model.UserClasses.ForEach(uc => types.Add(uc.Name));
            types.Add("void");
            types.Sort();
            cbEditor.StandardValues = types.ToArray<string>();
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;

            return cbEditor;
        }

        private SourceGrid.Cells.Editors.ComboBox getAccessComboxBoxEditor()
        {
            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            List<string> types = new List<string>() { "Private", "Protected", "Public" };
            types.Sort();
            cbEditor.StandardValues = types.ToArray<string>();
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;
            return cbEditor;
        }

        private void insertProperty(OOMMUserClassProperty property)
        {
            //string[] columns = new string[] { "Name", "Type", "Access", "Initial Value" };

            int rowIndex = properties.RowsCount;
            properties.Rows.Insert(rowIndex);

            SourceGrid.Cells.CheckBox cbCell = new SourceGrid.Cells.CheckBox("", false);
            cbCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            cbCell.Tag = property;

            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(property.Name, typeof(string));
            nameCell.View = getCellView();
            nameCell.AddController(_PropertyCellValueChangeController);

            SourceGrid.Cells.Editors.ComboBox cbEditor1 = getTypeComboxBoxEditor();
            SourceGrid.Cells.Cell typeCell = new SourceGrid.Cells.Cell(property.ValueType, cbEditor1);
            typeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            typeCell.View = SourceGrid.Cells.Views.ComboBox.Default;
            typeCell.AddController(_PropertyCellValueChangeController);

            SourceGrid.Cells.Editors.ComboBox cbEditor2 = getAccessComboxBoxEditor();
            SourceGrid.Cells.Cell accessCell = new SourceGrid.Cells.Cell(property.Accessor.ToString(), cbEditor2);
            accessCell.View = getCellView();
            accessCell.AddController(_PropertyCellValueChangeController);

            SourceGrid.Cells.Cell valueCell = new SourceGrid.Cells.Cell(property.InitialValue, typeof(string));
            valueCell.View = getCellView();
            valueCell.AddController(_PropertyCellValueChangeController);

            properties[rowIndex, 0] = cbCell;
            properties[rowIndex, 1] = nameCell;
            properties[rowIndex, 2] = typeCell;
            properties[rowIndex, 3] = accessCell;
            properties[rowIndex, 4] = valueCell;            
        }

        private string getNextPropertyName()
        {
            string rslt = "Property1";
            string expr = @"Property[\s]*([0-9\-]*)";
            if (properties.Rows.Count == 1)
                return rslt;

            int nextNumber = 0;
            for (int i = 1; i < properties.Rows.Count; i++)
            {
                string name = (string)properties[i, 1].Value;
                int number = 0;
                if (Regex.IsMatch(name, expr))
                {
                    Match m = Regex.Match(name, @"\d+");
                    if (int.TryParse(m.Value, out number))
                    {
                        if (number > nextNumber)
                            nextNumber = number;
                    }
                }
            }
            nextNumber++;
            rslt = "Property" + nextNumber;

            return rslt;
        }

        private void insertNewProperty()
        {
            //generate new name....
            string newName = getNextPropertyName();

            OOMMUserClassProperty newProperty = new OOMMUserClassProperty(newName, "int", AccessorType.Public, "0");
            _CurrentUserClass.Properties.Add(newProperty);
            insertProperty(newProperty);
        }

        private void btnAddProperty_Click(object sender, EventArgs e)
        {
            insertNewProperty();
            notityPropertyChangedEvent();
        }

        private void btnRemoveProperty_Click(object sender, EventArgs e)
        {
            if (properties.Rows.Count == 1)
                return;

            int count = 0;
            for (int i = properties.Rows.Count - 1; i >= 1; i--)
            {
                if (((SourceGrid.Cells.CheckBox)properties[i, 0]).Checked.GetValueOrDefault())
                {
                    string name = properties[i, 1].DisplayText;
                    if (!string.IsNullOrEmpty(name))
                        _CurrentUserClass.RemoveProperty(name);
                    properties.Rows.Remove(i);
                    count++;
                }
            }
            if (count > 0)
            {
                notityPropertyChangedEvent();
            }
        }


        private void notityPropertyChangedEvent()
        {
            if (UserClassChanged != null && UserClassChanged.GetInvocationList().Length > 0)
                UserClassChanged(_CurrentUserClass);
        }

        private void setupMethodsSection()
        {
            methods.Rows.Clear();

            methods.BorderStyle = BorderStyle.FixedSingle;
            methods.Redim(1, 6);
            methods.EnableSort = false;
            methods.CustomSort = false;
            methods.FixedRows = 1;

            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            methods.Font = new Font("Calibri", 10);
            methods.Columns[0].AutoSizeMode = SourceGrid.AutoSizeMode.None;
            methods.Columns[0].Width = 25;
            SourceGrid.Cells.RowHeader l_00Header1 = new SourceGrid.Cells.RowHeader(null);
            methods[0, 0] = l_00Header1;

            string[] columns = new string[] { "Name", "Access", "Return Type", "Arguments", "Body" };
            for (int i = 0; i < columns.Length; i++)
            {
                SourceGrid.Cells.ColumnHeader header = new SourceGrid.Cells.ColumnHeader(columns[i]);
                header.View = titleModel;
                header.SortComparer = new SourceGrid.ValueCellComparer();
                methods[0, i + 1] = header;
            }

            methods.Columns[1].Width = 100;
            methods.Columns[2].Width = 100;
            methods.Columns[3].Width = 100;
            methods.Columns[4].Width = 100;
            methods.Columns[5].Width = 100;

            //methods.AutoSizeCells();

            _MethodCellValueChangeController = new MethodCellValueChangedEventController();
            _MethodCellValueChangeController.ValueChanged +=
                new MethodCellValueChangedEventHandler(OnMethodCellValueChanged);
        }

        private void OnMethodCellValueChanged(int row, int col, string oldValue, string newValue)
        {
            //TODO
            //change the respective attribute of a method
            OOMMUserClassMethod method = (OOMMUserClassMethod)methods[row, 0].Tag;
            if (col == 1)
            {
                method.Name = newValue;
            }
            else if (col == 2)
            {
                string newAccessor = newValue.ToLower();
                if (newAccessor == "private")
                    method.Accessor = AccessorType.Private;
                else if (newAccessor == "public")
                    method.Accessor = AccessorType.Public;
                else
                    method.Accessor = AccessorType.Protected;
            }
            else if (col == 3)
            {
                method.ReturnType = newValue;
            }          
            else if (col == 4)
            {
                method.Parameters = newValue;
            }else if (col == 5)
            {
                method.MethodBody = newValue;
            }

            this.notityPropertyChangedEvent();

        }

        private void insertMethod(OOMMUserClassMethod method)
        {
            //string[] columns = new string[] { "Name", "Access", "Return Type", "Arguments", "Body"};

            int rowIndex = methods.RowsCount;
            methods.Rows.Insert(rowIndex);

            SourceGrid.Cells.CheckBox cbCell = new SourceGrid.Cells.CheckBox("", false);
            cbCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            cbCell.Tag = method;

            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(method.Name, typeof(string));
            nameCell.View = getCellView();
            nameCell.AddController(_MethodCellValueChangeController);

            SourceGrid.Cells.Editors.ComboBox cbEditor1 = getAccessComboxBoxEditor();
            SourceGrid.Cells.Cell accessCell = new SourceGrid.Cells.Cell(method.Accessor, cbEditor1);
            accessCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            accessCell.View = SourceGrid.Cells.Views.ComboBox.Default;
            accessCell.AddController(_MethodCellValueChangeController);

            SourceGrid.Cells.Editors.ComboBox cbEditor2 = getReturningTypeComboxBoxEditor();
            SourceGrid.Cells.Cell typeCell = new SourceGrid.Cells.Cell(method.ReturnType, cbEditor2);
            typeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            typeCell.View = SourceGrid.Cells.Views.ComboBox.Default;
            typeCell.AddController(_MethodCellValueChangeController);

            SourceGrid.Cells.Cell paramCell = new SourceGrid.Cells.Cell(method.Parameters, typeof(string));
            paramCell.View = getCellView();
            paramCell.AddController(_MethodCellValueChangeController);

            SourceGrid.Cells.Cell bodyCell = new SourceGrid.Cells.Cell(method.MethodBody, typeof(string));
            bodyCell.View = getCellView();
            SourceGrid.Cells.Editors.TextBoxButton button = new SourceGrid.Cells.Editors.TextBoxButton(typeof(string));
            bodyCell.Editor = button;
            button.Control.Button.Click += OnBodyEditButtonClicked;
            //MethodBodyEditorDialog codeEditor = new MethodBodyEditorDialog();
            //bodyCell.Editor = codeEditor;

            bodyCell.AddController(_MethodCellValueChangeController);

            methods[rowIndex, 0] = cbCell;
            methods[rowIndex, 1] = nameCell;
            methods[rowIndex, 2] = accessCell;
            methods[rowIndex, 3] = typeCell;
            methods[rowIndex, 4] = paramCell;
            methods[rowIndex, 5] = bodyCell;
        }
        
        private void OnBodyEditButtonClicked(object sender, EventArgs e)
        {
            DevAge.Windows.Forms.DevAgeTextBoxButton btn =
                (DevAge.Windows.Forms.DevAgeTextBoxButton)((Button)sender).Parent;

            OOMMUserClassMethod method = (OOMMUserClassMethod)methods[methods.Selection.ActivePosition.Row, 0].Tag;

            string strValue = (string)btn.TextBox.Text;

            MethodBodyEditor editor = new MethodBodyEditor(method);
            editor.ShowDialog();

            if (editor.DialogResult == DialogResult.OK)
            {
                btn.TextBox.Text = editor.Action;
                method.MethodBody = editor.Action;
            }
        }        

        private string getNextMethodName()
        {
            string rslt = "Method1";
            string expr = @"Method[\s]*([0-9\-]*)";
            if (methods.Rows.Count == 1)
                return rslt;

            int nextNumber = 0;
            for (int i = 1; i < methods.Rows.Count; i++)
            {
                string name = (string)methods[i, 1].Value;
                int number = 0;
                if (Regex.IsMatch(name, expr))
                {
                    Match m = Regex.Match(name, @"\d+");
                    if (int.TryParse(m.Value, out number))
                    {
                        if (number > nextNumber)
                            nextNumber = number;
                    }
                }
            }
            nextNumber++;
            rslt = "Method" + nextNumber;

            return rslt;
        }

        private void insertNewMethod()
        {
            //generate new name... Method1...
            string newName = getNextMethodName();

            OOMMUserClassMethod newMethod = new OOMMUserClassMethod(newName, AccessorType.Private, "", "", "void");
            _CurrentUserClass.Methods.Add(newMethod);
            insertMethod(newMethod);
        }

        private void btnAddMethod_Click(object sender, EventArgs e)
        {
            insertNewMethod();
            notityPropertyChangedEvent();
        }

        private void btnRemoveMethod_Click(object sender, EventArgs e)
        {
            if (properties.Rows.Count == 1)
                return;

            int count = 0;
            for (int i = properties.Rows.Count - 1; i >= 1; i--)
            {
                if (((SourceGrid.Cells.CheckBox)properties[i, 0]).Checked.GetValueOrDefault())
                {
                    string name = properties[i, 1].DisplayText;
                    if (!string.IsNullOrEmpty(name))
                        _CurrentUserClass.RemoveProperty(name);
                    properties.Rows.Remove(i);
                    count++;
                }
            }
            if (count > 0)
            {
                notityPropertyChangedEvent();
            }
        }

        private void handleNameChanged() { 
            string oldValue = _CurrentUserClass.Name;
            string newValue = txtName.Text;

            _CurrentUserClass.Name = newValue;

            if (UserClassChanged != null && UserClassChanged.GetInvocationList().Length > 0)
                UserClassChanged(_CurrentUserClass);
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            handleNameChanged();
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleNameChanged();
            }
        }

        public void Update(OOMMModel model, OOMMUserClass userClass)
        {
            _Model = model;
            _CurrentUserClass = userClass;

            txtName.Text = userClass.Name;

            //super class
            List<OOMMUserClass> ucList = model.UserClasses;
            ucList.Sort(delegate (OOMMUserClass x, OOMMUserClass y)
            {                
                return x.Name.CompareTo(y.Name);
            });
            
            cbSuperClasses.Items.Clear();
            cbSuperClasses.Items.Add("");
            ucList.ForEach(uc => cbSuperClasses.Items.Add(uc.Name));

            //properties
            _CurrentUserClass.Properties.ForEach(p => insertProperty(p));

            //methods
            _CurrentUserClass.Methods.ForEach(m => insertMethod(m));
        }

        private void cbSuperClasses_SelectedIndexChanged(object sender, EventArgs e)
        {
            OnSuperClassChanged();
        }
        private void OnSuperClassChanged() { 
            string oldValue = _CurrentUserClass.InheritedClass;
            string newValue = cbSuperClasses.Text;

            _CurrentUserClass.InheritedClass = newValue;

            if (UserClassChanged != null && UserClassChanged.GetInvocationList().Length > 0)
                UserClassChanged(_CurrentUserClass);
        }

        
    }

    public delegate void PropertyCellValueChangedEventHandler(int row, int col, string oldValue, string newValue);
    public class PropertyCellValueChangedEventController : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event PropertyCellValueChangedEventHandler ValueChanged;

        public PropertyCellValueChangedEventController() { }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);
            ValueChanged(sender.Position.Row, sender.Position.Column, e.OldValue == null ? "" : e.OldValue.ToString(), e.NewValue.ToString());
        }
    }

    public delegate void MethodCellValueChangedEventHandler(int row, int col, string oldName, string newName);
    public class MethodCellValueChangedEventController : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event MethodCellValueChangedEventHandler ValueChanged;

        public MethodCellValueChangedEventController() { }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);
            ValueChanged(sender.Position.Row, sender.Position.Column, e.OldValue == null ? "" : e.OldValue.ToString(), e.NewValue.ToString());
        }
    }
}
