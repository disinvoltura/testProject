﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.OID;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.StateObjects;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public partial class StateVariableUpdateLinkProperties: UserControl
    {
        private StateVariableUpdateLink _Link;
        private OOMMModel _Model;

        private bool isUpdating = false;

        #region Events
        public event PropertyValueChangedEventHandler PropertyValueChanged;
        #endregion

        public StateVariableUpdateLinkProperties()
        {
            InitializeComponent();
        }

        public void Update(OOMMModel model, StateVariableUpdateLink link)
        {
            _Link = link;
            _Model = model;

            showProperties();
        }

        private void showProperties()
        {
            isUpdating = true;

            MultiPortNode fromNode = null;
            if (_Link.FromNode is MultiPortNode)
                fromNode = (MultiPortNode)_Link.FromNode;
            MultiPortNode toNode = null;
            if (_Link.ToNode is MultiPortNode)
                toNode = (MultiPortNode)_Link.ToNode;

            initializeLocalEvents(fromNode, toNode);
            //EventObjectNode fromEventObject = (EventObjectNode)fromNode.UserObject;
            //EventObjectNode toEventObject = (EventObjectNode)toNode.UserObject;
            //initializeLocalEvents(fromEventObject, toEventObject);

            if (_Link.FromTriggerName != null && !string.IsNullOrEmpty(_Link.FromTriggerName))
                cbSrcSV.Text = _Link.FromTriggerName;
            if (_Link.ToTriggerName != null && !string.IsNullOrEmpty(_Link.ToTriggerName))
                cbDestSV.Text = _Link.ToTriggerName;

            isUpdating = false;
        }

        private void initializeLocalEvents(MultiPortNode fromNode, MultiPortNode toNode) {

            if (fromNode.UserObject is EventObjectNode)
            {
                label1.Text = "Event Object:";
                EventObjectNode eoNode = (EventObjectNode)fromNode.UserObject;
                OOEGEventObjectModel fromEOM = _Model.FindEventObjectModel(eoNode.Model.ID);
                txtMirrorObject.Text = fromNode.NodeName;
                cbSrcSV.Items.Clear();
                foreach (OOEGStateVariable sv in fromEOM.StateVariables)
                {
                    cbSrcSV.Items.Add(sv.Name);
                }
            }
            else if (fromNode.UserObject is StateObjectNode)
            {
                label1.Text = "State Object:";
                StateObjectNode soNode = (StateObjectNode)fromNode.UserObject;
                OOSGStateObjectModel fromSOM = _Model.FindStateObjectModel(soNode.Model.ID);
                txtMirrorObject.Text = fromNode.NodeName;
                cbSrcSV.Items.Clear();
                foreach (OOSGStateVariable sv in fromSOM.StateVariables)
                {
                    cbSrcSV.Items.Add(sv.Name);
                }
            }

            if (toNode.UserObject is EventObjectNode)
            {
                label2.Text = "Event Object:";
                EventObjectNode eoNode = (EventObjectNode)toNode.UserObject;
                OOEGEventObjectModel toEOM = _Model.FindEventObjectModel(eoNode.Model.ID);
                htxtBoundaryObject.Text = toNode.NodeName;

                cbDestSV.Items.Clear();
                foreach (OOEGStateVariable sv in toEOM.StateVariables)
                {
                    cbDestSV.Items.Add(sv.Name);
                }
            } else if (toNode.UserObject is StateObjectNode)
            {
                label2.Text = "State Object:";
                StateObjectNode soNode = (StateObjectNode)toNode.UserObject;
                OOSGStateObjectModel toSOM = _Model.FindStateObjectModel(soNode.Model.ID);
                htxtBoundaryObject.Text = toNode.NodeName;

                cbDestSV.Items.Clear();
                foreach (OOSGStateVariable sv in toSOM.StateVariables)
                {
                    cbDestSV.Items.Add(sv.Name);
                }
            }
        }

        /*
        private void initializeLocalEvents(EventObjectNode fromNode, EventObjectNode toNode)
        {
            OOMMObjectInteractionDiagram diagram = _Model.ObjectInteractionDiagram;

            OOEGEventObjectModel fromEOM = _Model.FindEventObjectModel(fromNode.Model.ID);
            OOEGEventObjectModel toEOM = _Model.FindEventObjectModel(toNode.Model.ID);

            if (fromEOM == null || toEOM == null)
                return;

            txtMirrorObject.Text = fromNode.NodeName;
            htxtBoundaryObject.Text = toNode.NodeName;

            //Mirror Event: state change is not allowed
            cbSrcSV.Items.Clear();
            foreach (OOEGStateVariable sv in fromEOM.StateVariables)
            {
                cbSrcSV.Items.Add(sv.Name);
            }
            cbDestSV.Items.Clear();
            foreach (OOEGStateVariable sv in toEOM.StateVariables)
            {
                cbDestSV.Items.Add(sv.Name);
            }
        }
        */

        private void cbMirrorEvents_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            if (string.IsNullOrEmpty(cbSrcSV.Text))
                return;

            string oldValue = _Link.FromTriggerName;
            _Link.FromTriggerName = cbSrcSV.Text;

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Link, "FromTrigger", oldValue, cbSrcSV.Text);
        }

        private void cbBoundaryEvents_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            if (string.IsNullOrEmpty(cbDestSV.Text))
                return;

            string oldValue = _Link.ToTriggerName;
            _Link.ToTriggerName = cbDestSV.Text;

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Link, "ToTrigger", oldValue, cbDestSV.Text);

        }
    }
}
