﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.OID;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model.ActivityObjects;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public partial class ObjectSchedulingLinkProperties : UserControl
    {
        private ObjectSchedulingLink _Link;
        private OOMMModel _Model;

        private bool isUpdating = false;

        private ParameterGridValueChangedEvent valueChangedController;

        #region Events
        public event PropertyValueChangedEventHandler PropertyValueChanged;
        #endregion

        public ObjectSchedulingLinkProperties()
        {
            InitializeComponent();

            drawHeaders();

            valueChangedController = new ParameterGridValueChangedEvent();
            valueChangedController.ValueChanged += new ParameterGridValueChangedEventHandler(OnParameterGridValueChanged);
        }

        public void Update(OOMMModel model, ObjectSchedulingLink link)
        {
            _Link = link;
            _Model = model;

            showProperties();
        }

        private MultiPortNode _FromNode;
        private MultiPortNode _ToNode;

        private void showProperties()
        {
            isUpdating = true;

            _FromNode = null;
            if (_Link.FromNode is MultiPortNode)
                _FromNode = (MultiPortNode)_Link.FromNode;
            _ToNode = null;
            if (_Link.ToNode is MultiPortNode)
                _ToNode = (MultiPortNode)_Link.ToNode;

            initializeLocalEvents(_FromNode, _ToNode);

            if (_Link.FromTriggerName != null && !string.IsNullOrEmpty(_Link.FromTriggerName))
            {
                cbMirrorTriggers.SelectedItem = _Link.FromTriggerName;
                cbMirrorTriggers.Text = _Link.FromTriggerName;
            }else
            {
                cbMirrorTriggers.Text = "";
            }
            if (_Link.ToTriggerName != null && !string.IsNullOrEmpty(_Link.ToTriggerName))
            {
                cbBoundaryTriggers.SelectedItem = _Link.ToTriggerName;
                cbBoundaryTriggers.Text = _Link.ToTriggerName;
            }else
            {
                cbBoundaryTriggers.Text = "";
            }

            //if (_Link.Parameters != null && !string.IsNullOrEmpty(_Link.Parameters))
            //    txtParameters.Text = _Link.Parameters;

            cbParam.Checked = _Link.HasParameterMatch;
            if (_Link.HasParameterMatch)
                updateParameters(_Link.Parameters);
                
            isUpdating = false;
        }


        private void initializeLocalEvents(MultiPortNode fromNode, MultiPortNode toNode)
        {
            OOMMObjectInteractionDiagram diagram = _Model.ObjectInteractionDiagram;
            cbMirrorTriggers.Items.Clear();
            cbMirrorTriggers.SelectedItem = "";
            cbMirrorTriggers.Text = "";

            cbBoundaryTriggers.Items.Clear();
            cbBoundaryTriggers.SelectedItem = "";
            cbBoundaryTriggers.Text = "";

            if (fromNode.UserObject is EventObjectNode)
            {
                label1.Text = "Event Object:";
                label3.Text = "Local Event:";
                EventObjectNode eoNode = (EventObjectNode)fromNode.UserObject;
                OOEGEventObjectModel fromEOM = _Model.FindEventObjectModel(eoNode.Model.ID);
                txtMirrorObject.Text = fromNode.NodeName;
                foreach (OOEGEventTransition et in fromEOM.EventTransitions)
                {
                    if (string.IsNullOrEmpty(et.Action))
                        cbMirrorTriggers.Items.Add(et.Event.Name);
                }
            }
            else if (fromNode.UserObject is StateObjectNode)
            {
                label1.Text = "State Object:";
                label3.Text = "Output Message:";
                StateObjectNode soNode = (StateObjectNode)fromNode.UserObject;
                OOSGStateObjectModel fromSOM = _Model.FindStateObjectModel(soNode.Model.ID);
                txtMirrorObject.Text = fromNode.NodeName;
                foreach (OOSGMessage m in fromSOM.Messages)
                {
                    if (m.Type == MessageType.Output)
                    {
                        cbMirrorTriggers.Items.Add(m.MName);
                    }
                }
            }
            else if (fromNode.UserObject is ActivityObjectNode)
            {
                label1.Text = "Activity Object:";
                label3.Text = "Activity:";
                ActivityObjectNode aoNode = (ActivityObjectNode)fromNode.UserObject;
                OOAGActivityObjectModel fromAOM = _Model.FindActivityObjectModel(aoNode.Model.ID);
                txtMirrorObject.Text = fromNode.NodeName;
                foreach (OOAGActivityTransition at in fromAOM.ActivityTransitions)
                {
                    cbMirrorTriggers.Items.Add(at.Activity.Name);
                }
            }

            if (toNode.UserObject is EventObjectNode)
            {
                label2.Text = "Event Object:";
                label4.Text = "Local Event:";

                EventObjectNode eoNode = (EventObjectNode)toNode.UserObject;
                OOEGEventObjectModel toEOM = _Model.FindEventObjectModel(eoNode.Model.ID);
                txtBoundaryObject.Text = toNode.NodeName;
                foreach (OOEGEventTransition et in toEOM.EventTransitions)
                {
                    cbBoundaryTriggers.Items.Add(et.Event.Name);
                }
            }
            else if (toNode.UserObject is StateObjectNode)
            {
                label2.Text = "State Object:";
                label4.Text = "Input Message:";

                StateObjectNode soNode = (StateObjectNode)toNode.UserObject;
                OOSGStateObjectModel toSOM = _Model.FindStateObjectModel(soNode.Model.ID);
                txtBoundaryObject.Text = toNode.NodeName;
                foreach (OOSGMessage m in toSOM.Messages)
                {
                    if (m.Type == MessageType.Input)
                        cbBoundaryTriggers.Items.Add(m.MName);
                }
            }
            else if (toNode.UserObject is ActivityObjectNode)
            {
                label2.Text = "Activity Object:";
                label4.Text = "Queue:";

                ActivityObjectNode aoNode = (ActivityObjectNode)toNode.UserObject;
                OOAGActivityObjectModel toAOM = _Model.FindActivityObjectModel(aoNode.Model.ID);
                txtBoundaryObject.Text = toNode.NodeName;
                foreach (OOAGQueue q in toAOM.Queues)
                {
                    cbBoundaryTriggers.Items.Add(q.Name);
                }
            }
        }

        private void txtParameters_TextChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            string oldValue = _Link.Parameters;
            _Link.Parameters = txtParameters.Text;
            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Link, "Parameters", oldValue, txtParameters.Text);
        }

        private void cbMirrorEvents_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            if (string.IsNullOrEmpty(cbMirrorTriggers.Text))
                return;

            string oldValue = _Link.FromTriggerName;
            _Link.FromTriggerName = cbMirrorTriggers.Text;

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Link, "FromTrigger", oldValue, cbMirrorTriggers.Text);
        }

        private void cbBoundaryEvents_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            if (string.IsNullOrEmpty(cbBoundaryTriggers.Text))
                return;

            string oldValue = _Link.ToTriggerName;
            _Link.ToTriggerName = cbBoundaryTriggers.Text;

            if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                PropertyValueChanged(_Model.ID, _Link, "ToTrigger", oldValue, cbBoundaryTriggers.Text);
        }

        #region Methods: Parameters
        private void updateParameters(string parameterMatch)
        {
            drawHeaders();

            List<string> destParamList = getDestParamList();
            string[] pairs = parameterMatch.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            Dictionary<string, string> match = new Dictionary<string, string>();
            foreach(String pair in pairs)
            {
                string[] plist = pair.Split(new char[] {':'}, StringSplitOptions.RemoveEmptyEntries);
                match.Add(plist[0], plist[1]);

                InsertParameter(plist[0], plist[1], destParamList);
            }
        }

        private void updateParameters()
        {
            if (!cbParam.Checked)
                return;

            drawHeaders();

            //No map exists
            cbParam.Enabled = true;
            if (_FromNode.UserObject is EventObjectNode)
            {
                EventObjectNode eoNode = (EventObjectNode)_FromNode.UserObject;
                OOEGEventObjectModel fromEOM = _Model.FindEventObjectModel(eoNode.Model.ID);
                OOEGEvent fromEvent = null;
                foreach (OOEGEventTransition et in fromEOM.EventTransitions)
                {
                    if (et.Event.Name.Equals(cbMirrorTriggers.Text))
                    {
                        fromEvent = et.Event;
                        break;
                    }
                }
                if (fromEvent != null)
                {
                    if (string.IsNullOrEmpty(fromEvent.Parameters))
                    {
                        cbParam.Enabled = false;
                        return;
                    }
                    else
                    {
                        List<string> destParameters = getDestParamList();                        
                        String[] parameters = fromEvent.Parameters.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                        foreach (string pName in parameters)
                        {
                            InsertParameter(pName, destParameters);
                        }

                    }
                }
                else if (_FromNode.UserObject is StateObjectNode)
                {
                    StateObjectNode soNode = (StateObjectNode)_FromNode.UserObject;
                    OOSGStateObjectModel som = _Model.FindStateObjectModel(soNode.Model.ID);

                    OOSGMessage msg = null;
                    msg = som.FindMessage(cbMirrorTriggers.Text);
                    if (msg != null)
                    {
                        List<string> destParameters = getDestParamList(); 
                        foreach (OOSGMessageParameter mp in msg.Parameters)
                        {
                            InsertParameter(mp.Name, destParameters);
                        }
                    }
                }
            }
        }

        private List<string> getDestParamList()
        {
            List<string> rslt = new List<string>();
            if (_ToNode.UserObject is EventObjectNode)
            {
                EventObjectNode eoNode = (EventObjectNode)_ToNode.UserObject;
                OOEGEventObjectModel eom = _Model.FindEventObjectModel(eoNode.Model.ID);
                OOEGEvent toEvent = null;
                foreach (OOEGEventTransition et in eom.EventTransitions)
                {
                    if (et.Event.Name.Equals(cbBoundaryTriggers.Text))
                    {
                        toEvent = et.Event;
                        break;
                    }
                }
                if (toEvent != null)
                {
                    String[] parameters = toEvent.Parameters.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    rslt.AddRange(parameters);
                }
            }
            else if (_ToNode.UserObject is StateObjectNode)
            {
                StateObjectNode soNode = (StateObjectNode)_ToNode.UserObject;
                OOSGStateObjectModel som = _Model.FindStateObjectModel(soNode.Model.ID);
                OOSGMessage toMsg = null;
                toMsg = som.FindMessage(cbBoundaryTriggers.Text);
                if (toMsg != null) {
                    foreach (OOSGMessageParameter mp in toMsg.Parameters)
                    {
                        rslt.Add(mp.Name);
                    }
                }
            }

            rslt.Sort();
            return rslt;
        }

        private void InsertParameter(string pName, List<string> destCatchers)
        {
            int rowIndex = grid.RowsCount - 1;
            grid.Rows.Insert(rowIndex);

            SourceGrid.Cells.Views.Cell cellView = new SourceGrid.Cells.Views.Cell();
            cellView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.Cell fromCell = new SourceGrid.Cells.Cell(pName, typeof(string));
            fromCell.View = cellView;
            fromCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            fromCell.Editor.EnableEdit = true;

            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus |
                                    SourceGrid.EditableMode.SingleClick |
                                    SourceGrid.EditableMode.AnyKey;
            cbEditor.Control.DropDownStyle = ComboBoxStyle.DropDownList;
            cbEditor.StandardValues = destCatchers;

            SourceGrid.Cells.Cell toCell = new SourceGrid.Cells.Cell("", cbEditor);
            toCell.View = cellView;

            grid[rowIndex, 0] = fromCell;
            grid[rowIndex, 1] = toCell;
        }

        private void InsertParameter(string fromParamName, string toParamName, List<string> destCatchers)
        {
            int rowIndex = grid.RowsCount - 1;
            grid.Rows.Insert(rowIndex);

            SourceGrid.Cells.Views.Cell cellView = new SourceGrid.Cells.Views.Cell();
            cellView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.Cell fromCell = new SourceGrid.Cells.Cell(fromParamName, typeof(string));
            fromCell.View = cellView;
            fromCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            fromCell.Editor.EnableEdit = true;

            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus |
                                    SourceGrid.EditableMode.SingleClick |
                                    SourceGrid.EditableMode.AnyKey;
            cbEditor.Control.DropDownStyle = ComboBoxStyle.DropDownList;
            cbEditor.StandardValues = destCatchers;

            SourceGrid.Cells.Cell toCell = new SourceGrid.Cells.Cell(toParamName, cbEditor);
            toCell.View = cellView;
            toCell.AddController(valueChangedController);

            grid[rowIndex, 0] = fromCell;
            grid[rowIndex, 1] = toCell;
        }

        private void drawHeaders()
        {
            grid.Rows.Clear();

            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Snow;
            backHeader.Border = DevAge.Drawing.RectangleBorder.NoBorder;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            grid.BorderStyle = BorderStyle.FixedSingle;
            grid.Redim(1, 3);
            grid.FixedRows = 1;
            grid.Font = new Font("Calibe", 10);
            //1st Header Row
            grid.Rows.Insert(0);

            //Name Column
            SourceGrid.Cells.ColumnHeader header1 = new SourceGrid.Cells.ColumnHeader("Source Parameters");
            header1.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            //Value Column
            SourceGrid.Cells.ColumnHeader header2 = new SourceGrid.Cells.ColumnHeader("Destination Parameters");
            header2.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            grid[0, 0] = header1;
            grid[0, 1] = header2;
            grid.Columns[0].Width = 100;
            grid.Columns[0].MinimalWidth = 50;
            grid.Columns[1].Width = 100;
            grid.Columns[1].MinimalWidth = 50;
        }

        private void cbParam_CheckedChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            if (cbParam.Checked)
                updateParameters();
        }

        private void OnParameterGridValueChanged()
        {
            string paramMatch = "";
            List<string> pairs = new List<string>();
            for(int i = 1; i < grid.RowsCount; i++)
            {
                string fpName = grid[i, 0].DisplayText;
                string tpName = grid[i, 1].DisplayText;

                if (string.IsNullOrEmpty(tpName))
                    continue;

                pairs.Add(string.Format("\\{{0}:{1}\\}", fpName, tpName));
            }
            for(int i = 0; i < pairs.Count; i++)
            {
                if (i < pairs.Count - 1)
                    paramMatch += pairs[i] + ",";
                else
                    paramMatch += pairs[i];
            }

            _Link.Parameters = paramMatch;
        }
        #endregion

        public delegate void ParameterGridValueChangedEventHandler();

        public class ParameterGridValueChangedEvent : SourceGrid.Cells.Controllers.ControllerBase
        {
            public event ParameterGridValueChangedEventHandler ValueChanged;

            public ParameterGridValueChangedEvent()
            {
            }

            public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
            {
                base.OnValueChanging(sender, e);

                SourceGrid.Cells.Cell nameCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 0);
                SourceGrid.Cells.Cell valueCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 1);
                if (ValueChanged != null && ValueChanged.GetInvocationList().Length > 0)
                    ValueChanged();
            }
        }
    }
}
