﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.OID;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public partial class DataAssociationLinkProperties : UserControl
    {
        private DataAssociationLink _Link;

        private bool isUpdating = false;

        public DataAssociationLinkProperties()
        {
            InitializeComponent();
        }

        public void Update(OOMMModel model, DataAssociationLink link)
        {
            _Link = link;

            showProperties();
        }

        private void showProperties()
        {
            isUpdating = true;

            lvMappers.Items.Clear();
            txtName.Text = "";
            tecAction.Text = "";

            foreach (OOMMDataMapper mapper in _Link.DataAssociationEdge.DataMappers)
            {
                ListViewItem item = new ListViewItem(mapper.Name);
                item.Tag = mapper;
                lvMappers.Items.Add(item);
            }

            isUpdating = false;
        }

        
        private void lvMappers_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvMappers.SelectedItems.Count == 0)
                return;

            ListViewItem item = lvMappers.SelectedItems[0];
            OOMMDataMapper mapper = (OOMMDataMapper)item.Tag;

            txtName.Text = mapper.Name;
            tecAction.Text = mapper.Code;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string name = getNextMapperName();
            OOMMDataMapper mapper = new OOMMDataMapper(name, "");
            _Link.AddDataMapper(mapper);
            ListViewItem item = new ListViewItem(mapper.Name);
            item.Tag = mapper;

            bool inserted = false;
            for(int i = 0; i < lvMappers.Items.Count; i++)
            {
                if (mapper.Name.CompareTo(lvMappers.Items[i].Text) <= 0)
                {
                    lvMappers.Items.Insert(i, item);
                    inserted = true;
                    break;
                }
            }

            if (!inserted)
                lvMappers.Items.Add(item);

            item.Selected = true ;
        }

        private string getNextMapperName()
        {
            string rslt = "Mapper 1";

            string expr = @"Mapper[\s]*([0-9\-]*)";

            int nextNumber = 0;
            foreach (ListViewItem item in lvMappers.Items)
            {
                OOMMDataMapper mapper = (OOMMDataMapper)item.Tag;
                int number = 0;
                if (Regex.IsMatch(mapper.Name, expr))
                {
                    Match m = Regex.Match(mapper.Name, @"\d+");
                    if (int.TryParse(m.Value, out number))
                    {
                        if (number > nextNumber)
                            nextNumber = number;
                    }
                }
            }

            nextNumber++;
            rslt = "Mapper " + nextNumber;

            return rslt;
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (lvMappers.SelectedItems.Count == 0)
                return;

            OOMMDataMapper mapper = (OOMMDataMapper)lvMappers.SelectedItems[0].Tag;
            _Link.RemoveDataMapper(mapper);
            lvMappers.Items.RemoveAt(lvMappers.SelectedIndices[0]);
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            if (lvMappers.SelectedItems.Count == 0)
                return;

            ListViewItem item = lvMappers.SelectedItems[0];
            OOMMDataMapper mapper = (OOMMDataMapper)item.Tag;
            mapper.Name = txtName.Text;
            item.Text = txtName.Text;
        }

        private void tecAction_TextChanged(object sender, EventArgs e)
        {
            if (lvMappers.SelectedItems.Count == 0)
                return;

            ListViewItem item = lvMappers.SelectedItems[0];
            OOMMDataMapper mapper = (OOMMDataMapper)item.Tag;
            mapper.Code = tecAction.Text;
        }
    }
}
