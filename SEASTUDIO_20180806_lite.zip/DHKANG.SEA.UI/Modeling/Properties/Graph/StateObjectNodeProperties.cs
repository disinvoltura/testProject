﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.UI.ETTEditor;
using DHKANG.SEA.Model.Entities;
using DHKANG.SEA.Model.StateObjects;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public partial class StateObjectNodeProperties: UserControl
    {
        private OOMMModel _Model;
        private StateObjectNode _Node;

        private bool isUpdating = false;
        private List<string> _PrimitiveTypes = OOSGStateVariableHelper.ValueType();
        //private List<string> _PrimitiveTypes = new List<string>() {
        //        "boolean", "int", "float", "DateTime", "double", "string", "EntityQueue", "Queue", "ParameterVariable", "Position", "RandomVariate", "Range", "Resource", "TimeQueue" };

        #region Events
        public event PropertyValueChangedEventHandler PropertyValueChanged;
        #endregion

        public StateObjectNodeProperties()
        {
            InitializeComponent();
        }

        public void Update(OOMMModel model, StateObjectNode node)
        {
            _Model = model;
            _Node = node;

            showProperties();
        }

        private void showProperties()
        {
            isUpdating = true;

            txtName.Text = _Node.NodeName;

            showStateVariables();

            isUpdating = false;
        }

        private void drawHeaders()
        {
            gridVariable.Rows.Clear();

            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Snow;
            backHeader.Border = DevAge.Drawing.RectangleBorder.NoBorder;
            titleModel.Background = backHeader;
            //titleModel.BackColor = Color.SteelBlue;
            //titleModel.ForeColor = Color.White;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            gridVariable.BorderStyle = BorderStyle.FixedSingle;
            gridVariable.Redim(1, 6);
            gridVariable.FixedRows = 1;
            gridVariable.Font = new Font("Calibe", 10);
            //1st Header Row
            gridVariable.Rows.Insert(0);
            SourceGrid.Cells.ColumnHeader nameHeader = new SourceGrid.Cells.ColumnHeader("Name");
            nameHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.ColumnHeader rowsHeader = new SourceGrid.Cells.ColumnHeader("Rows");
            rowsHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.ColumnHeader colsHeader = new SourceGrid.Cells.ColumnHeader("Columns");
            colsHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.ColumnHeader typeHeader = new SourceGrid.Cells.ColumnHeader("Type");
            typeHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.ColumnHeader initialValueHeader = new SourceGrid.Cells.ColumnHeader("Initial Value");
            initialValueHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.ColumnHeader descHeader = new SourceGrid.Cells.ColumnHeader("Description");
            descHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            nameHeader.AutomaticSortEnabled = false;
            typeHeader.AutomaticSortEnabled = false;
            initialValueHeader.AutomaticSortEnabled = false;
            descHeader.AutomaticSortEnabled = false;

            gridVariable[0, 0] = nameHeader;
            gridVariable[0, 1] = rowsHeader;
            gridVariable[0, 2] = colsHeader;
            gridVariable[0, 3] = typeHeader;
            gridVariable[0, 4] = initialValueHeader;
            gridVariable[0, 5] = descHeader;
        }

        private void showStateVariables()
        {
            drawHeaders();

            OOSGStateObjectModel soModel = _Model.FindStateObjectModel(_Node.Model.ID);

            //Sorting Order
            List<string> stateVariables = new List<string>();
            foreach (OOSGStateVariable sv in soModel.StateVariables)
                stateVariables.Add(sv.Name);
            stateVariables.Sort();

            foreach (string name in stateVariables)
            {
                InsertStateVariable(soModel.FindStateVariable(name));
            }

            gridVariable.AutoStretchColumnsToFitWidth = false;
            gridVariable.AutoStretchRowsToFitHeight = false;
            gridVariable.AutoSizeCells();
        }

        public void InsertStateVariable(OOSGStateVariable variable)
        {
            int rowIndex = gridVariable.RowsCount - 1;
            gridVariable.Rows.Insert(rowIndex);

            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(variable.Name, typeof(string));
            nameCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            nameCell.Editor.EnableEdit = false;

            SourceGrid.Cells.Cell rowCell = new SourceGrid.Cells.Cell("1", typeof(int));
            //SourceGrid.Cells.Cell rowCell = new SourceGrid.Cells.Cell(variable.Row, typeof(int));
            rowCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            rowCell.Editor.EnableEdit = false;

            SourceGrid.Cells.Cell colCell = new SourceGrid.Cells.Cell("1", typeof(int));
            //SourceGrid.Cells.Cell colCell = new SourceGrid.Cells.Cell(variable.Col, typeof(int));
            colCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            colCell.Editor.EnableEdit = false;

            SourceGrid.Cells.Cell typeCell = new SourceGrid.Cells.Cell(variable.Type.ToString(), typeof(string));
            //SourceGrid.Cells.Editors.ComboBox cbEditor = getAvailableTypes();
            //SourceGrid.Cells.Cell typeCell = new SourceGrid.Cells.Cell(variable.ValueType, cbEditor);
            typeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            //typeCell.View = SourceGrid.Cells.Views.ComboBox.Default;
            typeCell.Editor.EnableEdit = false;

            object svValue = _Node[variable.Name];
            SourceGrid.Cells.Button valueCell = new SourceGrid.Cells.Button("1 rows");
            //SourceGrid.Cells.Button valueCell = new SourceGrid.Cells.Button(variable.Row.ToString() + " rows");
            SourceGrid.Cells.Controllers.Button buttonClickEvent = new SourceGrid.Cells.Controllers.Button();
            buttonClickEvent.Executed += new EventHandler(CellButton_Click);
            if (svValue != null)
                valueCell.Tag = svValue;
            else
                valueCell.Tag = variable.InitialValue;

            valueCell.Controller.AddController(buttonClickEvent);
            valueCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.Cell descCell = new SourceGrid.Cells.Cell("", typeof(string));
            //SourceGrid.Cells.Cell descCell = new SourceGrid.Cells.Cell(variable.Description, typeof(string));
            descCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            descCell.Editor.EnableEdit = false;

            gridVariable[rowIndex, 0] = nameCell;
            gridVariable[rowIndex, 1] = rowCell;
            gridVariable[rowIndex, 2] = colCell;
            gridVariable[rowIndex, 3] = typeCell;
            gridVariable[rowIndex, 4] = valueCell;
            gridVariable[rowIndex, 5] = descCell;
        }

        private void CellButton_Click(object sender, EventArgs e)
        {
            SourceGrid.CellContext context = (SourceGrid.CellContext)sender;
            SourceGrid.Cells.Button btnCell = (SourceGrid.Cells.Button)context.Cell;

            int row = 1;
            int col = 1;
            string valueType = "int";

            string svName = "";
            if (gridVariable[btnCell.Row.Index, 0].Value != null)
                svName = gridVariable[btnCell.Row.Index, 0].Value.ToString();
            if (gridVariable[btnCell.Row.Index, 1].Value != null)
                row = int.Parse(gridVariable[btnCell.Row.Index, 1].Value.ToString());
            if (gridVariable[btnCell.Row.Index, 2].Value != null)
                col = int.Parse(gridVariable[btnCell.Row.Index, 2].Value.ToString());

            if (!string.IsNullOrEmpty(gridVariable[btnCell.Row.Index, 3].DisplayText))//!= null)
                valueType = (string)gridVariable[btnCell.Row.Index, 3].Value;

            if (!OOMMStateVariableHelper.IsPrimitiveType(valueType))
                return;

            string initialValues = "";
            if (btnCell.Tag != null && !string.IsNullOrEmpty(btnCell.Tag.ToString()))//!= null)
                initialValues = (string)btnCell.Tag;

            D_VariableValue dialog = null;
            if (string.IsNullOrEmpty(initialValues))
                dialog = new D_VariableValue(row, col, valueType);
            else
                dialog = new D_VariableValue(row, col, valueType, initialValues);

            dialog.ShowDialog();

            string oldValue = initialValues;
            if (dialog.InitialValues != null)
            {
                btnCell.Tag = dialog.InitialValues;
                btnCell.Value = row + " rows";

                _Node[svName] = dialog.InitialValues;
                if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                    PropertyValueChanged(_Model.ID, _Node, svName, oldValue, dialog.InitialValues);
            }
        }

        private SourceGrid.Cells.Editors.ComboBox getAvailableTypes()
        {
            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));

            List<string> types = new List<string>();

            //Entities
            Guid projectID = MainUI.App.ModelExplorer.CurrentProject;
            List<OOMMEntity> entities = MainUI.App.ModelExplorer.GetEntities(projectID);
            foreach (OOMMEntity entity in entities)
            {
                types.Add(entity.Name);
            }
            types.Sort();

            types.AddRange(_PrimitiveTypes);

            cbEditor.StandardValues = types.ToArray<string>();
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;

            return cbEditor;
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            
            /*
            node.NodeName = dialog.EventObjectNodeName;
            //node.Model.Name = dialog.EventObjectName;
            ((MultiPortNode)node.Presentation).NodeName = dialog.EventObjectNodeName;

            if (DiagramChanged != null && DiagramChanged.GetInvocationList().Length > 0)
                DiagramChanged(DiagramChangeType.Rename, "", dialog.EventObjectNodeName, oldName);
            */
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            handleNameChanged();
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleNameChanged();
            }
        }

        private void handleNameChanged()
        {
            if (isUpdating)
                return;

            string oldValue = _Node.NodeName;
            if (_Node.NodeName != txtName.Text)
            {
                _Node.NodeName = txtName.Text;
                ((MultiPortNode)_Node.Presentation).NodeName = txtName.Text;

                if (PropertyValueChanged != null && PropertyValueChanged.GetInvocationList().Length > 0)
                    PropertyValueChanged(_Model.ID, _Node, "Name", oldValue, txtName.Text);
            }
        }
    }
}
