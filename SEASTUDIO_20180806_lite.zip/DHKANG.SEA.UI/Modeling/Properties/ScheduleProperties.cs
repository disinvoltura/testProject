﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.UI.ETTEditor;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model;
using DHKANG.SEA.UI.STTEditor;

namespace DHKANG.SEA.UI.Modeling.Properties
{
    public partial class ScheduleProperties: UserControl
    {
        #region Member Variables
        private ScheduleNode _Node;

        private bool isUpdating = false;
        #endregion

        #region Constructors
        public ScheduleProperties()
        {
            InitializeComponent();

            cbTimeUnit.Items.Clear();
            cbTimeUnit.Items.AddRange(Enum.GetNames(typeof(ScheduleTimeUnit)));

            gridVariable.Leave += GridVariable_Leave;
        }
        #endregion

        #region Methods
        public void Update(ScheduleNode node)
        {
            _Node = node;

            showProperties();
        }

        private void showProperties()
        {
            isUpdating = true;

            txtName.Text = _Node.ScheduleName;

            cbType.SelectedIndex = 0;
            if (_Node.Type == ScheduleType.Float)
                cbType.SelectedIndex = 1;
            else if (_Node.Type == ScheduleType.Expression)
                cbType.SelectedIndex = 2;

            cbTimeUnit.SelectedIndex = (int)_Node.TimeUnit;
            showValues();
            isUpdating = false;
        }

        private void drawHeaders()
        {
            gridVariable.Rows.Clear();

            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Snow;
            backHeader.Border = DevAge.Drawing.RectangleBorder.NoBorder;
            titleModel.Background = backHeader;
            //titleModel.BackColor = Color.SteelBlue;
            //titleModel.ForeColor = Color.White;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            gridVariable.BorderStyle = BorderStyle.FixedSingle;
            gridVariable.Redim(1, 3);
            gridVariable.FixedRows = 1;
            gridVariable.Font = new Font("Calibe", 10);
            //1st Header Row
            gridVariable.Rows.Insert(0);
            SourceGrid.Cells.ColumnHeader header1= new SourceGrid.Cells.ColumnHeader("Duration");
            header1.View = titleModel; 
            SourceGrid.Cells.ColumnHeader header2 = new SourceGrid.Cells.ColumnHeader("Value");
            header2.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.ColumnHeader header0 = new SourceGrid.Cells.ColumnHeader();            
            header0.View = titleModel;

            header1.AutomaticSortEnabled = false;
            header1.AutomaticSortEnabled = false;

            gridVariable[0, 0] = header0;
            gridVariable[0, 1] = header1;
            gridVariable[0, 2] = header2;

            gridVariable.Columns[0].MinimalWidth = 20;
            gridVariable.Columns[0].Width = 20;
        }

        private void showValues()
        {
            drawHeaders();

            foreach(OOMMScheduleValue value in _Node.Values)
            {
                InsertScheduleValue(value);
            }

            gridVariable.AutoStretchColumnsToFitWidth = false;
            gridVariable.AutoStretchRowsToFitHeight = false;
            gridVariable.AutoSizeCells();
        }

        public void InsertScheduleValue(OOMMScheduleValue value)
        {
            int rowIndex = gridVariable.RowsCount - 1;
            gridVariable.Rows.Insert(rowIndex);

            SourceGrid.Cells.Cell cell0 = new SourceGrid.Cells.CheckBox("", false);
            cell0.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.Cell cell1 = new SourceGrid.Cells.Cell(value.Duration, typeof(string));
            cell1.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            cell1.Editor.EnableEdit = true;

            SourceGrid.Cells.Cell cell2 = new SourceGrid.Cells.Cell(value.Value, typeof(string));
            cell2.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            cell2.Editor.EnableEdit = true;

            gridVariable[rowIndex, 0] = cell0;
            gridVariable[rowIndex, 1] = cell1;
            gridVariable[rowIndex, 2] = cell2;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertEmptyRow();
        }

        private void InsertEmptyRow()
        {
            int rowIndex = gridVariable.RowsCount;
            //int rowIndex = gridData.RowsCount - 1;
            gridVariable.Rows.Insert(rowIndex);

            SourceGrid.Cells.CheckBox cell0 = new SourceGrid.Cells.CheckBox("", false);
            cell0.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.Cell cell1 = new SourceGrid.Cells.Cell("", typeof(string));
            cell1.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            cell1.Editor.EnableEdit = true;

            SourceGrid.Cells.Cell cell2 = new SourceGrid.Cells.Cell("", typeof(string));
            cell2.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            cell2.Editor.EnableEdit = true;

            gridVariable[rowIndex, 0] = cell0;
            gridVariable[rowIndex, 1] = cell1;
            gridVariable[rowIndex, 2] = cell2;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (gridVariable.Rows.Count == 1)
                return;

            int count = 0;
            for (int i = gridVariable.Rows.Count - 1; i >= 1; i--)
            {
                if ((SourceGrid.Cells.CheckBox)gridVariable[i, 0] == null)
                    continue;
                if (((SourceGrid.Cells.CheckBox)gridVariable[i, 0]).Checked.GetValueOrDefault())
                {
                    gridVariable.Rows.Remove(i);
                    count++;
                }
            }
            if (count > 0)
                updateValues();
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            handleNameChanged();
        }

        private void handleNameChanged()
        {
            if (isUpdating)
                return;

            if (_Node.ScheduleName!= txtName.Text)
            {
                _Node.ScheduleName = txtName.Text;
                _Node.UpdateText();
            }
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleNameChanged();
            }
        }

        private void cbType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            if (cbType.SelectedIndex == 0)
                _Node.Type = ScheduleType.Integer;
            else if (cbType.SelectedIndex == 1)
                _Node.Type = ScheduleType.Float;
            else
                _Node.Type = ScheduleType.Expression;
        }

        private void updateValues()
        {
            List<OOMMScheduleValue> values = new List<OOMMScheduleValue>();
            for (int i = 1; i < gridVariable.Rows.Count; i++)
            {
                if (gridVariable[i, 1] == null)
                    continue;
                if (gridVariable[i, 1].Value == null && gridVariable[i, 2].Value == null)
                    continue;

                string duration = "";
                if (gridVariable[i, 1].Value != null)
                    duration = (string)gridVariable[i, 1].Value;
                string value = "";
                if (gridVariable[i, 2].Value != null)
                    value = (string)gridVariable[i, 2].Value;

                values.Add(new OOMMScheduleValue(duration, value));
            }

            _Node.Values = values;
        }

        private void GridVariable_Leave(object sender, EventArgs e)
        {
            updateValues();
        }

        private void cbTimeUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            _Node.TimeUnit = (ScheduleTimeUnit)Enum.ToObject(typeof(ScheduleTimeUnit), cbTimeUnit.SelectedIndex);
        }
        #endregion
    }
}
