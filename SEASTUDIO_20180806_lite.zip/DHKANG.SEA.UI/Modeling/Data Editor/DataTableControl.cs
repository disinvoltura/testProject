﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Data.OleDb;
using System.Data.Sql;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model.Data;

namespace DHKANG.SEA.UI
{
    public partial class DataTableControl : UserControl
    {
        #region Member Variables
        private static int InitialRows = 50;
        private static int InitialCols = 50;

        private string _DataTableName;
        #endregion

        #region Properties
        public string DataTableName { get { return _DataTableName; } }

        public OOMMDataTable DataTable {
            get
            {
                OOMMDataTable table = new OOMMDataTable(_DataTableName);

                return table;
            }
        }
        #endregion

        #region Constructors
        public DataTableControl(string name)
        {
            _DataTableName = name;

            InitializeComponent();
        }
        #endregion

        #region Methods
        private Dictionary<string, int> _ColumnNameToIndex;

        public void LoadData(OOMMDataTable tableDef)
        {
            DataTable table = getDataTable(tableDef);

            _ColumnNameToIndex = new Dictionary<string, int>();
            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            //valueChangedController = new TableValueChangedEvent(this);

            spreadSheet.DataSource = new DevAge.ComponentModel.BoundDataView(table.DefaultView);
            //spreadSheet.Controller.AddController(valueChangedController);
            spreadSheet.CreateColumns();

            for (int i = 0; i < spreadSheet.Columns.Count; i++)
            {
                spreadSheet.Columns[i].HeaderCell.View = titleModel;
                spreadSheet.Columns[i].MinimalWidth = 
                    (spreadSheet.Columns[i].PropertyName.Length + 5) * (int)spreadSheet.Font.Size;
                //grid.Columns[i].AutoSizeMode = SourceGrid.AutoSizeMode.

                _ColumnNameToIndex.Add(spreadSheet.Columns[i].PropertyName, i);
            }

            spreadSheet.MinimumHeight = 20;
            //grid.AutoStretchColumnsToFitWidth = true;
            spreadSheet.AutoSizeCells();
            
        }

        private DataTable getDataTable(OOMMDataTable tableDef)
        {
            DataTable table = null;
            //refactor this method laster (using Factory design pattern
            if (tableDef.DataSource.Type == "DB")
            {

            }
            else if (tableDef.DataSource.Type == "FILE")
            {
                string conStr = tableDef.DataSource.ConnectionString;
                //string conStr = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + _FileName + ";Extended Properties=" + '"' + "Excel 12.0;HDR=YES;" + '"';
                OleDbConnection excelConnection = new OleDbConnection(conStr);

                OleDbDataAdapter da = new OleDbDataAdapter();
                excelConnection.Open();

                OleDbCommand cmd = new OleDbCommand("SELECT * FROM [" + tableDef.DataSource.TableName + "$]", excelConnection);

                da.SelectCommand = cmd;

                try
                {
                    da.Fill(table);
                }
                catch (OleDbException e)
                { }

                excelConnection.Close();
                excelConnection.Dispose();
            }

            return table;
        }

        /*
        public void LoadData(DataView view)
        {
            _ColumnNameToIndex = new Dictionary<string, int>();
            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            if (view.Table.TableName.Equals("Equipment"))
            {
                SourceGrid.Cells.Editors.ComboBox eqpTypeCB = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
                string[] eqpTypes = new string[] { "U", "B", "V", "C" };
                eqpTypeCB.StandardValues = eqpTypes;
                eqpTypeCB.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;
                eqpTypeCB.Control.DropDownStyle = ComboBoxStyle.DropDownList;

                SourceGrid.Cells.Cell eqpTypeCell = new SourceGrid.Cells.Cell("", eqpTypeCB);
                eqpTypeCell.View = SourceGrid.Cells.Views.ComboBox.Default;
                eqpTypeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

                grid.Columns[1].DataCell = eqpTypeCell;

            }
            else if (view.Table.TableName.Equals("EQP_Port"))
            {
                SourceGrid.Cells.Editors.ComboBox portTypeCB = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
                string[] portTypes = new string[] { "U", "I", "O", "V", "C" };
                portTypeCB.StandardValues = portTypes;
                portTypeCB.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;
                portTypeCB.Control.DropDownStyle = ComboBoxStyle.DropDownList;

                SourceGrid.Cells.Cell portTypeCell = new SourceGrid.Cells.Cell("", portTypeCB);
                portTypeCell.View = SourceGrid.Cells.Views.ComboBox.Default;
                portTypeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

                grid.Columns[1].DataCell = portTypeCell;
            }

            valueChangedController = new TableValueChangedEvent(this);

            grid.DataSource = new DevAge.ComponentModel.BoundDataView(view);
            grid.Controller.AddController(valueChangedController);
            grid.CreateColumns();

            for (int i = 0; i < grid.Columns.Count; i++)
            {
                grid.Columns[i].HeaderCell.View = titleModel;
                grid.Columns[i].MinimalWidth = (grid.Columns[i].PropertyName.Length + 5) * (int)grid.Font.Size;
                //grid.Columns[i].AutoSizeMode = SourceGrid.AutoSizeMode.

                _ColumnNameToIndex.Add(grid.Columns[i].PropertyName, i);
            }

            grid.MinimumHeight = 20;
            //grid.AutoStretchColumnsToFitWidth = true;
            grid.AutoSizeCells();
        }
        */

        public void GoTo(int row, string columnName)
        {
            if (_ColumnNameToIndex.ContainsKey(columnName))
            {
                //grid.Selection.ResetSelection(false);
                //grid.Selection.SelectCell(new SourceGrid.Position(row, _ColumnNameToIndex[columnName]),true);
                spreadSheet.Selection.FocusRow(row);

                //grid.ShowCell(new SourceGrid.Position(row, _ColumnNameToIndex[columnName]), true);
            }
        }

        /*
        private void drawHeader()
        {
           SourceGrid.Cells.Views.Cell defaultView = new SourceGrid.Cells.Views.Cell();
            defaultView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            spreadSheet.Rows.Clear();

            spreadSheet.BorderStyle = BorderStyle.FixedSingle;
            spreadSheet.Redim(InitialRows+1, InitialCols+1);
            spreadSheet.EnableSort = false;
            spreadSheet.CustomSort = false;
            spreadSheet.FixedRows = 1;

            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            spreadSheet.Font = new Font("Calibri", 11);

            for (int i = 0; i < InitialRows; i++)
            {
                for (int k = 0; k < InitialCols; k++)
                {
                    if (i == 0)
                    {
                        SourceGrid.Cells.ColumnHeader columnHeader =
                            new SourceGrid.Cells.ColumnHeader(k.ToString());
                        columnHeader.View = titleModel;
                        columnHeader.SortComparer = new SourceGrid.ValueCellComparer();
                        spreadSheet[0, k + 1] = columnHeader;
                    }
                    SourceGrid.Cells.Cell emptyCell =
                         new SourceGrid.Cells.Cell(string.Empty, typeof(string));
                    emptyCell.View = defaultView;
                    spreadSheet[i + 1, k + 1] = emptyCell;
                }

                SourceGrid.Cells.ColumnHeader rowHeader =
                new SourceGrid.Cells.ColumnHeader(i.ToString());
                rowHeader.View = titleModel;
                rowHeader.SortComparer = new SourceGrid.ValueCellComparer();
                spreadSheet[i + 1, 0] = rowHeader;

            }
        }
        */
        private void spreadSheet_Paint(object sender, PaintEventArgs e)
        {

        }

        private void DataTableControl_Load(object sender, EventArgs e)
        {
            //drawHeader();
        }

        #endregion
    }
}
