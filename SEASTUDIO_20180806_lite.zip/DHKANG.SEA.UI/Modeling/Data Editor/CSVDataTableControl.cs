﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Data.OleDb;
using System.Data.Sql;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using LumenWorks.Framework.IO.Csv;
using System.IO;
using DHKANG.SEA.Model.Data;

namespace DHKANG.SEA.UI
{
    public partial class CSVDataTableControl : UserControl
    {
        #region Member Variables
        private static int InitialRows = 50;
        private static int InitialCols = 50;

        private OOMMDataSource _DS;
        #endregion

        #region Properties
        public OOMMDataSource DataSource { get { return _DS; } }
        #endregion

        #region Constructors
        public CSVDataTableControl()
        {
            InitializeComponent();
        }
        #endregion

        #region Methods
        private Dictionary<string, int> _ColumnNameToIndex;

        public void LoadData(OOMMDataSource ds)
        {
            _DS = ds;
            DataTable table = getDataTable();
            if (table == null)
                return;

            _ColumnNameToIndex = new Dictionary<string, int>();
            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            //valueChangedController = new TableValueChangedEvent(this);

            spreadSheet.DataSource = new DevAge.ComponentModel.BoundDataView(table.DefaultView);
            //spreadSheet.Controller.AddController(valueChangedController);
            spreadSheet.CreateColumns();

            for (int i = 0; i < spreadSheet.Columns.Count; i++)
            {
                spreadSheet.Columns[i].HeaderCell.View = titleModel;
                spreadSheet.Columns[i].MinimalWidth =
                    (spreadSheet.Columns[i].PropertyName.Length + 5) * (int)spreadSheet.Font.Size;
                //grid.Columns[i].AutoSizeMode = SourceGrid.AutoSizeMode.

                _ColumnNameToIndex.Add(spreadSheet.Columns[i].PropertyName, i);
            }

            spreadSheet.MinimumHeight = 20;
            //grid.AutoStretchColumnsToFitWidth = true;
            spreadSheet.AutoSizeCells();
        }

        private DataTable getDataTable()
        {
            DataTable table = null;
            //refactor this method laster (using Factory design pattern
            if (_DS.Type != OOMMDataSourceType.CSV)
                return table;

            if (!File.Exists(_DS.FileName))
                return table;

            table = new DataTable(_DS.Name);
            using (CsvReader csv = new CsvReader(new StreamReader(_DS.FileName), false))
            {
                int fieldCount = csv.FieldCount;

                for (int k = 1; k <= fieldCount; k++)
                {
                    string columnName = "Column " + k;
                    table.Columns.Add(columnName);
                }
                //string[] headers = csv.GetFieldHeaders();
                while (csv.ReadNextRecord())
                {
                    DataRow row = table.NewRow();
                    for (int i = 0; i < fieldCount; i++)
                    {
                        row[i] = csv[i];
                        //System.Diagnostics.Debug.WriteLine(string.Format("{0} = {1};", i, csv[i]));
                        //System.Diagnostics.Debug.WriteLine(string.Format("{0} = {1};", headers[i], csv[i]));
                    }

                    table.Rows.Add(row);
                }
            }

            return table;
        }

        public void GoTo(int row, string columnName)
        {
            if (_ColumnNameToIndex.ContainsKey(columnName))
            {
                //grid.Selection.ResetSelection(false);
                //grid.Selection.SelectCell(new SourceGrid.Position(row, _ColumnNameToIndex[columnName]),true);
                spreadSheet.Selection.FocusRow(row);

                //grid.ShowCell(new SourceGrid.Position(row, _ColumnNameToIndex[columnName]), true);
            }
        }

        private void spreadSheet_Paint(object sender, PaintEventArgs e)
        {

        }

        private void DataTableControl_Load(object sender, EventArgs e)
        {
        }

        #endregion
    }
}
