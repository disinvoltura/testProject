﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Data.OleDb;
using System.Data.Sql;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using LumenWorks.Framework.IO.Csv;
using System.IO;
using DHKANG.SEA.Model.Data;

namespace DHKANG.SEA.UI
{
    public partial class ExcelDataTableControl : UserControl
    {
        #region Member Variables
        //private static int InitialRows = 50;
        //private static int InitialCols = 50;

        private OOMMDataSource _DS;
        #endregion

        #region Properties
        public OOMMDataSource DataSource { get { return _DS; } }
        #endregion

        #region Constructors
        public ExcelDataTableControl()
        {
            InitializeComponent();
        }
        #endregion

        #region Methods
        //private Dictionary<string, int> _ColumnNameToIndex;

        public void LoadData(OOMMDataSource ds)
        {
            _DS = ds;

            tabControl1.TabPages.Clear();
            foreach (string sheetName in _DS.Sheets)
            {
                DataTable table = getDataTable();
                if (table == null)
                    continue;

                 SourceGrid.DataGrid spreadSheet = getNewSpreadsheet(); 

                //_ColumnNameToIndex = new Dictionary<string, int>();
                SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
                DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
                backHeader.BackColor = Color.Lavender;
                backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
                titleModel.Background = backHeader;
                titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

                //valueChangedController = new TableValueChangedEvent(this);
                spreadSheet.DataSource = new DevAge.ComponentModel.BoundDataView(table.DefaultView);
                //spreadSheet.Controller.AddController(valueChangedController);
                spreadSheet.CreateColumns();

                for (int i = 0; i < spreadSheet.Columns.Count; i++)
                {
                    spreadSheet.Columns[i].HeaderCell.View = titleModel;
                    spreadSheet.Columns[i].MinimalWidth =
                        (spreadSheet.Columns[i].PropertyName.Length + 5) * (int)spreadSheet.Font.Size;
                    //grid.Columns[i].AutoSizeMode = SourceGrid.AutoSizeMode.

                    //_ColumnNameToIndex.Add(spreadSheet.Columns[i].PropertyName, i);
                }

                spreadSheet.MinimumHeight = 20;
                //grid.AutoStretchColumnsToFitWidth = true;
                spreadSheet.AutoSizeCells();

                TabPage tp = new TabPage(sheetName);
                tp.Margin = new Padding(0);
                tp.Padding = new Padding(0);
                spreadSheet.Margin = new Padding(0);
                spreadSheet.Padding = new Padding(0);
                tp.Controls.Add(spreadSheet);
                tabControl1.TabPages.Add(tp);
            }
        }

        private SourceGrid.DataGrid getNewSpreadsheet()
        {
            SourceGrid.DataGrid spreadSheet = new SourceGrid.DataGrid();

            spreadSheet.DeleteQuestionMessage = "Are you sure to delete all the selected rows?";
            spreadSheet.Dock = System.Windows.Forms.DockStyle.Fill;
            spreadSheet.EnableSort = false;
            spreadSheet.FixedRows = 1;
            spreadSheet.Location = new System.Drawing.Point(0, 0);
            spreadSheet.Margin = new System.Windows.Forms.Padding(0, 0, 0, 0);
            spreadSheet.Padding = new System.Windows.Forms.Padding(0, 0, 0, 0);
            //spreadSheet.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            spreadSheet.Name = "spreadSheet";
            spreadSheet.SelectionMode = SourceGrid.GridSelectionMode.Row;
            spreadSheet.Size = new System.Drawing.Size(417, 452);
            spreadSheet.ToolTipText = "";
            spreadSheet.Font = new Font("Calibri", 10);

            return spreadSheet;
        }
        private DataTable getDataTable()
        {
            DataTable table = new DataTable();
            //refactor this method laster (using Factory design pattern
            if (_DS.Type != OOMMDataSourceType.EXCEL)
                return table;

            if (!File.Exists(_DS.FileName))
                return table;

            string conStr = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + _DS.FileName + ";Extended Properties=" + '"' + "Excel 12.0;HDR=YES;" + '"';
            //string conStr = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + _FileName + ";Extended Properties=" + '"' + "Excel 12.0;HDR=YES;" + '"';

            OleDbConnection excelConnection = new OleDbConnection(conStr);

            OleDbDataAdapter da = new OleDbDataAdapter();
            excelConnection.Open();

            OleDbCommand cmd = new OleDbCommand("SELECT * FROM [" + _DS.Sheets[0] + "$]", excelConnection);

            da.SelectCommand = cmd;

            try
            {
                da.Fill(table);
            }
            catch (OleDbException e)
            { }

            excelConnection.Close();
            excelConnection.Dispose();

            return table;
        }

        public void GoTo(int row, string columnName)
        {
            /*
            if (_ColumnNameToIndex.ContainsKey(columnName))
            {
                //grid.Selection.ResetSelection(false);
                //grid.Selection.SelectCell(new SourceGrid.Position(row, _ColumnNameToIndex[columnName]),true);
                spreadSheet.Selection.FocusRow(row);

                //grid.ShowCell(new SourceGrid.Position(row, _ColumnNameToIndex[columnName]), true);
            }
            */
        }

        private void spreadSheet_Paint(object sender, PaintEventArgs e)
        {

        }

        private void DataTableControl_Load(object sender, EventArgs e)
        {
        }

        #endregion
    }
}
