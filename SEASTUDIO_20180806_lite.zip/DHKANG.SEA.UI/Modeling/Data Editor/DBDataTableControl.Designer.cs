﻿namespace DHKANG.SEA.UI
{
    partial class DBDataTableControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.componentLight1 = new DevAge.ComponentModel.ComponentLight();
            this.spreadSheet = new SourceGrid.DataGrid();
            this.SuspendLayout();
            // 
            // spreadSheet
            // 
            this.spreadSheet.DeleteQuestionMessage = "Are you sure to delete all the selected rows?";
            this.spreadSheet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spreadSheet.EnableSort = false;
            this.spreadSheet.FixedRows = 1;
            this.spreadSheet.Location = new System.Drawing.Point(0, 0);
            this.spreadSheet.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.spreadSheet.Name = "spreadSheet";
            this.spreadSheet.SelectionMode = SourceGrid.GridSelectionMode.Row;
            this.spreadSheet.Size = new System.Drawing.Size(417, 452);
            this.spreadSheet.TabIndex = 0;
            this.spreadSheet.TabStop = true;
            this.spreadSheet.ToolTipText = "";
            // 
            // DBDataTableControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.spreadSheet);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "DBDataTableControl";
            this.Size = new System.Drawing.Size(417, 452);
            this.Load += new System.EventHandler(this.DataTableControl_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private DevAge.ComponentModel.ComponentLight componentLight1;
        private SourceGrid.DataGrid spreadSheet;

    }
}
