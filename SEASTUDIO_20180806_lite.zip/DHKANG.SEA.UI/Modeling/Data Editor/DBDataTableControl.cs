﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Data.OleDb;
using System.Data.Sql;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.Data;
using DHKANG.SEA.Simulation.Data;

namespace DHKANG.SEA.UI
{
    public partial class DBDataTableControl : UserControl
    {
        #region Member Variables
        private static int InitialRows = 50;
        private static int InitialCols = 50;

        #endregion

        #region Properties
        #endregion

        #region Constructors
        public DBDataTableControl()
        {
            InitializeComponent();
        }
        #endregion

        #region Methods
        private Dictionary<string, int> _ColumnNameToIndex;

        public void LoadData(OOMMDataSource ds)
        {
            DataTable table = getDataTable(ds);

            _ColumnNameToIndex = new Dictionary<string, int>();
            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            //valueChangedController = new TableValueChangedEvent(this);

            spreadSheet.DataSource = new DevAge.ComponentModel.BoundDataView(table.DefaultView);
            //spreadSheet.Controller.AddController(valueChangedController);
            spreadSheet.CreateColumns();

            for (int i = 0; i < spreadSheet.Columns.Count; i++)
            {
                spreadSheet.Columns[i].HeaderCell.View = titleModel;
                spreadSheet.Columns[i].MinimalWidth = 
                    (spreadSheet.Columns[i].PropertyName.Length + 5) * (int)spreadSheet.Font.Size;
                //grid.Columns[i].AutoSizeMode = SourceGrid.AutoSizeMode.

                _ColumnNameToIndex.Add(spreadSheet.Columns[i].PropertyName, i);
            }

            spreadSheet.MinimumHeight = 20;
            //grid.AutoStretchColumnsToFitWidth = true;
            spreadSheet.AutoSizeCells();
            
        }

        private DataTable getDataTable(OOMMDataSource dsDef)
        {
            DataTable table = null;

            if (dsDef.Type != OOMMDataSourceType.DATABASE)
                return table;

            DBDataSource ds = new DBDataSource(dsDef.Name, dsDef.DatabaseType.ToString(), dsDef.ConnectionString, dsDef.Query);
            ds.Load();

            table = ds.Data;

            return table;
        }

        public void GoTo(int row, string columnName)
        {
            if (_ColumnNameToIndex.ContainsKey(columnName))
            {
                spreadSheet.Selection.FocusRow(row);
            }
        }

        private void spreadSheet_Paint(object sender, PaintEventArgs e)
        {
        }

        private void DataTableControl_Load(object sender, EventArgs e)
        {
        }

        #endregion
    }
}
