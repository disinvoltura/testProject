﻿using DHKANG.SEA.Model;
using DHKANG.SEA.Model.Data;
using System;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace DHKANG.SEA.UI
{
    public partial class DataEditorWindow : DockContent
    {
        private OOMMDataSource _DS;

        public DataEditorWindow(OOMMDataSource ds)
        {
            _DS = ds;

            InitializeComponent();
        }

        public void UpdateData()
        {
            if (_DS.Type == OOMMDataSourceType.CSV)
            {
                if (this.Controls[0] is CSVDataTableControl)
                {
                    CSVDataTableControl ctrl = (CSVDataTableControl)this.Controls[0];
                    ctrl.LoadData(_DS);
                } 
            }
            else if (_DS.Type == OOMMDataSourceType.EXCEL)
            {
                if (this.Controls[0] is ExcelDataTableControl)
                {
                    ExcelDataTableControl ctrl = (ExcelDataTableControl)this.Controls[0];
                    ctrl.LoadData(_DS);
                }
            }
            else if (_DS.Type == OOMMDataSourceType.DATABASE)
            {
                if (this.Controls[0] is DBDataTableControl)
                {
                    DBDataTableControl ctrl = (DBDataTableControl)this.Controls[0];
                    ctrl.LoadData(_DS);
                }
            }
        }

        private void showDataSource()
        {
            this.Text = _DS.Name;

            if (_DS.Type == OOMMDataSourceType.CSV)
            {

                CSVDataTableControl ctrl = new CSVDataTableControl();
                ctrl.LoadData(_DS);

                this.Controls.Add(ctrl);
                ctrl.Dock = DockStyle.Fill;
            }
            else if (_DS.Type == OOMMDataSourceType.EXCEL)
            {
                ExcelDataTableControl ctrl = new ExcelDataTableControl();
                ctrl.LoadData(_DS);

                this.Controls.Add(ctrl);
                ctrl.Dock = DockStyle.Fill;
            }
            else if (_DS.Type == OOMMDataSourceType.DATABASE)
            {
                DBDataTableControl ctrl = new DBDataTableControl();
                ctrl.LoadData(_DS);

                this.Controls.Add(ctrl);
                ctrl.Dock = DockStyle.Fill;
            }
        }

        private void DataEditorWindow_Load(object sender, EventArgs e)
        {
            showDataSource();
        }
    }
}
