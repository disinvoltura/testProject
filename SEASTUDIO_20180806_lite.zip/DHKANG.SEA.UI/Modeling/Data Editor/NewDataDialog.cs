﻿using DHKANG.SEA.Model;
using DHKANG.SEA.Simulation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model.Data;

namespace DHKANG.SEA.UI
{
    public partial class NewDataDialog: Form
    {
        #region Member Variables
        public readonly static string DATATYPE_CSV = "CSV";
        public readonly static string DATATYPE_EXCEL = "Excel";
        public readonly static string DATATYPE_DB = "Database";

        private string _DataType = DATATYPE_CSV;
        private List<string> _Sheets2Import;
        private string _FileName;
        private string _DataName;

        private string _ConnectionString;
        private string _Query;
        private OOMMDatabaseType _DBType;

        public string DataName { get { return _DataName; } }
        public string DataType { get { return _DataType; } }
        public string FileName { get { return _FileName; } }

        public string ConnectionString { get { return _ConnectionString; } }
        public string Query { get { return _Query; } }
        public OOMMDatabaseType DatabaseType { get { return _DBType; } }

        public List<string> Sheets
        {
            get { return _Sheets2Import; }
        }

        #endregion

        #region Constructors
        public NewDataDialog()
        {
            InitializeComponent();

            initializeImageList();

            initializeDataType();
        }
        #endregion


        #region Initialize Methods
        private void initializeDataType()
        {
            ListViewItem item1 = new ListViewItem(DATATYPE_CSV);
            item1.ImageKey = ImageManager.IMAGE_DATA_OBJECT;
            lvType.Items.Add(item1);

            ListViewItem item2 = new ListViewItem(DATATYPE_EXCEL);
            item2.ImageKey = ImageManager.IMAGE_DATA_OBJECT;
            lvType.Items.Add(item2);

            ListViewItem item3 = new ListViewItem(DATATYPE_DB);
            item3.ImageKey = ImageManager.IMAGE_DATA_OBJECT;
            lvType.Items.Add(item3);
        }

        private void initializeImageList()
        {
            List<string> images = new List<string>();
            images.AddRange(new string[] {
                                ImageManager.IMAGE_DATA_OBJECT,
                                ImageManager.IMAGE_DATA_LIST
                                });

            foreach (string key in images)
            {
                Image image = ImageManager.find(key);
                if (image != null)
                    imageList1.Images.Add(key, image);
            }
        }
        #endregion

        #region Event Handlers
        private void lvType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvType.SelectedItems.Count == 0)
                return;

            ListViewItem item = lvType.SelectedItems[0];

            if (item.Text == DATATYPE_CSV)
            {
                _DataType = DATATYPE_CSV;
                tabControl1.SelectedIndex = 0;
            }else if (item.Text == DATATYPE_EXCEL) { 
                _DataType = DATATYPE_EXCEL;
                tabControl1.SelectedIndex = 1;
            }else if (item.Text == DATATYPE_DB) { 
                _DataType = DATATYPE_DB;
                tabControl1.SelectedIndex = 2;
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (_DataType == DATATYPE_CSV)
            {
                if (string.IsNullOrEmpty(txtNameCSV.Text))
                    return;

                if (string.IsNullOrEmpty(txtFileNameCSV.Text))
                    return;

                _DataName = txtNameCSV.Text;
                _FileName = txtFileNameCSV.Text;
            }
            else if (_DataType == DATATYPE_EXCEL)
            {
                if (string.IsNullOrEmpty(txtNameExcel.Text))
                    return;
                
                if (string.IsNullOrEmpty(txtFileNameExcel.Text))
                    return;

                _DataName = txtNameExcel.Text;
                _FileName = txtFileNameExcel.Text;

                _Sheets2Import = new List<string>();
                foreach (ListViewItem item in lvSheets.Items)
                {
                    if (item.Checked)
                        _Sheets2Import.Add(item.Text);
                }

                if (_Sheets2Import.Count == 0)
                    return;
            }
            else if (_DataType == DATATYPE_DB)
            {
                if (string.IsNullOrEmpty(txtNameDB.Text) ||
                    string.IsNullOrEmpty(txtConnStr.Text) ||
                    string.IsNullOrEmpty(txtQuery.Text))
                    return;

                _DataName = txtNameDB.Text;

                if (cbDBType.SelectedIndex == 0)
                    _DBType = OOMMDatabaseType.SQLSERVER;
                else if (cbDBType.SelectedIndex == 1)
                    _DBType = OOMMDatabaseType.MYSQL;
                else
                    _DBType = OOMMDatabaseType.ORACLE;

                _ConnectionString = txtConnStr.Text;
                _Query = txtQuery.Text;
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;

            this.Close();
        }
        #endregion

        #region CSV methods
        private void btnChooseCSV_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*";
            //"Text files (*.txt)|*.txt|All files (*.*)|*.*"
            ofd.DefaultExt = "csv";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                txtFileNameCSV.Text = ofd.FileName;
            }
        }

        #endregion

        #region Excel methods
        private void btnChooseExcel_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Excel Files (*.xls)|*.xlsx|All files (*.*)|*.*";
            ofd.DefaultExt = "xls";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                txtFileNameExcel.Text = ofd.FileName;

                OfficeOpenXml.ExcelPackage p = new OfficeOpenXml.ExcelPackage(new System.IO.FileInfo(ofd.FileName));
                foreach (OfficeOpenXml.ExcelWorksheet sheet in p.Workbook.Worksheets)
                {
                    lvSheets.Items.Add(sheet.Name);
                }
            }
        }

        #endregion

        #region Database Methods

        #endregion

        private void button1_Click(object sender, EventArgs e)
        {
            if ((cbDBType.SelectedIndex < 0) ||
                 (string.IsNullOrEmpty(txtConnStr.Text)) )
                return;

            string dbType = DatabaseHelper.DATABASE_SQLSERVER;
            if (cbDBType.SelectedIndex == 1)
                dbType = DatabaseHelper.DATABASE_MYSQL;
            else if (cbDBType.SelectedIndex == 2)
                dbType = DatabaseHelper.DATABASE_ORACLE;

            bool rslt = DatabaseHelper.TestDatabaseConnection(dbType, txtConnStr.Text);

            if (rslt)
                MessageBox.Show(this, "Connected", "Test Connection");
            else
                MessageBox.Show(this, "Not connected", "Test Connection");
        }
    }
}
