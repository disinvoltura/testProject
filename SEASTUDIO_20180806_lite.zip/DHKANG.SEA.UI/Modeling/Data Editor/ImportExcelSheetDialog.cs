﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DHKANG.SEA.UI
{
    public partial class ImportExcelSheetDialog: Form
    {
        private string _FileName;
        private List<string> _Sheets2Import;

        /// <summary>
        /// File Name of imported excel
        /// </summary>
        public string FileName
        {
            get { return _FileName; }
        }

        /// <summary>
        /// Sheets to import
        /// </summary>
        public List<string> Sheets
        {
            get { return _Sheets2Import; }
        }

        public ImportExcelSheetDialog()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.OK;

            if (string.IsNullOrEmpty(txtFileName.Text))
                return;

            _FileName = txtFileName.Text;
            _Sheets2Import = new List<string>();
            foreach(ListViewItem item in lvSheets.Items)
            {
                if (item.Checked)
                    _Sheets2Import.Add(item.Text);
            }

            if (_Sheets2Import.Count == 0)
                return;

            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        private void AddGroupDialog_Load(object sender, EventArgs e)
        {
            button1.Focus();
        }

        private void label1_Click(object sender, EventArgs e)
        {
        
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog(); 
            ofd.Filter = "Excel Files (*.xls)|*.xls|*.xlsx|All files (*.*)|*.*";
            ofd.DefaultExt = "xls";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                txtFileName.Text = ofd.FileName;

                OfficeOpenXml.ExcelPackage p = new OfficeOpenXml.ExcelPackage(new System.IO.FileInfo(ofd.FileName));
                foreach(OfficeOpenXml.ExcelWorksheet sheet in p.Workbook.Worksheets)
                {
                    lvSheets.Items.Add(sheet.Name);
                }
            }
      
        }
    }
}
