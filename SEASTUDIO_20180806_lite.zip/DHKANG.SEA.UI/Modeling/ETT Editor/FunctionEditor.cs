﻿using System;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ICSharpCode.TextEditor.Document;
using Microsoft.CSharp;
using DHKANG.SEA.Model.EventObjects;
using WeifenLuo.WinFormsUI.Docking;
using DHKANG.SEA.UI.CodeGeneration;

namespace DHKANG.SEA.UI.ETTEditor
{
    public partial class FunctionWindow : DockContent
    {
        #region Member Variables
        private EventObjectModelEditor _Parent;
        #endregion

        #region Events
        public ChangedEventHandler Changed;
        #endregion

        #region Properties
        public string Functions
        {
            get { return this.tecFuncs.Text; }
        }
        #endregion

        #region Constructors
        public FunctionWindow(EventObjectModelEditor parent)
        {
            _Parent = parent;

            InitializeComponent();

            //tecFuncs.Text = functions;
        }
        #endregion

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            base.OnFormClosing(e);
        }

        public void Update(OOEGEventObjectModel model)
        {
            tecFuncs.Text = model.Functions;

            tecFuncs.Document.HighlightingStrategy = HighlightingStrategyFactory.CreateHighlightingStrategy("C#");
            tecFuncs.Text = model.Functions;
        }

        #region Compilation
        private bool printCompilerResults(
            CompilerResults results, 
            CompilerParameters parameters, 
            int funcLineNo)
        {
            lvOutput.Items.Clear();

            bool rslt = false;
            if (results.Errors.Count > 0)
            {
                //rtxtOutput.ForeColor = Color.Red;
                foreach (CompilerError CompErr in results.Errors)
                {
                    if (CompErr.IsWarning)
                        continue;

                    ListViewItem item = new ListViewItem(CompErr.ErrorText);

                    if (!string.IsNullOrEmpty(CompErr.FileName))
                    {
                        string tmpRFN = CompErr.FileName.Remove(0, parameters.TempFiles.BasePath.Length).Substring(1);
                        string tmpNum = tmpRFN.Substring(0, tmpRFN.IndexOf("."));
                        string tmpFN = "";
                        item.SubItems.Add(tmpFN);
                    }
                    else
                        item.SubItems.Add("");

                    int line = CompErr.Line - funcLineNo + 1;
                    item.SubItems.Add(line.ToString());
                    item.SubItems.Add(CompErr.Column.ToString());
                    item.SubItems.Add(CompErr.ErrorNumber);
                    item.Tag = CompErr;

                    lvOutput.Items.Add(item);
                }

                rslt = false;
            }
            else
            {
                rslt = true;
                //setMessage("Ready.");
            }

            return rslt;
        }

        #endregion

        private void tsbCompile_Click(object sender, EventArgs e)
        {
            //범위:
            //State Variables + Functions

            CodeGeneration.CodeGenerator generator = new CodeGeneration.CodeGenerator(null);
            string code = generator.GenerateEventObjectSimulatorCode(_Parent.EventObjectModel, false);

            Simulation.SimulationBuilder builder = new Simulation.SimulationBuilder();
            bool rslt = builder.BuildEventObjectSimulator(_Parent.EventObjectModel, false);
            //Error 가능성: functions 이 EventObjectModel 에 반영되지 않을 수도 있음

            if (!rslt)
            {
                MessageBox.Show("Check the error list for details.");
                printCompilerResults(builder.CompilerResults, builder.CompilerParameters, generator.FunctionLineNo);
            }
        }
    }
}
