﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Northwoods.Go;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.Foundation.DataCollection;
using DHKANG.SEA.UI.OutputView;

namespace DHKANG.SEA.UI.ETTEditor
{
    public class EntityQueueNode: GoSimpleNode 
    {
        #region Member Variables
        private OOMMEntityQueue _Queue;
        private GoText _Label;
        #endregion

        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Properties
        public OOMMEntityQueue Queue
        {
            get { return _Queue; }
            set { _Queue = value; }
        }

        public string EntityQueueName 
        {
            get { return _Queue.Name; }
            set {
                string oldValue = _Queue.Name;
                _Queue.Name = value;
                UpdateText();
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Name", oldValue, value);
            }
        }
        
        public Guid NodeID 
        {
            get { return _Queue.NodeID; }
            set {
                Guid oldValue = _Queue.NodeID;
                _Queue.NodeID = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "NodeID", oldValue, value);
            }
        }

        public SelectionRule Rule 
        {
            get { return _Queue.Rule; }
            set {
                SelectionRule oldValue = _Queue.Rule;
                _Queue.Rule = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Rule", oldValue, value);
            }
        }

        public List<OOMMObjectProperty> Properties 
        {
            get { return _Queue.Properties; }
            set {
                List<OOMMObjectProperty> oldValue = _Queue.Properties;
                _Queue.Properties = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "EntityQueue.Properties", oldValue, value);
            }
        }

        public string Description
        {
            get { return _Queue.Description; }
            set {
                string oldValue = _Queue.Description;
                _Queue.Description = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Description", oldValue, value);
            }
        }
        #endregion

        #region Constructors
        public EntityQueueNode(string name, float x, float y)
        {
            _Queue = new OOMMEntityQueue();
            _Queue.Name = name;
            _Queue.X = x;
            _Queue.Y = y;

            _Label = CreateLabel(name);
            _Label.Font = new Font("Calibri", 11, FontStyle.Bold);

            initialize(x, y);
        }

        public EntityQueueNode(OOMMEntityQueue queue)
        {
            _Queue = queue;

            _Label = CreateLabel(_Queue.Name);
            _Label.Font = new Font("Calibri", 11, FontStyle.Bold);

            initialize(_Queue.X, _Queue.Y);
        }

        private void initialize(float x, float y)
        {
            this.Initialize(null, null, _Queue.Name);
            this.Figure = GoFigure.Buffer;
            this.Icon.Size = new SizeF(15, 15);
            this.Icon.Resizable = false;
            this.Shape.FillShapeGradient(Color.CornflowerBlue);
            this.Orientation = Orientation.Vertical;
            this.InPort.Visible = false;
            this.OutPort.Visible = false;
            this.Editable = false;
            this.Left = x;
            this.Top = y;

            this.UpdateText();
        }
        #endregion

        #region Methods
        public void UpdateText()
        {
            this.Label.Text = "  " + _Queue.Name;
        }

        public void Reset()
        {
            this.Label.Text = "  " + _Queue.Name;
        }

        public override string GetToolTip(GoView view)
        {
            string tooltip = _Queue.Name;

            if (!string.IsNullOrEmpty(_Queue.Description))
                tooltip += " : " + _Queue.Description;
            return tooltip;
        }
        #endregion
    }
}
