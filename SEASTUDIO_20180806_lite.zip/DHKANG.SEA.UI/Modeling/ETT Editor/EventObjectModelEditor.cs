﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;
using WeifenLuo.WinFormsUI.Docking;
using Northwoods.Go;

namespace DHKANG.SEA.UI.ETTEditor
{
    public enum ChangedType { Added, Deleted, Modified };
    public enum ChangedTarget { EntityQueue, Schedule, Event, StateVariable, Parameter, Functions, SchedulingEdge, SchedulingEdgeType };

    public delegate void ChangedEventHandler(ChangedTarget targetType,
                                              ChangedType changedType,
                                              object before, object after);


    public partial class EventObjectModelEditor : Form
    {
        #region Member Variables
        private StateVariableWindow _SVWindow;
        private FunctionWindow _FunctionWindow;
        private EventTransitionTableWindow _ETTWindow;
        private EventGraphDiagramWindow _EGDWindow;
        private ETTPropertiesWindow _PropertiesWindow;
        private bool _IsChanged;
        private OOEGEventObjectModel _EOModel;
        private EventObjectNode _Node;

        private NodeFactory _NodeFactory;

        private WeifenLuo.WinFormsUI.Docking.VS2012LightTheme vS2012LightTheme1;
        private WeifenLuo.WinFormsUI.Docking.VS2015LightTheme vS2015LightTheme1;
        #endregion

        #region Properties
        public bool IsModelChanged { get { return _IsChanged; } }

        public OOEGEventObjectModel EventObjectModel
        {
            get
            {
                OOEGEventObjectModel rslt = _EOModel;

                rslt.EventTransitions.Clear();
                //Event Transitions
                foreach(OOEGEventTransition et in _ETTWindow.EventTransitions)
                {
                    EventVertexNode evNode = (EventVertexNode)_EGDWindow.FindNode(et.Event.Name);
                    if (evNode == null)
                    {
                        System.Diagnostics.Debug.WriteLine("Cannot find the event vertex named \"" + et.Event.Name + "\" in the event graph diagram");
                        continue;
                    }
                    et.Event.X = evNode.Presentation.Position.X; 
                    et.Event.Y = evNode.Presentation.Position.Y;
                    et.Event.Type = evNode.EventType;

                    foreach(GoLabeledLink link in evNode.Presentation.DestinationLinks)
                    {
                        EventVertexNode nextEventNode = (EventVertexNode)link.ToNode.UserObject;
                        foreach(OOEGEdgeTransition edge in et.Edges)
                        {
                            if (edge.NextEvent == nextEventNode.NodeName)
                            {
                                //FromPort
                                edge.FromPort = evNode.FindPortIndex(link.FromPort);
                                //ToPort
                                edge.ToPort = nextEventNode.FindPortIndex(link.ToPort);
                                //LinkStyle
                                edge.LinkStyle = (int)link.Style;

                                //curviness
                                edge.Curviness = link.Curviness;
                                edge.AdjustingStyle = (int)link.AdjustingStyle;
                                //Points
                                List<OOEGPoint> points = new List<OOEGPoint>();
                                for(int i= 0; i < link.RealLink.PointsCount; i++)
                                {
                                    PointF pt = link.RealLink.GetPoint(i);
                                    points.Add(new OOEGPoint(pt.X, pt.Y));
                                }

                                edge.Points = points;
                                break;
                            }
                        }
                    }
                    rslt.EventTransitions.Add(et);
                }
                
                //State Variables
                rslt.StateVariables.Clear();
                foreach (OOEGStateVariable sv in _SVWindow.StateVariables)
                {
                    rslt.StateVariables.Add(sv);
                }

                //Schedules
                rslt.Schedules.Clear();
                foreach(OOMMSchedule s in _EGDWindow.Schedules)
                {
                    rslt.Schedules.Add(s);
                }

                //Entity Queues
                rslt.Schedules.Clear();
                foreach (OOMMEntityQueue q in _EGDWindow.EntityQueues)
                {
                    rslt.EntityQueues.Add(q);
                }

                //Functions
                rslt.Functions = _FunctionWindow.Functions;

                return rslt;
            }
        }
        #endregion

        #region Constructors
        public EventObjectModelEditor(OOEGEventObjectModel eoModel)
        {
            InitializeComponent();

            this.vS2012LightTheme1 = new WeifenLuo.WinFormsUI.Docking.VS2012LightTheme();
            this.vS2015LightTheme1 = new WeifenLuo.WinFormsUI.Docking.VS2015LightTheme();
            dockPanel1.Theme = vS2015LightTheme1;
            
            _EOModel = eoModel;
            _IsChanged = false;

            CreateLayout();

            _NodeFactory = new NodeFactory();
            _NodeFactory.Document = _EGDWindow.View.Doc;

            _EGDWindow.NodeFactory = _NodeFactory;
            _ETTWindow.NodeFactory = _NodeFactory;

            _ETTWindow.Update(eoModel);
            _EGDWindow.Update(eoModel);
            _SVWindow.Update(eoModel);
            _FunctionWindow.Update(eoModel);

            _IsChanged = false;

            this.Text = _EOModel.Name + " ::: Event Object Model Editor";
        }

        public EventObjectModelEditor(EventObjectNode node, OOEGEventObjectModel eoModel)
            : this(eoModel)
        {
            _Node = node;
        }
        #endregion 

        #region Methods
        private void CreateLayout()
        {
            //dockPanel1.Theme = new WeifenLuo.WinFormsUI.Docking.VS2012LightTheme(); ;

            _EGDWindow = new EventGraphDiagramWindow(this);
            _EGDWindow.Show(dockPanel1, DockState.Document);
            _EGDWindow.DockHandler.AllowEndUserDocking = true;
            _EGDWindow.DockHandler.CloseButtonVisible = false;
            _EGDWindow.DockHandler.CloseButton = false;
            _EGDWindow.View.DocumentChanged += new GoChangedEventHandler(OnDocumentChanged);
            _EGDWindow.ObjectSelected += OnEGDWindow_ObjectSelected;

            dockPanel1.DockBottomPortion = 0.5;

            //tsbAddText.Checked = false;
            _ETTWindow = new EventTransitionTableWindow(this);
            _ETTWindow.Show(dockPanel1, DockState.DockBottom);
            _ETTWindow.DockHandler.AllowEndUserDocking = true;
            _ETTWindow.DockHandler.CloseButtonVisible = false;
            _ETTWindow.DockHandler.CloseButton = false;

            _SVWindow = new StateVariableWindow(this);
            _SVWindow.Show(dockPanel1, DockState.DockBottom);
            _SVWindow.DockHandler.CloseButtonVisible = false;
            _SVWindow.DockHandler.CloseButton = false;            
            _SVWindow.Changed += new ChangedEventHandler(OnChanged);

            _FunctionWindow = new FunctionWindow(this);
            _FunctionWindow.Show(dockPanel1, DockState.DockBottom);
            _FunctionWindow.DockHandler.CloseButtonVisible = false;
            _FunctionWindow.DockHandler.CloseButton = false;
 
            _PropertiesWindow = new ETTPropertiesWindow(this);
            _PropertiesWindow.Show(dockPanel1, DockState.DockBottom);
            _PropertiesWindow.DockHandler.AllowEndUserDocking = true;
            _PropertiesWindow.DockHandler.CloseButtonVisible = false;
            _PropertiesWindow.DockHandler.CloseButton = false;
            
            _ETTWindow.Changed += new EventTransitionTableChangedEvent(_EGDWindow.OnETTChanged);
            _ETTWindow.Changed += new EventTransitionTableChangedEvent(OnETTChanged);
            _EGDWindow.Changed += new EventGraphDiagramChangedEvent(_ETTWindow.OnEGDChanged);
            _EGDWindow.Changed += new EventGraphDiagramChangedEvent(_SVWindow.OnEGDChanged);
            _SVWindow.Changed += new ChangedEventHandler(_EGDWindow.OnSVChanged);

            _ETTWindow.Activate();

        }

        private void OnEGDWindow_ObjectSelected(OOMMModel model, object target)
        {
            _PropertiesWindow.Update(model, target);
        }

        private void OnDocumentChanged(object sender, GoChangedEventArgs e)
        {
            _IsChanged = true;
        }

        private void OnDiagramChanged(ChangedTarget target, ChangedType action, string targetName, string propertyName, object before, object after)
        {
            _ETTWindow.OnEGDChanged(target, action, targetName, propertyName, before, after);            
        }

        private void OnETTChanged(string target, string action, string before, string after)
        {
            _IsChanged = true;
        }

        private void OnEventNameChanged(string oldEventName, string newEventName)
        {
            _EGDWindow.OnETTChanged("eventvertex", "changed", oldEventName, newEventName);

            //Graph Diagram 에 반영할 것!!!

            /*
            foreach(Link l in _Node.Presentation.SourceLinks)
            {
                if (l is ObjectSchedulingLink)
                {
                    ObjectSchedulingLink osl = (ObjectSchedulingLink)l;
                    if (string.IsNullOrEmpty(osl.ToEventName))
                        continue;
                    if(osl.ToEventName.Equals(oldEventName))
                    {
                        osl.ToEventName = newEventName;
                    }
                }
            }

            foreach(Link l in _Node.Presentation.DestinationLinks)
            {
                if (l is ObjectSchedulingLink)
                {
                    ObjectSchedulingLink osl = (ObjectSchedulingLink)l;
                    if (string.IsNullOrEmpty(osl.FromEventName))
                        continue;

                    if(osl.FromEventName.Equals(oldEventName))
                    {
                        osl.FromEventName = newEventName;
                    }
                }
            }
            */
        }

        
        private void OnChanged(ChangedTarget targetType, 
                                              ChangedType changedType,
                                              object before, object after)
        {
            _IsChanged = true;
        }
        

        #endregion

        private void EOMControl_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_IsChanged)
                this.DialogResult = System.Windows.Forms.DialogResult.OK;
            else
                this.DialogResult = System.Windows.Forms.DialogResult.Cancel;

            //this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }

    }
}
