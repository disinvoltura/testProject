﻿using DHKANG.SEA.Model.EventObjects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace DHKANG.SEA.UI.ETTEditor
{
    public partial class ParameterWindow : DockContent
    {
        #region Member Variables
        private EventObjectModelEditor _Parent;
        private ParameterGridValueChangedEvent valueChangedController;

        private static string[] SupportingTypes = new string[] { "int", "float", "double", "string", "RandomVariate" };
        #endregion

        #region Events
        public event ChangedEventHandler Changed;
        #endregion

        #region Properties
        public List<OOEGParameter> Parameters
        {
            get
            {
                List<OOEGParameter> rslt = new List<OOEGParameter>();

                for (int k = 1; k < grid.RowsCount; k++)
                {
                    SourceGrid.Cells.ICellVirtual[] cells = grid.GetCellsAtRow(k);
                    int nullCount = 0;
                    for (int p = 0; p < 6; p++)
                    {
                        if (grid[k, p] == null || grid[k, p].Value == null)
                            nullCount++;
                    }
                    if (nullCount < 6)
                    {
                        OOEGParameter parameter = new OOEGParameter();
                        parameter.Name = (string)grid[k, 0].Value;

                        int row = 1;
                        int col = 1;
                        string valueType = "int";

                        if (grid[k, 1].Value != null)
                            row = int.Parse(grid[k, 1].Value.ToString());
                        if (grid[k, 2].Value != null)
                            col = int.Parse(grid[k, 2].Value.ToString());

                        if (!string.IsNullOrEmpty(grid[k, 3].DisplayText))//!= null)
                            valueType = (string)grid[k, 3].Value;

                        //parameter.Row = row;
                        //parameter.Col = col;
                        parameter.ValueType = valueType;

                        SourceGrid.Cells.Button btnCell = (SourceGrid.Cells.Button)grid[k, 4];
                        if (btnCell.Tag == null)
                            parameter.InitialValue = string.Empty;
                        else if (row == 1 && col == 1)
                        {
                            string svValue = (string)btnCell.Tag;
                            if (svValue.StartsWith("{"))
                                parameter.InitialValue = svValue.Substring(1, svValue.Length - 2);
                            else
                                parameter.InitialValue = svValue;
                        }
                        else
                            parameter.InitialValue = (string)btnCell.Tag;
                        parameter.Description = (string)grid[k, 5].Value;
                        rslt.Add(parameter);
                    }
                }

                return rslt;
            }
        }
        #endregion

        #region Constructors
        public ParameterWindow(EventObjectModelEditor parent)
        {
            _Parent = parent;

            InitializeComponent();

            drawHeaders();

            valueChangedController = new ParameterGridValueChangedEvent();
            valueChangedController.ValueChanged += new ParameterGridValueChangedEventHandler(valueChangedController_ValueChanged); 
        }

        private void valueChangedController_ValueChanged(OOEGParameter oldParameter, OOEGParameter newParameter)
        {
            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            {
                Changed(ChangedTarget.Parameter, ChangedType.Modified, oldParameter, newParameter);
            }
        }
        #endregion

        private void ParameterWindow_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            base.OnFormClosing(e);
        }

        private void drawHeaders()
        {
            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Snow;
            backHeader.Border = DevAge.Drawing.RectangleBorder.NoBorder;
            titleModel.Background = backHeader;
            //titleModel.BackColor = Color.SteelBlue;
            //titleModel.ForeColor = Color.White;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            grid.BorderStyle = BorderStyle.FixedSingle;
            grid.Redim(1, 6);
            grid.FixedRows = 1;
            grid.Font = new Font("Calibe", 10);
            //1st Header Row
            grid.Rows.Insert(0);
            SourceGrid.Cells.ColumnHeader nameHeader = new SourceGrid.Cells.ColumnHeader("Name");
            nameHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.ColumnHeader rowsHeader = new SourceGrid.Cells.ColumnHeader("Rows");
            rowsHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.ColumnHeader colsHeader = new SourceGrid.Cells.ColumnHeader("Columns");
            colsHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.ColumnHeader typeHeader = new SourceGrid.Cells.ColumnHeader("Type");
            typeHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.ColumnHeader initialValueHeader = new SourceGrid.Cells.ColumnHeader("Initial Value");
            initialValueHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.ColumnHeader descHeader = new SourceGrid.Cells.ColumnHeader("Description");
            descHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            nameHeader.AutomaticSortEnabled = false;
            typeHeader.AutomaticSortEnabled = false;
            initialValueHeader.AutomaticSortEnabled = false;
            descHeader.AutomaticSortEnabled = false;

            grid[0, 0] = nameHeader;
            grid[0, 1] = rowsHeader;
            grid[0, 2] = colsHeader;
            grid[0, 3] = typeHeader;
            grid[0, 4] = initialValueHeader;
            grid[0, 5] = descHeader;
        }

        public void Update(OOEGEventObjectModel eoModel)
        {
            //Sorting Order
            List<string> stateVariables = new List<string>();
            foreach (OOEGStateVariable sv in eoModel.StateVariables)
                stateVariables.Add(sv.Name);
            stateVariables.Sort();

            foreach (string name in stateVariables)
            {
                InsertParameter(eoModel.GetParameter(name));
            }

            grid.AutoStretchColumnsToFitWidth = false;
            grid.AutoStretchRowsToFitHeight = false;
            grid.AutoSizeCells();
        }

        public void InsertParameter(OOEGParameter parameter)
        {
            int rowIndex = grid.RowsCount - 1;
            grid.Rows.Insert(rowIndex);

            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(parameter.Name, typeof(string));
            nameCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.Cell rowCell = new SourceGrid.Cells.Cell(parameter.Row, typeof(int));
            rowCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.Cell colCell = new SourceGrid.Cells.Cell(parameter.Col, typeof(int));
            colCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;


            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            cbEditor.StandardValues = SupportingTypes;//= new string[] { "int", "float", "double", "string", "RandomVariate" };
            //cbEditor.StandardValues = new string[] { "int", "float", "double", "string", "Queue<int>", "Queue<float>", "Queue<double>", "Queue<string>", "List<int>","List<float>", "List<double>", "List<string>" };
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;

            SourceGrid.Cells.Cell typeCell = new SourceGrid.Cells.Cell(parameter.ValueType, cbEditor);
            typeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            typeCell.View = SourceGrid.Cells.Views.ComboBox.Default;

            SourceGrid.Cells.Button valueCell = new SourceGrid.Cells.Button(parameter.Row.ToString() + " rows");
            SourceGrid.Cells.Controllers.Button buttonClickEvent = new SourceGrid.Cells.Controllers.Button();
            buttonClickEvent.Executed += new EventHandler(CellButton_Click);
            valueCell.Tag = parameter.InitialValue;
            valueCell.Controller.AddController(buttonClickEvent);
            valueCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            //SourceGrid.Cells.Cell valueCell = new SourceGrid.Cells.Cell(variable.InitialValue, typeof(string));
            //valueCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.Cell descCell = new SourceGrid.Cells.Cell(parameter.Description, typeof(string));
            descCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            grid[rowIndex, 0] = nameCell;
            grid[rowIndex, 1] = rowCell;
            grid[rowIndex, 2] = colCell;
            grid[rowIndex, 3] = typeCell;
            grid[rowIndex, 4] = valueCell;
            grid[rowIndex, 5] = descCell;
        }

        private int _VariableCount = 1;
        public void InsertEmptyParameter()
        {
            int rowIndex = grid.RowsCount - 1;
            grid.Rows.Insert(rowIndex);

            grid[rowIndex, 0] = new SourceGrid.Cells.Cell("Parameter" + _VariableCount, typeof(string));
            grid[rowIndex, 1] = new SourceGrid.Cells.Cell("1", typeof(int));
            grid[rowIndex, 2] = new SourceGrid.Cells.Cell("1", typeof(int));

            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            cbEditor.StandardValues = SupportingTypes;// new string[] { "int", "float", "double", "string", "RandomVariate" };
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;
            grid[rowIndex, 3] = new SourceGrid.Cells.Cell("int", cbEditor);
            grid[rowIndex, 3].View = SourceGrid.Cells.Views.ComboBox.Default;

            //gridVariable[rowIndex, 4] = new SourceGrid.Cells.Cell("", typeof(string));
            grid[rowIndex, 4] = new SourceGrid.Cells.Button("0 rows");
            SourceGrid.Cells.Controllers.Button buttonClickEvent = new SourceGrid.Cells.Controllers.Button();
            buttonClickEvent.Executed += new EventHandler(CellButton_Click);
            grid[rowIndex, 4].Controller.AddController(buttonClickEvent);

            grid[rowIndex, 5] = new SourceGrid.Cells.Cell("", typeof(string));

            _VariableCount++;
        }

        private void CellButton_Click(object sender, EventArgs e)
        {
            SourceGrid.CellContext context = (SourceGrid.CellContext)sender;
            SourceGrid.Cells.Button btnCell = (SourceGrid.Cells.Button)context.Cell;

            int row = 1;
            int col = 1;
            string valueType = "int";

            if (grid[btnCell.Row.Index, 1].Value != null)
                row = int.Parse(grid[btnCell.Row.Index, 1].Value.ToString());
            if (grid[btnCell.Row.Index, 2].Value != null)
                col = int.Parse(grid[btnCell.Row.Index, 2].Value.ToString());

            if (!string.IsNullOrEmpty(grid[btnCell.Row.Index, 3].DisplayText))//!= null)
                valueType = (string)grid[btnCell.Row.Index, 3].Value;

            string initialValues = "";
            if (btnCell.Tag != null && !string.IsNullOrEmpty(btnCell.Tag.ToString()))//!= null)
                initialValues = (string)btnCell.Tag;

            D_VariableValue dialog = null;
            if (string.IsNullOrEmpty(initialValues))
                dialog = new D_VariableValue(row, col, valueType);
            else
                dialog = new D_VariableValue(row, col, valueType, initialValues);

            dialog.ShowDialog();

            btnCell.Tag = dialog.InitialValues;
            btnCell.Value = row + " rows";
        }

        private void grid_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            SourceGrid.Position p = grid.PositionAtPoint(e.Location);
            if (p.IsEmpty())
            {
                InsertEmptyParameter();
            }
        }

        private void tsbInsert_Click(object sender, EventArgs e)
        {
            InsertEmptyParameter();
        }

        private void tsbDelete_Click(object sender, EventArgs e)
        {
            int sRow = grid.Selection.ActivePosition.Row;
            if (sRow < 0 || grid[sRow, 0] == null)
                return;

            grid.Rows.Remove(sRow);


            //Remove Activity Transition
            /*
            int sRow = grid.Selection.ActivePosition.Row;
            if (sRow < 0 || grid[sRow, 0] == null)
                return;

            string pName = grid[sRow, 1].DisplayText;
            ParameterType pType = (ParameterType)Enum.Parse(typeof(ParameterType), grid[sRow, 2].DisplayText);
            string pValue = grid[sRow, 3].DisplayText;

            grid.Rows.Remove(sRow);

            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            {
                Parameter pm =
                    new Parameter(pName, pType, pValue);

                Changed(ChangedTarget.Parameter, ChangedType.Deleted, pm, null);
            }
            */
            //grid.AutoSizeCells();
        }
    }

    public delegate void ParameterGridValueChangedEventHandler(OOEGParameter oldParameter, OOEGParameter newParameter);

    public class ParameterGridValueChangedEvent : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event ParameterGridValueChangedEventHandler ValueChanged;

        public ParameterGridValueChangedEvent()
        {
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

            /*
            OOEGParameter oldParameter = null;
            OOEGParameter newParameter = null;

            SourceGrid.Cells.Cell nameCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 1);
            SourceGrid.Cells.Cell typeCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 2);
            SourceGrid.Cells.Cell valueCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 3);

            if (sender.Position.Column == 1) //name
            {
                ParameterType pType = (ParameterType)Enum.Parse(
                    typeof(ParameterType),
                    typeCell.DisplayText);
                string initialValue = valueCell.DisplayText ;
                oldParameter = new Parameter((string)e.OldValue, pType, initialValue);
                newParameter = new Parameter((string)e.NewValue, pType, initialValue);
            }
            else if (sender.Position.Column == 2) //type
            {
                ParameterType oType = (ParameterType)Enum.Parse(
                    typeof(ParameterType), e.OldValue.ToString());
                ParameterType nType = (ParameterType)Enum.Parse(
                    typeof(ParameterType), e.NewValue.ToString());

                string name = nameCell.DisplayText;
                string initialValue = valueCell.DisplayText;
                oldParameter = new Parameter(name, oType, initialValue);
                newParameter = new Parameter(name, nType, initialValue);
            }
            else
            {
                string name = nameCell.DisplayText;
                ParameterType type = (ParameterType)Enum.Parse(
                    typeof(ParameterType),
                    typeCell.DisplayText);
                oldParameter = new Parameter(name, type, (string)e.OldValue);
                newParameter = new Parameter(name, type, (string)e.NewValue);
            }

            if (ValueChanged != null && ValueChanged.GetInvocationList().Length > 0)
                ValueChanged(oldParameter, newParameter);
            */
        }
    }
}
