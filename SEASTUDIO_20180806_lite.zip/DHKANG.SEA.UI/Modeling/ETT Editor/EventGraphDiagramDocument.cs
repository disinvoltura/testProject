﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using Northwoods.Go;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.OID.Presentation;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI.ETTEditor
{
    public class EventGraphDiagramDocument : GoDocument, DiagramDocument
    {
        #region Member Variables
        private int _nodeCounter = 0;
        public static float NodeWidth = 60;
        public static float NodeHeight = 60;

        private NodeFactory _Factory;
        private Dictionary<string, int> _TypeIDList;
        #endregion

        #region Properties
        public NodeFactory NodeFactory
        {
            set { _Factory = value; }
            get { return _Factory; }
        }
        #endregion

        #region Constructors
        public EventGraphDiagramDocument()
            : base()
        {
            this.Name = "1";

            //_Factory = new NodeFactory();
            //_Factory.Document = this;

            _TypeIDList = new Dictionary<string, int>();
            string[] namelist = Enum.GetNames(typeof(NodeType));
            foreach (string name in namelist)
            {
                _TypeIDList.Add(name, 1);
            }

        }

        public EventGraphDiagramDocument(string name)
            : this()
        {
            this.Name = name;
        }
        #endregion

        #region Node Naming Methods
        public int NextTypeID(NodeType type)
        {
            int typeID = _TypeIDList[type.ToString()];
            _TypeIDList[type.ToString()]++;

            return typeID;
        }

        public string NextName(NodeType type)
        {
            int typeID = NextTypeID(type);

            string name = type.ToString() + " " + typeID;

            while (this.FindNode(name) != null)
            {
                typeID++;
                _TypeIDList[type.ToString()] = typeID;

                name = type.ToString() + " " + typeID;
            }

            return name;
        }

        #endregion

        #region Initialization Methods
        public void Initialize()
        {
            _Factory = new NodeFactory();
            //_Objects = new Dictionary<string, GoObject>();
            _Factory.Document = this;


        }
        #endregion

        #region Insertion Methods
        public GoTextNode InsertClockNode()
        {
            this.StartTransaction();

            GoTextNode node = new GoTextNode();
            node.Center = new PointF(15, 15);
            node.Text = "Clock: 0";
            this.Add(node);
            this.FinishTransaction("Clock Node is inserted.");
            return node;
        }

        public Node InsertEventVertexNode(float x, float y)
        {
            this.StartTransaction();

            EventVertexNode node =
                (EventVertexNode)_Factory.GetInstance(NodeType.EventVertex);
            node.Position = new PointF(x, y);
            
            this.Add(node.Presentation);
            //this.Add(node);
            this.FinishTransaction("EventVertex Node is inserted.");

            return node;
        }

        public Node InsertEventVertexNode(float x, float y, string name)
        {
            this.StartTransaction();

            EventVertexNode node =
                (EventVertexNode)_Factory.GetInstance(NodeType.EventVertex, name);
            node.Position = new PointF(x, y);

            this.Add(node.Presentation);
            //this.Add(node);
            this.FinishTransaction("EventVertex Node is inserted.");

            return node;
        }

        public Node InsertEventVertexNode(OOEGEvent ev, bool initialEvent)
        {
            this.StartTransaction();

            EventVertexNode node =
                (EventVertexNode)_Factory.GetInstance(NodeType.EventVertex);
            node.EventVertex = ev;
            node.EventName = ev.Name;
            node.Position = new PointF(ev.X, ev.Y);

            if (initialEvent)
                node.setInitial();

            node.EventType = ev.Type;

            this.Add(node.Presentation);
            this.FinishTransaction("EventVertex Node is inserted.");

            return node;
        }

        public ScheduleNode InsertScheduleNode(float x, float y)
        {
            this.StartTransaction();

            string name = NextName(NodeType.Schedule);
            ScheduleNode node = new ScheduleNode(name, x, y);
            //node.Position = new PointF(x, y);

            this.Add(node);
            this.FinishTransaction("Schedule Node is inserted.");

            return node;
        }

        public ScheduleNode InsertSchedulenode(float x, float y, string name)
        {
            this.StartTransaction();

            ScheduleNode node = new ScheduleNode(name, x, y);
            //node.Position = new PointF(x, y);

            this.Add(node);
            this.FinishTransaction("Schedule Node is inserted.");

            return node;
        }

        public ScheduleNode InsertScheduleNode(OOMMSchedule schedule)
        {
            this.StartTransaction();

            ScheduleNode node = 
                new ScheduleNode(
                        schedule.NodeID, 
                        schedule.Name, 
                        schedule.Type, 
                        schedule.TimeUnit, 
                        schedule.Description, 
                        schedule.Values, 
                        schedule.X, schedule.Y);
            //.node.Position = new PointF(schedule.X, schedule.Y);

            this.Add(node);
            this.FinishTransaction("Schedule Node is inserted.");

            return node;
        }

        public EntityQueueNode InsertEntityQueueNode(float x, float y)
        {
            this.StartTransaction();

            string name = NextName(NodeType.Schedule);
            EntityQueueNode node = new EntityQueueNode(name, x, y);

            this.Add(node);
            this.FinishTransaction("EntityQueue Node is inserted.");

            return node;
        }

        public EntityQueueNode InsertEntityQueueNode(float x, float y, string name)
        {
            this.StartTransaction();

            EntityQueueNode node = new EntityQueueNode(name, x, y);

            this.Add(node);
            this.FinishTransaction("EntityQueue Node is inserted.");

            return node;
        }

        public EntityQueueNode InsertEntityQueueNode(OOMMEntityQueue queue)
        {
            this.StartTransaction();

            EntityQueueNode node = new EntityQueueNode(queue);

            this.Add(node);
            this.FinishTransaction("EntityQueue Node is inserted.");

            return node;
        }

        public TextNode InsertTextNode(float x, float y)
        {
            this.StartTransaction();

            string name = NextName(NodeType.Text);
            TextNode node = new TextNode(name, x, y);

            this.Add(node);
            this.FinishTransaction("Text Node is inserted.");

            return node;

        }
        public TextNode InsertTextNode(OOMMTextNode lt)
        {
            this.StartTransaction();

            TextNode n = new TextNode(lt.Text, lt.X, lt.Y);

            FontStyle fs = new FontStyle();
            if (lt.Font.Bold)
                fs = fs | FontStyle.Bold;
            if (lt.Font.Italic)
                fs = fs | FontStyle.Italic;
            if (lt.Font.Underline)
                fs = fs | FontStyle.Underline;
            if (lt.Font.Strikeout)
                fs = fs | FontStyle.Strikeout;
            n.Font = new Font(lt.Font.Name, lt.Font.Size, fs);
            n.TextColor = Color.FromArgb(lt.Font.Color);
            n.BackgroundColor = Color.FromArgb(lt.BackColor);
            n.TransparentBackground = lt.TransparentBackground;
            n.Position = new PointF(lt.X, lt.Y);
            //n.Center = new PointF(lt.X, lt.Y);

            this.Add(n);
            this.FinishTransaction("Text Node is inserted.");

            return n;
        }

        public LabelNode InsertLabelNode(Guid eventObjectID, string eventObjectName, string stateVariableName, string initialValue, float x, float y)
        {
            this.StartTransaction();

            string nextName = NextName(NodeType.Variable);
            LabelNode n = new LabelNode(Guid.NewGuid(), nextName, eventObjectID, eventObjectName, stateVariableName, initialValue, x, y);
            n.Position = new PointF(x, y);

            this.Add(n);
            this.FinishTransaction("Label Node is inserted.");

            return n;
        }

        public LabelNode InsertLabelNode(OOMMModel model, OOMMLabelNode lt)
        {
            this.StartTransaction();

            OOEGEventObjectModel eoModel = model.FindEventObjectModel(lt.ObjectID);
            OOEGStateVariable sv = eoModel.GetStateVariable(lt.StateVariableName);
            LabelNode n = new LabelNode(lt.NodeID, lt.LabelName, lt.ObjectID, eoModel.Name, lt.StateVariableName, sv.InitialValue, lt.X, lt.Y);

            FontStyle fs = new FontStyle();
            if (lt.Font.Bold)
                fs = fs | FontStyle.Bold;
            if (lt.Font.Italic)
                fs = fs | FontStyle.Italic;
            if (lt.Font.Underline)
                fs = fs | FontStyle.Underline;
            if (lt.Font.Strikeout)
                fs = fs | FontStyle.Strikeout;
            n.Font = new Font(lt.Font.Name, lt.Font.Size, fs);
            n.TextColor = Color.FromArgb(lt.Font.Color);
            n.BackgroundColor = Color.FromArgb(lt.BackColor);
            n.TransparentBackground = lt.TransparentBackground;
            n.Position = new PointF(lt.X, lt.Y);
            //n.Center = new PointF(lt.X, lt.Y);

            this.Add(n);
            this.FinishTransaction("Text Node is inserted.");

            return n;
        }
        #endregion

        #region Find Methods
        public List<LabelNode> GetLabelNodes(string eventObjectName, string stateVariableName)
        {
            List<LabelNode> rslt = new List<LabelNode>();

            foreach (GoObject obj in this)
            {
                if (obj is LabelNode)
                {
                    LabelNode ln = (LabelNode)obj;
                    if (ln.ObjectName == eventObjectName &&
                        ln.StateVariableName == stateVariableName)
                    {
                        rslt.Add(ln);
                    }
                }
            }

            return rslt;
        }

        public new object FindNode(string name)
        {
            object rslt = null;

            foreach (GoObject obj in this)
            {
                if (obj is GoBasicNode) //Event Vertex
                {
                    GoBasicNode node = (GoBasicNode)obj;
                    if (node.Text.Equals(name))
                    {
                        rslt = (Node)node.UserObject;
                        break;
                    }
                }else if (obj is ScheduleNode) {
                    ScheduleNode node = (ScheduleNode)obj;
                    if (node.ScheduleName.Equals(name))
                    {
                        rslt = node;
                        break;
                    }
                }
            }
            return rslt;
        }

        public EntityQueueNode FindEntityQueueNode(string name)
        {
            EntityQueueNode rslt = null;

            foreach (GoObject obj in this)
            {
                if (obj is EntityQueueNode)
                {
                    EntityQueueNode node = (EntityQueueNode)obj;
                    if (node.EntityQueueName.Equals(name))
                    {
                        rslt = node;
                        break;
                    }
                }
            }
            return rslt;
        }

        public object FindNode(int id)
        {
            Node rslt = null;

            /*
            foreach (GoObject obj in this)
            {
                if (obj is Node)
                {
                    Node ll = (Node)obj;
                    if (ll.NodeID == id)
                    {
                        rslt = ll;
                        break;
                    }
                }
            }
             * */
            return rslt;
        }

        public Link FindLink(int id)
        {
            Link rslt = null;
            foreach (GoObject obj in this)
            {
                if (obj is Link)
                {
                    Link l = (Link)obj;
                    if (l.LinkID == id)
                    {
                        rslt = l;
                        break;
                    }
                }
            }

            return rslt;

        }
        #endregion

        public void InsertEdge(OOEGEvent evt, OOEGEdgeTransition edge)
        {
            EventVertexNode fromNode = (EventVertexNode)FindNode(evt.Name);
            EventVertexNode toNode = (EventVertexNode)FindNode(edge.NextEvent);

            if (fromNode == null || toNode == null)
                return;

            this.StartTransaction();

            IGoPort fromPort = ((GoBasicNode)fromNode.Presentation).Port;
            IGoPort toPort = ((GoBasicNode)toNode.Presentation).Port;
            //IGoPort fromPort = fromNode.FindPort(edge.FromPort);
            //IGoPort toPort = toNode.FindPort(edge.ToPort);

            ObjectSchedulingLink newEdge = null;

            if (edge.IsCancelingEdge)
                newEdge = (ObjectSchedulingLink) EventGraphDiagramView.MakeLink(UI.InsertionMode.CancelingEdge);
            else
                newEdge = (ObjectSchedulingLink) EventGraphDiagramView.MakeLink(UI.InsertionMode.SchedulingEdge);

            newEdge.FromPort = fromPort;
            newEdge.ToPort = toPort;

            while (this.FindLink(EventGraphDiagramView.LastID) != null)
            {
                EventGraphDiagramView.LastID++;
            }
            newEdge.LinkID = EventGraphDiagramView.LinkCount;
            EventGraphDiagramView.LastID++;
            EventGraphDiagramView.LinkCount++;

            newEdge.FromLabel = CreateLabel("");
            newEdge.ToLabel = CreateLabel("");

            newEdge.RealLink.Style = (GoStrokeStyle)edge.LinkStyle;
            if (newEdge.RealLink.Style != GoStrokeStyle.Line)
            {
                newEdge.RealLink.Curviness = edge.Curviness;
                newEdge.RealLink.AdjustingStyle = (GoLinkAdjustingStyle)edge.AdjustingStyle;
                if (edge.Points != null)
                {
                    newEdge.RealLink.ClearPoints();
                    foreach (OOEGPoint pt in edge.Points)
                    {
                        newEdge.RealLink.AddPoint(pt.X, pt.Y);
                    }
                }
            }
            this.LinksLayer.Add(newEdge);

            this.FinishTransaction("Scheduling Edge is inserted.");
        }

        public void InsertEdge(string originEventVertex, string destEventVertex)
        {
            this.StartTransaction();

            EventVertexNode fromNode = (EventVertexNode)FindNode(originEventVertex);
            EventVertexNode toNode = (EventVertexNode)FindNode(destEventVertex);

            IGoPort fromPort = fromNode.FindShortestDistancePort((int)toNode.Presentation.Center.X, (int)toNode.Presentation.Center.Y);
            IGoPort toPort = toNode.FindShortestDistancePort((int)fromNode.Presentation.Center.X, (int)fromNode.Presentation.Center.Y);

            ObjectSchedulingLink newEdge = (ObjectSchedulingLink)
                EventGraphDiagramView.MakeLink(UI.InsertionMode.SchedulingEdge);

            newEdge.FromPort = fromPort;
            newEdge.ToPort = toPort;

            while (this.FindLink(EventGraphDiagramView.LastID) != null)
            {
                EventGraphDiagramView.LastID++;
            }
            newEdge.LinkID = EventGraphDiagramView.LinkCount;
            EventGraphDiagramView.LastID++;
            EventGraphDiagramView.LinkCount++;

            newEdge.FromLabel = CreateLabel("");
            newEdge.ToLabel = CreateLabel("");

            this.LinksLayer.Add(newEdge);

            this.FinishTransaction("Scheduling Edge is inserted.");
        }

        public void RemoveEdge(string fromEventVertex, string toEventVertex)
        {
            this.StartTransaction();

            ObjectSchedulingLink targetEdge = null;
            targetEdge = findEdge(fromEventVertex, toEventVertex);

            if (targetEdge != null)
                this.LinksLayer.Remove(targetEdge);

            this.FinishTransaction("Scheduling Edge is removed.");
        }

        private ObjectSchedulingLink findEdge(string fromEventVertex, string toEventVertex)
        {
            ObjectSchedulingLink targetEdge = null;
            foreach (GoObject obj in this)
            {
                if (obj is ObjectSchedulingLink)
                {
                    ObjectSchedulingLink edge = (ObjectSchedulingLink)obj;

                    GoBasicNode fromNode = (GoBasicNode)edge.FromNode;
                    GoBasicNode toNode = (GoBasicNode)edge.ToNode;

                    if (fromNode.Text.Equals(fromEventVertex) &&
                         toNode.Text.Equals(toEventVertex))
                    {
                        targetEdge = edge;
                        break;
                    }
                }
            }

            return targetEdge;
        }

        public void ChangeEdgeType(string fromEventVertex, string toEventVertex, bool canceled)
        {
            this.StartTransaction();

            ObjectSchedulingLink targetEdge = null;
            targetEdge = findEdge(fromEventVertex, toEventVertex);

            if (targetEdge != null)
            {
                if (canceled)
                {
                    Pen cancelingPen = new Pen(Brushes.Black);
                    cancelingPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                    targetEdge.Pen = cancelingPen;
                }
                else
                {
                    Pen schedulingPen = new Pen(Brushes.Black);
                    schedulingPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                    targetEdge.Pen = schedulingPen;
                }
            }

            this.FinishTransaction("Scheduling Edge's Type is changed.");
        }

        private GoText CreateLabel(string textValue)
        {
            GoText fromLabel = new GoText();
            fromLabel.FontSize = 8;
            fromLabel.EditableWhenSelected = false;
            fromLabel.Editable = false;
            fromLabel.Text = textValue;

            return fromLabel;
        }


    }
}
