﻿namespace DHKANG.SEA.UI.ETTEditor
{
    partial class EventTransitionTableWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EventTransitionTableWindow));
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.Table = new SourceGrid.Grid();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.tsbInsert = new System.Windows.Forms.ToolStripButton();
            this.tsbDelete = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbInsertCondition = new System.Windows.Forms.ToolStripButton();
            this.tsbDeleteCondition = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbAutoCellSize = new System.Windows.Forms.ToolStripButton();
            this.tsbCopy = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.cbFonts = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.tsbSetInitialEvent = new System.Windows.Forms.ToolStripButton();
            this.tsbEdgeType = new System.Windows.Forms.ToolStripButton();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this.Table);
            this.toolStripContainer1.ContentPanel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(796, 519);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(796, 550);
            this.toolStripContainer1.TabIndex = 0;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip2);
            // 
            // Table
            // 
            this.Table.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Table.EnableSort = true;
            this.Table.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table.Location = new System.Drawing.Point(0, 0);
            this.Table.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Table.Name = "Table";
            this.Table.OptimizeMode = SourceGrid.CellOptimizeMode.ForRows;
            this.Table.SelectionMode = SourceGrid.GridSelectionMode.Row;
            this.Table.Size = new System.Drawing.Size(796, 519);
            this.Table.TabIndex = 1;
            this.Table.TabStop = true;
            this.Table.ToolTipText = "";
            this.Table.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Table_MouseDoubleClick);
            // 
            // toolStrip2
            // 
            this.toolStrip2.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStrip2.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbInsert,
            this.tsbDelete,
            this.toolStripSeparator1,
            this.tsbInsertCondition,
            this.tsbDeleteCondition,
            this.toolStripSeparator2,
            this.tsbAutoCellSize,
            this.tsbCopy,
            this.toolStripSeparator4,
            this.cbFonts,
            this.toolStripButton2,
            this.toolStripButton1,
            this.tsbSetInitialEvent,
            this.tsbEdgeType});
            this.toolStrip2.Location = new System.Drawing.Point(3, 0);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(282, 31);
            this.toolStrip2.TabIndex = 1;
            // 
            // tsbInsert
            // 
            this.tsbInsert.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbInsert.Image = ((System.Drawing.Image)(resources.GetObject("tsbInsert.Image")));
            this.tsbInsert.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbInsert.Name = "tsbInsert";
            this.tsbInsert.Size = new System.Drawing.Size(28, 28);
            this.tsbInsert.Text = "Insert new Event Row";
            this.tsbInsert.Click += new System.EventHandler(this.tsbInsert_Click);
            // 
            // tsbDelete
            // 
            this.tsbDelete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDelete.Image = ((System.Drawing.Image)(resources.GetObject("tsbDelete.Image")));
            this.tsbDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDelete.Name = "tsbDelete";
            this.tsbDelete.Size = new System.Drawing.Size(28, 28);
            this.tsbDelete.Text = "Delete Event Row";
            this.tsbDelete.Click += new System.EventHandler(this.tsbDelete_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 31);
            // 
            // tsbInsertCondition
            // 
            this.tsbInsertCondition.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbInsertCondition.Image = ((System.Drawing.Image)(resources.GetObject("tsbInsertCondition.Image")));
            this.tsbInsertCondition.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbInsertCondition.Name = "tsbInsertCondition";
            this.tsbInsertCondition.Size = new System.Drawing.Size(28, 28);
            this.tsbInsertCondition.Text = "Insert new outgoing edge";
            this.tsbInsertCondition.Click += new System.EventHandler(this.tsbInsertCondition_Click);
            // 
            // tsbDeleteCondition
            // 
            this.tsbDeleteCondition.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeleteCondition.Image = ((System.Drawing.Image)(resources.GetObject("tsbDeleteCondition.Image")));
            this.tsbDeleteCondition.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDeleteCondition.Name = "tsbDeleteCondition";
            this.tsbDeleteCondition.Size = new System.Drawing.Size(28, 28);
            this.tsbDeleteCondition.Text = "Delete outgoing edge";
            this.tsbDeleteCondition.Click += new System.EventHandler(this.tsbDeleteCondition_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 31);
            // 
            // tsbAutoCellSize
            // 
            this.tsbAutoCellSize.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAutoCellSize.Image = ((System.Drawing.Image)(resources.GetObject("tsbAutoCellSize.Image")));
            this.tsbAutoCellSize.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAutoCellSize.Name = "tsbAutoCellSize";
            this.tsbAutoCellSize.Size = new System.Drawing.Size(28, 28);
            this.tsbAutoCellSize.Text = "Auto Cell Size";
            this.tsbAutoCellSize.Click += new System.EventHandler(this.tsbAutoCellSize_Click);
            // 
            // tsbCopy
            // 
            this.tsbCopy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCopy.Image = ((System.Drawing.Image)(resources.GetObject("tsbCopy.Image")));
            this.tsbCopy.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCopy.Name = "tsbCopy";
            this.tsbCopy.Size = new System.Drawing.Size(28, 28);
            this.tsbCopy.Text = "Copy";
            this.tsbCopy.Visible = false;
            this.tsbCopy.Click += new System.EventHandler(this.tsbCopy_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 31);
            // 
            // cbFonts
            // 
            this.cbFonts.Name = "cbFonts";
            this.cbFonts.Size = new System.Drawing.Size(121, 31);
            this.cbFonts.Visible = false;
            this.cbFonts.SelectedIndexChanged += new System.EventHandler(this.cbFonts_SelectedIndexChanged);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(28, 28);
            this.toolStripButton2.Text = "Decrease Font Size";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(28, 28);
            this.toolStripButton1.Text = "Increase Font Size";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // tsbSetInitialEvent
            // 
            this.tsbSetInitialEvent.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSetInitialEvent.Image = ((System.Drawing.Image)(resources.GetObject("tsbSetInitialEvent.Image")));
            this.tsbSetInitialEvent.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSetInitialEvent.Name = "tsbSetInitialEvent";
            this.tsbSetInitialEvent.Size = new System.Drawing.Size(28, 28);
            this.tsbSetInitialEvent.Text = "Set Initial Event";
            this.tsbSetInitialEvent.Click += new System.EventHandler(this.tsbSetInitialEvent_Click);
            // 
            // tsbEdgeType
            // 
            this.tsbEdgeType.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbEdgeType.Image = ((System.Drawing.Image)(resources.GetObject("tsbEdgeType.Image")));
            this.tsbEdgeType.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEdgeType.Name = "tsbEdgeType";
            this.tsbEdgeType.Size = new System.Drawing.Size(28, 28);
            this.tsbEdgeType.Text = "Set Edge Type";
            this.tsbEdgeType.Click += new System.EventHandler(this.tsbEdgeType_Click);
            // 
            // EventTransitionTableWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(796, 550);
            this.Controls.Add(this.toolStripContainer1);
            this.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "EventTransitionTableWindow";
            this.ShowIcon = false;
            this.Text = "Event Transition Table";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.EventTransitionTableWindow_FormClosing);
            this.Load += new System.EventHandler(this.EventTransitionTableEditor_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.EventTransitionTableWindow_KeyDown);
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private SourceGrid.Grid Table;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton tsbInsert;
        private System.Windows.Forms.ToolStripButton tsbDelete;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsbInsertCondition;
        private System.Windows.Forms.ToolStripButton tsbDeleteCondition;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton tsbAutoCellSize;
        private System.Windows.Forms.ToolStripButton tsbCopy;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripComboBox cbFonts;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton tsbSetInitialEvent;
        private System.Windows.Forms.ToolStripButton tsbEdgeType;

    }
}