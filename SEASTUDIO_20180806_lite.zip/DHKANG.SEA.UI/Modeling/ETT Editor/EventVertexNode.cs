﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using Northwoods.Go;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.UI.OutputView;

namespace DHKANG.SEA.UI.ETTEditor
{
    public class EventVertexNode : Node
    {
        #region Member Variables
        private OOEGEvent _EventVertex;
        private string FontName = "Calibri"; //추후 toolkit configuration에서 가져와야 함
        private float FontSize = 14.0f;
        private Color RegularEvent_Background = Color.WhiteSmoke;
        private Color InitialEvent_Background = Color.Orchid;
        private Color MirrorEvent_Background = Color.Gray;
        #endregion

        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Properties
        public OOEGEvent EventVertex
        {
            get { return _EventVertex; }
            set { _EventVertex = value; }
        }

        public string EventName
        {
            get { return _NodeName; }
            set {
                OOEGEvent oldValue = this.EventVertex.Clone();
                string oldPropertyValue = _NodeName;
                _NodeName = value;

                GoBasicNode tnode = (GoBasicNode)_Presentation;
                tnode.Label.Text = value;
                _EventVertex.Name = value;

                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "NAME", oldPropertyValue, value);

            }
        }

        public OOEGEventType EventType
        {
            get { return _EventVertex.Type; }
            set
            {
                OOEGEvent oldValue = _EventVertex.Clone();
                OOEGEventType oldPropertyValue = _EventVertex.Type;
                _EventVertex.Type = value;

                if (_EventVertex.Type == OOEGEventType.Regular)
                    setRegular();
                else if (_EventVertex.Type == OOEGEventType.Initial)
                    setInitial();
                else if (_EventVertex.Type == OOEGEventType.Mirror)
                    setMirror();

                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "TYPE", oldPropertyValue, value);
            }
        }


        public override Color BackgroundColor
        {
            get
            {
                GoBasicNode tnode = (GoBasicNode)_Presentation;
                return tnode.Shape.BrushColor;
            }
            set
            {
                GoBasicNode tnode = (GoBasicNode)_Presentation;
                tnode.Shape.BrushColor = value;
            }
        }

        public string EventParameters
        {
            get { return this.EventVertex.Parameters; }
            set
            {
                OOEGEvent oldValue = this.EventVertex.Clone();
                string oldPropertyValue = this.EventVertex.Parameters;
                this.EventVertex.Parameters = value;

                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "PARAMETERS", oldPropertyValue, value);
            }
        }

        #endregion

        #region Constructors
        public EventVertexNode(int id, string name)
            : base (id, name, NodeType.EventVertex)
        {
            _EventVertex = new OOEGEvent(id, name, string.Empty, OOEGEventType.Regular);

            GoBasicNode presentation = new GoBasicNode();
            presentation.LabelSpot = GoObject.Middle;
            presentation.Shape = new GoRoundedRectangle();
            presentation.Shape.FillSingleEdge(Color.Red, Color.Orange, GoObject.MiddleTop);
            presentation.Shape.BrushMidFraction = 0.4f;

            presentation.UserObject = this;

            presentation.Text = name;
            presentation.Editable = true;
            presentation.Label.Editable = true;
            presentation.Label.EditableWhenSelected = true;
            presentation.Label.Multiline = false;
            presentation.Label.Font = new Font(FontName, FontSize, FontStyle.Regular);
            presentation.Label.TextColor = Color.White;

            foreach(GoPort port in presentation.Ports){
                port.IsValidDuplicateLinks = true;
                port.IsValidSelfNode = true;
            }
            _Presentation = presentation;
        }
        #endregion

        #region Methods
        public void setRegular()
        {
            ((GoBasicNode)_Presentation).Shape = new GoRoundedRectangle();

            ((GoBasicNode)_Presentation).Shape.FillSingleEdge(Color.Red, Color.Orange, GoObject.MiddleTop);
            _Presentation.Label.Font = new Font(FontName, FontSize, FontStyle.Regular);

            /*
            if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length> 0)
            {
                PropertyChanged(_EventVertex.Name, "TYPE", oldValue, newValue);
            }
            */
        }

        public void setInitial()
        {
            ((GoBasicNode)_Presentation).Shape.FillShadedGradient(InitialEvent_Background);
            _Presentation.Label.Font = new Font(FontName, FontSize, FontStyle.Italic);
        }

        public void setMirror()
        {
            ((GoBasicNode)_Presentation).Shape.FillShadedGradient(MirrorEvent_Background);
            _Presentation.Label.Font = new Font(FontName, FontSize, FontStyle.Italic);
        }

        public override bool ShowDialog(bool read)
        {
            /*
            EventObjectModelEditor editor =
                new EventObjectModelEditor(this, _Model);

            DialogResult rslt = editor.ShowDialog();
            if (rslt == DialogResult.OK)
            {
                _Model = editor.EventObjectModel;
            }
            */
            return true;
        }

        public override int FindPortIndex(IGoPort targetPort)
        {
            int rslt = 0;
            foreach(IGoPort port in this.Presentation.Ports)
            {
                if (port == targetPort)
                {
                    break; 
                }

                rslt++;
            }

            return rslt;
        }
  
        /*
        public IGoPort FindPort(int idx)
        {
            if (idx < _Ports.Count)
                return (IGoPort)_Ports[idx];
            else
                return null;
        }
        */

        public override IGoPort FindShortestDistancePort(int x, int y)
        {
            IGoPort rslt = null;

            GoBasicNode node = (GoBasicNode)this.Presentation;
            float minDistance = float.MaxValue;
            IGoPort minPort = null;
            foreach(IGoPort port in node.Ports)
            {
                if (port.GoObject == null)
                    continue;

                float distance = 
                    getDistance(port.GoObject.Center.X, port.GoObject.Center.Y, x, y);

                if (distance < minDistance)
                {
                    minDistance = distance;
                    minPort = port;
                }
            }

            if (minPort != null)
                rslt = minPort;
            
            return rslt;
        }

        private float getDistance(float x1, float y1, float x2, float y2)
        {
            float distance = 0;
            distance = (float)Math.Sqrt((x2 - x1) * (x2 - x1) * (y2 - y1) * (y2 - y1));

            return distance;
        }

        /*
        public int FindPortIndex(IGoPort port)
        {
            int rslt = 0;
            for (int i = 0; i < _Ports.Count; i++)
            {
                MultiPortNodePort p = (MultiPortNodePort)_Ports[i];
                if (p.Equals(port))
                {
                    rslt = i;
                    break;
                }

            }
            return rslt;
        }*/

        public override IGoPort FindPort(int portid)
        {
            int count = 0;
            IGoPort rslt = null;
            foreach(IGoPort port in this.Presentation.Ports)
            {
                if (count == portid)
                {
                    rslt = port;
                    break;
                }
                count++;
            }
            return rslt;
        }
        #endregion
    }
}
