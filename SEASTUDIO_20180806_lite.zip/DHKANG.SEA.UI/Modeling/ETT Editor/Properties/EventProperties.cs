﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.UI.ETTEditor;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.StateObjects;

namespace DHKANG.SEA.UI.ETTEditor.Properties
{
    public partial class EventProperties : UserControl
    {
        private EventObjectModelEditor _Parent;
        private EventVertexNode _Node;

        private bool isUpdating = false;

        public EventProperties(EventObjectModelEditor parent)
        {
            _Parent = parent;
            InitializeComponent();
        }

        public void Update(EventVertexNode node)
        {
            _Node = node;

            showProperties();
        }

        private void showProperties()
        {
            isUpdating = true;

            txtName.Text = _Node.EventName;

            setButtonSelection(btnRegular, false);
            setButtonSelection(btnInitial, false);
            setButtonSelection(btnMirror, false);

            if (_Node.EventVertex.Type == OOEGEventType.Regular)
                setButtonSelection(btnRegular, true);
            if (_Node.EventVertex.Type == OOEGEventType.Initial)
                setButtonSelection(btnInitial, true);
            if (_Node.EventVertex.Type == OOEGEventType.Mirror)
                setButtonSelection(btnMirror, true);

            txtParam.Text = "";
            lvPM.Items.Clear();
            lbSV.Items.Clear();
            if (!string.IsNullOrEmpty(_Node.EventVertex.Parameters))
            {
                txtParam.Text = _Node.EventVertex.Parameters;
                List<string> pmNameList = _Node.EventVertex.Parameters.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList<string>();
                List<string> svList = new List<string>();
                List<string> pmList = new List<string>();
                foreach (OOEGStateVariable sv in _Parent.EventObjectModel.StateVariables)
                {
                    if (!pmNameList.Contains(sv.Name))
                        svList.Add(sv.Name + ": " + sv.ValueType);
                    else
                        pmList.Add(sv.Name + ": " + sv.ValueType);
                }
                svList.Sort();
                svList.ForEach(sv => lbSV.Items.Add(sv));

                pmList.Sort();
                pmList.ForEach(pm => lvPM.Items.Add(pm));
            }
            else
            {
                List<string> svList = new List<string>();
                foreach (OOEGStateVariable sv in _Parent.EventObjectModel.StateVariables)
                {
                    svList.Add(sv.Name + ": " + sv.ValueType);
                }
                svList.Sort();
                svList.ForEach(sv => lbSV.Items.Add(sv));
            }

            isUpdating = false;


        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            handleNameChanged();
        }

        private void handleNameChanged()
        {
            if (isUpdating)
                return;

            if (_Node.EventName != txtName.Text)
            {
                _Node.EventName = txtName.Text;
                //_Node.UpdateText();
            }
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleNameChanged();
            }
        }

        private void handleParametersChanged()
        {
            if (isUpdating)
                return;

            if (_Node.EventParameters != txtParam.Text)
            {
                _Node.EventParameters = txtParam.Text;
            }
        }

        private void txtParam_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleParametersChanged();
            }
        }

        private void txtParam_Leave(object sender, EventArgs e)
        {
            handleParametersChanged();
        }

        private void txtParam_TextChanged(object sender, EventArgs e)
        {
            handleParametersChanged();
        }

        private void btnInitial_Click(object sender, EventArgs e)
        {
            setButtonSelection(btnRegular, false);
            setButtonSelection(btnInitial, true);
            setButtonSelection(btnMirror, false);

            _Node.EventType = OOEGEventType.Initial;
        }

        private void btnRegular_Click(object sender, EventArgs e)
        {
            setButtonSelection(btnRegular, true);
            setButtonSelection(btnInitial, false);
            setButtonSelection(btnMirror, false);

            _Node.EventType = OOEGEventType.Regular;
        }

        private void btnMirror_Click(object sender, EventArgs e)
        {
            setButtonSelection(btnRegular, false);
            setButtonSelection(btnInitial, false);
            setButtonSelection(btnMirror, true);

            _Node.EventType = OOEGEventType.Mirror;
        }

        private void setButtonSelection(Button btn, bool selected)
        {
            if (selected)
            {
                btn.FlatAppearance.BorderColor = Color.DarkGray;
                btn.FlatAppearance.BorderSize = 1;
                btn.Font = new Font(btn.Font.FontFamily, 9, FontStyle.Bold);
                btn.BackColor = Color.DarkGray;
            }
            else
            {
                btn.FlatAppearance.BorderColor = Color.Gray;
                btn.FlatAppearance.BorderSize = 0;
                btn.Font = new Font(btn.Font.FontFamily, 9, FontStyle.Regular);
                btn.BackColor = Color.LightGray;
            }
        }

        //move to SV listbox
        private void button2_Click(object sender, EventArgs e)
        {
            if (lvPM.SelectedIndex < 0)
                return;

            int index = lvPM.SelectedIndex;
            string pm = (string)lvPM.SelectedItem;
            lbSV.Items.Add(pm);
            lvPM.Items.RemoveAt(index);

            buildParameters();
        }

        //move to PM listbox
        private void button1_Click(object sender, EventArgs e)
        {
            if (lbSV.SelectedIndex < 0)
                return;

            int index = lbSV.SelectedIndex;
            string sv = (string)lbSV.SelectedItem;
            lvPM.Items.Add(sv);
            lbSV.Items.RemoveAt(index);

            buildParameters();
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            if (lvPM.SelectedIndex <= 0)
                return;

            int index = lvPM.SelectedIndex;
            string pm = (string)lvPM.SelectedItem;
            lvPM.Items.RemoveAt(index);
            lvPM.Items.Insert(index - 1, pm);

            buildParameters();
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            if (lvPM.SelectedIndex == lvPM.Items.Count - 1)
                return;

            int index = lvPM.SelectedIndex;
            string pm = (string)lvPM.SelectedItem;
            lvPM.Items.Insert(index + 1, pm);
            lvPM.Items.RemoveAt(index);

            buildParameters();
        }

        private void buildParameters()
        {
            string parameters = "";
            for(int i = 0; i < lvPM.Items.Count; i++)
            {
                string itemValue = (string)lvPM.Items[i];
                string pmName = itemValue.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries)[0];

                if (i < lvPM.Items.Count - 1)
                    parameters += pmName + ",";
                else
                    parameters += pmName;
            }
            txtParam.Text = parameters;
        }

    }
}