﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using DHKANG.SEA.Model.EventObjects;

namespace DHKANG.SEA.UI.ETTEditor
{
    public delegate void EventTransitionTableChangedEvent(string target, string action, string before, string after);
    public delegate void EventNameChangedEvent(string oldName, string newName);

    public partial class EventTransitionTableWindow : DockContent
    {
        #region Member Variables
        private EventObjectModelEditor _EOMControl;
        private SourceGrid.Cells.Editors.ComboBox _NextEventEditor;
        private ETTEventValueChangedEventController _EventValueChangeController;
        private ETTNextEventValueChangedEventController _NextEventValueChangeController;
        private ETTValueChangedEventController _ValueChangeController;
        private NodeFactory _NodeFactory;

        private SourceGrid.Cells.Views.ColumnHeader titleModel;
        #endregion

        #region Events
        public event EventTransitionTableChangedEvent Changed;
        public event EventNameChangedEvent EventNameChanged;
        #endregion

        #region Properties
        public NodeFactory NodeFactory
        {
            get { return _NodeFactory; }
            set { _NodeFactory = value; }
        }

        public List<OOEGEventTransition> EventTransitions
        {
            get
            {
                List<OOEGEventTransition> eventTransitions =
                    new List<OOEGEventTransition>();

                int eventNo = 1;
                for (int k = 2; k < Table.Rows.Count; k += Table[k, 1].RowSpan)
                {
                    if (string.IsNullOrEmpty(Table[k, 1].DisplayText))
                        continue;

                    OOEGEvent currentEvent = new OOEGEvent();
                    currentEvent.Name = Table[k, 1].DisplayText;
                    currentEvent.Parameters = string.IsNullOrEmpty(Table[k, 2].DisplayText) ? string.Empty : Table[k, 2].DisplayText;

                    string stateChange = Table[k, 3].DisplayText;

                    OOEGEventTransition transition =
                        new OOEGEventTransition(eventNo, currentEvent, stateChange);

                    if (Table[k, 1].View.Font != null)
                    {
                        transition.InitialEvent = Table[k, 1].View.Font.Italic;
                        if (Table[k, 1].View.Font.Underline)
                            transition.Event.Type = OOEGEventType.Mirror;
                    }
                    else
                        transition.InitialEvent = false;

                    for (int p = 0; p < Table[k, 1].RowSpan; p++)
                    {
                        if (Table[k + p, 4] == null)
                            continue;
                        string strEdgeNo = Table[k + p, 4].DisplayText;
                        int edgeNo = 0;
                        if (!int.TryParse(strEdgeNo, out edgeNo))
                            continue;

                        string edgeCond = string.IsNullOrEmpty(Table[k + p, 5].DisplayText) ? "true" : Table[k + p, 5].DisplayText;
                        string edgeDelay = string.IsNullOrEmpty(Table[k + p, 6].DisplayText) ? "0" : Table[k + p, 6].DisplayText;
                        string edgeParam = string.IsNullOrEmpty(Table[k + p, 7].DisplayText) ? string.Empty : Table[k + p, 7].DisplayText;
                        string edgeNextEvent = Table[k + p, 8].DisplayText;

                        bool isCancelingEdge = false;
                        if (Table[k + p, 8].View != null &&
                            Table[k + p, 8].View.Font != null)
                            isCancelingEdge = Table[k + p, 8].View.Font.Strikeout;
                        OOEGEdgeTransition edgeTransition =
                            new OOEGEdgeTransition(
                                edgeNo, edgeCond, edgeDelay, edgeParam, isCancelingEdge, edgeNextEvent);
                        //edgeNo, edgeCond, new OOEGRandomVariate(edgeDelay), edgeParam, edgeNextEvent);

                        transition.Edges.Add(edgeTransition);
                    }
                    eventNo++;
                    eventTransitions.Add(transition);
                }

                return eventTransitions;
            }
        }
        #endregion

        #region Constructors
        public EventTransitionTableWindow(EventObjectModelEditor parent)
        {
            _EOMControl = parent;

            InitializeComponent();

            drawETTHeaders();

            disableToolbars();

            this.Table.MouseWheel += Table_MouseWheel;
        }
        #endregion

        #region Methods
        private void fireChangeEvent()
        {
            /*
            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
                this.Changed();
             */
        }

        private void drawETTHeaders()
        {
            Table.Rows.Clear();

            Table.BorderStyle = BorderStyle.FixedSingle;
            Table.Redim(2, 9);
            Table.EnableSort = false;
            Table.CustomSort = false;

            Table.FixedRows = 2;

            titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
            titleModel.Font = new Font("Consolas", 9.0f, FontStyle.Bold);

            //Font
            //Table.Font = new Font(
            //    _AMControl.SGMControl.Configuration.StateTransitionTable.Font.FontName,
            //    _AMControl.SGMControl.Configuration.StateTransitionTable.Font.Size);
            //Table.AutoStretchColumnsToFitWidth = _AMControl.SGMControl.Configuration.StateTransitionTable.TableStretch;

            Table.Columns[0].AutoSizeMode = SourceGrid.AutoSizeMode.None;
            Table.Columns[0].Width = 25;
            SourceGrid.Cells.Header l_00Header = new SourceGrid.Cells.Header(null);
            l_00Header.RowSpan = 2;
            Table[0, 0] = l_00Header;

            //1st Row Headers
            SourceGrid.Cells.ColumnHeader eventHeader = new SourceGrid.Cells.ColumnHeader("Originating Event");
            eventHeader.ColumnSpan = 2;
            eventHeader.View = titleModel;
            //stateHeader.SortComparer = new SourceGrid.ValueCellComparer();
            Table[0, 1] = eventHeader;

            SourceGrid.Cells.ColumnHeader stateChangeHeader = new SourceGrid.Cells.ColumnHeader("State Change");
            stateChangeHeader.RowSpan = 2;
            stateChangeHeader.View = titleModel;
            //inputHeader.SortComparer = new SourceGrid.ValueCellComparer();
            Table[0, 3] = stateChangeHeader;

            SourceGrid.Cells.ColumnHeader edgeHeader = new SourceGrid.Cells.ColumnHeader("Edge");
            edgeHeader.RowSpan = 2;
            edgeHeader.View = titleModel;
            //nextStateHeader.SortComparer = new SourceGrid.ValueCellComparer();
            Table[0, 4] = edgeHeader;

            SourceGrid.Cells.ColumnHeader conditionHeader = new SourceGrid.Cells.ColumnHeader("Condition");
            conditionHeader.RowSpan = 2;
            conditionHeader.View = titleModel;
            //nextStateHeader.SortComparer = new SourceGrid.ValueCellComparer();
            Table[0, 5] = conditionHeader;

            SourceGrid.Cells.ColumnHeader delayHeader = new SourceGrid.Cells.ColumnHeader("Delay");
            delayHeader.RowSpan = 2;
            delayHeader.View = titleModel;
            //nextStateHeader.SortComparer = new SourceGrid.ValueCellComparer();
            Table[0, 6] = delayHeader;

            SourceGrid.Cells.ColumnHeader pvHeader = new SourceGrid.Cells.ColumnHeader("Parameter\r\nValue");
            pvHeader.RowSpan = 2;
            pvHeader.View = titleModel;
            //nextStateHeader.SortComparer = new SourceGrid.ValueCellComparer();
            Table[0, 7] = pvHeader;

            SourceGrid.Cells.ColumnHeader destEventHeader = new SourceGrid.Cells.ColumnHeader("Destination\r\nEvent");
            destEventHeader.RowSpan = 2;
            destEventHeader.View = titleModel;
            //nextStateHeader.SortComparer = new SourceGrid.ValueCellComparer();
            Table[0, 8] = destEventHeader;

            //2nd Row Headers
            SourceGrid.Cells.ColumnHeader nameHeader = new SourceGrid.Cells.ColumnHeader("Name");
            nameHeader.View = titleModel;
            Table[1, 1] = nameHeader;

            SourceGrid.Cells.ColumnHeader parameterHeader = new SourceGrid.Cells.ColumnHeader("Parameters");
            parameterHeader.View = titleModel;
            Table[1, 2] = parameterHeader;

            Table.AutoSizeCells();

            _NextEventEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            _NextEventEditor.EditableMode = SourceGrid.EditableMode.Focus |
                                        SourceGrid.EditableMode.SingleClick |
                                        SourceGrid.EditableMode.AnyKey;
            _NextEventEditor.Control.DropDownStyle = ComboBoxStyle.DropDownList;
            _NextEventEditor.Control.TextChanged += new EventHandler(OnNextEventValueChanged);

            _EventValueChangeController = new ETTEventValueChangedEventController();
            _EventValueChangeController.ValueChanged +=
                new ETTEventValueChangedEventHandler(_EventValueChangeController_ValueChanged);

            _NextEventValueChangeController = new ETTNextEventValueChangedEventController();
            _NextEventValueChangeController.ValueChanged +=
                new ETTNextEventValueChangedEventHandler(_NextEventValueChangeController_ValueChanged);

            _ValueChangeController = new ETTValueChangedEventController();
            _ValueChangeController.ValueChanged +=
                new ETTValueChangedEventHandler(_ValueChangeController_ValueChanged);
        }

        void OnNextEventValueChanged(object sender, EventArgs e)
        {
            //System.Diagnostics.Debug.WriteLine("Next Event Change to " + e.ToString());

            //            SourceGrid.Cells.Editors.ComboBox cb = (SourceGrid.Cells.Editors.ComboBox)sender;
            //            cb.
            //현재 위치(cell) 정보 알아낼 것!!!
            //if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            //    this.Changed("NextEvent","changed",  어떤 edge의 nextevent 인지?(from/to 는 알아야 하지 않나?)
        }

        private void _NextEventValueChangeController_ValueChanged(int row, string oldEventName, string newEventName)
        {
            if (isUpdating)
                return;

            string originEventName = Table[row, 1].DisplayText;

            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0 && isChangeable)
                this.Changed("nextevent", "changed", originEventName + "->" + oldEventName, originEventName + "->" + newEventName);
        }

        private void _ValueChangeController_ValueChanged(int row, int col, string oldValue, string newValue)
        {
            if (isUpdating)
                return;

            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0 && isChangeable)
                this.Changed("event_column_" + col, "changed", oldValue, newValue);
        }


        private void _EventValueChangeController_ValueChanged(int row, string oldEventName, string newEventName)
        {
            if (isUpdating)
                return;

            updateNextEventEditor(oldEventName, newEventName);

            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
                this.Changed("eventvertex", "changed", oldEventName, newEventName);
            /*
            if (this.EventNameChanged != null && this.EventNameChanged.GetInvocationList().Length>0)
            {
                this.EventNameChanged(oldEventName, newEventName);
            }*/
        }

        private void updateNextEventEditor(string oldEventName, string newEventName)
        {
            List<string> eventNames = new List<string>();

            bool isInserted = false;
            foreach (string en in _NextEventEditor.StandardValues)
            {
                if (en.Equals(oldEventName))
                {
                    eventNames.Add(newEventName);
                    isInserted = true;
                }
                else
                    eventNames.Add(en);
            }
            if (!isInserted)
                eventNames.Add(newEventName);

            eventNames.Sort();

            _NextEventEditor.StandardValues = eventNames.ToArray();
        }

        private void updateNextEventEditor()
        {
            List<string> eventNames = new List<string>();

            for (int i = 2; i < Table.RowsCount; i++)
            {
                string en = Table[i, 1].DisplayText;
                if (!eventNames.Contains(en))
                    eventNames.Add(en);
            }

            eventNames.Sort();

            _NextEventEditor.StandardValues = eventNames.ToArray();
        }

        private bool isUpdating = false;
        public void Update(OOEGEventObjectModel eoModel)
        {
            isUpdating = true;
            //Initial Event
            foreach (OOEGEventTransition et in eoModel.EventTransitions)
            {
                if (et.InitialEvent)
                    InsertEventTransition(et);
            }

            //Events
            List<string> eventNames = new List<string>();
            foreach (OOEGEventTransition et in eoModel.EventTransitions)
                eventNames.Add(et.Event.Name);
            eventNames.Sort();

            ////State Combo Editor
            _NextEventEditor.StandardValues = eventNames.ToArray();

            foreach (OOEGEventTransition et in eoModel.EventTransitions)
            {
                if (et.InitialEvent)
                    continue;

                InsertEventTransition(et);
            }

            Table.AutoStretchColumnsToFitWidth = false;
            Table.AutoStretchRowsToFitHeight = false;
            Table.AutoSizeCells();

            enableToolbars();

            isUpdating = false;
        }

        private void InsertEventTransition(OOEGEventTransition transition)
        {
            int rowIndex = Table.RowsCount;// -1;
            int rowCount = transition.Edges.Count == 0 ? 1 : transition.Edges.Count;
            Table.Rows.InsertRange(rowIndex, rowCount);

            //Views
            SourceGrid.Cells.Views.Cell defaultView = new SourceGrid.Cells.Views.Cell();
            defaultView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.Views.Cell topView = new SourceGrid.Cells.Views.Cell();
            topView.TextAlignment = DevAge.Drawing.ContentAlignment.TopLeft;

            SourceGrid.Cells.Views.Cell initialEventTopView = new SourceGrid.Cells.Views.Cell();
            initialEventTopView.TextAlignment = DevAge.Drawing.ContentAlignment.TopLeft;
            initialEventTopView.Font = new Font("Times, Arial", 10.0f, FontStyle.Italic);

            SourceGrid.Cells.Views.Cell mirrorEventTopView = new SourceGrid.Cells.Views.Cell();
            mirrorEventTopView.TextAlignment = DevAge.Drawing.ContentAlignment.TopLeft;
            mirrorEventTopView.Font = new Font("Times, Arial", 10.0f, FontStyle.Underline);

            SourceGrid.Cells.Views.Cell cancelingEventView = new SourceGrid.Cells.Views.Cell();
            cancelingEventView.TextAlignment = DevAge.Drawing.ContentAlignment.TopLeft;
            cancelingEventView.Font = new Font("Times, Arial", 10.0f, FontStyle.Strikeout);


            SourceGrid.Cells.Views.Cell conditionView = new SourceGrid.Cells.Views.Cell();
            conditionView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            SourceGrid.Cells.Views.ComboBox comboView = new SourceGrid.Cells.Views.ComboBox();
            comboView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.Views.ComboBox comboTopView = new SourceGrid.Cells.Views.ComboBox();
            comboTopView.TextAlignment = DevAge.Drawing.ContentAlignment.TopLeft;

            for (int i = 0; i < rowCount; i++)
            {
                Table[rowIndex + i, 0] = new SourceGrid.Cells.RowHeader(null);
            }

            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(transition.Event.Name, typeof(string));
            nameCell.RowSpan = rowCount;
            if (transition.InitialEvent)
                nameCell.View = initialEventTopView;
            else if (transition.Event.Type == OOEGEventType.Mirror)
                nameCell.View = mirrorEventTopView;
            else
                nameCell.View = topView;

            nameCell.AddController(_EventValueChangeController);
            Table[rowIndex, 1] = nameCell;

            SourceGrid.Cells.Cell paramCell = new SourceGrid.Cells.Cell(transition.Event.Parameters, typeof(string));
            paramCell.View = topView;
            paramCell.RowSpan = rowCount;
            paramCell.AddController(_ValueChangeController);
            Table[rowIndex, 2] = paramCell;

            SourceGrid.Cells.Cell stateChangeCell = new SourceGrid.Cells.Cell(transition.Action, typeof(string));
            stateChangeCell.View = topView;
            stateChangeCell.RowSpan = rowCount;
            ActionEditorDialog actionEditor1 = new ActionEditorDialog();
            stateChangeCell.Editor = actionEditor1;
            stateChangeCell.AddController(_ValueChangeController);
            Table[rowIndex, 3] = stateChangeCell;

            int rowIndex2 = rowIndex;
            for (int i = 0; i < transition.Edges.Count; i++)
            {
                OOEGEdgeTransition edge = transition.Edges[i];

                SourceGrid.Cells.Cell edgeCell = new SourceGrid.Cells.Cell(edge.EdgeNo, typeof(int));
                edgeCell.View = topView;
                edgeCell.AddController(_ValueChangeController);
                Table[rowIndex2, 4] = edgeCell;

                SourceGrid.Cells.Cell condCell = new SourceGrid.Cells.Cell(edge.Condition, typeof(string));
                condCell.View = conditionView;
                condCell.AddController(_ValueChangeController);
                Table[rowIndex2, 5] = condCell;

                SourceGrid.Cells.Cell delayCell = new SourceGrid.Cells.Cell(edge.Delay, typeof(string));
                //SourceGrid.Cells.Cell delayCell = new SourceGrid.Cells.Cell(edge.Delay.Expression, typeof(string));
                delayCell.View = topView;
                ActionEditorDialog actionEditor3 = new ActionEditorDialog();
                delayCell.Editor = actionEditor3;
                delayCell.AddController(_ValueChangeController);
                Table[rowIndex2, 6] = delayCell;

                SourceGrid.Cells.Cell pvCell = new SourceGrid.Cells.Cell(edge.Parameters, typeof(string));
                pvCell.View = topView;
                pvCell.AddController(_ValueChangeController);
                Table[rowIndex2, 7] = pvCell;

                SourceGrid.Cells.Cell nextEventCell = new SourceGrid.Cells.Cell(edge.NextEvent, _NextEventEditor);
                if (edge.IsCancelingEdge)
                    nextEventCell.View = cancelingEventView;
                else
                    nextEventCell.View = topView;
                nextEventCell.AddController(_NextEventValueChangeController);
                Table[rowIndex2, 8] = nextEventCell;

                rowIndex2++;
            }

            if (transition.Edges.Count == 0)
            {
                SourceGrid.Cells.Cell edgeCell = new SourceGrid.Cells.Cell(1, typeof(int));
                edgeCell.View = topView;
                edgeCell.AddController(_ValueChangeController);
                Table[rowIndex, 4] = edgeCell;

                SourceGrid.Cells.Cell edgeCondCell = new SourceGrid.Cells.Cell("true", typeof(string));
                edgeCondCell.View = conditionView;
                edgeCondCell.AddController(_ValueChangeController);
                Table[rowIndex, 5] = edgeCondCell;

                SourceGrid.Cells.Cell edgeDelayCell = new SourceGrid.Cells.Cell("0", typeof(string));
                edgeDelayCell.View = defaultView;
                //Delay 입력을 위한 dialog 를 따로 제작할 것!!!
                ActionEditorDialog actionEditor3 = new ActionEditorDialog();
                edgeDelayCell.Editor = actionEditor3;
                edgeDelayCell.AddController(_ValueChangeController);
                Table[rowIndex, 6] = edgeDelayCell;

                SourceGrid.Cells.Cell pvCell = new SourceGrid.Cells.Cell("", typeof(string));
                pvCell.View = defaultView;
                pvCell.AddController(_ValueChangeController);
                Table[rowIndex, 7] = pvCell;

                SourceGrid.Cells.Cell nextEventCell = new SourceGrid.Cells.Cell("", _NextEventEditor);
                nextEventCell.View = topView;
                nextEventCell.AddController(_NextEventValueChangeController);
                Table[rowIndex, 8] = nextEventCell;
            }
        }

        private void InsertEmptyEventTransition(string eventName)
        {
            if (this.EventTransitions.Count == 0)
                doInsertEmptyEventTransition(eventName, true);
            else
                doInsertEmptyEventTransition(eventName, false);
        }

        private void InsertEmptyEventTransition()
        {
            string eventName = "EventVertex " + _NodeFactory.NextTypeID(NodeType.EventVertex);

            doInsertEmptyEventTransition(eventName, false);
            //Table.Font = new Font(Table.Font.FontFamily, Table.Font.Size);
            if (isChangeable && this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            {
                this.Changed("eventvertex", "added", string.Empty, eventName);
            }
        }

        private void doInsertEmptyEventTransition(string eventName, bool isInitialEvent)
        {
            int rowIndex = Table.RowsCount;// -1;

            if (rowIndex == 2)
                enableToolbars();

            Table.Rows.Insert(rowIndex);

            SourceGrid.Cells.Views.ComboBox comboView = new SourceGrid.Cells.Views.ComboBox();
            comboView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.Views.ComboBox comboTopView = new SourceGrid.Cells.Views.ComboBox();
            comboTopView.TextAlignment = DevAge.Drawing.ContentAlignment.TopLeft;

            SourceGrid.Cells.Views.Cell defaultView = new SourceGrid.Cells.Views.Cell();
            defaultView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.Views.Cell topView = new SourceGrid.Cells.Views.Cell();
            topView.TextAlignment = DevAge.Drawing.ContentAlignment.TopLeft;

            SourceGrid.Cells.Views.Cell conditionView = new SourceGrid.Cells.Views.Cell();
            conditionView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            Table[rowIndex, 0] = new SourceGrid.Cells.RowHeader(null);

            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(eventName, typeof(string));
            nameCell.View = topView;
            nameCell.AddController(_EventValueChangeController);
            Table[rowIndex, 1] = nameCell;

            if (isInitialEvent)
            {
                if (Table[rowIndex, 1].View.Font == null)
                {
                    SourceGrid.Cells.Views.Cell cell = new SourceGrid.Cells.Views.Cell();
                    cell.Font = new Font("Times, Arial", 10.0f, FontStyle.Italic);
                    Table[rowIndex, 1].View = cell;
                }
                else if (Table[rowIndex, 1].View.Font != null && !Table[rowIndex, 1].View.Font.Italic)
                {
                    Table[rowIndex, 1].View.Font = new Font(Table[rowIndex, 1].View.Font.FontFamily,
                                                        Table[rowIndex, 1].View.Font.Size, FontStyle.Italic);
                }
            }

            SourceGrid.Cells.Cell paramCell = new SourceGrid.Cells.Cell("", typeof(string));
            paramCell.View = topView;
            paramCell.AddController(_ValueChangeController);
            Table[rowIndex, 2] = paramCell;

            SourceGrid.Cells.Cell actionCell = new SourceGrid.Cells.Cell("", typeof(string));
            actionCell.View = topView;
            ActionEditorDialog actionEditor1 = new ActionEditorDialog();
            actionCell.Editor = actionEditor1;
            actionCell.AddController(_ValueChangeController);
            Table[rowIndex, 3] = actionCell;

            SourceGrid.Cells.Cell edgeCell = new SourceGrid.Cells.Cell(1, typeof(int));
            edgeCell.View = topView;
            edgeCell.AddController(_ValueChangeController);
            Table[rowIndex, 4] = edgeCell;

            SourceGrid.Cells.Cell edgeCondCell = new SourceGrid.Cells.Cell("true", typeof(string));
            edgeCondCell.View = conditionView;
            edgeCondCell.AddController(_ValueChangeController);
            Table[rowIndex, 5] = edgeCondCell;

            SourceGrid.Cells.Cell edgeDelayCell = new SourceGrid.Cells.Cell("0", typeof(string));
            edgeDelayCell.View = defaultView;
            //Delay 입력을 위한 dialog 를 따로 제작할 것!!!
            ActionEditorDialog actionEditor3 = new ActionEditorDialog();
            edgeDelayCell.Editor = actionEditor3;
            edgeDelayCell.AddController(_ValueChangeController);
            Table[rowIndex, 6] = edgeDelayCell;

            SourceGrid.Cells.Cell pvCell = new SourceGrid.Cells.Cell("", typeof(string));
            pvCell.View = defaultView;
            pvCell.AddController(_ValueChangeController);
            Table[rowIndex, 7] = pvCell;

            SourceGrid.Cells.Cell nextEventCell = new SourceGrid.Cells.Cell("", _NextEventEditor);
            nextEventCell.View = topView;
            nextEventCell.AddController(_NextEventValueChangeController);
            Table[rowIndex, 8] = nextEventCell;
        }

        private void disableToolbars()
        {
            tsbDelete.Enabled = false;
            tsbInsertCondition.Enabled = false;
            tsbDeleteCondition.Enabled = false;
            tsbAutoCellSize.Enabled = false;
            tsbCopy.Enabled = false;
        }

        private void enableToolbars()
        {
            tsbDelete.Enabled = true;
            tsbInsertCondition.Enabled = true;
            tsbDeleteCondition.Enabled = true;
            tsbAutoCellSize.Enabled = true;
            tsbCopy.Enabled = true;
        }

        private void Clear()
        {
            while (Table.Rows.Count > 2)
                Table.Rows.Remove(2);
        }

        private void AutoSizeCells()
        {
            Table.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            Table.AutoStretchColumnsToFitWidth = false;
            Table.AutoStretchRowsToFitHeight = false;
            Table.AutoSizeCells();
            if (Table.Rows.Count > 2)
                Table.DefaultHeight = Table.Rows[3].Height;

        }
        #endregion

        #region Form Event Handlers
        private void EventTransitionTableEditor_Load(object sender, EventArgs e)
        {

        }

        private void EventTransitionTableWindow_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            base.OnFormClosing(e);
        }
        #endregion

        #region Toolstrip Handlers - Events
        private void tsbInsert_Click(object sender, EventArgs e)
        {
            try
            {
                InsertEmptyEventTransition();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
            }
        }

        private void tsbDelete_Click(object sender, EventArgs e)
        {
            int sRow = Table.Selection.ActivePosition.Row;

            deleteEventAtRow(sRow);
        }

        private void deleteEventAtRow(int sRow)
        {
            if (sRow < 2 || Table[sRow, 0] == null)
                return;

            string eventName = string.Empty;
            eventName = Table[sRow, 1].DisplayText;
            if (Table[sRow, 1].RowSpan > 1)
            {
                int count = Table[sRow, 1].RowSpan;
                for (int k = 0; k < count; k++)
                    Table.Rows.Remove(sRow);
            }
            else
            {
                Table.Rows.Remove(sRow);
            }

            if (Table.Rows.Count == 2)
            {
                disableToolbars();
            }

            if (isChangeable)
            {
                this.Changed("eventvertex", "deleted", eventName, string.Empty);
            }
        }

        #endregion

        #region Toolstrip Handlers - Outgoing Edge
        private void tsbInsertCondition_Click(object sender, EventArgs e)
        {
            int sRow = Table.Selection.ActivePosition.Row;

            if (sRow < 2)
                return;

            insertEmptyCondition(sRow);
        }

        private void insertEmptyCondition(int sRow)
        {
            int rowIndex = sRow + 1;
            //int rowIndex = sRow + 1;
            //int rowIndex = sRow + Table[sRow, 3].RowSpan;

            int startRow1 = Table[sRow, 1].Range.Start.Row;
            int startRow3 = Table[sRow, 4].Range.Start.Row;

            bool noRowSpan1 = false;
            int rowSpan1 = Table[sRow, 1].RowSpan;
            if (rowIndex < (startRow1 + rowSpan1))
                noRowSpan1 = true;

            bool noRowSpan3 = false;
            int rowSpan3 = Table[sRow, 4].RowSpan;
            if (rowIndex < (startRow3 + rowSpan3))
                noRowSpan3 = true;

            Table.Rows.Insert(rowIndex);

            try
            {
                Table[sRow, 1].RowSpan = rowSpan1 + 1;
                Table[sRow, 2].RowSpan = rowSpan1 + 1;
                Table[sRow, 3].RowSpan = rowSpan3 + 1;
                //if (!noRowSpan)
                //{
                //Table[sRow, 1].RowSpan++;
                //Table[sRow, 2].RowSpan++;
                //}
                //if (!noRowSpan2)
                //{
                //Table[sRow, 3].RowSpan++;
                //Table[sRow, 4].RowSpan++;
                //}

            }
            catch (Exception ex) { }

            SourceGrid.Cells.Views.Cell defaultView = new SourceGrid.Cells.Views.Cell();
            defaultView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.Views.Cell topView = new SourceGrid.Cells.Views.Cell();
            topView.TextAlignment = DevAge.Drawing.ContentAlignment.TopLeft;

            SourceGrid.Cells.Views.Cell conditionView = new SourceGrid.Cells.Views.Cell();
            conditionView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            Table[rowIndex, 0] = new SourceGrid.Cells.RowHeader(null);

            SourceGrid.Cells.Cell edgeCell = new SourceGrid.Cells.Cell(1, typeof(int));
            edgeCell.View = topView;
            edgeCell.AddController(_ValueChangeController);
            Table[rowIndex, 4] = edgeCell;

            SourceGrid.Cells.Cell edgeCondCell = new SourceGrid.Cells.Cell("true", typeof(string));
            edgeCondCell.View = conditionView;
            edgeCondCell.AddController(_ValueChangeController);
            Table[rowIndex, 5] = edgeCondCell;

            SourceGrid.Cells.Cell edgeDelayCell = new SourceGrid.Cells.Cell("0", typeof(string));
            edgeDelayCell.View = defaultView;
            //Delay 입력을 위한 dialog 를 따로 제작할 것!!!
            ActionEditorDialog actionEditor3 = new ActionEditorDialog();
            edgeDelayCell.Editor = actionEditor3;
            edgeDelayCell.AddController(_ValueChangeController);
            Table[rowIndex, 6] = edgeDelayCell;

            SourceGrid.Cells.Cell pvCell = new SourceGrid.Cells.Cell("", typeof(string));
            pvCell.View = defaultView;
            pvCell.AddController(_ValueChangeController);
            Table[rowIndex, 7] = pvCell;

            SourceGrid.Cells.Cell nextEventCell = new SourceGrid.Cells.Cell("", _NextEventEditor);
            nextEventCell.View = topView;
            nextEventCell.AddController(_NextEventValueChangeController);
            Table[rowIndex, 8] = nextEventCell;
        }


        private void deleteConditionEdgeRow(int sRow)
        {
            int inputStartRow = Table[sRow, 4].Range.Start.Row;
            int inputEndRow = Table[sRow, 4].Range.End.Row;
            int inputRowSpan = Table[inputStartRow, 4].RowSpan;

            int stateStartRow = Table[sRow, 1].Range.Start.Row;
            int stateEndRow = Table[sRow, 1].Range.End.Row;
            int stateRowSpan = Table[stateStartRow, 1].RowSpan;

            if (stateRowSpan == 1)
                return;

            if (inputStartRow == sRow)
            {
                SourceGrid.Cells.Cell nameCell = null;
                SourceGrid.Cells.Cell paramCell = null;
                SourceGrid.Cells.Cell stateChangeCell = null;

                SourceGrid.Cells.Cell edgeCell = null;
                SourceGrid.Cells.Cell condCell = null;
                SourceGrid.Cells.Cell delayCell = null;
                SourceGrid.Cells.Cell pvCell = null;
                SourceGrid.Cells.Cell nextEventCell = null;
                if (stateStartRow == inputStartRow)
                {
                    nameCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 1];
                    nameCell.UnBindToGrid();
                    paramCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 2];
                    paramCell.UnBindToGrid();
                    stateChangeCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 3];
                    stateChangeCell.UnBindToGrid();
                }

                edgeCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 3];
                edgeCell.UnBindToGrid();
                condCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 4];
                condCell.UnBindToGrid();
                delayCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 4];
                delayCell.UnBindToGrid();
                pvCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 4];
                pvCell.UnBindToGrid();
                nextEventCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 4];
                nextEventCell.UnBindToGrid();

                Table.Rows.Remove(sRow);

                if (stateStartRow == inputStartRow)
                {
                    nameCell.RowSpan = stateRowSpan - 1;
                    paramCell.RowSpan = stateRowSpan - 1;
                    stateChangeCell.RowSpan = stateRowSpan - 1;
                    Table[stateStartRow, 1] = nameCell;
                    Table[stateStartRow, 2] = paramCell;
                    Table[stateStartRow, 3] = stateChangeCell;
                }
            }
            else
            {
                Table.Rows.Remove(sRow);
            }

        }

        private void tsbDeleteCondition_Click(object sender, EventArgs e)
        {
            int sRow = Table.Selection.ActivePosition.Row;
            if (sRow < 2 || Table.Selection.ActivePosition.Column < 5)
                return;

            deleteConditionEdgeRow(sRow);
        }

        private void tsbAutoCellSize_Click(object sender, EventArgs e)
        {
            AutoSizeCells();
        }

        private void tsbCopy_Click(object sender, EventArgs e)
        {

        }
        #endregion

        #region Toolstrip Handlers - Fonts
        private void cbFonts_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            zoomOut();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            zoomIn();
        }

        private void zoomIn()
        {
            Table.Font = new Font(Table.Font.FontFamily, Table.Font.Size + 1);
            titleModel.Font = new Font(titleModel.Font.FontFamily, Table.Font.Size + 1, FontStyle.Bold);
            AutoSizeCells();
        }

        private void zoomOut()
        {
            Table.Font = new Font(Table.Font.FontFamily, Table.Font.Size - 1);
            titleModel.Font = new Font(titleModel.Font.FontFamily, Table.Font.Size - 1, FontStyle.Bold);

            AutoSizeCells();
        }
        #endregion

        #region Table Event Handlers
        private void Table_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            SourceGrid.Position p = Table.PositionAtPoint(e.Location);
            if (p.IsEmpty())
            {
                InsertEmptyEventTransition();
            }

        }
        #endregion

        private void tsbSetInitialEvent_Click(object sender, EventArgs e)
        {
            doSetInitialEvent();
        }

        private void doSetInitialEvent()
        {
            int row = Table.Selection.ActivePosition.Row;
            int column = Table.Selection.ActivePosition.Column;

            if (row < 0 || column < 0)
                return;

            bool oldValue = false;
            string eventName = Table[row, 1].DisplayText;

            if (Table[row, 1].View.Font == null)
            {
                SourceGrid.Cells.Views.Cell cell = new SourceGrid.Cells.Views.Cell();
                cell.Font = new Font("Times, Arial", 10.0f, FontStyle.Italic);
                Table[row, 1].View = cell;
            }
            else if (Table[row, 1].View.Font != null && !Table[row, 1].View.Font.Italic)
            {
                Table[row, 1].View.Font = new Font(Table[row, 1].View.Font.FontFamily,
                                                    Table[row, 1].View.Font.Size, FontStyle.Italic);
            }
            else
            {
                Table[row, 1].View.Font = new Font(Table[row, 1].View.Font.FontFamily,
                                                    Table[row, 1].View.Font.Size, FontStyle.Regular);
                oldValue = true;
            }

            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            {
                this.Changed("initialevent", "changed", eventName, (!oldValue).ToString());
            }

            Table.Invalidate();
        }

        private void tsbEdgeType_Click(object sender, EventArgs e)
        {
            doSetEdgeType();
        }

        private void doSetEdgeType(string fromEvent, string toEvent, bool isCancelingEdge)
        {
            for (int i = 2; i < Table.RowsCount; i++)
            {
                string originEventVertex = Table[i, 1].DisplayText;
                if (originEventVertex != fromEvent)
                    continue;

                bool isApplied = false;
                for (int k = 0; k < Table[i, 1].RowSpan; k++)
                {
                    int rowIndex = i + k;
                    string nextEventVertex = Table[rowIndex, 8].DisplayText;

                    if (originEventVertex == fromEvent && nextEventVertex == toEvent)
                    {
                        if (Table[rowIndex, 8].View.Font == null)
                        {
                            SourceGrid.Cells.Views.Cell cell = new SourceGrid.Cells.Views.Cell();
                            if (isCancelingEdge)
                                //Table[i, 8].View.Font = new Font("Calibri", 9.0f, FontStyle.Strikeout);
                                cell.Font = new Font("Calibri", 9.0f, FontStyle.Strikeout);
                            else
                                //Table[i, 8].View.Font = new Font("Calibri", 9.0f, FontStyle.Regular);
                                cell.Font = new Font("Calibri", 9.0f, FontStyle.Regular);
                            Table[rowIndex, 8].View = cell;
                        }
                        else
                        {
                            if (isCancelingEdge)
                            {
                                Table[rowIndex, 8].View.Font = new Font(
                                                                    Table[rowIndex, 8].View.Font.FontFamily,
                                                                    Table[rowIndex, 8].View.Font.Size,
                                                                    FontStyle.Strikeout);
                            }
                            else
                            {
                                Table[rowIndex, 8].View.Font = new Font(
                                                                    Table[rowIndex, 8].View.Font.FontFamily,
                                                                    Table[rowIndex, 8].View.Font.Size,
                                                                    FontStyle.Regular);
                            }
                        }
                        Table.Invalidate();
                        isApplied = true;
                        break;
                    }
                }

                if (isApplied)
                    break;
            }
        }

        private void doSetEdgeType()
        {
            int row = Table.Selection.ActivePosition.Row;
            int column = Table.Selection.ActivePosition.Column;

            if (row < 0 || column < 0)
                return;

            if (Table[row, 8].View.Font == null)
            {
                SourceGrid.Cells.Views.Cell cell = new SourceGrid.Cells.Views.Cell();
                cell.Font = new Font("Times, Arial", 10.0f, FontStyle.Strikeout);
                Table[row, 8].View = cell;

            }
            else if (Table[row, 8].View.Font != null && !Table[row, 8].View.Font.Strikeout)
                Table[row, 8].View.Font = new Font(Table[row, 8].View.Font.FontFamily,
                                                    Table[row, 8].View.Font.Size, FontStyle.Strikeout);
            else
                Table[row, 8].View.Font = new Font(Table[row, 8].View.Font.FontFamily,
                                                    Table[row, 8].View.Font.Size, FontStyle.Regular);

            Table.Invalidate();

            string fromEvent = string.Empty;
            string toEvent = string.Empty;

            fromEvent = Table[row, 1].DisplayText; //추후 수정필요함 (2015.05.06)
            toEvent = Table[row, 8].DisplayText;

            bool canceled = Table[row, 8].View.Font.Style == FontStyle.Strikeout;
            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            {
                this.Changed("edgetype", "changed", fromEvent + "->" + toEvent, canceled.ToString());
            }
        }

        private bool isChangeable = true;
        public void OnEGDChanged(ChangedTarget target, ChangedType action, string targetName, string propertyName, object before, object after)
        {
            //TODO
            //추후 evnet handler class 를 두어서 개별 cs 파일로 나눠서 관리할 것!!!
            //아니면, design pattern 을 적용할 것!!!

            isChangeable = false;
            if (target == ChangedTarget.Event)
            {
                doHandleVertexChange(action, targetName, propertyName, before, after);
            }
            else if (target == ChangedTarget.SchedulingEdge)
            {
                doHandleEdgeChange(action, before, after);
            }
            else if (target == ChangedTarget.SchedulingEdgeType)
            {
                doHandleEdgeTypeChange(action, before, after);
            }

            isChangeable = true;
        }

        private void doHandleVertexChange(ChangedType action, string eventName, string propertyName, object before, object after)
        {
            if (action == ChangedType.Modified)
            {
                if (before is OOEGEvent)
                    return;

                if (propertyName.Equals("NAME"))
                {
                    string oldValue = (string)before;
                    string newValue = (string)after;
                    for (int i = 2; i < Table.RowsCount; i++)
                    {
                        SourceGrid.Cells.Cell nameCell = (SourceGrid.Cells.Cell)Table[i, 1];
                        SourceGrid.Cells.Cell nextEventCell = (SourceGrid.Cells.Cell)Table[i, 8];

                        if (nameCell != null && nameCell.DisplayText == oldValue)
                        {
                            nameCell.Value = after;
                        }

                        if (nextEventCell != null && nextEventCell.DisplayText == oldValue)
                        {
                            nextEventCell.Value = after;
                        }
                    }
                }
                else if (propertyName.Equals("TYPE"))
                {
                    OOEGEventType oldValue = (OOEGEventType)before;
                    OOEGEventType newValue = (OOEGEventType)after;
                    for (int i = 2; i < Table.RowsCount; i++)
                    {
                        SourceGrid.Cells.Cell nameCell = (SourceGrid.Cells.Cell)Table[i, 1];
                        if (nameCell != null && nameCell.DisplayText == eventName)
                        {
                            bool underline = (newValue == OOEGEventType.Mirror) ? true : false;
                            if (nameCell.View.Font == null)
                            {
                                SourceGrid.Cells.Views.Cell cell = new SourceGrid.Cells.Views.Cell();
                                if (underline)
                                    cell.Font = new Font("Times, Arial", Table.Font.Size, FontStyle.Underline);
                                else
                                    cell.Font = new Font("Times, Arial", Table.Font.Size, FontStyle.Regular);
                                nameCell.View = cell;
                            }
                            else if (nameCell.View.Font != null)
                            {
                                if (underline)
                                    nameCell.View.Font = new Font(nameCell.View.Font.FontFamily, nameCell.View.Font.Size, FontStyle.Underline);
                                else
                                    nameCell.View.Font = new Font(nameCell.View.Font.FontFamily, nameCell.View.Font.Size, FontStyle.Regular);
                            }
                        }
                    }
                }
                else if (propertyName.Equals("PARAMETERS"))
                {
                    string oldValue = (string)before;
                    string newValue = (string)after;
                    for (int i = 2; i < Table.RowsCount; i++)
                    {
                        SourceGrid.Cells.Cell nameCell = (SourceGrid.Cells.Cell)Table[i, 1];
                        SourceGrid.Cells.Cell paramCell = (SourceGrid.Cells.Cell)Table[i, 2];

                        if (nameCell != null && nameCell.DisplayText == eventName)
                        {
                            paramCell.Value = newValue;
                            break;
                        }
                    }
                }
                updateNextEventEditor();
            }
            else if (action == ChangedType.Added)
            {
                string newValue = (string)after;
                InsertEmptyEventTransition(newValue);
                updateNextEventEditor();
            }
            else if (action == ChangedType.Deleted)
            {
                string oldValue = (string)before;
                for (int i = 2; i < Table.RowsCount; i++)
                {
                    SourceGrid.Cells.Cell nameCell =
                        (SourceGrid.Cells.Cell)Table[i, 1];

                    if (nameCell.DisplayText == oldValue)
                    {
                        deleteEventAtRow(i);
                        break;
                    }
                }
                updateNextEventEditor();
            }
        }

        private void doHandleEdgeTypeChange(ChangedType action, object before, object after)
        {
            string edgeType = (string)before;
            string[] strList = ((string)after).Split(new string[] { "->" }, StringSplitOptions.RemoveEmptyEntries);
            string fromEvent = strList[0];
            string toEvent = strList[1];
            bool isCancelingEdge = false;

            if (action == ChangedType.Modified)
            {
                if (edgeType == "scheduling")
                {
                    isCancelingEdge = false;
                }
                else if (edgeType == "canceling")
                {
                    isCancelingEdge = true;
                }
            }
            doSetEdgeType(fromEvent, toEvent, isCancelingEdge);
        }

        private void doHandleEdgeChange(ChangedType action, object before, object after)
        {
            if (action == ChangedType.Modified)
            {
                //TODO
            }
            else if (action == ChangedType.Added)
            {
                string[] eventVertices = ((string)after).Split(new string[] { "->" }, StringSplitOptions.RemoveEmptyEntries);
                string fromEvent = eventVertices[0];
                string toEvent = eventVertices[1];

                for (int i = 2; i < Table.RowsCount; i++)
                {
                    SourceGrid.Cells.Cell nameCell =
                        (SourceGrid.Cells.Cell)Table[i, 1];

                    if (nameCell.DisplayText == fromEvent)
                    {
                        bool isAdded = false;
                        for (int k = 0; k < nameCell.RowSpan; k++)
                        {
                            SourceGrid.Cells.Cell nextEventCell =
                                (SourceGrid.Cells.Cell)Table[i + k, 8];

                            if (nextEventCell == null)
                                continue;

                            if (string.IsNullOrEmpty(nextEventCell.DisplayText))
                            {
                                nextEventCell.Value = toEvent;
                                isAdded = true;
                                break;
                            }
                        }
                        if (!isAdded)
                        {
                            int nextRow = i + nameCell.RowSpan;
                            insertEmptyCondition(i);
                            //insertEmptyCondition(nextRow);

                            SourceGrid.Cells.Cell nextEventCell =
                                (SourceGrid.Cells.Cell)Table[nextRow, 8];

                            nextEventCell.Value = toEvent;
                        }

                        break;
                    }
                }

            }
            else if (action == ChangedType.Deleted)
            {
                string[] eventVertices = ((string)before).Split(new string[] { "->" }, StringSplitOptions.RemoveEmptyEntries);
                string fromEvent = eventVertices[0];
                string toEvent = eventVertices[1];

                for (int i = 2; i < Table.RowsCount; i++)
                {
                    SourceGrid.Cells.Cell nameCell =
                        (SourceGrid.Cells.Cell)Table[i, 1];

                    if (nameCell.DisplayText == fromEvent)
                    {
                        for (int k = 0; k < nameCell.RowSpan; k++)
                        {
                            SourceGrid.Cells.Cell nextEventCell =
                                (SourceGrid.Cells.Cell)Table[i + k, 8];

                            if (nextEventCell.DisplayText == toEvent)
                            {
                                nextEventCell.Value = string.Empty;

                                SourceGrid.Cells.Cell edgeCell =
                                        (SourceGrid.Cells.Cell)Table[i + k, 4];
                                edgeCell.Value = string.Empty;

                                SourceGrid.Cells.Cell edgeCondCell =
                                        (SourceGrid.Cells.Cell)Table[i + k, 5];
                                edgeCondCell.Value = "true";

                                SourceGrid.Cells.Cell edgeDelayCell =
                                        (SourceGrid.Cells.Cell)Table[i + k, 6];
                                edgeDelayCell.Value = "0";

                                SourceGrid.Cells.Cell pvCell =
                                        (SourceGrid.Cells.Cell)Table[i + k, 7];
                                pvCell.Value = string.Empty;

                                deleteConditionEdgeRow(i + k);
                                break;
                            }
                        }
                    }
                }
            }
        }

        private void EventTransitionTableWindow_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Add && e.Control)
            {
                zoomIn();
            }
            else if (e.KeyCode == Keys.Subtract && e.Control)
            {
                zoomOut();
            }
            else if (e.KeyCode == Keys.OemMinus && e.Control)
            {
                zoomOut();
            }
            else if (e.KeyCode == Keys.Oemplus && e.Control)
            {
                zoomIn();
            }
        }

        private void Table_MouseWheel(object sender, MouseEventArgs e)
        {
            if (Form.ModifierKeys == Keys.Control)
            {
                if (e.Delta > 0)
                {
                    //zoom in
                    zoomIn();
                }
                else if (e.Delta < 0)
                {
                    //zoom out
                    zoomOut();
                }
            }
        }
    }

    public delegate void ETTEventValueChangedEventHandler(int row, string oldEventName, string newEventName);

    public class ETTEventValueChangedEventController : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event ETTEventValueChangedEventHandler ValueChanged;

        public ETTEventValueChangedEventController()
        {
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

            ValueChanged(sender.Position.Row, e.OldValue == null ? "" : e.OldValue.ToString(), e.NewValue.ToString());
        }
    }

    public delegate void ETTNextEventValueChangedEventHandler(int row, string oldEventName, string newEventName);
    public class ETTNextEventValueChangedEventController : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event ETTNextEventValueChangedEventHandler ValueChanged;

        public ETTNextEventValueChangedEventController()
        {
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

            ValueChanged(sender.Position.Row, e.OldValue == null ? "" : e.OldValue.ToString(), e.NewValue.ToString());
        }
    }

    public delegate void ETTValueChangedEventHandler(int row, int column, string oldValue, string newValue);
    public class ETTValueChangedEventController : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event ETTValueChangedEventHandler ValueChanged;

        public ETTValueChangedEventController() { }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

             ValueChanged(sender.Position.Row, sender.Position.Column, e.OldValue == null ? "" : e.OldValue.ToString(), e.NewValue == null ? "" : e.NewValue.ToString());
        }
    }
}
