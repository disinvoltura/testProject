﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using DHKANG.SEA.Model;
using System.Text.RegularExpressions;
using DHKANG.SEA.UI.Modeling;
using DHKANG.SEA.UI.Modeling.Properties;
using DHKANG.SEA.UI.OutputView;
using DHKANG.SEA.UI.ETTEditor.Properties;

namespace DHKANG.SEA.UI.ETTEditor
{
    public partial class ETTPropertiesWindow : DockContent
    {
        #region Member Variables
        private EventObjectModelEditor _Parent;

        private EventProperties _EventProperties;
        private ScheduleProperties _ScheduleProperties;
        private EntityQueueProperties _EntityQueueProperties;
        #endregion

        #region Properties
        #endregion

        #region Constructors
        public ETTPropertiesWindow(EventObjectModelEditor parent)
        {
            InitializeComponent();

            _Parent = parent;

            _ScheduleProperties = new ScheduleProperties();
            _ScheduleProperties.Dock = DockStyle.Fill;
            _ScheduleProperties.Visible = false;
            this.Controls.Add(_ScheduleProperties);

            _EntityQueueProperties = new EntityQueueProperties();
            _EntityQueueProperties.Dock = DockStyle.Fill;
            _EntityQueueProperties.Visible = false;
            this.Controls.Add(_EntityQueueProperties);

            _EventProperties = new EventProperties(_Parent);
            _EventProperties.Dock = DockStyle.Fill;
            _EventProperties.Visible = false;
            this.Controls.Add(_EventProperties);
        }
        #endregion

        #region Methods
        public void Update(OOMMModel model, Object target)
        {
            _ScheduleProperties.Visible = false;
            _EntityQueueProperties.Visible = false;
            _EventProperties.Visible = false;

            if (target == null)
            {
                return;
            }
            else if (target is ScheduleNode)
            {
                _ScheduleProperties.Visible = true;
                _ScheduleProperties.BringToFront();
                _ScheduleProperties.Update((ScheduleNode)target);
            }
            else if (target is EventVertexNode)
            {
                _EventProperties.Visible = true;
                _EventProperties.BringToFront();
                _EventProperties.Update((EventVertexNode)target);
            }else if (target is EntityQueueNode)
            {
                _EntityQueueProperties.Visible = true;
                _EntityQueueProperties.BringToFront();
                _EntityQueueProperties.Update((EntityQueueNode)target);
            }
        }
        #endregion
    }
}