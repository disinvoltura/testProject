﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using Northwoods.Go;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;
using Microsoft.Msagl;
using Microsoft.Msagl.Core.Geometry;
using Microsoft.Msagl.Core.Geometry.Curves;
using Microsoft.Msagl.Core.DataStructures;
using Microsoft.Msagl.Core.Layout;
using Microsoft.Msagl.Miscellaneous;
using DHKANG.SEA.Model.OID;

namespace DHKANG.SEA.UI.ETTEditor
{
    public delegate void EventGraphDiagramChangedEvent
                            (ChangedTarget target, ChangedType action, string targetName, string propertyName, object before, object after);
    //(ChangedTarget target, ChangedType action, object before, object after);

    public partial class EventGraphDiagramWindow : DockContent
    {
        #region Member Variables
        private EventObjectModelEditor _EOMControl;
        #endregion

        #region Properties
        public float ViewScale { get { return _View.DocScale; } }

        public NodeFactory NodeFactory
        {
            get { return _View.Doc.NodeFactory; }
            set { _View.Doc.NodeFactory = value; }
        }

        public List<Node> EventVertices { get { return _View.EventVertices; } }

        public List<OOMMSchedule> Schedules
        {
            get
            {
                List<OOMMSchedule> rslt = new List<OOMMSchedule>();
                foreach (ScheduleNode node in _View.Schedules)
                {
                    OOMMSchedule s = new OOMMSchedule(node.NodeID, node.ScheduleName, node.Type, node.TimeUnit, node.Description, node.Left, node.Top);
                    s.Values = node.Values;
                    rslt.Add(s);
                }
                return rslt;
            }
        }

        public List<OOMMEntityQueue> EntityQueues 
        {
            get
            {
                List<OOMMEntityQueue> rslt = new List<OOMMEntityQueue>();
                foreach (EntityQueueNode node in _View.EntityQueues)
                {
                    OOMMEntityQueue q = node.Queue;
                    q.X = node.Left;
                    q.Y = node.Top;
                    rslt.Add(q);
                }
                return rslt;
            }
        }

        public EventGraphDiagramView View { get { return _View; } }

        #endregion

        #region Events
        //public event DiagramChangedEvent Changed;//position changes are included
        public event EventGraphDiagramChangedEvent Changed;//position changes are included
        public event DiagramSelectionChangedEventHandler SelectionChanged;
        public event DiagramObjectSelectedEventHandler ObjectSelected;

        #endregion

        #region Constructors
        public EventGraphDiagramWindow(EventObjectModelEditor parent)
        {
            _EOMControl = parent;

            InitializeComponent();

            _View = new EventGraphDiagramView();
            toolStripContainer1.ContentPanel.Controls.Clear();
            toolStripContainer1.ContentPanel.Controls.Add(_View);
            _View.Dock = DockStyle.Fill;

            _View.ObjectSingleClicked += new GoObjectEventHandler(OnViewObjectSingleClicked);
            _View.ObjectLostSelection += new GoSelectionEventHandler(OnViewObjectLostClicked);
            _View.LinkCreated += new GoSelectionEventHandler(OnViewLinkCreated);
            _View.DocumentChanged += new GoChangedEventHandler(OnViewDocumentChanged);
            _View.ScaleChanged += new DocumentScaleChangedEventHandler(OnViewScaleChanged);
            _View.SelectionFinished += new EventHandler(OnViewSelection);

            _View.InsertionMode = InsertionMode.None;
            _View.AutoConnect = true;

        }
        #endregion

        #region GoView Event Handlers
        private void OnViewObjectSingleClicked(object sender, GoObjectEventArgs e)
        {
            if (e.GoObject.ParentNode != null)
            {
                if (e.GoObject.ParentNode is ScheduleNode)
                {
                    if (this.ObjectSelected != null &&
                             this.ObjectSelected.GetInvocationList().Length > 0)
                        this.ObjectSelected(null, e.GoObject.ParentNode);
                }
                else if (e.GoObject.ParentNode is EntityQueueNode)
                {
                    if (this.ObjectSelected != null &&
                             this.ObjectSelected.GetInvocationList().Length > 0)
                        this.ObjectSelected(null, e.GoObject.ParentNode);
                }
                else if (e.GoObject.ParentNode is GoBasicNode)
                {
                    GoBasicNode node = (GoBasicNode)e.GoObject.ParentNode;
                    if (node.UserObject != null && node.UserObject is EventVertexNode)
                        if (this.ObjectSelected != null && this.ObjectSelected.GetInvocationList().Length > 0)
                            this.ObjectSelected(null, node.UserObject);
                }
                else if (e.GoObject.Parent is ObjectSchedulingLink)
                {
                    ObjectSchedulingLink link = (ObjectSchedulingLink)e.GoObject.Parent;

                    lastFromEventVertex = ((GoBasicNode)link.FromNode).Text;
                    lastToEventVertex = ((GoBasicNode)link.ToNode).Text;
                    lastFromPort = (GoPort)link.FromPort;
                    lastToPort = (GoPort)link.ToPort;
                }
            }
        }

        private void OnViewObjectLostClicked(object sender, GoSelectionEventArgs e)
        {
            if (this.ObjectSelected != null &&
                       this.ObjectSelected.GetInvocationList().Length > 0)
                this.ObjectSelected(null, null);
        }

        private void OnViewLinkCreated(object sender, GoSelectionEventArgs e)
        {
            if (e.GoObject is Link)
            {
                Link l = (Link)e.GoObject;

                if (l.LinkType == LinkType.SchedulingLink)
                {
                    while (_View.Doc.FindLink(EventGraphDiagramView.LastID) != null)
                    //while (_View.Doc.FindLink(EventGraphDiagramView.LastID) != null)
                    {
                        EventGraphDiagramView.LastID++;
                    }
                    l.LinkID = EventGraphDiagramView.LinkCount;
                    EventGraphDiagramView.LastID++;
                    EventGraphDiagramView.LinkCount++;
                }
            }
            else
            {
            }
        }

        private string oldEventVerex = "";
        private string lastFromEventVertex = "";
        private string lastToEventVertex = "";
        private GoPort lastFromPort;
        private GoPort lastToPort;
        private bool isOldEventVertexFrom = false;

        private void OnViewDocumentChanged(object sender, GoChangedEventArgs e)
        {
            if (e.Hint == GoLayer.InsertedObject)
            {
                if (e.GoObject is ScheduleNode)
                {
                    if (isChangeable)
                    {
                        ScheduleNode node = (ScheduleNode)e.GoObject;
                        node.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
                        Changed(ChangedTarget.Schedule, ChangedType.Added, "", "", "", node.ScheduleName);
                    }
                }
                else if (e.GoObject is EntityQueueNode)
                {
                    if (isChangeable)
                    {
                        EntityQueueNode node = (EntityQueueNode)e.GoObject;
                        node.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
                        Changed(ChangedTarget.EntityQueue, ChangedType.Added, "", "", "", node.EntityQueueName);
                    }
                }
                else if (e.GoObject is GoNode)
                {
                    if (isChangeable)
                    {
                        GoBasicNode node = (GoBasicNode)e.GoObject;
                        if (node.UserObject is EventVertexNode)
                        {
                            EventVertexNode eventNode = (EventVertexNode)node.UserObject;
                            eventNode.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
                            Changed(ChangedTarget.Event, ChangedType.Added, "", "", "", node.Text);
                            //Changed(ChangedTarget.State, ChangedType.Added, "", stateNode.State);
                        }
                    }

                }
                else if (e.GoObject is GoLabeledLink)
                {
                    if (isChangeable)
                    {
                        GoLabeledLink link = (GoLabeledLink)e.GoObject;
                        GoBasicNode fromNode = (GoBasicNode)link.FromNode;
                        GoBasicNode toNode = (GoBasicNode)link.ToNode;

                        Changed(ChangedTarget.SchedulingEdge, ChangedType.Added, "", "", "", fromNode.Text + "->" + toNode.Text);
                    }
                }
                UpdateHighlighting();
            }
            else if (e.Hint == GoLayer.RemovedObject)
            {
                if (e.GoObject is ScheduleNode)
                {
                    if (isChangeable)
                    {
                        ScheduleNode node = (ScheduleNode)e.GoObject;
                        Changed(ChangedTarget.Schedule, ChangedType.Deleted, "", "", node.ScheduleName, "");
                    }
                }
                else if (e.GoObject is EntityQueueNode)
                {
                    if (isChangeable)
                    {
                        EntityQueueNode node = (EntityQueueNode)e.GoObject;
                        Changed(ChangedTarget.EntityQueue, ChangedType.Deleted, "", "", node.EntityQueueName, "");
                    }
                }
                else if (e.GoObject is GoNode)
                {
                    if (isChangeable)
                    {
                        GoBasicNode node = (GoBasicNode)e.GoObject;
                        Changed(ChangedTarget.Event, ChangedType.Deleted, "", "", node.Text, "");
                    }
                }
                else if (e.GoObject is GoLabeledLink)
                {
                    if (isChangeable)
                    {
                        GoLabeledLink link = (GoLabeledLink)e.GoObject;
                        GoBasicNode fromNode = (GoBasicNode)link.FromNode;
                        GoBasicNode toNode = (GoBasicNode)link.ToNode;

                        Changed(ChangedTarget.SchedulingEdge, ChangedType.Deleted, "", "", fromNode.Text + "->" + toNode.Text, "");
                    }
                }

            }
            else if (e.Hint == GoLayer.ChangedObject)
            {
                if (e.GoObject is ScheduleNode)
                {
                    if (isChangeable)
                    {
                        if (e.SubHint == 1501 || (e.OldValue != null && e.NewValue != null))
                            Changed(ChangedTarget.Schedule, ChangedType.Modified, "", "", e.OldValue.ToString(), e.NewValue.ToString());
                    }
                }
                else if (e.GoObject is EntityQueueNode)
                {
                    if (isChangeable)
                    {
                        if (e.SubHint == 1501 || (e.OldValue != null && e.NewValue != null))
                            Changed(ChangedTarget.EntityQueue, ChangedType.Modified, "", "", e.OldValue.ToString(), e.NewValue.ToString());
                    }
                }
                else if (e.GoObject is GoBasicNode)
                {
                    if (isChangeable)
                    {
                        if (e.SubHint == 1501 || (e.OldValue != null && e.NewValue != null))
                            Changed(ChangedTarget.Event, ChangedType.Modified, "", "", e.OldValue.ToString(), e.NewValue.ToString());
                    }

                    //if (e.GoObject.ParentNode != null && e.GoObject.ParentNode is GoBasicNode) { }
                }
                else if (e.GoObject is GoText)
                {
                    if (isChangeable)
                    {
                        if (e.GoObject.ParentNode is GoBasicNode)
                        {
                            if (e.SubHint == 1501 || (e.OldValue != null && e.NewValue != null))
                                Changed(ChangedTarget.Event, ChangedType.Modified, e.OldValue.ToString(), "NAME", e.OldValue.ToString(), e.NewValue.ToString());
                        }
                    }

                }
                else if (e.GoObject is GoLink)
                {
                    if (e.SubHint == 1101)
                    {
                        ObjectSchedulingLink changedEdge = (ObjectSchedulingLink)e.GoObject.Parent;

                        string fromEventVertex = string.Empty;
                        string toEventVertex = string.Empty;

                        GoBasicNode fromNode = (GoBasicNode)changedEdge.FromNode;
                        GoBasicNode toNode = (GoBasicNode)changedEdge.ToNode;
                        fromEventVertex = fromNode.Text;
                        toEventVertex = toNode.Text;
                        if (isChangeable)
                        {
                            if (changedEdge.Pen.DashStyle == System.Drawing.Drawing2D.DashStyle.Solid)
                                Changed(ChangedTarget.SchedulingEdgeType, ChangedType.Modified, "", "", "scheduling", fromEventVertex + "->" + toEventVertex);
                            //Changed("edgetype", "scheduling", fromEventVertex, toEventVertex);
                            else
                                Changed(ChangedTarget.SchedulingEdgeType, ChangedType.Modified, "", "", "canceling", fromEventVertex + "->" + toEventVertex);
                            //Changed("edgetype",  "canceling", fromEventVertex, toEventVertex);
                        }
                    }
                    else if (e.SubHint == 1303)
                    {
                        ObjectSchedulingLink changedEdge = (ObjectSchedulingLink)e.GoObject.Parent;

                        if (e.OldValue is GoPort)
                        {
                            GoPort oldPort = (GoPort)e.OldValue;
                            /*
                            string eventName = ((GoBasicNode)oldPort.Node).Text;
                            oldEventVerex = eventName;

                            if (oldPort.PartID.Equals(lastFromPort.PartID))
                                isOldEventVertexFrom = true;
                            else
                                isOldEventVertexFrom = false;
                            //NewValue: Northwoods.Go.GoToolLinking.GoTemporaryPort
                            */
                        }
                        if (e.NewValue is GoPort)
                        {
                            //OldValue: Northwoods.Go.GoToolLinking.GoTemporaryPort
                            GoPort newPort = (GoPort)e.NewValue;
                            if (newPort.Node != null)
                            {
                                string newEventName = ((GoBasicNode)newPort.Node).Text;

                                string fromEventVertex = ((GoBasicNode)changedEdge.FromPort.Node).Text;
                                string toEventVertex = ((GoBasicNode)changedEdge.ToPort.Node).Text;

                                Changed(ChangedTarget.SchedulingEdge, ChangedType.Modified, "", "", lastFromEventVertex + "->" + lastToEventVertex, fromEventVertex + "->" + toEventVertex);
                                /*
                                if (isOldEventVertexFrom)
                                    Changed(ChangedTarget.SchedulingEdge, ChangedType.Modified, oldEventVerex + "->" + toEventVertex, fromEventVertex + "->" + toEventVertex);
                                else
                                    Changed(ChangedTarget.SchedulingEdge, ChangedType.Modified, fromEventVertex + "->" + oldEventVerex, fromEventVertex + "->" + toEventVertex);
                                */
                            }
                        }
                    }
                    else
                    {
                        ObjectSchedulingLink changedEdge = (ObjectSchedulingLink)e.GoObject.Parent;

                        //System.Diagnostics.Debug.WriteLine("---------");
                        //System.Diagnostics.Debug.WriteLine("e.SubHint: " + e.SubHint);
                        //if (e.OldValue != null)
                        //    System.Diagnostics.Debug.WriteLine("e.OldValue:" + e.OldValue.ToString());
                        //if (e.NewValue != null)
                        //    System.Diagnostics.Debug.WriteLine("e.NewValue:" + e.NewValue.ToString());
                        //if (e.PresentationName != null)
                        //    System.Diagnostics.Debug.WriteLine("e.PresentationName:" + e.PresentationName);
                    }
                }
            }

        }

        private bool isChangeable
        {
            get { return !isLoading && (Changed.GetInvocationList().Length > 0); }
        }

        private void OnViewScaleChanged(double scale)
        {
            tscbZoom.Text = Math.Round(scale * 100, 0).ToString() + "%";
        }

        private void OnViewSelection(object sender, EventArgs e)
        {
            GoView view = (GoView)sender;
            if (myPrimary != view.Selection.Primary)
            {
                UpdateHighlighting();
            }
        }

        private void OnPropertyChanged(object target, string propertyName, object oldPropertyValue, object newPropertyValue)
        {
            if (Changed != null && Changed.GetInvocationList().Length > 0)
            {
                ChangedTarget targetType = ChangedTarget.Event;
                if (target is EventVertexNode)
                {
                    targetType = ChangedTarget.Event;
                    Changed(targetType, ChangedType.Modified, ((EventVertexNode)target).EventName, propertyName, oldPropertyValue, newPropertyValue);
                }
                else if (target is ScheduleNode)
                {
                    targetType = ChangedTarget.Schedule;
                    Changed(targetType, ChangedType.Modified, "", "", oldPropertyValue, newPropertyValue);
                }

            }
        }
        #endregion

        #region Event Handlers for Toolbars - Drawing Components
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            tsbEventObjectNode.Checked = !tsbEventObjectNode.Checked;

            if (tsbEventObjectNode.Checked)
            {
                _View.InsertionMode = InsertionMode.EventVertex;
                _View.AllowLink = false;

                //tsbAddLabel.Checked = false;
                //tsbAddText.Checked = false;
                tsbSchedulingLink.Checked = false;
                tsbSchedule.Checked = false;
                tsbEntityQueue.Checked = false;
            }
            else
                _View.InsertionMode = InsertionMode.None;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            tsbSchedulingLink.Checked = !tsbSchedulingLink.Checked;

            if (tsbSchedulingLink.Checked)
            {
                _View.InsertionMode = InsertionMode.SchedulingEdge;
                _View.AllowLink = true;

                tsbEventObjectNode.Checked = false;
                tsbSchedule.Checked = false;
                tsbEntityQueue.Checked = false;
            }
            else
            {
                _View.InsertionMode = InsertionMode.None;
                _View.AllowLink = false;
            }
        }

        private void tsbSchedule_Click(object sender, EventArgs e)
        {
            tsbSchedule.Checked = !tsbSchedule.Checked;

            if (tsbSchedule.Checked)
            {
                _View.InsertionMode = InsertionMode.Schedule;
                _View.AllowLink = false;

                //tsbAddLabel.Checked = false;
                //tsbAddText.Checked = false;
                tsbSchedulingLink.Checked = false;
                tsbEventObjectNode.Checked = false;
                tsbEntityQueue.Checked = false;
            }
            else
                _View.InsertionMode = InsertionMode.None;
        }

        private void tsbEntityQueue_Click(object sender, EventArgs e)
        {
            tsbEntityQueue.Checked = !tsbEntityQueue.Checked;

            if (tsbEntityQueue.Checked)
            {
                _View.InsertionMode = InsertionMode.EntityQueue;
                _View.AllowLink = false;

                tsbSchedulingLink.Checked = false;
                tsbEventObjectNode.Checked = false;
                tsbSchedule.Checked = false;
            }
            else
                _View.InsertionMode = InsertionMode.None;

        }
        #endregion

        #region Event Handlers for Toolbar Menu - Alignments
        private void tsbLeft_Click(object sender, EventArgs e)
        {
            AlignLeftSides();
        }

        private void tsbCenter_Click(object sender, EventArgs e)
        {
            AlignHorizontalCenters();
        }

        private void tsbRight_Click(object sender, EventArgs e)
        {
            AlignRightSides();
        }

        private void tsbTop_Click(object sender, EventArgs e)
        {
            AlignTops();
        }

        private void tsbMiddle_Click(object sender, EventArgs e)
        {
            AlignVerticalCenters();
        }

        private void tsbBottom_Click(object sender, EventArgs e)
        {
            AlignBottoms();
        }
        #endregion

        #region Event Handlers for Toolstrip Menu - Zoom Control
        private void tsbGrid_Click(object sender, EventArgs e)
        {
            tsbGrid.Checked = !tsbGrid.Checked;
            _View.Grid.Visible = tsbGrid.Checked;
        }

        private void tsbZoomIn_Click(object sender, EventArgs e)
        {
            ZoomIn();
        }

        private void tsbZoomOut_Click(object sender, EventArgs e)
        {
            ZoomOut();
        }

        private void tsbZoomFit_Click(object sender, EventArgs e)
        {
            ZoomToFit();
        }

        private void tscbZoom_SelectedIndexChanged(object sender, EventArgs e)
        {
            string zoomScale = tscbZoom.Text;

            Zoom(zoomScale);
        }
        #endregion
        /*
        private void OnViewScaleChanged(double scale)
        {
            tscbZoom.Text = Math.Round(scale * 100, 0).ToString() + "%";
        } 
        */

        #region Zoom Control Methods
        public void Zoom(string zoomScale)
        {
            float scale = 1.0f;
            if (zoomScale.Contains("%"))
                zoomScale = zoomScale.Substring(0, zoomScale.Length - 1);
            scale = float.Parse(zoomScale) / 100;

            _View.ZoomHandler.Zoom(scale);
        }

        public void SetZoomScale(float scale)
        {
            tscbZoom.Text = Math.Round(scale * 100, 0).ToString() + "%";
        }

        public void ZoomIn()
        {
            _View.ZoomHandler.ZoomIn();

            tscbZoom.Text = Math.Round(_View.DocScale * 100, 0).ToString() + "%";
        }

        public void ZoomToFit()
        {
            _View.ZoomHandler.ZoomToFit();
            tscbZoom.Text = Math.Round(_View.DocScale * 100, 0).ToString() + "%";
        }

        public void ZoomOut()
        {
            _View.ZoomHandler.ZoomOut();
            tscbZoom.Text = Math.Round(_View.DocScale * 100, 0).ToString() + "%";
        }

        #endregion

        #region Alignment Methods

        public void AlignLeftSides()
        {
            _View.AlignLeftSides();
        }

        public void AlignHorizontalCenters()
        {
            _View.AlignHorizontalCenters();
        }

        public void AlignRightSides()
        {
            _View.AlignRightSides();
        }

        public void AlignTops()
        {
            _View.AlignTops();
        }

        public void AlignVerticalCenters()
        {
            _View.AlignVerticalCenters();
        }

        public void AlignBottoms()
        {
            _View.AlignBottoms();
        }
        #endregion

        #region Event Handlers for Form Events
        private void EventGraphDiagramWindow_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                tsbEventObjectNode.Checked = false;
                tsbSchedulingLink.Checked = false;

                _View.AllowLink = false;
                _View.InsertionMode = InsertionMode.None;
            }
            else if (e.KeyCode == Keys.Add && e.Control)
            {
                ZoomIn();
            }
            else if (e.KeyCode == Keys.Subtract && e.Control)
            {
                ZoomOut();
            }
            else if (e.KeyCode == Keys.OemMinus && e.Control)
            {
                ZoomOut();
            }
            else if (e.KeyCode == Keys.Oemplus && e.Control)
            {
                ZoomIn();
            }
        }

        #endregion

        #region Methods for Highlights
        private List<GoObject> mySelection = null;
        private GoObject myPrimary = null;
        private void UpdateHighlighting()
        {
            if (myPrimary != null)
            {
                //disableHighlight(myPrimary);
                foreach (GoObject obj in mySelection)
                    disableHighlight(obj);
                //highlight(myPrimary, Color.Black, 1);
            }

            myPrimary = _View.Selection.Primary;
            mySelection = _View.Selection.ToList<GoObject>();
            foreach (GoObject obj in mySelection)
                enableHighlight(obj);
        }

        private void enableHighlight(GoObject obj)
        {
            highlight(obj, Color.Red, 2);
        }


        private void disableHighlight(GoObject obj)
        {
            /*
            if (obj is Node)
            {
                Node n = (Node)obj;

                n.BorderPen = new Pen(Color.Black, 1);
                //n.Pen = new Pen(Color.Black, 1);
            }
            else
                highlight(obj, Color.Black, 1);
             */
        }

        private void highlight(GoObject obj, Color c, float w)
        {
            /*
            if (obj is Node)
            {
                Node n = (Node)obj;
                n.BorderPen = new Pen(c, w);
                //n.Pen = new Pen(c, w);

            }
            else if (obj is ObjectSchedulingLink)
            {
                ObjectSchedulingLink l = (ObjectSchedulingLink)obj;
                l.Highlight = true;
                l.HighlightPen = new Pen(c, w);
            }
             */
        }
        #endregion

        private bool isLoading = false;
        public void Update(OOEGEventObjectModel eoModel)
        {
            isLoading = true;
            //Event Vertice
            foreach (OOEGEventTransition et in eoModel.EventTransitions)
            {
                EventVertexNode node = (EventVertexNode)_View.Doc.InsertEventVertexNode(et.Event, et.InitialEvent);
                node.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
            }

            //Edge
            foreach (OOEGEventTransition et in eoModel.EventTransitions)
            {
                foreach (OOEGEdgeTransition edge in et.Edges)
                {
                    _View.Doc.InsertEdge(et.Event, edge);
                }
            }

            //Schedule 
            foreach (OOMMSchedule s in eoModel.Schedules)
            {
                ScheduleNode node = _View.Doc.InsertScheduleNode(s);
                node.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
            }

            //Entity Queue
            foreach (OOMMEntityQueue q in eoModel.EntityQueues)
            {
                EntityQueueNode node = _View.Doc.InsertEntityQueueNode(q);
                node.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
            }

            isLoading = false;
        }

        private void removeEntityQueueNode(string name)
        {
            EntityQueueNode node = _View.Doc.FindEntityQueueNode(name);
            if (node != null)
                node.Remove();
        }

        private void addEntityQueueNode(string name)
        {
            OOMMEntityQueue queue = new OOMMEntityQueue(name);
            queue.X = 100;
            queue.Y = 100;
            _View.Doc.InsertEntityQueueNode(queue);
        }

        public void OnSVChanged(//ChangedTarget target, ChangedType action, string targetName, string propertyName, object before, object after)
            ChangedTarget target, ChangedType action, object before, object after)
        {
            if (target ==  ChangedTarget.StateVariable)
            {
                if (action == ChangedType.Modified)
                {
                    OOEGStateVariable oldValue = (OOEGStateVariable)before;
                    OOEGStateVariable newValue = (OOEGStateVariable)after;
                    if (oldValue.Name != newValue.Name)
                    {
                        EntityQueueNode node = _View.Doc.FindEntityQueueNode(oldValue.Name);
                        if (node != null)
                        {
                            node.EntityQueueName = newValue.Name;
                        }
                    }
                    else if (oldValue.ValueType != newValue.ValueType)
                    {
                        if (oldValue.ValueType == OOMMStateVariableHelper.ENTITYQUEUE)
                        {
                            removeEntityQueueNode(oldValue.Name);
                        }
                        else if (newValue.ValueType == OOMMStateVariableHelper.ENTITYQUEUE)
                        {
                            addEntityQueueNode(newValue.Name);
                        }
                    }
               }
                else if (action == ChangedType.Added)
                {
                    OOEGStateVariable newValue = (OOEGStateVariable)after;
                    if (newValue.ValueType != OOMMStateVariableHelper.ENTITYQUEUE)
                        return;

                    OOMMEntityQueue queue = new OOMMEntityQueue(newValue.Name);
                    queue.X = 100;
                    queue.Y = 100;
                    _View.Doc.InsertEntityQueueNode(queue);
                } else if (action == ChangedType.Deleted)
                {
                    OOEGStateVariable oldValue = (OOEGStateVariable)before;
                    if (oldValue.ValueType != OOMMStateVariableHelper.ENTITYQUEUE)
                        return;

                    EntityQueueNode node = _View.Doc.FindEntityQueueNode(oldValue.Name);
                    if (node != null)
                        node.Remove();
                }
            }

        }

        public void OnETTChanged(string target, string action, string before, string after)
        {
            if (target == "eventvertex")
            {
                if (action == "changed")
                {
                    isLoading = true;
                    foreach (GoObject obj in _View.Doc)
                    {
                        if (obj is GoBasicNode)
                        {
                            GoBasicNode node = (GoBasicNode)obj;

                            if (node.Text == before)
                            {
                                node.Text = after;
                                break;
                            }
                        }
                    }
                    isLoading = false;
                }
                else if (action == "added")
                {
                    isLoading = true;
                    PointF pf = new PointF(100, 100);
                    foreach (GoObject obj in _View.Doc)
                    {
                        if (obj is GoBasicNode)
                        {
                            GoBasicNode node = (GoBasicNode)obj;

                            pf = node.Center;
                        }
                    }

                    pf.X += 50;
                    pf.Y += 50;
                    EventVertexNode newNode = (EventVertexNode)_View.Doc.InsertEventVertexNode(pf.X, pf.Y, after);
                    isLoading = false;

                }
                else if (action == "deleted")
                {
                    isLoading = true;
                    EventVertexNode deletedNode = (EventVertexNode)_View.Doc.FindNode(before);
                    _View.Doc.Remove(deletedNode.Presentation);
                    isLoading = false;
                }

            }
            else if (target == "nextevent")
            {
                if (action == "changed")
                {
                    isLoading = true;
                    string[] beforeEventPairs = before.Split(new string[] { "->" }, StringSplitOptions.RemoveEmptyEntries);
                    string[] afterEventPairs = after.Split(new string[] { "->" }, StringSplitOptions.RemoveEmptyEntries);

                    //기존 edge 삭제
                    if (beforeEventPairs.Length == 2)
                        _View.Doc.RemoveEdge(beforeEventPairs[0], beforeEventPairs[1]);

                    //다음 edge 추가
                    if (afterEventPairs.Length == 2)
                        _View.Doc.InsertEdge(afterEventPairs[0], afterEventPairs[1]);

                    //chained change가 일어나지 않도록 할 것!!!
                    isLoading = false;

                }
            }
            else if (target == "edgetype")
            {
                if (action == "changed")
                {
                    string[] eventPairs = before.Split(new string[] { "->" }, StringSplitOptions.RemoveEmptyEntries);
                    bool canceled = bool.Parse(after);

                    _View.Doc.ChangeEdgeType(eventPairs[0], eventPairs[1], canceled);
                }
            }
            else if (target == "initialevent")
            {
                if (action == "changed")
                {
                    bool initialEvent = bool.Parse(after);
                    Node node = (Node)_View.Doc.FindNode(before);
                    if (initialEvent)
                        ((EventVertexNode)node).setInitial();
                    else
                        ((EventVertexNode)node).setRegular();
                }
            }
        }

        private void tsbAutoConnect_Click(object sender, EventArgs e)
        {
            tsbAutoConnect.Checked = !tsbAutoConnect.Checked;

            _View.AutoConnect = tsbAutoConnect.Checked;

            if (tsbAutoConnect.Checked)
            {
                _View.InsertionMode = InsertionMode.SchedulingEdge;
                //tsbSchedulingLink.Checked = false;
            }
            else
                _View.InsertionMode = InsertionMode.None;
        }


        public Node FindNode(string eventName)
        {
            return _View.FindNode(eventName);
        }

        private void tsbLayout_Click(object sender, EventArgs e)
        {
            //Microsoft.Msagl.Core.Layout.GeometryGraph graph = new GeometryGraph();

            GeometryGraph graph = new GeometryGraph();

            double w = 30;
            double h = 20;

            Dictionary<string, GoBasicNode> goNodeList =
                new Dictionary<string, GoBasicNode>();

            Dictionary<string, Microsoft.Msagl.Core.Layout.Node> graphNodes =
                new Dictionary<string, Microsoft.Msagl.Core.Layout.Node>();
            foreach (GoObject obj in _View.Doc)
            {
                if (obj is GoBasicNode)
                {
                    GoBasicNode mpNode = (GoBasicNode)obj;
                    Microsoft.Msagl.Core.Layout.Node gNode =
                        new Microsoft.Msagl.Core.Layout.Node(
                            new Ellipse(w, h, new Microsoft.Msagl.Core.Geometry.Point(mpNode.Center.X, mpNode.Center.Y)), mpNode.Text);

                    graph.Nodes.Add(gNode);
                    graphNodes.Add(mpNode.Text, gNode);
                    goNodeList.Add(mpNode.Text, mpNode);
                }
            }

            foreach (GoObject obj in _View.Doc)
            {
                if (obj is GoLabeledLink)
                {
                    GoLabeledLink link = (GoLabeledLink)obj;
                    GoBasicNode fromNode = (GoBasicNode)link.FromNode;
                    GoBasicNode toNode = (GoBasicNode)link.ToNode;

                    Microsoft.Msagl.Core.Layout.Node fromGraphNode = graphNodes[fromNode.Text];
                    Microsoft.Msagl.Core.Layout.Node toGraphNode = graphNodes[toNode.Text];

                    Edge edge = new Edge(fromGraphNode, toGraphNode) { Length = 1 };
                    graph.Edges.Add(edge);
                }
            }

            var settings = new Microsoft.Msagl.Layout.MDS.MdsLayoutSettings();
            LayoutHelpers.CalculateLayout(graph, settings, null);

            foreach (Microsoft.Msagl.Core.Layout.Node node in graph.Nodes)
            {
                string nodeName = (string)node.UserData;
                GoBasicNode goNode = goNodeList[nodeName];
                goNode.Center = new PointF((float)node.Center.X, (float)node.Center.Y);
            }

            _View.ZoomHandler.ZoomToFit();
        }

        
    }
}
