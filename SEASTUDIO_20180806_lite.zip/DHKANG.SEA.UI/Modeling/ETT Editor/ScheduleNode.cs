﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Northwoods.Go;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.Foundation.DataCollection;
using DHKANG.SEA.UI.OutputView;

namespace DHKANG.SEA.UI.ETTEditor
{
    public class ScheduleNode: GoSimpleNode 
    {
        #region Member Variables
        private Guid _NodeID;
        private string _Name;
        private ScheduleType _Type;
        private ScheduleTimeUnit _TimeUnit;
        private List<OOMMScheduleValue> _Values;
        private string _Description;
        private GoText _Label;
        #endregion

        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Properties
        public string ScheduleName 
        {
            get { return _Name; }
            set {
                string oldValue = _Name;
                _Name = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "ScheduleName", oldValue, value);
            }
        }
        
        public Guid NodeID 
        {
            get { return _NodeID; }
            set {
                Guid oldValue = _NodeID;
                _NodeID = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "NodeID", oldValue, value);
            }
        }

        public ScheduleType Type 
        {
            get { return _Type; }
            set {
                ScheduleType oldValue = _Type;
                _Type = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Type", oldValue, value);
            }
        }

        public ScheduleTimeUnit TimeUnit 
        {
            get { return _TimeUnit; }
            set
            {
                ScheduleTimeUnit oldValue = _TimeUnit;
                _TimeUnit = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "TimeUnit", oldValue, value);
            }
        }

        public List<OOMMScheduleValue> Values 
        {
            get { return _Values; }
            set {
                List<OOMMScheduleValue> oldValue = _Values;
                _Values = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Values", oldValue, value);
            }
        }

        public string Description
        {
            get { return _Description; }
            set {
                string oldValue = _Description;
                _Description = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Description", oldValue, value);
            }
        }
        #endregion

        #region Constructors
        public ScheduleNode(string name)
        {
            _Name = name;
            _Type = ScheduleType.Integer;
            _TimeUnit = ScheduleTimeUnit.Seconds;
            _Values = new List<OOMMScheduleValue>();

            _Label = CreateLabel(name);
            _Label.Font = new Font("Calibri", 11, FontStyle.Bold);
        }

        public ScheduleNode(string name, float x, float y) : this(name)
        {
            _NodeID = Guid.NewGuid();
            initialize(x, y);
        }

        public ScheduleNode(Guid nodeid, string name, ScheduleType type, ScheduleTimeUnit tu, string description, List<OOMMScheduleValue> values, float x, float y)
            : this(name)
        {
            _NodeID = nodeid;
            _Type = type;
            _TimeUnit = tu;
            _Values = values;
            _Description = description;

            initialize(x, y);
        }

        private void initialize(float x, float y)
        {
            this.Initialize(null, null, _Name);
            this.Figure = GoFigure.BpmnEventTimer;
            this.Icon.Size = new SizeF(15, 15);
            this.Icon.Resizable = false;
            this.Shape.FillShapeGradient(Color.CornflowerBlue);
            this.Orientation = Orientation.Vertical;
            this.InPort.Visible = false;
            this.OutPort.Visible = false;
            this.Editable = false;
            this.Left = x;
            this.Top = y;

            this.UpdateText();
        }
        #endregion

        #region Methods
        public void UpdateText()
        {
            this.Label.Text = "  " + _Name;
        }

        public void Reset()
        {
            this.Label.Text = "  " + _Name;
        }

        public override string GetToolTip(GoView view)
        {
            string tooltip = _Name;

            if (!string.IsNullOrEmpty(_Description))
                tooltip += " : " + _Description;
            return tooltip;
        }
        #endregion
    }
}
