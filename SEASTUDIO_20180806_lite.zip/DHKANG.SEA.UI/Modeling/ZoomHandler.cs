﻿using Northwoods.Go;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.UI.Modeling
{
    public class ZoomHandler
    {
        private GoView _View;

        private PointF myOriginalDocPosition = new PointF();
        private float myOriginalDocScale = 1.0f;
        private bool myOriginalScale = true;

        public ZoomHandler(GoView view)
        {
            _View = view;
        }

        public virtual void ZoomIn()
        {
            myOriginalScale = true;
            float newscale = (float)(Math.Round(_View.DocScale / 0.9f * 100) / 100);
            _View.DocScale = newscale;
        }

        public virtual void ZoomOut()
        {
            myOriginalScale = true;
            float newscale = (float)(Math.Round(_View.DocScale * 0.9f * 100) / 100);
            _View.DocScale = newscale;
        }

        public virtual void ZoomNormal()
        {
            myOriginalScale = true;
            _View.DocScale = 1;
        }

        public virtual void Zoom(float scale)
        {
            myOriginalScale = true;
            _View.DocScale = scale;
        }

        public virtual void ZoomToFit()
        {
            if (myOriginalScale)
            {
                myOriginalDocPosition = _View.DocPosition;
                myOriginalDocScale = _View.DocScale;
                _View.RescaleToFit();
            }
            else
            {
                _View.DocPosition = myOriginalDocPosition;
                _View.DocScale = myOriginalDocScale;
            }
            myOriginalScale = !myOriginalScale;
        }
    }
}
