﻿using DHKANG.SEA.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DHKANG.SEA.UI.Modeling
{
    public static class EntityManager
    {
        #region Member Variables
        private static Dictionary<Guid, List<OOMMEntity>> _Entities = new Dictionary<Guid, List<OOMMEntity>>();
        #endregion

        #region Properties
        #endregion

        #region Methods
        public static void SetEntities(Guid projectid, List<OOMMEntity> entities)
        {
            if (entities == null)
            {
                entities = new List<OOMMEntity>();
            }

            if (_Entities.ContainsKey(projectid))
                _Entities[projectid] = entities;
            else
                _Entities.Add(projectid, entities);
        }

        public static List<OOMMEntity> GetEntities(Guid projectid)
        {
            List<OOMMEntity> rslt = new List<OOMMEntity>();
            if (_Entities.ContainsKey(projectid))
                rslt = _Entities[projectid];

            return rslt;
        }

        public static void Clear(Guid project)
        {
            List<OOMMEntity> entities = _Entities[project];
            if (entities != null)
            {
                entities.Clear();
                _Entities[project] = entities;
            }
        }

        public static void NewEntity(Guid project)
        {
            List<OOMMEntity> entities = null;
            if (_Entities.ContainsKey(project))
            {
                entities = _Entities[project];
            }else
            {
                entities = new List<OOMMEntity>();
            }

            string name = getNextEntityName(project);
            OOMMEntity entity = new OOMMEntity(name);

            entities.Add(entity);

            _Entities[project] = entities;
        }

        private static string getNextEntityName(Guid project)
        {
            string rslt = "Entity 1";

            string expr = @"Entity[\s]*([0-9\-]*)";

            int nextNumber = 0;
            List<OOMMEntity> entities = _Entities[project];
            foreach (OOMMEntity entity in entities)
            {
                int number = 0;
                if (Regex.IsMatch(entity.Name, expr))
                {
                    Match m = Regex.Match(entity.Name, @"\d+");
                    if (int.TryParse(m.Value, out number))
                    {
                        if (number > nextNumber)
                            nextNumber = number;
                    }
                }
            }

            nextNumber++;
            rslt = "Entity " + nextNumber;

            return rslt;
        }

        public static OOMMEntity FindEntity(Guid project, string name)
        {
            OOMMEntity rslt = null;

            List<OOMMEntity> entities = _Entities[project];
            if (entities != null)
                rslt = entities.Find(e => e.Name.Equals(name));
            return rslt;
        }

        public static void DeleteEntity(Guid project, string name)
        {
            OOMMEntity entity = FindEntity(project, name);
            if (entity != null)
            {
                List<OOMMEntity> entities = _Entities[project];
                entities.Remove(entity);
                _Entities[project] = entities;
            }
        }
        #endregion
    }
}
