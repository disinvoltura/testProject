﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DHKANG.SEA.UI.ATTEditor
{
    public class ActionEditorDialog : SourceGrid.Cells.Editors.TextBoxButton
    {
        public ActionEditorDialog()
            : base(typeof(string))
        {
            this.Control.TextBox.Multiline = true;
            Control.DialogOpen += new EventHandler(Control_DialogOpen);
        }

        void Control_DialogOpen(object sender, EventArgs e)
        {
            string action = (string)Control.Value;

            ActionEditor editor = new ActionEditor(action);
            DialogResult rslt = editor.ShowDialog();
            if (rslt == DialogResult.OK)
            {
                    
                Control.Value = editor.Action;
            }
        }
    }
}
