﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DHKANG.SEA.UI.ATTEditor
{
    public partial class ActionEditor : Form
    {
        public string Action
        {
            get { return this.tecAction.Text; }
        }

        public int NumberOfLines
        {
            get { return tecAction.Document.TotalNumberOfLines; }
        }
        public ActionEditor(string action)
        {
            InitializeComponent();

            tecAction.Text = action;
        }

        private void ActionEditor_FormClosing(object sender, FormClosingEventArgs e)
        {
            //base.OnFormClosing(e);
            System.Diagnostics.Trace.WriteLine(tecAction.Document.TotalNumberOfLines);
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }
    }
}
