﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DHKANG.SEA.UI.ATTEditor
{
    public partial class VariableValueDialog : Form
    {
        private int _Row;
        private int _Col;
        private string _ValueType;

        public string InitialValues
        {
            get
            {
                string rslt = string.Empty;

                for (int k = 1; k <= _Row; k++)
                {
                    rslt += "{";
                    for (int p = 1; p <= _Col; p++)
                    {
                        if (grid1[k, p].Value == null)
                        {
                            if (_ValueType.Equals("int"))
                                rslt += "0";
                            else if(_ValueType.Equals("float"))
                                rslt += "0.0f";
                            else if (_ValueType.Equals("double"))
                                rslt += "0.0";
                            else if (_ValueType.Equals("string"))
                                rslt += "";
                        }
                        else
                            rslt += grid1[k, p].Value.ToString();

                        if (p < _Col)
                            rslt += ",";
                    }
                    if (k < _Row)
                        rslt += "};";
                    else
                        rslt += "}";
                }


                return rslt;
            }
        }

        public VariableValueDialog(int row, int col, string valueType)
        {
            _Row = row;
            _Col = col;
            _ValueType = valueType;

            InitializeComponent();

            drawHeaders();
        }

        public VariableValueDialog(int row, int col, string valueType, string values)
            : this(row, col, valueType)
        {
            loadValues(values);
        }

        private void drawHeaders()
        {
            //SourceGrid.Cells.Views.Cell titleModel = new SourceGrid.Cells.Views.Cell();
            //titleModel.BackColor = Color.SteelBlue;
            //titleModel.ForeColor = Color.White;
            //titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Snow;
            backHeader.Border = DevAge.Drawing.RectangleBorder.NoBorder;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            grid1.BorderStyle = BorderStyle.FixedSingle;
            grid1.Redim(_Row + 1, _Col + 1);
            grid1.FixedRows = 1;
            grid1.FixedColumns = 1;
            grid1.Font = new Font("Calibe", 10);
            //1st Header Row
            grid1.Rows.Insert(0);
            SourceGrid.Cells.ColumnHeader firstHeader = new SourceGrid.Cells.ColumnHeader("");
            firstHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            firstHeader.AutomaticSortEnabled = false;
            //firstHeader.View.BackColor = Color.Gray;
            grid1[0, 0] = firstHeader;

            for (int k = 0; k < _Col; k++)
            {
                SourceGrid.Cells.ColumnHeader kHeader = new SourceGrid.Cells.ColumnHeader(k.ToString());
                kHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
                kHeader.AutomaticSortEnabled = false;
                //kHeader.View.BackColor = Color.Gray;
                grid1[0, k + 1] = kHeader;                
            }

            for (int k = 1; k <= _Row; k++)
            {
                grid1[k, 0] = new SourceGrid.Cells.RowHeader((k-1).ToString());
                grid1[k, 0].View = titleModel; //
                //grid1[k, 0] = new SourceGrid.Cells.Cell((k-1).ToString(), typeof(string));
                //grid1[k, 0].View.BackColor = Color.Gray;
                for (int p = 1; p <= _Col; p++)
                {
                    if (_ValueType.Equals("int"))
                        grid1[k, p] = new SourceGrid.Cells.Cell("0", typeof(int));
                    else if (_ValueType.Equals("float"))
                        grid1[k, p] = new SourceGrid.Cells.Cell("0.0f", typeof(float));
                    else if (_ValueType.Equals("double"))
                        grid1[k, p] = new SourceGrid.Cells.Cell("0.0", typeof(double));
                    else if (_ValueType.Equals("string"))
                        grid1[k, p] = new SourceGrid.Cells.Cell("", typeof(string));
                    else if (_ValueType.Equals("RandomVariate"))
                        grid1[k, p] = new SourceGrid.Cells.Cell("", typeof(string));
                }
            }
        }

        //private void initializeGridValues()
        //{
        //    for (int k = 0; k < _Row; k++)
        //    {
        //        for (int p = 0; p < _Col; p++)
        //        {
        //            if (_ValueType.Equals("int"))
        //                grid1[k + 1, p + 1].Value = 0;
        //            else if (_ValueType.Equals("float"))
        //                grid1[k + 1, p + 1].Value = 0.0f;
        //            else if (_ValueType.Equals("string"))
        //                grid1[k + 1, p + 1].Value = "";
        //        }
        //    }
        //}
            
        private void loadValues(string values)
        {
            //values: {1}
            //values: {1, 2,3,4, 5}
            //values: {1, 2,3,4, 5}; {1, 2,3,4, 5};

            string[] rows = values.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
            
            //_Row; _Col;

            for (int k = 0; k < rows.Length; k++)
            {
                if (k >= _Row)
                    break;

                string row = rows[k].Replace("{", "").Replace("}", "");
                string[] cells = row.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                for (int p = 0; p < cells.Length; p++)
                {
                    if (p < _Col)
                    {
                        if (_ValueType.Equals("int"))
                        {
                            int val = 0;
                            if (!int.TryParse(cells[p], out val))
                                val = 0;
                            grid1[k + 1, p + 1].Value = val;
                            //grid1[k + 1, p + 1].Value = int.Parse(cells[p]);
                        }
                        else if (_ValueType.Equals("float"))
                        {
                            float val = 0.0f;
                            if (!float.TryParse(cells[p], out val))
                                val = 0.0f;
                            grid1[k + 1, p + 1].Value = val;
                        }
                        else if (_ValueType.Equals("double"))
                        {
                            double val = 0.0;
                            if (!double.TryParse(cells[p], out val))
                                val = 0.0;
                            grid1[k + 1, p + 1].Value = val;
                        }
                        else if (_ValueType.Equals("string"))
                        {
                            grid1[k + 1, p + 1].Value = cells[p];
                        }
                    }
                }
            }
        }
    }
}
