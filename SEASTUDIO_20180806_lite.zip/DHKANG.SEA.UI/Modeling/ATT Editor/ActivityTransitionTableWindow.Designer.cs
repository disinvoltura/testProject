﻿namespace DHKANG.SEA.UI.ATTEditor
{
    partial class ActivityTransitionTableWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ActivityTransitionTableWindow));
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.Table = new SourceGrid.Grid();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbAdd = new System.Windows.Forms.ToolStripButton();
            this.tsbDelete = new System.Windows.Forms.ToolStripButton();
            this.tsbSetEnabledActivity = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbAddAtEnd = new System.Windows.Forms.ToolStripButton();
            this.tsbDelAtEnd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbAutoSizecell = new System.Windows.Forms.ToolStripButton();
            this.tsbSort = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this.Table);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(590, 452);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(590, 477);
            this.toolStripContainer1.TabIndex = 0;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip1);
            // 
            // grid1
            // 
            this.Table.AutoStretchColumnsToFitWidth = true;
            this.Table.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Table.EnableSort = true;
            this.Table.FixedRows = 2;
            this.Table.Location = new System.Drawing.Point(0, 0);
            this.Table.Name = "grid1";
            this.Table.OptimizeMode = SourceGrid.CellOptimizeMode.ForColumns;
            this.Table.SelectionMode = SourceGrid.GridSelectionMode.Cell;
            this.Table.Size = new System.Drawing.Size(590, 452);
            this.Table.TabIndex = 1;
            this.Table.TabStop = true;
            this.Table.ToolTipText = "";
            this.Table.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.grid1_PreviewKeyDown);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbAdd,
            this.tsbDelete,
            this.tsbSetEnabledActivity,
            this.toolStripSeparator1,
            this.tsbAddAtEnd,
            this.tsbDelAtEnd,
            this.toolStripSeparator2,
            this.tsbAutoSizecell,
            this.tsbSort,
            this.toolStripButton1,
            this.toolStripButton2});
            this.toolStrip1.Location = new System.Drawing.Point(3, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(262, 25);
            this.toolStrip1.TabIndex = 1;
            // 
            // tsbAdd
            // 
            this.tsbAdd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAdd.Image = ((System.Drawing.Image)(resources.GetObject("tsbAdd.Image")));
            this.tsbAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAdd.Name = "tsbAdd";
            this.tsbAdd.Size = new System.Drawing.Size(23, 22);
            this.tsbAdd.Text = "Add an Activity";
            this.tsbAdd.Click += new System.EventHandler(this.tsbAdd_Click);
            // 
            // tsbDelete
            // 
            this.tsbDelete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDelete.Enabled = false;
            this.tsbDelete.Image = ((System.Drawing.Image)(resources.GetObject("tsbDelete.Image")));
            this.tsbDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDelete.Name = "tsbDelete";
            this.tsbDelete.Size = new System.Drawing.Size(23, 22);
            this.tsbDelete.Text = "Delete an activity ";
            this.tsbDelete.Click += new System.EventHandler(this.tsbDelete_Click);
            // 
            // tsbSetEnabledActivity
            // 
            this.tsbSetEnabledActivity.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSetEnabledActivity.Enabled = false;
            this.tsbSetEnabledActivity.Image = ((System.Drawing.Image)(resources.GetObject("tsbSetEnabledActivity.Image")));
            this.tsbSetEnabledActivity.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSetEnabledActivity.Name = "tsbSetEnabledActivity";
            this.tsbSetEnabledActivity.Size = new System.Drawing.Size(23, 22);
            this.tsbSetEnabledActivity.Text = "Set Enabled Activity";
            this.tsbSetEnabledActivity.Click += new System.EventHandler(this.tsbSetEnabledActivity_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbAddAtEnd
            // 
            this.tsbAddAtEnd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAddAtEnd.Enabled = false;
            this.tsbAddAtEnd.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddAtEnd.Image")));
            this.tsbAddAtEnd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAddAtEnd.Name = "tsbAddAtEnd";
            this.tsbAddAtEnd.Size = new System.Drawing.Size(23, 22);
            this.tsbAddAtEnd.Text = "Add an arc";
            this.tsbAddAtEnd.Click += new System.EventHandler(this.tsbAddAtEnd_Click);
            // 
            // tsbDelAtEnd
            // 
            this.tsbDelAtEnd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDelAtEnd.Enabled = false;
            this.tsbDelAtEnd.Image = ((System.Drawing.Image)(resources.GetObject("tsbDelAtEnd.Image")));
            this.tsbDelAtEnd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDelAtEnd.Name = "tsbDelAtEnd";
            this.tsbDelAtEnd.Size = new System.Drawing.Size(23, 22);
            this.tsbDelAtEnd.Text = "Delete an arc";
            this.tsbDelAtEnd.Click += new System.EventHandler(this.tsbDelAtEnd_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbAutoSizecell
            // 
            this.tsbAutoSizecell.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAutoSizecell.Image = ((System.Drawing.Image)(resources.GetObject("tsbAutoSizecell.Image")));
            this.tsbAutoSizecell.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAutoSizecell.Name = "tsbAutoSizecell";
            this.tsbAutoSizecell.Size = new System.Drawing.Size(23, 22);
            this.tsbAutoSizecell.Text = "Resize Cells Automatically";
            this.tsbAutoSizecell.Click += new System.EventHandler(this.tsbAutoSizecell_Click);
            // 
            // tsbSort
            // 
            this.tsbSort.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSort.Image = ((System.Drawing.Image)(resources.GetObject("tsbSort.Image")));
            this.tsbSort.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSort.Name = "tsbSort";
            this.tsbSort.Size = new System.Drawing.Size(23, 22);
            this.tsbSort.Text = "Sort";
            this.tsbSort.Click += new System.EventHandler(this.tsbSort_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "Copy to Clipboard";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton2.Text = "toolStripButton2";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // ActivityTransitionTableWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(590, 477);
            this.Controls.Add(this.toolStripContainer1);
            this.Name = "ActivityTransitionTableWindow";
            this.Text = "Activity Transition Table";
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private SourceGrid.Grid Table;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbAdd;
        private System.Windows.Forms.ToolStripButton tsbDelete;
        private System.Windows.Forms.ToolStripButton tsbSetEnabledActivity;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsbAddAtEnd;
        private System.Windows.Forms.ToolStripButton tsbDelAtEnd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton tsbAutoSizecell;
        private System.Windows.Forms.ToolStripButton tsbSort;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
    }
}