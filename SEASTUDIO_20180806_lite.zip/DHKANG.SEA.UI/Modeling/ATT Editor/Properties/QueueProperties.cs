﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.UI.ETTEditor;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model.ActivityObjects;

namespace DHKANG.SEA.UI.ATTEditor.Properties
{
    public partial class QueueProperties : UserControl
    {
        private ActivityObjectModelEditor _Parent;
        private QueueNode _Node;

        private bool isUpdating = false;

        public QueueProperties(ActivityObjectModelEditor parent)
        {
            _Parent = parent;
            InitializeComponent();
        }

        public QueueProperties()
        {
        }

        public void Update(QueueNode node)
        {
            _Node = node;

            showProperties();
        }

        private void showProperties()
        {
            isUpdating = true;

            txtName.Text = _Node.Queue.Name;

            setButtonSelection(btnResource, false);
            setButtonSelection(btnCreaotr, false);
            setButtonSelection(btnEntity, false);

            if (_Node.Queue.Type == OOAGQueueType.Resource)
                setButtonSelection(btnResource, true);
            if (_Node.Queue.Type == OOAGQueueType.Creator)
                setButtonSelection(btnCreaotr, true);
            if (_Node.Queue.Type == OOAGQueueType.Entity)
                setButtonSelection(btnEntity, true);

            if (_Node.Queue.Parameters != null)
                txtParam.Text = _Node.Queue.Parameters;

            if (!string.IsNullOrEmpty(_Node.Queue.Parameters))
            {
                List<string> pmNameList = _Node.Queue.Parameters.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList<string>();
                List<string> svList = new List<string>();
                List<string> pmList = new List<string>();
                foreach (OOAGStateVariable sv in _Parent.ActivityObjectModel.StateVariables)
                {
                    if (!pmNameList.Contains(sv.Name))
                        svList.Add(sv.Name + ": " + sv.ValueType);
                    else
                        pmList.Add(sv.Name + ": " + sv.ValueType);
                }
                lbSV.Items.Clear();
                svList.Sort();
                svList.ForEach(sv => lbSV.Items.Add(sv));

                lvPM.Items.Clear();
                pmList.Sort();
                pmList.ForEach(pm => lvPM.Items.Add(pm));
            }
            else
            {
                List<string> svList = new List<string>();
                foreach (OOAGStateVariable sv in _Parent.ActivityObjectModel.StateVariables)
                {
                    svList.Add(sv.Name + ": " + sv.ValueType);
                }
                lbSV.Items.Clear();
                svList.Sort();
                svList.ForEach(sv => lbSV.Items.Add(sv));
            }

            txtInitialValue.Text = _Node.Queue.InitialValue;

            isUpdating = false;
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            handleNameChanged();
        }

        private void handleNameChanged()
        {
            if (isUpdating)
                return;

            if (_Node.Queue.Name != txtName.Text)
            {
                _Node.QueueName = txtName.Text;
                //_Node.Queue.Name = txtName.Text;
                //_Node.Text = txtName.Text;
            }
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleNameChanged();
            }
        }

        private void handleParametersChanged()
        {
            if (isUpdating)
                return;

            if (_Node.Queue.Parameters != txtParam.Text)
            {
                _Node.Queue.Parameters = txtParam.Text;
            }
        }

        private void txtTimeDelay_Leave(object sender, EventArgs e)
        {
            handleParametersChanged();
        }

        private void txtTimeDelay_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleParametersChanged();
            }
        }

        private void btnInitial_Click(object sender, EventArgs e)
        {
            setButtonSelection(btnResource, false);
            setButtonSelection(btnCreaotr, true);
            setButtonSelection(btnEntity, false);

            _Node.Queue.Type = OOAGQueueType.Creator;            
        }

        private void btnRegular_Click(object sender, EventArgs e)
        {
            setButtonSelection(btnResource, true);
            setButtonSelection(btnCreaotr, false);
            setButtonSelection(btnEntity, false);

            _Node.Queue.Type = OOAGQueueType.Resource;            
        }

        private void btnMirror_Click(object sender, EventArgs e)
        {
            setButtonSelection(btnResource, false);
            setButtonSelection(btnCreaotr, false);
            setButtonSelection(btnEntity, true);

            _Node.Queue.Type = OOAGQueueType.Entity;            
        }

        private void setButtonSelection(Button btn, bool selected)
        {
            if (selected)
            {
                btn.FlatAppearance.BorderColor = Color.DarkGray;
                btn.FlatAppearance.BorderSize = 1;
                btn.Font = new Font(btn.Font.FontFamily, 9, FontStyle.Bold);
                btn.BackColor = Color.DarkGray;
            }
            else
            {
                btn.FlatAppearance.BorderColor = Color.Gray;
                btn.FlatAppearance.BorderSize = 0;
                btn.Font = new Font(btn.Font.FontFamily, 9, FontStyle.Regular);
                btn.BackColor = Color.LightGray;
            }
        }

        //move to SV listbox
        private void button2_Click(object sender, EventArgs e)
        {
            if (lvPM.SelectedIndex < 0)
                return;

            int index = lvPM.SelectedIndex;
            string pm = (string)lvPM.SelectedItem;
            lbSV.Items.Add(pm);
            lvPM.Items.RemoveAt(index);

            buildParameters();
        }

        //move to PM listbox
        private void button1_Click(object sender, EventArgs e)
        {
            if (lbSV.SelectedIndex < 0)
                return;

            int index = lbSV.SelectedIndex;
            string sv = (string)lbSV.SelectedItem;
            lvPM.Items.Add(sv);
            lbSV.Items.RemoveAt(index);

            buildParameters();
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            if (lvPM.SelectedIndex <= 0)
                return;

            int index = lvPM.SelectedIndex;
            string pm = (string)lvPM.SelectedItem;
            lvPM.Items.RemoveAt(index);
            lvPM.Items.Insert(index - 1, pm);

            buildParameters();
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            if (lvPM.SelectedIndex == lvPM.Items.Count - 1)
                return;

            int index = lvPM.SelectedIndex;
            string pm = (string)lvPM.SelectedItem;
            lvPM.Items.Insert(index + 1, pm);
            lvPM.Items.RemoveAt(index);

            buildParameters();
        }

        private void buildParameters()
        {
            string parameters = "";
            for(int i = 0; i < lvPM.Items.Count; i++)
            {
                string itemValue = (string)lvPM.Items[i];
                string pmName = itemValue.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries)[0];

                if (i < lvPM.Items.Count - 1)
                    parameters += pmName + ",";
                else
                    parameters += pmName;
            }
            txtParam.Text = parameters;
        }

        private void txtInitialValue_Leave(object sender, EventArgs e)
        {
            handleInitialValueChanged();
        }

        private void handleInitialValueChanged()
        {
            if (isUpdating)
                return;

            if (_Node.Queue.InitialValue != txtInitialValue.Text)
            {
                _Node.Queue.InitialValue = txtInitialValue.Text;
            }
        }

        private void txtInitialValue_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleInitialValueChanged();
            }
        }
    }
}