﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.UI.ETTEditor;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model.ActivityObjects;

namespace DHKANG.SEA.UI.ATTEditor.Properties
{
    public partial class ArcProperties : UserControl
    {
        private ActivityObjectModelEditor _Parent;
        private Arc _Arc;

        private bool isUpdating = false;

        public ArcProperties(ActivityObjectModelEditor parent)
        {
            _Parent = parent;
            InitializeComponent();
        }

        public void Update(Arc arc)
        {
            _Arc = arc;

            showProperties();
        }

        private void showProperties()
        {
            isUpdating = true;

            txtMultiplicity.Text = _Arc.Multiplicity.ToString();
            txtCondition.Text = _Arc.Condition;

            isUpdating = false;
        }

        private void txtMultiplicity_Leave(object sender, EventArgs e)
        {
            handleMultiplicityChanged();
        }

        private void handleMultiplicityChanged()
        {
            if (isUpdating)
                return;

            int multi = 1;
            if (int.TryParse(txtMultiplicity.Text, out multi))
            {
                _Arc.Multiplicity = multi;
            }
        }

        private void txtMultiplicity_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleMultiplicityChanged();
            }
        }

        private void handleConditionChanged()
        {
            if (isUpdating)
                return;

            if (_Arc.Condition != txtCondition.Text)
            {
                _Arc.Condition = txtCondition.Text;
            }
        }

        private void txtCondition_Leave(object sender, EventArgs e)
        {
            handleConditionChanged();
        }

        private void txtCondition_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleConditionChanged();
            }
        }
    }
}