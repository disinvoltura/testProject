﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using DHKANG.SEA.Model;
using System.Text.RegularExpressions;
using DHKANG.SEA.UI.Modeling;
using DHKANG.SEA.UI.OutputView;
using DHKANG.SEA.UI.ETTEditor.Properties;
using DHKANG.SEA.UI.ATTEditor.Properties;

namespace DHKANG.SEA.UI.ATTEditor
{
    public partial class ATTPropertiesWindow : DockContent
    {
        #region Member Variables
        private ActivityObjectModelEditor _Parent;

        private QueueProperties _QueueProperties;
        private ActivityProperties _ActivityProperties;
        private ArcProperties _ArcProperties;
        #endregion

        #region Properties
        #endregion

        #region Constructors
        public ATTPropertiesWindow(ActivityObjectModelEditor parent)
        {
            InitializeComponent();

            _Parent = parent;

            _QueueProperties = new QueueProperties(_Parent);
            _QueueProperties.Dock = DockStyle.Fill;
            _QueueProperties.Visible = false;
            this.Controls.Add(_QueueProperties);

            _ActivityProperties = new ActivityProperties(_Parent);
            _ActivityProperties.Dock = DockStyle.Fill;
            _ActivityProperties.Visible = false;
            this.Controls.Add(_ActivityProperties);

            _ArcProperties = new ArcProperties(_Parent);
            _ArcProperties.Dock = DockStyle.Fill;
            _ArcProperties.Visible = false;
            this.Controls.Add(_ArcProperties);
        }
        #endregion

        #region Methods
        public void Update(OOMMModel model, Object target)
        {
            _QueueProperties.Visible = false;
            _ActivityProperties.Visible = false;

            if (target == null)
            {
                return;
            }else if (target is ActivityNode)
            {
                _ActivityProperties.Visible = true;
                _ActivityProperties.BringToFront();
                _ActivityProperties.Update((ActivityNode)target);
            }
            else if (target is QueueNode)
            {
                _QueueProperties.Visible = true;
                _QueueProperties.BringToFront();
                _QueueProperties.Update((QueueNode)target);
            }else if (target is Arc){
                _ArcProperties.Visible = true;
                _ArcProperties.BringToFront();
                _ArcProperties.Update((Arc)target);
            }
            /*
            else if (target is ScheduleNode)
            {
                _ScheduleProperties.Visible = true;
                _ScheduleProperties.BringToFront();
                _ScheduleProperties.Update((ScheduleNode)target);
            }
            else if (target is EventVertexNode)
            {
                _EventProperties.Visible = true;
                _EventProperties.BringToFront();
                _EventProperties.Update((EventVertexNode)target);
            }
            */
        }
        #endregion
    }
}