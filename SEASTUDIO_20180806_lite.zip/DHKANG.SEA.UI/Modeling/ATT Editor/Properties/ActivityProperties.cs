﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.UI.ETTEditor;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model.ActivityObjects;

namespace DHKANG.SEA.UI.ATTEditor.Properties
{
    public partial class ActivityProperties : UserControl
    {
        private ActivityObjectModelEditor _Parent;
        private ActivityNode _Node;

        private bool isUpdating = false;

        public ActivityProperties(ActivityObjectModelEditor parent)
        {
            _Parent = parent;
            InitializeComponent();
        }

        public void Update(ActivityNode node)
        {
            _Node = node;

            showProperties();
        }

        private void showProperties()
        {
            isUpdating = true;

            txtName.Text = _Node.Activity.Name;

            setButtonSelection(btnRegular, false);
            setButtonSelection(btnInitial, false);

            if (_Node.Activity.IsEnabled)
                setButtonSelection(btnInitial, true);
            else
                setButtonSelection(btnRegular, true);

            if (_Node.Activity.Parameters != null)
                txtParam.Text = _Node.Activity.Parameters;

            if (!string.IsNullOrEmpty(_Node.Activity.Parameters))
            {
                List<string> pmNameList = _Node.Activity.Parameters.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList<string>();
                List<string> svList = new List<string>();
                List<string> pmList = new List<string>();
                foreach (OOAGStateVariable sv in _Parent.ActivityObjectModel.StateVariables)
                {
                    if (!pmNameList.Contains(sv.Name))
                        svList.Add(sv.Name + ": " + sv.ValueType);
                    else
                        pmList.Add(sv.Name + ": " + sv.ValueType);
                }
                lbSV.Items.Clear();
                svList.Sort();
                svList.ForEach(sv => lbSV.Items.Add(sv));

                lvPM.Items.Clear();
                pmList.Sort();
                pmList.ForEach(pm => lvPM.Items.Add(pm));
            }
            else
            {
                List<string> svList = new List<string>();
                foreach (OOAGStateVariable sv in _Parent.ActivityObjectModel.StateVariables)
                {
                    svList.Add(sv.Name + ": " + sv.ValueType);
                }
                lbSV.Items.Clear();
                svList.Sort();
                svList.ForEach(sv => lbSV.Items.Add(sv));
            }

            if (string.IsNullOrEmpty(_Node.TimeDelay))
                txtTimeDelay.Text = "";
            else
                txtTimeDelay.Text = _Node.TimeDelay;

            isUpdating = false;
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            handleNameChanged();
        }

        private void handleNameChanged()
        {
            if (isUpdating)
                return;

            if (_Node.Activity.Name != txtName.Text)
            {
                _Node.ActivityName = txtName.Text;
                //_Node.Activity.Name = txtName.Text;
                //_Node.Text = txtName.Text;
                //_Node.
            }
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleNameChanged();
            }
        }

        private void handleParametersChanged()
        {
            if (isUpdating)
                return;

            if (_Node.Activity.Parameters != txtParam.Text)
            {
                _Node.Activity.Parameters = txtParam.Text;
            }
        }

        private void handleTimeDelayChanged()
        {
            if (isUpdating)
                return;

            if (_Node.Activity.TimeDelay != txtTimeDelay.Text)
            {
                _Node.TimeDelay = txtTimeDelay.Text;
            }
        }

        private void txtTimeDelay_Leave(object sender, EventArgs e)
        {
            handleTimeDelayChanged();
        }

        private void txtTimeDelay_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleTimeDelayChanged();
            }
        }

        private void btnInitial_Click(object sender, EventArgs e)
        {
            setButtonSelection(btnRegular, false);
            setButtonSelection(btnInitial, true);

            _Node.Activity.IsEnabled = true;
        }

        private void btnRegular_Click(object sender, EventArgs e)
        {
            setButtonSelection(btnRegular, true);
            setButtonSelection(btnInitial, false);

            _Node.Activity.IsEnabled = false;            
        }

        private void setButtonSelection(Button btn, bool selected)
        {
            if (selected)
            {
                btn.FlatAppearance.BorderColor = Color.DarkGray;
                btn.FlatAppearance.BorderSize = 1;
                btn.Font = new Font(btn.Font.FontFamily, 9, FontStyle.Bold);
                btn.BackColor = Color.DarkGray;
            }
            else
            {
                btn.FlatAppearance.BorderColor = Color.Gray;
                btn.FlatAppearance.BorderSize = 0;
                btn.Font = new Font(btn.Font.FontFamily, 9, FontStyle.Regular);
                btn.BackColor = Color.LightGray;
            }
        }

        //move to SV listbox
        private void button2_Click(object sender, EventArgs e)
        {
            if (lvPM.SelectedIndex < 0)
                return;

            int index = lvPM.SelectedIndex;
            string pm = (string)lvPM.SelectedItem;
            lbSV.Items.Add(pm);
            lvPM.Items.RemoveAt(index);

            buildParameters();
        }

        //move to PM listbox
        private void button1_Click(object sender, EventArgs e)
        {
            if (lbSV.SelectedIndex < 0)
                return;

            int index = lbSV.SelectedIndex;
            string sv = (string)lbSV.SelectedItem;
            lvPM.Items.Add(sv);
            lbSV.Items.RemoveAt(index);

            buildParameters();
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            if (lvPM.SelectedIndex <= 0)
                return;

            int index = lvPM.SelectedIndex;
            string pm = (string)lvPM.SelectedItem;
            lvPM.Items.RemoveAt(index);
            lvPM.Items.Insert(index - 1, pm);

            buildParameters();
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            if (lvPM.SelectedIndex == lvPM.Items.Count - 1)
                return;

            int index = lvPM.SelectedIndex;
            string pm = (string)lvPM.SelectedItem;
            lvPM.Items.Insert(index + 1, pm);
            lvPM.Items.RemoveAt(index);

            buildParameters();
        }

        private void buildParameters()
        {
            string parameters = "";
            for(int i = 0; i < lvPM.Items.Count; i++)
            {
                string itemValue = (string)lvPM.Items[i];
                string pmName = itemValue.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries)[0];

                if (i < lvPM.Items.Count - 1)
                    parameters += pmName + ",";
                else
                    parameters += pmName;
            }
            txtParam.Text = parameters;
        }

    }
}