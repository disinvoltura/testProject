﻿using DHKANG.SEA.Model;
using DHKANG.SEA.Model.ActivityObjects;
using Northwoods.Go;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.UI.ATTEditor
{
    public class Arc : GoLabeledLink
    {
        #region Member Variables
        private bool _ProbBranch; //only in outgoing arc
        private float _Prob; //only in outgoinng arc
        private OOAGArcType _ArcType;
        private OOAGArcStyle _ArcStyle;
        private int _Multiplicity=1; //only in incoming arc
        private string _Condition="true"; //only in incoming arc

        private GoText _lblCond;
        private GoText _lblWeight;
        #endregion

        #region Properties
        public OOAGArc ArcProperties
        {
            get
            {
                Guid sourceId = Guid.Empty;
                Guid targetId = Guid.Empty;
                OOAGNodeType sourceType = OOAGNodeType.Activity;
                OOAGNodeType targetType = OOAGNodeType.Queue;
                int sourcePortIndex = 0;
                int targetPortIndex = 0;
                if (this.FromNode is ActivityNode)
                {
                    sourceId = ((ActivityNode)this.FromNode).Activity.ID;
                    sourceType = OOAGNodeType.Activity;
                    sourcePortIndex = ((ActivityNode)this.FromNode).FindPortIndex(this.FromPort);
                }
                else if (this.FromNode is QueueNode)
                {
                    sourceId = ((QueueNode)this.FromNode).Queue.ID;
                    sourceType = OOAGNodeType.Queue;
                    sourcePortIndex = ((QueueNode)this.FromNode).FindPortIndex(this.FromPort);
                }

                if (this.ToNode is ActivityNode)
                {
                    targetId = ((ActivityNode)this.ToNode).Activity.ID;
                    targetType = OOAGNodeType.Activity;
                    targetPortIndex = ((ActivityNode)this.ToNode).FindPortIndex(this.FromPort);
                }
                else if (this.ToNode is QueueNode)
                {
                    targetId = ((QueueNode)this.ToNode).Queue.ID;
                    targetType = OOAGNodeType.Activity;
                    targetPortIndex = ((QueueNode)this.ToNode).FindPortIndex(this.FromPort);
                }


                OOAGArc rslt = new OOAGArc(sourceId, sourceType, targetId, targetType, this.ArcType, sourcePortIndex, targetPortIndex, this.ArcStyle);
                rslt.Multiplicity = this.Multiplicity;
                rslt.Condition = this.Condition;
                rslt.Probability = this.Probability;

                return rslt;
            }
        }

        public bool IsProbabilisticBranch
        {
            get { return _ProbBranch; }
            set { _ProbBranch = value; }
        }

        public float Probability {
            get { return _Prob; }
            set { _Prob = value;
                if (_Prob > 0)
                    _lblCond.Text = _Prob.ToString();
                else
                    _lblCond.Text = "";
            }
        }

        public OOAGArcType ArcType
        {
            get { return _ArcType; }
            set { _ArcType = value;

                if (_ArcType == OOAGArcType.Resource)
                {
                    this.UserFlags = 0;//resource

                    this.Brush = Brushes.Gray;
                    Pen dashedPen = new Pen(Color.Gray);
                    dashedPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                    this.Pen = dashedPen;
                }else if (_ArcType == OOAGArcType.Entity)
                {
                    this.UserFlags = 1;//entity

                    this.Brush = Brushes.Black;
                    Pen solidPen = new Pen(Color.Black);
                    solidPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                    this.Pen = solidPen;
                }
            }
        }

        public OOAGArcStyle ArcStyle
        {
            get { return _ArcStyle; }
            set { _ArcStyle = value;

                if (_ArcStyle == OOAGArcStyle.Line)
                    this.Style = GoStrokeStyle.Line;
                else if (_ArcStyle == OOAGArcStyle.RoundedLine)
                    this.Style = GoStrokeStyle.RoundedLine;
                else if (_ArcStyle == OOAGArcStyle.RoundedLineWithJumpOvers)
                    this.Style = GoStrokeStyle.RoundedLineWithJumpOvers;
            }
        }

        public int Multiplicity
        {
            get { return _Multiplicity; }
            set {
                OOAGArc oldValue = this.ArcProperties;
                _Multiplicity = value;
                if (_Multiplicity > 1)
                {
                    //_lblWeight.Text = _Multiplicity.ToString();
                    ((GoText)this.ToLabel).Text = _Multiplicity.ToString();
                }
                else
                {
                    //_lblWeight.Text = "";
                    ((GoText)this.ToLabel).Text = "";
                }

                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Multiplicity", oldValue, this.ArcProperties);
            }
        }

        public string Condition
        {
            get { return _Condition; }
            set {
                OOAGArc oldValue = this.ArcProperties;
                string oldValueProperty = _Condition;
                _Condition = value;
                if (!string.IsNullOrEmpty(_Condition))
                {
                    _lblCond.Text = _Condition;
                    ((GoText)this.MidLabel).Text = _Condition;
                }
                else
                {
                    _lblCond.Text = "";
                    ((GoText)this.MidLabel).Text = "";
                }
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                   this.PropertyChanged(this, "Condition", oldValue, this.ArcProperties);
            }

        }

        public bool IsConditionalArc
        {
            get { return string.IsNullOrEmpty(_Condition) ? false : true; }
        }
        #endregion

        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Constructors
        public Arc(): base()
        {
            this.AvoidsNodes = true;
            //this.Brush = Brushes.Gray;
            this.ToArrow = true;
            this.ToArrowFilled = true;
            this.ToArrowStyle = GoStrokeArrowheadStyle.Polygon;
            this.ToArrowWidth = 4.0f;

            this.Style = GoStrokeStyle.RoundedLine; // GoStrokeStyle.Bezier;// GoStrokeStyle.Bezier;
            this.Orthogonal = true;

            //Label for Arc Condition
            _lblCond = new GoText();
            _lblCond.Selectable = false;
            _lblCond.Editable = false;
            _lblCond.Text = "";
            _lblCond.FontSize = ActivityCycleDiagramView.ARCATTRIBUTE_FONTSIZE;
            _lblCond.Italic = true;
            _lblCond.TextColor = ActivityCycleDiagramView.ARCATTRIBUTE_COLOR;

            this.MidLabel = _lblCond;
            this.MidLabel.AutoRescales = true;
            this.MidLabelCentered = false;

            //Label for Arc Multiplicity
            _lblWeight = new GoText();
            _lblWeight.Selectable = false;
            _lblWeight.Editable = false;
            _lblWeight.Text = "";
            _lblWeight.FontSize = 8;
            _lblWeight.FontSize = ActivityCycleDiagramView.ARCATTRIBUTE_FONTSIZE;
            _lblWeight.Italic = true;
            _lblWeight.TextColor = ActivityCycleDiagramView.ARCATTRIBUTE_COLOR;

            this.ToLabel = _lblWeight;
            this.ToLabelCentered = false;
        }
        #endregion
        /*
        public override GoLink CreateRealLink()
        {
            return new TransitionLink();
        }
        */
    }
}
