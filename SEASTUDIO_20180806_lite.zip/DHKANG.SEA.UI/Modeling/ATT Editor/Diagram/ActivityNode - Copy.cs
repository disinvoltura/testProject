﻿using DHKANG.SEA.Model.ActivityObjects;
using Northwoods.Go;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.UI.ATTEditor
{
    public class ActivityNode : GoMultiTextNode
    {
        #region Member Variables
        private GoText _Header;
        private GoText _Middle;
        private GoText _Tail;
        private GoText _Blank;
        private GoPort _LeftPort1;
        private GoPort _LeftPort2;
        private GoPort _LeftPort3;
        private GoPort _RightPort1;
        private GoPort _RightPort2;
        private GoPort _RightPort3;
        private GoPort _TopPort1;
        private GoPort _TopPort2;
        private GoPort _BottomPort1;
        private GoPort _BottomPort2;
        private List<GoPort> _Ports;

        private OOAGActivity _Activity;
        /*
        private Guid _ID;
        private string _ActivityName;
        private string _TimeDelay;
        private bool _IsInitial = false;
        private string _Parameters;
        */
        #endregion

        #region Properties
     
        public OOAGActivity Activity {  get { return _Activity; } }
        /*
        public Guid ID { get { return _ID; } set { _ID = value; } }
        public bool IsInitial
        {
            get { return _IsInitial; }
            set { _IsInitial = value; }
        }

        public string Parameters
        {
            get { return _Parameters; }
            set { _Parameters = value; }
        }

        public string ActivityName
        {
            get { return _ActivityName; }
            set { setActivityName(value); }
        }

        public string TimeDelay
        {
            get { return _TimeDelay; }
            set { setTimeDelay(value); }
        }
        */
        #endregion

        #region Constructors
        public ActivityNode(OOAGActivity activity)
        {
            _Activity = activity;

            initializeNode();
        }

        public ActivityNode(string name)
        {
            _Activity = new OOAGActivity(name, string.Empty, string.Empty);

            initializeNode();
        }

        private void initializeNode()
        {
            _Ports = new List<GoPort>();
            //-------------------------------------------------
            _LeftPort1 = (GoPort)CreatePort(true, 0);
            _LeftPort2 = (GoPort)CreatePort(true, 1);
            _LeftPort3 = (GoPort)CreatePort(true, 2);
            _RightPort1 = (GoPort)CreatePort(false, 0);
            _RightPort2 = (GoPort)CreatePort(false, 1);
            _RightPort3 = (GoPort)CreatePort(false, 2);

            //-------------------------------------------------
            _TopPort1 = (GoPort)CreateEndPort(true);
            _TopPort2 = (GoPort)CreateEndPort(true);
            _BottomPort1 = (GoPort)CreateEndPort(false);
            _BottomPort2 = (GoPort)CreateEndPort(false);

            _Ports.Add(_LeftPort1);
            _Ports.Add(_LeftPort2);
            _Ports.Add(_LeftPort3);
            _Ports.Add(_RightPort1);
            _Ports.Add(_RightPort2);
            _Ports.Add(_RightPort3);
            _Ports.Add(_TopPort1);
            _Ports.Add(_TopPort2);
            _Ports.Add(_BottomPort1);
            _Ports.Add(_BottomPort2);
            foreach (GoPort gp in this.Ports)
                _Ports.Add(gp);
            //positioning
            _Header = CreateText(_Activity.Name, 0);
            this.LinePen = new Pen(Color.Transparent);
            this.Spacing = 0.0f;
            if (_Header != null)
            {
                _Header.Bold = true;
                _Header.BackgroundColor = Color.Transparent;
                _Header.TextColor = Color.Black;
                _Header.TransparentBackground = true;
                _Header.Bordered = false;
                _Header.Alignment = GoText.MiddleCenter;
                AddItem(_Header, _LeftPort1, _RightPort1);
                System.Diagnostics.Trace.WriteLine("Height: " + _Header.Height);
            }

            _Middle = CreateText("", 1);
            if (_Middle != null)
            {
                _Middle.Height = 0;
                AddItem(_Middle, _LeftPort2, _RightPort2);
            }
            _Tail = CreateText("", 2);
            if (_Tail != null)
            {
                _Tail.Bold = false;
                _Tail.FontSize = 6;
                _Tail.BackgroundColor = Color.Transparent;
                _Tail.TextColor = Color.Black;
                _Tail.TransparentBackground = true;
                _Tail.Bordered = false;
                _Tail.Height = 9;
                _Tail.Alignment = GoText.MiddleCenter;
                AddItem(_Tail, _LeftPort3, _RightPort3);
            }
            _Blank = CreateText("", 3);
            if (_Blank != null)
            {
                _Blank.Height = 6;
                _Blank.AutoRescales = false;
                _Blank.AutoResizes = false;
                AddItem(_Blank, null, null);
            }

            this.Add(_TopPort1);
            this.Add(_TopPort2);
            this.Add(_BottomPort1);
            this.Add(_BottomPort2);

            this.ToolTipText = _Activity.Name;
            this.ComputeBounds();

            UpdatePortCenters();
        }

        public override GoObject CreatePort(bool left, int idx)
        {
            ActivityNodePort p = new ActivityNodePort();
            p.Size = new SizeF(3, 5);
            p.Style = GoPortStyle.None;
            if (left)
            {
                p.FromSpot = MiddleLeft;
                p.ToSpot = MiddleLeft;
            }
            else
            {
                p.FromSpot = MiddleRight;
                p.ToSpot = MiddleRight;
            }
            return p;
        }

        private void setTimeDelay(string timeDelay)
        {
            _Activity.TimeDelay = timeDelay;
            decimal constantTime;
            if (decimal.TryParse(timeDelay, out constantTime))
            {
                _Tail.Text = string.Format("Constant({0})", timeDelay);
            }
            else
            {
                _Tail.Text = timeDelay;
            }
        }

        public string ActivityName
        {
            get
            {
                return _Activity.Name;
            }
            set
            {
                _Activity.Name = value;
                _Header.Text = value;
                this.ToolTipText = value;

                if (_Header.Width < 100)
                    _Header.Width = 100;
                this.ComputeBounds();
                //UpdatePortCenters();
                LayoutAllPorts();
            }
        }

        private void setActivityName(string name)
        {
            _Activity.Name = name;
            _Header.Text = name;

            //this.ComputeBounds();
            //UpdatePortCenters();
        }

        public override void Changed(int subhint, int oldI, object oldVal, RectangleF oldRect, int newI, object newVal, RectangleF newRect)
        {
            if (_Tail != null && _Blank != null)
            {
                //_Tail.Height = _Header.Height;
                System.Diagnostics.Trace.WriteLine(
                    this.Text + "(" + _Header.Height + "," + _Middle.Height + "," + _Tail.Height + "," + _Blank.Height + ")");

                _Blank.Height = _Header.Height - _Tail.Height - 0.6606f;// 0.6029f;
                _Blank.AutoResizes = false;
                _Blank.AutoRescales = false;
                System.Diagnostics.Trace.WriteLine(
                    this.Text + "(" + _Header.Height + "," + _Middle.Height + "," + _Tail.Height + "," + _Blank.Height + ")");
                //this.Height = _Header.Height + _Tail.Height;
                System.Diagnostics.Trace.WriteLine(
                    this.Text + "(" + _RightPort2.Location.X + "," + _RightPort2.Location.Y + ": ");
            }

            base.Changed(subhint, oldI, oldVal, oldRect, newI, newVal, newRect);
        }

        protected override void OnBoundsChanged(RectangleF old)
        {
            base.OnBoundsChanged(old);
            //UpdatePortCenters();
            LayoutAllPorts();
        }

        private void UpdatePortCenters()
        {
            if (_TopPort1 != null)
            {
                float step = this.Width / 4;
                _TopPort1.Center = new PointF(this.TopPort.Center.X - step, this.TopPort.Center.Y);
                _TopPort2.Center = new PointF(this.TopPort.Center.X + step, this.TopPort.Center.Y);
                _BottomPort1.Center = new PointF(this.BottomPort.Center.X - step, this.BottomPort.Center.Y);
                _BottomPort2.Center = new PointF(this.BottomPort.Center.X + step, this.BottomPort.Center.Y);

                float step2 = this.Height / 4;
                _LeftPort1.Center = new PointF(this.Left, this.Top + step2);
                _LeftPort2.Center = new PointF(this.Left, this.Top + step2 * 2);
                _LeftPort3.Center = new PointF(this.Left, this.Top + step2 * 3);
                _RightPort1.Center = new PointF(this.Right, _LeftPort1.Center.Y);
                _RightPort2.Center = new PointF(this.Right, _LeftPort2.Center.Y);
                _RightPort3.Center = new PointF(this.Right, _LeftPort3.Center.Y);
            }
        }

        public virtual void LayoutAllPorts()
        {
            if (this.MultiPorts.Count == 0) return;
            this.Initializing = false;
            // recalculate border, in case base.LayoutChildren caused changes
            // Note that ComputeInsideMarginsSkip skips all ports in its determination
            // of what to ignore when computing the border
            RectangleF rect = this.Bounds;
            //RectangleF rect = new RectangleF(this.Top, this.Left, this.Width, this.Height);
            this.Initializing = true;
            // compute corners

            float minLeft1 = _Header.Left < _Middle.Left ? _Header.Left : _Middle.Left;
            float minLeft2 = _Tail.Left < _Blank.Left ? _Tail.Left : _Blank.Left;
            float maxRight1 = _Header.Right > _Middle.Right ? _Header.Right : _Middle.Right;
            float maxRight2 = _Tail.Right > _Blank.Right ? _Tail.Right : _Blank.Right;

            float top = _Header.Top - 3 - 0.3f;
            float left = Math.Min(minLeft1, minLeft2) - 3 - 0.3f;
            float right = Math.Max(maxRight1, maxRight2) + 3 + 0.3f;
            float bottom = top + _Header.Height + _Middle.Height + _Tail.Height + _Blank.Height + 9 + 0.3f;

            //float top = _Header.Top - 3;
            //float left = _Middle.Left - 3;
            //float right = _Middle.Right + 3;
            //float bottom = top + _Header.Height + _Middle.Height + _Tail.Height + _Blank.Height + 9;

            PointF tl = new PointF(left, top);
            PointF tr = new PointF(right, top);
            PointF br = new PointF(right, bottom);
            PointF bl = new PointF(left, bottom);

            //PointF tl = new PointF(rect.X, rect.Y);
            //PointF tr = new PointF(rect.X + rect.Width, rect.Y);
            //PointF br = new PointF(rect.X + rect.Width, rect.Y + rect.Height);
            //PointF bl = new PointF(rect.X, rect.Y + rect.Height);

            /*
            RectangleF rect = ComputeBounds();// ComputeBorder();
            this.Initializing = true;
            // compute corners
            PointF tl = new PointF(rect.X, rect.Y);
            PointF tr = new PointF(rect.X + rect.Width, rect.Y);
            PointF br = new PointF(rect.X + rect.Width, rect.Y + rect.Height);
            PointF bl = new PointF(rect.X, rect.Y + rect.Height);
            */
            // now layout each set of ports between the corners
            LayoutPorts(MiddleLeft, tl, bl);
            LayoutPorts(MiddleTop, tl, tr);
            LayoutPorts(MiddleRight, tr, br);
            LayoutPorts(MiddleBottom, bl, br);
            this.Initializing = false;
        }

        private void LayoutPorts(int spot, PointF a, PointF b)
        {
            // count how many there are on a particular side (as specified by SPOT)
            int count = 0;
            foreach (MultiPortNodePort port in this.MultiPorts)
            {
                if (port.Side == spot)
                {
                    count++;
                }
            }
            // now position them evenly along that side
            float c = 1;
            foreach (MultiPortNodePort port in this.MultiPorts)
            {
                if (port.Side == spot)
                {
                    float nX = a.X + (c / (count + 1)) * (b.X - a.X);
                    float nY = a.Y + (c / (count + 1)) * (b.Y - a.Y);
                    PointF p = new PointF(nX, nY);
                    port.SetSpotLocation(spot, p);
                    c++;
                    port.Size = new SizeF(3, 3);
                }
            }
        }

        public override void OnGotSelection(GoSelection sel)
        {
            base.OnGotSelection(sel);
        }

        #endregion

        #region Methods
        public int FindPortIndex(IGoPort port)
        {
            int idx = 0;
            if (port.Equals(this.TopPort))
                idx = 0;
            else if (port.Equals(this.BottomPort))
                idx = 4;
            else if (port.Equals(_LeftPort1))
                idx = 1;
            else if (port.Equals(_LeftPort2))
                idx = 2;
            else if (port.Equals(_LeftPort3))
                idx = 3;
            else if (port.Equals(_RightPort1))
                idx = 7;
            else if (port.Equals(_RightPort2))
                idx = 6;
            else if (port.Equals(_RightPort3))
                idx = 5;
            else if (port.Equals(_TopPort1))
                idx = 8;
            else if (port.Equals(_TopPort2))
                idx = 11;
            else if (port.Equals(_BottomPort1))
                idx = 9;
            else if (port.Equals(_BottomPort2))
                idx = 10;

            return idx;
        }

        public IGoPort FindPort(int idx)
        {
            IGoPort port = null;

            if (idx == 0)
                port = (IGoPort)this.TopPort;
            else if (idx == 1)
                port = _LeftPort1;
            else if (idx == 2)
                port = _LeftPort2;
            else if (idx == 3)
                port = _LeftPort3;
            else if (idx == 4)
                port = (IGoPort)this.BottomPort;
            else if (idx == 5)
                port = _RightPort3;
            else if (idx == 6)
                port = _RightPort2;
            else if (idx == 7)
                port = _RightPort1;
            else if (idx == 8)
                port = _TopPort1;
            else if (idx == 11)
                port = _TopPort2;
            else if (idx == 9)
                port = _BottomPort1;
            else if (idx == 10)
                port = _BottomPort2;

            return port;
        }

        public void ShowPorts()
        {
            Pen p = new Pen(Brushes.Black, 0.5f);
            p.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;

            int count = 0;
            foreach (GoPort port in _Ports)
            {
                if ((count % 2) == 0)
                {
                    port.Style = GoPortStyle.Ellipse;
                }
                else
                {
                    port.Style = GoPortStyle.Rectangle;
                }

                port.Pen = p;
                port.BrushStyle = GoBrushStyle.Solid;
                port.BrushColor = Color.White;
            }
            UpdatePortCenters();
            //LayoutAllPorts();
        }

        public void HidePorts()
        {
            foreach (GoPort port in _Ports)
            {
                port.Style = GoPortStyle.None;
            }
        }

        #endregion
    }

    public class ActivityNodePort : GoPort
    {
        public ActivityNodePort()
            : base()
        {
        }

        public override bool CanLinkTo()
        {
            return true;
            /*
            if (MainApp.App.FromNode is QueueNode)
            {
                return true;
            }
            return false;
             * */
        }

        public override void Changing(int subhint)
        {
            System.Diagnostics.Trace.WriteLine("[ActivityNodePort.Changing]" + subhint);
            base.Changing(subhint);
        }

        public override void OnGotSelection(GoSelection sel)
        {
            base.OnGotSelection(sel);
        }
    }

}
