﻿using DHKANG.SEA.Model;
using DHKANG.SEA.Model.ActivityObjects;
using DHKANG.SEA.UI.OutputView;
using Northwoods.Go;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.UI.ATTEditor
{
    public enum QueueType { Regular, Source, Dummy };

    public class QueueNode : GoTextNode
    {
        #region Member Variables
        private OOAGQueue _Queue;

        //Ports: GoTextNode의 기본 Ports 이외에 4개 Ports를 추가
        //- TopPort를 기준으로 반시계방향으로 4,5,6,7 
        private GoPort _Port1; //ID: 4
        private GoPort _Port2; //ID: 5
        private GoPort _Port3; //ID: 6
        private GoPort _Port4; //ID: 7
        private GoEllipse _Background;

        private List<GoPort> _Ports;
        #endregion

        #region Properties
        public string QueueName
        {
            get { return _Queue.Name; }

            set
            {
                _Queue.Name = value;
                this.Text = value;
                this.ToolTipText = value;
                if (this.Width < 50)
                {
                    _Background.Size = new SizeF(50, 50);
                }
                //this.ComputeBounds();
                UpdatePortPositions();
            }
        }

        public OOAGQueue Queue
        {
            get { return _Queue; }
            set { _Queue = value; }
        }
        #endregion

        #region Constructors
        public QueueNode(OOAGQueue q)
            :this (q.Name)
        {
            _Queue = q;
            //this.Text = _Queue.Name;
            this.AutoResizes = false;
            this.AutoRescales = false;
            this.Resizable = false;
        }

        public QueueNode(string name)
        {
            _Queue = new OOAGQueue(name);
            this.Text = name;

            _Background = new GoEllipse();
            this.Background = _Background;
            this.Background.Selectable = false;
            //this.Brush = new SolidBrush(Color.Silver);
            this.Brush = new SolidBrush(Color.FromArgb(38, 208,206));
            //_Background.FillShapeGradient(Color.FromArgb(26,41,128), Color.FromArgb(38,208,206));
            //_Background.FillShapeGradient(Color.DarkKhaki, Color.Khaki);
            this.Pen = new Pen(Color.FromArgb(33,169,168));
            //this.Pen = new Pen(Color.DarkKhaki);
            //this.Pen = new Pen(Color.Black);
            this.Label.Editable = false;
            this.Label.Alignment = GoTextNode.MiddleCenter; 
            this.Editable = true;
            this.Movable = true;
            this.AutoResizes = false;
            this.AutoRescales = false;
            this.Resizable = false;
            this.Size = new SizeF(50, 50);

            //Ports
            _Port1 = CreatePort(GoObject.TopLeft);
            _Port2 = CreatePort(GoObject.BottomLeft);
            _Port3 = CreatePort(GoObject.BottomRight);
            _Port4 = CreatePort(GoObject.TopRight);

            //UpdatePortPositions();

            this.Add(_Port1);
            this.Add(_Port2);
            this.Add(_Port3);
            this.Add(_Port4);

            _Ports = new List<GoPort>();
            _Ports.Add(_Port1); _Ports.Add(_Port2);
            _Ports.Add(_Port3); _Ports.Add(_Port4);
            foreach (GoPort gp in this.Ports)
            {
                _Ports.Add(gp);
            }

            UpdatePortPositions();
            this.ToolTipText = name;
            this.Size = new SizeF(50, 50);

        }
        #endregion

        #region Methods
        protected override GoPort CreatePort(int spot)
        {
            QueueNodePort p = new QueueNodePort();
            p.Style = GoPortStyle.None;
            p.Size = new SizeF(4, 4);
            p.FromSpot = spot;
            p.ToSpot = spot;
            p.Resizable = false;
            p.AutoRescales = false;

            return p;
        }

        private void setText(string name)
        {
            _Queue.Name = name;
            this.Text = name;

            UpdatePortPositions();
        }

        public int FindPortIndex(IGoPort port)
        {
            int idx = 0;

            if (port.Equals(this.TopPort))
                idx = 0;
            else if (port.Equals(this.LeftPort))
                idx = 1;
            else if (port.Equals(this.BottomPort))
                idx = 2;
            else if (port.Equals(this.RightPort))
                idx = 3;
            else if (port.Equals(_Port1))
                idx = 4;
            else if (port.Equals(_Port2))
                idx = 5;
            else if (port.Equals(_Port3))
                idx = 6;
            else if (port.Equals(_Port4))
                idx = 7;

            return idx;
        }

        public IGoPort FindPort(int idx)
        {
            IGoPort port = null;

            if (idx == 0)
                port = this.TopPort;
            else if (idx == 1)
                port = this.LeftPort;
            else if (idx == 2)
                port = this.BottomPort;
            else if (idx == 3)
                port = this.RightPort;
            else if (idx == 4)
                port = _Port1;
            else if (idx == 5)
                port = _Port1;
            else if (idx == 6)
                port = _Port1;
            else if (idx == 7)
                port = _Port1;

            return port;
        }

        public override void Changed(int subhint, int oldI, object oldVal, RectangleF oldRect, int newI, object newVal, RectangleF newRect)
        {
            base.Changed(subhint, oldI, oldVal, oldRect, newI, newVal, newRect);
        }

        public override void OnGotSelection(GoSelection sel)
        {
            base.OnGotSelection(sel);

            //MainApp.App.FromNode = this;
        }

        protected override void OnBoundsChanged(RectangleF old)
        {
            base.OnBoundsChanged(old);

            UpdatePortPositions();
        }

        private void UpdatePortPositions()
        {
            if (_Port1 == null)
                return;

            _Port1.Center = _Background.GetSpotLocation(GoEllipse.TopLeft);
            _Port2.Center = _Background.GetSpotLocation(GoEllipse.BottomLeft);
            _Port3.Center = _Background.GetSpotLocation(GoEllipse.BottomRight);
            _Port4.Center = _Background.GetSpotLocation(GoEllipse.TopRight);

            PointF f1 = new PointF();
            PointF f2 = new PointF();
            PointF f3 = new PointF();
            PointF f4 = new PointF();

            _Background.GetNearestIntersectionPoint(new PointF(_Port1.Left, _Port1.Top), _Background.Center, out f1);
            _Background.GetNearestIntersectionPoint(new PointF(_Port2.Left, _Port2.Bottom), _Background.Center, out f2);
            _Background.GetNearestIntersectionPoint(new PointF(_Port3.Right, _Port3.Bottom), _Background.Center, out f3);
            _Background.GetNearestIntersectionPoint(new PointF(_Port4.Right, _Port4.Top), _Background.Center, out f4);

            /*
            _Port1.Left = f1.X - 2;
            _Port1.Top = f1.Y - 2;
            _Port2.Left = f2.X - 2;
            _Port2.Bottom = f2.Y + 2;
            _Port3.Right = f3.X + 2;
            _Port3.Bottom = f3.Y + 2;
            _Port4.Right = f4.X + 2;
            _Port4.Top = f4.Y + 2;
            */

            _Port1.Position = f1;
            _Port2.Left = f2.X;
            _Port2.Bottom = f2.Y;
            _Port3.Right = f3.X;
            _Port3.Bottom = f3.Y;
            _Port4.Right = f4.X;
            _Port4.Top = f4.Y;

        }

        public void ShowPorts()
        {
            Pen p = new Pen(Brushes.Black, 0.5f);
            p.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;

            int count = 0;
            foreach (GoPort port in _Ports)
            {
                if ((count % 2) == 0)
                {
                    port.Style = GoPortStyle.Ellipse;
                }
                else
                {
                    port.Style = GoPortStyle.Rectangle;
                }

                port.Pen = p;
                port.BrushStyle = GoBrushStyle.Solid;
                port.BrushColor = Color.White;
            }
            UpdatePortPositions();
            //LayoutAllPorts();
        }

        public void HidePorts()
        {
            foreach (GoPort port in _Ports)
            {
                port.Style = GoPortStyle.None;
            }
        }

        #endregion
    }

    public class QueueNodePort : GoPort
    {
        public QueueNodePort()
            : base()
        {
        }

        public override bool CanLinkTo()
        {
            return true;
        }

        public override void OnGotSelection(GoSelection sel)
        {
            base.OnGotSelection(sel);
            //MainApp.App.FromNode = this.Node;
        }

    }
}
