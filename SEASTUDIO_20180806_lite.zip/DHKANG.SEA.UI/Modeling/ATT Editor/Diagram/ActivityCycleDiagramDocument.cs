﻿using DHKANG.SEA.Model.ActivityObjects;
using DHKANG.SEA.UI.ETTEditor;
using Northwoods.Go;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.UI.ATTEditor
{
    public class ActivityCycleDiagramDocument : GoDocument
    {
        #region Member Variables
        private static int ACTIVITY_NODE_HEIGHT = 60;
        private static int QUEUE_NODE_HEIGHT = 50;
        private int _nodeCounter = 0;
        private NodeFactory _Factory;
        private Dictionary<string, int> _TypeIDList;
        #endregion

        #region Properties
        #endregion

        #region Constructors
        public ActivityCycleDiagramDocument() : base()
        {
            this.Name = "1";

            _TypeIDList = new Dictionary<string, int>();
            string[] namelist = Enum.GetNames(typeof(NodeType));
            foreach (string name in namelist)
            {
                _TypeIDList.Add(name, 1);
            }

        }
        
        public ActivityCycleDiagramDocument(string name) : this()
        {
            this.Name = name;
        }
        #endregion

        #region Methods
        public List<ActivityNode> ActivityNodes
        {
            get
            {
                List<ActivityNode> nodes = new List<ActivityNode>();
                foreach (GoObject obj in this)
                {
                    if (obj.ParentNode is ActivityNode)
                    {
                        nodes.Add((ActivityNode)obj.ParentNode);
                    }
                }
                return nodes;
            }
        }

        public List<QueueNode> QueueNodes
        {
            get
            {
                List<QueueNode> nodes = new List<QueueNode>();
                foreach (GoObject obj in this)
                {
                    if (obj.ParentNode is QueueNode)
                    {
                        nodes.Add((QueueNode)obj.ParentNode);
                    }
                }

                return nodes;
            }
        }

        public List<Arc> Arcs
        {
            get
            {
                List<Arc> arcs = new List<Arc>();
                foreach (GoObject obj in this)
                {
                    if (obj is Arc)
                        arcs.Add((Arc)obj);
                }
                return arcs;
            }
        }

        public ActivityNode InsertActivityNode(float x, float y)
        {
            this.StartTransaction();

            string name = NextName(NodeType.ActivityVertex);
            ActivityNode n = new ActivityNode(name);
            n.Location = new PointF(x, y);
            n.Height = ACTIVITY_NODE_HEIGHT - 2.0f;
            n.Width = 90.3f;

            this.Add(n);
            this.FinishTransaction("Activity Node is inserted.");

            return n;
        }

        
        public ActivityNode InsertActivityNode(OOAGActivityTransition at)
        {
            this.StartTransaction();

            ActivityNode n =
                new ActivityNode(at.Activity);
            n.Center = new PointF(at.Activity.X, at.Activity.Y);

            //n.Activity.Name = at.Activity.Name;
            //n.Activity.TimeDelay = at.BTOEvent.Time;
            //System.Diagnostics.Debug.WriteLine("ACDDocument.insertActivityNode.1] height: " + n.Height);
            //System.Diagnostics.Debug.WriteLine("ACDDocument.insertActivityNode.1] width: " + n.Width);
            n.Height = ACTIVITY_NODE_HEIGHT - 2.0f;
            n.Width = 90.3f;

            if (at.Activity.IsEnabled)
                n.Brush = Brushes.LightGray;

            //System.Diagnostics.Debug.WriteLine("ACDDocument.insertActivityNode.2] height: " + n.Height);
            //System.Diagnostics.Debug.WriteLine("ACDDocument.insertActivityNode.2] width: " + n.Width);
            this.Add(n);
            this.FinishTransaction("Activity Node is inserted.");

            return n;
        }

        public QueueNode InsertQueueNode(float x, float y)
        {
            this.StartTransaction();

            string name = NextName(NodeType.QueueVertex);

            QueueNode n = new QueueNode(name);
            n.Center = new System.Drawing.PointF(x, y);
            n.Label.Bold = true;
            //n.Height = QUEUE_NODE_HEIGHT;
            //n.Width = QUEUE_NODE_HEIGHT;
            
            this.Add(n);
            this.FinishTransaction("Queue Node is inserted.");

            return n;
        }

        public QueueNode InsertQueueNode(OOAGQueue q)
        {
            this.StartTransaction();

            QueueNode n =
                new QueueNode(q);
            n.Center = new PointF(q.X, q.Y);
            n.Label.Bold = true;
            n.Label.Alignment = GoText.MiddleCenter;
            //n.Height = QUEUE_NODE_HEIGHT;
            //n.Width = QUEUE_NODE_HEIGHT;

            int initialValue = 0;

            n.Text = q.Name + "\r\n";
            if (int.TryParse(q.InitialValue, out initialValue))
            {
                if (initialValue > 0)
                {
                    n.Text = q.Name + "\r\n" + "•";
                }
            }

            this.Add(n);
            this.FinishTransaction("Queue Node is inserted.");

            return n;
        }

        public ScheduleNode InsertScheduleNode(float x, float y)
        {
            this.StartTransaction();

            string name = NextName(NodeType.Schedule);
            ScheduleNode node = new ScheduleNode(name, x, y);
            //node.Position = new PointF(x, y);

            this.Add(node);
            this.FinishTransaction("Schedule Node is inserted.");

            return node;
        }

        /// <summary>
        /// Remove any queue whose name is equal to the given name if its input activities and output activities are not involved with the given activity.
        /// </summary>
        /// <param name="name"></param>
        public void RemoveQueueNodeIfNoLinks(string queueName, string activityName)
        {
            foreach (GoObject obj in this)
            {
                if (obj is QueueNode)
                {
                    QueueNode node = (QueueNode)obj;

                    if (node.Text == queueName)
                    {
                        bool isIndependent = true;
                        foreach (ActivityNode inNode in node.Sources)
                        {
                            if (inNode.Text != activityName)
                            {
                                isIndependent = false;
                                break;
                            }
                        }
                        if (!isIndependent)
                            return;

                        foreach (ActivityNode outNode in node.Destinations)
                        {
                            if (outNode.Text != activityName)
                            {
                                isIndependent = false;
                                break;
                            }
                        }
                        if (isIndependent)
                            this.Remove(node);

                        return;
                    }
                }
            }
        }

        public void RemoveActivityNode(string name)
        {
            foreach (GoObject obj in this)
            {
                if (obj is ActivityNode)
                {
                    ActivityNode node = (ActivityNode)obj;

                    if (node.Text == name)
                    {
                        this.Remove(node);
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// 주어진 이름(name)을 가지는 Activity Node 나 Queue Node 가 있는지 알려준다.
        /// </summary>
        /// <param name="name">찾고자 하는 Node의 이름</param>
        /// <returns>존재 여부</returns>
        public bool Contains(string name)
        {
            bool rslt = false;

            foreach (GoObject obj in this)
            {
                if (obj is ActivityNode)
                {
                    ActivityNode node = (ActivityNode)obj;

                    if (node.Text.Equals(name))
                    {
                        rslt = true;
                        break;
                    }
                }
                else if (obj is QueueNode)
                {
                    QueueNode node = (QueueNode)obj;

                    if (node.Text.Equals(name))
                    {
                        rslt = true;
                        break;
                    }
                }
            }

            return rslt;
        }

        protected override void OnChanged(GoChangedEventArgs evt)
        {
            /*
            System.Diagnostics.Trace.WriteLine("[OnChanged] " + evt.ToString());
            if (evt.Object is ActivityNodePort)
            {
                if (evt.Hint == 104)
                {
                    ActivityNodePort p = (ActivityNodePort)evt.Object;
                    MainApp.App.FromNode = p.Node;
                }
                //System.Diagnostics.Trace.WriteLine("-/-");
            }
            else if (evt.Object is QueueNodePort)
            {
                if (evt.Hint == 104)
                {
                    QueueNodePort p = (QueueNodePort)evt.Object;
                    MainApp.App.FromNode = p.Node;
                }
                //System.Diagnostics.Trace.WriteLine("-/-");
            }
            else if (evt.Object is GoLabeledLink)
            {
                GoLabeledLink link = (GoLabeledLink)evt.Object;

                MainApp.App.FromNode = link.FromNode;

                System.Diagnostics.Debug.WriteLine("[ACD] (hint, subhint) = (" + evt.Hint + "," + evt.SubHint + ")");

                if (evt.Hint == 901 && (evt.SubHint == 1302 || evt.SubHint == 1303))
                {
                    UpdateActivityNode();
                }
                if (evt.Hint == 902)//inserted
                {
                    if ((link.FromNode is QueueNode && link.ToNode is QueueNode) ||
                         (link.FromNode is ActivityNode && link.ToNode is ActivityNode))
                    {
                        link.Remove();
                    }
                    else
                        UpdateActivityNodeOnLinkInserted(link);
                }
                else if (evt.Hint == 903) //removed
                {
                    UpdateActivityNodeOnLinkRemoved(link);
                }
            }
            else if (evt.Object is GoText)
            {
                GoText gt = (GoText)evt.Object;
                if (gt.ParentNode is QueueNode)
                {
                    QueueNode node = (QueueNode)gt.ParentNode;

                    if (evt.Hint == 901 && evt.SubHint == 1501)
                    {
                        foreach (ActivityNode anode in node.Sources)
                        {
                            anode.PropertyDialog.Update();
                        }

                        foreach (ActivityNode anode in node.Destinations)
                        {
                            anode.PropertyDialog.Update();
                        }
                    }
                }
                //901, 1001: Queue changed (position)
                //901, 1501: Queue changed (changed text)
            }
            */

            base.OnChanged(evt);
        }

        //Update all activity nodes (Activity Transition)
        private void UpdateActivityNode()
        {
            /*
            foreach (GoObject obj in this)
            {
                if (obj is ActivityNode)
                {
                    ActivityNode node = (ActivityNode)obj;

                }
            }
            */
        }
        private void UpdateActivityNodeOnLinkInserted(GoLabeledLink link)
        {
            /*
            if (link.FromNode is ActivityNode)
            {
                ActivityNode node = (ActivityNode)link.FromNode;

                //node.PropertyDialog.Update();
            }

            if (link.ToNode is ActivityNode)
            {
                ActivityNode node = (ActivityNode)link.ToNode;

                //node.PropertyDialog.Update();
            }
            */
        }

        private void UpdateActivityNodeOnLinkRemoved(GoLabeledLink link)
        {
            /*
            if (link.FromNode is ActivityNode && link.ToNode is QueueNode)
            {
                ActivityNode node = (ActivityNode)link.FromNode;
                QueueNode qNode = (QueueNode)link.ToNode;
                //node.PropertyDialog.UpdateAtEndTransition(qNode);
            }

            if (link.ToNode is ActivityNode && link.FromNode is QueueNode)
            {
                QueueNode qNode = (QueueNode)link.FromNode;
                ActivityNode node = (ActivityNode)link.ToNode;

                //node.PropertyDialog.UpdateAtBeginTransition(qNode);
            }
            */
        }
        #endregion

        #region Node Naming Methods
        public int NextTypeID(NodeType type)
        {
            int typeID = _TypeIDList[type.ToString()];
            _TypeIDList[type.ToString()]++;

            return typeID;
        }

        public string NextName(NodeType type)
        {
            int typeID = NextTypeID(type);

            string name = type.ToString() + " " + typeID;

            while (this.FindNode(name) != null)
            {
                typeID++;
                _TypeIDList[type.ToString()] = typeID;

                name = type.ToString() + " " + typeID;
            }

            return name;
        }

        #endregion
    }
}
