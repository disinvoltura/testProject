﻿namespace DHKANG.SEA.UI.ATTEditor
{
    partial class ActivityCycleDiagramWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ActivityCycleDiagramWindow));
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbActivityNode = new System.Windows.Forms.ToolStripButton();
            this.tsbQueue = new System.Windows.Forms.ToolStripButton();
            this.entityArcToolBar = new System.Windows.Forms.ToolStripButton();
            this.resArcToaolBar = new System.Windows.Forms.ToolStripButton();
            this.toolStrip4 = new System.Windows.Forms.ToolStrip();
            this.tsbLeft = new System.Windows.Forms.ToolStripButton();
            this.tsbCenter = new System.Windows.Forms.ToolStripButton();
            this.tsbRight = new System.Windows.Forms.ToolStripButton();
            this.tsbTop = new System.Windows.Forms.ToolStripButton();
            this.tsbMiddle = new System.Windows.Forms.ToolStripButton();
            this.tsbBottom = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbGrid = new System.Windows.Forms.ToolStripButton();
            this.tsbLayout = new System.Windows.Forms.ToolStripButton();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.tsbZoomIn = new System.Windows.Forms.ToolStripButton();
            this.tsbZoomOut = new System.Windows.Forms.ToolStripButton();
            this.tsbZoomFit = new System.Windows.Forms.ToolStripButton();
            this.tscbZoom = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.toolStrip4.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(823, 443);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(823, 480);
            this.toolStripContainer1.TabIndex = 0;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip1);
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip4);
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip2);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(30, 30);
            this.toolStrip1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbActivityNode,
            this.tsbQueue,
            this.entityArcToolBar,
            this.resArcToaolBar});
            this.toolStrip1.Location = new System.Drawing.Point(3, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(148, 37);
            this.toolStrip1.TabIndex = 0;
            // 
            // tsbActivityNode
            // 
            this.tsbActivityNode.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbActivityNode.Image = ((System.Drawing.Image)(resources.GetObject("tsbActivityNode.Image")));
            this.tsbActivityNode.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbActivityNode.Name = "tsbActivityNode";
            this.tsbActivityNode.Size = new System.Drawing.Size(34, 34);
            this.tsbActivityNode.Text = "Activity Node";
            this.tsbActivityNode.Click += new System.EventHandler(this.tsbActivityNode_Click);
            // 
            // tsbQueue
            // 
            this.tsbQueue.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbQueue.Image = ((System.Drawing.Image)(resources.GetObject("tsbQueue.Image")));
            this.tsbQueue.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbQueue.Name = "tsbQueue";
            this.tsbQueue.Size = new System.Drawing.Size(34, 34);
            this.tsbQueue.Text = "Queue Node";
            this.tsbQueue.Click += new System.EventHandler(this.tsbQueue_Click);
            // 
            // entityArcToolBar
            // 
            this.entityArcToolBar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.entityArcToolBar.Image = ((System.Drawing.Image)(resources.GetObject("entityArcToolBar.Image")));
            this.entityArcToolBar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.entityArcToolBar.Name = "entityArcToolBar";
            this.entityArcToolBar.Size = new System.Drawing.Size(34, 34);
            this.entityArcToolBar.Text = "Entity Arc";
            this.entityArcToolBar.Click += new System.EventHandler(this.entityArcToolBar_Click);
            // 
            // resArcToaolBar
            // 
            this.resArcToaolBar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.resArcToaolBar.Image = ((System.Drawing.Image)(resources.GetObject("resArcToaolBar.Image")));
            this.resArcToaolBar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.resArcToaolBar.Name = "resArcToaolBar";
            this.resArcToaolBar.Size = new System.Drawing.Size(34, 34);
            this.resArcToaolBar.Text = "Resource Arc";
            this.resArcToaolBar.Click += new System.EventHandler(this.resArcToaolBar_Click);
            // 
            // toolStrip4
            // 
            this.toolStrip4.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip4.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStrip4.ImageScalingSize = new System.Drawing.Size(30, 30);
            this.toolStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbLeft,
            this.tsbCenter,
            this.tsbRight,
            this.tsbTop,
            this.tsbMiddle,
            this.tsbBottom,
            this.toolStripSeparator4,
            this.tsbGrid,
            this.tsbLayout});
            this.toolStrip4.Location = new System.Drawing.Point(151, 0);
            this.toolStrip4.Name = "toolStrip4";
            this.toolStrip4.Size = new System.Drawing.Size(266, 37);
            this.toolStrip4.TabIndex = 8;
            // 
            // tsbLeft
            // 
            this.tsbLeft.AutoSize = false;
            this.tsbLeft.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbLeft.Image = ((System.Drawing.Image)(resources.GetObject("tsbLeft.Image")));
            this.tsbLeft.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbLeft.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLeft.Name = "tsbLeft";
            this.tsbLeft.Size = new System.Drawing.Size(30, 30);
            this.tsbLeft.Text = "Align Left";
            this.tsbLeft.Click += new System.EventHandler(this.tsbLeft_Click);
            // 
            // tsbCenter
            // 
            this.tsbCenter.AutoSize = false;
            this.tsbCenter.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCenter.Image = ((System.Drawing.Image)(resources.GetObject("tsbCenter.Image")));
            this.tsbCenter.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCenter.Name = "tsbCenter";
            this.tsbCenter.Size = new System.Drawing.Size(30, 30);
            this.tsbCenter.Text = "Align Center";
            this.tsbCenter.Click += new System.EventHandler(this.tsbCenter_Click);
            // 
            // tsbRight
            // 
            this.tsbRight.AutoSize = false;
            this.tsbRight.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRight.Image = ((System.Drawing.Image)(resources.GetObject("tsbRight.Image")));
            this.tsbRight.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRight.Name = "tsbRight";
            this.tsbRight.Size = new System.Drawing.Size(30, 30);
            this.tsbRight.Text = "Align Right";
            this.tsbRight.Click += new System.EventHandler(this.tsbRight_Click);
            // 
            // tsbTop
            // 
            this.tsbTop.AutoSize = false;
            this.tsbTop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbTop.Image = ((System.Drawing.Image)(resources.GetObject("tsbTop.Image")));
            this.tsbTop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTop.Name = "tsbTop";
            this.tsbTop.Size = new System.Drawing.Size(30, 30);
            this.tsbTop.Text = "Align Top";
            this.tsbTop.Click += new System.EventHandler(this.tsbTop_Click);
            // 
            // tsbMiddle
            // 
            this.tsbMiddle.AutoSize = false;
            this.tsbMiddle.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMiddle.Image = ((System.Drawing.Image)(resources.GetObject("tsbMiddle.Image")));
            this.tsbMiddle.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbMiddle.Name = "tsbMiddle";
            this.tsbMiddle.Size = new System.Drawing.Size(30, 30);
            this.tsbMiddle.Text = "Align Middle";
            this.tsbMiddle.Click += new System.EventHandler(this.tsbMiddle_Click);
            // 
            // tsbBottom
            // 
            this.tsbBottom.AutoSize = false;
            this.tsbBottom.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbBottom.Image = ((System.Drawing.Image)(resources.GetObject("tsbBottom.Image")));
            this.tsbBottom.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbBottom.Name = "tsbBottom";
            this.tsbBottom.Size = new System.Drawing.Size(30, 30);
            this.tsbBottom.Text = "Align Bottom";
            this.tsbBottom.Click += new System.EventHandler(this.tsbBottom_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 23);
            // 
            // tsbGrid
            // 
            this.tsbGrid.Checked = true;
            this.tsbGrid.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsbGrid.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbGrid.Image = ((System.Drawing.Image)(resources.GetObject("tsbGrid.Image")));
            this.tsbGrid.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbGrid.Name = "tsbGrid";
            this.tsbGrid.Size = new System.Drawing.Size(34, 34);
            this.tsbGrid.Text = "Grid";
            this.tsbGrid.Click += new System.EventHandler(this.tsbGrid_Click);
            // 
            // tsbLayout
            // 
            this.tsbLayout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbLayout.Image = ((System.Drawing.Image)(resources.GetObject("tsbLayout.Image")));
            this.tsbLayout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLayout.Name = "tsbLayout";
            this.tsbLayout.Size = new System.Drawing.Size(34, 34);
            this.tsbLayout.Text = "Automatic Layout";
            this.tsbLayout.Click += new System.EventHandler(this.tsbLayout_Click);
            // 
            // toolStrip2
            // 
            this.toolStrip2.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStrip2.ImageScalingSize = new System.Drawing.Size(30, 30);
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbZoomIn,
            this.tsbZoomOut,
            this.tsbZoomFit,
            this.tscbZoom});
            this.toolStrip2.Location = new System.Drawing.Point(420, 0);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(191, 37);
            this.toolStrip2.TabIndex = 7;
            // 
            // tsbZoomIn
            // 
            this.tsbZoomIn.AutoSize = false;
            this.tsbZoomIn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbZoomIn.Image = ((System.Drawing.Image)(resources.GetObject("tsbZoomIn.Image")));
            this.tsbZoomIn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZoomIn.Name = "tsbZoomIn";
            this.tsbZoomIn.Size = new System.Drawing.Size(34, 34);
            this.tsbZoomIn.Text = "Zoom In";
            this.tsbZoomIn.Click += new System.EventHandler(this.tsbZoomIn_Click);
            // 
            // tsbZoomOut
            // 
            this.tsbZoomOut.AutoSize = false;
            this.tsbZoomOut.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbZoomOut.Image = ((System.Drawing.Image)(resources.GetObject("tsbZoomOut.Image")));
            this.tsbZoomOut.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZoomOut.Name = "tsbZoomOut";
            this.tsbZoomOut.Size = new System.Drawing.Size(34, 34);
            this.tsbZoomOut.Text = "Zoom Out";
            this.tsbZoomOut.Click += new System.EventHandler(this.tsbZoomOut_Click);
            // 
            // tsbZoomFit
            // 
            this.tsbZoomFit.AutoSize = false;
            this.tsbZoomFit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbZoomFit.Image = ((System.Drawing.Image)(resources.GetObject("tsbZoomFit.Image")));
            this.tsbZoomFit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZoomFit.Name = "tsbZoomFit";
            this.tsbZoomFit.Size = new System.Drawing.Size(34, 34);
            this.tsbZoomFit.Text = "Zoom to fit";
            this.tsbZoomFit.Click += new System.EventHandler(this.tsbZoomFit_Click);
            // 
            // tscbZoom
            // 
            this.tscbZoom.Items.AddRange(new object[] {
            "10%",
            "25%",
            "50%",
            "65%",
            "75%",
            "100%",
            "200%",
            "300%",
            "400%"});
            this.tscbZoom.Name = "tscbZoom";
            this.tscbZoom.Size = new System.Drawing.Size(75, 23);
            this.tscbZoom.Text = "100%";
            this.tscbZoom.SelectedIndexChanged += new System.EventHandler(this.tscbZoom_SelectedIndexChanged);
            // 
            // ActivityCycleDiagramWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(823, 480);
            this.Controls.Add(this.toolStripContainer1);
            this.KeyPreview = true;
            this.Name = "ActivityCycleDiagramWindow";
            this.Text = "Activity Graph Diagram Window";
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.toolStrip4.ResumeLayout(false);
            this.toolStrip4.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbActivityNode;
        private System.Windows.Forms.ToolStripButton tsbQueue;
        private System.Windows.Forms.ToolStripButton tsbZoomIn;
        private System.Windows.Forms.ToolStripButton tsbZoomOut;
        private System.Windows.Forms.ToolStripButton tsbZoomFit;
        private System.Windows.Forms.ToolStripComboBox tscbZoom;
        private System.Windows.Forms.ToolStrip toolStrip4;
        private System.Windows.Forms.ToolStripButton tsbLeft;
        private System.Windows.Forms.ToolStripButton tsbCenter;
        private System.Windows.Forms.ToolStripButton tsbRight;
        private System.Windows.Forms.ToolStripButton tsbTop;
        private System.Windows.Forms.ToolStripButton tsbMiddle;
        private System.Windows.Forms.ToolStripButton tsbBottom;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton tsbGrid;
        private System.Windows.Forms.ToolStripButton tsbLayout;
        private System.Windows.Forms.ToolStripButton entityArcToolBar;
        private System.Windows.Forms.ToolStripButton resArcToaolBar;
        private System.Windows.Forms.ToolStrip toolStrip2;
    }
}