﻿using DHKANG.SEA.UI.ETTEditor;
using DHKANG.SEA.UI.Modeling;
using Northwoods.Go;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DHKANG.SEA.UI.ATTEditor
{
    public delegate void ActivityPropertyChangedEventHandler(string name);
    public delegate void QueuePropertyChangedEventHandler(string name);

    public class ActivityCycleDiagramView : GoView
    {
        #region Member Variables
        public static int LastID = 0;
        public static int LinkCount = 0;
        public bool AutoConnect = true;


        private InsertionMode _CurrentMode = InsertionMode.None;
        private ZoomHandler _ZoomHandler;

        private PointF myOriginalDocPosition = new PointF();
        private float myOriginalDocScale = 1.0f;
        private bool myOriginalScale = true;
        private string myFileName = null;

        public static readonly float ARCATTRIBUTE_FONTSIZE = 7.0f;
        public static readonly Color ARCATTRIBUTE_COLOR = Color.Blue;
        #endregion

        #region Properties
        public InsertionMode InsertionMode
        {
            get { return _CurrentMode; }
            set { _CurrentMode = value; }
        }

        public ZoomHandler ZoomHandler
        {
            get { return _ZoomHandler; }
        }
        
        /// <summary>
        /// A convenience property for getting the view's GoDocument as a GraphDoc.
        /// </summary>
        public ActivityCycleDiagramDocument Doc
        {
            get { return this.Document as ActivityCycleDiagramDocument; }
        }

        public string FileName
        {
            get { return myFileName; }
            set { myFileName = value; }
        }

        public List<ActivityNode> ActivityNodes
        {
            get
            {
                List<ActivityNode> rslt = new List<ActivityNode>();
                foreach (GoObject obj in this.Doc)
                {
                    if (obj is ActivityNode)
                    {
                        ActivityNode node = (ActivityNode)obj;
                        rslt.Add(node);
                    }
                }
                return rslt;
            }
        }

        public List<QueueNode> QueueNodes
        {
            get
            {
                List<QueueNode> rslt = new List<QueueNode>();

                foreach (GoObject obj in this.Doc)
                {
                    if (obj is QueueNode)
                    {
                        QueueNode node = (QueueNode)obj;
                        rslt.Add(node);
                     
                    }
                }

                return rslt;
            }
        }
        #endregion

        #region Events
        public ActivityPropertyChangedEventHandler ActivityPropertyChanged;
        public QueuePropertyChangedEventHandler QueuePropertyChanged;
        public event DocumentScaleChangedEventHandler ScaleChanged;

        #endregion

        #region Constructors
        public ActivityCycleDiagramView() : base()
        {
            this.GridSnapDrag = GoViewSnapStyle.Jump;
            this.GridStyle = GoViewGridStyle.Line;
            this.GridCellSize = new SizeF(10, 10);
            this.GridLineWidth = 0.1f;
            
            this.AllowLink = false;

            _ZoomHandler = new Modeling.ZoomHandler(this);
        }

        public ActivityCycleDiagramView(string name)
            : this()
        {
        }
        #endregion

        #region Methods
        /// <summary>
        /// A new GraphView will have a GraphDoc as its document.
        /// </summary>
        /// <returns>A <see cref="GraphDoc"/></returns>
        public override GoDocument CreateDocument()
        {
            ActivityCycleDiagramDocument doc = new ActivityCycleDiagramDocument("ACD Model");
            doc.UndoManager = new GoUndoManager();
            return doc;
        }

        private void UpdateDocInfo()
        {

        }

        protected override void OnPropertyChanged(PropertyChangedEventArgs evt)
        {
            base.OnPropertyChanged(evt);
            if (evt.PropertyName == "DocScale")
            {
                if (ScaleChanged != null && ScaleChanged.GetInvocationList().Length > 0)
                    ScaleChanged(this.DocScale);
            }
        }


        /*
        public static ActivityCycleDiagramView Parse(VisualATTModel model)
        {
            ActivityCycleDiagramView view = new ActivityCycleDiagramView(model.Name);
            //Model Header
            

            //StateSet
            Hashtable stateset = new Hashtable();
            foreach (VisualQueue state in model.QueueSet)
            {
                QueueNode node = view.Doc.InsertQueueNode(state);
                node.Label.Bold = true;
                stateset.Add(state.Name, node);
            }

            //ActivityTransitionSet
            Hashtable activityset = new Hashtable();
            foreach (VisualActivityTransition transition in model.ActivityTransitionSet)
            {
                ActivityNode node = view.Doc.InsertActivityNode(transition);
                activityset.Add(transition.Name, node);
            }

            //ArcSet
            foreach (VisualArc arc in model.ArcSet)
            {
                GoNode sourceNode = null;
                GoNode destinationNode = null;

                IGoPort srcPort = null;
                IGoPort destPort = null;
                if (stateset.ContainsKey(arc.Source))
                {
                    QueueNode node = (QueueNode)stateset[arc.Source];
                    sourceNode = node;

                    srcPort = node.FindPort(arc.SourcePort);
                }
                else if (activityset.ContainsKey(arc.Source))
                {
                    ActivityNode node = (ActivityNode)activityset[arc.Source];
                    sourceNode = node;

                    srcPort = node.FindPort(arc.SourcePort);
                }

                if (stateset.ContainsKey(arc.Destination))
                {
                    QueueNode node = (QueueNode)stateset[arc.Destination];
                    destinationNode = node;

                    destPort = node.FindPort(arc.DestinationPort);
                }
                else if (activityset.ContainsKey(arc.Destination))
                {
                    ActivityNode node = (ActivityNode)activityset[arc.Destination];
                    destinationNode = node;

                    destPort = node.FindPort(arc.DestinationPort);
                }

                if (sourceNode == null || destinationNode == null)
                {
                    System.Diagnostics.Debug.WriteLine("Can't find source or destination for a link (" + arc.Source + "," + arc.Destination + ")");
                    continue;
                }

                GoLabeledLink link = null;

                //Arc Type
                if (arc.Type == VisualArcType.Resource)
                {
                    link = GraphView.MakeResourceTypeLink();
                }
                else if (arc.Type == VisualArcType.Entity)
                {
                    link = GraphView.MakeEntityTypeLink();
                }
                link.FromPort = srcPort;
                link.ToPort = destPort;

                //Arc Style
                if (arc.Style == ArcStyle.Bezier)
                    link.Style = GoStrokeStyle.Bezier;
                else if (arc.Style == ArcStyle.Line)
                    link.Style = GoStrokeStyle.Line;
                else if (arc.Style == ArcStyle.RoundedLine)
                {
                    link.Style = GoStrokeStyle.RoundedLine;
                    link.Orthogonal = true;
                }
                else if (arc.Style == ArcStyle.RoundedLineWithJumpOvers)
                {
                    link.Style = GoStrokeStyle.RoundedLineWithJumpOvers;
                    link.Orthogonal = true;
                }

                //Arc Attributes
                GoText arcCond = (GoText)link.MidLabel;
                //arcCond.Text = "";
                //arcCond.Alignment = GoText.TopCenter;
                //arcCond.Font = new Font(FontFamily.GenericSansSerif, GraphView.ARCATTRIBUTE_FONTSIZE, FontStyle.Italic);
                //arcCond.TextColor = GraphView.ARCATTRIBUTE_COLOR;

                GoText arcWeight = (GoText)link.ToLabel;
                //arcWeight.Text = "";
                //arcWeight.Alignment = GoText.BottomLeft;
                //arcWeight.Font = new Font(FontFamily.GenericSansSerif, GraphView.ARCATTRIBUTE_FONTSIZE, FontStyle.Italic);
                //arcWeight.TextColor = GraphView.ARCATTRIBUTE_COLOR;

                //Arc Direction 
                if (sourceNode is ActivityNode && destinationNode is QueueNode)
                {
                    //outgoing arc
                    OutgoingArcPropertyDlalog arcdlg = new OutgoingArcPropertyDlalog(arc.Probability);
                    link.UserObject = arcdlg;

                    if (arc.Probability > 0)
                        arcCond.Text = arc.Probability.ToString();

                    if (arc.Multiplicity > 1)
                        arcWeight.Text = arc.Multiplicity.ToString();

                }
                else if (sourceNode is QueueNode && destinationNode is ActivityNode)
                {
                    //incoming arc
                    IncomingArcPropertyDialog arcdlg = new IncomingArcPropertyDialog(arc);
                    link.UserObject = arcdlg;

                    if (!string.IsNullOrEmpty(arc.Condition))
                        arcCond.Text = arc.Condition;

                    if (arc.Multiplicity > 1)
                        arcWeight.Text = arc.Multiplicity.ToString();

                }
                link.ToLabel = arcWeight;
                link.MidLabel = arcCond;

                view.Doc.LinksLayer.Add(link);
                if (link != null)
                {
                    view.Document.LinksLayer.Add(link.GoObject);
                    view.RaiseLinkCreated(link.GoObject);
                }
            }

            return view;
        }
        */
        public static Arc MakeEntityTypeLink()
        {
            Arc link = new Arc();
            link.ArcType = Model.ActivityObjects.OOAGArcType.Entity;
            return link;
        }

        /*
        public static GoLabeledLink MakeEntityTypeLink()
        {
            //straight line
            GoLabeledLink link = new GoLabeledLink();
            link.AvoidsNodes = true;
            link.Brush = Brushes.Black;
            link.ToArrow = true;
            link.ToArrowFilled = true;
            link.ToArrowStyle = GoStrokeArrowheadStyle.Polygon;
            link.Style = GoStrokeStyle.Line;//GoStrokeStyle.Bezier;// GoStrokeStyle.Bezier;
            link.ToArrowWidth = 4.0f;
            //link.Orthogonal = true;
            link.UserFlags = 1;//entity

            //Label for Arc Condition
            GoText lblCond = new GoText();
            lblCond.Selectable = false;
            lblCond.Editable = false;
            lblCond.Text = "";
            lblCond.Font = new Font(FontFamily.GenericSansSerif, ActivityCycleDiagramView.ARCATTRIBUTE_FONTSIZE, FontStyle.Italic);
            lblCond.TextColor = ActivityCycleDiagramView.ARCATTRIBUTE_COLOR;

            link.MidLabel = lblCond;
            link.MidLabelCentered = false;
            //Label for Arc Multiplicity
            GoText lblWeight = new GoText();
            lblWeight.Selectable = false;
            lblWeight.Editable = false;
            lblWeight.Text = "";
            lblWeight.Font = new Font(FontFamily.GenericSansSerif, ActivityCycleDiagramView.ARCATTRIBUTE_FONTSIZE, FontStyle.Italic);
            lblWeight.TextColor = ActivityCycleDiagramView.ARCATTRIBUTE_COLOR;

            link.ToLabel = lblWeight;
            link.ToLabelCentered = true;
            return link;
        }
        */


        public static Arc MakeResourceTypeLink()
        {
            //broken line            
            Arc link = new Arc();
            link.ArcType = Model.ActivityObjects.OOAGArcType.Resource;
            return link;
            /*
            link.AvoidsNodes = true;
            link.Brush = Brushes.Gray;
            link.ToArrow = true;
            link.ToArrowFilled = true;
            link.ToArrowStyle = GoStrokeArrowheadStyle.Polygon;
            link.ToArrowWidth = 4.0f;

            link.Style = GoStrokeStyle.RoundedLine; // GoStrokeStyle.Bezier;// GoStrokeStyle.Bezier;
            link.Orthogonal = true;

            Pen dashedPen = new Pen(Color.Gray);
            dashedPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            link.Pen = dashedPen;
            link.UserFlags = 0;//resource

            //Label for Arc Condition
            GoText lblCond = new GoText();
            lblCond.Selectable = false;
            lblCond.Editable = false;
            lblCond.Text = "";
            lblCond.FontSize = ActivityCycleDiagramView.ARCATTRIBUTE_FONTSIZE;
            lblCond.Italic = true;
            lblCond.TextColor = ActivityCycleDiagramView.ARCATTRIBUTE_COLOR;

            link.MidLabel = lblCond;
            link.MidLabel.AutoRescales = true;
            link.MidLabelCentered = false;

            //Label for Arc Multiplicity
            GoText lblWeight = new GoText();
            lblWeight.Selectable = false;
            lblWeight.Editable = false;
            lblWeight.Text = "";
            lblWeight.FontSize = 8;
            lblWeight.FontSize = ActivityCycleDiagramView.ARCATTRIBUTE_FONTSIZE;
            lblWeight.Italic = true;
            lblWeight.TextColor = ActivityCycleDiagramView.ARCATTRIBUTE_COLOR;

            link.ToLabel = lblWeight;
            link.ToLabelCentered = true;

            return link;
            */
        }

        public void AllowEntityArc()
        {
            //change to straight line
            this.AllowLink = true;
            Arc link = ActivityCycleDiagramView.MakeEntityTypeLink();
            //link.ToArrowFilled = false;
            //link.ToArrow = true;
            link.ToArrowWidth = 4.0f;
            //link.ToArrowShaftLength = 0.1f;
            //link.ToArrowStyle = GoStrokeArrowheadStyle.

            //this.NewGoLink = link.RealLink;
            this.NewGoLabeledLink = link;
        }

        public void AllowResourceArc()
        {
            this.AllowLink = true;
            Arc link = ActivityCycleDiagramView.MakeResourceTypeLink();
            //link.ToArrowWidth = 4.0f;
            //link.ToArrowLength = 1;
            //this.NewGoLink = link;
            this.NewGoLabeledLink = link;
        }

        #endregion

        #region Node Arrange methods
        //align all object's left sides to the left side of the primary selection
        public virtual void AlignLeftSides()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float X = obj.SelectionObject.Left;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Left = X;
                }
                FinishTransaction("Align Left Sides");
            }
            else
            {
                //MessageBox.Show("Alignment failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        //align all object's horizontal centers to the horizontal center of the primary selection
        public virtual void AlignHorizontalCenters()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float X = obj.SelectionObject.Center.X;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Center = new PointF(X, t.Center.Y);
                }
                FinishTransaction("Align Horizontal Centers");
            }
            else
            {
                // MessageBox.Show("Alignment failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        //align all object's right sides to the right side of the primary selection
        public virtual void AlignRightSides()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float X = obj.SelectionObject.Right;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Right = X;
                }
                FinishTransaction("Align Right Sides");
            }
            else
            {
                //MessageBox.Show("Alignment failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        //align all object's tops to the top of the primary selection
        public virtual void AlignTops()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float Y = obj.SelectionObject.Top;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Top = Y;
                }
                FinishTransaction("Align Tops");
            }
            else
            {
                // MessageBox.Show("Alignment failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        //align all object's vertical centers to the vertical center of the primary selection
        public virtual void AlignVerticalCenters()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float Y = obj.SelectionObject.Center.Y;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Center = new PointF(t.Center.X, Y);
                }
                FinishTransaction("Align Vertical Centers");
            }
            else
            {
                //MessageBox.Show("Alignment failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        //align all object's bottoms to the bottom of the primary selection
        public virtual void AlignBottoms()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float Y = obj.SelectionObject.Bottom;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Bottom = Y;
                }
                FinishTransaction("Align Bottoms");
            }
            else
            {
                //MessageBox.Show("Alignment failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        // this makes the widths of all objects equal to the width of the main selection.
        public virtual void MakeWidthsSame()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float W = obj.SelectionObject.Width;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Width = W;
                }
                FinishTransaction("Same Widths");
            }
            else
            {
                //MessageBox.Show("Sizing failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        // this makes the heights of all objects equal to the height of the main selection.
        public virtual void MakeHeightsSame()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float H = obj.SelectionObject.Height;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Height = H;
                }
                FinishTransaction("Same Heights");
            }
            else
            {
                // MessageBox.Show("Sizing failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        // this makes the heights and widths of all objects equal to the height and
        //width of the main selection.
        public virtual void MakeSizesSame()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                SizeF S = obj.SelectionObject.Size;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Size = S;
                }
                FinishTransaction("Same Sizes");
            }
            else
            {
                //MessageBox.Show("Sizing failure: Primary Selection is empty or a link instead of a node.");
            }
        }
        #endregion

        #region Zoom Control methods
        public virtual void ZoomIn()
        {
            myOriginalScale = true;
            float newscale = (float)(Math.Round(this.DocScale / 0.9f * 100) / 100);
            this.DocScale = newscale;
        }

        public virtual void ZoomOut()
        {
            myOriginalScale = true;
            float newscale = (float)(Math.Round(this.DocScale * 0.9f * 100) / 100);
            this.DocScale = newscale;
        }

        public virtual void ZoomNormal()
        {
            myOriginalScale = true;
            this.DocScale = 1;
        }

        public virtual void Zoom(float scale)
        {
            myOriginalScale = true;
            this.DocScale = scale;
        }

        public virtual void ZoomToFit()
        {
            if (myOriginalScale)
            {
                myOriginalDocPosition = this.DocPosition;
                myOriginalDocScale = this.DocScale;
                RescaleToFit();
            }
            else
            {
                this.DocPosition = myOriginalDocPosition;
                this.DocScale = myOriginalDocScale;
            }
            myOriginalScale = !myOriginalScale;
        }
        #endregion

        #region OnBackground Single Clicked
        private ActivityNode doCreateActivityVertex(GoInputEventArgs evt)
        {
            ActivityCycleDiagramDocument doc = (ActivityCycleDiagramDocument)this.Document;

            int noActivityVertice = 0;
            foreach (GoObject obj in this.Doc)
            {
                if (obj is ActivityNode)
                {
                    noActivityVertice++;
                }
            }

            ActivityNode node = (ActivityNode)doc.InsertActivityNode(evt.DocPoint.X, evt.DocPoint.Y);

            if (noActivityVertice == 0)
            {
                node.Activity.IsEnabled= true;
            }

            this.Update();
            this.UpdateView();

            return node;
        }


        private QueueNode doCreateQueueVertex(GoInputEventArgs evt)
        {
            ActivityCycleDiagramDocument doc = (ActivityCycleDiagramDocument)this.Document;

            QueueNode node = (QueueNode)doc.InsertQueueNode(evt.DocPoint.X, evt.DocPoint.Y);

            this.Update();
            this.UpdateView();

            return node;
        }

        private ScheduleNode doCreateScheduleNode(GoInputEventArgs evt)
        {
            ActivityCycleDiagramDocument doc = (ActivityCycleDiagramDocument)this.Document;

            ScheduleNode node = (ScheduleNode)doc.InsertScheduleNode(evt.DocPoint.X, evt.DocPoint.Y);

            this.Update();
            this.UpdateView();

            return node;
        }

        #endregion
        #region Overiden Methods

        protected override void OnDocumentChanged(Object sender, GoChangedEventArgs evt)
        {
            base.OnDocumentChanged(sender, evt);
            if (evt.Hint == GoLayer.ChangedObject)
            {

            }
            else if (evt.Hint == GoLayer.InsertedObject)
            {
                if (evt.Object is IGoLink)
                {
                    //MainApp.App.SetStatusMessage("Inserted a link");
                }
            }
            else if (evt.Hint == GoLayer.RemovedObject)
            {
                if (evt.Object is IGoLink)
                {
                    //MainApp.App.SetStatusMessage("Removed a link");
                }
                /*
                if (evt.GoObject == MainForm.App.GetPropertiesObject())
                    if (this.Selection.Primary != null)
                        MainForm.App.SetPropertiesInfo(this, this.Selection.Primary);
                    else
                        MainForm.App.SetPropertiesInfo(this, this.Document);
                 * */
            }
            else if (evt.Hint == GoDocument.ChangedName ||
                     evt.Hint == GoDocument.RepaintAll || evt.Hint == GoDocument.FinishedUndo || evt.Hint == GoDocument.FinishedRedo)
            {
                UpdateDocInfo();
            }
        }

        protected override void OnBackgroundSingleClicked(GoInputEventArgs evt)
        {
            base.OnBackgroundSingleClicked(evt);

            switch (_CurrentMode)
            {
                case UI.InsertionMode.ActivityVertex:
                    {
                        doCreateActivityVertex(evt); break;
                    }
                case UI.InsertionMode.QueueVertex:
                    {
                        doCreateQueueVertex(evt); break;
                    }
                case UI.InsertionMode.Schedule:
                    {
                        doCreateScheduleNode(evt); break;
                    }
            }
        }

        protected override void OnBackgroundDoubleClicked(GoInputEventArgs evt)
        {
            base.OnBackgroundDoubleClicked(evt);

            ActivityCycleDiagramDocument doc = (ActivityCycleDiagramDocument)this.Document;
            /*
            if (MainApp.App.Mode == DrawMode.None)
            {
                //show model property dialog
                string oldName = doc.PropertyDialog.ModelName;
                doc.PropertyDialog.ShowDialog();
                if (doc.PropertyDialog.DialogResult2 == DialogResult.OK)
                {
                    MainApp.App.ChangeModelName(oldName, doc.PropertyDialog.ModelName);
                }
            }
            */
        }

        protected override void OnObjectContextClicked(GoObjectEventArgs evt)
        {
            base.OnObjectContextClicked(evt);

            if (evt.MouseEventArgs.Button == MouseButtons.Right)
            {
                ContextMenuStrip m = new ContextMenuStrip();

                if (evt.GoObject is GoLink)
                {
                    ToolStripItem m1 = m.Items.Add("Straight Line");
                    m1.Click += new EventHandler(OnStraightLineMenuItemClicked);
                    m1.Tag = evt.GoObject.ParentNode;
                    ToolStripItem m2 = m.Items.Add("Broken Line");
                    m2.Click += new EventHandler(OnBrokenLineMenuItemClicked);
                    m2.Tag = evt.GoObject.ParentNode;
                    ToolStripItem m3 = m.Items.Add("Curved Line");
                    m3.Click += new EventHandler(OnCurvedLineMenuItemClicked);
                    m3.Tag = evt.GoObject.ParentNode;
                    ToolStripItem m4 = m.Items.Add("-");

                    /*
                    ToolStripMenuItem ddEdgeType = new ToolStripMenuItem("Edge Type");
                    ToolStripMenuItem schedulingEdgeType = new ToolStripMenuItem("Scheduling Edge");
                    schedulingEdgeType.Click += new EventHandler(OnSchedulingEdgeMenuIetmClicked);
                    schedulingEdgeType.Tag = evt.GoObject.ParentNode;
                    ToolStripMenuItem cancelingEdgeType = new ToolStripMenuItem("Canceling Edge");
                    cancelingEdgeType.Click += new EventHandler(OnCancelingEdgeMenuIetmClicked);
                    cancelingEdgeType.Tag = evt.GoObject.ParentNode;

                    ddEdgeType.DropDownItems.Add(schedulingEdgeType);
                    ddEdgeType.DropDownItems.Add(cancelingEdgeType);
                    m.Items.Add(ddEdgeType);
                    */
                }

                m.Tag = evt.GoObject.ParentNode;
                m.Show(this, evt.ViewPoint);
            }

            /*
            base.OnObjectContextClicked(evt);
            if (evt.MouseEventArgs.Button == MouseButtons.Right)
            {
                ContextMenu m = new ContextMenu();

                MenuItem mCut = m.MenuItems.Add("Cu&t", new EventHandler(OnCutMenuItemClicked));
                MenuItem mCopy = m.MenuItems.Add("&Copy", new EventHandler(OnCopyMenuItemClicked));
                MenuItem mPaste = m.MenuItems.Add("&Paste", new EventHandler(OnPasteMenuItemClicked));
                MenuItem mDel = m.MenuItems.Add("&Delete", new EventHandler(OnDeleteMenuItemClicked));
                m.MenuItems.Add("-");
                mCut.Enabled = false;
                mCopy.Enabled = false;
                mPaste.Enabled = false;

                m.MenuItems.Add("-");
                if (evt.GoObject.ParentNode is ActivityNode)
                {
                    ActivityNode node = (ActivityNode)evt.GoObject.ParentNode;

                    if (!node.PropertyDialog.IsInitialActivity)
                    {
                        MenuItem m1 = m.MenuItems.Add("&Set as Initial Activity", new EventHandler(OnSetInitialActivityMenuItemClicked));
                    }
                    else
                    {
                        MenuItem m1 = m.MenuItems.Add("&Set as Initial Activity", new EventHandler(OnSetInitialActivityMenuItemClicked));
                        m1.Checked = true;
                    }
                }
                else if (evt.GoObject is GoLink)
                {
                    MenuItem m1 = m.MenuItems.Add("Straight Line", new EventHandler(OnStraightLineMenuItemClicked));
                    MenuItem m2 = m.MenuItems.Add("Broken Line", new EventHandler(OnBrokenLineMenuItemClicked));
                    MenuItem m3 = m.MenuItems.Add("Curved Line", new EventHandler(OnCurvedLineMenuItemClicked));
                    MenuItem m4 = m.MenuItems.Add("-");

                    //m3.Checked = true;
                    m.MenuItems.Add("-");
                }

                MenuItem mProperty = m.MenuItems.Add("P&roperty", new EventHandler(OnPropertyMenuItemClicked));
                m.Tag = evt.GoObject.ParentNode;
                m.Show(this, evt.ViewPoint);
            }
            */
        }

        protected override void OnObjectLostSelection(GoSelectionEventArgs evt)
        {
            if (evt.GoObject is MultiPortNode)
            {
                MultiPortNode n = (MultiPortNode)evt.GoObject;
                n.HidePorts();
            }

            base.OnObjectLostSelection(evt);
        }

        private GoObject _HoverObject = null;
        protected override void OnObjectEnterLeave(GoObjectEnterLeaveEventArgs evt)
        {
            //System.Diagnostics.Debug.WriteLine("ObjectEnterLeave...");

            if (_CurrentMode == InsertionMode.EntityArc ||
                _CurrentMode == InsertionMode.ResourceArc)
            {
                if (evt.To != null)
                {
                    if (evt.To.ParentNode is ActivityNode)
                    {
                        ((ActivityNode)evt.To.ParentNode).ShowPorts();
                    }
                    else if (evt.To.ParentNode is QueueNode)
                    {
                        ((QueueNode)evt.To.ParentNode).ShowPorts();
                    }
                }
                else if (evt.From.ParentNode != null)
                {
                    if (evt.From.ParentNode is ActivityNode)
                    {
                        ((ActivityNode)evt.From.ParentNode).HidePorts();
                    }
                    else if (evt.From.ParentNode is QueueNode)
                    {
                        ((QueueNode)evt.From.ParentNode).HidePorts();
                    }
                }
            }
            
            base.OnObjectEnterLeave(evt);
        }

        protected override void OnObjectSingleClicked(GoObjectEventArgs evt)
        {
            if (evt.GoObject.ParentNode is MultiPortNode)
            {
                MultiPortNode n = (MultiPortNode)evt.GoObject.ParentNode;
                n.ShowPorts();
            }
            base.OnObjectSingleClicked(evt);
        }

        protected override void OnObjectDoubleClicked(GoObjectEventArgs evt)
        {
            base.OnObjectDoubleClicked(evt);
        }

        #endregion

        #region Context MenuItem Handlers
        private void OnCutMenuItemClicked(object obj, EventArgs args)
        {

        }

        private void OnCopyMenuItemClicked(object obj, EventArgs args)
        {
        }

        private void OnPasteMenuItemClicked(object obj, EventArgs args)
        {

        }

        private void OnDeleteMenuItemClicked(object obj, EventArgs args)
        {
            ToolStripMenuItem m = (ToolStripMenuItem)obj;

            if (m.Tag != null && m.Tag is GoObject)
            {
                this.Doc.Remove((GoObject)m.Tag);

            }
        }

        private void OnStraightLineMenuItemClicked(object obj, EventArgs args)
        {
            ToolStripMenuItem m = (ToolStripMenuItem)obj;

            if (m.Tag is GoLabeledLink)
            {
                GoLabeledLink link = (GoLabeledLink)m.Tag;
                link.Style = GoStrokeStyle.Line;
                link.Orthogonal = false;
                link.CalculateStroke();
            }
        }

        private void OnBrokenLineMenuItemClicked(object obj, EventArgs args)
        {
            ToolStripMenuItem m = (ToolStripMenuItem)obj;

            if (m.Tag is GoLabeledLink)
            {
                GoLabeledLink link = (GoLabeledLink)m.Tag;
                link.Style = GoStrokeStyle.RoundedLine;
                link.Orthogonal = true;
            }
        }

        private void OnCurvedLineMenuItemClicked(object obj, EventArgs args)
        {
            ToolStripMenuItem m = (ToolStripMenuItem)obj;

            if (m.Tag is GoLabeledLink)
            {
                GoLabeledLink link = (GoLabeledLink)m.Tag;
                link.Style = GoStrokeStyle.Bezier;
            }
        }

        private void OnSetInitialActivityMenuItemClicked(object obj, EventArgs args)
        {
            ToolStripMenuItem m = (ToolStripMenuItem)obj;

            if (m.Tag != null)
            {
                if (m.Tag is ActivityNode)
                {
                    ActivityNode node = (ActivityNode)m.Tag;

                    m.Checked = !m.Checked;
                    /*
                    if (!node.PropertyDialog.IsInitialActivity)
                    {
                        node.PropertyDialog.IsInitialActivity = true;
                        node.Brush = Brushes.LightGray;
                    }
                    else
                    {
                        node.PropertyDialog.IsInitialActivity = false;
                        node.Brush = Brushes.Transparent;
                    }
                    */
                }
            }
        }

        private void OnPropertyMenuItemClicked(object obj, EventArgs args)
        {
            MenuItem m = (MenuItem)obj;

            /*
            if (m.Parent.Tag != null)
            {
                if (m.Parent.Tag is ActivityNode)
                {
                    ActivityNode node = (ActivityNode)m.Parent.Tag;
                    ShowActivityDialog(node);
                }
                else if (m.Parent.Tag is QueueNode)
                {
                    QueueNode node = (QueueNode)m.Parent.Tag;
                    ShowQueueDialog(node);
                }
                else if (m.Parent.Tag is GoLabeledLink)
                {
                    GoLabeledLink link = (GoLabeledLink)m.Parent.Tag;
                    ShowArcDialog(link);
                }
            }
            */
        }
        #endregion

        #region Save & Open Methods

        public bool Save()
        {
            /*
            if (myFileName == null)
                return false;

            bool rslt = true;
            try
            {
                VisualATTModel model = this.ToVisualACDModel();

                XMLWriter writer = new XMLWriter();
                writer.Create(myFileName);
                writer.Write(model);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("[Save] got an error.");
                System.Diagnostics.Debug.WriteLine(ex.ToString());
                System.Diagnostics.Debug.WriteLine("---------------------");
                rslt = false;
            }

            return rslt;
            */

            return false;
        }

        public void setGrid(GoViewGridStyle ggstyle)
        {
            this.GridStyle = ggstyle;
            this.Grid.BrushColor = Color.DarkGray;
            this.GridCellSize = new SizeF((float)20, (float)20);
            //this.GridPenDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.Grid.PenWidth = (float).25;
            this.GridSnapDrag = GoViewSnapStyle.After;
        }

        #endregion

        #region Translation Methods
        /*
        public VisualATTModel ToVisualACDModel()
        {
            Dialogs.ModelPropertyDlg modelDlg = (Dialogs.ModelPropertyDlg)this.Doc.PropertyDialog;

            string modelName = modelDlg.ModelName;
            string modelDesc = modelDlg.Description;

            VisualATTModel model = new VisualATTModel(modelName, modelDesc);

            //StateSet
            List<QueueNode> queueNodes = this.Doc.QueueNodes;
            foreach (QueueNode node in queueNodes)
            {
                Dialogs.QueuePropertyDlg dlg = node.PropertyDialog;

                VisualQueue state = null;

                if (dlg.QueueType == QueueType.Regular)
                    state = new VisualQueue(
                                dlg.QueueName, dlg.QueueType, "int", dlg.InitialValue.ToString(),
                                node.Center.X, node.Center.Y);
                //node.Location.X, node.Location.Y);
                else
                    state = new VisualQueue(
                                dlg.QueueName, dlg.QueueType, "", "",
                                node.Center.X, node.Center.Y);
                //node.Location.X, node.Location.Y);

                model.AddState(state);
            }

            //ActivityTransitionSet
            List<ActivityNode> activityNodes = this.Doc.ActivityNodes;
            foreach (ActivityNode node in activityNodes)
            {
                Dialogs.ActivityPropertyDlg dlg = node.PropertyDialog;
                VisualActivityTransition transition =
                    new VisualActivityTransition(
                        dlg.ActivityName, dlg.Description, dlg.AtBeginCondition, dlg.AtBeginStateUpdate,
                        dlg.BTOEventName, dlg.BTOEventTime, dlg.AtEndStateUpdate, dlg.InfluencedActivities,
                        dlg.IsInitialActivity, dlg.Priority, node.Center.X, node.Center.Y);

                model.AddActivityTransition(transition);
            }
            //ArcSet
            List<GoLabeledLink> links = this.Doc.Arcs;
            foreach (GoLabeledLink link in links)
            {
                string source = "", destination = "";
                int destPort = 0;
                int srcPort = 0;

                VisualArcType type = VisualArcType.Entity;

                if (link.UserFlags == 0)
                    type = VisualArcType.Resource;

                if (link.FromNode is ActivityNode)
                {
                    ActivityNode fromNode = (ActivityNode)link.FromNode;
                    Dialogs.ActivityPropertyDlg dlg = fromNode.PropertyDialog;
                    source = dlg.ActivityName;

                    srcPort = fromNode.FindPortIndex(link.FromPort);
                }
                else if (link.FromNode is QueueNode)
                {
                    QueueNode fromNode = (QueueNode)link.FromNode;
                    Dialogs.QueuePropertyDlg dlg = fromNode.PropertyDialog;
                    source = dlg.QueueName;

                    srcPort = fromNode.FindPortIndex(link.FromPort);
                }

                if (link.ToNode is ActivityNode)
                {
                    ActivityNode toNode = (ActivityNode)link.ToNode;
                    Dialogs.ActivityPropertyDlg dlg = toNode.PropertyDialog;
                    destination = dlg.ActivityName;

                    destPort = toNode.FindPortIndex(link.ToPort);
                }
                else if (link.ToNode is QueueNode)
                {
                    QueueNode toNode = (QueueNode)link.ToNode;
                    Dialogs.QueuePropertyDlg dlg = toNode.PropertyDialog;
                    destination = dlg.QueueName;

                    destPort = toNode.FindPortIndex(link.ToPort);
                }

                VisualArc arc = null;

                ArcStyle style = ArcStyle.Bezier;
                if (link.Style == GoStrokeStyle.Line)
                    style = ArcStyle.Line;
                else if (link.Style == GoStrokeStyle.RoundedLine)
                    style = ArcStyle.RoundedLine;
                else if (link.Style == GoStrokeStyle.RoundedLineWithJumpOvers)
                    style = ArcStyle.RoundedLineWithJumpOvers;

                if (link.FromNode is ActivityNode && link.ToNode is QueueNode)
                {
                    //outgoing arc (probabilistic branching)
                    if (link.UserObject != null)
                    {
                        OutgoingArcPropertyDlalog dlg = (OutgoingArcPropertyDlalog)link.UserObject;

                        if (dlg.IsProbabilisticBranching)
                        {
                            float prob = dlg.Probability;
                            arc = new VisualArc(source, destination, type, srcPort, destPort, style, prob);
                        }
                        else
                        {
                            arc = new VisualArc(source, destination, type, srcPort, destPort, style);
                        }
                    }
                    else
                    {
                        arc = new VisualArc(source, destination, type, srcPort, destPort, style);
                    }
                }
                else if (link.FromNode is QueueNode && link.ToNode is ActivityNode)
                {
                    //incoming arc (batch size
                    if (link.UserObject != null)
                    {
                        IncomingArcPropertyDialog dlg =
                            (IncomingArcPropertyDialog)link.UserObject;

                        if (dlg.IsConditionArc)
                            arc = new VisualArc(source, destination, type, srcPort, destPort, style, dlg.ArcMultiplicity, dlg.ArcCondition);
                        else
                            arc = new VisualArc(source, destination, type, srcPort, destPort, style, dlg.ArcMultiplicity);
                    }
                    else
                    {
                        arc = new VisualArc(source, destination, type, srcPort, destPort);
                    }
                }

                model.AddArc(arc);
            }

            return model;
        }
        */

        public void LayerAction()
        {
            //TODO: Automatic Layout
        }
        #endregion

        #region Highliht Methods
        /*
        /// <summary>
        /// Set a highlight on an activity cycle
        /// </summary>
        /// <param name="cycle">Activity Cycle of states</param>
        /// <param name="hlSet">true or false</param>
        /// <param name="hlColor">color of highlight</param>
        public void SetHighightOnActivityCycle(VisualActivityCycle cycle, bool hlSet, Color hlColor)
        {
            string[] states = cycle.InActivityCycle.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

            this.ShadowColor = hlColor;
            this.ShadowOffset = new SizeF(0.0f, 0.0f);
            for (int i = 0; i < states.Length; i++)
            {
                //state 및 state 간 arc에 설정
                GoNode node = (GoNode)this.Document.FindNode(states[i], true, true);

                if (node != null)
                {
                    node.Shadowed = hlSet;
                    this.Update();
                    node.Text = node.Text;
                    if (node is ActivityNode)
                    {
                        ActivityNode aNode = (ActivityNode)node;
                        aNode.SetName(aNode.PropertyDialog.ActivityName);
                    }
                }
            }
            foreach (GoObject obj in this.Doc)
            {
                if (obj is GoLabeledLink)
                {
                    GoLabeledLink link = (GoLabeledLink)obj;
                    string source = "", dest = "";

                    if (link.FromNode is ActivityNode)
                        source = ((ActivityNode)link.FromNode).PropertyDialog.ActivityName;
                    else if (link.FromNode is QueueNode)
                        source = ((QueueNode)link.FromNode).PropertyDialog.QueueName;

                    if (link.ToNode is ActivityNode)
                        dest = ((ActivityNode)link.ToNode).PropertyDialog.ActivityName;
                    else if (link.ToNode is QueueNode)
                        dest = ((QueueNode)link.ToNode).PropertyDialog.QueueName;

                    string inCycle = cycle.InActivityCycle.ToLower();
                    if (inCycle.Contains(source.ToLower()) &&
                        inCycle.Contains(dest.ToLower()))
                    {
                        link.Highlight = hlSet;

                        if (hlSet)
                        {
                            link.HighlightPen = new Pen(hlColor);
                            link.HighlightPenWidth = 8.0f;
                        }
                    }
                }

            }
        }
        */
        #endregion
    }
}
