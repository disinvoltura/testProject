﻿using DHKANG.SEA.Model.ActivityObjects;
using DHKANG.SEA.Model;
using DHKANG.SEA.UI.ATTEditor;
using DHKANG.SEA.UI.ETTEditor;
using Microsoft.Msagl.Core.Geometry.Curves;
using Microsoft.Msagl.Core.Layout;
using Microsoft.Msagl.Miscellaneous;
using Northwoods.Go;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace DHKANG.SEA.UI.ATTEditor
{
    public delegate void ActivityCycleDiagramChangedEvent
                        (ChangedTarget target, ChangedType action, object before, object after);

    public partial class ActivityCycleDiagramWindow : DockContent
    {
        #region Member Variables
        private ActivityObjectModelEditor _Parent;
        private ActivityCycleDiagramView _View;
        #endregion

        #region Properties
        public float ViewScale { get { return _View.DocScale; } }

        public List<ActivityNode> ActivityNodeList
        {
            get { return _View.ActivityNodes; }
        }

        public List<QueueNode> QueueNodeList
        {
            get { return _View.QueueNodes; }
        }

        public List<Arc> ArcList
        {
            get { return _View.Doc.Arcs; }
        }

        public List<OOAGActivity> Activities
        {
            get
            {
                List<OOAGActivity> rslt = new List<OOAGActivity>();

                foreach (ActivityNode node in _View.ActivityNodes)
                {
                    OOAGActivity activity = node.Activity;
                    activity.X = node.Left;
                    activity.Y = node.Top;
                    activity.IsEnabled = node.Activity.IsEnabled;
                    activity.ID = node.Activity.ID;

                    rslt.Add(activity);
                }
                return rslt;
            }
        }

        public List<OOAGQueue> Queues
        {
            get
            {
                List<OOAGQueue> rslt = new List<OOAGQueue>();
                foreach (QueueNode node in _View.QueueNodes)
                {
                    node.Queue.X = node.Left;
                    node.Queue.Y = node.Top;
                    //OOAGQueue q = new OOAGQueue(node.Queue.Name, node.Queue.Parameters, node.Queue.Type, node.Queue.InitialValue, "");
                    //q.X = node.Left;
                    //q.Y = node.Top;

                    rslt.Add(node.Queue);
                }
                return rslt;
            }
        }

        public List<OOAGArc> Arcs
        {
            get
            {
                List<OOAGArc> rslt = new List<OOAGArc>();
                List<Arc> links = _View.Doc.Arcs;
                foreach (Arc link in links)
                {
                    Guid source = Guid.Empty;
                    Guid destination = Guid.Empty;
                    OOAGNodeType sourceType = OOAGNodeType.Activity;
                    OOAGNodeType destType = OOAGNodeType.Queue;
                    int destPort = 0;
                    int srcPort = 0;

                    OOAGArcType type = link.ArcType;

                    if (link.FromNode is ActivityNode)
                    {
                        ActivityNode fromNode = (ActivityNode)link.FromNode;
                        source = fromNode.Activity.ID;
                        srcPort = fromNode.FindPortIndex(link.FromPort);
                        sourceType = OOAGNodeType.Activity;
                    }
                    else if (link.FromNode is QueueNode)
                    {
                        QueueNode fromNode = (QueueNode)link.FromNode;
                        source = fromNode.Queue.ID;
                        srcPort = fromNode.FindPortIndex(link.FromPort);
                        sourceType = OOAGNodeType.Queue;
                    }

                    if (link.ToNode is ActivityNode)
                    {
                        ActivityNode toNode = (ActivityNode)link.ToNode;
                        destination = toNode.Activity.ID;
                        destPort = toNode.FindPortIndex(link.ToPort);
                        destType = OOAGNodeType.Activity;
                    }
                    else if (link.ToNode is QueueNode)
                    {
                        QueueNode toNode = (QueueNode)link.ToNode;
                        destination = toNode.Queue.ID;
                        destPort = toNode.FindPortIndex(link.ToPort);
                        destType = OOAGNodeType.Queue;
                    }

                    OOAGArc arc = null;

                    OOAGArcStyle style = link.ArcStyle;
                    if (link.FromNode is ActivityNode && link.ToNode is QueueNode)
                    {
                        //outgoing arc (probabilistic branching)
                        if (link.IsProbabilisticBranch)
                        {
                            float prob = link.Probability;
                            arc = new OOAGArc(source, sourceType, destination, destType, type, srcPort, destPort, style, prob);
                        }
                        else
                        {
                            arc = new OOAGArc(source, sourceType, destination, destType, type, srcPort, destPort, style);
                        }
                    }
                    else if (link.FromNode is QueueNode && link.ToNode is ActivityNode)
                    {
                        //incoming arc (batch size
                        if (link.UserObject != null)
                        {
                            if (link.IsConditionalArc)
                                arc = new OOAGArc(source, sourceType, destination, destType, type, srcPort, destPort, style, link.Multiplicity, link.Condition);
                            else
                                arc = new OOAGArc(source, sourceType, destination, destType, type, srcPort, destPort, style, link.Multiplicity);
                        }
                        else
                        {
                            arc = new OOAGArc(source, sourceType, destination, destType, type, srcPort, destPort, style);
                        }
                    }
                    rslt.Add(arc);
                }
                return rslt;
            }
        }

        public ActivityCycleDiagramView View { get { return _View; } }

        #endregion

        #region Events
        public event ActivityCycleDiagramChangedEvent Changed;//position changes are included
        public event DiagramSelectionChangedEventHandler SelectionChanged;
        public event DiagramObjectSelectedEventHandler ObjectSelected;

        #endregion

        #region Constructors
        public ActivityCycleDiagramWindow(ActivityObjectModelEditor parent)
        {
            _Parent = parent;
            InitializeComponent();

            _View = new ActivityCycleDiagramView();
            toolStripContainer1.ContentPanel.Controls.Add(_View);
            _View.Dock = DockStyle.Fill;

            _View.ObjectSingleClicked += new GoObjectEventHandler(OnViewObjectSingleClicked);
            _View.ObjectLostSelection += new GoSelectionEventHandler(OnViewObjectLostClicked);
            _View.LinkCreated += new GoSelectionEventHandler(OnViewLinkCreated);
            _View.DocumentChanged += new GoChangedEventHandler(OnViewDocumentChanged);
            _View.ScaleChanged += new DocumentScaleChangedEventHandler(OnViewScaleChanged);
            _View.SelectionFinished += new EventHandler(OnViewSelection);

            _View.InsertionMode = InsertionMode.EventVertex;
            _View.AutoConnect = true;
            _View.Grid.Visible = true;
        }
        #endregion

        #region Methods
        public void Update(OOAGActivityObjectModel model)
        {
            isUpdating = true;
            //StateSet
            Hashtable stateset = new Hashtable();
            foreach (OOAGQueue queue in model.Queues)
            {
                QueueNode node = _View.Doc.InsertQueueNode(queue);
                node.Label.Bold = true;
                stateset.Add(queue.ID, node);
            }

            //ActivityTransitionSet
            Hashtable activityset = new Hashtable();
            foreach (OOAGActivityTransition transition in model.ActivityTransitions)
            {
                ActivityNode node = _View.Doc.InsertActivityNode(transition);
                activityset.Add(transition.Activity.ID, node);
            }

            //ArcSet
            foreach (OOAGArc arc in model.Arcs)
            {
                GoNode sourceNode = null;
                GoNode destinationNode = null;

                IGoPort srcPort = null;
                IGoPort destPort = null;

                if (arc.SourceType == OOAGNodeType.Activity)
                {
                    ActivityNode node = null;
                    if (activityset.ContainsKey(arc.SourceId))
                        node = (ActivityNode)activityset[arc.SourceId];

                    if (node != null)
                    {
                        sourceNode = node;
                        srcPort = node.FindPort(arc.SourcePort);
                    }
                }
                else if (arc.SourceType == OOAGNodeType.Queue)
                {
                    QueueNode node = null;
                    if (stateset.ContainsKey(arc.SourceId))
                        node = (QueueNode)stateset[arc.SourceId];
                    if (node != null)
                    {
                        sourceNode = node;
                        srcPort = node.FindPort(arc.SourcePort);
                    }
                }
                if (arc.DestinationType == OOAGNodeType.Activity)
                {
                    ActivityNode node = null;
                    if (activityset.ContainsKey(arc.DestinationId))
                        node = (ActivityNode)activityset[arc.DestinationId];
                    if (node != null)
                    {
                        destinationNode = node;
                        destPort = node.FindPort(arc.DestinationPort);
                    }
                }
                else if (arc.DestinationType == OOAGNodeType.Queue)
                {
                    QueueNode node = null;
                    if (stateset.ContainsKey(arc.DestinationId))
                        node = (QueueNode)stateset[arc.DestinationId];
                    if (node != null)
                    {
                        destinationNode = node;
                        destPort = node.FindPort(arc.DestinationPort);
                    }
                }

                if (sourceNode == null || destinationNode == null)
                {
                    System.Diagnostics.Debug.WriteLine("Can't find source or destination for a link (" + arc.SourceId + "," + arc.DestinationId + ")");
                    continue;
                }

                Arc link = new Arc();
                //Arc Type
                if (arc.Type == OOAGArcType.Resource)
                {
                    link.ArcType = OOAGArcType.Resource;
                    //link = ActivityCycleDiagramView.MakeResourceTypeLink();
                }
                else if (arc.Type == OOAGArcType.Entity)
                {
                    link.ArcType = OOAGArcType.Entity;
                    //link = ActivityCycleDiagramView.MakeEntityTypeLink();
                }
                link.FromPort = srcPort;
                link.ToPort = destPort;

                //Arc Style
                if (arc.Style == OOAGArcStyle.Bezier)
                    link.Style = GoStrokeStyle.Bezier;
                else if (arc.Style == OOAGArcStyle.Line)
                    link.Style = GoStrokeStyle.Line;
                else if (arc.Style == OOAGArcStyle.RoundedLine)
                {
                    link.Style = GoStrokeStyle.RoundedLine;
                    link.Orthogonal = true;
                }
                else if (arc.Style == OOAGArcStyle.RoundedLineWithJumpOvers)
                {
                    link.Style = GoStrokeStyle.RoundedLineWithJumpOvers;
                    link.Orthogonal = true;
                }

                //Arc Attributes
                //GoText arcCond = (GoText)link.MidLabel;
                //GoText arcWeight = (GoText)link.ToLabel;

                //Arc Direction 
                if (sourceNode is ActivityNode && destinationNode is QueueNode)
                {
                    //outgoing arc
                    link.Probability = arc.Probability;
                    //arcCond.Text = arc.Probability.ToString();

                    link.Multiplicity = arc.Multiplicity;
                    //arcWeight.Text = arc.Multiplicity.ToString();
                }
                else if (sourceNode is QueueNode && destinationNode is ActivityNode)
                {
                    //incoming arc
                    link.Condition = arc.Condition;
                    //if (!string.IsNullOrEmpty(arc.Condition))
                    //    arcCond.Text = arc.Condition;

                    link.Multiplicity = arc.Multiplicity;
                    //if (arc.Multiplicity > 1)
                    //    arcWeight.Text = arc.Multiplicity.ToString();
                }
                //link.ToLabel = arcWeight;
                //link.MidLabel = arcCond;

                _View.Doc.LinksLayer.Add(link);
                if (link != null)
                {
                    _View.Document.LinksLayer.Add(link.GoObject);
                    _View.RaiseLinkCreated(link.GoObject);
                }
            }

            isUpdating = false;
        }

        public void OnATTChanged(string target, string action, string before, string after)
        {

        }
        #endregion

        #region Toolbar methods
        private void tsbActivityNode_Click(object sender, EventArgs e)
        {
            tsbActivityNode.Checked = !tsbActivityNode.Checked;

            if (tsbActivityNode.Checked)
            {
                _View.InsertionMode = InsertionMode.ActivityVertex;
                _View.AllowLink = false;

                tsbQueue.Checked = false;
                entityArcToolBar.Checked = false;
                resArcToaolBar.Checked = false;
            }
            else
                _View.InsertionMode = InsertionMode.None;
        }

        private void tsbQueue_Click(object sender, EventArgs e)
        {
            tsbQueue.Checked = !tsbQueue.Checked;

            if (tsbQueue.Checked)
            {
                _View.InsertionMode = InsertionMode.QueueVertex;
                _View.AllowLink = false;

                tsbActivityNode.Checked = false;
                entityArcToolBar.Checked = false;
                resArcToaolBar.Checked = false;
            }
            else
                _View.InsertionMode = InsertionMode.None;
        }


        private void entityArcToolBar_Click(object sender, EventArgs e)
        {
            entityArcToolBar.Checked = !entityArcToolBar.Checked;

            if (entityArcToolBar.Checked)
            {
                _View.InsertionMode = InsertionMode.EntityArc;
                _View.AllowEntityArc();

                tsbActivityNode.Checked = false;
                tsbQueue.Checked = false;
                resArcToaolBar.Checked = false;
            }
            else
                _View.InsertionMode = InsertionMode.None;
        }

        private void resArcToaolBar_Click(object sender, EventArgs e)
        {
            tsbQueue.Checked = !tsbQueue.Checked;

            if (tsbQueue.Checked)
            {
                _View.InsertionMode = InsertionMode.ResourceArc;
                _View.AllowResourceArc();

                tsbActivityNode.Checked = false;
                tsbQueue.Checked = false;
                entityArcToolBar.Checked = false;
            }
            else
                _View.InsertionMode = InsertionMode.None;
        }

        private void tsbGrid_Click(object sender, EventArgs e)
        {
            tsbGrid.Checked = !tsbGrid.Checked;
            _View.Grid.Visible = tsbGrid.Checked;
        }

        private void tsbLayout_Click(object sender, EventArgs e)
        {
            GeometryGraph graph = new GeometryGraph();

            double w = 30;
            double h = 20;

            Dictionary<string, GoNode> goNodeList =
                new Dictionary<string, GoNode>();

            Dictionary<string, Microsoft.Msagl.Core.Layout.Node> graphNodes =
                new Dictionary<string, Microsoft.Msagl.Core.Layout.Node>();
            foreach (GoObject obj in _View.Doc)
            {
                if (obj is GoNode)
                {
                    GoNode mpNode = (GoNode)obj;
                    Microsoft.Msagl.Core.Layout.Node gNode =
                        new Microsoft.Msagl.Core.Layout.Node(
                            new Ellipse(mpNode.Width, mpNode.Height, new Microsoft.Msagl.Core.Geometry.Point(mpNode.Center.X, mpNode.Center.Y)), mpNode.Text);

                    graph.Nodes.Add(gNode);
                    graphNodes.Add(mpNode.Text, gNode);
                    goNodeList.Add(mpNode.Text, mpNode);
                }
            }

            foreach (GoObject obj in _View.Doc)
            {
                if (obj is GoLink)
                {
                    GoLink link = (GoLink)obj;
                    GoNode fromNode = (GoNode)link.FromNode;
                    GoNode toNode = (GoNode)link.ToNode;

                    Microsoft.Msagl.Core.Layout.Node fromGraphNode = graphNodes[fromNode.Text];
                    Microsoft.Msagl.Core.Layout.Node toGraphNode = graphNodes[toNode.Text];

                    Edge edge = new Edge(fromGraphNode, toGraphNode) { Length = 1 };
                    graph.Edges.Add(edge);
                }
            }

            //var settings = new Microsoft.Msagl.Layout.Layered.SugiyamaLayoutSettings();
            //var settings = new Microsoft.Msagl.Layout.Incremental.FastIncrementalLayoutSettings();
            var settings = new Microsoft.Msagl.Layout.MDS.MdsLayoutSettings();
            LayoutHelpers.CalculateLayout(graph, settings, null);


            foreach (Microsoft.Msagl.Core.Layout.Node node in graph.Nodes)
            {
                string nodeName = (string)node.UserData;
                GoNode goNode = goNodeList[nodeName];
                goNode.Center = new PointF((float)node.Center.X, (float)node.Center.Y);
            }

            this.ZoomToFit();
            
        }
        #endregion

        #region winform methods
        private void ActivityCycleDiagramWindow_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                tsbActivityNode.Checked = false;
                tsbQueue.Checked = false;
                //tsbSchedulingLink.Checked = false;

                _View.AllowLink = false;
                _View.InsertionMode = InsertionMode.None;
            }
            else if (e.KeyCode == Keys.Add && e.Control)
            {
                ZoomIn();
            }
            else if (e.KeyCode == Keys.Subtract && e.Control)
            {
                ZoomOut();
            }
            else if (e.KeyCode == Keys.OemMinus && e.Control)
            {
                ZoomOut();
            }
            else if (e.KeyCode == Keys.Oemplus && e.Control)
            {
                ZoomIn();
            }
        }
        #endregion

        #region Zoom Control

        private void tsbZoomIn_Click(object sender, EventArgs e)
        {
            ZoomIn();
        }

        private void tsbZoomOut_Click(object sender, EventArgs e)
        {
            ZoomOut();
        }

        private void tsbZoomFit_Click(object sender, EventArgs e)
        {
            ZoomToFit();
        }

        private void tscbZoom_SelectedIndexChanged(object sender, EventArgs e)
        {
            string zoomScale = tscbZoom.Text;

            Zoom(zoomScale);
        }

        public void Zoom(string zoomScale)
        {
            float scale = 1.0f;
            if (zoomScale.Contains("%"))
                zoomScale = zoomScale.Substring(0, zoomScale.Length - 1);
            scale = float.Parse(zoomScale) / 100;

            _View.ZoomHandler.Zoom(scale);
        }

        public void SetZoomScale(float scale)
        {
            tscbZoom.Text = Math.Round(scale * 100, 0).ToString() + "%";
        }

        public void ZoomIn()
        {
            _View.ZoomHandler.ZoomIn();

            tscbZoom.Text = Math.Round(_View.DocScale * 100, 0).ToString() + "%";
        }

        public void ZoomToFit()
        {
            _View.ZoomHandler.ZoomToFit();
            tscbZoom.Text = Math.Round(_View.DocScale * 100, 0).ToString() + "%";
        }

        public void ZoomOut()
        {
            _View.ZoomHandler.ZoomOut();
            tscbZoom.Text = Math.Round(_View.DocScale * 100, 0).ToString() + "%";
        }
        #endregion

        #region Alignment Methods

        public void AlignLeftSides()
        {
            _View.AlignLeftSides();
        }

        public void AlignHorizontalCenters()
        {
            _View.AlignHorizontalCenters();
        }

        public void AlignRightSides()
        {
            _View.AlignRightSides();
        }

        public void AlignTops()
        {
            _View.AlignTops();
        }

        public void AlignVerticalCenters()
        {
            _View.AlignVerticalCenters();
        }

        public void AlignBottoms()
        {
            _View.AlignBottoms();
        }

        private void tsbLeft_Click(object sender, EventArgs e)
        {
            AlignLeftSides();
        }

        private void tsbCenter_Click(object sender, EventArgs e)
        {
            AlignHorizontalCenters();
        }

        private void tsbRight_Click(object sender, EventArgs e)
        {
            AlignRightSides();
        }

        private void tsbTop_Click(object sender, EventArgs e)
        {
            AlignTops();
        }

        private void tsbMiddle_Click(object sender, EventArgs e)
        {
            AlignVerticalCenters();
        }

        private void tsbBottom_Click(object sender, EventArgs e)
        {
            AlignBottoms();
        }
        #endregion

        #region GoView Event Handlers
        private string lastFromEventVertex = "";
        private string lastToEventVertex = "";
        private GoPort lastFromPort;
        private GoPort lastToPort;

        private void OnViewObjectSingleClicked(object sender, GoObjectEventArgs e)
        {
            if (e.GoObject.ParentNode != null)
            {
                if (e.GoObject.ParentNode is ScheduleNode)
                {
                    if (this.ObjectSelected != null &&
                             this.ObjectSelected.GetInvocationList().Length > 0)
                        this.ObjectSelected(null, e.GoObject.ParentNode);
                }
                else if (e.GoObject.ParentNode is ActivityNode)
                {
                    ActivityNode node = (ActivityNode)e.GoObject.ParentNode;
                    if (this.ObjectSelected != null && this.ObjectSelected.GetInvocationList().Length > 0)
                        this.ObjectSelected(null, node);
                }
                else if (e.GoObject.ParentNode is QueueNode)
                {
                    QueueNode node = (QueueNode)e.GoObject.ParentNode;
                    if (this.ObjectSelected != null && this.ObjectSelected.GetInvocationList().Length > 0)
                        this.ObjectSelected(null, node);
                }else if (e.GoObject.Parent is Arc)
                {
                    Arc arc = (Arc)e.GoObject.Parent;
                    if (arc.FromNode is ActivityNode)
                        lastFromEventVertex = ((ActivityNode)arc.FromNode).Text;
                    else if (arc.FromNode is QueueNode)
                        lastFromEventVertex = ((QueueNode)arc.FromNode).Text;

                    if (arc.ToNode is ActivityNode)
                        lastToEventVertex = ((ActivityNode)arc.ToNode).Text;
                    else if (arc.ToNode is QueueNode)
                        lastToEventVertex = ((QueueNode)arc.ToNode).Text;
                        
                    lastFromPort = (GoPort)arc.FromPort;
                    lastToPort = (GoPort)arc.ToPort;
                    if (this.ObjectSelected != null && this.ObjectSelected.GetInvocationList().Length > 0)
                        this.ObjectSelected(null, arc);
                }
            }
        }

        private void OnViewObjectLostClicked(object sender, GoSelectionEventArgs e)
        {
            if (this.ObjectSelected != null &&
                       this.ObjectSelected.GetInvocationList().Length > 0)
                this.ObjectSelected(null, null);
        }

        private void OnViewLinkCreated(object sender, GoSelectionEventArgs e)
        {
            /*
            if (e.GoObject is Link)
            {
                Link l = (Link)e.GoObject;

                if (l.LinkType == LinkType.SchedulingLink)
                {
                    while (_View.Doc.FindLink(ActivityCycleDiagramView.LastID) != null)
                    //while (_View.Doc.FindLink(EventGraphDiagramView.LastID) != null)
                    {
                        EventGraphDiagramView.LastID++;
                    }
                    l.LinkID = ActivityCycleDiagramView.LinkCount;
                    ActivityCycleDiagramView.LastID++;
                    ActivityCycleDiagramView.LinkCount++;
                }
            }
            else
            {
            }
            */
        }

        private bool isUpdating;

        private void OnViewDocumentChanged(object sender, GoChangedEventArgs e)
        {
            if (isUpdating)
                return;

            if (e.Hint == GoLayer.InsertedObject)
            {
                if (e.GoObject is ActivityNode)
                {
                    ActivityNode node = (ActivityNode)e.GoObject;
                    node.Activity.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
                    Changed(ChangedTarget.Activity, ChangedType.Added, "", node.Text);
                }
                else if (e.GoObject is QueueNode)
                {
                    QueueNode node = (QueueNode)e.GoObject;
                    node.Queue.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
                    Changed(ChangedTarget.Queue, ChangedType.Added, "", node.Text);
                }
                else if (e.GoObject is Arc)
                {
                    Arc link = (Arc)e.GoObject;
                    link.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
                    GoNode fromNode = (GoNode)link.FromNode;
                    GoNode toNode = (GoNode)link.ToNode;
                    Changed(ChangedTarget.Arc, ChangedType.Added, "", fromNode.Text + "->" + toNode.Text);
                }
                //UpdateHighlighting();
            }
            else if (e.Hint == GoLayer.RemovedObject)
            {
                if (e.GoObject is ActivityNode)
                {
                    ActivityNode node = (ActivityNode)e.GoObject;
                    Changed(ChangedTarget.Activity, ChangedType.Deleted, node.Text, "");
                }
                else if (e.GoObject is QueueNode)
                {
                    QueueNode node = (QueueNode)e.GoObject;
                    Changed(ChangedTarget.Queue, ChangedType.Deleted, node.Text, "");
                }
                else if (e.GoObject is Arc)
                {
                    Arc link = (Arc)e.GoObject;
                    GoNode fromNode = (GoNode)link.FromNode;
                    GoNode toNode = (GoNode)link.ToNode;
                    Changed(ChangedTarget.Arc, ChangedType.Deleted, fromNode.Text + "->" + toNode.Text, "");
                }
            }
            else if (e.Hint == GoLayer.ChangedObject)
            {
                if (e.GoObject is ActivityNode)
                {
                    if (e.SubHint == 1501 || (e.OldValue != null && e.NewValue != null))
                        Changed(ChangedTarget.Activity, ChangedType.Modified, e.OldValue.ToString(), e.NewValue.ToString());
                }
                else if (e.GoObject is QueueNode)
                {
                    if (e.SubHint == 1501 || (e.OldValue != null && e.NewValue != null))
                        Changed(ChangedTarget.Queue, ChangedType.Modified, e.OldValue.ToString(), e.NewValue.ToString());
                }

                else if (e.GoObject is Arc)
                {
                    if (e.SubHint == 1101)
                    {
                        Arc changedEdge = (Arc)e.GoObject.Parent;

                        string fromVertex = string.Empty;
                        string toVertex = string.Empty;

                        GoBasicNode fromNode = (GoBasicNode)changedEdge.FromNode;
                        GoBasicNode toNode = (GoBasicNode)changedEdge.ToNode;
                        fromVertex = fromNode.Text;
                        toVertex = toNode.Text;

                        /* resource vs entity
                        if (isChangeable)
                        {
                            if (changedEdge.Pen.DashStyle == System.Drawing.Drawing2D.DashStyle.Solid)
                                Changed(ChangedTarget.SchedulingEdgeType, ChangedType.Modified, "scheduling", fromEventVertex + "->" + toEventVertex);
                            //Changed("edgetype", "scheduling", fromEventVertex, toEventVertex);
                            else
                                Changed(ChangedTarget.SchedulingEdgeType, ChangedType.Modified, "canceling", fromEventVertex + "->" + toEventVertex);
                            //Changed("edgetype",  "canceling", fromEventVertex, toEventVertex);
                        }
                        */
                    }
                    else if (e.SubHint == 1303)
                    {
                        Arc changedEdge = (Arc)e.GoObject.Parent;

                        if (e.OldValue is GoPort)
                        {
                            GoPort oldPort = (GoPort)e.OldValue;
                            /*
                            string eventName = ((GoBasicNode)oldPort.Node).Text;
                            oldEventVerex = eventName;

                            if (oldPort.PartID.Equals(lastFromPort.PartID))
                                isOldEventVertexFrom = true;
                            else
                                isOldEventVertexFrom = false;
                            //NewValue: Northwoods.Go.GoToolLinking.GoTemporaryPort
                            */
                        }
                        if (e.NewValue is GoPort)
                        {
                            //OldValue: Northwoods.Go.GoToolLinking.GoTemporaryPort
                            GoPort newPort = (GoPort)e.NewValue;
                            if (newPort.Node != null)
                            {
                                string newName = ((GoNode)newPort.Node).Text;

                                string fromActivityVertex = ((GoBasicNode)changedEdge.FromPort.Node).Text;
                                string toActivityVertex = ((GoBasicNode)changedEdge.ToPort.Node).Text;

                                Changed(ChangedTarget.Arc, ChangedType.Modified, lastFromEventVertex + "->" + lastToEventVertex, fromActivityVertex + "->" + toActivityVertex);
                                /*
                                if (isOldEventVertexFrom)
                                    Changed(ChangedTarget.SchedulingEdge, ChangedType.Modified, oldEventVerex + "->" + toEventVertex, fromEventVertex + "->" + toEventVertex);
                                else
                                    Changed(ChangedTarget.SchedulingEdge, ChangedType.Modified, fromEventVertex + "->" + oldEventVerex, fromEventVertex + "->" + toEventVertex);
                                */
                            }
                        }
                    }
                    else
                    {
                        Arc changedEdge = (Arc)e.GoObject.Parent;

                        //System.Diagnostics.Debug.WriteLine("---------");
                        //System.Diagnostics.Debug.WriteLine("e.SubHint: " + e.SubHint);
                        //if (e.OldValue != null)
                        //    System.Diagnostics.Debug.WriteLine("e.OldValue:" + e.OldValue.ToString());
                        //if (e.NewValue != null)
                        //    System.Diagnostics.Debug.WriteLine("e.NewValue:" + e.NewValue.ToString());
                        //if (e.PresentationName != null)
                        //    System.Diagnostics.Debug.WriteLine("e.PresentationName:" + e.PresentationName);
                    }
                }
            }
        }

        private void OnViewScaleChanged(double scale)
        {
            tscbZoom.Text = Math.Round(scale * 100, 0).ToString() + "%";
        }

        private void OnViewSelection(object sender, EventArgs e)
        {
            /*
            GoView view = (GoView)sender;
            if (myPrimary != view.Selection.Primary)
            {
                UpdateHighlighting();
            }
            */
        }

        private void OnPropertyChanged(object target, string propertyName, object oldPropertyValue, object newPropertyValue)
        {
            if (Changed != null && Changed.GetInvocationList().Length > 0)
            {
                ChangedTarget targetType = ChangedTarget.Activity;
                if (target is OOAGActivity)
                {
                    targetType = ChangedTarget.Activity;
                }
                else if (target is OOAGQueue)
                {
                    targetType = ChangedTarget.Queue;
                }
                else if (target is OOAGArc || target is Arc)
                {
                    targetType = ChangedTarget.Arc;
                }
                else if (target is ScheduleNode)
                {
                    targetType = ChangedTarget.Schedule;
                }

                Changed(targetType, ChangedType.Modified, oldPropertyValue, newPropertyValue);
            }
        }

        public List<string> getInfluencedActivity(string queueName)
        {
            List<string> rslt = new List<string>();

            QueueNode qNode = _View.Doc.QueueNodes.Find(q => q.Queue.Name.Equals(queueName));

            if (qNode != null)
            {
                foreach (GoNode destNode in qNode.Destinations)
                {
                    if (destNode is ActivityNode)
                    {
                        rslt.Add(((ActivityNode)destNode).Activity.Name);
                    }
                }
            }

            return rslt;
        }

        #endregion


    }
}
