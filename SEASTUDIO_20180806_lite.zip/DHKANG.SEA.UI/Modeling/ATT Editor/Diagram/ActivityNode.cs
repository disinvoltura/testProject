﻿using DHKANG.SEA.Model;
using DHKANG.SEA.Model.ActivityObjects;
using Northwoods.Go;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.UI.ATTEditor
{
    public class ActivityNode : MultiPortNode
    {
        #region Member Variables
        private OOAGActivity _Activity;
        #endregion

        #region Properties
        public OOAGActivity Activity {  get { return _Activity; } }

        public string ActivityName
        {
            get
            {
                return _Activity.Name;
            }
            set
            {
                _Activity.Name = value;
                this.NodeName = value;
            }
        }

        public string TimeDelay
        {
            get { return _Activity.TimeDelay; }
            set
            {
                _Activity.TimeDelay = value;
                this.NodeType = value;
            }
        }

        #endregion

        #region Constructors
        public ActivityNode(OOAGActivity activity): base(activity.Name, activity.TimeDelay)
        {
            _Activity = activity;
            initialize();
        }

        public ActivityNode(string name) : base (name, "")
        {
            _Activity = new OOAGActivity(name, string.Empty, string.Empty);
            initialize();
        }

        private void initialize()
        {
            //alt 1
            /*
            LinearGradientBrush brush = new LinearGradientBrush(this.Bounds, Color.White, Color.LightBlue, 90.0f);
            this.Brush = brush;
            this.BorderPen = new Pen(Color.LightBlue);
            */

            //alt 2
            LinearGradientBrush brush = new LinearGradientBrush(this.Bounds, Color.FromArgb(116,116,191),  Color.FromArgb(52,138,199), 270.0f);
            //LinearGradientBrush brush = new LinearGradientBrush(this.Bounds, Color.FromArgb(131,164,212),  Color.FromArgb(182,251,255), 270.0f);
            //LinearGradientBrush brush = new LinearGradientBrush(this.Bounds, Color.FromArgb(75, 108, 183),  Color.FromArgb(24, 40, 72), 270.0f);
            //LinearGradientBrush brush = new LinearGradientBrush(this.Bounds, Color.FromArgb(115,200,169),  Color.FromArgb(55, 59, 68), 90.0f);
            this.Brush = brush;
            this.BorderPen = new Pen(Color.FromArgb(116, 116, 191));


        }

        private void setTimeDelay(string timeDelay)
        {
            _Activity.TimeDelay = timeDelay;
            decimal constantTime;
            if (decimal.TryParse(timeDelay, out constantTime))
            {
                this.NodeType = string.Format("Constant({0})", timeDelay);
            }
            else
            {
                this.NodeType = timeDelay;
            }
        }

        #endregion

        #region Methods
        #endregion
    }
}
