﻿using DHKANG.SEA.Model.ActivityObjects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace DHKANG.SEA.UI.ATTEditor
{
    public delegate void ActivityTransitionTableChangedEvent(string target, string action, string before, string after);

    public partial class ActivityTransitionTableWindow : DockContent
    {
        #region Member Variables
        private ActivityObjectModelEditor _Parent;
        private OOAGActivityObjectModel _Model;
        private SourceGrid.Cells.Views.ColumnHeader titleModel;

        #endregion

        #region Properties
        public List<OOAGActivityTransition> ActivityTransitions
        {
            get
            {
                List<OOAGActivityTransition> rslt = new List<OOAGActivityTransition>();
                int rowspan = 1;
                for (int k = 2; k < Table.RowsCount - 1; k += rowspan)
                {
                    SourceGrid.Cells.ICellVirtual[] cells = Table.GetCellsAtRow(k);
                    int nullCount = 0;
                    for (int p = 0; p < 10; p++)
                    {
                        if (Table[k, p] == null || Table[k, p].Value == null)
                            nullCount++;
                    }
                    if (nullCount < 9)
                    {
                        OOAGActivityTransition transition = new OOAGActivityTransition();
                        transition.Activity.Name = (string)Table[k, 1].Value;
                        //transition.No = (int)grid1[k, 0].Value;
                        //transition.Name = (string)grid1[k, 1].Value;
                        transition.AtBegin.Condition = (string)Table[k, 2].Value;
                        transition.AtBegin.Action = (string)Table[k, 3].Value;
                        transition.BTOEvent.Time = (string)Table[k, 4].Value;
                        transition.Activity.TimeDelay = (string)Table[k, 4].Value;
                        transition.BTOEvent.Name = (string)Table[k, 5].Value;
                        if (Table[k, 1].View.Font != null)
                            transition.Activity.IsEnabled = Table[k, 1].View.Font.Underline;
                        else
                            transition.Activity.IsEnabled = false;
                        for (int m = k; m <= k + Table[k, 0].RowSpan - 1; m++)
                        {
                            OOAGAtEndTransition endTransition = new OOAGAtEndTransition();
                            if (Table[m, 6].Value == null)
                                endTransition.Arc = 1;
                            else
                                endTransition.Arc = int.Parse(Table[m, 6].Value.ToString());
                            endTransition.Condition = (string)Table[m, 7].Value;
                            endTransition.Action = (string)Table[m, 8].Value;
                            endTransition.InfluencedActivity = (string)Table[m, 9].Value;
                            transition.AtEnds.Add(endTransition);
                        }
                        rslt.Add(transition);

                        rowspan = Table[k, 0].RowSpan;
                    }
                    else
                    {
                        rowspan = 1;
                    }
                }

                return rslt;
            }
        }
        #endregion

        #region Events
        public event ActivityTransitionTableChangedEvent Changed;
        #endregion

        #region Constructors
        public ActivityTransitionTableWindow(ActivityObjectModelEditor parent)
        {
            _Parent = parent;
            InitializeComponent();

            drawATTHeaders();
            //insertEmptyActivityTransition();
            //insertInitialzeRow();
            //_InitialValueCell.Value = "Initial Marking={}; Enabled Activities={}";
            AutoSizeCells();

            initializeGridChangeControllers();

            Table.GotFocus += new EventHandler(OnGrid1_GotFocus);
            Table.LostFocus += new EventHandler(OnGrid1_LostFocus);
            Table.Selection.SelectionChanged += new SourceGrid.RangeRegionChangedEventHandler(OnGrid1_SelectionChanged);

            Table.MouseWheel += Table_MouseWheel;

        }

        private void OnGrid1_SelectionChanged(object sender, SourceGrid.RangeRegionChangedEventArgs e)
        {
            if (e.AddedRange != null && e.AddedRange.ContainsRow(_InitialValueCell.Row.Index))
            {
                disableATTToolbars();
            }
            else
            {
                enableATTToolbars();
            }
        }

        private void OnGrid1_GotFocus(object sender, EventArgs e)
        {
            enableATTToolbars();
        }

        private void OnGrid1_LostFocus(object sender, EventArgs e)
        {
            disableATTToolbars();
        }

        private void enableATTToolbars()
        {
            tsbDelete.Enabled = true;
            tsbSetEnabledActivity.Enabled = true;
            tsbAddAtEnd.Enabled = true;
            tsbDelAtEnd.Enabled = true;
        }

        private void disableATTToolbars()
        {
            tsbDelete.Enabled = false;
            tsbSetEnabledActivity.Enabled = false;
            tsbAddAtEnd.Enabled = false;
            tsbDelAtEnd.Enabled = false;
        }

        private void initializeGridChangeControllers()
        {
            GridChangeController gcController = new GridChangeController();
            gcController.GridChanged = OnGridChanged;
            Table.Controller.AddController(gcController);
        }

        private void OnGridChanged(object source)
        {
            setChange(true);
        }

        public bool IsChanged = false;
        public void setChange(bool changed)
        {
            this.IsChanged = changed;
            /*
            if (changed)
            {
                if (string.IsNullOrEmpty(this.ModelFileName))
                    this.Text = "*" + this.Table.Name;
                else
                    this.Text = "*" + this.Table.Name + " - " + ModelFileName;

                UpdateToATT();
                UpdateInitializeCell();
            }
            else
            {
                if (string.IsNullOrEmpty(this.ModelFileName))
                    this.Text = this.Table.Name;
                else
                    this.Text = this.Table.Name + " - " + ModelFileName;
            }
            */
        }
        #endregion

        #region Methods
        private void drawATTHeaders()
        {
            Table.BorderStyle = BorderStyle.FixedSingle;
            Table.Redim(2, 11);
            Table.EnableSort = false;
            Table.CustomSort = false;

            titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Snow;
            backHeader.Border = DevAge.Drawing.RectangleBorder.NoBorder;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
            titleModel.Font = new Font("Consolas", 9.0f, FontStyle.Bold);

            Table.EnableSort = false;
            Table.Font = new Font("Calibe", 10);
            //1st Header Row
            Table.Rows.Insert(0);
            Table.Rows.Insert(1);
            SourceGrid.Cells.ColumnHeader noHeader = new SourceGrid.Cells.ColumnHeader("No");
            noHeader.RowSpan = 2;
            noHeader.View = titleModel;
            noHeader.SortComparer = new SourceGrid.ValueCellComparer();

            SourceGrid.Cells.ColumnHeader activityHeader = new SourceGrid.Cells.ColumnHeader("Activity");
            activityHeader.RowSpan = 2;
            activityHeader.View = titleModel;

            SourceGrid.Cells.ColumnHeader atBeginHeader = new SourceGrid.Cells.ColumnHeader("At-begin");
            atBeginHeader.ColumnSpan = 2;
            atBeginHeader.View = titleModel;
            SourceGrid.Cells.ColumnHeader btoEventHeader = new SourceGrid.Cells.ColumnHeader("BTO-event");
            btoEventHeader.ColumnSpan = 2;
            btoEventHeader.View = titleModel;

            SourceGrid.Cells.ColumnHeader atEndHeader = new SourceGrid.Cells.ColumnHeader("At-end");
            atEndHeader.ColumnSpan = 4;
            atEndHeader.View = titleModel;

            Table[0, 0] = noHeader;
            Table[0, 1] = activityHeader;
            Table[0, 2] = atBeginHeader;
            Table[0, 4] = btoEventHeader;
            Table[0, 6] = atEndHeader;

            //2nd Header Row

            SourceGrid.Cells.ColumnHeader abCondHeader = new SourceGrid.Cells.ColumnHeader("Condition");
            SourceGrid.Cells.ColumnHeader abActionHeader = new SourceGrid.Cells.ColumnHeader("Action");
            SourceGrid.Cells.ColumnHeader beTimeHeader = new SourceGrid.Cells.ColumnHeader("Time");
            SourceGrid.Cells.ColumnHeader beNameHeader = new SourceGrid.Cells.ColumnHeader("Name");
            SourceGrid.Cells.ColumnHeader aeArcHeader = new SourceGrid.Cells.ColumnHeader("Arc");
            SourceGrid.Cells.ColumnHeader aeCondHeader = new SourceGrid.Cells.ColumnHeader("Condition");
            SourceGrid.Cells.ColumnHeader aeActionHeader = new SourceGrid.Cells.ColumnHeader("Action");
            SourceGrid.Cells.ColumnHeader aeIAHeader = new SourceGrid.Cells.ColumnHeader("Influenced Activity");

            abCondHeader.View = titleModel;
            abActionHeader.View = titleModel;
            beTimeHeader.View = titleModel;
            beNameHeader.View = titleModel;
            aeArcHeader.View = titleModel;
            aeCondHeader.View = titleModel;
            aeActionHeader.View = titleModel;
            aeIAHeader.View = titleModel;

            Table[1, 2] = abCondHeader;
            Table[1, 3] = abActionHeader;
            Table[1, 4] = beTimeHeader;
            Table[1, 5] = beNameHeader;
            Table[1, 6] = aeArcHeader;
            Table[1, 7] = aeCondHeader;
            Table[1, 8] = aeActionHeader;
            Table[1, 9] = aeIAHeader;

            Table.Selection.FocusRowEntered += new SourceGrid.RowEventHandler(Selection_FocusRowEntered);
            Table.Selection.FocusColumnEntered += new SourceGrid.ColumnEventHandler(Selection_FocusColumnEntered);
        }

        private int _CurrentRow;
        private int _CurrentColumn;
        private void Selection_FocusColumnEntered(object sender, SourceGrid.ColumnEventArgs e)
        {
            _CurrentColumn = e.Column;
            if (Table.Selection.ActivePosition.Column < 6 ||
                Table[_CurrentRow, 0].RowSpan == 1)
            {
                tsbDelAtEnd.Enabled = false;
            }
            else
            {
                tsbDelAtEnd.Enabled = true;
            }
        }

        private void Selection_FocusRowEntered(object sender, SourceGrid.RowEventArgs e)
        {
            _CurrentRow = e.Row;
            if (Table.Selection.ActivePosition.Column < 6 ||
                Table[_CurrentRow, 0].RowSpan == 1)
            {
                tsbDelAtEnd.Enabled = false;
            }
            else
            {
                tsbDelAtEnd.Enabled = true;
            }
        }

        private int _ActivityCount = 1;
        private void insertEmptyActivityTransition()
        {
            UpdateToATT();

            int rowIndex = Table.RowsCount - 1;
            Table.Rows.Insert(rowIndex);

            Table[rowIndex, 0] = new SourceGrid.Cells.Cell(this.ActivityTransitions.Count + 1, typeof(int));
            SourceGrid.Cells.Views.Cell noView = new SourceGrid.Cells.Views.Cell();
            noView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
            Table[rowIndex, 0].View = noView;

            Table[rowIndex, 1] = new SourceGrid.Cells.Cell("Activity " + _ActivityCount++, typeof(string));
            Table[rowIndex, 2] = new SourceGrid.Cells.Cell("", typeof(string));
            Table[rowIndex, 3] = new SourceGrid.Cells.Cell("", typeof(string));
            //SourceGrid.Cells.Editors.TextBox abActionEditor = new SourceGrid.Cells.Editors.TextBox(typeof(string));
            //abActionEditor.Control.Multiline = true;
            //grid1[rowIndex, 3].Editor = abActionEditor;
            ActionEditorDialog abActionEditor = new ActionEditorDialog();
            Table[rowIndex, 3].Editor = abActionEditor;

            Table[rowIndex, 4] = new SourceGrid.Cells.Cell("", typeof(string));
            Table[rowIndex, 5] = new SourceGrid.Cells.Cell("", typeof(string));
            Table[rowIndex, 6] = new SourceGrid.Cells.Cell(1, typeof(int));
            SourceGrid.Cells.Views.Cell arcNoView = new SourceGrid.Cells.Views.Cell();
            arcNoView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
            Table[rowIndex, 6].View = arcNoView;

            Table[rowIndex, 7] = new SourceGrid.Cells.Cell("true", typeof(string));
            SourceGrid.Cells.Views.Cell aeCondView = new SourceGrid.Cells.Views.Cell();
            aeCondView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
            Table[rowIndex, 7].View = aeCondView;

            Table[rowIndex, 8] = new SourceGrid.Cells.Cell("", typeof(string));
            ActionEditorDialog aeActionEditor = new ActionEditorDialog();
            Table[rowIndex, 8].Editor = aeActionEditor;

            Table[rowIndex, 9] = new SourceGrid.Cells.Cell("", typeof(string));

            SourceGrid.Cells.Editors.TextBox activityNameEditor = new SourceGrid.Cells.Editors.TextBox(typeof(string));
            activityNameEditor.KeyPress += new KeyPressEventHandler(activityNameEditor_KeyPress);
            activityNameEditor.ConvertingValueToDisplayString += new DevAge.ComponentModel.ConvertingObjectEventHandler(activityNameEditor_ConvertingValueToDisplayString);
            Table[rowIndex, 1].Editor = activityNameEditor;

            setChange(true);
        }

        void activityNameEditor_ConvertingValueToDisplayString(object sender, DevAge.ComponentModel.ConvertingObjectEventArgs e)
        {
            UpdateInitializeCell();
        }

        void activityNameEditor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Tab)
            {
                UpdateInitializeCell();
            }
        }

        private void activityNameEditor_Changed(object sender, EventArgs e)
        {
            UpdateInitializeCell();
        }

        private void insertActivityTransition(OOAGActivityTransition transition)
        {
            int rowIndex = Table.RowsCount - 2;
            int rowSpan = transition.AtEnds.Count == 0 ? 1 : transition.AtEnds.Count;
            Table.Rows.InsertRange(rowIndex, rowSpan);
            //grid1.Rows.Insert(rowIndex);

            //TODO remove the column 'no'
            SourceGrid.Cells.Cell createNo = new SourceGrid.Cells.Cell(1, typeof(int));
            createNo.RowSpan = rowSpan;
            SourceGrid.Cells.Views.Cell noView = new SourceGrid.Cells.Views.Cell();
            noView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
            createNo.View = noView;

            SourceGrid.Cells.Cell createActivity = new SourceGrid.Cells.Cell(transition.Activity.Name, typeof(string));
            if (transition.Activity.IsEnabled)
            {
                createActivity.View = new SourceGrid.Cells.Views.Cell();
                createActivity.View.Font = new Font("Times, Arial", 10.0f, FontStyle.Underline);
            }
            createActivity.RowSpan = rowSpan;
            SourceGrid.Cells.Cell createAbCond = new SourceGrid.Cells.Cell(transition.AtBegin.Condition, typeof(string));
            createAbCond.RowSpan = rowSpan;
            SourceGrid.Cells.Cell createAbAction = new SourceGrid.Cells.Cell(transition.AtBegin.Action, typeof(string));
            createAbAction.RowSpan = rowSpan;

            SourceGrid.Cells.Cell createbtoTime = new SourceGrid.Cells.Cell(transition.Activity.TimeDelay, typeof(string));
            createbtoTime.RowSpan = rowSpan;
            createbtoTime.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
            SourceGrid.Cells.Cell createbtoName = new SourceGrid.Cells.Cell(transition.BTOEvent.Name, typeof(string));
            createbtoName.RowSpan = rowSpan;
            createbtoName.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            Table[rowIndex, 0] = createNo;
            Table[rowIndex, 1] = createActivity;
            Table[rowIndex, 2] = createAbCond;
            Table[rowIndex, 3] = createAbAction;
            ActionEditorDialog abActionEditor = new ActionEditorDialog();
            createAbAction.Editor = abActionEditor;

            Table[rowIndex, 4] = createbtoTime;
            Table[rowIndex, 5] = createbtoName;

            if (transition.AtEnds.Count > 0)
            {
                for (int k = 0; k < transition.AtEnds.Count; k++)
                {
                    OOAGAtEndTransition endTransition = transition.AtEnds[k];

                    SourceGrid.Cells.Cell createae1Arc = new SourceGrid.Cells.Cell(endTransition.Arc, typeof(int));
                    SourceGrid.Cells.Views.Cell aeArcView = new SourceGrid.Cells.Views.Cell();
                    aeArcView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
                    createae1Arc.View = aeArcView;

                    SourceGrid.Cells.Cell createae1Cond = new SourceGrid.Cells.Cell(endTransition.Condition, typeof(string));
                    SourceGrid.Cells.Views.Cell aeCondView = new SourceGrid.Cells.Views.Cell();
                    aeCondView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
                    createae1Cond.View = aeCondView;

                    SourceGrid.Cells.Cell createae1Action = new SourceGrid.Cells.Cell(endTransition.Action, typeof(string));
                    SourceGrid.Cells.Cell createae1IA = new SourceGrid.Cells.Cell(endTransition.InfluencedActivity, typeof(string));

                    Table[rowIndex + k, 6] = createae1Arc;
                    Table[rowIndex + k, 7] = createae1Cond;
                    Table[rowIndex + k, 8] = createae1Action;
                    ActionEditorDialog aeActionEditor = new ActionEditorDialog();
                    Table[rowIndex + k, 8].Editor = aeActionEditor;

                    Table[rowIndex + k, 9] = createae1IA;
                }
            }else
            {
                SourceGrid.Cells.Cell createae1Arc = new SourceGrid.Cells.Cell(1, typeof(int));
                SourceGrid.Cells.Views.Cell aeArcView = new SourceGrid.Cells.Views.Cell();
                aeArcView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
                createae1Arc.View = aeArcView;

                SourceGrid.Cells.Cell createae1Cond = new SourceGrid.Cells.Cell("", typeof(string));
                SourceGrid.Cells.Views.Cell aeCondView = new SourceGrid.Cells.Views.Cell();
                aeCondView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
                createae1Cond.View = aeCondView;

                SourceGrid.Cells.Cell createae1Action = new SourceGrid.Cells.Cell("", typeof(string));
                SourceGrid.Cells.Cell createae1IA = new SourceGrid.Cells.Cell("", typeof(string));

                Table[rowIndex, 6] = createae1Arc;
                Table[rowIndex, 7] = createae1Cond;
                Table[rowIndex, 8] = createae1Action;
                ActionEditorDialog aeActionEditor = new ActionEditorDialog();
                Table[rowIndex, 8].Editor = aeActionEditor;

                Table[rowIndex, 9] = createae1IA;

            }
        }

        private SourceGrid.Cells.RichTextBox CreateRichTextBox()
        {
            DevAge.Windows.Forms.RichText richText = new DevAge.Windows.Forms.RichText(
                    "{\\rtf1\\ansi\\ansicpg1252\\deff0\\deflang1033{\\fonttbl{\\f0\\fnil\\fcharset0" +
                    "Microsoft Sans Serif;}}\r\n\\viewkind4\\uc1\\pard\\f0\\fs17 Only a \\b " +
                    "Test\\b0.\\par\r\n}\r\n");
            return new SourceGrid.Cells.RichTextBox(richText);
        }

        private SourceGrid.Cells.Views.RichTextBox CreateRichTextBoxView()
        {
            SourceGrid.Cells.Views.RichTextBox richTextBoxView = new SourceGrid.Cells.Views.RichTextBox();
            richTextBoxView.BackColor = Color.AliceBlue;
            return richTextBoxView;
        }

        private void insertActivityTransitionTable(OOAGActivityObjectModel model)
        {
            Table.Rows.Clear();
            drawATTHeaders();

            foreach (OOAGActivityTransition transition in model.ActivityTransitions)
                insertActivityTransition(transition);

            //Initialize
            insertInitialzeRow();
            updateInitializeCellonLoad();

            Table.AutoSizeCells();
        }

        bool isNoAscending = false;
        bool isNameAscending = false;
        private void insertActivityTransitionTable(OOAGActivityObjectModel table, int columnIndex, bool Ascending)
        {
            /*
            List<OOAGActivityTransition> sortedList = new List<OOAGActivityTransition>();

            if (columnIndex == 0)//no
            {
                foreach (OOAGActivityTransition transition in table.ActivityTransitions)
                {
                    if (sortedList.Count == 0)
                        sortedList.Add(transition);
                    else
                    {
                        for (int k = 0; k < sortedList.Count; k++)
                        {
                            if (Ascending)
                            {
                                if (transition.No <= sortedList[k].No)
                                {
                                    sortedList.Insert(k, transition);
                                    break;
                                }
                                else if (k == sortedList.Count - 1)
                                {
                                    sortedList.Add(transition);
                                    break;
                                }
                            }
                            else
                            {
                                if (transition.No >= sortedList[k].No)
                                {
                                    sortedList.Insert(k, transition);
                                    break;
                                }
                                else if (k == sortedList.Count - 1)
                                {
                                    sortedList.Add(transition);
                                    break;
                                }
                            }
                        }
                    }
                }

            }
            else if (columnIndex == 1)
            {
                foreach (string key in table.ActivityTransitions.Keys)
                {
                    ATTActivityTransition transition = table.ActivityTransitions[key];

                    if (sortedList.Count == 0)
                        sortedList.Add(transition);
                    else
                    {
                        for (int k = 0; k < sortedList.Count; k++)
                        {
                            if (Ascending)
                            {
                                if (transition.Name.CompareTo(sortedList[k].Name) <= 0)
                                {
                                    sortedList.Insert(k, transition);
                                    break;
                                }
                                else if (k == sortedList.Count - 1)
                                {
                                    sortedList.Add(transition);
                                    break;
                                }
                            }
                            else
                            {
                                if (transition.Name.CompareTo(sortedList[k].Name) >= 0)
                                {
                                    sortedList.Insert(k, transition);
                                    break;
                                }
                                else if (k == sortedList.Count - 1)
                                {
                                    sortedList.Add(transition);
                                    break;
                                }
                            }
                        }
                    }
                }

            }
            */

            //foreach (ATTActivityTransition transition in sortedList)
            foreach (OOAGActivityTransition transition in table.ActivityTransitions)
                insertActivityTransition(transition);

            _Model.ActivityTransitions.Clear();
            //Initialize
            insertInitialzeRow();
            UpdateInitializeCell();

            Table.AutoSizeCells();
        }

        private SourceGrid.Cells.Cell _InitialValueCell;
        private void insertInitialzeRow()
        {
            int rowIndex = Table.RowsCount;
            Table.Rows.Insert(rowIndex);

            SourceGrid.Cells.Cell initialHeader = new SourceGrid.Cells.Cell("Initialize", typeof(string));
            initialHeader.ColumnSpan = 2;
            SourceGrid.Cells.Views.Cell initialHeaderView = new SourceGrid.Cells.Views.Cell();
            initialHeaderView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
            initialHeader.View = initialHeaderView;
            SourceGrid.Cells.Editors.TextBox ihEditor = new SourceGrid.Cells.Editors.TextBox(typeof(string));
            ihEditor.EnableEdit = false;
            initialHeader.Editor = ihEditor;

            SourceGrid.Cells.Cell initialValue = new SourceGrid.Cells.Cell("Initial Marking = {}; Enabled Activities={}", typeof(string));
            initialValue.ColumnSpan = 8;
            SourceGrid.Cells.Editors.TextBox ivEditor = new SourceGrid.Cells.Editors.TextBox(typeof(string));
            ivEditor.EnableEdit = false;
            initialValue.Editor = ivEditor;
            SourceGrid.Cells.Views.Cell ivView = new SourceGrid.Cells.Views.Cell();
            ivView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            ivView.BackColor = Color.LightGray;
            initialValue.View = ivView;

            Table[rowIndex, 0] = initialHeader;
            Table[rowIndex, 2] = initialValue;

            _InitialValueCell = initialValue;
        }

        public void UpdateInitializeCell()
        {
            if (_InitialValueCell == null)
                return;

            //Initial Marking
            string strInitValue = "Initial Marking={";
            int count = 0;
            foreach (OOAGQueue queue in _Model.Queues)
            {
                strInitValue += queue.Name + "=" + queue.InitialValue;
                if (count < _Model.Queues.Count - 1)
                    strInitValue += ",";

                count++;
            }
            strInitValue += "}; ";
            //Variables
            if (_Model.StateVariables.Count > 0)
            {
                strInitValue += "Variables={";
                count = 0;
                foreach (OOAGStateVariable variable in _Model.StateVariables)
                {
                    if (variable.Row == 1 && variable.Col == 1)
                    {
                        string tmp = variable.InitialValue.Replace("{", "").Replace("}", "");
                        if (tmp == "0.0f" || tmp == "0.0")
                            tmp = "0";
                        strInitValue += variable.Name + "=" + tmp;
                    }
                    else
                    {
                        if (variable.Row > 1 && variable.Col > 1)
                            strInitValue += variable.Name + "[" + variable.Row + "," + variable.Col + "]";
                        else if (variable.Row == 1 && variable.Col > 1)
                            strInitValue += variable.Name + "[" + variable.Col + "]";
                        else if (variable.Row > 1 && variable.Col == 1)
                            strInitValue += variable.Name + "[" + variable.Row + "]";
                    }

                    if (count < _Model.StateVariables.Count - 1)
                        strInitValue += ",";

                    count++;
                }
                strInitValue += "}; ";
            }

            //Enabled Activities
            strInitValue += "Enabled Activities={";
            List<string> enabledActivities = new List<string>();

            int rowspan = 1;
            for (int k = 2; k < Table.RowsCount - 1; k += rowspan)
            {
                SourceGrid.Cells.ICellVirtual[] cells = Table.GetCellsAtRow(k);
                int nullCount = 0;
                for (int p = 0; p < 10; p++)
                {
                    if (Table[k, p] == null || Table[k, p].Value == null)
                        nullCount++;
                }
                if (nullCount < 9)
                {
                    if (Table[k, 1].View.Font != null && Table[k, 1].View.Font.Underline)
                        enabledActivities.Add((string)Table[k, 1].Value);

                    rowspan = Table[k, 0].RowSpan;
                }
                else
                {
                    rowspan = 1;
                }
            }

            count = 0;
            foreach (string enabledActivityName in enabledActivities)
            {
                strInitValue += enabledActivityName;
                if (count < enabledActivities.Count - 1)
                    strInitValue += ",";
                count++;
            }
            strInitValue += "}";
            _InitialValueCell.Value = strInitValue;
        }

        private void updateInitializeCellonLoad()
        {
            string strInitValue = "Initial Marking={";
            int count = 0;
            foreach (OOAGQueue queue in _Model.Queues)
            {
                strInitValue += queue.Name + "=" + queue.InitialValue;
                if (count < _Model.Queues.Count - 1)
                    strInitValue += ",";

                count++;
            }
            strInitValue += "}; ";

            //Variables
            if (_Model.StateVariables.Count > 0)
            {
                strInitValue += "Variables={";
                count = 0;
                foreach (OOAGStateVariable variable in _Model.StateVariables)
                {
                    if (variable.Row == 1 && variable.Col == 1)
                    {
                        string tmp = variable.InitialValue.Replace("{", "").Replace("}", "");
                        if (tmp == "0.0f" || tmp == "0.0")
                            tmp = "0";
                        strInitValue += variable.Name + "=" + tmp;
                    }
                    else
                    {
                        if (variable.Row > 1 && variable.Col > 1)
                            strInitValue += variable.Name + "[" + variable.Row + "," + variable.Col + "]";
                        else if (variable.Row == 1 && variable.Col > 1)
                            strInitValue += variable.Name + "[" + variable.Col + "]";
                        else if (variable.Row > 1 && variable.Col == 1)
                            strInitValue += variable.Name + "[" + variable.Row + "]";
                    }

                    if (count < _Model.StateVariables.Count - 1)
                        strInitValue += ",";

                    count++;
                }
                strInitValue += "}; ";
            }

            strInitValue += "Enabled Activities={";
            List<string> enabledActivities = new List<string>();
            foreach (OOAGActivityTransition transition in _Model.ActivityTransitions)
            {
                if (transition.Activity.IsEnabled)
                    enabledActivities.Add(transition.Activity.Name);
            }
            count = 0;
            foreach (string enabledActivityName in enabledActivities)
            {
                strInitValue += enabledActivityName;
                if (count < enabledActivities.Count - 1)
                    strInitValue += ",";
                count++;
            }
            strInitValue += "}";
            _InitialValueCell.Value = strInitValue;

        }

        public void Update(OOAGActivityObjectModel model)
        {
            this.Open(model);
        }

        private bool isChangeable;
        public void OnACDChanged(ChangedTarget target, ChangedType action, object before, object after)
        {
            isChangeable = false;
            if (target == ChangedTarget.Activity)
                doHandleActivityVertexChange(action, before, after);
            else if (target == ChangedTarget.Queue)
                doHandleQueueVertexChange(action, before, after);
            //else if (target == ChangedTarget.Arc)
            //    doHandleEdgeChange(action, before, after);

            isChangeable = true;
        }

        private void doHandleQueueVertexChange(ChangedType action, object before, object after)
        {

        }

        private void doHandleActivityVertexChange(ChangedType action, object before, object after)
        {
            if (action == ChangedType.Modified)
            {
                string oldValue = (string)before;
                string newValue = (string)after;
                for (int i = 2; i < Table.RowsCount; i++)
                {
                    SourceGrid.Cells.Cell nameCell = (SourceGrid.Cells.Cell)Table[i, 1];
                    if (nameCell == null)
                        continue;

                    if (nameCell.DisplayText == oldValue)
                    {
                        nameCell.Value = after;
                    }

                    SourceGrid.Cells.Cell infActCell = (SourceGrid.Cells.Cell)Table[i, 9];

                    if (!string.IsNullOrEmpty(infActCell.DisplayText))
                    {
                        string[] infActList = infActCell.DisplayText.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                        if (infActList.Contains<string>(oldValue))
                        {
                            string infAct = "";
                            for (int p = 0; p < infActList.Length; p++)
                            {
                                if (infActList[p] == oldValue)
                                    infAct += newValue;
                                else
                                    infAct += infActList[p];
                                if (p < infActList.Length - 1)
                                    infAct += ",";
                            }

                            infActCell.Value = infAct;
                        }
                    }

                    /*
                    SourceGrid.Cells.Cell nameCell = (SourceGrid.Cells.Cell)grid1[i, 1];
                    SourceGrid.Cells.Cell nextEventCell = (SourceGrid.Cells.Cell)Table[i, 8];

                    if (nameCell == null || nextEventCell == null)
                        continue;

                    if (nameCell.DisplayText == oldValue)
                    {
                        nameCell.Value = after;
                    }

                    if (nextEventCell.DisplayText == oldValue)
                    {
                        nextEventCell.Value = after;
                    }
                    */
                }
                //updateNextEventEditor();
            }
            else if (action == ChangedType.Added)
            {
                string newValue = (string)after;
                OOAGActivityTransition newTransition = new OOAGActivityTransition();
                newTransition.Activity.Name = newValue;
                newTransition.AtBegin = new OOAGAtBeginTransition("", "");
                newTransition.AtEnds.Add(new OOAGAtEndTransition(1, "true", "", ""));
                newTransition.BTOEvent = new OOAGBTOEvent(newValue + "_Event", "");

                insertActivityTransition(newTransition);
                //updateNextEventEditor();
            }
            else if (action == ChangedType.Deleted)
            {
                string oldValue = (string)before;
                for (int i = 2; i < Table.RowsCount; i++)
                {
                    SourceGrid.Cells.Cell nameCell =
                        (SourceGrid.Cells.Cell)Table[i, 1];

                    if (nameCell.DisplayText == oldValue)
                    {
                        deleteActivityAtRow(i);
                        break;
                    }
                }
                //updateNextEventEditor();
            }
        }

        private void deleteActivityAtRow(int sRow)
        {
            if (sRow < 2 || Table[sRow, 0] == null)
                return;

            string eventName = string.Empty;
            eventName = Table[sRow, 1].DisplayText;
            if (Table[sRow, 1].RowSpan > 1)
            {
                int count = Table[sRow, 1].RowSpan;
                for (int k = 0; k < count; k++)
                    Table.Rows.Remove(sRow);
            }
            else
            {
                Table.Rows.Remove(sRow);
            }

            /*
            if (grid1.Rows.Count == 2)
            {
                disableToolbars();
            }
            */

            if (isChangeable)
            {
                this.Changed("activityvertex", "deleted", eventName, string.Empty);
            }
        }

        private void doHandleEdgeChange(ChangedType action, object before, object after)
        {
            if (action == ChangedType.Modified)
            {
                //before, after는 Arc가 되어야 함
            }
            else if (action == ChangedType.Added)
            {
                string[] vertices = ((string)after).Split(new string[] { "->" }, StringSplitOptions.RemoveEmptyEntries);
                string fromVertex = vertices[0];
                string toVertex = vertices[1];

                //assuming from vertex is a kind of queue node.
                for (int i = 2; i < Table.RowsCount; i++)
                {
                    SourceGrid.Cells.Cell nameCell =
                        (SourceGrid.Cells.Cell)Table[i, 1];

                    if (nameCell == null)
                        continue;
                    if (nameCell.DisplayText == toVertex)
                    {
                        SourceGrid.Cells.Cell atBeginCondCell =
                                (SourceGrid.Cells.Cell)Table[i, 2];
                        SourceGrid.Cells.Cell atBeginActionCell =
                                (SourceGrid.Cells.Cell)Table[i, 3];
                        if (string.IsNullOrEmpty(atBeginCondCell.DisplayText))
                            atBeginCondCell.Value += "(" + fromVertex + ">0" + ")";
                        else
                            atBeginCondCell.Value += " && (" + fromVertex + ">0)";

                        atBeginActionCell.Value += fromVertex + "--;";
                        break;
                    }
                    else if (nameCell.DisplayText == fromVertex)
                    {
                        SourceGrid.Cells.Cell atEndActionCell =
                                    (SourceGrid.Cells.Cell)Table[i, 8];

                        int arcNo = 1;
                        int rowIndex = i;

                        if (string.IsNullOrEmpty(atEndActionCell.DisplayText))
                        {
                            arcNo = 1;
                            rowIndex = i;
                        }
                        else
                        {
                            arcNo = Table[i, 1].RowSpan + 1;
                            rowIndex = i + 1;
                            Table.Rows.Insert(rowIndex);
                        }

                        string atEndAction = toVertex + "++;";
                        string infActivities = "";
                        List<string> infActList = _Parent.DiagramWindow.getInfluencedActivity(toVertex);
                        for (int p = 0; p < infActList.Count; p++)
                        {
                            infActivities += infActList[p];
                            if (p < infActList.Count - 1)
                                infActivities += ",";
                        }

                        OOAGAtEndTransition atEnd = new OOAGAtEndTransition(arcNo, "true", atEndAction, infActivities);

                        SourceGrid.Cells.Cell createae1Arc = new SourceGrid.Cells.Cell(atEnd.Arc, typeof(int));
                        SourceGrid.Cells.Views.Cell aeArcView = new SourceGrid.Cells.Views.Cell();
                        aeArcView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
                        createae1Arc.View = aeArcView;

                        SourceGrid.Cells.Cell createae1Cond = new SourceGrid.Cells.Cell(atEnd.Condition, typeof(string));
                        SourceGrid.Cells.Views.Cell aeCondView = new SourceGrid.Cells.Views.Cell();
                        aeCondView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
                        createae1Cond.View = aeCondView;

                        SourceGrid.Cells.Cell createae1Action = new SourceGrid.Cells.Cell(atEnd.Action, typeof(string));
                        SourceGrid.Cells.Cell createae1IA = new SourceGrid.Cells.Cell(atEnd.InfluencedActivity, typeof(string));

                        Table[rowIndex, 6] = createae1Arc;
                        Table[rowIndex, 7] = createae1Cond;
                        Table[rowIndex, 8] = createae1Action;
                        ActionEditorDialog aeActionEditor = new ActionEditorDialog();
                        Table[rowIndex, 8].Editor = aeActionEditor;
                        Table[rowIndex, 9] = createae1IA;

                        if (rowIndex > i)
                        {
                            for (int c = 0; c < 6; c++)
                                Table[i, c].RowSpan++;
                        }
                        break;
                    }
                }
            }
            else if (action == ChangedType.Deleted)
            {
                string[] vertices = ((string)before).Split(new string[] { "->" }, StringSplitOptions.RemoveEmptyEntries);
                string fromVertex = vertices[0];
                string toVertex = vertices[1];

                //그냥 activity transition list로부터 table을 전체 갱신하는 편이 좋음
                //효율을 위해서 
                //assuming from vertex is a kind of queue node.
                for (int i = 2; i < Table.RowsCount; i++)
                {
                    SourceGrid.Cells.Cell nameCell =
                        (SourceGrid.Cells.Cell)Table[i, 1];

                    if (nameCell == null)
                        continue;
                    if (nameCell.DisplayText == toVertex)
                    {
                        SourceGrid.Cells.Cell atBeginCondCell =
                                (SourceGrid.Cells.Cell)Table[i, 2];
                        SourceGrid.Cells.Cell atBeginActionCell =
                                (SourceGrid.Cells.Cell)Table[i, 3];

                        string atBeginCond = "(" + fromVertex + ">0" + ")";
                        string atBeginAction = fromVertex + "--;";

                        atBeginCondCell.Value = atBeginCondCell.DisplayText.Replace(atBeginCond, "");
                        atBeginActionCell.Value = atBeginActionCell.DisplayText.Replace(atBeginAction, "");

                        break;
                    }
                    else if (nameCell.DisplayText == fromVertex)
                    {
                        string atEndAction = toVertex + "++;";

                        bool done = false;
                        for (int k = i; k < i + Table[i, 1].RowSpan; k++)
                        {
                            SourceGrid.Cells.Cell atEndActionCell =
                                (SourceGrid.Cells.Cell)Table[k, 8];
                            SourceGrid.Cells.Cell infActCell =
                                (SourceGrid.Cells.Cell)Table[k, 9];
                            if (atEndActionCell.DisplayText.Contains(atEndAction))
                            {
                                atEndActionCell.Value = "";
                                infActCell.Value = "";

                                done = true;
                                break;
                            }
                        }
                        if (done)
                            break;
                    }
                }
            }
        }
        #endregion

        private void tsbAdd_Click(object sender, EventArgs e)
        {
            insertEmptyActivityTransition();
        }

        private void tsbDelete_Click(object sender, EventArgs e)
        {
            //Remove Activity Transition
            int sRow = Table.Selection.ActivePosition.Row;
            if (sRow < 0 || Table[sRow, 0] == null)
                return;

            if (Table[sRow, 0] != null && Table[sRow, 0].Value.Equals("Initialize"))
                return;
            //Delete rows from the datagrid
            //if (!string.IsNullOrEmpty(grid1[sRow, 1].DisplayText))
            //{
            //    string sName = grid1[sRow, 1].Value.ToString();
            //    //Delete from the table data
            //    this.Table.RemoveActivityTransition(sName);
            //}

            if (Table[sRow, 1].RowSpan > 1)
            {
                int maxRow = sRow + Table[sRow, 1].RowSpan - 1;
                for (int k = maxRow; k >= sRow; k--)
                {
                    Table.Rows.Remove(k);
                }
            }
            else
            {
                Table.Rows.Remove(sRow);
            }

            UpdateInitializeCell();
            setChange(true);
        }

        private void tsbSetEnabledActivity_Click(object sender, EventArgs e)
        {
            int row = Table.Selection.ActivePosition.Row;
            int column = Table.Selection.ActivePosition.Column;

            //grid1[row, 1].View = new SourceGrid.Cells.Views.Cell();
            if (Table[row, 1].View.Font == null)
            {
                SourceGrid.Cells.Views.Cell cell = new SourceGrid.Cells.Views.Cell();
                cell.Font = new Font("Times, Arial", 10.0f, FontStyle.Underline);
                Table[row, 1].View = cell;

            }
            else if (Table[row, 1].View.Font != null && !Table[row, 1].View.Font.Underline)
                Table[row, 1].View.Font = new Font(Table[row, 1].View.Font.FontFamily,
                                                    Table[row, 1].View.Font.Size, FontStyle.Underline);
            else
                Table[row, 1].View.Font = new Font(Table[row, 1].View.Font.FontFamily,
                                                    Table[row, 1].View.Font.Size, FontStyle.Regular);

            Table.Invalidate();
            UpdateInitializeCell();
            setChange(true);
        }

        private void tsbAddAtEnd_Click(object sender, EventArgs e)
        {
            int sRow = Table.Selection.ActivePosition.Row;

            Table.Rows.Insert(sRow + Table[sRow, 1].RowSpan);
            //grid1.Rows.Insert(sRow + 1);

            int noArc = Table[sRow, 1].RowSpan + 1;
            int arcRow = sRow + Table[sRow, 0].RowSpan;
            try
            {
                Table[sRow, 0].RowSpan++;
                Table[sRow, 1].RowSpan++;
                Table[sRow, 2].RowSpan++;
                Table[sRow, 3].RowSpan++;
                Table[sRow, 4].RowSpan++;
                Table[sRow, 5].RowSpan++;
            }
            catch (Exception ex) { }

            SourceGrid.Cells.Cell createae1Arc = new SourceGrid.Cells.Cell(noArc, typeof(int));
            SourceGrid.Cells.Views.Cell aeArcView = new SourceGrid.Cells.Views.Cell();
            aeArcView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
            createae1Arc.View = aeArcView;

            SourceGrid.Cells.Cell createae1Cond = new SourceGrid.Cells.Cell("true", typeof(string));
            SourceGrid.Cells.Views.Cell aeCondView = new SourceGrid.Cells.Views.Cell();
            aeCondView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
            createae1Cond.View = aeCondView;
            SourceGrid.Cells.Cell createae1Action = new SourceGrid.Cells.Cell("", typeof(string));
            SourceGrid.Cells.Cell createae1IA = new SourceGrid.Cells.Cell("", typeof(string));

            Table[arcRow, 6] = createae1Arc;
            Table[arcRow, 7] = createae1Cond;
            Table[arcRow, 8] = createae1Action;
            Table[arcRow, 9] = createae1IA;

            setChange(true);
        }

        private void tsbDelAtEnd_Click(object sender, EventArgs e)
        {
            int sRow = Table.Selection.ActivePosition.Row;
            if (sRow < 0 || Table.Selection.ActivePosition.Column < 6)
                return;

            if (Table[sRow, 0].RowSpan > 1)
            {
                if (Table[sRow, 0].Range.Start.Row == sRow)
                {
                    //첫 번째 at-end transition 의 경우 주의
                    int startRow = Table[sRow, 0].Range.Start.Row;
                    int endRow = Table[sRow, 0].Range.End.Row;
                    for (int k = startRow; k < endRow; k++)
                    {
                        Table[k, 6].Value = Table[k + 1, 6].Value;
                        Table[k, 7].Value = Table[k + 1, 7].Value;
                        Table[k, 8].Value = Table[k + 1, 8].Value;
                        Table[k, 9].Value = Table[k + 1, 9].Value;
                    }

                    Table.Rows.Remove(endRow);
                }
                else
                {
                    Table.Rows.Remove(sRow);
                }
                setChange(true);
            }
            else
            {
                //하나의 at-end transition만 있는 경우에는 Delete로만 가능 (at-end delete로는 지울 수 없음)
                //grid1.Rows.Remove(sRow);
            }

        }

        private void tsbAutoSizecell_Click(object sender, EventArgs e)
        {
            AutoSizeCells();

        }

        private void tsbSort_Click(object sender, EventArgs e)
        {
            if (_CurrentColumn > 1 || _CurrentColumn < 0)
                return;

            bool preChanged = IsChanged;
            UpdateToATT();

            Table.Rows.Clear();
            drawATTHeaders();

            if (_CurrentColumn == 0)
            {
                isNoAscending = !isNoAscending;
                insertActivityTransitionTable(_Model, _CurrentColumn, isNoAscending);
            }
            else if (_CurrentColumn == 1)
            {
                isNameAscending = !isNameAscending;
                insertActivityTransitionTable(_Model, _CurrentColumn, isNameAscending);
            }

            if (!preChanged)
            {
                IsChanged = false;
                setChange(false);
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            CopyGrid1toClipboard();
        }

        public void Open(OOAGActivityObjectModel model)
        {
            _Model = model;

            insertActivityTransitionTable(model);
        }

        private void grid1_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode == Keys.C && e.Control)
            {
                CopyGrid1toClipboard();
            }
            else if (e.KeyCode == Keys.T && e.Control)
            {
                tsbAdd_Click(sender, e);
            }
            else if (e.KeyCode == Keys.E && e.Control)
            {
                tsbAddAtEnd_Click(sender, e);
            }
        }


        private void CopyGrid1toClipboard()
        {
            UpdateToATT();

            StringBuilder buffer = new StringBuilder();

            //Header
            buffer.Append("No");
            buffer.Append('\t');
            buffer.Append("Activity");
            buffer.Append('\t');
            buffer.Append("At-begin");
            buffer.Append('\t');
            buffer.Append('\t');
            buffer.Append("BTO-event");
            buffer.Append('\t');
            buffer.Append('\t');
            buffer.Append("At-end");
            buffer.Append('\t');
            buffer.Append('\t');
            buffer.Append('\t');
            buffer.Append('\t');
            buffer.Append(Environment.NewLine);

            buffer.Append('\t');
            buffer.Append('\t');
            buffer.Append("Condition");
            buffer.Append('\t');
            buffer.Append("Action");
            buffer.Append('\t');
            buffer.Append("Time");
            buffer.Append('\t');
            buffer.Append("Name");
            buffer.Append('\t');
            buffer.Append("Arc");
            buffer.Append('\t');
            buffer.Append("Condition");
            buffer.Append('\t');
            buffer.Append("Action");
            buffer.Append('\t');
            buffer.Append("Influenced Activity");
            buffer.Append('\t');
            buffer.Append(Environment.NewLine);

            int count = 1;
            foreach (OOAGActivityTransition transition in _Model.ActivityTransitions)
            {
                buffer.Append(count++);
                buffer.Append('\t');
                buffer.Append(transition.Activity.Name);
                buffer.Append('\t');
                buffer.Append(transition.AtBegin.Condition);
                buffer.Append('\t');
                buffer.Append(transition.AtBegin.Action);
                buffer.Append('\t');
                buffer.Append(transition.Activity.TimeDelay);
                buffer.Append('\t');
                buffer.Append(transition.BTOEvent.Name);
                buffer.Append('\t');

                for (int k = 0; k < transition.AtEnds.Count; k++)
                {
                    OOAGAtEndTransition endTransition = transition.AtEnds[k];

                    if (k > 0)
                    {
                        buffer.Append('\t');
                        buffer.Append('\t');
                        buffer.Append('\t');
                        buffer.Append('\t');
                        buffer.Append('\t');
                        buffer.Append('\t');
                    }
                    buffer.Append(endTransition.Arc);
                    buffer.Append('\t');
                    buffer.Append(endTransition.Condition);
                    buffer.Append('\t');
                    buffer.Append(endTransition.Action);
                    buffer.Append('\t');
                    buffer.Append(endTransition.InfluencedActivity);

                    buffer.Append(Environment.NewLine);
                }
            }

            buffer.Append("Initialize");
            buffer.Append('\t');
            buffer.Append('\t');
            buffer.Append(this._InitialValueCell.DisplayText);
            buffer.Append(Environment.NewLine);

            Clipboard.SetText(buffer.ToString());

        }

        private void UpdateToATT()
        {

            //Queue
            _Model.Queues = _Parent.DiagramWindow.Queues;

            //Variable
            _Model.StateVariables = _Parent.VariableWindow.StateVariables;

            //Activity Transitions
            _Model.ActivityTransitions = new List<OOAGActivityTransition>();
            int rowspan = 1;
            for (int k = 2; k < Table.RowsCount - 1; k += rowspan)
            {
                SourceGrid.Cells.ICellVirtual[] cells = Table.GetCellsAtRow(k);
                int nullCount = 0;
                for (int p = 0; p < 10; p++)
                {
                    if (Table[k, p] == null || Table[k, p].Value == null)
                        nullCount++;
                }
                if (nullCount < 9)
                {
                    OOAGActivityTransition transition = new OOAGActivityTransition();
                    //transition.No = (int)grid1[k, 0].Value;
                    transition.Activity.Name = (string)Table[k, 1].Value;
                    transition.AtBegin.Condition = (string)Table[k, 2].Value;
                    transition.AtBegin.Action = (string)Table[k, 3].Value;
                    transition.Activity.TimeDelay = (string)Table[k, 4].Value;
                    transition.BTOEvent.Name = (string)Table[k, 5].Value;
                    if (Table[k, 1].View.Font != null)
                        transition.Activity.IsEnabled = Table[k, 1].View.Font.Underline;
                    else
                        transition.Activity.IsEnabled = false;
                    for (int m = k; m <= k + Table[k, 0].RowSpan - 1; m++)
                    {
                        OOAGAtEndTransition endTransition = new OOAGAtEndTransition();
                        endTransition.Arc = int.Parse(Table[m, 6].Value.ToString());
                        endTransition.Condition = (string)Table[m, 7].Value;
                        endTransition.Action = (string)Table[m, 8].Value;
                        endTransition.InfluencedActivity = (string)Table[m, 9].Value;
                        transition.AtEnds.Add(endTransition);
                    }
                    _Model.ActivityTransitions.Add(transition);

                    rowspan = Table[k, 0].RowSpan;
                }
                else
                {
                    rowspan = 1;
                }
            }
        }

        //ACD --> ATT
        public void UpdateATT()
        {
            //Queue
            _Model.Queues = _Parent.DiagramWindow.Queues;

            //Variable
            _Model.StateVariables = _Parent.VariableWindow.StateVariables;

            _Model.ActivityTransitions.Clear();
            //ActivityTransitionSet
            List<ActivityNode> activityNodes = _Parent.DiagramWindow.ActivityNodeList;
            foreach (ActivityNode node in activityNodes)
            {
                OOAGActivityTransition transition = new OOAGActivityTransition();
                string atBeginCond = "";
                string abBeginAction = "";
                List<string> conds = new List<string>();
                foreach (Arc incomingArc in node.SourceLinks)
                {
                    QueueNode qNode = (QueueNode)incomingArc.FromNode;
                    int arcSize = incomingArc.Multiplicity;
                    string arcCond = incomingArc.Condition;
                    //At-Begin Condition/State Update
                    string cond = "";
                    string stateupdate = "";

                    if (arcSize > 1)
                    {
                        cond = qNode.Queue.Name + ">=" + arcSize.ToString();
                        stateupdate = qNode.Queue.Name + "-=" + arcSize.ToString() + ";";
                    }
                    else
                    {
                        cond = qNode.Queue.Name + ">0";
                        stateupdate = qNode.Queue.Name + "--;";
                    }

                    conds.Add(cond);

                    if (!string.IsNullOrEmpty(arcCond) && arcCond.ToLower() != "true")
                    {
                        conds.Add(arcCond);
                    }
                    abBeginAction += stateupdate;
                }

                for (int i = 0; i < conds.Count; i++)
                {
                    if (i < (conds.Count - 1))
                        atBeginCond += conds[i] + " && ";
                    else
                        atBeginCond += conds[i];
                }

                transition.Activity = node.Activity;
                transition.AtBegin.Condition = atBeginCond;
                transition.AtBegin.Action = abBeginAction;
                //transition.BTOEvent.Time = node.Activity.TimeDelay;
                transition.BTOEvent.Name = node.Activity.Name + "_Event";
                
                float lastProb = 0.0f;
                int arcIndex = 1;
                foreach (Arc outgoingArc in node.DestinationLinks)
                {
                    OOAGAtEndTransition atEndTransition = new OOAGAtEndTransition();

                    QueueNode qNode = (QueueNode)outgoingArc.ToNode;
                    //At-End State Update
                    float prob = outgoingArc.Probability;
                    string stateupdate = "";
                    if (prob > 0.0)
                    {
                        float nextProb = lastProb + prob;
                        if (nextProb == 1.0)
                            stateupdate = "if ( " + lastProb.ToString() + " <= U && U <= " + nextProb.ToString() + " ) { " + qNode.Queue.Name+ "++;} ";
                        else
                            stateupdate = "if ( " + lastProb.ToString() + " <= U && U < " + nextProb.ToString() + " ) { " + qNode.Queue.Name + "++;} ";
                        lastProb = nextProb;
                    }
                    else
                        stateupdate = qNode.Queue.Name + "++;";

                    //At-End Influenced Activity Set
                    List<string> influencedSet = new List<string>();
                    foreach (ActivityNode infActNode in qNode.Destinations)
                    {
                        influencedSet.Add(infActNode.Activity.Name);
                    }
                    string infActSet = "";
                    for (int i = 0; i < influencedSet.Count; i++)
                    {
                        if (i < (influencedSet.Count - 1))
                            infActSet += influencedSet[i] + ",";
                        else
                            infActSet += influencedSet[i];
                    }

                    atEndTransition.Condition = outgoingArc.Condition;
                    atEndTransition.Action = stateupdate;
                    atEndTransition.InfluencedActivity = infActSet;
                    atEndTransition.Arc = arcIndex++;

                    transition.AtEnds.Add(atEndTransition);
                }

                _Model.ActivityTransitions.Add(transition);
            }

            insertActivityTransitionTable(_Model);
        }

        private void AutoSizeCells()
        {
            Table.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowOnly;
            Table.AutoStretchColumnsToFitWidth = true;
            Table.AutoSizeCells(new SourceGrid.Range(2, 0, Table.RowsCount - 2, 9));
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            UpdateATT();
        }

        private void Table_MouseWheel(object sender, MouseEventArgs e)
        {
            if (Form.ModifierKeys == Keys.Control)
            {
                if (e.Delta > 0)
                {
                    //zoom in
                    zoomIn();
                }
                else if (e.Delta < 0)
                {
                    //zoom out
                    zoomOut();
                }
            }
        }

        private void zoomIn()
        {
            Table.Font = new Font(Table.Font.FontFamily, Table.Font.Size + 1);
            titleModel.Font = new Font(titleModel.Font.FontFamily, Table.Font.Size + 1, FontStyle.Bold);
            AutoSizeCells();
        }

        private void zoomOut()
        {
            Table.Font = new Font(Table.Font.FontFamily, Table.Font.Size - 1);
            titleModel.Font = new Font(titleModel.Font.FontFamily, Table.Font.Size - 1, FontStyle.Bold);

            AutoSizeCells();
        }

    }

    public class GridChangeController : SourceGrid.Cells.Controllers.ControllerBase
    {
        public delegate void GridChangeDelegate(object source);
        public GridChangeDelegate GridChanged;

        public override void OnValueChanged(SourceGrid.CellContext sender, EventArgs e)
        {
            base.OnValueChanged(sender, e);

            if (GridChanged != null)
                GridChanged(sender.Grid);
        }
    }

    public class HeaderSortingController : SourceGrid.Cells.Controllers.ControllerBase
    {
        bool AscendingOrder = false;

        public override void OnMouseDown(SourceGrid.CellContext sender, MouseEventArgs e)
        {
            base.OnMouseDown(sender, e);
            if (e.Clicks == 2)
            {
                if (AscendingOrder)
                {

                }
                else
                {

                }

                AscendingOrder = !AscendingOrder;
            }
        }
    }
}
