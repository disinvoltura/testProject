﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;
using WeifenLuo.WinFormsUI.Docking;
using Northwoods.Go;
using DHKANG.SEA.Model.ActivityObjects;

namespace DHKANG.SEA.UI.ATTEditor
{
    public enum ChangedType { Added, Deleted, Modified };
    public enum ChangedTarget { Schedule, Activity, Queue, StateVariable, Parameter, Functions, Arc};

    public delegate void ChangedEventHandler(ChangedTarget targetType,
                                              ChangedType changedType,
                                              object before, object after);


    public partial class ActivityObjectModelEditor : Form
    {
        #region Member Variables
        private StateVariableWindow _SVWindow;
        private ActivityTransitionTableWindow _ATTWindow;
        private ActivityCycleDiagramWindow _ACDWindow;
        private ATTPropertiesWindow _PropertiesWindow;
        private bool _IsChanged;
        private OOAGActivityObjectModel _Model;

        private NodeFactory _NodeFactory;

        private WeifenLuo.WinFormsUI.Docking.VS2012LightTheme vS2012LightTheme1;
        private WeifenLuo.WinFormsUI.Docking.VS2015LightTheme vS2015LightTheme1;
        #endregion

        #region Properties
        public bool IsModelChanged { get { return _IsChanged; } }

        public ActivityCycleDiagramWindow DiagramWindow
        {
            get { return _ACDWindow; }
        }

        public ActivityTransitionTableWindow TableWindow
        {
            get { return _ATTWindow; }
        }

        public StateVariableWindow VariableWindow
        {
            get { return _SVWindow; }
        }

        public OOAGActivityObjectModel ActivityObjectModel
        {
            get
            {
                OOAGActivityObjectModel rslt = _Model;

                //Queue
                rslt.Queues = _ACDWindow.Queues;
                //Variables
                rslt.StateVariables = _SVWindow.StateVariables;
                //Transitions
                List<OOAGActivity> activityList = _ACDWindow.Activities;
                rslt.ActivityTransitions = _ATTWindow.ActivityTransitions;
                foreach(OOAGActivityTransition at in rslt.ActivityTransitions)
                {
                    OOAGActivity act = activityList.Find(a => a.Name.Equals(at.Activity.Name));
                    if (act != null)
                    {
                        bool isEnabled = at.Activity.IsEnabled;
                        at.Activity = act;
                        at.Activity.IsEnabled = isEnabled;
                    }                    
                }
                //arcs
                rslt.Arcs = _ACDWindow.Arcs;
                return rslt;
            }
        }
        #endregion

        #region Constructors
        public ActivityObjectModelEditor(OOAGActivityObjectModel model)
        {
            InitializeComponent();

            this.vS2012LightTheme1 = new WeifenLuo.WinFormsUI.Docking.VS2012LightTheme();
            this.vS2015LightTheme1 = new WeifenLuo.WinFormsUI.Docking.VS2015LightTheme();
            dockPanel1.Theme = vS2015LightTheme1;

            _Model = model;
            _IsChanged = false;

            CreateLayout();

            //_NodeFactory = new NodeFactory();
            //_NodeFactory.Document = _EGDWindow.View.Doc;

            //_ACDWindow.NodeFactory = _NodeFactory;
            //_ATTWindow.NodeFactory = _NodeFactory;

            _ATTWindow.Update(model);
            _ACDWindow.Update(model);
            _SVWindow.Update(model);

            _IsChanged = false;

            this.Text = _Model.Name + " ::: Activity Object Model Editor";
        }
        #endregion 

        #region Methods
        private void CreateLayout()
        {
            //dockPanel1.Theme = new WeifenLuo.WinFormsUI.Docking.VS2012LightTheme(); ;

            _ACDWindow = new ActivityCycleDiagramWindow(this);
            _ACDWindow.Show(dockPanel1, DockState.Document);
            _ACDWindow.DockHandler.AllowEndUserDocking = true;
            _ACDWindow.DockHandler.CloseButtonVisible = false;
            _ACDWindow.DockHandler.CloseButton = false;
            _ACDWindow.View.DocumentChanged += new GoChangedEventHandler(OnDocumentChanged);
            _ACDWindow.ObjectSelected += OnACDWindow_ObjectSelected;

            dockPanel1.DockBottomPortion = 0.5;

            //tsbAddText.Checked = false;
            _ATTWindow = new ActivityTransitionTableWindow(this);
            _ATTWindow.Show(dockPanel1, DockState.DockBottom);
            _ATTWindow.DockHandler.AllowEndUserDocking = true;
            _ATTWindow.DockHandler.CloseButtonVisible = false;
            _ATTWindow.DockHandler.CloseButton = false;

            _SVWindow = new StateVariableWindow(this);
            _SVWindow.Show(dockPanel1, DockState.DockBottom);
            _SVWindow.DockHandler.CloseButtonVisible = false;
            _SVWindow.DockHandler.CloseButton = false;            
            _SVWindow.Changed += new ChangedEventHandler(OnChanged);

            _PropertiesWindow = new ATTPropertiesWindow(this);
            _PropertiesWindow.Show(dockPanel1, DockState.DockBottom);
            _PropertiesWindow.DockHandler.AllowEndUserDocking = true;
            _PropertiesWindow.DockHandler.CloseButtonVisible = false;
            _PropertiesWindow.DockHandler.CloseButton = false;
            
            _ATTWindow.Changed += new ActivityTransitionTableChangedEvent(_ACDWindow.OnATTChanged);
            _ATTWindow.Changed += new ActivityTransitionTableChangedEvent(OnATTChanged);
            _ACDWindow.Changed += new ActivityCycleDiagramChangedEvent(_ATTWindow.OnACDChanged);

            _ATTWindow.Activate();
        }

        private void OnACDWindow_ObjectSelected(OOMMModel model, object target)
        {
            _PropertiesWindow.Update(model, target);
        }

        private void OnDocumentChanged(object sender, GoChangedEventArgs e)
        {
            _IsChanged = true;
        }

        private void OnDiagramChanged(ChangedTarget target, ChangedType action, object before, object after)
        {
            _ATTWindow.OnACDChanged(target, action, before, after);            
        }

        private void OnATTChanged(string target, string action, string before, string after)
        {
            _IsChanged = true;
        }

        private void OnEventNameChanged(string oldEventName, string newEventName)
        {
            _ACDWindow.OnATTChanged("eventvertex", "changed", oldEventName, newEventName);
        }
        
        private void OnChanged(ChangedTarget targetType, 
                                              ChangedType changedType,
                                              object before, object after)
        {
            _IsChanged = true;
        }

        #endregion

        private void EOMControl_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_IsChanged)
                this.DialogResult = System.Windows.Forms.DialogResult.OK;
            else
                this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }

    }
}
