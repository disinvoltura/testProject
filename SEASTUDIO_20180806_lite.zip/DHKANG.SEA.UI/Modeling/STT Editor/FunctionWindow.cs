﻿using System;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ICSharpCode.TextEditor.Document;
using Microsoft.CSharp;
using DHKANG.SEA.Model;
using WeifenLuo.WinFormsUI.Docking;
using DHKANG.SEA.Model.StateObjects;

namespace DHKANG.SEA.UI.STTEditor
{
    public partial class FunctionWindow : DockContent
    {
        #region Member Variables
        private StateObjectModelEditor _AMControl;
        private bool _IsUpdating;
        #endregion

        #region Events
        public ChangedEventHandler Changed;
        #endregion

        #region Properties
        public string Functions
        {
            get { return this.tecFuncs.Text; }
        }
        #endregion

        #region Constructors
        public FunctionWindow(StateObjectModelEditor parent)
        {
            _AMControl = parent;

            InitializeComponent();

            //tecFuncs.Text = functions;
        }
        #endregion

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            base.OnFormClosing(e);
        }

        public void Update(OOSGStateObjectModel am)
        //public void Update(AtomicModel am)
        {
            _IsUpdating = true;
            tecFuncs.Text = am.Functions;

            tecFuncs.Document.HighlightingStrategy = HighlightingStrategyFactory.CreateHighlightingStrategy("C#");
            tecFuncs.Text = am.Functions;
            _IsUpdating = false;
        }

        #region Compilation
        private string _N = Environment.NewLine;
        private string _Q = "\""; //quotation
        private string _L = "{";
        private string _R = "}";
        private string _T = "\t";
        private string _S = "#region";
        private string _E = "#endregion";
        private string _C = ";";
        private string _U = " = ";

        private int _LineNumFunctions;
        private string getFunctionCode()
        {
            string code = string.Empty;

            string amName = _AMControl.StateObjectModel.Name.Replace(" ", "").Replace("(", "").Replace(")", "").Replace("-", "");

            code += generateHeaderComment(amName);

            code += generateConstructor(amName) + _N;

            code += generateCurrentStateProperty() + _N;

            code += generateOverrideMethod(_AMControl.StateObjectModel) + _N;

            code += generateStateVariableMethods(_AMControl.StateObjectModel) + _N;

            if (!string.IsNullOrEmpty(this.tecFuncs.Text))
            {
                code += getTab(2) + _S + " Functions" + _N;

                string[] tmp = code.Split(new string[] { _N }, StringSplitOptions.None);
                _LineNumFunctions = tmp.Length;
                code += this.tecFuncs.Text;
                code += _N + getTab(2) + _E + _N;
            }

            code += getTab(1) + _R + _N;
            code += _R;

            System.Diagnostics.Debug.WriteLine(code);
            return code;
        }

        private string generateOverrideMethod(OOSGStateObjectModel atomic)
        //private string generateOverrideMethod(AtomicModel atomic)
        {
            string method = string.Empty;
            method = getTab(2) + "public override void Run()" + _N;
            method += getTab(2) + _L + _N;
            method += getTab(2) + _R + _N + _N;

            method += getTab(2) + "public override void ExternalInput(INPUT input)" + _N;
            method += getTab(2) + _L + _N;
            method += getTab(2) + _R + _N;
            return method;

        }

        private string generateStateVariableMethods(OOSGStateObjectModel atomic)
        //private string generateStateVariableMethods(AtomicModel atomic)
        {
            string method = string.Empty;
            method += getTab(2) + "public override object getStateVariable(string name)" + _N;
            method += getTab(2) + _L + _N;

            string properties = string.Empty;
            if (atomic.StateVariables.Count > 0)
            {
                //int count = 0;
                foreach (OOSGStateVariable sv in atomic.StateVariables)
                {
                    method += getTab(3) + "if (name.Equals(\"" + sv.Name + "\"))" + _N;
                    method += getTab(4) + "return this." + sv.Name + _C + _N;

                    if (sv.Type == OOSGStateVariableHelper.TIMEQUEUE)
                    {
                        properties += getTab(2) + "public double " + sv.Name + "_Tau { get { return " + sv.Name + ".Tau;} set { " + sv.Name + ".Tau = value;}}";
                    }
                }
            }

            method += getTab(3) + "return null" + _C + _N;
            method += getTab(2) + _R + _N;

            method += properties + _N;

            return method;
        }

        private string generateCurrentStateProperty()
        {
            string property = string.Empty;

            property += getTab(2) + "public override string CurrentState" + _N;
            property += getTab(2) + _L + _N;
            property += getTab(3) + "get { return \"\";}" + _N;
            //property += getTab(3) + "get { return this.STATE.ToString();}" + _N;
            property += getTab(2) + _R + _N;

            return property;
        }


        private string generateHeaderComment(string name)
        {
            string headerTemplate =
@" 
using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using Troschuetz.Random;
using VMS.StateGraph.Data;
using VMS.StateGraph.Simulation;
using VMS.StateGraph.Simulation.Random;
" + _N + _N;

            return headerTemplate;
        }

        private string generateConstructor(string amName)
        {
            string namespaceName = amName;

            string constructor = "namespace " + namespaceName + _N;
            constructor += _L + _N;
            constructor += getTab(1) + "public class " + amName + " : AtomicSimulator " + _N;
            constructor += getTab(1) + _L + _N;
            constructor += getTab(2) + _S + " Variables and Constructor" + _N;

            foreach (OOSGParameter pm in _AMControl.StateObjectModel.Parameters) //Parameters
            {
                if (pm.Type.Equals(OOSGStateVariableHelper.INT))
                {
                    constructor += getTab(2) + "public int " + pm.Name + _C + _N;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.STRING))
                {
                    constructor += getTab(2) + "public string " + pm.Name + _C + _N;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.DOUBLE))
                {
                    constructor += getTab(2) + "public double " + pm.Name + _C + _N;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.DATETIME))
                {
                    constructor += getTab(2) + "public DateTime " + pm.Name + _C + _N;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.BOOL))
                {
                    constructor += getTab(2) + "public bool " + pm.Name + _C + _N;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.RANDOMVARIATE))
                {
                    constructor += getTab(2) + "public RandomVariate " + pm.Name + _C + _N;
                }
                else
                {
                    constructor += getTab(2) + "public " + pm.Type.ToString() + " " + pm.Name + _C + _N;
                }
            }

            foreach (OOSGStateVariable sv in _AMControl.StateObjectModel.StateVariables) //state variable (public)
            {
                constructor += getTab(2) + "public " + sv.Type + " " + sv.Name + _C + _N;
            }

            constructor += getTab(2) + "public " + amName + "(string name)" + _N;
            constructor += getTab(3) + " : base (name)" + _N;
            constructor += getTab(2) + _L + _N;

            //Parameters
            foreach (OOSGParameter pm in _AMControl.StateObjectModel.Parameters)
            {
                if (pm.Type.Equals(OOSGStateVariableHelper.INT))
                {
                    if (pm.InitialValue == null || string.IsNullOrEmpty(pm.InitialValue.ToString()))
                        constructor += getTab(3) + pm.Name + _U + "0" + _C + _N;
                    else if (pm.InitialValue.ToString().ToLower().Contains("maxvalue"))
                        constructor += getTab(3) + pm.Name + _U + pm.InitialValue.ToString() + _C + _N;
                    else if (pm.InitialValue.ToString().ToLower().Contains("minvalue"))
                        constructor += getTab(3) + pm.Name + _U + pm.InitialValue.ToString() + _C + _N;
                    else
                        constructor += getTab(3) + pm.Name + _U + int.Parse(pm.InitialValue.ToString()) + _C + _N;
                    break;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.STRING))
                {
                    if (pm.InitialValue == null || string.IsNullOrEmpty(pm.InitialValue.ToString()))
                        constructor += getTab(3) + pm.Name + _U + "" + _C + _N;
                    else
                        constructor += getTab(3) + pm.Name + _U + pm.InitialValue.ToString() + _C + _N;
                    break;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.DOUBLE))
                {
                    if (pm.InitialValue == null || string.IsNullOrEmpty(pm.InitialValue.ToString()))
                        constructor += getTab(3) + pm.Name + _U + "0.0" + _C + _N;
                    else if (pm.InitialValue.ToString().ToLower().Contains("maxvalue"))
                        constructor += getTab(3) + pm.Name + _U + pm.InitialValue.ToString() + _C + _N;
                    else if (pm.InitialValue.ToString().ToLower().Contains("minvalue"))
                        constructor += getTab(3) + pm.Name + _U + pm.InitialValue.ToString() + _C + _N;
                    else
                        constructor += getTab(3) + pm.Name + _U + double.Parse(pm.InitialValue.ToString()) + _C + _N;
                    break;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.DATETIME))
                {
                    if (pm.InitialValue == null || string.IsNullOrEmpty(pm.InitialValue.ToString()))
                        constructor += getTab(3) + pm.Name + _C + _N;
                    else
                        constructor += getTab(3) + pm.Name + _U + DateTime.Parse(pm.InitialValue.ToString()) + _C + _N;
                    break;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.BOOL))
                {
                    if (pm.InitialValue == null || string.IsNullOrEmpty(pm.InitialValue.ToString()))
                        constructor += getTab(3) + pm.Name + _U + "true" + _C + _N;
                    else
                        constructor += getTab(3) + pm.Name + _U + pm.InitialValue.ToString() + _C + _N;
                    break;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.RANDOMVARIATE))
                {
                    if (pm.InitialValue == null || string.IsNullOrEmpty(pm.InitialValue.ToString()))
                        constructor += getTab(3) + pm.Name + _U + "null" + _C + _N;
                    else
                    {
                        constructor += getTab(3) + pm.Name + _U + "RandomVariateGenerator.GetRandomVariate(\"" + pm.InitialValue.ToString() + "\")" + _C + _N;
                    }
                    break;
                }
                else
                {
                    constructor += getTab(3) + pm.Name + _U + " new " + pm.Type.ToString() + "()" + _C + _N;
                    break;
                }
            }

            //State Variables
            foreach (OOSGStateVariable sv in _AMControl.StateObjectModel.StateVariables) //state variable (public)
            {
                if (sv.Type == OOSGStateVariableHelper.INT)
                {
                    if (sv.InitialValue == null || string.IsNullOrEmpty(sv.InitialValue.ToString()))
                        constructor += getTab(3) + sv.Name + _U + "0" + _C + _N;
                    else if (sv.InitialValue.ToString().ToLower().Contains("maxvalue"))
                        constructor += getTab(3) + sv.Name + _U + " int.MaxValue" + _C + _N;
                    else if (sv.InitialValue.ToString().ToLower().Contains("minvalue"))
                        constructor += getTab(3) + sv.Name + _U + " int.MinValue" + _C + _N;
                    else
                        constructor += getTab(3) + sv.Name + _U + sv.InitialValue.ToString() + _C + _N;
                    break;
                }
                else if (sv.Type == OOSGStateVariableHelper.STRING)
                {
                    if (sv.InitialValue == null || string.IsNullOrEmpty(sv.InitialValue.ToString()))
                        constructor += getTab(3) + sv.Name + _U + "" + _C + _N;
                    else
                        constructor += getTab(3) + sv.Name + _U + sv.InitialValue.ToString() + _C + _N;
                    break;
                }
                else if (sv.Type == OOSGStateVariableHelper.DOUBLE)
                {
                    if (sv.InitialValue == null || string.IsNullOrEmpty(sv.InitialValue.ToString()))
                        constructor += getTab(3) + sv.Name + _U + "0.0" + _C + _N;
                    else if (sv.InitialValue.ToString().ToLower().Contains("maxvalue"))
                        constructor += getTab(3) + sv.Name + _U + " double.MaxValue" + _C + _N;
                    else if (sv.InitialValue.ToString().ToLower().Contains("minvalue"))
                        constructor += getTab(3) + sv.Name + _U + " double.MinValue" + _C + _N;
                    else
                        constructor += getTab(3) + sv.Name + _U + sv.InitialValue.ToString() + _C + _N;
                    break;
                }
                else if (sv.Type == OOSGStateVariableHelper.DATETIME)
                {
                    if (sv.InitialValue == null || string.IsNullOrEmpty(sv.InitialValue.ToString()))
                        constructor += getTab(3) + sv.Name + _C + _N;
                    else
                        constructor += getTab(3) + sv.Name + _U + " DateTime.Parse( " + sv.InitialValue.ToString() + ")" + _C + _N;
                    break;
                }
                else if (sv.Type == OOSGStateVariableHelper.BOOL)
                {
                    if (sv.InitialValue == null || string.IsNullOrEmpty(sv.InitialValue.ToString()))
                        constructor += getTab(3) + sv.Name + _U + "true" + _C + _N;
                    else
                        constructor += getTab(3) + sv.Name + _U + sv.InitialValue.ToString() + _C + _N;
                    break;
                }
                else if (sv.Type == OOSGStateVariableHelper.TIMEQUEUE)
                {
                    constructor += getTab(3) + sv.Name + _U + " new TimeQueue(this)" + _C + _N;
                    break;
                }
                else
                {
                    if (sv.Type.Contains("["))
                    {
                        if (sv.InitialValue != null)
                            constructor += getTab(3) + sv.Name + _U + " new " + sv.Type + sv.InitialValue + _C + _N;
                    }
                    else
                    {
                        constructor += getTab(3) + sv.Name + _U + " new " + sv.Type + "()" + _C + _N;
                    }
                    break;
                }
            }

            constructor += getTab(2) + _R + _N;
            constructor += getTab(2) + _E + _N;
            return constructor;
        }

        private string getTab(int count)
        {
            string tab = string.Empty;
            for (int i = 0; i < count; i++)
                tab += _T;
            return tab;
        }

        private bool compile()
        {
            CSharpCodeProvider codeProvider = new CSharpCodeProvider();

            ICodeCompiler icc = codeProvider.CreateCompiler();

            string amName = _AMControl.StateObjectModel.Name;
            string Output = amName + ".dll";

            System.CodeDom.Compiler.CompilerParameters parameters = new CompilerParameters();
            parameters.GenerateExecutable = false;
            parameters.GenerateInMemory = true;
            parameters.ReferencedAssemblies.Add("system.dll");
            parameters.ReferencedAssemblies.Add(Application.StartupPath + @"\" + "Troschuetz.Random.dll");
            parameters.ReferencedAssemblies.Add(Application.StartupPath + @"\" + "VMS.StateGraph.Data.dll");
            parameters.ReferencedAssemblies.Add(Application.StartupPath + @"\" + "VMS.StateGraph.Simulation.dll");

            string[] codes = new string[] { getFunctionCode() };

            string codeName = amName + ".cs";

            CompilerResults results = icc.CompileAssemblyFromSourceBatch(parameters, codes);

            lvOutput.Items.Clear();

            bool rslt = false;
            if (results.Errors.Count > 0)
            {
                //rtxtOutput.ForeColor = Color.Red;
                foreach (CompilerError CompErr in results.Errors)
                {
                    if (CompErr.IsWarning)
                        continue;

                    ListViewItem item = new ListViewItem(CompErr.ErrorText);

                    if (!string.IsNullOrEmpty(CompErr.FileName))
                    {
                        string tmpRFN = CompErr.FileName.Remove(0, parameters.TempFiles.BasePath.Length).Substring(1);
                        string tmpNum = tmpRFN.Substring(0, tmpRFN.IndexOf("."));
                        string tmpFN = "";
                        item.SubItems.Add(tmpFN);
                    }
                    else
                        item.SubItems.Add("");

                    int line = CompErr.Line - _LineNumFunctions + 1;
                    item.SubItems.Add(line.ToString());
                    item.SubItems.Add(CompErr.Column.ToString());
                    item.SubItems.Add(CompErr.ErrorNumber);
                    item.Tag = CompErr;

                    lvOutput.Items.Add(item);
                }

                rslt = false;
            }
            else
            {
                rslt = true;
                //setMessage("Ready.");
            }

            return rslt;
        }

        #endregion

        private void tsbCompile_Click(object sender, EventArgs e)
        {
            bool rslt = compile();

            if (!rslt)
            {
                MessageBox.Show("Check the error list for details.");
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            tecFuncs.Document.FormattingStrategy.IndentLines(tecFuncs.ActiveTextAreaControl.TextArea, 0, tecFuncs.Document.TotalNumberOfLines - 1);

        }

        private string _LastValue;
        private void tecFuncs_Enter(object sender, EventArgs e)
        {
            _LastValue = tecFuncs.Text;
        }

        private void tecFuncs_Leave(object sender, EventArgs e)
        {
            if (!tecFuncs.Text.Equals(_LastValue))
            {
                if (_IsUpdating)
                    return;

                string oldValue = _LastValue;
                string newValue = tecFuncs.Text;

                if (Changed != null && Changed.GetInvocationList().Length > 0)
                    Changed(ChangedTarget.Functions, ChangedType.Modified, oldValue, newValue);
            }
        }
    }
}
