﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Windows.Forms;
using Northwoods.Go;
using System.ComponentModel;
using DHKANG.SEA.UI.ETTEditor;

namespace DHKANG.SEA.UI.STTEditor
{
    public enum StateGraphInsertionMode { None, Label, Text, TransitionEdge}
    
    public class StateGraphDiagramView : GoView
    {
        #region Events
        public event DocumentScaleChangedEventHandler ScaleChanged;
        public bool AutoConnect = true;
        #endregion

        #region Member Variables
        private PointF myOriginalDocPosition = new PointF();
        private float myOriginalDocScale = 1.0f;
        private bool myOriginalScale = true;
        private InsertionMode _CurrentMode = InsertionMode.None;

        public static readonly float ARCATTRIBUTE_FONTSIZE = 6.0f;
        public static readonly Color ARCATTRIBUTE_COLOR = Color.Blue;
        public bool ShowLinkLength = true;
        #endregion

        #region Properties
        public InsertionMode InsertionMode
        {
            get { return _CurrentMode; }
            set { _CurrentMode = value; }
        }

        public List<StateVertexNode> StateVertices
        {
            get
            {
                List<StateVertexNode> rslt = new List<StateVertexNode>();
            
                foreach(GoObject obj in this.Doc)
                {
                    if (obj is GoNode)
                    {
                        GoNode presentation = (GoNode)obj;
                        if (presentation.UserObject is StateVertexNode)
                        {
                            StateVertexNode node = (StateVertexNode)presentation.UserObject;
                            rslt.Add(node);
                        }
                    }
                }

                return rslt;
            }
        }

        public List<ScheduleNode> Schedules
        {
            get
            {
                List<ScheduleNode> rslt = new List<ScheduleNode>();

                foreach (GoObject obj in this.Doc)
                {
                    if (obj is ScheduleNode)
                    {
                        rslt.Add((ScheduleNode)obj);
                    }
                }

                return rslt;
            }
        }

        public List<MessageNode> Messages 
        {
            get
            {
                List<MessageNode> rslt = new List<MessageNode>();

                foreach (GoObject obj in this.Doc)
                {
                    if (obj is MessageNode)
                    {
                        rslt.Add((MessageNode)obj);
                    }
                }

                return rslt;
            }
        }

        public List<ParameterNode> Parameters 
        {
            get
            {
                List<ParameterNode> rslt = new List<ParameterNode>();

                foreach (GoObject obj in this.Doc)
                {
                    if (obj is ParameterNode)
                    {
                        rslt.Add((ParameterNode)obj);
                    }
                }

                return rslt;
            }
        }

        public StateGraphDiagramDocument Doc
        {
            get { return this.Document as StateGraphDiagramDocument; }
        }

        #endregion

        #region Constructors
        public StateGraphDiagramView()
            : base()
        {
            this.GridSnapDrag = GoViewSnapStyle.Jump;
            this.GridStyle = GoViewGridStyle.Line;
            this.GridCellSize = new SizeF(10, 10);
            this.GridLineWidth = 0.1f;
        }
        #endregion

        #region Methods
        /// <summary>
        /// A new GraphView will have a GraphDoc as its document.
        /// </summary>
        /// <returns>A <see cref="NodeLinkDiagramDocument"/></returns>
        public override GoDocument CreateDocument()
        {
            GoDocument doc = new StateGraphDiagramDocument();
            doc.UndoManager = new GoUndoManager();
            return doc;
        }

        public static GoText CreateLabel(string textValue)
        {
            GoText fromLabel = new GoText();
                fromLabel.FontSize = 8;
                fromLabel.EditableWhenSelected = false;
                fromLabel.Editable = false;
                fromLabel.Text = textValue;

            return fromLabel;
        }
        
        public static int LastID = 0;
        public static int LinkCount = 0;
        public static Transition MakeLink(InsertionMode mode)
        {
            Transition rslt = null;

            if (mode == InsertionMode.TransitionEdge)
            {
                rslt = new Transition();

                //rslt.FromLabel = CreateLabel("");
                //rslt.ToLabel = CreateLabel("");

                //rslt.AvoidsNodes = true;
                //rslt.Brush = Brushes.Black;
                //rslt.ToArrow = true;
                //rslt.ToArrowFilled = true;
                //rslt.ToArrowStyle = GoStrokeArrowheadStyle.Polygon;
                //rslt.ToArrowWidth = 8.0f;
                //rslt.ToArrowLength = 6.0f;
                //rslt.ToArrowShaftLength = 4.0f;
                //rslt.AdjustingStyle = GoLinkAdjustingStyle.Scale;

                //rslt.Style = GoStrokeStyle.Bezier;//GoStrokeStyle.Bezier;// GoStrokeStyle.Bezier;
                //rslt.RealLink.PenWidth = 2; 
            }

            return rslt;
        }

        public bool AllowLink
        {
            get
            {
                return base.AllowLink;
            }

            set
            {
                //change to straight line
                base.AllowLink = value;
                if (value)
                {                    
                    GoLabeledLink link = StateGraphDiagramView.MakeLink(_CurrentMode);
                    //link.ToArrowWidth = 2.0f;
                    this.NewGoLabeledLink = link;
                }
            }
        }

        #endregion

        #region Node Arrange methods
        //align all object's left sides to the left side of the primary selection
        public virtual void AlignLeftSides()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float X = obj.SelectionObject.Left;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Left = X;
                }
                FinishTransaction("Align Left Sides");
            }
            else
            {
                //MessageBox.Show("Alignment failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        //align all object's horizontal centers to the horizontal center of the primary selection
        public virtual void AlignHorizontalCenters()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float X = obj.SelectionObject.Center.X;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Center = new PointF(X, t.Center.Y);
                }
                FinishTransaction("Align Horizontal Centers");
            }
            else
            {
                // MessageBox.Show("Alignment failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        //align all object's right sides to the right side of the primary selection
        public virtual void AlignRightSides()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float X = obj.SelectionObject.Right;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Right = X;
                }
                FinishTransaction("Align Right Sides");
            }
            else
            {
                //MessageBox.Show("Alignment failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        //align all object's tops to the top of the primary selection
        public virtual void AlignTops()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float Y = obj.SelectionObject.Top;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Top = Y;
                }
                FinishTransaction("Align Tops");
            }
            else
            {
                // MessageBox.Show("Alignment failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        //align all object's vertical centers to the vertical center of the primary selection
        public virtual void AlignVerticalCenters()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float Y = obj.SelectionObject.Center.Y;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Center = new PointF(t.Center.X, Y);
                }
                FinishTransaction("Align Vertical Centers");
            }
            else
            {
                //MessageBox.Show("Alignment failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        //align all object's bottoms to the bottom of the primary selection
        public virtual void AlignBottoms()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float Y = obj.SelectionObject.Bottom;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Bottom = Y;
                }
                FinishTransaction("Align Bottoms");
            }
            else
            {
                //MessageBox.Show("Alignment failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        // this makes the widths of all objects equal to the width of the main selection.
        public virtual void MakeWidthsSame()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                float W = obj.SelectionObject.Width;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Width = W;
                }
                FinishTransaction("Same Widths");
            }
            else
            {
                //MessageBox.Show("Sizing failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        // this makes the heights of all objects equal to the height of the main selection.
        public virtual void MakeHeightsSame()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {

                StartTransaction();
                float H = obj.SelectionObject.Height;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Height = H;
                }
                FinishTransaction("Same Heights");
            }
            else
            {
                // MessageBox.Show("Sizing failure: Primary Selection is empty or a link instead of a node.");
            }
        }

        // this makes the heights and widths of all objects equal to the height and
        //width of the main selection.
        public virtual void MakeSizesSame()
        {
            GoObject obj = this.Selection.Primary;
            if (obj != null && !(obj is IGoLink))
            {
                StartTransaction();
                SizeF S = obj.SelectionObject.Size;
                foreach (GoObject temp in this.Selection)
                {
                    GoObject t = temp.SelectionObject;
                    if (!(t is IGoLink))
                        t.Size = S;
                }
                FinishTransaction("Same Sizes");
            }
            else
            {
                //MessageBox.Show("Sizing failure: Primary Selection is empty or a link instead of a node.");
            }
        }
        #endregion

        #region Zoom Control methods
        public virtual void ZoomIn()
        {
            myOriginalScale = true;
            float newscale = (float)(Math.Round(this.DocScale / 0.9f * 100) / 100);
            this.DocScale = newscale;
        }

        public virtual void ZoomOut()
        {
            myOriginalScale = true;
            float newscale = (float)(Math.Round(this.DocScale * 0.9f * 100) / 100);
            this.DocScale = newscale;
        }

        public virtual void ZoomNormal()
        {
            myOriginalScale = true;
            this.DocScale = 1;
        }

        public virtual void Zoom(float scale)
        {
            myOriginalScale = true;
            this.DocScale = scale;
        }

        public virtual void ZoomToFit()
        {
            if (myOriginalScale)
            {
                myOriginalDocPosition = this.DocPosition;
                myOriginalDocScale = this.DocScale;
                RescaleToFit();
            }
            else
            {
                this.DocPosition = myOriginalDocPosition;
                this.DocScale = myOriginalDocScale;
            }
            myOriginalScale = !myOriginalScale;
        }
        #endregion

        #region OnBackgroundSingleClicked....
        private Node doCreateStateVertex(GoInputEventArgs evt)
        {
            StateGraphDiagramDocument  doc = (StateGraphDiagramDocument)this.Document;

            int noVertice = 0;
            foreach (GoObject obj in this.Doc)
            {
                if (obj is GoBasicNode)
                //if (obj is GoTextNode)
                {
                    noVertice++;
                }
            }

            Node node = (Node)doc.InsertStateVertexNode(evt.DocPoint.X, evt.DocPoint.Y);
            if (noVertice == 0)
            {
                ((StateVertexNode)node).setInitial();
            }

            this.Update();
            this.UpdateView();

            return node;
        }

        private TextNode doCreateTextNode(GoInputEventArgs evt)
        {
            StateGraphDiagramDocument doc = (StateGraphDiagramDocument)this.Document;

            TextNode node = (TextNode)doc.InsertTextNode(evt.DocPoint.X, evt.DocPoint.Y);

            this.Update();
            this.UpdateView();

            return node;
        }

        private LabelNode doCreateLabelNode(GoInputEventArgs evt)
        {
            /*
            EventGraphDiagramDocument doc = (EventGraphDiagramDocument)this.Document;

            OOEGEventGraphModel model = MainForm.App.getCurrentEditor().BuildModel();

            LabelNodeDialog  dialog = new LabelNodeDialog(model);
            DialogResult rslt = dialog.ShowDialog();

            LabelNode node = null;
            if (rslt == DialogResult.OK)
            {
                OOEGEventObjectModel eoModel = model.FindEventObjectModel(dialog.EventObjectName);
                OOEGStateVariable sv = eoModel.GetStateVariable(dialog.StateVariableName);

                node = (LabelNode)doc.InsertLabelNode(
                    eoModel.ID, eoModel.Name, 
                    sv.Name, sv.InitialValue, 
                    evt.DocPoint.X, evt.DocPoint.Y);

                this.Update();
                this.UpdateView();
            }
            return node;
             */

            return null;
        }

        private ScheduleNode doCreateScheduleNode(GoInputEventArgs evt)
        {
            StateGraphDiagramDocument doc = (StateGraphDiagramDocument)this.Document;

            ScheduleNode node = (ScheduleNode)doc.InsertScheduleNode(evt.DocPoint.X, evt.DocPoint.Y);

            this.Update();
            this.UpdateView();

            return node;
        }

        private MessageNode doCreateMessageNode(GoInputEventArgs evt)
        {
            StateGraphDiagramDocument doc = (StateGraphDiagramDocument)this.Document;

            MessageNode node = (MessageNode)doc.InsertMessageNode(evt.DocPoint.X, evt.DocPoint.Y);

            this.Update();
            this.UpdateView();

            return node;
        }

        private ParameterNode doCreateParameterNode(GoInputEventArgs evt)
        {
            StateGraphDiagramDocument doc = (StateGraphDiagramDocument)this.Document;

            ParameterNode node = (ParameterNode)doc.InsertParameterNode(evt.DocPoint.X, evt.DocPoint.Y);

            this.Update();
            this.UpdateView();

            return node;
        }

        #endregion

        #region Selection Methods
        private bool _IsSelectionDeletion = false;
        protected override void OnSelectionDeleting(CancelEventArgs evt)
        {
            _IsSelectionDeletion = true;
            base.OnSelectionDeleting(evt);
        }

        protected override void OnSelectionDeleted(EventArgs evt)
        {
            base.OnSelectionDeleted(evt);

            _IsSelectionDeletion = false;

            //if (DiagramChanged != null && DiagramChanged.GetInvocationList().Length > 0)
            //    DiagramChanged();
        }

        protected override void OnObjectGotSelection(GoSelectionEventArgs evt)
        {
            base.OnObjectGotSelection(evt);

            //if (evt.GoObject is GoNode)
            //    _PrimaryNode = (GoNode)evt.GoObject;
        }
        protected override void OnObjectLostSelection(GoSelectionEventArgs evt)
        {
            base.OnObjectLostSelection(evt);

            //if (evt.GoObject is GoNode)
            //_PrimaryNode = null
        }
        #endregion

        #region OnBackground...
        protected override void OnBackgroundDoubleClicked(GoInputEventArgs evt)
        {
            base.OnBackgroundDoubleClicked(evt);
        }

        private GoNode _PrimaryNode = null;
        protected override void OnMouseDown(MouseEventArgs evt)
        {
            /*
            if (this.Selection.Primary != null && this.Selection.Primary is Node)
                _PrimaryNode = (Node)this.Selection.Primary;
            */

            base.OnMouseDown(evt);
        }

        protected override void OnDocumentChanged(object sender, GoChangedEventArgs e)
        {
            base.OnDocumentChanged(sender, e);

            if (e.Hint == 903 && e.GoObject is GoBasicNode)
            //if (e.Hint == 903 && e.GoObject is GoTextNode)
            {
                if (_PrimaryNode != null && e.GoObject == _PrimaryNode)
                {
                    _PrimaryNode = null;
                }
            }
        }

        protected override void OnBackgroundSingleClicked(GoInputEventArgs evt)
        {
            base.OnBackgroundSingleClicked(evt);

            Node newNode = null;
            switch (_CurrentMode)
            {
                case UI.InsertionMode.EventVertex:
                    {
                        newNode = doCreateStateVertex(evt);
                        break;
                    }
                case UI.InsertionMode.Text:
                    {
                        doCreateTextNode(evt); break;
                    }
                case UI.InsertionMode.Label:
                    {
                        doCreateLabelNode(evt); break;
                    }
                case UI.InsertionMode.Schedule:
                    {
                        doCreateScheduleNode(evt); break;
                    }
                case UI.InsertionMode.Message:
                    {
                        doCreateMessageNode(evt); break;
                    }
                case UI.InsertionMode.Parameter:
                    {
                        doCreateParameterNode(evt); break;
                    }

            }

            if (this.AutoConnect && newNode != null)
            {
                if (_PrimaryNode != null)
                //if (this.AutoConnect && _PrimaryNode != null && newNode != null)
                {
                    Node node = (Node)_PrimaryNode.UserObject;

                    Transition newLink = (Transition)
                        StateGraphDiagramView.MakeLink(UI.InsertionMode.TransitionEdge);

                    //find shortest-distance port 
                    IGoPort fromPort = node.FindShortestDistancePort(evt.ViewPoint.X, evt.ViewPoint.Y);
                    IGoPort toPort = newNode.FindShortestDistancePort(evt.ViewPoint.X, evt.ViewPoint.Y);
                    newLink.FromPort = fromPort;
                    newLink.ToPort = toPort;
                    //newLink.FromPort = node.Port;
                    //newLink.ToPort = newNode.Port;

                    //Link ID
                    StateGraphDiagramDocument doc = (StateGraphDiagramDocument)this.Document;
                    //while (doc.FindLink(StateGraphDiagramView.LastID) != null)
                    //{
                    //    StateGraphDiagramView.LastID++;
                    //}
                    //newLink.LinkID = StateGraphDiagramView.LinkCount;
                    //StateGraphDiagramView.LastID++;
                    //StateGraphDiagramView.LinkCount++;

                    newLink.FromLabel = CreateLabel("");
                    newLink.ToLabel = CreateLabel("");

                    this.Doc.LinksLayer.Add(newLink);

                    this.Selection.Clear();
                    this.Selection.Add(newNode.Presentation);
                    _PrimaryNode = newNode.Presentation;
                }
                else
                {
                    this.Selection.Add(newNode.Presentation);
                    _PrimaryNode = newNode.Presentation;
                }
            }
            else
            {
                this.Selection.Clear();
            }

        }
        #endregion

        #region Object Clicked ...
        protected override void OnObjectSingleClicked(GoObjectEventArgs evt)
        {
            base.OnObjectSingleClicked(evt);
        }

        protected override void OnObjectDoubleClicked(GoObjectEventArgs evt)
        {
            base.OnObjectDoubleClicked(evt);

            /*
            if (evt.GoObject.ParentNode is Node)
            {
                Node n = (Node)evt.GoObject.ParentNode;
                if (n.ShowDialog(false))
                {
                    base.OnObjectSingleClicked(evt);
                }
            }
            else if (evt.GoObject.ParentNode is Link)
            {
                Link l = (Link)evt.GoObject.ParentNode;
                if (l.ShowDialog(false))
                {
                    base.OnObjectSingleClicked(evt);
                }
            }
            else if (evt.GoObject.ParentNode is TextNode)
            {
                TextNode n = (TextNode)evt.GoObject.ParentNode;
                if (n.ShowDialog())
                {
                    base.OnObjectSingleClicked(evt);
                }
            }
            */
        }
        #endregion

        #region Context MenuItem Handlers
        protected override void OnObjectContextClicked(GoObjectEventArgs evt)
        {
            base.OnObjectContextClicked(evt);

            if (evt.MouseEventArgs.Button == MouseButtons.Right)
            {
                ContextMenuStrip m = new ContextMenuStrip();

                if (evt.GoObject is GoLink)
                {
                    ToolStripItem m1 = m.Items.Add("Straight Line");
                    m1.Click += new EventHandler(OnStraightLineMenuItemClicked);
                    m1.Tag = evt.GoObject.ParentNode;
                    ToolStripItem m2 = m.Items.Add("Broken Line");
                    m2.Click += new EventHandler(OnBrokenLineMenuItemClicked);
                    m2.Tag = evt.GoObject.ParentNode;
                    ToolStripItem m3 = m.Items.Add("Curved Line");
                    m3.Click += new EventHandler(OnCurvedLineMenuItemClicked);
                    m3.Tag = evt.GoObject.ParentNode;
                    ToolStripItem m4 = m.Items.Add("-");

                    ToolStripMenuItem ddEdgeType = new ToolStripMenuItem("Edge Type");
                    ToolStripMenuItem schedulingEdgeType = new ToolStripMenuItem("Scheduling Edge");
                    schedulingEdgeType.Click += new EventHandler(OnSchedulingEdgeMenuIetmClicked);
                    schedulingEdgeType.Tag = evt.GoObject.ParentNode;
                    ToolStripMenuItem cancelingEdgeType= new ToolStripMenuItem("Canceling Edge");
                    cancelingEdgeType.Click += new EventHandler(OnCancelingEdgeMenuIetmClicked);
                    cancelingEdgeType.Tag = evt.GoObject.ParentNode;

                    ddEdgeType.DropDownItems.Add(schedulingEdgeType);
                    ddEdgeType.DropDownItems.Add(cancelingEdgeType); 

                    m.Items.Add(ddEdgeType);
                }
                
                m.Tag = evt.GoObject.ParentNode;
                m.Show(this, evt.ViewPoint);
            }

            /*
            if (evt.MouseEventArgs.Button == MouseButtons.Right)
            {
                ContextMenu m = new ContextMenu();

                if (evt.GoObject is GoLink)
                {
                    //MenuItem m0 = m.MenuItems.Add("Edit Properties", new EventHandler(OnEditLinkPropertiesMenuItemClicked));
                    //m.MenuItems.Add("-");
                    MenuItem m1 = m.MenuItems.Add("Straight Line", new EventHandler(OnStraightLineMenuItemClicked));
                    MenuItem m2 = m.MenuItems.Add("Broken Line", new EventHandler(OnBrokenLineMenuItemClicked));
                    MenuItem m3 = m.MenuItems.Add("Curved Line", new EventHandler(OnCurvedLineMenuItemClicked));
                    MenuItem m4 = m.MenuItems.Add("-");

                    System.Windows.Forms.ToolStripComboBox tsc = new ToolStripComboBox();

                    MenuItem m5 = m.MenuItems.Add(tsc);

                    //m3.Checked = true;
                }else if (evt.GoObject is GoNode)
                {
                    EventObjectNode eoNode = (EventObjectNode)evt.GoObject.ParentNode;
                  
                    MenuItem m3 = m.MenuItems.Add("Add Label of");
                    OOEGEventObjectModel eoModel = eoNode.Model;
                    List<string> svNameList = new List<string>();
                    Dictionary<string, OOEGStateVariable> svlist = new Dictionary<string,OOEGStateVariable>();
                    foreach(OOEGStateVariable sv in eoModel.StateVariables)
                    {
                        svlist.Add(sv.Name, sv);
                        svNameList.Add(sv.Name);
                    }
                    svNameList.Sort();
                    foreach(string svName in svNameList)
                    {
                        OOEGStateVariable sv = svlist[svName];
                        MenuItem m5 = m3.MenuItems.Add(svName +": " + sv.ValueType, new EventHandler(OnAddLabelMenuItemClicked));
                        m5.Tag = sv;
                    }
                    m3.Tag = evt.GoObject.ParentNode;
                    m.MenuItems.Add("-");
                    //MenuItem m4 = m.MenuItems.Add("View Code", new EventHandler(OnViewCodeMenuItemClicked));
                }

                m.MenuItems.Add("-");
                MenuItem mCut = m.MenuItems.Add("Cu&t", new EventHandler(OnCutMenuItemClicked));
                MenuItem mCopy = m.MenuItems.Add("&Copy", new EventHandler(OnCopyMenuItemClicked));
                MenuItem mPaste = m.MenuItems.Add("&Paste", new EventHandler(OnPasteMenuItemClicked));
                MenuItem mDel = m.MenuItems.Add("&Delete", new EventHandler(OnDeleteMenuItemClicked));

                m.Tag = evt.GoObject.ParentNode;
                m.Show(this, evt.ViewPoint);
            }
            */
        }

        private void OnAddLabelMenuItemClicked(object obj, EventArgs args)
        {
            //TODO @ 2015.04.19
            //revise the following codes

            /*
            MenuItem item = (MenuItem)obj;
            OOEGStateVariable sv = (OOEGStateVariable)item.Tag;
            EventObjectNode node = (EventObjectNode)item.Parent.Tag;

            OOEGDiagramDocument doc = (OOEGDiagramDocument)this.Document;
            OOEGEventGraphModel model = MainForm.App.getCurrentEditor().BuildModel();
            OOEGEventObjectModel eoModel = node.Model;


            doc.InsertLabelNode(
                    eoModel.ID, eoModel.Name,
                    sv.Name, sv.InitialValue,
                    node.Position.X, node.Position.Y + 80);

                this.Update();
                this.UpdateView();
            */
        }

        /*
        private void OnRenameMenuItemClicked(object obj, EventArgs args)
        {
            MenuItem item = (MenuItem)obj;
            EventObjectNode node = (EventObjectNode)item.Parent.Tag;

            EventObjectNodeDialog dialog = new EventObjectNodeDialog(node.NodeName);
            DialogResult rslt = dialog.ShowDialog(this);
            if (rslt == DialogResult.OK)
            {
                node.NodeName = dialog.EventObjectName;
                node.Model.Name = dialog.EventObjectName;
            }
        }

        private void OnEditEventTransitionTableMenuItemClicked(object obj, EventArgs args)
        {
            MenuItem item = (MenuItem)obj;
            EventObjectNode node = (EventObjectNode)item.Parent.Tag;
            node.ShowDialog(false);
        }
        */

        /*
        private void OnViewCodeMenuItemClicked(object obj, EventArgs args)
        {
            MenuItem item = (MenuItem)obj;
            EventObjectNode node = (EventObjectNode)item.Parent.Tag;

            OOEGEventGraphModel model = new OOEGEventGraphModel();
            //model.EventObjectModels.Add(node.Model);

            foreach(GoObject goobj in this.Doc)
            {
                if (goobj  is EventObjectNode)
                {
                    EventObjectNode eoNode = (EventObjectNode)goobj;
                    model.EventObjectModels.Add(eoNode.Model);
                }
            }

            foreach (Link n in node.DestinationLinks)
            {
                Model.OOEGEventObjectSchedulingEdge link =
                    new OOEGEventObjectSchedulingEdge();

                if (n.LinkType == LinkType.SchedulingLink)
                {
                    ObjectSchedulingLink osl = (ObjectSchedulingLink)n;

                    link.ID = osl.LinkID;
                    link.MirrorEventObject = ((EventObjectNode)osl.FromNode).NodeID;
                    //link.MirrorEventObject = osl.FromEventObjectID;
                    link.MirrorEventName = osl.FromEventName;
                    link.BoundaryEventObject = ((EventObjectNode)osl.ToNode).NodeID;
                    //link.BoundaryEventObject = osl.ToEventObjectID;
                    link.BoundaryEventName = osl.ToEventName;
                }
                model.EventObjectSchedulingEdges.Add(link);
            }

            D_Code dialog = new D_Code(node.Model.Name, model);
            dialog.ShowDialog(this.Parent);
           
        }
         */

        /*
        private void OnEditLinkPropertiesMenuItemClicked(object obj, EventArgs args)
        {
            MenuItem item = (MenuItem)obj;
            ObjectSchedulingLink link = (ObjectSchedulingLink)item.Parent.Tag;

            link.ShowDialog(false);

        }
        */

        private void OnDeleteMenuItemClicked(object obj, EventArgs args)
        {
            MenuItem item = (MenuItem)obj;
            GoObject goobj = (GoObject)item.Parent.Tag;

            goobj.Remove();
        }

        private void OnCutMenuItemClicked(object obj, EventArgs args)
        {   
            //Node 만 복사 지원하고 복사된 노드 간의 연결관계는 유지한다
        }

        private void OnCopyMenuItemClicked(object obj, EventArgs args)
        {
        }

        private void OnPasteMenuItemClicked(object obj, EventArgs args)
        {

        }

        private void OnStraightLineMenuItemClicked(object obj, EventArgs args)
        {
            ToolStripMenuItem m = (ToolStripMenuItem)obj;

            if (m.Tag is GoLabeledLink)
            {
                GoLabeledLink link = (GoLabeledLink)m.Tag;
                link.Style = GoStrokeStyle.Line;
                link.Orthogonal = false;
                link.CalculateStroke();

            }
        }

        private void OnSchedulingEdgeMenuIetmClicked(object obj, EventArgs args)
        {
            ToolStripMenuItem m = (ToolStripMenuItem)obj;

            if (m.Tag is GoLabeledLink)
            {
                GoLabeledLink targetEdge = (GoLabeledLink)m.Tag;

                if (targetEdge.Pen.DashStyle == System.Drawing.Drawing2D.DashStyle.Dash)
                {
                    Pen schedulingPen = new Pen(Brushes.Black);
                    schedulingPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                    targetEdge.Pen = schedulingPen;
                }
            }
        }
 
        private void OnCancelingEdgeMenuIetmClicked(object obj, EventArgs args)
        {
            ToolStripMenuItem m = (ToolStripMenuItem)obj;

            if (m.Tag is GoLabeledLink)
            {
                GoLabeledLink targetEdge = (GoLabeledLink)m.Tag;

                if (targetEdge.Pen.DashStyle == System.Drawing.Drawing2D.DashStyle.Solid)
                {
                    Pen cancelingPen = new Pen(Brushes.Black);
                    cancelingPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                    targetEdge.Pen = cancelingPen;
                }
            }
        }

        protected override void OnPropertyChanged(PropertyChangedEventArgs evt)
        {
            base.OnPropertyChanged(evt);
            if (evt.PropertyName == "DocScale")
            {
                if (ScaleChanged != null && ScaleChanged.GetInvocationList().Length > 0)
                    ScaleChanged(this.DocScale);
            }
        }

        private void OnBrokenLineMenuItemClicked(object obj, EventArgs args)
        {
            ToolStripMenuItem m = (ToolStripMenuItem)obj;

            if (m.Tag is GoLabeledLink)
            {
                GoLabeledLink link = (GoLabeledLink)m.Tag;
                link.Style = GoStrokeStyle.RoundedLine;
                link.Orthogonal = true;
            }
        }

        private void OnCurvedLineMenuItemClicked(object obj, EventArgs args)
        {
            ToolStripMenuItem m = (ToolStripMenuItem)obj;

            if (m.Tag is GoLabeledLink)
            {
                GoLabeledLink link = (GoLabeledLink)m.Tag;
                link.Style = GoStrokeStyle.Bezier;
                link.Orthogonal = true;
                link.Curviness = 20 * this.Doc.NumLinksBetween(link.FromPort, link.ToPort);
                link.CalculateRoute();
            }
        }

        #endregion

        #region Object Visibility
        public void setGrid(GoViewGridStyle ggstyle)
        {
            this.GridStyle = ggstyle;
            this.Grid.LineColor = Color.DarkGray;
            this.GridCellSize = new SizeF((float)20, (float)20);
            //this.GridPenDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.Grid.LineWidth = (float).25;
            this.GridSnapDrag = GoViewSnapStyle.After;
        }

        #endregion

        #region Highliht Methods


        #endregion

        #region FindObject Methods
        public Node FindNode(int nodeID)
        {
            Node rslt = null;

            /*
            foreach (GoObject obj in this.Doc)
            {
                if (obj is Node)
                {
                    Node node = (Node)obj;
                    if (node.NodeID == nodeID)
                    {
                        rslt = node;
                        break;
                    }
                }
            }
            */
            return rslt;
        }

        public Node FindNode(string name)
        {
            Node rslt = null;
    
            foreach(GoObject obj in this.Doc)
            {
                if (obj is GoNode)
                {
                    GoBasicNode presentation = (GoBasicNode)obj;
                    //GoTextNode presentation = (GoTextNode)obj;
                    if (presentation.Text == name)
                    {
                        Node node = (Node)presentation.UserObject;
                        rslt = node;
                        break;
                    } 
                }
            }
            return rslt;
        }

        public ObjectSchedulingLink FindLink(int linkID)
        {
            ObjectSchedulingLink rslt = null;
            foreach (GoObject obj in this.Doc)
            {
                if (obj is ObjectSchedulingLink)
                {
                    ObjectSchedulingLink link = (ObjectSchedulingLink)obj;
                    if (link.LinkID == linkID)
                    {
                        rslt = link;
                        break;
                    }
                }
            }
            return rslt;
        }

        #endregion

        #region Key Methods
        private Keys _LastTimeDowned = Keys.None;
        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);

            if (e.KeyCode == Keys.OemMinus || e.KeyCode == Keys.Add)
            {
                if (_LastTimeDowned == Keys.ControlKey)
                {
                    ZoomIn();
                }
            }
            else if (e.KeyCode == Keys.Oemplus || e.KeyCode == Keys.Subtract)
            {
                if (_LastTimeDowned == Keys.ControlKey)
                {
                    ZoomOut();
                }
            }
            else
            {
                _LastTimeDowned = e.KeyCode;
            }
        }
        #endregion

        /*
        #region Copy and Paste
        private Keys _LastTimeDowned = Keys.None;
        private int _PasteTimes = 0;
        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Z && _LastTimeDowned == Keys.ControlKey)
                return;

            base.OnKeyDown(e);

            if (e.KeyCode == Keys.C)
            {
                if (_LastTimeDowned == Keys.ControlKey)
                {
                    CopySelection();

                    _LastTimeDowned = Keys.None;
                    _PasteTimes = 0;
                }
            }

            if (e.KeyCode == Keys.V)
            {
                if (_LastTimeDowned == Keys.ControlKey)
                {
                    PasteSelection();

                    _LastTimeDowned = Keys.None;
                    _PasteTimes++;
                }
            }
            _LastTimeDowned = e.KeyCode;
        }

        private GoObject[] _CopiedObjects;
        private void CopySelection()
        {
            _CopiedObjects = this.Selection.CopyArray();
        }

        protected override void OnSelectionCopied(EventArgs evt)
        {
            base.OnSelectionCopied(evt);
        }

        private void PasteSelection()
        {
            if (_CopiedObjects == null || _CopiedObjects.Length == 0)
                return;

            this.Selection.Clear();

            SortedList<int, GoNode> copiedNodes =
                new SortedList<int, GoNode>();

            //기존의 Link ID 를 신규 Link ID 로 mapping
            Dictionary<int, int> newLinkIDList =
                new Dictionary<int, int>();
            List<SplitNode> splitNodeList = new List<SplitNode>();
            List<MergeNode> mergeNodeList = new List<MergeNode>();

            foreach (GoObject obj in _CopiedObjects)
            {
                if (obj is Node)
                {
                    Node rawNode = (Node)obj;
                    string newNodeName = "Copy of " + rawNode.NodeName;
                    if (_PasteTimes > 0)
                        newNodeName += " #" + _PasteTimes;

                    int nodeCounter = _PasteTimes;
                    Node existingNode = null;
                    do
                    {
                        existingNode = this.Doc.FindNode(newNodeName);
                        if (existingNode != null)
                        {
                            nodeCounter++;
                            newNodeName = string.Format("Copy of {0} #{1}", rawNode.NodeName, nodeCounter);
                        }
                    } while (existingNode != null);

                    if (obj is SourceNode)
                    {
                        SourceNode node = (SourceNode)obj;
                        SourceNode newNode =
                            (SourceNode)this.Doc.InsertSourceNode(
                                node.Center.X + 15, node.Center.Y + 15);

                        newNode.NodeName = newNodeName;
                        newNode.InterArrivingTime = node.InterArrivingTime;

                        this.Selection.Add(newNode);
                        copiedNodes.Add(node.NodeID, newNode);
                    }
                    else if (obj is SinkNode)
                    {
                        SinkNode node = (SinkNode)obj;

                        SinkNode newNode =
                            (SinkNode)this.Doc.InsertSinkNode(
                                node.Center.X + 15, node.Center.Y + 15);

                        newNode.NodeName = newNodeName;
                        newNode.InterBlockingTime = node.InterBlockingTime;

                        this.Selection.Add(newNode);
                        copiedNodes.Add(node.NodeID, newNode);
                    }
                    else if (obj is GateNode)
                    {
                        GateNode node = (GateNode)obj;

                        GateNode newNode =
                            (GateNode)this.Doc.InsertGateNode(
                                node.Center.X + 15, node.Center.Y + 15);

                        newNode.NodeName = newNodeName;
                        newNode.InterReleasingTime = node.InterReleasingTime;
                        newNode.Probability = node.Probability;
                        newNode.SignalControlID = node.SignalControlID;

                        this.Selection.Add(newNode);
                        copiedNodes.Add(node.NodeID, newNode);
                    }
                    else if (obj is EndNode)
                    {
                        EndNode node = (EndNode)obj;

                        EndNode newNode =
                            (EndNode)this.Doc.InsertEndNode(
                                node.Center.X + 15, node.Center.Y + 15);

                        newNode.NodeName = newNodeName;
                        newNode.InterExitingTime = node.InterExitingTime;

                        this.Selection.Add(newNode);
                        copiedNodes.Add(node.NodeID, newNode);
                    }
                    else if (obj is BusGarageNode)
                    {
                        BusGarageNode node = (BusGarageNode)obj;

                        BusGarageNode newNode =
                            (BusGarageNode)this.Doc.InsertBusGarageNode(
                                node.Center.X + 15, node.Center.Y + 15);

                        newNode.NodeName = newNodeName;
                        newNode.NoBuses = node.NoBuses;

                        this.Selection.Add(newNode);
                        copiedNodes.Add(node.NodeID, newNode);
                    }
                    else if (obj is BusStationNode)
                    {
                        BusStationNode node = (BusStationNode)obj;

                        BusStationNode newNode =
                            (BusStationNode)this.Doc.InsertBusStationNode(
                                node.Center.X + 15, node.Center.Y + 15);

                        newNode.NodeName = newNodeName;
                        newNode.NoPassenger = node.NoPassenger;
                        newNode.BusStationType = node.BusStationType;

                        this.Selection.Add(newNode);
                        copiedNodes.Add(node.NodeID, newNode);
                    }
                    else if (obj is ConnectorNode)
                    {
                        ConnectorNode node = (ConnectorNode)obj;

                        ConnectorNode newNode =
                            (ConnectorNode)this.Doc.InsertConnectorNode(
                                node.Center.X + 15, node.Center.Y + 15);

                        newNode.NodeName = newNodeName;

                        this.Selection.Add(newNode);
                        copiedNodes.Add(node.NodeID, newNode);
                    }
                    else if (obj is SplitNode)
                    {
                        SplitNode node = (SplitNode)obj;

                        SplitNode newNode =
                            (SplitNode)this.Doc.InsertSplitNode(
                                node.Center.X + 15, node.Center.Y + 15);

                        newNode.NodeName = newNodeName;
                        newNode.InterReleasingTime = node.InterReleasingTime;
                        newNode.WaitingTime = node.WaitingTime;

                        foreach (int linkid in node.Percentages.Keys)
                        {
                            newNode.Percentages.Add(linkid, node.Percentages[linkid]);
                        }

                        this.Selection.Add(newNode);
                        splitNodeList.Add(newNode);
                        copiedNodes.Add(node.NodeID, newNode);
                    }
                    else if (obj is MergeNode)
                    {
                        MergeNode node = (MergeNode)obj;

                        MergeNode newNode =
                            (MergeNode)this.Doc.InsertMergeNode(
                                node.Center.X + 15, node.Center.Y + 15);

                        newNode.NodeName = newNodeName;
                        newNode.InterReleasingTime = node.InterReleasingTime;
                        newNode.HighPriorityLaneID = node.HighPriorityLaneID;
                        newNode.LowPriorityLaneID = node.LowPriorityLaneID;

                        this.Selection.Add(newNode);
                        mergeNodeList.Add(newNode);
                        copiedNodes.Add(node.NodeID, newNode);
                    }
                }
                else if (obj is TextNode)
                {
                    TextNode node = (TextNode)obj;
                    TextNode newNode = this.Doc.InsertTextNode(node.Center.X, node.Center.Y);
                    newNode.Text = node.Text;

                    FontStyle fs = new FontStyle();
                    if (node.Font.Bold)
                        fs = fs | FontStyle.Bold;
                    if (node.Font.Italic)
                        fs = fs | FontStyle.Italic;
                    if (node.Font.Underline)
                        fs = fs | FontStyle.Underline;
                    if (node.Font.Strikeout)
                        fs = fs | FontStyle.Strikeout;

                    newNode.Font = new Font(node.Font.Name, node.Font.Size, fs);
                    newNode.TextColor = node.TextColor;
                    newNode.BackgroundColor = node.BackgroundColor;
                    newNode.TransparentBackground = node.TransparentBackground;
                    newNode.Center = new PointF(node.Center.X + 15, node.Center.Y + 15);

                    this.Selection.Add(newNode);
                }
            }

            if (copiedNodes.Count == 0)
                return;

            foreach (GoObject obj in _CopiedObjects)
            {
                if (obj is LaneLink)
                {
                    LaneLink link = (LaneLink)obj;

                    Node fromNode = (Node)link.FromNode;
                    Node toNode = (Node)link.ToNode;

                    if (!copiedNodes.ContainsKey(fromNode.NodeID) ||
                        !copiedNodes.ContainsKey(toNode.NodeID))
                        continue;

                    Node newFromNode = (Node)copiedNodes[fromNode.NodeID];
                    Node newToNode = (Node)copiedNodes[toNode.NodeID];

                    LaneLink newLink = (LaneLink)LinkNodeDiagramView.MakeLink(UI.InsertionMode.LaneLink);
                    newLink.FromPort = newFromNode.Port;
                    newLink.ToPort = newToNode.Port;

                    //Link ID
                    while (this.Doc.FindLaneLink(LinkNodeDiagramView.LastID) != null)
                    {
                        LinkNodeDiagramView.LastID++;
                    }
                    newLink.LinkID = LinkNodeDiagramView.LinkCount;
                    LinkNodeDiagramView.LastID++;
                    LinkNodeDiagramView.LinkCount++;

                    //Link Name
                    string newLinkName = "Copy of " + link.LinkName;
                    if (_PasteTimes > 0)
                        newLinkName += " #" + _PasteTimes;

                    LaneLink existingLaneLink = null;
                    int linkCounter = _PasteTimes;
                    do
                    {
                        existingLaneLink = this.Doc.FindLaneLink(newLinkName);
                        if (existingLaneLink != null)
                        {
                            linkCounter++;
                            newLinkName = string.Format("Copy of {0} #{1}", link.LinkName, linkCounter);
                        }
                    } while (existingLaneLink != null);

                    newLink.LinkName = newLinkName;

                    //Lane Link Properties

                    newLink.LinkLength = link.LinkLength;
                    newLink.SpeedFactor = link.SpeedFactor;

                    GoText lengthText = new GoText();
                    lengthText.FontSize = 8;
                    lengthText.EditableWhenSelected = true;
                    lengthText.Editable = true;
                    newLink.MidLabel = lengthText;
                    lengthText.Text = link.LinkLength.ToString();

                    this.Doc.LinksLayer.Add(newLink);

                    this.Selection.Add(newLink);
                    newLinkIDList.Add(link.LinkID, newLink.LinkID);
                }
                else if (obj is IntersectionLink)
                {
                    IntersectionLink link = (IntersectionLink)obj;

                    Node fromNode = (Node)link.FromNode;
                    Node toNode = (Node)link.ToNode;

                    if (!copiedNodes.ContainsKey(fromNode.NodeID) ||
                        !copiedNodes.ContainsKey(toNode.NodeID))
                        continue;

                    Node newFromNode = (Node)copiedNodes[fromNode.NodeID];
                    Node newToNode = (Node)copiedNodes[toNode.NodeID];

                    IntersectionLink newLink = (IntersectionLink)LinkNodeDiagramView.MakeLink(UI.InsertionMode.IntersectionLink);
                    newLink.FromPort = newFromNode.Port;
                    newLink.ToPort = newToNode.Port;

                    //Link ID
                    while (this.Doc.FindIntersectionLink(LinkNodeDiagramView.LastIntersectionLinkID) != null)
                    {
                        LinkNodeDiagramView.LastIntersectionLinkID++;
                    }
                    newLink.LinkID = LinkNodeDiagramView.LinkCount;
                    LinkNodeDiagramView.LastIntersectionLinkID++;
                    LinkNodeDiagramView.LinkCount++;

                    //Link Name
                    string newLinkName = "Copy of " + link.LinkName;
                    if (_PasteTimes > 0)
                        newLinkName += " #" + _PasteTimes;

                    IntersectionLink existingLink = null;
                    int linkCounter = _PasteTimes;
                    do
                    {
                        existingLink = this.Doc.FindIntersectionLink(newLinkName);
                        if (existingLink != null)
                        {
                            linkCounter++;
                            newLinkName = string.Format("Copy of {0} #{1}", link.LinkName, linkCounter);
                        }
                    } while (existingLink != null);

                    newLink.LinkName = newLinkName;

                    //Lane Link Properties
                    newLink.LinkLength = link.LinkLength;
                    newLink.Speed = link.Speed;
                    newLink.Movement = link.Movement;

                    this.Doc.LinksLayer.Add(newLink);

                    this.Selection.Add(newLink);
                    newLinkIDList.Add(link.LinkID, newLink.LinkID);
                }
            }

            foreach (SplitNode node in splitNodeList)
            {
                Dictionary<int, float> newPercentages = new Dictionary<int, float>();
                foreach (int linkid in node.Percentages.Keys)
                {
                    if (newLinkIDList.ContainsKey(linkid))
                    {
                        newPercentages.Add(newLinkIDList[linkid], node.Percentages[linkid]);
                    }
                }
                node.Percentages = newPercentages;
            }

            foreach (MergeNode node in mergeNodeList)
            {
                if (newLinkIDList.ContainsKey(node.HighPriorityLaneID))
                    node.HighPriorityLaneID = newLinkIDList[node.HighPriorityLaneID];

                if (newLinkIDList.ContainsKey(node.LowPriorityLaneID))
                    node.LowPriorityLaneID = newLinkIDList[node.LowPriorityLaneID];
            }
        }
        
        #endregion
        */

    }
}
