﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using DHKANG.SEA.Model;
using System.Text.RegularExpressions;
using DHKANG.SEA.UI.Modeling;
using DHKANG.SEA.UI.Modeling.Properties;
using DHKANG.SEA.UI.OutputView;
using DHKANG.SEA.UI.ETTEditor;
using DHKANG.SEA.UI.STTEditor.Properties;

namespace DHKANG.SEA.UI.STTEditor
{
    public partial class STTPropertiesWindow : DockContent
    {
        #region Member Variables
        private StateObjectModelEditor _Parent;

        private ScheduleProperties _ScheduleProperties;
        private MessageProperties _MessageProperties;
        private ParameterProperties _ParameterProperties;
        private StateProperties _StateProperties;
        #endregion

        #region Properties
        #endregion

        #region Constructors
        public STTPropertiesWindow(StateObjectModelEditor parent)
        {
            InitializeComponent();

            _Parent = parent;

            _ScheduleProperties = new ScheduleProperties();
            _ScheduleProperties.Dock = DockStyle.Fill;
            _ScheduleProperties.Visible = false;
            this.Controls.Add(_ScheduleProperties);

            _StateProperties = new StateProperties(_Parent);
            _StateProperties.Dock = DockStyle.Fill;
            _StateProperties.Visible = false;
            this.Controls.Add(_StateProperties);

            _MessageProperties = new MessageProperties(_Parent);
            _MessageProperties.Dock = DockStyle.Fill;
            _MessageProperties.Visible = false;
            this.Controls.Add(_MessageProperties);

            _ParameterProperties = new ParameterProperties(_Parent);
            _ParameterProperties.Dock = DockStyle.Fill;
            _ParameterProperties.Visible = false;
            this.Controls.Add(_ParameterProperties);
        }
        #endregion

        #region Methods
        public void Update(OOMMModel model, Object target)
        {
            _ScheduleProperties.Visible = false;
            _StateProperties.Visible = false;
            _MessageProperties.Visible = false;
            _ParameterProperties.Visible = false;

            if (target == null)
            {
                return;
            }
            else if (target is ScheduleNode)
            {
                _ScheduleProperties.Visible = true;
                _ScheduleProperties.BringToFront();
                _ScheduleProperties.Update((ScheduleNode)target);
            }
            else if (target is StateVertexNode)
            {
                _StateProperties.Visible = true;
                _StateProperties.BringToFront();
                _StateProperties.Update((StateVertexNode)target);
            }
            else if (target is MessageNode)
            {
                _MessageProperties.Visible = true;
                _MessageProperties.BringToFront();
                _MessageProperties.Update((MessageNode)target);
            }
            else if (target is ParameterNode)
            {
                _ParameterProperties.Visible = true;
                _ParameterProperties.BringToFront();
                _ParameterProperties.Update((ParameterNode)target);
            }
        }
        #endregion
    }
}