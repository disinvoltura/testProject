﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model.Entities;
using System.Text.RegularExpressions;

namespace DHKANG.SEA.UI.STTEditor
{
    public partial class StateVariableWindow : DockContent
    {
        #region Member Variables
        private StateObjectModelEditor _AMControl;
        private StateVariableGridValueChangedEvent valueChangedController;
        #endregion

        #region Events
        public event ChangedEventHandler Changed;
        #endregion

        #region Properties
        public List<OOSGStateVariable> StateVariables
        {
            get
            {
                List<OOSGStateVariable> rslt = new List<OOSGStateVariable>();
                List<string> valueTypeList = OOSGStateVariableHelper.ValueType();
                if (grid.RowsCount > 1)
                {
                    for (int i = 1; i < grid.RowsCount; i++)
                    {
                        string svName = grid[i, 1].DisplayText;
                        string svType = grid[i, 2].DisplayText;
                        string svInitialValue = grid[i, 3].DisplayText;

                        OOSGStateVariable sv = null;
                        if (valueTypeList.Contains(svType))
                            sv = new OOSGStateVariable(svName, svType, svInitialValue);
                        else
                            sv = new OOSGStateVariable(svName, svType, true, svInitialValue);

                        rslt.Add(sv);
                    }
                }

                return rslt;
            }
        }
        #endregion

        public StateVariableWindow(StateObjectModelEditor parent)
        {
            _AMControl = parent;

            InitializeComponent();

            drawHeaders();

            valueChangedController = new StateVariableGridValueChangedEvent();
            valueChangedController.ValueChanged += new StateVariableGridValueChangedEventHandler(valueChangedController_ValueChanged);
            this.grid.MouseWheel += Grid_MouseWheel;
        }

        private void valueChangedController_ValueChanged(OOSGStateVariable oldStateVariable, OOSGStateVariable newStateVariable)
        {
            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            {
                Changed(ChangedTarget.StateVariable, ChangedType.Modified, oldStateVariable, newStateVariable);
            }
        }

        private void StateVariableWindow_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            base.OnFormClosing(e);
        }

        SourceGrid.Cells.Views.ColumnHeader titleModel;
        private void drawHeaders()
        {
            grid.Rows.Clear();

            grid.BorderStyle = BorderStyle.None;
            grid.Redim(1, 4);
            //grid.EnableSort = true;
            //grid.CustomSort = false;
            grid.FixedRows = 1;
            grid.FixedColumns = 1;

            titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
            titleModel.Font = new Font("Consolas", 9.0f, FontStyle.Bold);

            //grid.Font = new Font("Calibe", 9);
            grid.Font = new Font(
                ToolkitConfiguration.Table.Font.FontName,
                ToolkitConfiguration.Table.Font.Size);
            grid.AutoStretchColumnsToFitWidth = ToolkitConfiguration.Table.TableStretch;

            grid.Columns[0].AutoSizeMode = SourceGrid.AutoSizeMode.None;
            grid.Columns[0].Width = 25;
            SourceGrid.Cells.Header l_00Header = new SourceGrid.Cells.Header(null);
            grid[0, 0] = l_00Header;

            string[] columns = { "Name", "Type", "Initial Value" };
            for (int i = 0; i < columns.Length; i++)
            {
                SourceGrid.Cells.ColumnHeader header =
                    new SourceGrid.Cells.ColumnHeader(columns[i]);

                header.View = titleModel;
                grid[0, 1 + i] = header;
            }
        }

        public void Update(OOSGStateObjectModel am)//AMModel
        {
            //Sorting Order
            List<string> stateVariables = new List<string>();
            foreach (OOSGStateVariable sv in am.StateVariables)
            {
                stateVariables.Add(sv.Name);
            }
            stateVariables.Sort();

            foreach (string name in stateVariables)
            {
                InsertStateVariable(am.FindStateVariable(name));
            }

            grid.AutoStretchColumnsToFitWidth = false;
            grid.AutoStretchRowsToFitHeight = false;
            grid.AutoSizeCells();
        }

        public void InsertStateVariable(OOSGStateVariable sv)
        {
            int rowIndex = grid.RowsCount;
            grid.Rows.Insert(rowIndex);

            grid[rowIndex, 0] = new SourceGrid.Cells.RowHeader(null);

            SourceGrid.Cells.Views.Cell topView = new SourceGrid.Cells.Views.Cell();
            topView.TextAlignment = DevAge.Drawing.ContentAlignment.TopLeft;

            //Name
            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(sv.Name, typeof(string));
            nameCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 1] = nameCell;
            grid[rowIndex, 1].AddController(this.valueChangedController);

            //Type
            SourceGrid.Cells.Editors.ComboBox cbEditor = getAvailableTypes();
            //SourceGrid.Cells.Editors.ComboBox cbEditor =
            //    new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            //cbEditor.EditableMode = SourceGrid.EditableMode.Focus |
            //                        SourceGrid.EditableMode.SingleClick |
            //                        SourceGrid.EditableMode.AnyKey;
            //cbEditor.Control.DropDownStyle = ComboBoxStyle.DropDownList;
            //List<string> valueTypeList = OOSGStateVariableHelper.ValueType();
            //cbEditor.StandardValues = valueTypeList;

            SourceGrid.Cells.Cell typeCell = null;
            typeCell = new SourceGrid.Cells.Cell(sv.Type, cbEditor);

            typeCell.View = topView;
            grid[rowIndex, 2] = typeCell;
            grid[rowIndex, 2].AddController(this.valueChangedController);

            //Initial Value
            SourceGrid.Cells.Cell initialValueCell = new SourceGrid.Cells.Cell(sv.InitialValue, typeof(string));
            initialValueCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 3] = initialValueCell;
            grid[rowIndex, 3].AddController(this.valueChangedController);
        }

        private SourceGrid.Cells.Editors.ComboBox getAvailableTypes()
        {
            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));

            List<string> types = new List<string>();

            //Entities
            Guid projectID = MainUI.App.ModelExplorer.CurrentProject;
            List<OOMMEntity> entities = MainUI.App.ModelExplorer.GetEntities(projectID);
            foreach (OOMMEntity entity in entities)
                types.Add(entity.Name);
            types.Sort();

            List<string> valueTypeList = OOSGStateVariableHelper.ValueType();
            types.AddRange(valueTypeList);
            //types.AddRange(_BasicTypes);

            cbEditor.StandardValues = types.ToArray<string>();
            //cbEditor.StandardValues = new string[] { "int", "float", "double", "string", "RandomVariate" };
            //cbEditor.StandardValues = new string[] { "int", "float", "double", "string", "Queue<int>", "Queue<float>", "Queue<double>", "Queue<string>", "List<int>","List<float>", "List<double>", "List<string>" };
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;

            return cbEditor;
        }

        private string getNextVariableName()
        {
            string rslt = "Variable 1";

            string expr = @"Variable[\s]*([0-9\-]*)";

            int nextNumber = 0;
            foreach (OOSGStateVariable sv in this.StateVariables)
            {
                if (sv == null)
                    continue;
                int number = 0;
                if (Regex.IsMatch(sv.Name, expr))
                {
                    Match m = Regex.Match(sv.Name, @"\d+");
                    if (int.TryParse(m.Value, out number))
                    {
                        if (number > nextNumber)
                            nextNumber = number;
                    }
                }
            }

            nextNumber++;
            rslt = "Variable " + nextNumber;

            return rslt;
        }

        public void InsertEmptyStateVariable()
        {
            OOSGStateVariable newVariable = new OOSGStateVariable(
                                                    getNextVariableName(), "int", 0);
            InsertStateVariable(newVariable);

            /*
            int rowIndex = grid.RowsCount;
            grid.Rows.Insert(rowIndex);

            grid[rowIndex, 0] = new SourceGrid.Cells.RowHeader(null);

            SourceGrid.Cells.Views.Cell topView = new SourceGrid.Cells.Views.Cell();
            topView.TextAlignment = DevAge.Drawing.ContentAlignment.TopLeft;

            //Name
            string sName = "State Variable " + rowIndex;
            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(sName, typeof(string));
            nameCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 1] = nameCell;
            grid[rowIndex, 1].AddController(this.valueChangedController);

            //Type
            SourceGrid.Cells.Editors.ComboBox cbEditor = getAvailableTypes();
            //SourceGrid.Cells.Editors.ComboBox cbEditor =
            //    new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            //cbEditor.EditableMode = SourceGrid.EditableMode.Focus |
            //    SourceGrid.EditableMode.SingleClick |
            //    SourceGrid.EditableMode.AnyKey;
            //cbEditor.Control.DropDownStyle = ComboBoxStyle.DropDownList;
            //List<string> valueTypeList = OOSGStateVariableHelper.ValueType();
            //cbEditor.StandardValues = valueTypeList;

            SourceGrid.Cells.Cell typeCell = new SourceGrid.Cells.Cell(valueTypeList[0], cbEditor);
            typeCell.View = topView;
            //typeCell.View = SourceGrid.Cells.Views.ComboBox.Default;
            //typeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 2] = typeCell;
            grid[rowIndex, 2].AddController(this.valueChangedController);

            //Initial Value
            SourceGrid.Cells.Cell initialValueCell = new SourceGrid.Cells.Cell("0", typeof(string));
            initialValueCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 3] = initialValueCell;
            grid[rowIndex, 3].AddController(this.valueChangedController);


            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            {
                OOSGStateVariable sv =
                    new OOSGStateVariable(sName, OOSGStateVariableHelper.DefaultValueType(), "0");

                Changed(ChangedTarget.StateVariable, ChangedType.Added, null, sv);
            }

            if (grid.Rows.Count == 2)
                grid.AutoSizeCells();
            */
        }

        private void grid_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            SourceGrid.Position p = grid.PositionAtPoint(e.Location);
            if (p.IsEmpty())
            {
                InsertEmptyStateVariable();
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            InsertEmptyStateVariable();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            //Remove State Variable
            int sRow = grid.Selection.ActivePosition.Row;
            if (sRow < 0 || grid[sRow, 0] == null)
                return;


            string sName = grid[sRow, 1].DisplayText;
            string sValue = grid[sRow, 3].DisplayText;
            string strType = grid[sRow, 2].DisplayText;

            OOSGStateVariable sv = new OOSGStateVariable(sName, strType, sValue);

            grid.Rows.Remove(sRow);
            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            {
                Changed(ChangedTarget.StateVariable, ChangedType.Deleted, sv, null);
            }
        }

        private void zoomIn()
        {
            grid.Font = new Font(grid.Font.FontFamily, grid.Font.Size + 1);
            titleModel.Font = new Font(titleModel.Font.FontFamily, grid.Font.Size + 1, FontStyle.Bold);
            AutoSizeCells();
        }

        private void zoomOut()
        {
            grid.Font = new Font(grid.Font.FontFamily, grid.Font.Size - 1);
            titleModel.Font = new Font(titleModel.Font.FontFamily, grid.Font.Size - 1, FontStyle.Bold);
            AutoSizeCells();
        }

        private void AutoSizeCells()
        {
            grid.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            grid.AutoStretchColumnsToFitWidth = false;
            grid.AutoStretchRowsToFitHeight = false;
            grid.AutoSizeCells();
        }

        private void StateVariableWindow_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Add && e.Control)
            {
                zoomIn();
            }
            else if (e.KeyCode == Keys.Subtract && e.Control)
            {
                zoomOut();
            }
            else if (e.KeyCode == Keys.OemMinus && e.Control)
            {
                zoomOut();
            }
            else if (e.KeyCode == Keys.Oemplus && e.Control)
            {
                zoomIn();
            }
        }

        private void Grid_MouseWheel(object sender, MouseEventArgs e)
        {
            if (Form.ModifierKeys == Keys.Control)
            {
                if (e.Delta > 0)
                {
                    //zoom in
                    zoomIn();
                }
                else if (e.Delta < 0)
                {
                    //zoom out
                    zoomOut();
                }
            }
        }
    }

    public delegate void StateVariableGridValueChangedEventHandler(OOSGStateVariable oldStateVariable, OOSGStateVariable newStateVariable);

    public class StateVariableGridValueChangedEvent : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event StateVariableGridValueChangedEventHandler ValueChanged;

        public StateVariableGridValueChangedEvent()
        {
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

            OOSGStateVariable oldStateVariable = null;
            OOSGStateVariable newStateVariable = null;

            SourceGrid.Cells.Cell nameCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 1);
            SourceGrid.Cells.Cell typeCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 2);
            SourceGrid.Cells.Cell valueCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 3);

            if (sender.Position.Column == 1) //name
            {
                string initialValue = valueCell.DisplayText;
                string type = typeCell.DisplayText;
                try
                {
                    oldStateVariable = new OOSGStateVariable((string)e.OldValue, type, initialValue);
                    newStateVariable = new OOSGStateVariable((string)e.NewValue, type, initialValue);
                }
                catch (Exception ex)
                {
                    oldStateVariable = new OOSGStateVariable((string)e.OldValue, typeCell.DisplayText, initialValue);
                    newStateVariable = new OOSGStateVariable((string)e.NewValue, typeCell.DisplayText, initialValue);
                }
            }
            else if (sender.Position.Column == 2) //type
            {
                string name = nameCell.DisplayText;
                string initialValue = valueCell.DisplayText;

                string oldValueType = e.OldValue.ToString();
                oldStateVariable = new OOSGStateVariable(name, oldValueType, initialValue);

                string newValueType = e.NewValue.ToString();
                newStateVariable = new OOSGStateVariable(name, newValueType, initialValue);
            }
            else
            {
                string name = nameCell.DisplayText;
                string type = typeCell.DisplayText;
                oldStateVariable = new OOSGStateVariable(name, type, e.OldValue.ToString());
                newStateVariable = new OOSGStateVariable(name, type, e.NewValue.ToString());
            }

            if (ValueChanged != null && ValueChanged.GetInvocationList().Length > 0)
                ValueChanged(oldStateVariable, newStateVariable);
        }

    }
}
