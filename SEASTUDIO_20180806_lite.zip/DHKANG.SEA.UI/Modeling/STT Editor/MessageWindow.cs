﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.StateObjects;

namespace DHKANG.SEA.UI.STTEditor
{
    public enum ChangedType { Added, Deleted, Modified };
    public enum ChangedTarget { ScheduleNode, Transition, InputEvent, InputAction, TransitionCondition, TransitionAction, Message, StateVariable, Parameter, State, StateVertex, TransitionLink, Functions, Cell, NextState, InitiaState };

    public delegate void ChangedEventHandler (ChangedTarget targetType, 
                                              ChangedType changedType, 
                                              object before, object after);
    //public delegate void ChangedEventHandler(ChangedTarget targetType, object[] targets);

    public partial class MessageWindow : DockContent
    {
        #region Member Variables
        private StateObjectModelEditor _AMControl;
        private MessageGridValueChangedEvent  valueChangedController;

        #endregion

        #region Events
        public ChangedEventHandler Changed;
        #endregion

        #region Properties
        public List<OOSGMessage> Messages
        {
            get
            {
                List<OOSGMessage> rslt = new List<OOSGMessage>();
                if (grid.RowsCount > 1)
                {
                    for (int i = 1; i < grid.RowsCount ; i++)
                    {
                        string mName = grid[i, 1].DisplayText;
                        
                        MessageType mType = (MessageType)Enum.Parse(typeof(MessageType), grid[i,2].DisplayText);
                        OOSGMessage msg = new OOSGMessage(mName, mType);

                        //parameters
                        Dictionary<string, string> parameters = new Dictionary<string, string>();
                        if (grid[i, 1].Tag != null)
                            parameters = (Dictionary<string, string>)grid[i, 1].Tag;
                        foreach (string pName in parameters.Keys)
                        {
                            msg.AddParameter(pName, parameters[pName]);
                        }

                        rslt.Add(msg);
                    }
                }
                return rslt;
            }
        }
        #endregion

        #region Constructors
        public MessageWindow(StateObjectModelEditor parent)
        {
            _AMControl = parent;
            InitializeComponent();
            drawHeaders();

            valueChangedController = new MessageGridValueChangedEvent ();
            valueChangedController.ValueChanged += new MessageGridValueChangedEventHandler(valueChangedController_ValueChanged); 
        }

        private void valueChangedController_ValueChanged(OOSGMessage oldMsg, OOSGMessage newMsg)
        {
            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            {
                Changed(ChangedTarget.Message, ChangedType.Modified, oldMsg, newMsg);
            }
        }
        #endregion

        private void MessageWindow_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            base.OnFormClosing(e);
        }

        private void drawHeaders()
        {
            grid.Rows.Clear();

            grid.BorderStyle = BorderStyle.None;
            grid.Redim(1, 3);
            //grid.EnableSort = true;
            //grid.CustomSort = false;
            grid.FixedRows = 1;
            grid.FixedColumns = 1;

            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            //grid.Font = new Font("Calibe", 9);
            grid.Font = new Font(
                ToolkitConfiguration.Table.Font.FontName,
                ToolkitConfiguration.Table.Font.Size);
            grid.AutoStretchColumnsToFitWidth = ToolkitConfiguration.Table.TableStretch;

            grid.Columns[0].AutoSizeMode = SourceGrid.AutoSizeMode.None;
            grid.Columns[0].Width = 25;
            SourceGrid.Cells.RowHeader l_00Header = new SourceGrid.Cells.RowHeader(null);
            grid[0, 0] = l_00Header;

            string[] columns = { "Name", "Type"};
            for (int i = 0; i < columns.Length; i++)
            {
                SourceGrid.Cells.ColumnHeader header =
                    new SourceGrid.Cells.ColumnHeader(columns[i]);

                header.View = titleModel;
                grid[0, 1 + i] = header;
            }

            grid.SelectionMode = SourceGrid.GridSelectionMode.Row;
        }

        public void Update(OOSGStateObjectModel am)
        //public void Update(AtomicModel am)
        {
            //Sorting Order
            List<string> messages = (from m in am.Messages select m.MName).ToList<string>();
            messages.Sort();

            foreach (string name in messages)
            {
                InsertMessage(am.FindMessage(name));
            }

            grid.AutoStretchColumnsToFitWidth = false;
            grid.AutoStretchRowsToFitHeight = false;
            grid.AutoSizeCells();
        }

        public void InsertMessage(OOSGMessage msg)
        {
            int rowIndex = grid.RowsCount;
            grid.Rows.Insert(rowIndex);

            grid[rowIndex, 0] = new SourceGrid.Cells.RowHeader(null);

            //Name
            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(msg.MName, typeof(string));
            nameCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 1] = nameCell;
            grid[rowIndex, 1].AddController(this.valueChangedController);

            //Type
            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            string[] types = Enum.GetNames(typeof(MessageType));
            cbEditor.StandardValues = types;
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;
            cbEditor.Control.DropDownStyle = ComboBoxStyle.DropDownList;

            SourceGrid.Cells.Cell typeCell = new SourceGrid.Cells.Cell(msg.Type.ToString(), cbEditor);
            typeCell.View = SourceGrid.Cells.Views.ComboBox.Default;
            typeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 2] = typeCell;
            grid[rowIndex, 2].AddController(this.valueChangedController);

            //parameters
            Dictionary<string, string> newParameters = new Dictionary<string, string>();
            foreach (OOSGMessageParameter p in msg.Parameters)
            {
                newParameters.Add(p.Name, p.Value);
            }

            grid[rowIndex, 1].Tag = newParameters;
        }

        public void InsertEmptyMessage()
        {
            int rowIndex = grid.RowsCount;
            grid.Rows.Insert(rowIndex);

            grid[rowIndex, 0] = new SourceGrid.Cells.RowHeader(null);

            //Name
            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell("Message " + rowIndex, typeof(string));
            nameCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 1] = nameCell;
            grid[rowIndex, 1].AddController(this.valueChangedController);

            //Type
            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            string[] types = Enum.GetNames(typeof(MessageType));
            cbEditor.StandardValues = types;
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;
            cbEditor.Control.DropDownStyle = ComboBoxStyle.DropDownList;

            SourceGrid.Cells.Cell typeCell = new SourceGrid.Cells.Cell(MessageType.Input.ToString(), cbEditor);
            typeCell.View = SourceGrid.Cells.Views.ComboBox.Default;
            typeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 2] = typeCell;
            grid[rowIndex, 2].AddController(this.valueChangedController);

            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            {
                OOSGMessage msg =
                    new OOSGMessage(
                        grid[rowIndex, 1].DisplayText, 
                        MessageType.Input);

                Changed(ChangedTarget.Message, ChangedType.Added, null, msg);
            }

            if (grid.Rows.Count == 2)
                grid.AutoSizeCells();
        }

        private void grid_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            SourceGrid.Position p = grid.PositionAtPoint(e.Location);
            if (p.IsEmpty())
            {
                InsertEmptyMessage();
            }
        }

        private void tsbInsert_Click(object sender, EventArgs e)
        {
            InsertEmptyMessage();
        }

        private void tsbDelete_Click(object sender, EventArgs e)
        {
            //Remove Activity Transition
            int sRow = grid.Selection.ActivePosition.Row;
            if (sRow < 0 || grid[sRow, 0] == null)
                return;

            string mName = grid[sRow, 1].DisplayText;
            MessageType mType = (MessageType)Enum.Parse(typeof(MessageType), grid[sRow, 2].DisplayText);
            
            grid.Rows.Remove(sRow);

            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            {
                OOSGMessage msg =
                    new OOSGMessage(
                        mName,mType);

                Changed(ChangedTarget.Message, ChangedType.Deleted, msg, null);
            }

            //grid.AutoSizeCells();
        }

        private void tsbMsgParams_Click(object sender, EventArgs e)
        {
            //Is there any message selected?
            int sRow = grid.Selection.ActivePosition.Row;
            if (sRow < 0 || grid[sRow, 0] == null)
                return;

            //Selected Message
            string mName = grid[sRow, 1].DisplayText;
            MessageType mType = (MessageType)Enum.Parse(typeof(MessageType), grid[sRow, 2].DisplayText);

            OOSGMessage msg =
                new OOSGMessage(mName, mType);

            //parameter pair of name and value
            Dictionary<string, string> parameters = new Dictionary<string, string>();
            if (grid[sRow, 1].Tag != null)
                parameters = (Dictionary<string, string>)grid[sRow, 1].Tag;
            foreach (string pName in parameters.Keys)
            {
                msg.AddParameter(pName, parameters[pName]);
            }

            D_Message dialog = new D_Message(msg, _AMControl.StateObjectModel);
            DialogResult rslt = dialog.ShowDialog(this);
            if (rslt == System.Windows.Forms.DialogResult.OK)
            {
                //parameters into grid tag
                Dictionary<string, string> newParameters = new Dictionary<string, string>();
                foreach (OOSGMessageParameter p in dialog.Message.Parameters)
                {
                    newParameters.Add(p.Name, p.Value);
                }

                grid[sRow, 1].Tag = newParameters;
            }
        }
    }

    public class ChangedEvent
    {
        public ChangedTarget Type;
        public object[] Targets;
    }

    public delegate void MessageGridValueChangedEventHandler(OOSGMessage prevMsg, OOSGMessage newMsg);

    public class MessageGridValueChangedEvent : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event MessageGridValueChangedEventHandler ValueChanged;

        public MessageGridValueChangedEvent()
        {
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

            OOSGMessage oldMsg = null;
            OOSGMessage newMsg = null;

            SourceGrid.Cells.Cell nameCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 1);
            SourceGrid.Cells.Cell typeCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 2);

            if (sender.Position.Column == 1) //name
            {
                MessageType mType = (MessageType)Enum.Parse(
                    typeof(MessageType),
                    typeCell.DisplayText);
                oldMsg = new OOSGMessage((string)e.OldValue, mType);
                newMsg = new OOSGMessage((string)e.NewValue, mType);
            }
            else
            {
                MessageType oType = (MessageType)Enum.Parse(
                    typeof(MessageType), e.OldValue.ToString());
                MessageType nType = (MessageType)Enum.Parse(
                    typeof(MessageType), e.NewValue.ToString());

                string mName = nameCell.DisplayText;
                oldMsg = new OOSGMessage(mName, oType);
                newMsg = new OOSGMessage(mName, nType);
            }

            if (ValueChanged != null && ValueChanged.GetInvocationList().Length > 0)
                ValueChanged(oldMsg, newMsg);
        }
    }
}
