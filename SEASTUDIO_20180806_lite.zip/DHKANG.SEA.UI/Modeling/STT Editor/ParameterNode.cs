﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Northwoods.Go;
using System.Windows.Forms;
using DHKANG.SEA.UI.OutputView;
using DHKANG.Foundation.DataCollection;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI.STTEditor
{
    public class ParameterNode : GoSimpleNode
    {
        #region Member Variables
        //private Guid _NodeID;
        private OOSGParameter _Parameter;
        #endregion

        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Properties
        public OOSGParameter Parameter 
        {
            get { return _Parameter; }
            set {
                OOSGParameter oldValue = null;
                if (this.Parameter != null)
                    oldValue = this.Parameter.Clone();
                _Parameter = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Message", oldValue, value);
            }
        }

        public string ParameterName 
        {
            get { return _Parameter.Name; }
            set
            {
                OOSGParameter oldValue = this.Parameter.Clone();
                string oldPropertyValue = _Parameter.Name;
                _Parameter.Name = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Name", oldValue, this.Parameter);
            }
        }

        public string InitialValue
        {
            get { return _Parameter.InitialValue; }
            set
            {
                OOSGParameter oldValue = this.Parameter.Clone();
                string oldPropertyValue = _Parameter.InitialValue;
                _Parameter.InitialValue = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "InitialValue", oldValue, this.Parameter);
            }
        }

        public string ParameterType 
        {
            get { return _Parameter.Type; }
            set
            {
                OOSGParameter oldValue = this.Parameter.Clone();
                string oldPropertyValue = _Parameter.Type;
                _Parameter.Type = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Type", oldValue, this.Parameter);
            }
        }
        #endregion

        #region Constructors
        public ParameterNode(string name, float x, float y)
        {
            //_NodeID = Guid.NewGuid();
            _Parameter = new OOSGParameter(name, OOSGStateVariableHelper.DefaultValueType(), "0");
            _Parameter.X = x;
            _Parameter.Y = y;
            initialize(x, y);
        }

        public ParameterNode(OOSGParameter parameter)
        {
            _Parameter = parameter;

            initialize(_Parameter.X, _Parameter.Y);
        }

        private void initialize(float x, float y)
        {
            this.Initialize(null, null, _Parameter.Name);
            this.Figure = GoFigure.Triangle;
            //this.Image.Name = “special.gif”
            this.Icon.Size = new SizeF(15, 15);
            this.Icon.Resizable = false;
            this.Shape.FillShapeGradient(Color.Orange);
            this.Orientation = Orientation.Vertical;
            this.InPort.Visible = false;
            this.OutPort.Visible = false;
            this.Editable = false;
            this.Left = x;
            this.Top = y;

            this.UpdateText();
        }
        #endregion

        #region Methods
        public void UpdateText()
        {
            this.Text = _Parameter.Name;
        }

        public void Reset()
        {
        }

        public override string GetToolTip(GoView view)
        {
            string tooltip = string.Empty;
            if (_Parameter != null)
            {
                if (string.IsNullOrEmpty(_Parameter.Type))
                    tooltip = _Parameter.Name;
                else
                    tooltip = _Parameter.Name + ": " + _Parameter.Type.ToString();
            }
            return tooltip;
        }
        #endregion
    }
}
