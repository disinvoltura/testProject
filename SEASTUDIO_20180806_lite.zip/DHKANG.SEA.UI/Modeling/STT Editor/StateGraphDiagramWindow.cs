﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using Northwoods.Go;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;
using Microsoft.Msagl;
using Microsoft.Msagl.Core.Geometry;
using Microsoft.Msagl.Core.Geometry.Curves;
using Microsoft.Msagl.Core.DataStructures;
using Microsoft.Msagl.Core.Layout;
using Microsoft.Msagl.Miscellaneous;
using DHKANG.SEA.Model.OID;
using DHKANG.SEA.UI.ETTEditor;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.UI.STTEditor;

namespace DHKANG.SEA.UI.STTEditor
{
    public delegate void StateGraphDiagramChangedEvent
                            (ChangedTarget target, ChangedType action, object before, object after);
    public partial class StateGraphDiagramWindow : DockContent
    {
        #region Member Variables
        private StateObjectModelEditor _Parent;
        #endregion

        #region Properties
        public float ViewScale { get { return _View.DocScale; } }

        public NodeFactory NodeFactory
        {
            get { return _View.Doc.NodeFactory; }
            set { _View.Doc.NodeFactory = value; }
        }

        public List<StateVertexNode> StateVertices { get { return _View.StateVertices; } }

        public List<OOSGState> States
        {
            get
            {
                List<OOSGState> rslt = new List<OOSGState>();
                _View.StateVertices.ForEach(node => rslt.Add(node.State));
                return rslt;
            }
        }
        public List<OOMMSchedule> Schedules
        {
            get
            {
                List<OOMMSchedule> rslt = new List<OOMMSchedule>();
                foreach (ScheduleNode node in _View.Schedules)
                {
                    OOMMSchedule s = new OOMMSchedule(node.NodeID, node.ScheduleName, node.Type, node.TimeUnit, node.Description, node.Left, node.Top);
                    s.Values = node.Values;
                    rslt.Add(s);
                }
                return rslt;
            }
        }

        public List<OOSGMessage> Messages
        {
            get
            {
                List<OOSGMessage> rslt = new List<OOSGMessage>();
                foreach (MessageNode node in _View.Messages)
                {
                    node.Message.X = node.Left;
                    node.Message.Y = node.Top;
                    rslt.Add(node.Message);
                }
                return rslt;
            }
        }

        public List<OOSGParameter> Parameters
        {
            get
            {
                List<OOSGParameter> rslt = new List<OOSGParameter>();
                foreach (ParameterNode node in _View.Parameters)
                {
                    node.Parameter.X = node.Left;
                    node.Parameter.Y = node.Top;
                    rslt.Add(node.Parameter);
                }
                return rslt;
            }
        }

        public OOSGState InitialState
        {
            get
            {
                OOSGState rslt = null;

                List<OOSGState> states = this.States;
                foreach (OOSGState state in states)
                {
                    if (state.Type == StateType.Initial)
                    {
                        rslt = state; break;
                    }
                }

                return rslt;
            }
        }


        public StateGraphDiagramView View { get { return _View; } }

        #endregion

        #region Events
        public event StateGraphDiagramChangedEvent Changed;//position changes are included
        public event DiagramSelectionChangedEventHandler SelectionChanged;
        public event DiagramObjectSelectedEventHandler ObjectSelected;

        #endregion

        #region Constructors
        public StateGraphDiagramWindow(StateObjectModelEditor parent)
        {
            _Parent = parent;

            InitializeComponent();

            _View = new StateGraphDiagramView();
            toolStripContainer1.ContentPanel.Controls.Clear();
            toolStripContainer1.ContentPanel.Controls.Add(_View);
            _View.Dock = DockStyle.Fill;

            _View.ObjectSingleClicked += new GoObjectEventHandler(OnViewObjectSingleClicked);
            _View.ObjectLostSelection += new GoSelectionEventHandler(OnViewObjectLostClicked);
            _View.LinkCreated += new GoSelectionEventHandler(OnViewLinkCreated);
            _View.DocumentChanged += new GoChangedEventHandler(OnViewDocumentChanged);
            _View.ScaleChanged += new DocumentScaleChangedEventHandler(OnViewScaleChanged);
            _View.SelectionFinished += new EventHandler(OnViewSelection);

            _View.InsertionMode = InsertionMode.None;
            _View.AutoConnect = true;
            _View.NewLinkClass = typeof(Transition);
        }
        #endregion

        #region GoView Event Handlers
        private void OnViewObjectSingleClicked(object sender, GoObjectEventArgs e)
        {
            if (e.GoObject.ParentNode != null)
            {

                if (e.GoObject.ParentNode is ScheduleNode ||
                    e.GoObject.ParentNode is MessageNode ||
                    e.GoObject.ParentNode is ParameterNode)
                {
                    if (this.ObjectSelected != null && this.ObjectSelected.GetInvocationList().Length > 0)
                        this.ObjectSelected(null, e.GoObject.ParentNode);
                }
                else if (e.GoObject.ParentNode is GoBasicNode)
                {
                    GoBasicNode node = (GoBasicNode)e.GoObject.ParentNode;
                    if (node.UserObject != null && node.UserObject is StateVertexNode)
                        if (this.ObjectSelected != null && this.ObjectSelected.GetInvocationList().Length > 0)
                            this.ObjectSelected(null, node.UserObject);
                }
            }
        }

        private void OnViewObjectLostClicked(object sender, GoSelectionEventArgs e)
        {
            if (this.ObjectSelected != null &&
                       this.ObjectSelected.GetInvocationList().Length > 0)
                this.ObjectSelected(null, null);
        }

        private void OnViewLinkCreated(object sender, GoSelectionEventArgs e)
        {
            if (e.GoObject is Link)
            {
                Link l = (Link)e.GoObject;

                if (l.LinkType == LinkType.SchedulingLink)
                {
                    while (_View.Doc.FindLink(EventGraphDiagramView.LastID) != null)
                    //while (_View.Doc.FindLink(EventGraphDiagramView.LastID) != null)
                    {
                        EventGraphDiagramView.LastID++;
                    }
                    l.LinkID = EventGraphDiagramView.LinkCount;
                    EventGraphDiagramView.LastID++;
                    EventGraphDiagramView.LinkCount++;
                }
            }
            else
            {

            }
        }

        private void OnViewDocumentChanged(object sender, GoChangedEventArgs e)
        {
            if (e.Hint == GoLayer.InsertedObject)
            {
                if (e.GoObject is ScheduleNode)
                {
                    if (isChangeable)
                    {
                        ScheduleNode node = (ScheduleNode)e.GoObject;
                        Changed(ChangedTarget.ScheduleNode, ChangedType.Added, "", node.ScheduleName);
                    }
                }
                else if (e.GoObject is MessageNode)
                {
                    if (isChangeable)
                    {
                        MessageNode node = (MessageNode)e.GoObject;
                        node.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
                        Changed(ChangedTarget.Message, ChangedType.Added, "", node.Message);
                    }
                }
                else if (e.GoObject is ParameterNode)
                {
                    if (isChangeable)
                    {
                        ParameterNode node = (ParameterNode)e.GoObject;
                        node.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
                        Changed(ChangedTarget.Parameter, ChangedType.Added, "", node.Parameter);
                    }
                }
                else if (e.GoObject is GoNode)
                {
                    if (isChangeable)
                    {
                        GoBasicNode node = (GoBasicNode)e.GoObject;
                        if (node.UserObject is StateVertexNode)
                        {
                            StateVertexNode stateNode = (StateVertexNode)node.UserObject;
                            stateNode.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
                            Changed(ChangedTarget.State, ChangedType.Added, "", stateNode.State);
                        }
                    }
                }
                else if (e.GoObject is GoLabeledLink)
                {
                    if (isChangeable)
                    {
                        GoLabeledLink link = (GoLabeledLink)e.GoObject;
                        GoBasicNode fromNode = (GoBasicNode)link.FromNode;
                        GoBasicNode toNode = (GoBasicNode)link.ToNode;

                        Changed(ChangedTarget.TransitionLink, ChangedType.Added, "", fromNode.Text + "->" + toNode.Text);
                    }
                }
                UpdateHighlighting();
            }
            else if (e.Hint == GoLayer.RemovedObject)
            {
                if (e.GoObject is ScheduleNode)
                {
                    if (isChangeable)
                    {
                        ScheduleNode node = (ScheduleNode)e.GoObject;
                        Changed(ChangedTarget.ScheduleNode, ChangedType.Deleted, node.ScheduleName, "");
                    }
                }
                else if (e.GoObject is MessageNode)
                {
                    if (isChangeable)
                    {
                        MessageNode node = (MessageNode)e.GoObject;
                        Changed(ChangedTarget.Message, ChangedType.Deleted, node.Message, "");
                    }
                }
                else if (e.GoObject is ParameterNode)
                {
                    if (isChangeable)
                    {
                        ParameterNode node = (ParameterNode)e.GoObject;
                        Changed(ChangedTarget.Parameter, ChangedType.Deleted, node.Parameter, "");
                    }
                }
                else if (e.GoObject is GoNode)
                {
                    if (isChangeable)
                    {
                        GoBasicNode node = (GoBasicNode)e.GoObject;
                        if (node.UserObject is StateVertexNode)
                            Changed(ChangedTarget.State, ChangedType.Deleted, ((StateVertexNode)node.UserObject).State, "");
                    }
                }
                else if (e.GoObject is GoLabeledLink)
                {
                    if (isChangeable)
                    {
                        GoLabeledLink link = (GoLabeledLink)e.GoObject;
                        GoBasicNode fromNode = (GoBasicNode)link.FromNode;
                        GoBasicNode toNode = (GoBasicNode)link.ToNode;

                        Changed(ChangedTarget.TransitionLink, ChangedType.Deleted, fromNode.Text + "->" + toNode.Text, "");
                    }
                }

            }
            else if (e.Hint == GoLayer.ChangedObject)
            {
                if (e.GoObject is ScheduleNode)
                {
                    if (isChangeable)
                    {
                        if (e.SubHint == 1501 || (e.OldValue != null && e.NewValue != null))
                            Changed(ChangedTarget.ScheduleNode, ChangedType.Modified, e.OldValue.ToString(), e.NewValue.ToString());
                    }
                }
                else if (e.GoObject is MessageNode)
                {
                    if (isChangeable)
                    {
                        //if (e.SubHint == 1501 || (e.OldValue != null && e.NewValue != null))
                        //    Changed(ChangedTarget.Message, ChangedType.Modified, e.OldValue.ToString(), e.NewValue.ToString());
                    }
                }
                else if (e.GoObject is ParameterNode)
                {
                    if (isChangeable)
                    {
                        //if (e.SubHint == 1501 || (e.OldValue != null && e.NewValue != null))
                        //    Changed(ChangedTarget.Parameter, ChangedType.Modified, e.OldValue.ToString(), e.NewValue.ToString());
                    }
                }
                else if (e.GoObject is GoText)
                {
                    if (e.GoObject.ParentNode != null)
                    {
                        if (e.GoObject.ParentNode is GoBasicNode)
                        {
                            if (isChangeable)
                            {
                                if (e.SubHint == 1501 || (e.OldValue != null && e.NewValue != null))
                                {
                                    if (!(e.NewValue is bool))
                                    {
                                        GoBasicNode parentNode = (GoBasicNode)e.GoObject.ParentNode;
                                        StateVertexNode stateNode = (StateVertexNode)parentNode.UserObject;
                                        OOSGState ovState = stateNode.State.Clone();
                                        stateNode.StateName = e.NewValue.ToString();
                                        OOSGState nvState = stateNode.State.Clone();
                                        //Changed(ChangedTarget.State, ChangedType.Modified, e.OldValue.ToString(), e.NewValue.ToString());
                                        Changed(ChangedTarget.State, ChangedType.Modified, ovState, nvState);
                                    }
                                }
                            }
                        }
                        /*
                        else if (e.GoObject.ParentNode is MessageNode)
                        {
                            MessageNode parentNode = (MessageNode)e.GoObject.ParentNode;
                            OOSGMessage ovMessage = parentNode.Message.Clone();
                            parentNode.MessageName = e.NewValue.ToString();
                            OOSGMessage nvMessage = parentNode.Message.Clone();
                            Changed(ChangedTarget.Message, ChangedType.Modified, ovMessage, nvMessage);
                        }
                        else if (e.GoObject.ParentNode is ParameterNode)
                        {
                            ParameterNode parentNode = (ParameterNode)e.GoObject.ParentNode;
                            OOSGParameter ovParam = parentNode.Parameter.Clone();
                            parentNode.ParameterName = e.NewValue.ToString();
                            OOSGParameter nvParam = parentNode.Parameter.Clone();
                            Changed(ChangedTarget.Parameter, ChangedType.Modified, ovParam, nvParam);
                        }
                        */
                    }
                }
                else if (e.GoObject is GoBasicNode)
                {
                    if (isChangeable)
                    {
                        if (e.SubHint == 1501 || (e.OldValue != null && e.NewValue != null))
                            Changed(ChangedTarget.State, ChangedType.Modified, e.OldValue.ToString(), e.NewValue.ToString());
                    }
                }
                else if (e.GoObject is GoLink)
                {
                    /*
                    if (e.SubHint == 1101)
                    {
                        Transition changedEdge = (Transition)e.GoObject.Parent;

                        string fromEventVertex = string.Empty;
                        string toEventVertex = string.Empty;

                        GoBasicNode fromNode = (GoBasicNode)changedEdge.FromNode;
                        GoBasicNode toNode = (GoBasicNode)changedEdge.ToNode;
                        fromEventVertex = fromNode.Text;
                        toEventVertex = toNode.Text;
                        if (isChangeable)
                        {
                            if (changedEdge.Pen.DashStyle == System.Drawing.Drawing2D.DashStyle.Solid)
                                Changed("edgetype", "scheduling", fromEventVertex, toEventVertex);
                            else
                                Changed("edgetype", "canceling", fromEventVertex, toEventVertex);
                        }
                    }
                    */
                }
            }

        }

        private bool isChangeable
        {
            get { return !isLoading && (Changed != null && Changed.GetInvocationList().Length > 0); }
        }

        private void OnViewScaleChanged(double scale)
        {
            tscbZoom.Text = Math.Round(scale * 100, 0).ToString() + "%";
        }

        private void OnViewSelection(object sender, EventArgs e)
        {
            GoView view = (GoView)sender;
            if (myPrimary != view.Selection.Primary)
            {
                UpdateHighlighting();
            }
        }
        #endregion

        #region Event Handlers for Toolbars - Drawing Components
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            tsbEventObjectNode.Checked = !tsbEventObjectNode.Checked;

            if (tsbEventObjectNode.Checked)
            {
                _View.InsertionMode = InsertionMode.EventVertex;
                _View.AllowLink = false;

                //tsbAddLabel.Checked = false;
                //tsbAddText.Checked = false;
                tsbSchedulingLink.Checked = false;
                tsbSchedule.Checked = false;
            }
            else
                _View.InsertionMode = InsertionMode.None;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            tsbSchedulingLink.Checked = !tsbSchedulingLink.Checked;

            if (tsbSchedulingLink.Checked)
            {
                _View.InsertionMode = InsertionMode.SchedulingEdge;
                _View.AllowLink = true;

                tsbEventObjectNode.Checked = false;
                tsbSchedule.Checked = false;
            }
            else
            {
                _View.InsertionMode = InsertionMode.None;
                _View.AllowLink = false;
            }
        }

        private void tsbSchedule_Click(object sender, EventArgs e)
        {
            tsbSchedule.Checked = !tsbSchedule.Checked;

            if (tsbSchedule.Checked)
            {
                _View.InsertionMode = InsertionMode.Schedule;
                _View.AllowLink = false;

                //tsbAddLabel.Checked = false;
                //tsbAddText.Checked = false;
                tsbSchedulingLink.Checked = false;
                tsbEventObjectNode.Checked = false;
            }
            else
                _View.InsertionMode = InsertionMode.None;
        }

        private void tsbMessage_Click(object sender, EventArgs e)
        {
            tsbMessage.Checked = !tsbMessage.Checked;

            if (tsbMessage.Checked)
            {
                _View.InsertionMode = InsertionMode.Message;
                _View.AllowLink = false;

                tsbSchedulingLink.Checked = false;
                tsbEventObjectNode.Checked = false;
                tsbSchedule.Checked = false;
                tsbParameter.Checked = false;
            }
            else
                _View.InsertionMode = InsertionMode.None;
        }

        private void tsbParameter_Click(object sender, EventArgs e)
        {
            tsbParameter.Checked = !tsbParameter.Checked;

            if (tsbParameter.Checked)
            {
                _View.InsertionMode = InsertionMode.Parameter;
                _View.AllowLink = false;

                tsbSchedulingLink.Checked = false;
                tsbEventObjectNode.Checked = false;
                tsbSchedule.Checked = false;
                tsbMessage.Checked = false;
            }
            else
                _View.InsertionMode = InsertionMode.None;
        }
        #endregion

        #region Event Handlers for Toolbar Menu - Alignments
        private void tsbLeft_Click(object sender, EventArgs e)
        {
            AlignLeftSides();
        }

        private void tsbCenter_Click(object sender, EventArgs e)
        {
            AlignHorizontalCenters();
        }

        private void tsbRight_Click(object sender, EventArgs e)
        {
            AlignRightSides();
        }

        private void tsbTop_Click(object sender, EventArgs e)
        {
            AlignTops();
        }

        private void tsbMiddle_Click(object sender, EventArgs e)
        {
            AlignVerticalCenters();
        }

        private void tsbBottom_Click(object sender, EventArgs e)
        {
            AlignBottoms();
        }
        #endregion

        #region Event Handlers for Toolstrip Menu - Zoom Control
        private void tsbGrid_Click(object sender, EventArgs e)
        {
            tsbGrid.Checked = !tsbGrid.Checked;
            _View.Grid.Visible = tsbGrid.Checked;
        }

        private void tsbZoomIn_Click(object sender, EventArgs e)
        {
            ZoomIn();
        }

        private void tsbZoomOut_Click(object sender, EventArgs e)
        {
            ZoomOut();
        }

        private void tsbZoomFit_Click(object sender, EventArgs e)
        {
            ZoomToFit();
        }

        private void tscbZoom_SelectedIndexChanged(object sender, EventArgs e)
        {
            string zoomScale = tscbZoom.Text;

            Zoom(zoomScale);
        }
        #endregion
        /*
        private void OnViewScaleChanged(double scale)
        {
            tscbZoom.Text = Math.Round(scale * 100, 0).ToString() + "%";
        } 
        */

        #region Zoom Control Methods
        public void Zoom(string zoomScale)
        {
            float scale = 1.0f;
            if (zoomScale.Contains("%"))
                zoomScale = zoomScale.Substring(0, zoomScale.Length - 1);
            scale = float.Parse(zoomScale) / 100;

            _View.Zoom(scale);
        }

        public void SetZoomScale(float scale)
        {
            tscbZoom.Text = Math.Round(scale * 100, 0).ToString() + "%";
        }

        public void ZoomIn()
        {
            _View.ZoomIn();

            tscbZoom.Text = Math.Round(_View.DocScale * 100, 0).ToString() + "%";
        }

        public void ZoomToFit()
        {
            _View.ZoomToFit();
            tscbZoom.Text = Math.Round(_View.DocScale * 100, 0).ToString() + "%";
        }

        public void ZoomOut()
        {
            _View.ZoomOut();
            tscbZoom.Text = Math.Round(_View.DocScale * 100, 0).ToString() + "%";
        }

        #endregion

        #region Alignment Methods

        public void AlignLeftSides()
        {
            _View.AlignLeftSides();
        }

        public void AlignHorizontalCenters()
        {
            _View.AlignHorizontalCenters();
        }

        public void AlignRightSides()
        {
            _View.AlignRightSides();
        }

        public void AlignTops()
        {
            _View.AlignTops();
        }

        public void AlignVerticalCenters()
        {
            _View.AlignVerticalCenters();
        }

        public void AlignBottoms()
        {
            _View.AlignBottoms();
        }
        #endregion

        #region Event Handlers for Form Events
        private void EventGraphDiagramWindow_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                tsbEventObjectNode.Checked = false;
                tsbSchedulingLink.Checked = false;

                _View.AllowLink = false;
                _View.InsertionMode = InsertionMode.None;
            }
            else if (e.KeyCode == Keys.Add && e.Control)
            {
                ZoomIn();
            }
            else if (e.KeyCode == Keys.Subtract && e.Control)
            {
                ZoomOut();
            }
            else if (e.KeyCode == Keys.OemMinus && e.Control)
            {
                ZoomOut();
            }
            else if (e.KeyCode == Keys.Oemplus && e.Control)
            {
                ZoomIn();
            }
        }

        #endregion

        #region Methods for Highlights
        private List<GoObject> mySelection = null;
        private GoObject myPrimary = null;
        private void UpdateHighlighting()
        {
            if (myPrimary != null)
            {
                //disableHighlight(myPrimary);
                foreach (GoObject obj in mySelection)
                    disableHighlight(obj);
                //highlight(myPrimary, Color.Black, 1);
            }

            myPrimary = _View.Selection.Primary;
            mySelection = _View.Selection.ToList<GoObject>();
            foreach (GoObject obj in mySelection)
                enableHighlight(obj);
        }

        private void enableHighlight(GoObject obj)
        {
            highlight(obj, Color.Red, 2);
        }


        private void disableHighlight(GoObject obj)
        {
            /*
            if (obj is Node)
            {
                Node n = (Node)obj;

                n.BorderPen = new Pen(Color.Black, 1);
                //n.Pen = new Pen(Color.Black, 1);
            }
            else
                highlight(obj, Color.Black, 1);
             */
        }

        private void highlight(GoObject obj, Color c, float w)
        {
            /*
            if (obj is Node)
            {
                Node n = (Node)obj;
                n.BorderPen = new Pen(c, w);
                //n.Pen = new Pen(c, w);

            }
            else if (obj is ObjectSchedulingLink)
            {
                ObjectSchedulingLink l = (ObjectSchedulingLink)obj;
                l.Highlight = true;
                l.HighlightPen = new Pen(c, w);
            }
             */
        }
        #endregion

        private bool isLoading = false;
        public void Update(OOSGStateObjectModel objectModel)
        {
            isLoading = true;

            //State Vertice
            foreach (OOSGState state in objectModel.States)
            {
                StateVertexNode node = (StateVertexNode)_View.Doc.InsertStateVertexNode(state);
                node.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
            }

            //Edge
            foreach (OOSGStateTransition st in objectModel.STT)
            {
                _View.Doc.InsertEdge(st.CurrentState, st);
            }

            //Schedule 
            foreach (OOMMSchedule s in objectModel.Schedules)
            {
                ScheduleNode node = (ScheduleNode)_View.Doc.InsertScheduleNode(s);
                node.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
            }

            //Message
            foreach (OOSGMessage msg in objectModel.Messages)
            {
                MessageNode node = _View.Doc.InsertMessageNode(msg);
                node.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);
            }

            //Parameter
            foreach (OOSGParameter p in objectModel.Parameters)
            {
                ParameterNode node = _View.Doc.InsertParameterNode(p);
                node.PropertyChanged += new Model.PropertyChangedEventHandler(OnPropertyChanged);

            }


            isLoading = false;
        }

        private void OnPropertyChanged(object target, string propertyName, object oldPropertyValue, object newPropertyValue)
        {
            if (Changed != null && Changed.GetInvocationList().Length > 0)
            {
                ChangedTarget targetType = ChangedTarget.State;
                if (target is StateVertexNode)
                {
                    targetType = ChangedTarget.State;
                }
                else if (target is MessageNode)
                {
                    targetType = ChangedTarget.Message;
                }
                else if (target is ParameterNode)
                {
                    targetType = ChangedTarget.Parameter;
                }
                else if (target is ScheduleNode)
                {
                    targetType = ChangedTarget.ScheduleNode;
                }

                Changed(targetType, ChangedType.Modified, oldPropertyValue, newPropertyValue);
            }
        }

        private void handleStateVertexEvent(ChangedType action, object before, object after)
        {
            if (action == ChangedType.Modified)
            {
                isLoading = true;
                foreach (GoObject obj in _View.Doc)
                {
                    if (obj is GoBasicNode)
                    {
                        GoBasicNode node = (GoBasicNode)obj;

                        if (node.Text == before.ToString())
                        {
                            node.Text = after.ToString();
                            break;
                        }
                    }
                }
                isLoading = false;
            }
            else if (action == ChangedType.Added)
            {
                isLoading = true;
                PointF pf = new PointF(100, 100);
                foreach (GoObject obj in _View.Doc)
                {
                    if (obj is GoBasicNode)
                    {
                        GoBasicNode node = (GoBasicNode)obj;

                        pf = node.Center;
                    }
                }

                pf.X += 50;
                pf.Y += 50;
                StateVertexNode newNode = (StateVertexNode)_View.Doc.InsertStateVertexNode(pf.X, pf.Y, after.ToString());
                isLoading = false;

            }
            else if (action == ChangedType.Deleted)
            {
                isLoading = true;
                EventVertexNode deletedNode = (EventVertexNode)_View.Doc.FindNode((string)before);
                _View.Doc.Remove(deletedNode.Presentation);
                isLoading = false;
            }
        }

        private void handleNextStateEvent(ChangedType action, object before, object after)
        {
            if (action == ChangedType.Modified)
            {
                isLoading = true;
                string[] beforeEventPairs = before.ToString().Split(new string[] { "->" }, StringSplitOptions.RemoveEmptyEntries);
                string[] afterEventPairs = after.ToString().Split(new string[] { "->" }, StringSplitOptions.RemoveEmptyEntries);

                //기존 edge 삭제
                if (beforeEventPairs.Length == 2)
                    _View.Doc.RemoveEdge(beforeEventPairs[0], beforeEventPairs[1]);

                //다음 edge 추가
                if (afterEventPairs.Length == 2)
                    _View.Doc.InsertEdge(afterEventPairs[0], afterEventPairs[1]);

                //chained change가 일어나지 않도록 할 것!!!
                isLoading = false;

            }
            else if (action == ChangedType.Added)
            {
                isLoading = true;
                string[] afterEventPairs = after.ToString().Split(new string[] { "->" }, StringSplitOptions.RemoveEmptyEntries);
                if (afterEventPairs.Length == 2)
                    _View.Doc.InsertEdge(afterEventPairs[0], afterEventPairs[1]);

                isLoading = false;
            }
        }

        private void handleInitiaStateEvent(ChangedType action, object before, object after)
        {
            if (action == ChangedType.Modified)
            {
                bool initialState = bool.Parse(after.ToString());
                Node node = (Node)_View.Doc.FindNode(before.ToString());
                if (initialState)
                    ((StateVertexNode)node).setInitial();
                else
                    ((StateVertexNode)node).setRegular();
            }
        }

        private void handleTranstionEvent(ChangedType action, object before, object after)
        {
            if (action == ChangedType.Modified)
            {
                //TODO
            }
            else if (action == ChangedType.Deleted)
            {
                List<OOSGStateTransition> transitionList = (List<OOSGStateTransition>)before;
                foreach (OOSGStateTransition targetTransition in transitionList)
                {
                    deleteTransition(targetTransition);
                }
            }
        }

        public void OnSTTChanged(ChangedTarget target, ChangedType action, object before, object after)
        {
            if (target == ChangedTarget.StateVertex)
            {
                handleStateVertexEvent(action, before, after);         
            }
            else if (target == ChangedTarget.NextState)
            {
                handleNextStateEvent(action, before, after);   
            }
            else if (target == ChangedTarget.InitiaState)
            {
                handleInitiaStateEvent(action, before, after);
            }
            else if (target == ChangedTarget.Transition)
            {
                handleTranstionEvent(action, before, after);
            }
            else if (target == ChangedTarget.TransitionCondition)
            {
                if (action == ChangedType.Modified)
                {
                    OOSGStateTransition newST = (OOSGStateTransition)after;
                    if (newST.NextState == null)
                        return;

                    foreach (GoObject obj in this.View.Doc)
                    {
                        //현재 transition을 unique하게 구별할 방법이 없음
                        if (obj is Transition)
                        {
                            Transition link = (Transition)obj;

                            if (((GoBasicNode)link.FromNode).Text.Equals(newST.CurrentState.Name) &&
                                 ((GoBasicNode)link.ToNode).Text.Equals(newST.NextState.Name))
                            {
                                GoText fromLabel = null;
                                GoText midLabel = null;

                                if (link.FromLabel != null)
                                    fromLabel = (GoText)link.FromLabel;
                                else
                                    fromLabel = this.View.Doc.CreateInputEventLabel("");

                                if (link.MidLabel != null)
                                    midLabel = (GoText)link.MidLabel;
                                else
                                    midLabel = this.View.Doc.CreateConditionLabel("");

                                if (string.IsNullOrEmpty(newST.InputOrDelay) && string.IsNullOrEmpty(fromLabel.Text))
                                {
                                    midLabel.Text = newST.Condition;
                                }
                                else if (newST.InputOrDelay.Equals(fromLabel.Text))
                                {
                                    midLabel.Text = newST.Condition;
                                }
                            }
                        }
                    }
                }
                else if (action == ChangedType.Deleted)
                {
                    List<OOSGStateTransition> transitionList = (List<OOSGStateTransition>)before;
                    OOSGStateTransition targetTransition = transitionList[0];

                    deleteTransition(targetTransition);
                }
            }
            else if (target == ChangedTarget.InputEvent)
            {
                if (action == ChangedType.Modified)
                {
                    OOSGStateTransition newST = (OOSGStateTransition)after;
                    foreach (GoObject obj in this.View.Doc)
                    {
                        //현재 transition을 unique하게 구별할 방법이 없음
                        if (obj is Transition)
                        {
                            Transition link = (Transition)obj;

                            if (newST.NextState == null)
                                continue;

                            if (((GoBasicNode)link.FromNode).Text.Equals(newST.CurrentState.Name) &&
                                 ((GoBasicNode)link.ToNode).Text.Equals(newST.NextState.Name))
                            {
                                GoText fromLabel = null;
                                GoText midLabel = null;

                                if (link.FromLabel != null)
                                    fromLabel = (GoText)link.FromLabel;
                                else
                                    fromLabel = this.View.Doc.CreateInputEventLabel("");

                                if (link.MidLabel != null)
                                    midLabel = (GoText)link.MidLabel;
                                else
                                    midLabel = this.View.Doc.CreateConditionLabel("");

                                if (string.IsNullOrEmpty(newST.Condition) && string.IsNullOrEmpty(midLabel.Text))
                                {
                                    fromLabel.Text = newST.InputOrDelay;
                                }
                                else if (newST.Condition.Equals(midLabel.Text))
                                {
                                    fromLabel.Text = newST.InputOrDelay;
                                }
                            }
                        }
                    }
                }
                else if (action == ChangedType.Deleted)
                {
                    List<OOSGStateTransition> transitionList = (List<OOSGStateTransition>)before;
                    foreach (OOSGStateTransition targetTransition in transitionList)
                    {
                        deleteTransition(targetTransition);
                    }
                }
            }
        }

        private void deleteTransition(OOSGStateTransition targetTransition)
        {
            Transition targetLink = null;
            foreach (GoObject obj in this.View.Doc)
            {
                //현재 transition을 unique하게 구별할 방법이 없음
                if (obj is Transition)
                {
                    Transition link = (Transition)obj;

                    if (((GoBasicNode)link.FromNode).Text.Equals(targetTransition.CurrentState.Name) &&
                         ((GoBasicNode)link.ToNode).Text.Equals(targetTransition.NextState.Name))
                    {
                        GoText fromLabel = null;
                        GoText midLabel = null;

                        if (link.FromLabel != null)
                            fromLabel = (GoText)link.FromLabel;
                        else
                            fromLabel = this.View.Doc.CreateInputEventLabel("");

                        if (link.MidLabel != null)
                            midLabel = (GoText)link.MidLabel;
                        else
                            midLabel = this.View.Doc.CreateConditionLabel("");

                        bool isSame = false;
                        if (string.IsNullOrEmpty(targetTransition.InputOrDelay) && string.IsNullOrEmpty(fromLabel.Text))
                        {
                            isSame = true;
                        }
                        else if (targetTransition.InputOrDelay.Equals(fromLabel.Text))
                        {
                            isSame = true;
                        }

                        if (string.IsNullOrEmpty(targetTransition.Condition) && string.IsNullOrEmpty(midLabel.Text))
                        {
                            isSame = true;
                        }
                        else if (targetTransition.Condition.Equals(midLabel.Text))
                        {
                            isSame = true;
                        }

                        if (isSame)
                        {
                            targetLink = link;
                            break;
                        }
                    }
                }
            }

            if (targetLink != null)
            {
                targetLink.Remove();
            }
        }
        private void tsbAutoConnect_Click(object sender, EventArgs e)
        {
            tsbAutoConnect.Checked = !tsbAutoConnect.Checked;

            _View.AutoConnect = tsbAutoConnect.Checked;

            if (tsbAutoConnect.Checked)
            {
                _View.InsertionMode = InsertionMode.SchedulingEdge;
                //tsbSchedulingLink.Checked = false;
            }
            else
                _View.InsertionMode = InsertionMode.None;
        }


        public Node FindNode(string name)
        {
            return _View.FindNode(name);
        }

        private void tsbLayout_Click(object sender, EventArgs e)
        {
            //Microsoft.Msagl.Core.Layout.GeometryGraph graph = new GeometryGraph();

            GeometryGraph graph = new GeometryGraph();

            double w = 30;
            double h = 20;

            Dictionary<string, GoBasicNode> goNodeList =
                new Dictionary<string, GoBasicNode>();

            Dictionary<string, Microsoft.Msagl.Core.Layout.Node> graphNodes =
                new Dictionary<string, Microsoft.Msagl.Core.Layout.Node>();
            foreach (GoObject obj in _View.Doc)
            {
                if (obj is GoBasicNode)
                {
                    GoBasicNode mpNode = (GoBasicNode)obj;
                    Microsoft.Msagl.Core.Layout.Node gNode =
                        new Microsoft.Msagl.Core.Layout.Node(
                            new Ellipse(w, h, new Microsoft.Msagl.Core.Geometry.Point(mpNode.Center.X, mpNode.Center.Y)), mpNode.Text);

                    graph.Nodes.Add(gNode);
                    graphNodes.Add(mpNode.Text, gNode);
                    goNodeList.Add(mpNode.Text, mpNode);
                }
            }

            foreach (GoObject obj in _View.Doc)
            {
                if (obj is GoLabeledLink)
                {
                    GoLabeledLink link = (GoLabeledLink)obj;
                    GoBasicNode fromNode = (GoBasicNode)link.FromNode;
                    GoBasicNode toNode = (GoBasicNode)link.ToNode;

                    Microsoft.Msagl.Core.Layout.Node fromGraphNode = graphNodes[fromNode.Text];
                    Microsoft.Msagl.Core.Layout.Node toGraphNode = graphNodes[toNode.Text];

                    Edge edge = new Edge(fromGraphNode, toGraphNode) { Length = 1 };
                    graph.Edges.Add(edge);
                }
            }

            var settings = new Microsoft.Msagl.Layout.MDS.MdsLayoutSettings();
            LayoutHelpers.CalculateLayout(graph, settings, null);

            foreach (Microsoft.Msagl.Core.Layout.Node node in graph.Nodes)
            {
                string nodeName = (string)node.UserData;
                GoBasicNode goNode = goNodeList[nodeName];
                goNode.Center = new PointF((float)node.Center.X, (float)node.Center.Y);
            }

            _View.ZoomToFit();
        }
    }
}
