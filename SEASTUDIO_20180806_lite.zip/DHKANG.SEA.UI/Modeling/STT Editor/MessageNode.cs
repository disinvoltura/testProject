﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Northwoods.Go;
using System.Windows.Forms;
using DHKANG.SEA.UI.OutputView;
using DHKANG.Foundation.DataCollection;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model;

namespace DHKANG.SEA.UI.STTEditor
{
    public class MessageNode : GoSimpleNode
    {
        #region Member Variables
        //private Guid _NodeID;
        private OOSGMessage _Message;
        #endregion

        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Properties
        public OOSGMessage Message 
        {
            get { return _Message; }
            set {
                OOSGMessage oldValue = null;
                if (this.Message != null)
                    oldValue = this.Message.Clone();
                  _Message = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Message", oldValue, value);
            }
        }
       
        public string MessageName
        {
            get { return _Message.MName; }
            set
            {
                OOSGMessage oldValue = this.Message.Clone();
                string oldPropertyValue = _Message.MName;
                _Message.MName = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Name", oldValue, this.Message);
            }
        } 

        public MessageType MessageType
        {
            get { return _Message.Type; }
            set
            {
                OOSGMessage oldValue = this.Message.Clone();
                MessageType oldPropertyValue = _Message.Type;
                _Message.Type = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Type", oldValue, this.Message);
            }
        }

        /*
        public Guid NodeID 
        {
            get { return _NodeID; }
            set {
                Guid oldValue = _NodeID;
                _NodeID = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "NodeID", oldValue, value);
            }
        }

        public string XAxsisValue
        {
            get { return _XAxisValue; }
            set {
                string oldValue = _XAxisValue;
                _XAxisValue = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "XAxsisValue", oldValue, value);
            }
        }
        */
        #endregion

        #region Constructors
        public MessageNode(string name, float x, float y)
        {
            //_NodeID = Guid.NewGuid();
            _Message = new OOSGMessage(name, MessageType.Input);
            _Message.X = x;
            _Message.Y = y;
            initialize(x, y);
        }

        public MessageNode(OOSGMessage message)
        {
            _Message = message;

            initialize(_Message.X, _Message.Y);
        }

        private void initialize(float x, float y)
        {
            this.Initialize(null, null, _Message.MName);
            this.Figure = GoFigure.RightTriangle;
            //this.Image.Name = “special.gif”
            this.Icon.Size = new SizeF(15, 15);
            this.Icon.Resizable = false;
            this.Shape.FillShapeGradient(Color.Orange);
            this.Orientation = Orientation.Vertical;
            this.InPort.Visible = false;
            this.OutPort.Visible = false;
            this.Editable = false;
            this.Left = x;
            this.Top = y;

            this.UpdateText();
        }
        #endregion

        #region Methods
        public void UpdateText()
        {
            this.Text = _Message.MName;

            if (_Message.Type == MessageType.Input)
                this.Figure = GoFigure.RightTriangle;
            else if (_Message.Type == MessageType.Output)
                this.Figure = GoFigure.DoubleArrow;
        }

        public void Reset()
        {
        }

        public override string GetToolTip(GoView view)
        {
            string tooltip = string.Empty;
            if (_Message != null)
            {
                tooltip =  _Message.DisplayName;
            }
            return tooltip;
        }

        /*
        public bool ShowDialog()
        {
            bool rslt = false;

            OOEGEventGraphModel model = MainForm.App.getCurrentEditor().BuildModel();
            LabelNodeDialog dialog = new LabelNodeDialog(model, this);
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                OOEGEventObjectModel eoModel = model.FindEventObjectModel(dialog.EventObjectName);
                OOEGStateVariable sv = eoModel.GetStateVariable(dialog.StateVariableName);

                this.EventObjectID = eoModel.ID;
                this.EventObjectName = eoModel.Name;
                this.StateVariableName = sv.Name;
                this.InitialValue = sv.InitialValue;
                rslt = true;
            }
            return rslt;
        }
        */

        /*
        public bool ShowFontDialog()
        {
            bool rslt = false;

            FontDialog dialog = new FontDialog();
            dialog.Font = this.Font;
            dialog.ShowColor = true;
            dialog.ShowEffects = true;
            dialog.Color = this.TextColor;

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                this.Font = dialog.Font;
                this.TextColor = dialog.Color;
                rslt = true;
            }

            return rslt;
        }
        */
        #endregion
    }
}
