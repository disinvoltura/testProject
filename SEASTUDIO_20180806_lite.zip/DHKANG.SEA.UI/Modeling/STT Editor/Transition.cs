﻿using Northwoods.Go;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.UI.STTEditor
{
    public class Transition : GoLabeledLink
    {
        public Transition(): base()
        {
            this.Style = GoStrokeStyle.Bezier;
            this.ToArrow = true;
            this.RealLink.PenColor = Color.Black;
            this.RealLink.PenWidth = 2;
        }

        public override GoLink CreateRealLink()
        {
            return new TransitionLink();
        }
    }

    [Serializable]
    public class TransitionLink : GoLink
    {
        public TransitionLink() { }

        // Whenever the user resizes a link interactively, don't automatically recalculate
        // the stroke all the time.
        public override void DoResize(GoView view, RectangleF origRect, PointF newPoint,
                                      int whichHandle, GoInputState evttype, SizeF min, SizeF max)
        {
            base.DoResize(view, origRect, newPoint, whichHandle, evttype, min, max);
            this.AdjustingStyle = GoLinkAdjustingStyle.Scale;
        }
    }
}
