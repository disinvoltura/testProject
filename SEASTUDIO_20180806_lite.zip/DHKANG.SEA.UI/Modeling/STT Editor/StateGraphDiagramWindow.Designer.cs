﻿namespace DHKANG.SEA.UI.STTEditor
{
    partial class StateGraphDiagramWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StateGraphDiagramWindow));
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this._View = new DHKANG.SEA.UI.STTEditor.StateGraphDiagramView();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbEventObjectNode = new System.Windows.Forms.ToolStripButton();
            this.tsbSchedulingLink = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbAutoConnect = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbSchedule = new System.Windows.Forms.ToolStripButton();
            this.tsbMessage = new System.Windows.Forms.ToolStripButton();
            this.tsbParameter = new System.Windows.Forms.ToolStripButton();
            this.toolStrip4 = new System.Windows.Forms.ToolStrip();
            this.tsbLeft = new System.Windows.Forms.ToolStripButton();
            this.tsbCenter = new System.Windows.Forms.ToolStripButton();
            this.tsbRight = new System.Windows.Forms.ToolStripButton();
            this.tsbTop = new System.Windows.Forms.ToolStripButton();
            this.tsbMiddle = new System.Windows.Forms.ToolStripButton();
            this.tsbBottom = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbGrid = new System.Windows.Forms.ToolStripButton();
            this.tsbLayout = new System.Windows.Forms.ToolStripButton();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.tsbZoomIn = new System.Windows.Forms.ToolStripButton();
            this.tsbZoomOut = new System.Windows.Forms.ToolStripButton();
            this.tsbZoomFit = new System.Windows.Forms.ToolStripButton();
            this.tscbZoom = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.toolStrip4.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this._View);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(835, 275);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(835, 386);
            this.toolStripContainer1.TabIndex = 0;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip2);
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip4);
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip1);
            this.toolStripContainer1.TopToolStripPanel.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // _View
            // 
            this._View.ArrowMoveLarge = 10F;
            this._View.ArrowMoveSmall = 1F;
            this._View.BackColor = System.Drawing.Color.White;
            this._View.Dock = System.Windows.Forms.DockStyle.Fill;
            this._View.GridCellSizeHeight = 15F;
            this._View.GridCellSizeWidth = 15F;
            this._View.GridLineWidth = 0.1F;
            this._View.GridSnapDrag = Northwoods.Go.GoViewSnapStyle.Jump;
            this._View.GridStyle = Northwoods.Go.GoViewGridStyle.Line;
            this._View.InsertionMode = DHKANG.SEA.UI.InsertionMode.None;
            this._View.Location = new System.Drawing.Point(0, 0);
            this._View.Name = "_View";
            this._View.Size = new System.Drawing.Size(835, 275);
            this._View.TabIndex = 0;
            this._View.Text = "eventGraphDiagramView1";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(30, 30);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbEventObjectNode,
            this.tsbSchedulingLink,
            this.toolStripSeparator1,
            this.tsbAutoConnect,
            this.toolStripButton1,
            this.tsbSchedule,
            this.tsbMessage,
            this.tsbParameter});
            this.toolStrip1.Location = new System.Drawing.Point(3, 74);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(216, 37);
            this.toolStrip1.TabIndex = 0;
            // 
            // tsbEventObjectNode
            // 
            this.tsbEventObjectNode.AutoSize = false;
            this.tsbEventObjectNode.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbEventObjectNode.Image = ((System.Drawing.Image)(resources.GetObject("tsbEventObjectNode.Image")));
            this.tsbEventObjectNode.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEventObjectNode.Name = "tsbEventObjectNode";
            this.tsbEventObjectNode.Size = new System.Drawing.Size(30, 30);
            this.tsbEventObjectNode.Text = "Add an Event Vertex";
            this.tsbEventObjectNode.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // tsbSchedulingLink
            // 
            this.tsbSchedulingLink.AutoSize = false;
            this.tsbSchedulingLink.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSchedulingLink.Image = ((System.Drawing.Image)(resources.GetObject("tsbSchedulingLink.Image")));
            this.tsbSchedulingLink.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSchedulingLink.Name = "tsbSchedulingLink";
            this.tsbSchedulingLink.Size = new System.Drawing.Size(30, 30);
            this.tsbSchedulingLink.Text = "Add an Edge";
            this.tsbSchedulingLink.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 37);
            // 
            // tsbAutoConnect
            // 
            this.tsbAutoConnect.AutoSize = false;
            this.tsbAutoConnect.Checked = true;
            this.tsbAutoConnect.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsbAutoConnect.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAutoConnect.Image = ((System.Drawing.Image)(resources.GetObject("tsbAutoConnect.Image")));
            this.tsbAutoConnect.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAutoConnect.Name = "tsbAutoConnect";
            this.tsbAutoConnect.Size = new System.Drawing.Size(30, 30);
            this.tsbAutoConnect.Text = "Auto Connect";
            this.tsbAutoConnect.Click += new System.EventHandler(this.tsbAutoConnect_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(6, 37);
            // 
            // tsbSchedule
            // 
            this.tsbSchedule.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSchedule.Image = ((System.Drawing.Image)(resources.GetObject("tsbSchedule.Image")));
            this.tsbSchedule.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSchedule.Name = "tsbSchedule";
            this.tsbSchedule.Size = new System.Drawing.Size(34, 34);
            this.tsbSchedule.Text = "Schedule";
            this.tsbSchedule.ToolTipText = "Add a Schedule";
            this.tsbSchedule.Click += new System.EventHandler(this.tsbSchedule_Click);
            // 
            // tsbMessage
            // 
            this.tsbMessage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMessage.Image = ((System.Drawing.Image)(resources.GetObject("tsbMessage.Image")));
            this.tsbMessage.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbMessage.Name = "tsbMessage";
            this.tsbMessage.Size = new System.Drawing.Size(34, 34);
            this.tsbMessage.Text = "Add a Message";
            this.tsbMessage.Click += new System.EventHandler(this.tsbMessage_Click);
            // 
            // tsbParameter
            // 
            this.tsbParameter.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbParameter.Image = ((System.Drawing.Image)(resources.GetObject("tsbParameter.Image")));
            this.tsbParameter.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbParameter.Name = "tsbParameter";
            this.tsbParameter.Size = new System.Drawing.Size(34, 34);
            this.tsbParameter.Text = "Add a Parameter";
            this.tsbParameter.Click += new System.EventHandler(this.tsbParameter_Click);
            // 
            // toolStrip4
            // 
            this.toolStrip4.AutoSize = false;
            this.toolStrip4.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip4.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStrip4.ImageScalingSize = new System.Drawing.Size(30, 30);
            this.toolStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbLeft,
            this.tsbCenter,
            this.tsbRight,
            this.tsbTop,
            this.tsbMiddle,
            this.tsbBottom,
            this.toolStripSeparator4,
            this.tsbGrid,
            this.tsbLayout});
            this.toolStrip4.Location = new System.Drawing.Point(3, 37);
            this.toolStrip4.Name = "toolStrip4";
            this.toolStrip4.Size = new System.Drawing.Size(666, 37);
            this.toolStrip4.TabIndex = 5;
            // 
            // tsbLeft
            // 
            this.tsbLeft.AutoSize = false;
            this.tsbLeft.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbLeft.Image = ((System.Drawing.Image)(resources.GetObject("tsbLeft.Image")));
            this.tsbLeft.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbLeft.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLeft.Name = "tsbLeft";
            this.tsbLeft.Size = new System.Drawing.Size(30, 30);
            this.tsbLeft.Text = "Align Left";
            this.tsbLeft.Click += new System.EventHandler(this.tsbLeft_Click);
            // 
            // tsbCenter
            // 
            this.tsbCenter.AutoSize = false;
            this.tsbCenter.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCenter.Image = ((System.Drawing.Image)(resources.GetObject("tsbCenter.Image")));
            this.tsbCenter.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCenter.Name = "tsbCenter";
            this.tsbCenter.Size = new System.Drawing.Size(30, 30);
            this.tsbCenter.Text = "Align Center";
            this.tsbCenter.Click += new System.EventHandler(this.tsbCenter_Click);
            // 
            // tsbRight
            // 
            this.tsbRight.AutoSize = false;
            this.tsbRight.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRight.Image = ((System.Drawing.Image)(resources.GetObject("tsbRight.Image")));
            this.tsbRight.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRight.Name = "tsbRight";
            this.tsbRight.Size = new System.Drawing.Size(30, 30);
            this.tsbRight.Text = "Align Right";
            this.tsbRight.Click += new System.EventHandler(this.tsbRight_Click);
            // 
            // tsbTop
            // 
            this.tsbTop.AutoSize = false;
            this.tsbTop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbTop.Image = ((System.Drawing.Image)(resources.GetObject("tsbTop.Image")));
            this.tsbTop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTop.Name = "tsbTop";
            this.tsbTop.Size = new System.Drawing.Size(30, 30);
            this.tsbTop.Text = "Align Top";
            this.tsbTop.Click += new System.EventHandler(this.tsbTop_Click);
            // 
            // tsbMiddle
            // 
            this.tsbMiddle.AutoSize = false;
            this.tsbMiddle.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMiddle.Image = ((System.Drawing.Image)(resources.GetObject("tsbMiddle.Image")));
            this.tsbMiddle.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbMiddle.Name = "tsbMiddle";
            this.tsbMiddle.Size = new System.Drawing.Size(30, 30);
            this.tsbMiddle.Text = "Align Middle";
            this.tsbMiddle.Click += new System.EventHandler(this.tsbMiddle_Click);
            // 
            // tsbBottom
            // 
            this.tsbBottom.AutoSize = false;
            this.tsbBottom.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbBottom.Image = ((System.Drawing.Image)(resources.GetObject("tsbBottom.Image")));
            this.tsbBottom.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbBottom.Name = "tsbBottom";
            this.tsbBottom.Size = new System.Drawing.Size(30, 30);
            this.tsbBottom.Text = "Align Bottom";
            this.tsbBottom.Click += new System.EventHandler(this.tsbBottom_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 37);
            // 
            // tsbGrid
            // 
            this.tsbGrid.Checked = true;
            this.tsbGrid.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsbGrid.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbGrid.Image = ((System.Drawing.Image)(resources.GetObject("tsbGrid.Image")));
            this.tsbGrid.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbGrid.Name = "tsbGrid";
            this.tsbGrid.Size = new System.Drawing.Size(34, 34);
            this.tsbGrid.Text = "Grid";
            this.tsbGrid.Click += new System.EventHandler(this.tsbGrid_Click);
            // 
            // tsbLayout
            // 
            this.tsbLayout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbLayout.Image = ((System.Drawing.Image)(resources.GetObject("tsbLayout.Image")));
            this.tsbLayout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLayout.Name = "tsbLayout";
            this.tsbLayout.Size = new System.Drawing.Size(34, 34);
            this.tsbLayout.Text = "Automatic Layout";
            this.tsbLayout.Click += new System.EventHandler(this.tsbLayout_Click);
            // 
            // toolStrip2
            // 
            this.toolStrip2.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStrip2.ImageScalingSize = new System.Drawing.Size(30, 30);
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbZoomIn,
            this.tsbZoomOut,
            this.tsbZoomFit,
            this.tscbZoom});
            this.toolStrip2.Location = new System.Drawing.Point(3, 0);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(191, 37);
            this.toolStrip2.TabIndex = 6;
            // 
            // tsbZoomIn
            // 
            this.tsbZoomIn.AutoSize = false;
            this.tsbZoomIn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbZoomIn.Image = ((System.Drawing.Image)(resources.GetObject("tsbZoomIn.Image")));
            this.tsbZoomIn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZoomIn.Name = "tsbZoomIn";
            this.tsbZoomIn.Size = new System.Drawing.Size(34, 34);
            this.tsbZoomIn.Text = "Zoom In";
            this.tsbZoomIn.Click += new System.EventHandler(this.tsbZoomIn_Click);
            // 
            // tsbZoomOut
            // 
            this.tsbZoomOut.AutoSize = false;
            this.tsbZoomOut.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbZoomOut.Image = ((System.Drawing.Image)(resources.GetObject("tsbZoomOut.Image")));
            this.tsbZoomOut.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZoomOut.Name = "tsbZoomOut";
            this.tsbZoomOut.Size = new System.Drawing.Size(34, 34);
            this.tsbZoomOut.Text = "Zoom Out";
            this.tsbZoomOut.Click += new System.EventHandler(this.tsbZoomOut_Click);
            // 
            // tsbZoomFit
            // 
            this.tsbZoomFit.AutoSize = false;
            this.tsbZoomFit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbZoomFit.Image = ((System.Drawing.Image)(resources.GetObject("tsbZoomFit.Image")));
            this.tsbZoomFit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZoomFit.Name = "tsbZoomFit";
            this.tsbZoomFit.Size = new System.Drawing.Size(34, 34);
            this.tsbZoomFit.Text = "Zoom to fit";
            this.tsbZoomFit.Click += new System.EventHandler(this.tsbZoomFit_Click);
            // 
            // tscbZoom
            // 
            this.tscbZoom.Items.AddRange(new object[] {
            "10%",
            "25%",
            "50%",
            "65%",
            "75%",
            "100%",
            "200%",
            "300%",
            "400%"});
            this.tscbZoom.Name = "tscbZoom";
            this.tscbZoom.Size = new System.Drawing.Size(75, 37);
            this.tscbZoom.Text = "100%";
            this.tscbZoom.SelectedIndexChanged += new System.EventHandler(this.tscbZoom_SelectedIndexChanged);
            // 
            // StateGraphDiagramWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(835, 386);
            this.Controls.Add(this.toolStripContainer1);
            this.Font = new System.Drawing.Font("Calibri", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "StateGraphDiagramWindow";
            this.ShowIcon = false;
            this.Text = "State Graph Diagram Window";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.EventGraphDiagramWindow_KeyDown);
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.toolStrip4.ResumeLayout(false);
            this.toolStrip4.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbEventObjectNode;
        private System.Windows.Forms.ToolStripButton tsbSchedulingLink;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private StateGraphDiagramView _View;
        private System.Windows.Forms.ToolStrip toolStrip4;
        private System.Windows.Forms.ToolStripButton tsbLeft;
        private System.Windows.Forms.ToolStripButton tsbCenter;
        private System.Windows.Forms.ToolStripButton tsbRight;
        private System.Windows.Forms.ToolStripButton tsbTop;
        private System.Windows.Forms.ToolStripButton tsbMiddle;
        private System.Windows.Forms.ToolStripButton tsbBottom;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton tsbGrid;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton tsbZoomIn;
        private System.Windows.Forms.ToolStripButton tsbZoomOut;
        private System.Windows.Forms.ToolStripButton tsbZoomFit;
        private System.Windows.Forms.ToolStripComboBox tscbZoom;
        private System.Windows.Forms.ToolStripButton tsbAutoConnect;
        private System.Windows.Forms.ToolStripButton tsbLayout;
        private System.Windows.Forms.ToolStripSeparator toolStripButton1;
        private System.Windows.Forms.ToolStripButton tsbSchedule;
        private System.Windows.Forms.ToolStripButton tsbMessage;
        private System.Windows.Forms.ToolStripButton tsbParameter;
    }
}