﻿using DHKANG.SEA.Model.StateObjects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DHKANG.Foundation.Logging;

namespace DHKANG.SEA.UI.STTEditor
{
    public partial class D_Message : Form
    {
        private OOSGMessage _Message;
        private OOSGStateObjectModel _AM;

        public OOSGMessage Message
        {
            get { return _Message; }
        }

        public D_Message(OOSGMessage msg, OOSGStateObjectModel am)
        {
            InitializeComponent();

            _Message = msg;
            _AM = am;
            
            LogManager.Info("D_LName>OpenDialog Message: " +msg.ToString() + ", AtomicModel:" + am.Name);
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            LogManager.Info("D_Message>OK ButtonClicked");

            this.DialogResult = DialogResult.OK;

            _Message.Parameters.Clear();
            foreach (ListViewItem item in lvParameters.Items)
            {
                _Message.AddParameter(item.Text, item.SubItems[1].Text);
            }

            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            LogManager.Info("D_Message>Cancel ButtonClicked");

            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void D_Message_Load(object sender, EventArgs e)
        {
            loadMessage();
        }

        private void loadMessage()
        {
            this.Text = _Message.MName + ": " + _Message.Type.ToString();

            //parameters
            foreach (OOSGMessageParameter p in _Message.Parameters)
            {
                string paramValue = p.Value;
                ListViewItem item = new ListViewItem(p.Name);
                item.SubItems.Add(paramValue);

                lvParameters.Items.Add(item);
            }

            //state variables.
            foreach (OOSGStateVariable sv in _AM.StateVariables)
            {
                cbSVs.Items.Add(sv.Name);
            }
        }

        private void tsbAddMessage_Click(object sender, EventArgs e)
        {
            LogManager.Info("D_Message>Add ToolstripButtonClicked");

            if (string.IsNullOrEmpty(txtParamName.Text))
                return;

            if (cbSVs.SelectedItem == null && string.IsNullOrEmpty(cbSVs.Text))
                return;

            string paramName = txtParamName.Text;
            string paramValue = cbSVs.Text;

            bool isNew = true;
            foreach (ListViewItem item in lvParameters.Items)
            {
                if (item.Text.Equals(paramName))
                {
                    isNew = false;
                    break;
                }
            }

            if (isNew)
            {
                ListViewItem item = new ListViewItem(paramName);
                item.SubItems.Add(paramValue);
                lvParameters.Items.Add(item);
                //lvParameters.Sort(new ListViewItemComparer(0, "asc"));
            }
        }

        private void tsbEditMessage_Click(object sender, EventArgs e)
        {
            LogManager.Info("D_Message>Edit ToolstripButtonClicked");

            if (lvParameters.SelectedItems.Count == 0)
                return;

            if (string.IsNullOrEmpty(txtParamName.Text))
                return;

            if (cbSVs.SelectedItem == null && string.IsNullOrEmpty(cbSVs.Text))
                return;

            ListViewItem item = lvParameters.SelectedItems[0];
            item.Text = txtParamName.Text;
            item.SubItems[1].Text = cbSVs.Text;
        }

        private void tsbDeleteMessage_Click(object sender, EventArgs e)
        {
            LogManager.Info("D_Message>Edit ToolstripButtonClicked");

            if (lvParameters.SelectedItems.Count == 0)
                return;

            lvParameters.Items.Remove(lvParameters.SelectedItems[0]);
            txtParamName.Text = string.Empty;
            cbSVs.Text = string.Empty;
        }

        private void lvParameters_SelectedIndexChanged(object sender, EventArgs e)
        {
            LogManager.Info("D_Message>lvParameters>SelectedIndexChanged");

            if (lvParameters.SelectedItems.Count == 0)
                return;

            if (lvParameters.SelectedItems.Count > 0)
            {
                ListViewItem item = lvParameters.SelectedItems[0];

                txtParamName.Text = item.Text;

                cbSVs.Text = item.SubItems[1].Text;
                cbSVs.SelectedItem = item.SubItems[1].Text;

                tsbAddMessage.Enabled = false;
                tsbEditMessage.Enabled = true;
                tsbDeleteMessage.Enabled = true;

            }else if (lvParameters.SelectedItems.Count == 0)
            {
                txtParamName.Text = string.Empty;
                cbSVs.Text = string.Empty;

                tsbAddMessage.Enabled = true;
                tsbEditMessage.Enabled = false;
                tsbDeleteMessage.Enabled = false ;
            }
        }
    }
}
