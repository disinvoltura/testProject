﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.UI.ETTEditor;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.StateObjects;

namespace DHKANG.SEA.UI.STTEditor.Properties
{
    public partial class StateProperties : UserControl
    {
        private StateObjectModelEditor _Parent;
        private StateVertexNode _Node;

        private bool isUpdating = false;

        public StateProperties(StateObjectModelEditor parent)
        {
            _Parent = parent;
            InitializeComponent();
        }

        public void Update(StateVertexNode node)
        {
            _Node = node;

            showProperties();
        }

        private void showProperties()
        {
            isUpdating = true;

            txtName.Text = _Node.NodeName;

            setButtonSelection(btnRegular, false);
            setButtonSelection(btnInitial, false);
            setButtonSelection(btnFinal, false);

            if (_Node.StateType == StateType.Final)
                setButtonSelection(btnFinal, true);
            if (_Node.StateType == StateType.Initial)
                setButtonSelection(btnInitial, true);
            if (_Node.StateType == StateType.Regular)
                setButtonSelection(btnRegular, true);

            if (_Node.Delay != null)
                txtTimeDelay.Text = _Node.Delay.Name;

            isUpdating = false;
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            handleNameChanged();
        }

        private void handleNameChanged()
        {
            if (isUpdating)
                return;

            if (_Node.StateName != txtName.Text)
            {
                _Node.StateName = txtName.Text;
            }
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleNameChanged();
            }
        }

        private void cbType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            if (cbType.SelectedIndex == 0)
            {
                _Node.StateType = StateType.Final;
                _Node.setFinal();
            }
            else if (cbType.SelectedIndex == 1)
            {
                _Node.StateType = StateType.Initial;
                _Node.setInitial();
            }
            else
            {
                _Node.StateType = StateType.Regular;
                _Node.setRegular();
            }
        }

        private void handleTimeDelayChanged()
        {
            if (isUpdating)
                return;

            if (_Node.Delay.Name != txtTimeDelay.Text)
            {
                _Node.Delay = new OOSGDelay(txtTimeDelay.Text);
            }
        }

        private void txtTimeDelay_Leave(object sender, EventArgs e)
        {
            handleTimeDelayChanged();
        }

        private void txtTimeDelay_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleTimeDelayChanged();
            }
        }

        private void btnInitial_Click(object sender, EventArgs e)
        {
            setButtonSelection(btnRegular, false);
            setButtonSelection(btnInitial, true);
            setButtonSelection(btnFinal, false);

            _Node.StateType = StateType.Initial;
            _Node.setInitial();
        }

        private void btnRegular_Click(object sender, EventArgs e)
        {
            setButtonSelection(btnRegular, true);
            setButtonSelection(btnInitial, false);
            setButtonSelection(btnFinal, false);

            _Node.StateType = StateType.Regular;
            _Node.setRegular();
        }

        private void btnFinal_Click(object sender, EventArgs e)
        {
            setButtonSelection(btnRegular, false);
            setButtonSelection(btnInitial, false);
            setButtonSelection(btnFinal, true);

            _Node.StateType = StateType.Final;
            _Node.setFinal();
        }

        private void setButtonSelection(Button btn, bool selected)
        {
            if (selected)
            {
                btn.FlatAppearance.BorderColor = Color.DarkGray;
                btn.FlatAppearance.BorderSize = 1;
                btn.Font = new Font(btn.Font.FontFamily, 9, FontStyle.Bold);
                btn.BackColor = Color.DarkGray;
            }
            else
            {
                btn.FlatAppearance.BorderColor = Color.Gray;
                btn.FlatAppearance.BorderSize = 0;
                btn.Font = new Font(btn.Font.FontFamily, 9, FontStyle.Regular);
                btn.BackColor = Color.LightGray;
            }
        }
    }
}