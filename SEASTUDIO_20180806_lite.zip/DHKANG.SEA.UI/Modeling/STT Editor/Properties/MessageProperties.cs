﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.UI.ETTEditor;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.StateObjects;

namespace DHKANG.SEA.UI.STTEditor.Properties
{
    public partial class MessageProperties: UserControl
    {
        #region Member Variables
        private StateObjectModelEditor _Parent;
        private MessageNode _Node;

        private bool isUpdating = false;

        private ParameterGridValueChangedEvent valueChangedController;

        #endregion

        #region Constructors
        public MessageProperties(StateObjectModelEditor parent)
        {
            _Parent = parent;
            InitializeComponent();

            drawHeaders();

            valueChangedController = new ParameterGridValueChangedEvent();
            valueChangedController.ValueChanged += new ParameterGridValueChangedEventHandler(OnParameterGridValueChanged);

        }
        #endregion

        #region Methods
        private void OnParameterGridValueChanged(OOSGMessageParameter oldValue, OOSGMessageParameter newValue)
        {
            //필요하면, 모든 parameters를 삭제하고, grid에서 다시 목록을 저장하는 방안도 있음
            OOSGMessageParameter existingParmeter = _Node.Message.FindParameter(oldValue.Name);
            existingParmeter.Name = newValue.Name;
            existingParmeter.Value = newValue.Value;
            /*
            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            {
                Changed(ChangedTarget.StateVariable, ChangedType.Modified, oldStateVariable, newStateVariable);
            }
            */
        }

        public void Update(MessageNode node)
        {
            _Node = node;

            showProperties();
        }

        private void showProperties()
        {
            isUpdating = true;

            txtName.Text = _Node.Message.MName;
            if (_Node.Message.Type == MessageType.Input)
            {
                setButtonSelection(btnInput, true);
                setButtonSelection(btnOutput, false);
            }
            if (_Node.Message.Type == MessageType.Output)
            {
                setButtonSelection(btnInput, false);
                setButtonSelection(btnOutput, true);
            }

            showParameters();

            isUpdating = false;
        }

        private void showParameters()
        {
            drawHeaders();

            //_Node.Message.Parameters()
            List<OOSGMessageParameter> parameters = _Node.Message.Parameters;
           
            foreach (OOSGMessageParameter mp in parameters)
            {
                InsertParameter(mp);
            }

            grid.AutoStretchColumnsToFitWidth = false;
            grid.AutoStretchRowsToFitHeight = false;
            grid.AutoSizeCells();
        }

        public void InsertEmptyParameter()
        {
            int rowIndex = grid.RowsCount;
            grid.Rows.Insert(rowIndex);

            SourceGrid.Cells.Views.Cell cellView = new SourceGrid.Cells.Views.Cell();
            cellView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            //Name Column
            string sName = "Parameter " + rowIndex;
            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(sName, typeof(string));
            nameCell.View = cellView;

            //Value Column
            List<OOSGStateVariable> stateVariables = _Parent.StateObjectModel.StateVariables;
            List<string> valueList = new List<string>();
            stateVariables.ForEach(s => valueList.Add(s.Name));
            valueList.Sort();

            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus |
                                    SourceGrid.EditableMode.SingleClick |
                                    SourceGrid.EditableMode.AnyKey;
            cbEditor.Control.DropDownStyle = ComboBoxStyle.DropDownList;
            cbEditor.StandardValues = valueList;

            SourceGrid.Cells.Cell valueCell = new SourceGrid.Cells.Cell("", cbEditor);
            valueCell.View = cellView;

            grid[rowIndex, 0] = nameCell;
            grid[rowIndex, 1] = valueCell;

            grid[rowIndex, 0].AddController(this.valueChangedController);
            grid[rowIndex, 1].AddController(this.valueChangedController);

            OOSGMessageParameter mp = new OOSGMessageParameter(sName, "");
            nameCell.Tag = mp;
            _Node.Message.AddParameter(mp);
        }

        public void InsertParameter(OOSGMessageParameter mp)
        {
            int rowIndex = grid.RowsCount - 1;
            grid.Rows.Insert(rowIndex);

            SourceGrid.Cells.Views.Cell cellView = new SourceGrid.Cells.Views.Cell();
            cellView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            //Name Column
            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(mp.Name, typeof(string));
            nameCell.View = cellView;
            nameCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            nameCell.Editor.EnableEdit = true;

            //Value Column
            List<OOSGStateVariable> stateVariables = _Parent.StateObjectModel.StateVariables;
            List<string> valueList = new List<string>();
            stateVariables.ForEach(s => valueList.Add(s.Name));
            valueList.Sort();

            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus |
                                    SourceGrid.EditableMode.SingleClick |
                                    SourceGrid.EditableMode.AnyKey;
            cbEditor.Control.DropDownStyle = ComboBoxStyle.DropDownList;
            cbEditor.StandardValues = valueList;

            SourceGrid.Cells.Cell valueCell = new SourceGrid.Cells.Cell(mp.Value, cbEditor);
            valueCell.View = cellView;

            nameCell.Tag = mp;
            grid[rowIndex, 0] = nameCell;
            grid[rowIndex, 1] = valueCell;
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            handleNameChanged();
        }

        private void handleNameChanged()
        {
            if (isUpdating)
                return;

            if (_Node.MessageName != txtName.Text)
            {
                _Node.MessageName = txtName.Text;
                _Node.UpdateText();
            }
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleNameChanged();
            }
        }

        private void setButtonSelection(Button btn, bool selected)
        {
            if (selected)
            {
                btn.FlatAppearance.BorderColor = Color.DarkGray;
                btn.FlatAppearance.BorderSize = 1;
                btn.Font = new Font(btn.Font.FontFamily, 9, FontStyle.Bold);
                btn.BackColor = Color.DarkGray;
            }
            else
            {
                btn.FlatAppearance.BorderColor = Color.Gray;
                btn.FlatAppearance.BorderSize = 0;
                btn.Font = new Font(btn.Font.FontFamily, 9, FontStyle.Regular);
                btn.BackColor = Color.LightGray;
            }
        }

        private void btnInput_Click(object sender, EventArgs e)
        {
            setButtonSelection(btnInput, true);
            setButtonSelection(btnOutput, false);

            _Node.Message.Type = MessageType.Input;
            _Node.UpdateText();
        }

        private void btnRegular_Click(object sender, EventArgs e)
        {
            setButtonSelection(btnInput, false);
            setButtonSelection(btnOutput, true);

            _Node.Message.Type = MessageType.Output;
            _Node.UpdateText();
        }

        private void drawHeaders()
        {
            grid.Rows.Clear();

            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Snow;
            backHeader.Border = DevAge.Drawing.RectangleBorder.NoBorder;
            titleModel.Background = backHeader;
            //titleModel.BackColor = Color.SteelBlue;
            //titleModel.ForeColor = Color.White;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            grid.BorderStyle = BorderStyle.FixedSingle;
            grid.Redim(1, 3);
            grid.FixedRows = 1;
            grid.Font = new Font("Calibe", 10);
            //1st Header Row
            grid.Rows.Insert(0);

            //Name Column
            SourceGrid.Cells.ColumnHeader nameHeader = new SourceGrid.Cells.ColumnHeader("Name");
            nameHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            //Value Column
            SourceGrid.Cells.ColumnHeader valueHeader = new SourceGrid.Cells.ColumnHeader("Value");
            valueHeader.View = titleModel; //.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            //nameHeader.AutomaticSortEnabled = false;
            //valueHeader.AutomaticSortEnabled = false;

            grid[0, 0] = nameHeader;
            grid[0, 1] = valueHeader;
            grid.Columns[0].Width = 200;
            grid.Columns[0].MinimalWidth = 150;
            grid.Columns[1].Width = 200;
            grid.Columns[1].MinimalWidth = 150;
        }

        private void RemoveParameter()
        {
            int sRow = grid.Selection.ActivePosition.Row;
            if (sRow < 0 || grid[sRow, 0] == null)
                return;

            string sName = grid[sRow, 0].DisplayText;
            string sValue = grid[sRow, 1].DisplayText;

            _Node.Message.RemoveParamter(sName);
            grid.Rows.Remove(sRow);
        }

        private void MoveUpParameter()
        {

        }

        private void MoveDownParameter()
        {

        }

        private void MessageProperties_Load(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            InsertEmptyParameter();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            RemoveParameter();
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            MoveUpParameter();
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            MoveDownParameter();
        }
        #endregion
    }

    public delegate void ParameterGridValueChangedEventHandler(OOSGMessageParameter oldValue, OOSGMessageParameter newValue);

    public class ParameterGridValueChangedEvent : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event ParameterGridValueChangedEventHandler ValueChanged;

        public ParameterGridValueChangedEvent()
        {
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

            SourceGrid.Cells.Cell nameCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 0);
            SourceGrid.Cells.Cell valueCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 1);

            OOSGMessageParameter mp = (OOSGMessageParameter)nameCell.Tag;
            if (sender.Position.Column == 0) //name
            {
                mp.Name = (string)e.NewValue;
            }
            else if (sender.Position.Column == 1) //type
            {
                mp.Value = (string)e.NewValue;
            }

            /*
            OOSGMessageParameter oldValue = null;
            OOSGMessageParameter newValue = null;

            SourceGrid.Cells.Cell nameCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 0);
            SourceGrid.Cells.Cell valueCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 1);

            if (sender.Position.Column == 0) //name
            {
                oldValue = new OOSGMessageParameter((string)e.OldValue, valueCell.DisplayText);
                newValue = new OOSGMessageParameter((string)e.NewValue, valueCell.DisplayText);
            }
            else if (sender.Position.Column == 1) //type
            {
                oldValue = new OOSGMessageParameter(nameCell.DisplayText, (string)e.OldValue);
                newValue = new OOSGMessageParameter(valueCell.DisplayText, (string)e.NewValue);
            }

            if (ValueChanged != null && ValueChanged.GetInvocationList().Length > 0)
                ValueChanged(oldValue, newValue);
            */
        }
    }
}
