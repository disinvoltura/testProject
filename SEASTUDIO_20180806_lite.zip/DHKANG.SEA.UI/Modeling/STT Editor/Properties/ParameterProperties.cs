﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.SEA.UI.ETTEditor;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.StateObjects;

namespace DHKANG.SEA.UI.STTEditor.Properties
{
    public partial class ParameterProperties: UserControl
    {
        private StateObjectModelEditor _Parent;
        private ParameterNode _Node;

        private bool isUpdating = false;

        public ParameterProperties(StateObjectModelEditor parent)
        {
            _Parent = parent;
            InitializeComponent();
        }

        public void Update(ParameterNode node)
        {
            _Node = node;

            showProperties();
        }

        private void showProperties()
        {
            isUpdating = true;

            //Name
            txtName.Text = _Node.Parameter.Name;

            //Type
            List<string> valueTypeList = OOSGStateVariableHelper.ValueType();
            cbType.Items.Clear();
            cbType.Items.AddRange(valueTypeList.ToArray());

            //Initial Value
            txtValue.Text = _Node.Parameter.InitialValue;

            isUpdating = false;
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            handleNameChanged();
        }

        private void handleNameChanged()
        {
            if (isUpdating)
                return;

            if (_Node.ParameterName != txtName.Text)
            {
                _Node.ParameterName = txtName.Text;
                _Node.UpdateText();
            }
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleNameChanged();
            }
        }

        private void cbType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isUpdating)
                return;

            _Node.ParameterType = (string)cbType.SelectedValue;
            //_Node.ParameterType = (ParameterType)Enum.GetValues(typeof(ParameterType)).GetValue(cbType.SelectedIndex);
        }

        private void txtValue_Leave(object sender, EventArgs e)
        {
            handleValueChanged();
        }

        private void txtValue_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                handleValueChanged();
            }
        }

        private void handleValueChanged()
        {
            if (isUpdating)
                return;

            if (_Node.InitialValue != txtValue.Text)
            {
                _Node.InitialValue = txtValue.Text;
            }
        }
    }
}
