﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.StateObjects;

namespace DHKANG.SEA.UI.STTEditor
{
    public delegate void StateTransitionTableChangedEvent(ChangedTarget target, ChangedType action, object before, object after);
    public delegate void StateNameChangedEvent(string oldName, string newName);

    public partial class StateTransitionTableWindow : DockContent
    {
        #region Member Variables
        private StateObjectModelEditor _AMControl;
        private SourceGrid.Cells.Editors.ComboBox _InputEventEditor;
        private SourceGrid.Cells.Editors.ComboBox _StateEditor;

        private STTStateValueChangedEventController _StateValueChangeController;
        private STTEntryActionChangedEventController _EntryActionChangeController;
        private CellValueChangedEventController _CellValueChangedEventController;
        private STTNextStateValueChangedEventController _NextStateValueChangeController;
        private STTValueChangedEventController _ValueChangeController;

        private bool _IsUpdating;
        #endregion

        #region Events
        public event StateTransitionTableChangedEvent Changed;
        public event StateNameChangedEvent EventNameChanged;
        #endregion

        #region Events
        //public ChangedEventHandler Changed;
        #endregion

        #region Properties
        public List<OOSGStateTransition> StateTransitions
        {
            get
            {
                List<OOSGStateTransition> stateTransitions =
                    new List<OOSGStateTransition>();

                List<OOSGState> rawStateList = _AMControl.States;
                SortedList<string, OOSGState> stateList = new SortedList<string, OOSGState>();
                foreach (OOSGState state in rawStateList)
                    stateList.Add(state.Name, state);

                for (int k = 2; k < Table.Rows.Count; k += Table[k, 1] == null ? 0 : Table[k, 1].RowSpan)
                {
                    if (Table[k, 1] == null || string.IsNullOrEmpty(Table[k, 1].DisplayText))
                    {
                        System.Diagnostics.Debug.WriteLine("[StateTransitions] at row " + k + " state cell is null.");
                        continue;
                    }

                    OOSGState currentState = stateList[Table[k, 1].DisplayText];
                    string stateAction = Table[k, 2].DisplayText;

                    for (int p = 0; p < Table[k, 1].RowSpan; p += Table[k + p, 3].RowSpan)
                    {
                        //Input Event and Input Action
                        string inputEvent = Table[k + p, 3].DisplayText;
                        string inputAction = Table[k + p, 4].DisplayText;

                        //commetted out 2017/11/09
                        //if (string.IsNullOrEmpty(inputEvent))
                        //    continue;

                        for (int m = 0; m < Table[k + p, 3].RowSpan; m++)
                        {
                            string transitionCondition = Table[k + p + m, 5].DisplayText;
                            string transitionAction = Table[k + p + m, 6].DisplayText;
                            string nextStateName = Table[k + p + m, 7].DisplayText;

                            if (string.IsNullOrEmpty(nextStateName))
                                continue;

                            if (!stateList.ContainsKey(nextStateName))
                                continue;
                            OOSGState nextState = stateList[nextStateName];

                            OOSGStateTransition st =
                                new OOSGStateTransition(currentState, stateAction, inputEvent, inputAction, transitionCondition, transitionAction, nextState);

                            stateTransitions.Add(st);
                        }
                    }
                }

                return stateTransitions;
            }
        }
        #endregion

        #region Constructors
        public StateTransitionTableWindow(StateObjectModelEditor parent)
        {
            _AMControl = parent;
            _CellValueChangedEventController = new CellValueChangedEventController();
            _CellValueChangedEventController.ValueChanged += OnCellValueChanged;

            InitializeComponent();

            drawSTTHeaders();

            disableToolbars();

            this.Table.MouseWheel += Table_MouseWheel;
        }

        private void OnCellValueChanged(int row, int col, string oldValue, string newValue)
        {
            if (_IsUpdating)
                return;
            if (col == 7)
            {
                //next state
                if (Changed != null && Changed.GetInvocationList().Length > 0)
                {
                    string originStateName = Table[row, 1].DisplayText;
                    if (string.IsNullOrEmpty(oldValue))
                        Changed(ChangedTarget.NextState, ChangedType.Added, "", originStateName + "->" + newValue);
                    else
                    {
                        string oldPair = originStateName + "->" + oldValue;
                        string newPair = originStateName + "->" + newValue;

                        Changed(ChangedTarget.NextState, ChangedType.Modified, oldPair, newPair);
                    }
                }
            }
            if (Changed != null && Changed.GetInvocationList().Length > 0)
                Changed(ChangedTarget.Cell, ChangedType.Modified, oldValue, newValue);
        }
        #endregion

        private void StateTransitionTableWindow_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            base.OnFormClosing(e);
        }

        SourceGrid.Cells.Views.ColumnHeader titleModel;
        private void drawSTTHeaders()
        {
            Table.Rows.Clear();

            Table.BorderStyle = BorderStyle.FixedSingle;
            Table.Redim(2, 8);
            Table.EnableSort = false;
            Table.CustomSort = false;

            Table.FixedRows = 2;

            titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
            titleModel.Font = new Font("Consolas", 9.0f, FontStyle.Bold);

            //Font
            Table.Font = new Font(
                ToolkitConfiguration.Table.Font.FontName,
                ToolkitConfiguration.Table.Font.Size);
            Table.AutoStretchColumnsToFitWidth = ToolkitConfiguration.Table.TableStretch;

            Table.Columns[0].AutoSizeMode = SourceGrid.AutoSizeMode.None;
            Table.Columns[0].Width = 25;
            SourceGrid.Cells.Header l_00Header = new SourceGrid.Cells.Header(null);
            l_00Header.RowSpan = 2;
            Table[0, 0] = l_00Header;

            //1st Row Headers
            SourceGrid.Cells.ColumnHeader stateHeader = new SourceGrid.Cells.ColumnHeader("State");
            stateHeader.ColumnSpan = 2;
            stateHeader.View = titleModel;
            //stateHeader.SortComparer = new SourceGrid.ValueCellComparer();
            Table[0, 1] = stateHeader;

            SourceGrid.Cells.ColumnHeader inputHeader = new SourceGrid.Cells.ColumnHeader("Input");
            inputHeader.ColumnSpan = 2;
            inputHeader.View = titleModel;
            //inputHeader.SortComparer = new SourceGrid.ValueCellComparer();
            Table[0, 3] = inputHeader;

            SourceGrid.Cells.ColumnHeader transitionHeader = new SourceGrid.Cells.ColumnHeader("Transition");
            transitionHeader.ColumnSpan = 2;
            transitionHeader.View = titleModel;
            //transitionHeader.SortComparer = new SourceGrid.ValueCellComparer();
            Table[0, 5] = transitionHeader;

            SourceGrid.Cells.ColumnHeader nextStateHeader = new SourceGrid.Cells.ColumnHeader("Next State");
            nextStateHeader.RowSpan = 2;
            nextStateHeader.View = titleModel;
            //nextStateHeader.SortComparer = new SourceGrid.ValueCellComparer();
            Table[0, 7] = nextStateHeader;

            //2nd Row Headers
            SourceGrid.Cells.ColumnHeader nameHeader = new SourceGrid.Cells.ColumnHeader("Name");
            nameHeader.View = titleModel;
            Table[1, 1] = nameHeader;

            SourceGrid.Cells.ColumnHeader stateActionHeader = new SourceGrid.Cells.ColumnHeader("Action");
            stateActionHeader.View = titleModel;
            Table[1, 2] = stateActionHeader;

            SourceGrid.Cells.ColumnHeader eventHeader = new SourceGrid.Cells.ColumnHeader("Event");
            eventHeader.View = titleModel;
            Table[1, 3] = eventHeader;

            SourceGrid.Cells.ColumnHeader inputActionHeader = new SourceGrid.Cells.ColumnHeader("Action");
            inputActionHeader.View = titleModel;
            Table[1, 4] = inputActionHeader;

            SourceGrid.Cells.ColumnHeader conditionHeader = new SourceGrid.Cells.ColumnHeader("Condition");
            conditionHeader.View = titleModel;
            Table[1, 5] = conditionHeader;

            SourceGrid.Cells.ColumnHeader transitionActionHeader = new SourceGrid.Cells.ColumnHeader("Action");
            transitionActionHeader.View = titleModel;
            Table[1, 6] = transitionActionHeader;

            Table.AutoSizeCells();

            _StateEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            _StateEditor.EditableMode = SourceGrid.EditableMode.Focus |
                                        SourceGrid.EditableMode.SingleClick |
                                        SourceGrid.EditableMode.AnyKey;
            _StateEditor.Control.DropDownStyle = ComboBoxStyle.DropDownList;
            //_StateEditor.Control.SelectionChangeCommitted += new EventHandler(Control_SelectionChangeCommitted);


            _InputEventEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            _InputEventEditor.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;
            _InputEventEditor.Control.DropDownStyle = ComboBoxStyle.DropDownList;

            _StateValueChangeController = new STTStateValueChangedEventController();
            _StateValueChangeController.ValueChanged += new STTStateValueChangedEventHandler(_StateValueChangeController_ValueChanged);

            _NextStateValueChangeController = new STTNextStateValueChangedEventController();
            _NextStateValueChangeController.ValueChanged +=
                new STTNextStateValueChangedEventHandler(_NextStateValueChangeController_ValueChanged);

            _ValueChangeController = new STTValueChangedEventController();
            _ValueChangeController.ValueChanged +=
                new STTValueChangedEventHandler(_ValueChangeController_ValueChanged);

        }

        private void _StateValueChangeController_ValueChanged(int row, string oldEventName, string newEventName)
        {
            if (_IsUpdating)
                return;

            /*
            updateNextEventEditor(oldEventName, newEventName);

            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
                this.Changed("eventvertex", "changed", oldEventName, newEventName);
            */
        }

        private void _NextStateValueChangeController_ValueChanged(int row, string oldEventName, string newEventName)
        {
            if (_IsUpdating)
                return;

            string originStateName = Table[row, 1].DisplayText;

            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0 && isChangeable)
                this.Changed(ChangedTarget.Transition, ChangedType.Modified, originStateName + "->" + oldEventName, originStateName + "->" + newEventName);
        }

        private void _ValueChangeController_ValueChanged(int row, int col, string oldValue, string newValue)
        {
            if (_IsUpdating)
                return;

            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0 && isChangeable)
            {
                if (col != 1 && col != 7)
                {
                    OOSGStateTransition oldST = getStateTransitionAt(row);

                    if (oldST == null)
                        return;
                    OOSGStateTransition newST = oldST.Clone();
                    if (col == 3) //input event
                    {
                        newST.InputOrDelay = newValue;
                        this.Changed(ChangedTarget.InputEvent, ChangedType.Modified, null, newST);
                    }
                    else if (col == 4) //input action 
                    {
                        newST.InputAction = newValue;
                        this.Changed(ChangedTarget.InputAction, ChangedType.Modified, null, newST);
                    }
                    else if (col == 5) //transition condition
                    {
                        newST.Condition = newValue;
                        this.Changed(ChangedTarget.TransitionCondition, ChangedType.Modified, null, newST);
                    }
                    else if (col == 6) //transition action 
                    {
                        newST.TransitionAction = newValue;
                        this.Changed(ChangedTarget.TransitionAction, ChangedType.Modified, null, newST);
                    }

                    //this.Changed(ChangedTarget.Transition, ChangedType.Modified, null, newST);
                }
            }
        }

        private List<OOSGStateTransition> getStateTransitionsAt(int k)
        {
            List<OOSGStateTransition> stateTransitions =
                    new List<OOSGStateTransition>();

            List<OOSGState> rawStateList = _AMControl.States;
            SortedList<string, OOSGState> stateList = new SortedList<string, OOSGState>();
            foreach (OOSGState state in rawStateList)
                stateList.Add(state.Name, state);

            if (string.IsNullOrEmpty(Table[k, 1].DisplayText))
                return stateTransitions;

            OOSGState currentState = stateList[Table[k, 1].DisplayText];
            string stateAction = Table[k, 2].DisplayText;

            for (int p = 0; p < Table[k, 1].RowSpan; p += Table[k + p, 3].RowSpan)
            {
                //Input Event and Input Action
                string inputEvent = Table[k + p, 3].DisplayText;
                string inputAction = Table[k + p, 4].DisplayText;

                if (string.IsNullOrEmpty(inputEvent))
                    continue;

                for (int m = 0; m < Table[k + p, 3].RowSpan; m++)
                {
                    string transitionCondition = Table[k + p + m, 5].DisplayText;
                    string transitionAction = Table[k + p + m, 6].DisplayText;
                    string nextStateName = Table[k + p + m, 7].DisplayText;

                    if (string.IsNullOrEmpty(nextStateName))
                        continue;

                    if (!stateList.ContainsKey(nextStateName))
                        continue;
                    OOSGState nextState = stateList[nextStateName];

                    OOSGStateTransition st =
                        new OOSGStateTransition(currentState, stateAction, inputEvent, inputAction, transitionCondition, transitionAction, nextState);

                    stateTransitions.Add(st);
                }
            }

            return stateTransitions;
        }

        private OOSGStateTransition getStateTransitionAt(int row)
        {
            OOSGStateTransition rslt = null;

            if (string.IsNullOrEmpty(Table[row, 1].DisplayText))
                return rslt;

            List<OOSGState> rawStateList = _AMControl.States;
            SortedList<string, OOSGState> stateList = new SortedList<string, OOSGState>();
            foreach (OOSGState state in rawStateList)
                stateList.Add(state.Name, state);

            string currentStateName = Table[row, 1].DisplayText;
            OOSGState currentState = null;
            if (stateList.ContainsKey(currentStateName))
                currentState = stateList[currentStateName];
            string stateAction = Table[row, 2].DisplayText;

            string inputEvent = Table[row, 3].DisplayText;
            string inputAction = Table[row, 4].DisplayText;

            string transitionCondition = Table[row, 5].DisplayText;
            string transitionAction = Table[row, 6].DisplayText;
            string nextStateName = Table[row, 7].DisplayText;

            OOSGState nextState = null;
            if (stateList.ContainsKey(nextStateName))
                nextState = stateList[nextStateName];

            rslt = new OOSGStateTransition(currentState, stateAction, inputEvent, inputAction, transitionCondition, transitionAction, nextState);

            /*
            for (int p = 0; p < Table[row, 1].RowSpan; p += Table[row + p, 3].RowSpan)
            {
                //Input Event and Input Action
                string inputEvent = Table[row + p, 3].DisplayText;
                string inputAction = Table[row + p, 4].DisplayText;

                if (string.IsNullOrEmpty(inputEvent))
                    continue;

                for (int m = 0; m < Table[row + p, 3].RowSpan; m++)
                {
                    string transitionCondition = Table[row + p + m, 5].DisplayText;
                    string transitionAction = Table[row + p + m, 6].DisplayText;
                    string nextStateName = Table[row + p + m, 7].DisplayText;

                    if (string.IsNullOrEmpty(nextStateName))
                        continue;

                    if (!stateList.ContainsKey(nextStateName))
                        continue;
                    OOSGState nextState = stateList[nextStateName];

                    rslt = new OOSGStateTransition(currentState, stateAction, inputEvent, inputAction, transitionCondition, transitionAction, nextState);
                }
            }
            */
            return rslt;
        }

        private OOSGStateTransition getStateTransitionAt2(int row)
        {
            OOSGStateTransition rslt = null;

            if (string.IsNullOrEmpty(Table[row, 1].DisplayText))
                return rslt;

            List<OOSGState> rawStateList = _AMControl.States;
            SortedList<string, OOSGState> stateList = new SortedList<string, OOSGState>();
            foreach (OOSGState state in rawStateList)
                stateList.Add(state.Name, state);

            OOSGState currentState = stateList[Table[row, 1].DisplayText];
            string stateAction = Table[row, 2].DisplayText;

            for (int p = 0; p < Table[row, 1].RowSpan; p += Table[row + p, 3].RowSpan)
            {
                //Input Event and Input Action
                string inputEvent = Table[row + p, 3].DisplayText;
                string inputAction = Table[row + p, 4].DisplayText;

                if (string.IsNullOrEmpty(inputEvent))
                    continue;

                for (int m = 0; m < Table[row + p, 3].RowSpan; m++)
                {
                    string transitionCondition = Table[row + p + m, 5].DisplayText;
                    string transitionAction = Table[row + p + m, 6].DisplayText;
                    string nextStateName = Table[row + p + m, 7].DisplayText;

                    if (string.IsNullOrEmpty(nextStateName))
                        continue;

                    if (!stateList.ContainsKey(nextStateName))
                        continue;
                    OOSGState nextState = stateList[nextStateName];

                    rslt = new OOSGStateTransition(currentState, stateAction, inputEvent, inputAction, transitionCondition, transitionAction, nextState);
                }
            }

            return rslt;
        }

        private void _StateValueChangeController_ValueChanged(int row, string stateName)
        {
            //if (_AMControl.AtomicModel.States.ContainsKey(stateName))
            //{
            //    State state = _AMControl.AtomicModel.States[stateName];
            //    Table[row, 2].Value = state.EntryAction;
            //}
        }

        public void OnChanged(ChangedTarget targetType,
                                              ChangedType changedType,
                                              object before, object after)
        {
            if (targetType == ChangedTarget.Message)
            {
                if (changedType == ChangedType.Added)
                {
                    HandleAddedMessage((OOSGMessage)after);
                }
                else if (changedType == ChangedType.Deleted)
                {
                    HandleDeletedMessage((OOSGMessage)before);
                }
                else if (changedType == ChangedType.Modified)
                {
                    HandleModifiedMessage((OOSGMessage)before, (OOSGMessage)after);
                }
            }
            else if (targetType == ChangedTarget.State)
            {
                if (changedType == ChangedType.Added)
                    HandleAddedState((OOSGState)after);
                else if (changedType == ChangedType.Deleted)
                    HandleDeletedState((OOSGState)before);
                else if (changedType == ChangedType.Modified)
                {
                    //HandleModifiedState((OOSGState)before, (OOSGState)after);
                    if (before is string)
                        HandleModifiedState((string)before, (string)after);
                    else if (before is OOSGState)
                        HandleModifiedState((OOSGState)before, (OOSGState)after);
                }
            }
            else if (targetType == ChangedTarget.StateVertex)
            {

            }
            else if (targetType == ChangedTarget.TransitionLink)
            {
                doHandleEdgeChange(changedType, before, after);
            }
        }

        private bool isChangeable = true;
        public void OnSGDChanged(ChangedTarget target, ChangedType action, object before, object after)
        {
            isChangeable = false;
            if (target == ChangedTarget.State)
            {
                //doHandleVertexChange(action, before, after);
                //doHandleVertexChange(action, ((OOSGState)before).Name, ((OOSGState)after).Name);

            }
            else if (target == ChangedTarget.TransitionLink)
            {
                //doHandleEdgeChange(action, before, after);
            }

            isChangeable = true;
        }

        private void doHandleVertexChange(ChangedType action, object before, object after)
        {
            if (action == ChangedType.Modified)
            {
                for (int i = 2; i < Table.RowsCount; i++)
                {
                    SourceGrid.Cells.Cell nameCell = (SourceGrid.Cells.Cell)Table[i, 1];
                    SourceGrid.Cells.Cell nextEventCell = (SourceGrid.Cells.Cell)Table[i, 7];

                    if (nameCell != null && nameCell.DisplayText == (string)before)
                    {
                        nameCell.Value = after;
                    }

                    if (nextEventCell != null && nextEventCell.DisplayText == (string)before)
                    {
                        nextEventCell.Value = after;
                    }
                }
                //TODO 2017.10.11
                //실제로는 _StateEditor를 update 해야 하는데, 선행 조건으로 OOSGState가 정의되어 있어야 함
                //NewState가 State Window에 정의되지 않은 경우에는 문제가 발생함
                //하지만, 이는 State Window에 먼저 정의되었다고 가정해야 함
                //updateNextEventEditor();

            }
            else if (action == ChangedType.Added)
            {
                //TODO 2017.10.11
                //신규  state 가 추가되었더라도, 연결되지 않았을 경우에는 굳이 table에 추가하지 않아도 됨

                //InsertEmptyEventTransition(after);
                //updateNextEventEditor();
            }
            else if (action == ChangedType.Deleted)
            {
                for (int i = 2; i < Table.RowsCount; i++)
                {
                    SourceGrid.Cells.Cell nameCell =
                        (SourceGrid.Cells.Cell)Table[i, 1];

                    if (nameCell.DisplayText == (string)before)
                    {
                        //deleteEventAtRow(i);
                        break;
                    }

                    //TODO 2017.10.11
                    //이와 함게 _StateEditor도 update해야 하며, 
                    //Next State Column도 수정해야 함

                }

                //updateNextEventEditor();
            }
        }

        private void doHandleEdgeChange(ChangedType action, object before, object after)
        {
            if (action == ChangedType.Modified)
            {
                //TODO
                //1. From State는 그대로고, Next State만 변경된 경우,
                //   - Next State 만 변경
                //2. From State가 변경된 경우
                //   - 기존의 연결을 제거
                //   - 신규 From State 에 State Transition 을 추가; 단, 기존 transition의 input, input action, condition, condtional action은 같이 이동
            }
            else if (action == ChangedType.Added)
            {
                string[] stateVertices = ((string)after).Split(new string[] { "->" }, StringSplitOptions.RemoveEmptyEntries);
                string fromState = stateVertices[0];
                string toState = stateVertices[1];

                //기존에 FromState로부터의 State Transition이 존재하는 경우
                bool isExisting = false;
                for (int i = 2; i < Table.RowsCount; i++)
                {
                    SourceGrid.Cells.Cell nameCell =
                        (SourceGrid.Cells.Cell)Table[i, 1];

                    if (nameCell.DisplayText == fromState)
                    {
                        for (int k = 0; k < nameCell.RowSpan; k++)
                        {
                            SourceGrid.Cells.Cell nextStateCell =
                                (SourceGrid.Cells.Cell)Table[i + k, 7];

                            if (nextStateCell == null)
                                continue;

                            if (!string.IsNullOrEmpty(nextStateCell.DisplayText) && nextStateCell.DisplayText.Equals(toState))
                            {
                                isExisting = true;
                                break;
                            }
                        }
                        if (!isExisting)
                        {
                            int nextRow = i + nameCell.RowSpan;

                            //기존의 FromState의 transitions에 추가해야 함
                            InsertInputEventAt(i, toState);

                            isExisting = true;
                        }
                        break;
                    }
                }
                if (!isExisting)
                {
                    List<OOSGState> states = _AMControl.States;
                    OOSGState fromStateObject = null;
                    OOSGState toStateObject = null;
                    foreach (OOSGState s in states)
                    {
                        if (s.Name.Equals(fromState))
                            fromStateObject = s;
                        if (s.Name.Equals(toState))
                            toStateObject = s;

                        if (fromStateObject != null && toStateObject != null)
                            break;
                    }

                    if (fromStateObject != null && toStateObject != null)
                    {
                        OOSGStateTransition st = new OOSGStateTransition(fromStateObject, "", "", "", "", "", toStateObject);
                        InsertStateTransiiton(st);
                    }
                }
            }
            else if (action == ChangedType.Deleted)
            {
                string[] stateVertices = ((string)before).Split(new string[] { "->" }, StringSplitOptions.RemoveEmptyEntries);
                string fromState = stateVertices[0];
                string toState = stateVertices[1];

                for (int i = 2; i < Table.RowsCount; i++)
                {
                    SourceGrid.Cells.Cell nameCell =
                        (SourceGrid.Cells.Cell)Table[i, 1];

                    if (nameCell.DisplayText == fromState)
                    {
                        for (int k = 0; k < nameCell.RowSpan; k++)
                        {
                            SourceGrid.Cells.Cell nextStateCell =
                                (SourceGrid.Cells.Cell)Table[i + k, 7];

                            if (nextStateCell.DisplayText == toState)
                            {
                                nextStateCell.Value = string.Empty;
                                //state, entry action, input, input action, condition, conditional action, next state
                                SourceGrid.Cells.Cell inputCell =
                                        (SourceGrid.Cells.Cell)Table[i + k, 3];
                                //inputCell.Value = string.Empty;

                                SourceGrid.Cells.Cell inputActionCell =
                                        (SourceGrid.Cells.Cell)Table[i + k, 4];
                                //inputActionCell.Value = string.Empty;

                                SourceGrid.Cells.Cell condCell =
                                        (SourceGrid.Cells.Cell)Table[i + k, 5];
                                condCell.Value = "true";

                                SourceGrid.Cells.Cell condActionCell =
                                        (SourceGrid.Cells.Cell)Table[i + k, 6];
                                condActionCell.Value = string.Empty;

                                //TODO
                                //기존의 input event의 row span이 1 보다 크면 input event는 keep
                                //그렇지 않다면 input event 삭제
                                if (inputCell.RowSpan > 1)
                                {
                                    //simply remove the condition row only
                                    deleteConditionAt(i + k);
                                }

                                if (nameCell.RowSpan == 1)
                                {
                                    deleteStateTransitionAt(i);
                                }
                                else if (nameCell.RowSpan > 1)
                                {
                                    if (inputCell.RowSpan == 1)
                                    {
                                        deleteInputEventAt(i + k);
                                    }
                                }
                                return;
                            }
                        }


                    }
                }
            }
        }

        private void HandleAddedState(OOSGState newState)
        {
            List<string> values = new List<string>();
            foreach (string value in _StateEditor.StandardValues)
            {
                if (!values.Contains(value))
                    values.Add(value);
            }
            values.Add(newState.Name);
            values.Sort();

            _StateEditor.StandardValues = values.ToArray();

            //필요하다면, empty state transition 추가 가능
        }

        private void HandleDeletedState(OOSGState oldState)
        {
            List<string> values = new List<string>();
            foreach (string value in _StateEditor.StandardValues)
            {
                if (!value.Equals(oldState.Name))
                    values.Add(value);
            }
            values.Sort();

            _StateEditor.StandardValues = values.ToArray();
        }

        private void HandleAddedMessage(OOSGMessage newMsg)
        {
            //Add to ComboBox
            List<string> values = new List<string>();
            foreach (string value in _InputEventEditor.StandardValues)
            {
                if (!values.Contains(value))
                    values.Add(value);
            }
            values.Add(newMsg.DisplayName);
            values.Sort();

            _InputEventEditor.StandardValues = values.ToArray();
        }

        private void HandleDeletedMessage(OOSGMessage oldMsg)
        {
            List<string> values = new List<string>();
            foreach (string value in _InputEventEditor.StandardValues)
            {
                if (!value.Equals(oldMsg.DisplayName))
                    values.Add(value);
            }
            values.Sort();

            _InputEventEditor.StandardValues = values.ToArray();

            //message 가 output 인 경우 action 에서 삭제
            if (oldMsg.Type == MessageType.Output)
            {
                for (int k = 2; k < Table.Rows.Count; k += Table[k, 1].RowSpan)
                {
                    if (string.IsNullOrEmpty(Table[k, 1].DisplayText))
                        continue;

                    string stateAction = Table[k, 2].DisplayText;
                    if (!string.IsNullOrEmpty(stateAction))
                    {
                        stateAction = removeOutMsgInAction(stateAction, oldMsg.MName);
                        Table[k, 2].Value = stateAction;
                    }

                    for (int p = 0; p < Table[k, 1].RowSpan; p += Table[k + p, 3].RowSpan)
                    {
                        //Input Event and Input Action
                        string inputEvent = Table[k + p, 3].DisplayText;
                        string inputAction = Table[k + p, 4].DisplayText;
                        if (!string.IsNullOrEmpty(inputAction))
                        {
                            inputAction = removeOutMsgInAction(inputAction, oldMsg.MName);
                            Table[k + p, 4].Value = inputAction;
                        }
                        for (int m = 0; m < Table[k + p, 3].RowSpan; m++)
                        {
                            string transitionCondition = Table[k + p + m, 5].DisplayText;
                            string transitionAction = Table[k + p + m, 6].DisplayText;

                            if (!string.IsNullOrEmpty(transitionAction))
                            {
                                transitionAction = removeOutMsgInAction(transitionAction, oldMsg.MName);
                                Table[k + p + m, 6].Value = transitionAction;
                            }

                            string nextStateName = Table[k + p + m, 7].DisplayText;
                        }
                    }
                }
            }
        }

        private string removeOutMsgInAction(string action, string msgName)
        {
            string pattern = @"\(\s*" + msgName + @"\s*\)\!\s*\;";
            action = System.Text.RegularExpressions.Regex.Replace(action, pattern, "");

            return action;
        }

        private string renameOutMsgInAction(string action, string oldMsgName, string newMsgName)
        {
            string pattern = @"\(\s*" + oldMsgName + @"\s*\)\!\s*\;";
            action = System.Text.RegularExpressions.Regex.Replace(action, pattern, "(" + newMsgName + ")!;");

            return action;
        }

        private void HandleModifiedMessage(OOSGMessage oldMsg, OOSGMessage newMsg)
        {
            if (oldMsg.MName.Equals(newMsg.MName))
            {
                //Type is chaned
                if (oldMsg.Type == MessageType.Output)
                {
                    //Add to ComboBox
                    List<string> values = new List<string>();
                    foreach (string value in _InputEventEditor.StandardValues)
                    {
                        if (!values.Contains(value))
                            values.Add(value);
                    }
                    values.Add(newMsg.DisplayName);
                    values.Sort();

                    _InputEventEditor.StandardValues = values.ToArray();

                    //message 가 output 인 경우 action 에서 삭제
                    if (oldMsg.Type == MessageType.Output)
                    {
                        for (int k = 2; k < Table.Rows.Count; k += Table[k, 1].RowSpan)
                        {
                            if (string.IsNullOrEmpty(Table[k, 1].DisplayText))
                                continue;

                            string stateAction = Table[k, 2].DisplayText;
                            if (!string.IsNullOrEmpty(stateAction))
                            {
                                stateAction = removeOutMsgInAction(stateAction, oldMsg.MName);
                                Table[k, 2].Value = stateAction;
                            }

                            for (int p = 0; p < Table[k, 1].RowSpan; p += Table[k + p, 3].RowSpan)
                            {
                                //Input Event and Input Action
                                string inputEvent = Table[k + p, 3].DisplayText;
                                string inputAction = Table[k + p, 4].DisplayText;
                                if (!string.IsNullOrEmpty(inputAction))
                                {
                                    inputAction = removeOutMsgInAction(inputAction, oldMsg.MName);
                                    Table[k + p, 4].Value = inputAction;
                                }
                                for (int m = 0; m < Table[k + p, 3].RowSpan; m++)
                                {
                                    string transitionCondition = Table[k + p + m, 5].DisplayText;
                                    string transitionAction = Table[k + p + m, 6].DisplayText;

                                    if (!string.IsNullOrEmpty(transitionAction))
                                    {
                                        transitionAction = removeOutMsgInAction(transitionAction, oldMsg.MName);
                                        Table[k + p + m, 6].Value = transitionAction;
                                    }

                                    string nextStateName = Table[k + p + m, 7].DisplayText;

                                }
                            }
                        }
                    }
                }
                else
                {
                    //Remove from the ComboBox
                    List<string> values = new List<string>();
                    foreach (string value in _InputEventEditor.StandardValues)
                    {
                        if (!value.Equals(oldMsg.DisplayName))
                            values.Add(value);
                    }
                    values.Sort();

                    _InputEventEditor.StandardValues = values.ToArray();
                }
            }
            else
            {
                //Name is changed
                List<string> values = new List<string>();
                foreach (string value in _InputEventEditor.StandardValues)
                {
                    if (!value.Equals(oldMsg.DisplayName) && !values.Contains(value))
                        values.Add(value);
                }

                values.Add(newMsg.DisplayName);
                values.Sort();

                _InputEventEditor.StandardValues = values.ToArray();

                string mName = oldMsg.DisplayName;
                for (int k = 2; k < Table.Rows.Count; k++)
                {
                    if (mName.Equals(Table[k, 3].DisplayText))
                    {
                        Table[k, 3].Value = newMsg.DisplayName;
                    }
                }

                //message name 을 action 에서 변경
                if (oldMsg.Type == MessageType.Output)
                {
                    for (int k = 2; k < Table.Rows.Count; k += Table[k, 1].RowSpan)
                    {
                        if (string.IsNullOrEmpty(Table[k, 1].DisplayText))
                            continue;

                        string stateAction = Table[k, 2].DisplayText;
                        if (!string.IsNullOrEmpty(stateAction))
                        {
                            stateAction = renameOutMsgInAction(stateAction, oldMsg.MName, newMsg.MName);
                            Table[k, 2].Value = stateAction;
                        }

                        for (int p = 0; p < Table[k, 1].RowSpan; p += Table[k + p, 3].RowSpan)
                        {
                            //Input Event and Input Action
                            string inputEvent = Table[k + p, 3].DisplayText;
                            string inputAction = Table[k + p, 4].DisplayText;
                            if (!string.IsNullOrEmpty(inputAction))
                            {
                                inputAction = renameOutMsgInAction(inputAction, oldMsg.MName, newMsg.MName);
                                Table[k + p, 4].Value = inputAction;
                            }
                            for (int m = 0; m < Table[k + p, 3].RowSpan; m++)
                            {
                                string transitionCondition = Table[k + p + m, 5].DisplayText;
                                string transitionAction = Table[k + p + m, 6].DisplayText;

                                if (!string.IsNullOrEmpty(transitionAction))
                                {
                                    transitionAction = renameOutMsgInAction(transitionAction, oldMsg.MName, newMsg.MName);
                                    Table[k + p + m, 6].Value = transitionAction;
                                }

                                string nextStateName = Table[k + p + m, 7].DisplayText;

                            }
                        }
                    }
                }
            }
        }

        private void HandleModifiedState(string oldName, string newName)
        {
            if (!oldName.Equals(newName))
            {
                //Name is changed
                List<string> values = new List<string>();
                foreach (string value in _StateEditor.StandardValues)
                {
                    if (!value.Equals(oldName) && !values.Contains(value))
                        values.Add(value);
                }
                if (!values.Contains(newName))
                    values.Add(newName);
                values.Sort();

                _StateEditor.StandardValues = values.ToArray();

                string sName = oldName;
                for (int k = 2; k < Table.Rows.Count; k++)
                {
                    if (sName.Equals(Table[k, 1].DisplayText))
                    {
                        Table[k, 1].Value = newName;
                    }

                    if (sName.Equals(Table[k, 7].DisplayText))
                    {
                        Table[k, 7].Value = newName;
                    }
                }
            }
        }

        private void HandleModifiedState(OOSGState oldState, OOSGState newState)
        {
            if (!oldState.Name.Equals(newState.Name))
            {
                //Name is changed
                List<string> values = new List<string>();
                foreach (string value in _StateEditor.StandardValues)
                {
                    if (!value.Equals(oldState.Name) && !values.Contains(value))
                        values.Add(value);
                }
                if (!values.Contains(newState.Name))
                    values.Add(newState.Name);
                values.Sort();

                _StateEditor.StandardValues = values.ToArray();

                string sName = oldState.Name;
                for (int k = 2; k < Table.Rows.Count; k++)
                {
                    if (sName.Equals(Table[k, 1].DisplayText))
                    {
                        Table[k, 1].Value = newState.Name;
                    }

                    if (sName.Equals(Table[k, 7].DisplayText))
                    {
                        Table[k, 7].Value = newState.Name;
                    }
                }
            }

            string newEntryAction = newState.EntryAction == null ? "" : newState.EntryAction;
            string oldEntryAction = oldState.EntryAction == null ? "" : oldState.EntryAction;
            if (!newEntryAction.Equals(oldEntryAction))
            {
                //Entry Action is Changed
                for (int k = 2; k < Table.Rows.Count; k += Table[k, 1].RowSpan)
                {
                    if (oldState.Name.Equals(Table[k, 1].DisplayText))
                    {
                        Table[k, 2].Value = newState.EntryAction;
                        break;
                    }
                }
            }

            string newDeltaName = newState.Delay == null ? "" : newState.Delay.DeltaName;
            string oldDeltaName = oldState.Delay == null ? "" : oldState.Delay.DeltaName;
            if (!newDeltaName.Equals(oldDeltaName))
            {
                //Old Value 지우고, 신규 추가

                List<string> values = new List<string>();
                foreach (string value in _InputEventEditor.StandardValues)
                {
                    values.Add(value);
                }
                if (values.Contains(oldDeltaName))
                    values.Remove(oldDeltaName);
                if (!values.Contains(newDeltaName) && newDeltaName != "delta[]")
                    values.Add(newDeltaName);

                values.Sort();

                _InputEventEditor.StandardValues = values.ToArray();

                bool found = false;
                for (int k = 2; k < Table.Rows.Count; k += Table[k, 1].RowSpan)
                {
                    if (oldState.Name.Equals(Table[k, 1].DisplayText))
                    {
                        Table[k, 2].Value = newState.EntryAction;

                        for (int p = 0; p < Table[k, 1].RowSpan; p += Table[k + p, 3].RowSpan)
                        {
                            if (Table[k + p, 3].DisplayText.Equals(oldState.Delay.DeltaName))
                            {
                                Table[k + p, 3].Value = newState.Delay.DeltaName;
                                found = true;
                                break;
                            }
                        }

                        if (found)
                            break;
                    }
                }
            }

            if (!oldState.Type.Equals(newState.Type))
            {
                //대안 1:
                //Table --> TEFSMModel 로, Update(TEFSMModel)
                UpdateStateTransitions();
                //대안 2:
                //바로 row를 이동
                //for (int k = 2; k < Table.Rows.Count; k += Table[k, 1].RowSpan)
                //{
                //    if (oldState.SName.Equals(Table[k, 1].DisplayText))
                //    {
                //        Table[k, 2].Value = newState.EntryAction;

                //        Table.Rows.Move(


                //        break;
                //    }
                //}
            }
            ///TODO
            ///1. State Type 변경에 따른 순서 변경 필요함
        }

        private void Clear()
        {
            while (Table.Rows.Count > 2)
                Table.Rows.Remove(2);
        }

        private SortedList<string, List<OOSGStateTransition>> GroupTransitionsByStates(List<OOSGStateTransition> stateTransitions)
        {
            SortedList<string, List<OOSGStateTransition>> states =
               new SortedList<string, List<OOSGStateTransition>>();

            //State 별 transition 묶음
            foreach (OOSGStateTransition st in stateTransitions)
            {
                if (states.ContainsKey(st.CurrentState.Name))
                {
                    List<OOSGStateTransition> transitions = states[st.CurrentState.Name];
                    transitions.Add(st);
                    states[st.CurrentState.Name] = transitions;
                }
                else
                {
                    List<OOSGStateTransition> transitions = new List<OOSGStateTransition>();
                    transitions.Add(st);

                    states.Add(st.CurrentState.Name, transitions);
                }
            }

            return states;
        }

        private void UpdateStateTransitions()
        {
            //1. Table --> Models
            List<OOSGStateTransition> stateTransitions = this.StateTransitions;
            if (stateTransitions.Count == 0)
                return;

            ///////////////////////////////////////////////////////////////
            //2. Clear State Transitions from the table
            Clear();

            ///////////////////////////////////////////////////////////////
            //3. Models --> Table
            SortedList<string, List<OOSGStateTransition>> states =
               new SortedList<string, List<OOSGStateTransition>>();

            foreach (OOSGStateTransition st in stateTransitions)
            {
                if (states.ContainsKey(st.CurrentState.Name))
                {
                    List<OOSGStateTransition> transitions = states[st.CurrentState.Name];
                    transitions.Add(st);
                    states[st.CurrentState.Name] = transitions;
                }
                else
                {
                    List<OOSGStateTransition> transitions = new List<OOSGStateTransition>();
                    transitions.Add(st);

                    states.Add(st.CurrentState.Name, transitions);
                }
            }

            //Initial State
            string initialStateName = string.Empty;
            if (_AMControl.InitialState != null)
            {
                initialStateName = _AMControl.InitialState.Name;
                if (!string.IsNullOrEmpty(initialStateName) && states.ContainsKey(initialStateName))
                    InsertStateTransitions(initialStateName, states[initialStateName]);
            }

            //Regular/Final States
            List<string> stateNames = new List<string>();
            foreach (OOSGState state in _AMControl.States)
                stateNames.Add(state.Name);
            stateNames.Sort();

            foreach (string sName in stateNames)
            {
                if (sName.Equals(initialStateName) || !states.ContainsKey(sName))
                    continue;

                InsertStateTransitions(sName, states[sName]);
            }

            Table.AutoStretchColumnsToFitWidth = false;
            Table.AutoStretchRowsToFitHeight = false;
            Table.AutoSizeCells();
        }

        public void Update(OOSGStateObjectModel am)
        //public void Update(AtomicModel am)
        {
            _IsUpdating = true;
            SortedList<string, List<OOSGStateTransition>> states =
                new SortedList<string, List<OOSGStateTransition>>();

            //State 별 transition 묶음
            string initialStateName = string.Empty;
            foreach (OOSGStateTransition st in am.STT)
            {
                if (st.CurrentState.Type == StateType.Initial)
                    initialStateName = st.CurrentState.Name;

                if (states.ContainsKey(st.CurrentState.Name))
                {
                    List<OOSGStateTransition> transitions = states[st.CurrentState.Name];
                    transitions.Add(st);
                    states[st.CurrentState.Name] = transitions;
                }
                else
                {
                    List<OOSGStateTransition> transitions = new List<OOSGStateTransition>();
                    transitions.Add(st);

                    states.Add(st.CurrentState.Name, transitions);
                }
            }

            //Initial State
            if (!string.IsNullOrEmpty(initialStateName))
                InsertStateTransitions(initialStateName, states[initialStateName]);

            //Regular/Final States
            List<string> stateNames = (from s in am.States select s.Name).ToList<string>();//..ToList<string>();
            stateNames.Sort();

            ////State Combo Editor
            _StateEditor.StandardValues = stateNames.ToArray();
            ////InputEvent Combo Editor
            List<string> inputEvents = new List<string>();
            foreach (OOSGMessage msg in am.InputMesssages)
                inputEvents.Add(msg.DisplayName);

            foreach (OOSGState state in am.States)
            {
                if (state.Delay != null && !string.IsNullOrEmpty(state.Delay.Name))
                    inputEvents.Add(state.Delay.DeltaName);
            }

            inputEvents.Sort();
            _InputEventEditor.StandardValues = inputEvents.ToArray();

            foreach (string sName in stateNames)
            {
                if (sName.Equals(initialStateName) || !states.ContainsKey(sName))
                    continue;

                InsertStateTransitions(sName, states[sName]);
            }

            Table.AutoStretchColumnsToFitWidth = false;
            Table.AutoStretchRowsToFitHeight = false;
            Table.AutoSizeCells();

            enableToolbars();
            _IsUpdating = false;
        }

        private void InsertStateTransitions(string sName, List<OOSGStateTransition> transitions)
        {
            int rowIndex = Table.RowsCount;// -1;
            Table.Rows.InsertRange(rowIndex, transitions.Count);

            //Views
            SourceGrid.Cells.Views.Cell defaultView = new SourceGrid.Cells.Views.Cell();
            defaultView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.Views.Cell topView = new SourceGrid.Cells.Views.Cell();
            topView.TextAlignment = DevAge.Drawing.ContentAlignment.TopLeft;

            SourceGrid.Cells.Views.Cell conditionView = new SourceGrid.Cells.Views.Cell();
            conditionView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            SourceGrid.Cells.Views.ComboBox comboView = new SourceGrid.Cells.Views.ComboBox();
            comboView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.Views.ComboBox comboTopView = new SourceGrid.Cells.Views.ComboBox();
            comboTopView.TextAlignment = DevAge.Drawing.ContentAlignment.TopLeft;

            //Zero Column
            //대안 1: 전체가 rowspan 으로 설정
            //Table[rowIndex, 0] = new SourceGrid.Cells.RowHeader(null);
            //Table[rowIndex, 0].RowSpan = transitions.Count;
            //대안 2: 개별 row 설정
            for (int i = 0; i < transitions.Count; i++)
            {
                Table[rowIndex + i, 0] = new SourceGrid.Cells.RowHeader(null);
            }

            //Name Column
            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(sName, _StateEditor);
            nameCell.View = topView;
            //nameCell.View = SourceGrid.Cells.Views.ComboBox.Default;
            nameCell.RowSpan = transitions.Count;
            nameCell.AddController(_StateValueChangeController);
            Table[rowIndex, 1] = nameCell;
            nameCell.AddController(_CellValueChangedEventController);
            nameCell.AddController(_ValueChangeController);

            //State Action Column 
            SourceGrid.Cells.Cell stateActionCell = new SourceGrid.Cells.Cell(transitions[0].EntryAction, typeof(string));
            stateActionCell.View = topView;
            stateActionCell.RowSpan = transitions.Count;
            ActionEditorDialog actionEditor1 = new ActionEditorDialog();
            stateActionCell.Editor = actionEditor1;
            Table[rowIndex, 2] = stateActionCell;
            stateActionCell.AddController(_CellValueChangedEventController);
            stateActionCell.AddController(_ValueChangeController);

            //Group State Transitions by Input Event (Same)
            SortedList<string, List<OOSGStateTransition>> transitionByInputEvent =
                new SortedList<string, List<OOSGStateTransition>>();

            foreach (OOSGStateTransition st in transitions)
            {
                if (transitionByInputEvent.ContainsKey(st.InputOrDelay))
                {
                    List<OOSGStateTransition> ts = transitionByInputEvent[st.InputOrDelay];
                    ts.Add(st);
                    transitionByInputEvent[st.InputOrDelay] = ts;
                }
                else
                {
                    List<OOSGStateTransition> ts = new List<OOSGStateTransition>();
                    ts.Add(st);
                    transitionByInputEvent.Add(st.InputOrDelay, ts);
                }
            }

            List<string> inputEvents = transitionByInputEvent.Keys.ToList<string>();
            inputEvents.Sort();

            int rowIndex2 = rowIndex;
            foreach (string inputEvent in inputEvents)
            {
                List<OOSGStateTransition> tset = transitionByInputEvent[inputEvent];
                if (string.IsNullOrEmpty(inputEvent))
                {
                    foreach (OOSGStateTransition st in tset)
                    {
                        //Input Event Column
                        SourceGrid.Cells.Cell inputEventCell = new SourceGrid.Cells.Cell(st.InputOrDelay, _InputEventEditor);
                        //SourceGrid.Cells.Cell inputEventCell = new SourceGrid.Cells.Cell(tset[0].InputOrDelay, typeof(string));
                        inputEventCell.View = topView;
                        Table[rowIndex2, 3] = inputEventCell;
                        inputEventCell.AddController(_CellValueChangedEventController);
                        inputEventCell.AddController(_ValueChangeController);

                        //Input Action Column
                        SourceGrid.Cells.Cell inputActionCell = new SourceGrid.Cells.Cell(st.InputAction, typeof(string));
                        inputActionCell.View = topView;
                        ActionEditorDialog actionEditor2 = new ActionEditorDialog();
                        inputActionCell.Editor = actionEditor2;
                        Table[rowIndex2, 4] = inputActionCell;
                        inputActionCell.AddController(_CellValueChangedEventController);
                        inputActionCell.AddController(_ValueChangeController);

                        //Transition Condition Column
                        SourceGrid.Cells.Cell transitionConditionCell = new SourceGrid.Cells.Cell(st.Condition, typeof(string));
                        transitionConditionCell.View = conditionView;
                        Table[rowIndex2, 5] = transitionConditionCell;
                        transitionConditionCell.AddController(_CellValueChangedEventController);
                        transitionConditionCell.AddController(_ValueChangeController);

                        //Transition Action Column
                        SourceGrid.Cells.Cell transitionActionCell = new SourceGrid.Cells.Cell(st.TransitionAction, typeof(string));
                        transitionActionCell.View = defaultView;
                        ActionEditorDialog actionEditor3 = new ActionEditorDialog();
                        transitionActionCell.Editor = actionEditor3;
                        Table[rowIndex2, 6] = transitionActionCell;
                        transitionActionCell.AddController(_CellValueChangedEventController);
                        transitionActionCell.AddController(_ValueChangeController);

                        //Next State Column
                        SourceGrid.Cells.Cell nextStateCell = new SourceGrid.Cells.Cell(st.NextState.Name, _StateEditor);
                        //SourceGrid.Cells.Cell nextStateCell = new SourceGrid.Cells.Cell(st.NextState.SName, typeof(string));
                        //nextStateCell.View = defaultView;
                        nextStateCell.View = defaultView;
                        Table[rowIndex2, 7] = nextStateCell;
                        nextStateCell.AddController(_CellValueChangedEventController);
                        nextStateCell.AddController(_NextStateValueChangeController);
                        nextStateCell.AddController(_ValueChangeController);

                        rowIndex2++;
                    }
                }
                else
                {
                    //Input Event Column
                    SourceGrid.Cells.Cell inputEventCell = new SourceGrid.Cells.Cell(tset[0].InputOrDelay, _InputEventEditor);
                    //SourceGrid.Cells.Cell inputEventCell = new SourceGrid.Cells.Cell(tset[0].InputOrDelay, typeof(string));
                    inputEventCell.View = topView;
                    inputEventCell.RowSpan = tset.Count;
                    Table[rowIndex2, 3] = inputEventCell;
                    inputEventCell.AddController(_CellValueChangedEventController);
                    inputEventCell.AddController(_ValueChangeController);

                    //Input Action Column
                    SourceGrid.Cells.Cell inputActionCell = new SourceGrid.Cells.Cell(tset[0].InputAction, typeof(string));
                    inputActionCell.View = topView;
                    inputActionCell.RowSpan = tset.Count;
                    ActionEditorDialog actionEditor2 = new ActionEditorDialog();
                    inputActionCell.Editor = actionEditor2;
                    Table[rowIndex2, 4] = inputActionCell;
                    inputActionCell.AddController(_CellValueChangedEventController);
                    inputActionCell.AddController(_ValueChangeController);

                    //Transition
                    foreach (OOSGStateTransition st in tset)
                    {
                        //Transition Condition Column
                        SourceGrid.Cells.Cell transitionConditionCell = new SourceGrid.Cells.Cell(st.Condition, typeof(string));
                        transitionConditionCell.View = conditionView;
                        Table[rowIndex2, 5] = transitionConditionCell;
                        transitionConditionCell.AddController(_CellValueChangedEventController);
                        transitionConditionCell.AddController(_ValueChangeController);

                        //Transition Action Column
                        SourceGrid.Cells.Cell transitionActionCell = new SourceGrid.Cells.Cell(st.TransitionAction, typeof(string));
                        transitionActionCell.View = defaultView;
                        ActionEditorDialog actionEditor3 = new ActionEditorDialog();
                        transitionActionCell.Editor = actionEditor3;
                        Table[rowIndex2, 6] = transitionActionCell;
                        transitionActionCell.AddController(_CellValueChangedEventController);
                        transitionActionCell.AddController(_ValueChangeController);

                        //Next State Column
                        SourceGrid.Cells.Cell nextStateCell = new SourceGrid.Cells.Cell(st.NextState.Name, _StateEditor);
                        //SourceGrid.Cells.Cell nextStateCell = new SourceGrid.Cells.Cell(st.NextState.SName, typeof(string));
                        //nextStateCell.View = defaultView;
                        nextStateCell.View = defaultView;
                        Table[rowIndex2, 7] = nextStateCell;
                        nextStateCell.AddController(_CellValueChangedEventController);
                        nextStateCell.AddController(_NextStateValueChangeController);
                        nextStateCell.AddController(_ValueChangeController);

                        rowIndex2++;
                    }
                }
            }
        }

        /// <summary>
        /// No more used.
        /// </summary>
        /// <param name="st"></param>
        private void InsertStateTransiiton(OOSGStateTransition st)
        {
            int rowIndex = Table.RowsCount;// -1;
            Table.Rows.Insert(rowIndex);

            SourceGrid.Cells.Views.Cell defaultView = new SourceGrid.Cells.Views.Cell();
            defaultView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.Views.Cell centerView = new SourceGrid.Cells.Views.Cell();
            centerView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
            SourceGrid.Cells.Views.Cell topView = new SourceGrid.Cells.Views.Cell();
            topView.TextAlignment = DevAge.Drawing.ContentAlignment.TopLeft;

            Table[rowIndex, 0] = new SourceGrid.Cells.RowHeader(null);

            //Name Column
            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(st.CurrentState.Name, typeof(string));
            nameCell.View = topView;
            nameCell.AddController(_StateValueChangeController);
            nameCell.AddController(_ValueChangeController);
            Table[rowIndex, 1] = nameCell;

            //State Action Column
            SourceGrid.Cells.Cell stateActionCell = new SourceGrid.Cells.Cell(st.EntryAction, typeof(string));
            stateActionCell.View = topView;
            ActionEditorDialog actionEditor1 = new ActionEditorDialog();
            stateActionCell.Editor = actionEditor1;
            stateActionCell.AddController(_ValueChangeController);
            Table[rowIndex, 2] = stateActionCell;

            //Input Event Column
            SourceGrid.Cells.Cell inputEventCell = new SourceGrid.Cells.Cell(st.InputOrDelay, typeof(string));
            inputEventCell.View = topView;
            inputEventCell.AddController(_ValueChangeController);
            Table[rowIndex, 3] = inputEventCell;

            //Input Action Column
            SourceGrid.Cells.Cell inputActionCell = new SourceGrid.Cells.Cell(st.InputAction, typeof(string));
            inputActionCell.View = topView;
            ActionEditorDialog actionEditor2 = new ActionEditorDialog();
            inputActionCell.Editor = actionEditor2;
            inputActionCell.AddController(_ValueChangeController);
            Table[rowIndex, 4] = inputActionCell;

            //Transition Condition Column
            SourceGrid.Cells.Cell transitionConditionCell = new SourceGrid.Cells.Cell(st.Condition, typeof(string));
            transitionConditionCell.View = centerView;
            transitionConditionCell.AddController(_ValueChangeController);
            Table[rowIndex, 5] = transitionConditionCell;

            //Transition Action Column
            SourceGrid.Cells.Cell transitionActionCell = new SourceGrid.Cells.Cell(st.TransitionAction, typeof(string));
            transitionActionCell.View = defaultView;
            ActionEditorDialog actionEditor3 = new ActionEditorDialog();
            transitionActionCell.Editor = actionEditor3;
            transitionActionCell.AddController(_ValueChangeController);

            Table[rowIndex, 6] = transitionActionCell;

            //Next State Column
            SourceGrid.Cells.Cell nextStateCell = new SourceGrid.Cells.Cell(st.NextState.Name, typeof(string));
            nextStateCell.View = defaultView;
            nextStateCell.AddController(_ValueChangeController);
            nextStateCell.AddController(_NextStateValueChangeController);

            Table[rowIndex, 7] = nextStateCell;
        }

        private void InsertEmptyStateTransition()
        {
            int rowIndex = Table.RowsCount;// -1;

            if (rowIndex == 2)
                enableToolbars();

            Table.Rows.Insert(rowIndex);

            SourceGrid.Cells.Views.ComboBox comboView = new SourceGrid.Cells.Views.ComboBox();
            comboView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.Views.ComboBox comboTopView = new SourceGrid.Cells.Views.ComboBox();
            comboTopView.TextAlignment = DevAge.Drawing.ContentAlignment.TopLeft;

            SourceGrid.Cells.Views.Cell defaultView = new SourceGrid.Cells.Views.Cell();
            defaultView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            SourceGrid.Cells.Views.Cell topView = new SourceGrid.Cells.Views.Cell();
            topView.TextAlignment = DevAge.Drawing.ContentAlignment.TopLeft;

            SourceGrid.Cells.Views.Cell conditionView = new SourceGrid.Cells.Views.Cell();
            conditionView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;


            Table[rowIndex, 0] = new SourceGrid.Cells.RowHeader(null);

            //Name Column
            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell("", _StateEditor);
            nameCell.View = topView;
            nameCell.AddController(_StateValueChangeController);
            nameCell.AddController(_CellValueChangedEventController);
            nameCell.AddController(_ValueChangeController);
            Table[rowIndex, 1] = nameCell;

            //State Action Column
            SourceGrid.Cells.Cell stateActionCell = new SourceGrid.Cells.Cell("", typeof(string));
            stateActionCell.View = topView;
            ActionEditorDialog actionEditor1 = new ActionEditorDialog();
            stateActionCell.Editor = actionEditor1;
            Table[rowIndex, 2] = stateActionCell;
            stateActionCell.AddController(_CellValueChangedEventController);
            stateActionCell.AddController(_ValueChangeController);

            //Input Event Column
            SourceGrid.Cells.Cell inputEventCell = new SourceGrid.Cells.Cell("", _InputEventEditor);
            inputEventCell.View = topView;
            Table[rowIndex, 3] = inputEventCell;
            inputEventCell.AddController(_CellValueChangedEventController);
            inputEventCell.AddController(_ValueChangeController);

            //Input Action Column
            SourceGrid.Cells.Cell inputActionCell = new SourceGrid.Cells.Cell("", typeof(string));
            inputActionCell.View = topView;
            ActionEditorDialog actionEditor2 = new ActionEditorDialog();
            inputActionCell.Editor = actionEditor2;
            Table[rowIndex, 4] = inputActionCell;
            inputActionCell.AddController(_CellValueChangedEventController);
            inputActionCell.AddController(_ValueChangeController);

            //Transition Condition Column
            SourceGrid.Cells.Cell transitionConditionCell = new SourceGrid.Cells.Cell("true", typeof(string));
            transitionConditionCell.View = conditionView;
            Table[rowIndex, 5] = transitionConditionCell;
            transitionConditionCell.AddController(_CellValueChangedEventController);
            transitionConditionCell.AddController(_ValueChangeController);

            //Transition Action Column
            SourceGrid.Cells.Cell transitionActionCell = new SourceGrid.Cells.Cell("", typeof(string));
            transitionActionCell.View = defaultView;
            ActionEditorDialog actionEditor3 = new ActionEditorDialog();
            transitionActionCell.Editor = actionEditor3;
            Table[rowIndex, 6] = transitionActionCell;
            transitionActionCell.AddController(_CellValueChangedEventController);
            transitionActionCell.AddController(_ValueChangeController);

            //Next State Column
            SourceGrid.Cells.Cell nextStateCell = new SourceGrid.Cells.Cell("", _StateEditor);
            nextStateCell.View = defaultView;
            Table[rowIndex, 7] = nextStateCell;
            nextStateCell.AddController(_CellValueChangedEventController);
            nextStateCell.AddController(_NextStateValueChangeController);
            nextStateCell.AddController(_ValueChangeController);

            Table.Font = new Font(Table.Font.FontFamily, Table.Font.Size);
        }

        #region Toolbar Event Handlers
        private void Table_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            SourceGrid.Position p = Table.PositionAtPoint(e.Location);
            if (p.IsEmpty())
            {
                InsertEmptyStateTransition();
            }
        }

        private void tsbInsert_Click(object sender, EventArgs e)
        {
            InsertEmptyStateTransition();


            if (Changed != null && Changed.GetInvocationList().Length > 0)
                Changed(ChangedTarget.Transition, ChangedType.Added, null, null);

        }

        private void tsbDelete_Click(object sender, EventArgs e)
        {
            //Current Cursor 의 위치에 따라 삭제 가능할 것.... 아닌가?
            //우선 현재 transition 만 
            int sRow = Table.Selection.ActivePosition.Row;
            deleteStateTransitionAt(sRow);
        }

        //delete all the state transitions from a state
        private void deleteStateTransitionAt(int sRow)
        {
            if (sRow < 2 || Table[sRow, 0] == null)
                return;

            List<OOSGStateTransition> transitionList = getStateTransitionsAt(sRow);
            if (Table[sRow, 1].RowSpan > 1)
            {
                int count = Table[sRow, 1].RowSpan;
                for (int k = 0; k < count; k++)
                    Table.Rows.Remove(sRow);
            }
            else
            {
                Table.Rows.Remove(sRow);
            }

            if (Table.Rows.Count == 2)
            {
                disableToolbars();
            }

            if (Changed != null && Changed.GetInvocationList().Length > 0)
                Changed(ChangedTarget.Transition, ChangedType.Deleted, transitionList, null);
        }

        private void disableToolbars()
        {
            tsbDelete.Enabled = false;
            tsbInsertInputEvent.Enabled = false;
            tsbDeleteInputEvent.Enabled = false;
            tsbInsertCondition.Enabled = false;
            tsbDeleteCondition.Enabled = false;
            tsbAutoCellSize.Enabled = false;
            tsbCopy.Enabled = false;
        }

        private void enableToolbars()
        {
            tsbDelete.Enabled = true;
            tsbInsertInputEvent.Enabled = true;
            tsbDeleteInputEvent.Enabled = true;
            tsbInsertCondition.Enabled = true;
            tsbDeleteCondition.Enabled = true;
            tsbAutoCellSize.Enabled = true;
            tsbCopy.Enabled = true;
        }


        private void tsbInsertInputEvent_Click(object sender, EventArgs e)
        {
            int sRow = Table.Selection.ActivePosition.Row;

            InsertInputEventAt(sRow, string.Empty);
        }

        private void InsertInputEventAt(int sRow, string nextState)
        {
            if (sRow < 2)
                return;

            int startRow1 = Table[sRow, 1].Range.Start.Row;
            int startRow3 = Table[sRow, 3].Range.Start.Row;
            int rowIndex = startRow3 + Table[startRow3, 3].RowSpan;
            int rowSpan1 = Table[startRow1, 1].RowSpan;
            //int rowIndex = sRow + Table[sRow, 3].RowSpan;

            //bool noRowSpan = false;
            //if (rowIndex < startRow1 + Table[startRow1, 1].RowSpan)
            //    noRowSpan = true;

            Table.Rows.Insert(rowIndex);

            try
            {
                Table[sRow, 1].RowSpan = rowSpan1 + 1;
                Table[sRow, 2].RowSpan = rowSpan1 + 1;
            }
            catch (Exception ex) { }

            SourceGrid.Cells.Views.Cell defaultView = new SourceGrid.Cells.Views.Cell();
            defaultView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.Views.Cell centerView = new SourceGrid.Cells.Views.Cell();
            centerView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
            SourceGrid.Cells.Views.Cell topView = new SourceGrid.Cells.Views.Cell();
            topView.TextAlignment = DevAge.Drawing.ContentAlignment.TopLeft;
            SourceGrid.Cells.Views.ComboBox comboView = new SourceGrid.Cells.Views.ComboBox();
            comboView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.Views.ComboBox comboTopView = new SourceGrid.Cells.Views.ComboBox();
            comboTopView.TextAlignment = DevAge.Drawing.ContentAlignment.TopLeft;

            Table[rowIndex, 0] = new SourceGrid.Cells.RowHeader(null);


            //Input Event Column
            SourceGrid.Cells.Cell inputEventCell = new SourceGrid.Cells.Cell("", _InputEventEditor);
            inputEventCell.View = topView;
            Table[rowIndex, 3] = inputEventCell;
            inputEventCell.AddController(_CellValueChangedEventController);
            inputEventCell.AddController(_ValueChangeController);

            //Input Action Column
            SourceGrid.Cells.Cell inputActionCell = new SourceGrid.Cells.Cell("", typeof(string));
            inputActionCell.View = topView;
            ActionEditorDialog actionEditor2 = new ActionEditorDialog();
            inputActionCell.Editor = actionEditor2;
            Table[rowIndex, 4] = inputActionCell;

            inputActionCell.AddController(_ValueChangeController);
            inputActionCell.AddController(_CellValueChangedEventController);

            //Transition Condition Column
            SourceGrid.Cells.Cell transitionConditionCell = new SourceGrid.Cells.Cell("true", typeof(string));
            transitionConditionCell.View = centerView;
            Table[rowIndex, 5] = transitionConditionCell;
            transitionConditionCell.AddController(_CellValueChangedEventController);
            transitionConditionCell.AddController(_ValueChangeController);

            //Transition Action Column
            SourceGrid.Cells.Cell transitionActionCell = new SourceGrid.Cells.Cell("", typeof(string));
            transitionActionCell.View = defaultView;
            ActionEditorDialog actionEditor3 = new ActionEditorDialog();
            transitionActionCell.Editor = actionEditor3;
            Table[rowIndex, 6] = transitionActionCell;
            transitionActionCell.AddController(_CellValueChangedEventController);
            transitionActionCell.AddController(_ValueChangeController);

            //Next State Column
            SourceGrid.Cells.Cell nextStateCell = new SourceGrid.Cells.Cell(nextState, _StateEditor);
            nextStateCell.View = defaultView;
            Table[rowIndex, 7] = nextStateCell;
            nextStateCell.AddController(_CellValueChangedEventController);
            nextStateCell.AddController(_ValueChangeController);
            nextStateCell.AddController(_NextStateValueChangeController);

            if (Changed != null && Changed.GetInvocationList().Length > 0)
                Changed(ChangedTarget.Transition, ChangedType.Added, null, null);
        }

        private void DeleteInputEvent_Click(object sender, EventArgs e)
        {
            int sRow = Table.Selection.ActivePosition.Row;

            deleteInputEventAt(sRow);
        }

        private void deleteInputEventAt(int sRow)
        {
            if (sRow < 2)//|| Table.Selection.ActivePosition.Column < 3)
                return;
            //if (sRow < 2 || Table[sRow, 0] == null)
            //    return;

            List<OOSGState> rawStateList = _AMControl.States;
            SortedList<string, OOSGState> stateList = new SortedList<string, OOSGState>();
            foreach (OOSGState state in rawStateList)
                stateList.Add(state.Name, state);

            List<OOSGStateTransition> transitionList = new List<OOSGStateTransition>();

            //Input Event Columns
            int startRow = Table[sRow, 3].Range.Start.Row;
            int endRow = Table[sRow, 3].Range.End.Row;
            int count = endRow - startRow + 1;

            //State Columns
            if (Table[sRow, 1].RowSpan > count)
            {
                int sr = Table[sRow, 1].Range.Start.Row;
                int er = Table[sRow, 1].Range.End.Row;
                int rs = Table[sr, 1].RowSpan;

                OOSGState currentState = null;
                string stateAction = string.Empty;

                SourceGrid.Cells.Cell nameCell = null;
                SourceGrid.Cells.Cell stateActionCell = null;
                if (sr == startRow)
                {
                    nameCell = (SourceGrid.Cells.Cell)Table[sr, 1];
                    currentState = stateList[Table[sr, 1].DisplayText];

                    nameCell.UnBindToGrid();
                    stateActionCell = (SourceGrid.Cells.Cell)Table[sr, 2];
                    stateAction = Table[sr, 2].DisplayText;
                    stateActionCell.UnBindToGrid();
                }
                else
                {
                    nameCell = (SourceGrid.Cells.Cell)Table[sr, 1];
                    currentState = stateList[Table[sr, 1].DisplayText];
                    stateActionCell = (SourceGrid.Cells.Cell)Table[sr, 2];
                    stateAction = Table[sr, 2].DisplayText;
                }

                for (int k = 0; k < count; k++)
                {
                    string inputEvent = Table[startRow, 3].DisplayText;
                    string inputAction = Table[startRow, 4].DisplayText;
                    string transitionCondition = Table[startRow, 5].DisplayText;
                    string transitionAction = Table[startRow, 6].DisplayText;
                    string nextStateName = Table[startRow, 7].DisplayText;

                    if (string.IsNullOrEmpty(nextStateName))
                        continue;

                    if (!stateList.ContainsKey(nextStateName))
                        continue;
                    OOSGState nextState = stateList[nextStateName];
                    OOSGStateTransition st = new OOSGStateTransition(currentState, stateAction, inputEvent, inputAction, transitionCondition, transitionAction, nextState);
                    transitionList.Add(st);
                    Table.Rows.Remove(startRow);
                }
                if (sr == startRow)
                {
                    nameCell.RowSpan = rs - count;
                    stateActionCell.RowSpan = rs - count;
                    Table[sr, 1] = nameCell;
                    Table[sr, 2] = stateActionCell;
                }
            }

            if (Changed != null && Changed.GetInvocationList().Length > 0)
                Changed(ChangedTarget.InputEvent, ChangedType.Deleted, transitionList, null);
        }

        private void tsbInsertCondition_Click(object sender, EventArgs e)
        {
            int sRow = Table.Selection.ActivePosition.Row;

            if (sRow < 2)
                return;

            int rowIndex = sRow + 1;
            //int rowIndex = sRow + Table[sRow, 3].RowSpan;

            int startRow1 = Table[sRow, 1].Range.Start.Row;
            int startRow3 = Table[sRow, 3].Range.Start.Row;

            bool noRowSpan1 = false;
            int rowSpan1 = Table[sRow, 1].RowSpan;
            if (rowIndex < (startRow1 + rowSpan1))
                noRowSpan1 = true;

            bool noRowSpan3 = false;
            int rowSpan3 = Table[sRow, 3].RowSpan;
            if (rowIndex < (startRow3 + rowSpan3))
                noRowSpan3 = true;

            Table.Rows.Insert(rowIndex);

            try
            {
                Table[sRow, 1].RowSpan = rowSpan1 + 1;
                Table[sRow, 2].RowSpan = rowSpan1 + 1;
                Table[sRow, 3].RowSpan = rowSpan3 + 1;
                Table[sRow, 4].RowSpan = rowSpan3 + 1;
                //if (!noRowSpan)
                //{
                //Table[sRow, 1].RowSpan++;
                //Table[sRow, 2].RowSpan++;
                //}
                //if (!noRowSpan2)
                //{
                //Table[sRow, 3].RowSpan++;
                //Table[sRow, 4].RowSpan++;
                //}

            }
            catch (Exception ex) { }

            SourceGrid.Cells.Views.Cell defaultView = new SourceGrid.Cells.Views.Cell();
            defaultView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            SourceGrid.Cells.Views.Cell centerView = new SourceGrid.Cells.Views.Cell();
            centerView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;
            SourceGrid.Cells.Views.ComboBox comboView = new SourceGrid.Cells.Views.ComboBox();
            comboView.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

            Table[rowIndex, 0] = new SourceGrid.Cells.RowHeader(null);

            //Transition Condition Column
            SourceGrid.Cells.Cell transitionConditionCell = new SourceGrid.Cells.Cell("true", typeof(string));
            transitionConditionCell.View = centerView;
            Table[rowIndex, 5] = transitionConditionCell;
            transitionConditionCell.AddController(_CellValueChangedEventController);
            transitionConditionCell.AddController(_ValueChangeController);

            //Transition Action Column
            SourceGrid.Cells.Cell transitionActionCell = new SourceGrid.Cells.Cell("", typeof(string));
            transitionActionCell.View = defaultView;
            ActionEditorDialog actionEditor3 = new ActionEditorDialog();
            transitionActionCell.Editor = actionEditor3;
            Table[rowIndex, 6] = transitionActionCell;
            transitionActionCell.AddController(_CellValueChangedEventController);
            transitionActionCell.AddController(_ValueChangeController);

            //Next State Column
            SourceGrid.Cells.Cell nextStateCell = new SourceGrid.Cells.Cell("", _StateEditor);
            nextStateCell.View = defaultView;
            Table[rowIndex, 7] = nextStateCell;
            nextStateCell.AddController(_CellValueChangedEventController);
            nextStateCell.AddController(_ValueChangeController);
            nextStateCell.AddController(_NextStateValueChangeController);

            if (Changed != null && Changed.GetInvocationList().Length > 0)
                Changed(ChangedTarget.Transition, ChangedType.Added, null, null);
        }

        private void tsbDeleteCondition_Click(object sender, EventArgs e)
        {
            int sRow = Table.Selection.ActivePosition.Row;
            deleteConditionAt(sRow);
        }

        private void deleteConditionAt(int sRow)
        {
            if (sRow < 2)//|| Table.Selection.ActivePosition.Column < 5)
                return;

            List<OOSGStateTransition> transitions = this.StateTransitions;

            List<OOSGState> rawStateList = _AMControl.States;
            SortedList<string, OOSGState> stateList = new SortedList<string, OOSGState>();
            foreach (OOSGState state in rawStateList)
                stateList.Add(state.Name, state);
            List<OOSGStateTransition> removedTransitions = new List<OOSGStateTransition>();

            int inputStartRow = Table[sRow, 3].Range.Start.Row;
            int inputEndRow = Table[sRow, 3].Range.End.Row;
            int inputRowSpan = Table[inputStartRow, 3].RowSpan;

            int stateStartRow = Table[sRow, 1].Range.Start.Row;
            int stateEndRow = Table[sRow, 1].Range.End.Row;
            int stateRowSpan = Table[stateStartRow, 1].RowSpan;

            if (inputRowSpan == 1)
                return;

            OOSGState currentState = null;
            string stateAction = string.Empty;
            string inputEvent = string.Empty;
            string inputAction = string.Empty;
            string transitionCondition = string.Empty;
            string transitionAction = string.Empty;
            string nextStateName = string.Empty;
            SourceGrid.Cells.Cell nameCell = null;
            SourceGrid.Cells.Cell stateActionCell = null;
            SourceGrid.Cells.Cell inputEventCell = null;
            SourceGrid.Cells.Cell inputActionCell = null;
            if (inputStartRow == sRow)
            {
                if (stateStartRow == inputStartRow)
                {
                    nameCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 1];
                    currentState = stateList[nameCell.DisplayText];
                    nameCell.UnBindToGrid();
                    stateActionCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 2];
                    stateAction = stateActionCell.DisplayText;
                    stateActionCell.UnBindToGrid();
                }
                else
                {
                    nameCell = (SourceGrid.Cells.Cell)Table[stateStartRow, 1];
                    currentState = stateList[nameCell.DisplayText];
                    stateActionCell = (SourceGrid.Cells.Cell)Table[stateStartRow, 2];
                    stateAction = stateActionCell.DisplayText;
                }

                inputEventCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 3];
                inputEvent = inputEventCell.DisplayText;
                inputEventCell.UnBindToGrid();
                inputActionCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 4];
                inputAction = inputActionCell.DisplayText;
                inputActionCell.UnBindToGrid();

                transitionCondition = Table[inputStartRow, 5].DisplayText;
                transitionAction = Table[inputStartRow, 6].DisplayText;
                nextStateName = Table[inputStartRow, 7].DisplayText;
                if (!string.IsNullOrEmpty(nextStateName) && stateList.ContainsKey(nextStateName))
                {
                    OOSGState nextState = stateList[nextStateName];
                    OOSGStateTransition st = new OOSGStateTransition(currentState, stateAction, inputEvent, inputAction, transitionCondition, transitionAction, nextState);
                    removedTransitions.Add(st);
                }

                Table.Rows.Remove(sRow);

                inputEventCell.RowSpan = inputRowSpan - 1;
                inputActionCell.RowSpan = inputRowSpan - 1;
                Table[sRow, 3] = inputEventCell;
                Table[sRow, 4] = inputActionCell;

                if (stateStartRow == inputStartRow)
                {
                    nameCell.RowSpan = stateRowSpan - 1;
                    stateActionCell.RowSpan = stateRowSpan - 1;
                    Table[stateStartRow, 1] = nameCell;
                    Table[stateStartRow, 2] = stateActionCell;
                }
            }
            else
            {
                nameCell = (SourceGrid.Cells.Cell)Table[stateStartRow, 1];
                //nameCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 1]
                currentState = stateList[nameCell.DisplayText];
                stateActionCell = (SourceGrid.Cells.Cell)Table[stateStartRow, 2];
                stateAction = stateActionCell.DisplayText;

                inputEventCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 3];
                inputEvent = inputEventCell.DisplayText;
                inputActionCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 4];
                inputAction = inputActionCell.DisplayText;

                transitionCondition = Table[sRow, 5].DisplayText;
                transitionAction = Table[sRow, 6].DisplayText;
                nextStateName = Table[sRow, 7].DisplayText;
                if (!string.IsNullOrEmpty(nextStateName) && stateList.ContainsKey(nextStateName))
                {
                    OOSGState nextState = stateList[nextStateName];
                    OOSGStateTransition st = new OOSGStateTransition(currentState, stateAction, inputEvent, inputAction, transitionCondition, transitionAction, nextState);
                    removedTransitions.Add(st);
                }

                deleteStateTransitionAt(stateStartRow);

                List<OOSGStateTransition> stateTransitions = new List<OOSGStateTransition>();

                if (removedTransitions.Count > 0)
                {
                    foreach (OOSGStateTransition st in transitions)
                    {
                        if (st.Equals(removedTransitions[0]))
                            continue;

                        if (st.CurrentState.Name.Equals(nameCell.DisplayText))
                            stateTransitions.Add(st);
                    }
                }

                InsertStateTransitions(nameCell.DisplayText, stateTransitions);
                /*
                aa
                nameCell.RowSpan = stateRowSpan - 1;
                Table[stateStartRow, 1] = nameCell;
                stateActionCell.RowSpan = stateRowSpan - 1;
                inputEventCell.RowSpan = inputRowSpan - 1;
                inputActionCell.RowSpan = inputRowSpan - 1;

                Table.Rows.Remove(sRow);

                */

            }

            if (Changed != null && Changed.GetInvocationList().Length > 0)
                Changed(ChangedTarget.TransitionCondition, ChangedType.Deleted, removedTransitions, null);
        }

        private void deleteConditionAt2(int sRow)
        {
            if (sRow < 2)//|| Table.Selection.ActivePosition.Column < 5)
                return;

            List<OOSGState> rawStateList = _AMControl.States;
            SortedList<string, OOSGState> stateList = new SortedList<string, OOSGState>();
            foreach (OOSGState state in rawStateList)
                stateList.Add(state.Name, state);
            List<OOSGStateTransition> removedTransitions = new List<OOSGStateTransition>();

            int inputStartRow = Table[sRow, 3].Range.Start.Row;
            int inputEndRow = Table[sRow, 3].Range.End.Row;
            int inputRowSpan = Table[inputStartRow, 3].RowSpan;

            int stateStartRow = Table[sRow, 1].Range.Start.Row;
            int stateEndRow = Table[sRow, 1].Range.End.Row;
            int stateRowSpan = Table[stateStartRow, 1].RowSpan;

            if (inputRowSpan == 1)
                return;

            OOSGState currentState = null;
            string stateAction = string.Empty;
            string inputEvent = string.Empty;
            string inputAction = string.Empty;
            string transitionCondition = string.Empty;
            string transitionAction = string.Empty;
            string nextStateName = string.Empty;
            SourceGrid.Cells.Cell nameCell = null;
            SourceGrid.Cells.Cell stateActionCell = null;
            SourceGrid.Cells.Cell inputEventCell = null;
            SourceGrid.Cells.Cell inputActionCell = null;
            if (inputStartRow == sRow)
            {
                if (stateStartRow == inputStartRow)
                {
                    nameCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 1];
                    currentState = stateList[nameCell.DisplayText];
                    nameCell.UnBindToGrid();
                    stateActionCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 2];
                    stateAction = stateActionCell.DisplayText;
                    stateActionCell.UnBindToGrid();
                }
                else
                {
                    nameCell = (SourceGrid.Cells.Cell)Table[stateStartRow, 1];
                    currentState = stateList[nameCell.DisplayText];
                    stateActionCell = (SourceGrid.Cells.Cell)Table[stateStartRow, 2];
                    stateAction = stateActionCell.DisplayText;
                }

                inputEventCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 3];
                inputEvent = inputEventCell.DisplayText;
                inputEventCell.UnBindToGrid();
                inputActionCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 4];
                inputAction = inputActionCell.DisplayText;
                inputActionCell.UnBindToGrid();

                transitionCondition = Table[inputStartRow, 5].DisplayText;
                transitionAction = Table[inputStartRow, 6].DisplayText;
                nextStateName = Table[inputStartRow, 7].DisplayText;
                if (!string.IsNullOrEmpty(nextStateName) && stateList.ContainsKey(nextStateName))
                {
                    OOSGState nextState = stateList[nextStateName];
                    OOSGStateTransition st = new OOSGStateTransition(currentState, stateAction, inputEvent, inputAction, transitionCondition, transitionAction, nextState);
                    removedTransitions.Add(st);
                }

                Table.Rows.Remove(sRow);

                inputEventCell.RowSpan = inputRowSpan - 1;
                inputActionCell.RowSpan = inputRowSpan - 1;
                Table[sRow, 3] = inputEventCell;
                Table[sRow, 4] = inputActionCell;

                if (stateStartRow == inputStartRow)
                {
                    nameCell.RowSpan = stateRowSpan - 1;
                    stateActionCell.RowSpan = stateRowSpan - 1;
                    Table[stateStartRow, 1] = nameCell;
                    Table[stateStartRow, 2] = stateActionCell;
                }
            }
            else
            {
                nameCell = (SourceGrid.Cells.Cell)Table[stateStartRow, 1];
                //nameCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 1]
                currentState = stateList[nameCell.DisplayText];
                stateActionCell = (SourceGrid.Cells.Cell)Table[stateStartRow, 2];
                stateAction = stateActionCell.DisplayText;

                inputEventCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 3];
                inputEvent = inputEventCell.DisplayText;
                inputActionCell = (SourceGrid.Cells.Cell)Table[inputStartRow, 4];
                inputAction = inputActionCell.DisplayText;

                transitionCondition = Table[sRow, 5].DisplayText;
                transitionAction = Table[sRow, 6].DisplayText;
                nextStateName = Table[sRow, 7].DisplayText;
                if (!string.IsNullOrEmpty(nextStateName) && stateList.ContainsKey(nextStateName))
                {
                    OOSGState nextState = stateList[nextStateName];
                    OOSGStateTransition st = new OOSGStateTransition(currentState, stateAction, inputEvent, inputAction, transitionCondition, transitionAction, nextState);
                    removedTransitions.Add(st);
                }

                nameCell.RowSpan = stateRowSpan - 1;
                Table[stateStartRow, 1] = nameCell;
                stateActionCell.RowSpan = stateRowSpan - 1;
                inputEventCell.RowSpan = inputRowSpan - 1;
                inputActionCell.RowSpan = inputRowSpan - 1;

                Table.Rows.Remove(sRow);


            }

            if (Changed != null && Changed.GetInvocationList().Length > 0)
                Changed(ChangedTarget.TransitionCondition, ChangedType.Deleted, removedTransitions, null);
        }

        private void tsbAutoCellSize_Click(object sender, EventArgs e)
        {
            AutoSizeCells();
        }

        private void tsbCopy_Click(object sender, EventArgs e)
        {

        }

        private void AutoSizeCells()
        {
            Table.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            Table.AutoStretchColumnsToFitWidth = false;
            Table.AutoStretchRowsToFitHeight = false;
            Table.AutoSizeCells();
        }
        #endregion

        public bool IsInputEventUsed(string messageName)
        {
            string inputEvent = "?(" + messageName + ")";

            bool rslt = false;
            for (int i = 2; i < Table.Rows.Count; i++)
            {
                if (inputEvent.Equals(Table[i, 3].DisplayText))
                {
                    rslt = true;
                    break;
                }
            }
            return rslt;
        }

        public bool IsStateUsed(string stateName)
        {
            bool rslt = false;
            for (int i = 2; i < Table.Rows.Count; i++)
            {
                if (stateName.Equals(Table[i, 1].DisplayText) ||
                    stateName.Equals(Table[i, 7].DisplayText))
                {
                    rslt = true;
                    break;
                }
            }

            return rslt;
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            //Table.Font = new Font("Calibe", 9);
            zoomIn();
        }


        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            zoomOut();
        }

        private void zoomIn()
        {
            Table.Font = new Font(Table.Font.FontFamily, Table.Font.Size + 1);
            titleModel.Font = new Font(titleModel.Font.FontFamily, Table.Font.Size + 1, FontStyle.Bold);
            //Table.Font = new Font("Consolas", Table.Font.Size + 1);
            //Table.Font = new Font("Calibe", Table.Font.Size + 1);
            AutoSizeCells();
        }

        private void zoomOut()
        {
            Table.Font = new Font(Table.Font.FontFamily, Table.Font.Size - 1);
            titleModel.Font = new Font(titleModel.Font.FontFamily, Table.Font.Size - 1, FontStyle.Bold);
            //Table.Font = new Font("Calibe", Table.Font.Size - 1);
            AutoSizeCells();
        }

        private void Table_MouseWheel(object sender, MouseEventArgs e)
        {
            if (Form.ModifierKeys == Keys.Control)
            {
                if (e.Delta > 0)
                {
                    //zoom in
                    zoomIn();
                }
                else if (e.Delta < 0)
                {
                    //zoom out
                    zoomOut();
                }
            }
        }

        private void EventTransitionTableWindow_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Add && e.Control)
            {
                zoomIn();
            }
            else if (e.KeyCode == Keys.Subtract && e.Control)
            {
                zoomOut();
            }
            else if (e.KeyCode == Keys.OemMinus && e.Control)
            {
                zoomOut();
            }
            else if (e.KeyCode == Keys.Oemplus && e.Control)
            {
                zoomIn();
            }
        }
    }

    public delegate void STTStateValueChangedEventHandler(int row, string stateName);
    public delegate void STTEntryActionChangedEventHandler(int row, string stateName);

    public class STTStateValueChangedEventController : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event STTStateValueChangedEventHandler ValueChanged;

        public STTStateValueChangedEventController()
        {
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

            ValueChanged(sender.Position.Row, e.NewValue.ToString());
        }
    }

    public delegate void STTNextStateValueChangedEventHandler(int row, string oldStateName, string newStateName);
    public class STTNextStateValueChangedEventController : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event STTNextStateValueChangedEventHandler ValueChanged;

        public STTNextStateValueChangedEventController()
        {
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

            ValueChanged(sender.Position.Row, e.OldValue == null ? "" : e.OldValue.ToString(), e.NewValue.ToString());
        }
    }

    public delegate void STTValueChangedEventHandler(int row, int column, string oldValue, string newValue);
    public class STTValueChangedEventController : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event STTValueChangedEventHandler ValueChanged;

        public STTValueChangedEventController() { }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

            string oldValue = string.Empty;
            if (e.OldValue != null)
                oldValue = e.OldValue.ToString();
            string newValue = string.Empty;
            if (e.NewValue != null)
                newValue = e.NewValue.ToString();

            ValueChanged(sender.Position.Row, sender.Position.Column, oldValue, newValue);
        }
    }


    public class STTEntryActionChangedEventController : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event STTEntryActionChangedEventHandler ValueChanged;

        public STTEntryActionChangedEventController()
        {
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

            ValueChanged(sender.Position.Row, e.NewValue.ToString());
        }
    }

    public delegate void CellValueChangedEventHandler(int row, int col, string oldValue, string newValue);

    public class CellValueChangedEventController : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event CellValueChangedEventHandler ValueChanged;

        public CellValueChangedEventController()
        {
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

            string oldValue = string.Empty;
            if (e.OldValue != null)
                oldValue = e.OldValue.ToString();
            string newValue = string.Empty;
            if (e.NewValue != null)
                newValue = e.NewValue.ToString();
            ValueChanged(sender.Position.Row, sender.Position.Column, oldValue, newValue);
        }
    }

}
