﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.StateObjects;

namespace DHKANG.SEA.UI.STTEditor
{
    public partial class StateWindow : DockContent
    {
        #region Member Variables
        private StateObjectModelEditor _AMControl;
        private StateGridValueChangedEvent valueChangedController;

        #endregion

        #region Events
        public event ChangedEventHandler Changed;
        #endregion

        #region Properties
        public OOSGState InitialState
        {
            get
            {
                OOSGState rslt = null;

                List<OOSGState> states = this.States;
                foreach (OOSGState state in states)
                {
                    if (state.Type == StateType.Initial)
                    {
                        rslt = state; break;
                    }
                }

                return rslt;
            }
        }
        public List<OOSGState> States
        {
            get
            {
                List<OOSGState> rslt = new List<OOSGState>();
                if (grid.RowsCount > 1)
                {
                    for (int i = 1; i < grid.RowsCount; i++)
                    {
                        //Name, Type, Action, Time Delay
                        string sName = grid[i, 1].DisplayText;
                        StateType sType = (StateType)Enum.Parse(typeof(StateType), grid[i, 2].DisplayText);
                        string sAction = grid[i, 3].DisplayText;
                        string sTimeDelay = grid[i, 4].DisplayText;

                        OOSGState state = new OOSGState(sName, sType, sAction, new OOSGDelay(sTimeDelay));
                        
                        rslt.Add(state);
                    }
                }
                return rslt;
            }
        }
        #endregion

        #region Constructors
        public StateWindow(StateObjectModelEditor parent)
        {
            _AMControl = parent;

            InitializeComponent();

            drawHeaders();

            valueChangedController = new StateGridValueChangedEvent();
            valueChangedController.ValueChanged += new StateGridValueChangedEventHandler(valueChangedController_ValueChanged);
        }

        private void valueChangedController_ValueChanged(OOSGState oldState, OOSGState newState)
        {
            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            {
                Changed(ChangedTarget.State, ChangedType.Modified, oldState, newState);
            }
            
        }
        #endregion

        private void StateWindow_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            base.OnFormClosing(e);
        }

        private void drawHeaders()
        {
            grid.Rows.Clear();

            grid.BorderStyle = BorderStyle.None;
            grid.Redim(1, 5);
            //grid.EnableSort = true;
            //grid.CustomSort = false;
            grid.FixedRows = 1;
            grid.FixedColumns = 1;
            grid.AutoStretchRowsToFitHeight = true;

            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            //grid.Font = new Font("Calibe", 9);
            grid.Font = new Font(
                ToolkitConfiguration.Table.Font.FontName,
                ToolkitConfiguration.Table.Font.Size);
            grid.AutoStretchColumnsToFitWidth = ToolkitConfiguration.Table.TableStretch;

            grid.Columns[0].AutoSizeMode = SourceGrid.AutoSizeMode.None;
            grid.Columns[0].Width = 25;
            SourceGrid.Cells.Header l_00Header = new SourceGrid.Cells.Header(null);
            grid[0, 0] = l_00Header;

            string[] columns = { "Name", "Type", "Action", "Time Delay" };
            for (int i = 0; i < columns.Length; i++)
            {
                SourceGrid.Cells.ColumnHeader header = 
                    new SourceGrid.Cells.ColumnHeader(columns[i]);
                header.View = titleModel;

                grid[0, 1+ i] = header;
            }

            grid.Columns[3].Visible = false;
        }

        public void Update(OOSGStateObjectModel am)
        //public void Update(AtomicModel am)
        {
            //Sorting Order
            List<string> states = (from s in am.States select s.Name).ToList<string>();
            states.Sort();

            foreach (string name in states)
            {
                InsertState(am.FindState(name));
            }

            grid.AutoStretchColumnsToFitWidth = false;
            grid.AutoStretchRowsToFitHeight = false;
            grid.AutoSizeCells();
        }

        public void InsertState(OOSGState state)
        {
            int rowIndex = grid.RowsCount;
            grid.Rows.Insert(rowIndex);

            grid[rowIndex, 0] = new SourceGrid.Cells.RowHeader(null);

            //Name
            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(state.Name, typeof(string));
            nameCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 1] = nameCell;
            grid[rowIndex, 1].AddController(this.valueChangedController);

            //Type
            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            //string[] types = Enum.GetNames(typeof(StateType));
            string[] types = new string[] { "Regular", "Initial", "Final" };
            cbEditor.StandardValues = types;
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;
            cbEditor.Control.DropDownStyle = ComboBoxStyle.DropDownList;

            SourceGrid.Cells.Cell typeCell = new SourceGrid.Cells.Cell(state.Type.ToString(), cbEditor);
            typeCell.View = SourceGrid.Cells.Views.ComboBox.Default;
            typeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 2] = typeCell;
            grid[rowIndex, 2].AddController(this.valueChangedController);

            //Action
            SourceGrid.Cells.Cell actionCell = new SourceGrid.Cells.Cell(state.EntryAction);
            actionCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            ActionEditorDialog actionEditor = new ActionEditorDialog();
            actionCell.Editor = actionEditor;
            grid[rowIndex, 3] = actionCell;
            grid[rowIndex, 3].AddController(this.valueChangedController);

            //Time Delay
            string delay = state.Delay == null ? "" : state.Delay.Name;
            SourceGrid.Cells.Cell timeCell = new SourceGrid.Cells.Cell(delay, typeof(string));
            timeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 4] = timeCell;
            grid[rowIndex, 4].AddController(this.valueChangedController);
        }

        private void InsertEmptyState()
        {
            int rowIndex = grid.RowsCount;
            grid.Rows.Insert(rowIndex);

            grid[rowIndex, 0] = new SourceGrid.Cells.RowHeader(null);

            //Name
            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell("State " + rowIndex, typeof(string));
            nameCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 1] = nameCell;
            grid[rowIndex, 1].AddController(this.valueChangedController);

            //Type
            SourceGrid.Cells.Editors.ComboBox cbEditor = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
            //string[] types = Enum.GetNames(typeof(StateType));
            string[] types = new string[] { "Regular", "Initial", "Final" };
            cbEditor.StandardValues = types;
            cbEditor.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;
            cbEditor.Control.DropDownStyle = ComboBoxStyle.DropDownList;

            SourceGrid.Cells.Cell typeCell = new SourceGrid.Cells.Cell(StateType.Regular.ToString(), cbEditor);
            typeCell.View = SourceGrid.Cells.Views.ComboBox.Default;
            typeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 2] = typeCell;
            grid[rowIndex, 2].AddController(this.valueChangedController);

            //Action
            SourceGrid.Cells.Cell actionCell = new SourceGrid.Cells.Cell("");
            actionCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            ActionEditorDialog actionEditor = new ActionEditorDialog();
            actionCell.Editor = actionEditor;
            grid[rowIndex, 3] = actionCell;
            grid[rowIndex, 3].AddController(this.valueChangedController);

            //Time Delay
            SourceGrid.Cells.Cell timeCell = new SourceGrid.Cells.Cell("", typeof(string));
            timeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 4] = timeCell;
            grid[rowIndex, 4].AddController(this.valueChangedController);

            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            {
                OOSGState state =
                    new OOSGState(
                        grid[rowIndex, 1].DisplayText,
                        (StateType)Enum.Parse(typeof(StateType), grid[rowIndex, 2].DisplayText),
                        grid[rowIndex, 3].DisplayText,new OOSGDelay(grid[rowIndex, 4].DisplayText));

                Changed(ChangedTarget.State, ChangedType.Added, null, state);
            }

            if (grid.Rows.Count == 2)
                grid.AutoSizeCells();
        }

        private void grid_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            SourceGrid.Position p = grid.PositionAtPoint(e.Location);
            if (p.IsEmpty())
            {
                InsertEmptyState();
            }
        }

        private void tsbInsert_Click(object sender, EventArgs e)
        {
            InsertEmptyState();
        }

        private void tsbDelete_Click(object sender, EventArgs e)
        {
            int sRow = grid.Selection.ActivePosition.Row;
            if (sRow < 0 || grid[sRow, 0] == null)
                return;

            string sName = grid[sRow, 1].DisplayText;
            StateType sType = (StateType)Enum.Parse(typeof(StateType), grid[sRow, 2].DisplayText);
            string sAction = grid[sRow, 3].DisplayText;
            OOSGDelay delay = new OOSGDelay(grid[sRow, 4].DisplayText);
                        
            grid.Rows.Remove(sRow);

            if (this.Changed != null && this.Changed.GetInvocationList().Length > 0)
            {
                OOSGState state =
                    new OOSGState(sName, sType, sAction, delay);

                Changed(ChangedTarget.State, ChangedType.Deleted, state, null);
            }

            //grid.AutoSizeCells();
        }

    }

    public delegate void StateGridValueChangedEventHandler(OOSGState prevMsg, OOSGState newMsg);

    public class StateGridValueChangedEvent : SourceGrid.Cells.Controllers.ControllerBase
    {
        public event StateGridValueChangedEventHandler ValueChanged;

        public StateGridValueChangedEvent()
        {
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

            OOSGState oldState = null;
            OOSGState newState = null;

            SourceGrid.Cells.Cell nameCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 1);
            SourceGrid.Cells.Cell typeCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 2);
            SourceGrid.Cells.Cell actionCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 3);
            SourceGrid.Cells.Cell timeCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 4);

            if (sender.Position.Column == 1) //name
            {
                StateType sType = (StateType)Enum.Parse(
                    typeof(StateType),
                    typeCell.DisplayText);
                string sAction = actionCell.DisplayText;
                string sTimeDelay = timeCell.DisplayText;
                oldState = new OOSGState((string)e.OldValue, sType, sAction, new OOSGDelay(sTimeDelay));
                newState = new OOSGState((string)e.NewValue, sType, sAction, new OOSGDelay(sTimeDelay));
            }
            else if (sender.Position.Column == 2)
            {
                StateType oType = (StateType)Enum.Parse(
                    typeof(StateType), e.OldValue.ToString());
                StateType nType = (StateType)Enum.Parse(
                    typeof(StateType), e.NewValue.ToString());

                string sName = nameCell.DisplayText;
                string sAction = actionCell.DisplayText;
                string sTimeDelay = timeCell.DisplayText;

                oldState = new OOSGState(sName, oType, sAction, new OOSGDelay(sTimeDelay));
                newState = new OOSGState(sName, nType, sAction, new OOSGDelay(sTimeDelay));
            }
            else if (sender.Position.Column == 3)
            {
                StateType sType = (StateType)Enum.Parse(
                    typeof(StateType),
                    typeCell.DisplayText);

                string sName = nameCell.DisplayText;
                string sTimeDelay = timeCell.DisplayText;

                oldState = new OOSGState(sName, sType, (string)e.OldValue, new OOSGDelay(sTimeDelay));
                newState = new OOSGState(sName, sType, (string)e.NewValue, new OOSGDelay(sTimeDelay));
            }
            else if (sender.Position.Column == 4)
            {
                StateType sType = (StateType)Enum.Parse(
                    typeof(StateType),
                    typeCell.DisplayText);

                string sName = nameCell.DisplayText;
                string sAction = actionCell.DisplayText;
                string sTimeDelay = timeCell.DisplayText;

                oldState = new OOSGState(sName, sType, sAction, new OOSGDelay((string)e.OldValue));
                newState = new OOSGState(sName, sType, sAction, new OOSGDelay((string)e.NewValue));
            }

            if (ValueChanged != null && ValueChanged.GetInvocationList().Length > 0)
                ValueChanged(oldState, newState);
        }
    }
}
