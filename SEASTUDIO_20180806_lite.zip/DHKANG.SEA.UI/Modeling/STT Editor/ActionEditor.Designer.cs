﻿namespace DHKANG.SEA.UI.STTEditor
{
    partial class ActionEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tecAction = new ICSharpCode.TextEditor.TextEditorControl();
            this.SuspendLayout();
            // 
            // tecAction
            // 
            this.tecAction.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tecAction.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tecAction.IsReadOnly = false;
            this.tecAction.Location = new System.Drawing.Point(0, 0);
            this.tecAction.Name = "tecAction";
            this.tecAction.Size = new System.Drawing.Size(398, 255);
            this.tecAction.TabIndex = 35;
            // 
            // ActionEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(398, 255);
            this.Controls.Add(this.tecAction);
            this.MaximizeBox = false;
            this.Name = "ActionEditor";
            this.Text = "ActionEditor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ActionEditor_FormClosing);
            this.ResumeLayout(false);

        }

        #endregion

        private ICSharpCode.TextEditor.TextEditorControl tecAction;
    }
}