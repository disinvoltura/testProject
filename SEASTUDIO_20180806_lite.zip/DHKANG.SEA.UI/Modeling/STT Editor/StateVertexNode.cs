﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using Northwoods.Go;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.UI.OutputView;

namespace DHKANG.SEA.UI.STTEditor
{
    public class StateVertexNode : Node
    {
        #region Member Variables
        private OOSGState _StateVertex;
        #endregion

        private string FontName = "Calibri"; //추후 toolkit configuration에서 가져와야 함
        private float FontSize = 14.0f;
        private Color RegularState_Background = Color.WhiteSmoke;
        private Color InitialState_Background = Color.Orchid;
        private Color FinalState_Background = Color.BlanchedAlmond;

        #region Properties
        public OOSGState State
        {
            get { return _StateVertex; }
            set {
                OOSGState oldValue = null;
                if (this.State != null)
                    oldValue = this.State.Clone();
                _StateVertex = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "State", oldValue, value);
            }
        }

        public string StateName
        {
            get { return _NodeName; }
            set
            {
                OOSGState oldValue = this.State.Clone();
                string oldPropertyValue = _NodeName;
                _NodeName = value;

                GoBasicNode tnode = (GoBasicNode)_Presentation;
                tnode.Label.Text = value;
                _StateVertex.Name = value;

                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Name", oldValue, this.State);
            }
        }

        public StateType StateType
        {
            get { return _StateVertex.Type; }
            set
            {
                OOSGState oldValue = this.State.Clone();
                StateType oldPropertyValue = _StateVertex.Type;
                _StateVertex.Type = value;

                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Type", oldValue, this.State);
            }
        }

        public OOSGDelay Delay
        {
            get { return _StateVertex.Delay; }
            set
            {
                OOSGState oldValue = this.State.Clone();
                OOSGDelay oldPropertyValue = _StateVertex.Delay.Clone();
                _StateVertex.Delay = value;

                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Delay", oldValue, this.State);
            }
        }

        public override Color BackgroundColor
        {
            get
            {
                GoBasicNode tnode = (GoBasicNode)_Presentation;
                return tnode.Shape.BrushColor;
            }
            set
            {
                GoBasicNode tnode = (GoBasicNode)_Presentation;
                tnode.Shape.BrushColor = value;
            }
        }
        #endregion

        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion


        #region Constructors
        public StateVertexNode(int id, string name)
            : base(id, name, NodeType.StateVertex)
        {
            _StateVertex = new OOSGState();
            _StateVertex.Name = name;

            GoBasicNode presentation = new GoBasicNode();
            presentation.LabelSpot = GoObject.Middle;
            presentation.Shape = new GoRoundedRectangle();
            //GoTextNode presentation = new GoTextNode(GoFigure.RoundedRectangle);

            //presentation.Shape.FillShadedGradient(Color.WhiteSmoke);

            //presentation.Shape.FillShapeHighlight(Color.FromArgb(80, 180, 240), Color.FromArgb(255, 255, 255));
            //presentation.Shape.FillShadedGradient(Color.Blue);

            presentation.Shape.FillSingleEdge(Color.Red, Color.Orange, GoObject.MiddleTop);
            presentation.Shape.BrushMidFraction = 0.4f;
            presentation.Text = name;
            presentation.Label.TextColor = Color.White;

            //presentation.Shape.FillHalfGradient(Color.Black);

            //GoTextNode presentation = new GoTextNode(GoFigure.Ellipse);
            presentation.UserObject = this;
            presentation.Editable = true;
            presentation.Label.Editable = true;
            presentation.Label.EditableWhenSelected = true;
            presentation.Label.Multiline = true;
            presentation.Label.Font = new Font(FontName, FontSize, FontStyle.Regular);

            foreach (GoPort port in presentation.Ports)
            {
                port.IsValidDuplicateLinks = true;
                port.IsValidSelfNode = true;
            }
            _Presentation = presentation;
        }

        #endregion

        #region Methods
        public void setRegular()
        {
            //((GoBasicNode)_Presentation).Shape.FillShadedGradient(RegularState_Background);
            //_Presentation.Label.Font = new Font(FontName, FontSize, FontStyle.Regular);
            ((GoBasicNode)_Presentation).Shape = new GoRoundedRectangle();
            ((GoBasicNode)_Presentation).Shape.FillSingleEdge(Color.Red, Color.Orange, GoObject.MiddleTop);
            ((GoBasicNode)_Presentation).Shape.BrushMidFraction = 0.4f;
        }

        public void setInitial()
        {
            ((GoBasicNode)_Presentation).Shape = new GoRoundedRectangle();
            ((GoBasicNode)_Presentation).Shape.FillShadedGradient(InitialState_Background);
            _Presentation.Label.Font = new Font(FontName, FontSize, FontStyle.Italic);
        }

        public void setFinal()
        {
            //TODO: double line으로 변경해야 함
            ((GoBasicNode)_Presentation).Shape = new GoRoundedRectangle();
            ((GoBasicNode)_Presentation).Shape.FillShadedGradient(FinalState_Background);
            _Presentation.Label.Font = new Font(FontName, FontSize, FontStyle.Bold);
        }

        public override bool ShowDialog(bool read)
        {
            return true;
        }

        public override int FindPortIndex(IGoPort targetPort)
        {
            int rslt = 0;
            foreach (IGoPort port in this.Presentation.Ports)
            {
                if (port == targetPort)
                {
                    break;
                }

                rslt++;
            }

            return rslt;
        }

        public override IGoPort FindShortestDistancePort(int x, int y)
        {
            IGoPort rslt = null;

            GoBasicNode node = (GoBasicNode)this.Presentation;
            //GoTextNode node = (GoTextNode)this.Presentation;
            float minDistance = float.MaxValue;
            IGoPort minPort = null;
            foreach (IGoPort port in node.Ports)
            {
                if (port.GoObject == null)
                    continue;

                float distance =
                    getDistance(port.GoObject.Center.X, port.GoObject.Center.Y, x, y);

                if (distance < minDistance)
                {
                    minDistance = distance;
                    minPort = port;
                }
            }

            if (minPort != null)
                rslt = minPort;

            return rslt;
        }

        private float getDistance(float x1, float y1, float x2, float y2)
        {
            float distance = 0;
            distance = (float)Math.Sqrt((x2 - x1) * (x2 - x1) * (y2 - y1) * (y2 - y1));

            return distance;
        }

        public override IGoPort FindPort(int portid)
        {
            int count = 0;
            IGoPort rslt = null;
            foreach (IGoPort port in this.Presentation.Ports)
            {
                if (count == portid)
                {
                    rslt = port;
                    break;
                }
                count++;
            }
            return rslt;
        }
        #endregion
    }
}
