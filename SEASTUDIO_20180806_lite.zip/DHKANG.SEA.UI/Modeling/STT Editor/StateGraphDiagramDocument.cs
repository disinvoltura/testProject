﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using Northwoods.Go;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.OID.Presentation;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.UI.ETTEditor;

namespace DHKANG.SEA.UI.STTEditor
{
    public class StateGraphDiagramDocument : GoDocument, DiagramDocument
    {
        #region Member Variables
        private int _nodeCounter = 0;
        public static float NodeWidth = 60;
        public static float NodeHeight = 60;

        private NodeFactory _Factory;
        private Dictionary<string, int> _TypeIDList;

        private bool _EdgeLabelVisible = false;
        #endregion

        #region Properties
        public NodeFactory NodeFactory
        {
            set { _Factory = value; }
            get { return _Factory; }
        }

        public bool EdgeLabelVisibile
        {
            get { return _EdgeLabelVisible; }
            set { _EdgeLabelVisible = value;
            
                foreach(GoObject obj in this)
                {
                    if (obj is Transition)
                    {
                        Transition edge = (Transition)obj;

                        if (edge.MidLabel != null)
                            edge.MidLabel.Visible = _EdgeLabelVisible;
                        if (edge.FromLabel != null)
                            edge.FromLabel.Visible = _EdgeLabelVisible;
                    }
                }

            }
        }
        #endregion

        #region Constructors
        public StateGraphDiagramDocument()
            : base()
        {
            this.Name = "1";

            _TypeIDList = new Dictionary<string, int>();
            string[] namelist = Enum.GetNames(typeof(NodeType));
            foreach (string name in namelist)
            {
                _TypeIDList.Add(name, 1);
            }

        }

        public StateGraphDiagramDocument(string name)
            : this()
        {
            this.Name = name;
        }
        #endregion

        #region Node Naming Methods
        public int NextTypeID(NodeType type)
        {
            int typeID = _TypeIDList[type.ToString()];
            _TypeIDList[type.ToString()]++;

            return typeID;
        }

        public string NextName(NodeType type)
        {
            int typeID = NextTypeID(type);

            string name = type.ToString() + " " + typeID;

            while (this.FindNode(name) != null)
            {
                typeID++;
                _TypeIDList[type.ToString()] = typeID;

                name = type.ToString() + " " + typeID;
            }

            return name;
        }

        #endregion

        #region Initialization Methods
        public void Initialize()
        {
            _Factory = new NodeFactory();
            //_Objects = new Dictionary<string, GoObject>();
            _Factory.Document = this;
        }
        #endregion

        #region Insertion Methods
        public GoTextNode InsertClockNode()
        {
            this.StartTransaction();

            GoTextNode node = new GoTextNode();
            node.Center = new PointF(15, 15);
            node.Text = "Clock: 0";
            this.Add(node);
            this.FinishTransaction("Clock Node is inserted.");
            return node;
        }

        public Node InsertStateVertexNode(float x, float y)
        {
            this.StartTransaction();

            StateVertexNode node =
                (StateVertexNode)_Factory.GetInstance(NodeType.StateVertex);
            node.Position = new PointF(x, y);
            
            this.Add(node.Presentation);
            //this.Add(node);
            this.FinishTransaction("StateVertexNode Node is inserted.");

            return node;
        }

        public Node InsertStateVertexNode(float x, float y, string name)
        {
            this.StartTransaction();

            StateVertexNode node =
                (StateVertexNode)_Factory.GetInstance(NodeType.StateVertex, name);
            node.Position = new PointF(x, y);

            this.Add(node.Presentation);
            this.FinishTransaction("StateVertexNode Node is inserted.");

            return node;
        }

        public Node InsertStateVertexNode(OOSGState state)
        {
            this.StartTransaction();

            StateVertexNode node =
                (StateVertexNode)_Factory.GetInstance(NodeType.StateVertex);
            node.State = state;
            node.StateName = state.Name;
            node.Position = new PointF(state.X, state.Y);

            if (state.Type == StateType.Initial)
                node.setInitial();
            if (state.Type == StateType.Final)
                node.setFinal();

            this.Add(node.Presentation);
            this.FinishTransaction("StateVertex Node is inserted.");

            return node;
        }

        public ScheduleNode InsertScheduleNode(float x, float y)
        {
            this.StartTransaction();

            string name = NextName(NodeType.Schedule);
            ScheduleNode node = new ScheduleNode(name, x, y);
            //node.Position = new PointF(x, y);

            this.Add(node);
            this.FinishTransaction("Schedule Node is inserted.");

            return node;
        }

        public ScheduleNode InsertSchedulenode(float x, float y, string name)
        {
            this.StartTransaction();

            ScheduleNode node = new ScheduleNode(name, x, y);
            //node.Position = new PointF(x, y);

            this.Add(node);
            this.FinishTransaction("Schedule Node is inserted.");

            return node;
        }

        public ScheduleNode InsertScheduleNode(OOMMSchedule schedule)
        {
            this.StartTransaction();

            ScheduleNode node = 
                new ScheduleNode(
                        schedule.NodeID, 
                        schedule.Name, 
                        schedule.Type, 
                        schedule.TimeUnit, 
                        schedule.Description, 
                        schedule.Values, 
                        schedule.X, schedule.Y);
            //.node.Position = new PointF(schedule.X, schedule.Y);

            this.Add(node);
            this.FinishTransaction("Schedule Node is inserted.");

            return node;
        }

        public MessageNode InsertMessageNode(float x, float y)
        {
            this.StartTransaction();

            string name = NextName(NodeType.Message);
            MessageNode node = new MessageNode(name, x, y);

            this.Add(node);
            this.FinishTransaction("Message Node is inserted.");

            return node;
        }

        public MessageNode InsertMessageNode(float x, float y, string name)
        {
            this.StartTransaction();

            MessageNode node = new MessageNode(name, x, y);

            this.Add(node);
            this.FinishTransaction("Message Node is inserted.");

            return node;
        }

        public MessageNode InsertMessageNode(OOSGMessage msg)
        {
            this.StartTransaction();

            MessageNode node = new MessageNode(msg);
            node.Left = msg.X;
            node.Top = msg.Y;

            this.Add(node);
            this.FinishTransaction("Message Node is inserted.");

            return node;
        }

        public ParameterNode InsertParameterNode(float x, float y)
        {
            this.StartTransaction();

            string name = NextName(NodeType.Parameter);
            ParameterNode node = new ParameterNode(name, x, y);

            this.Add(node);
            this.FinishTransaction("Parameter Node is inserted.");

            return node;
        }

        public ParameterNode InsertParameterNode(float x, float y, string name)
        {
            this.StartTransaction();

            ParameterNode node = new ParameterNode(name, x, y);

            this.Add(node);
            this.FinishTransaction("Parameter Node is inserted.");

            return node;
        }

        public ParameterNode InsertParameterNode(OOSGParameter p)
        {
            this.StartTransaction();

            ParameterNode node = new ParameterNode(p);
            node.Left = p.X;
            node.Top = p.Y;

            this.Add(node);
            this.FinishTransaction("Parameter Node is inserted.");

            return node;
        }

        public TextNode InsertTextNode(float x, float y)
        {
            this.StartTransaction();

            string name = NextName(NodeType.Text);
            TextNode node = new TextNode(name, x, y);

            this.Add(node);
            this.FinishTransaction("Text Node is inserted.");

            return node;

        }

        public TextNode InsertTextNode(OOMMTextNode lt)
        {
            this.StartTransaction();

            TextNode n = new TextNode(lt.Text, lt.X, lt.Y);

            FontStyle fs = new FontStyle();
            if (lt.Font.Bold)
                fs = fs | FontStyle.Bold;
            if (lt.Font.Italic)
                fs = fs | FontStyle.Italic;
            if (lt.Font.Underline)
                fs = fs | FontStyle.Underline;
            if (lt.Font.Strikeout)
                fs = fs | FontStyle.Strikeout;
            n.Font = new Font(lt.Font.Name, lt.Font.Size, fs);
            n.TextColor = Color.FromArgb(lt.Font.Color);
            n.BackgroundColor = Color.FromArgb(lt.BackColor);
            n.TransparentBackground = lt.TransparentBackground;
            n.Position = new PointF(lt.X, lt.Y);
            //n.Center = new PointF(lt.X, lt.Y);

            this.Add(n);
            this.FinishTransaction("Text Node is inserted.");

            return n;
        }

        public LabelNode InsertLabelNode(Guid eventObjectID, string eventObjectName, string stateVariableName, string initialValue, float x, float y)
        {
            this.StartTransaction();

            string nextName = NextName(NodeType.Variable);
            LabelNode n = new LabelNode(Guid.NewGuid(), nextName, eventObjectID, eventObjectName, stateVariableName, initialValue, x, y);
            n.Position = new PointF(x, y);

            this.Add(n);
            this.FinishTransaction("Label Node is inserted.");

            return n;
        }

        public LabelNode InsertLabelNode(OOMMModel model, OOMMLabelNode lt)
        {
            this.StartTransaction();

            OOSGStateObjectModel soModel = model.FindStateObjectModel(lt.ObjectID);
            OOSGStateVariable sv = soModel.FindStateVariable(lt.StateVariableName);
            LabelNode n = new LabelNode(lt.NodeID, lt.LabelName, lt.ObjectID, soModel.Name, lt.StateVariableName, sv.InitialValue.ToString(), lt.X, lt.Y);


            FontStyle fs = new FontStyle();
            if (lt.Font.Bold)
                fs = fs | FontStyle.Bold;
            if (lt.Font.Italic)
                fs = fs | FontStyle.Italic;
            if (lt.Font.Underline)
                fs = fs | FontStyle.Underline;
            if (lt.Font.Strikeout)
                fs = fs | FontStyle.Strikeout;
            n.Font = new Font(lt.Font.Name, lt.Font.Size, fs);
            n.TextColor = Color.FromArgb(lt.Font.Color);
            n.BackgroundColor = Color.FromArgb(lt.BackColor);
            n.TransparentBackground = lt.TransparentBackground;
            n.Position = new PointF(lt.X, lt.Y);
            //n.Center = new PointF(lt.X, lt.Y);

            this.Add(n);
            this.FinishTransaction("Text Node is inserted.");

            return n;
        }
        #endregion

        #region Find Methods
        public List<LabelNode> GetLabelNodes(string objectName, string stateVariableName)
        {
            List<LabelNode> rslt = new List<LabelNode>();

            foreach (GoObject obj in this)
            {
                if (obj is LabelNode)
                {
                    LabelNode ln = (LabelNode)obj;
                    if (ln.ObjectName == objectName &&
                        ln.StateVariableName == stateVariableName)
                    {
                        rslt.Add(ln);
                    }
                }
            }

            return rslt;
        }

        public new object FindNode(string name)
        {
            object rslt = null;

            foreach (GoObject obj in this)
            {
                if (obj is GoBasicNode) //State Vertex
                //if (obj is GoTextNode)
                {
                    GoBasicNode node = (GoBasicNode)obj;
                    if (node.Text.Equals(name))
                    {
                        rslt = (Node)node.UserObject;
                        break;
                    }
                }else if (obj is ScheduleNode) {
                    ScheduleNode node = (ScheduleNode)obj;
                    if (node.ScheduleName.Equals(name))
                    {
                        rslt = node;
                        break;
                    }
                }
            }
            return rslt;
        }

        public object FindNode(int id)
        {
            Node rslt = null;

            /*
            foreach (GoObject obj in this)
            {
                if (obj is Node)
                {
                    Node ll = (Node)obj;
                    if (ll.NodeID == id)
                    {
                        rslt = ll;
                        break;
                    }
                }
            }
             * */
            return rslt;
        }

        public Link FindLink(int id)
        {
            Link rslt = null;
            foreach (GoObject obj in this)
            {
                if (obj is Link)
                {
                    Link l = (Link)obj;
                    if (l.LinkID == id)
                    {
                        rslt = l;
                        break;
                    }
                }
            }

            return rslt;

        }
        #endregion

        public GoText CreateInputEventLabel(string inptuEvent)
        {
            GoText fromLabel = CreateLabel(inptuEvent);
            fromLabel.Font = new Font("Calibri", 8.0f);
            fromLabel.TextColor = Color.DarkSlateGray;
            fromLabel.Editable = false;
            fromLabel.Selectable = false;
            fromLabel.Multiline = true;
            fromLabel.Deletable = false;
            fromLabel.Movable = true;

            return fromLabel;
        }

        public GoText CreateConditionLabel(string condition)
        {
            GoText midLabel = CreateLabel(condition);
            midLabel.Font = new Font("Calibri", 8.0f, FontStyle.Italic);
            midLabel.TextColor = Color.DarkGray;
            midLabel.Editable = false;
            midLabel.Selectable = false;
            midLabel.Multiline = true;
            midLabel.Deletable = false;
            midLabel.Movable = true;

            return midLabel;
        }
        public void InsertEdge(OOSGState state, OOSGStateTransition edge)
        {
            StateVertexNode fromNode = (StateVertexNode)FindNode(state.Name);
            StateVertexNode toNode = (StateVertexNode)FindNode(edge.NextState.Name);

            if (fromNode == null || toNode == null)
                return;

            this.StartTransaction();

            Transition newEdge = (Transition) StateGraphDiagramView.MakeLink(UI.InsertionMode.TransitionEdge);
            
            //IGoPort fromPort = fromNode.FindPort(edge.FromPort);
            //IGoPort toPort = toNode.FindPort(edge.ToPort);
            //newEdge.FromPort = fromPort;
            //newEdge.ToPort = toPort;

            newEdge.FromPort = ((GoBasicNode)fromNode.Presentation).Port;
            newEdge.ToPort = ((GoBasicNode)toNode.Presentation).Port; 
            //while (this.FindLink(StateGraphDiagramView.LastID) != null)
            //{
            //    StateGraphDiagramView.LastID++;
            //}
            //newEdge.LinkID = StateGraphDiagramView.LinkCount;
            //StateGraphDiagramView.LastID++;
            //StateGraphDiagramView.LinkCount++;

            if (!string.IsNullOrEmpty(edge.InputOrDelay))
            {
                GoText fromLabel = CreateInputEventLabel(edge.InputOrDelay);
                newEdge.FromLabel = fromLabel;
            }

            if (!string.IsNullOrEmpty(edge.Condition))
            {
                GoText midLabel = CreateConditionLabel(edge.Condition);
                newEdge.MidLabel = midLabel;
            }
 
            /*
            newEdge.RealLink.Style = (GoStrokeStyle)edge.LinkStyle;
            newEdge.Orthogonal = edge.Orthogonal;
            if (newEdge.RealLink.Style != GoStrokeStyle.Line)
            {
                newEdge.RealLink.Curviness = edge.Curviness;
                newEdge.RealLink.AdjustingStyle = (GoLinkAdjustingStyle)edge.AdjustingStyle;
                if (edge.Points != null)
                {
                    newEdge.RealLink.ClearPoints();
                    foreach (OOSGPoint pt in edge.Points)
                    {
                        newEdge.RealLink.AddPoint(pt.X, pt.Y);
                    }
                }
            }
            */

            newEdge.Curviness = 20 * this.NumLinksBetween(newEdge.FromPort, newEdge.ToPort);
            newEdge.CalculateRoute();

            this.LinksLayer.Add(newEdge);

            this.FinishTransaction("Transition is inserted.");
        }

        public void InsertEdge(string originVertex, string destVertex)
        {
            this.StartTransaction();

            StateVertexNode fromNode = (StateVertexNode)FindNode(originVertex);
            StateVertexNode toNode = (StateVertexNode)FindNode(destVertex);

            Transition newEdge = (Transition)
                StateGraphDiagramView.MakeLink(UI.InsertionMode.TransitionEdge);

            //IGoPort fromPort = fromNode.FindShortestDistancePort((int)toNode.Presentation.Center.X, (int)toNode.Presentation.Center.Y);
            //IGoPort toPort = toNode.FindShortestDistancePort((int)fromNode.Presentation.Center.X, (int)fromNode.Presentation.Center.Y);
            //newEdge.FromPort = fromPort;
            //newEdge.ToPort = toPort;

            newEdge.FromPort = ((GoBasicNode)fromNode.Presentation).Port;
            newEdge.ToPort = ((GoBasicNode)toNode.Presentation).Port;

            //while (this.FindLink(StateGraphDiagramView.LastID) != null)
            //{
            //    StateGraphDiagramView.LastID++;
            //}
            ////newEdge.LinkID = StateGraphDiagramView.LinkCount;
            //StateGraphDiagramView.LastID++;
            //StateGraphDiagramView.LinkCount++;

            newEdge.FromLabel = CreateLabel("");
            newEdge.ToLabel = CreateLabel("");

            this.LinksLayer.Add(newEdge);

            this.FinishTransaction("Scheduling Edge is inserted.");
        }

        public void RemoveEdge(string fromVertex, string toVertex)
        {
            this.StartTransaction();

            Transition targetEdge = FindLink(fromVertex, toVertex);

            if (targetEdge != null)
                this.LinksLayer.Remove(targetEdge);

            this.FinishTransaction("Scheduling Edge is removed.");
        }

        private Transition FindLink(string fromVertex, string toVertex)
        {
            Transition target = null;
            
            foreach(GoObject obj in this){

                if (obj is Transition)
                {
                    Transition edge = (Transition)obj;

                    GoBasicNode fromNode = (GoBasicNode)edge.FromNode;
                    GoBasicNode toNode = (GoBasicNode)edge.ToNode;
                    if (fromNode.Text.Equals(fromVertex) &&
                         toNode.Text.Equals(toVertex))
                    {
                        target = edge;
                        break;
                    }
                }
            }
            return target;
        }

        //private ObjectSchedulingLink findEdge(string fromEventVertex, string toEventVertex)
        //{
        //    ObjectSchedulingLink targetEdge = null;
        //    foreach (GoObject obj in this)
        //    {
        //        if (obj is ObjectSchedulingLink)
        //        {
        //            ObjectSchedulingLink edge = (ObjectSchedulingLink)obj;

        //            GoTextNode fromNode = (GoTextNode)edge.FromNode;
        //            GoTextNode toNode = (GoTextNode)edge.ToNode;

        //            if (fromNode.Text.Equals(fromEventVertex) &&
        //                 toNode.Text.Equals(toEventVertex))
        //            {
        //                targetEdge = edge;
        //                break;
        //            }
        //        }
        //    }

        //    return targetEdge;
        //}

        public void ChangeEdgeType(string fromVertex, string toVertex, bool canceled)
        {
            this.StartTransaction();

            Transition targetEdge = null;
            targetEdge = FindLink(fromVertex, toVertex);

            if (targetEdge != null)
            {
                if (canceled)
                {
                    Pen cancelingPen = new Pen(Brushes.Black);
                    cancelingPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                    targetEdge.Pen = cancelingPen;
                }
                else
                {
                    Pen schedulingPen = new Pen(Brushes.Black);
                    schedulingPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                    targetEdge.Pen = schedulingPen;
                }
            }

            this.FinishTransaction("Scheduling Edge's Type is changed.");
        }

        public virtual int NumLinksBetween(IGoPort a, IGoPort b)
        {
            int count = 0;
            foreach (IGoLink l in a.DestinationLinks)
            {
                if (l.ToPort == b)
                    count++;
            }
            return count;
        }


        private GoText CreateLabel(string textValue)
        {
            GoText fromLabel = new GoText();
            fromLabel.FontSize = 8;
            fromLabel.EditableWhenSelected = false;
            fromLabel.Editable = false;
            fromLabel.Text = textValue;

            return fromLabel;
        }


    }
}
