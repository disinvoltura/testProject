﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.StateObjects;
using Northwoods.Go;

namespace DHKANG.SEA.UI.STTEditor
{
    public partial class StateObjectModelEditor : Form
    {
        #region Member Variables
        private StateTransitionTableWindow _STTWindow;
        private StateVariableWindow _SVWindow;
        private FunctionWindow _FunctionWindow;
        private StateGraphDiagramWindow _SGDWindow;
        private STTPropertiesWindow _PropertiesWindow;

        private OOSGStateObjectModel _AM;
        private bool _IsChanged; //
        private bool _IsUpdating;
        private WeifenLuo.WinFormsUI.Docking.VS2012LightTheme vS2012LightTheme1;
        private WeifenLuo.WinFormsUI.Docking.VS2015LightTheme vS2015LightTheme1;

        private NodeFactory _NodeFactory;
        #endregion

        #region Properties
        public bool IsModelChanged { get { return _IsChanged; } }

        public OOSGStateObjectModel StateObjectModel //AtomicModel 
        {
            get
            {
                OOSGStateObjectModel rslt = _AM;
                rslt.BackgroundColor = _AM.BackgroundColor;
                rslt.Description = _AM.Description;

                //States
                rslt.States.Clear();
                Dictionary<string, StateVertexNode> stateNodes = new Dictionary<string, StateVertexNode>();
                /*
                List<OOSGState> stateList = _StateWindow.States;
                foreach (OOSGState state in stateList)
                {
                    StateVertexNode node = (StateVertexNode)_SGDWindow.FindNode(state.Name);
                    stateNodes.Add(state.Name, node);
                    state.X = node.Presentation.Position.X;
                    state.Y = node.Presentation.Position.Y;
                    rslt.AddState(state);
                }
                */

                List<StateVertexNode> stateList = _SGDWindow.StateVertices;
                foreach (StateVertexNode stateNode in stateList)
                {
                    stateNodes.Add(stateNode.NodeName, stateNode);
                    stateNode.State.X = stateNode.Presentation.Position.X;
                    stateNode.State.Y = stateNode.Presentation.Position.Y;
                    rslt.AddState(stateNode.State);
                }

                //Messages
                rslt.Messages.Clear();
                /*
                List<OOSGMessage> messageList = _MessageWindow.Messages;
                foreach (OOSGMessage msg in messageList)
                {
                    if (!rslt.ContainsMessage(msg.MName))
                        rslt.AddMessage(msg);
                }
                */
                List<OOSGMessage> messageList = _SGDWindow.Messages;
                foreach (OOSGMessage msg in messageList)
                {
                    if (!rslt.ContainsMessage(msg.MName))
                        rslt.AddMessage(msg);
                }

                //Parameters
                rslt.Parameters.Clear();
                /*
                List<OOSGParameter> parameterList = _ParameterWindow.Parameters;
                foreach (OOSGParameter parameter in parameterList)
                    rslt.AddParameter(parameter);
                */

                List<OOSGParameter> parameterList = _SGDWindow.Parameters;
                foreach (OOSGParameter parameter in parameterList)
                    rslt.AddParameter(parameter);


                //StateVariables
                rslt.StateVariables.Clear();
                List<OOSGStateVariable> svList = _SVWindow.StateVariables;
                foreach (OOSGStateVariable sv in svList)
                    rslt.AddStateVariable(sv);

                //StateTransitions
                rslt.STT.Clear();
                foreach (OOSGStateTransition st in _STTWindow.StateTransitions)
                {
                    OOSGState curState = rslt.FindState(st.CurrentState.Name);
                    curState.EntryAction = st.EntryAction;
                    //rslt.States[st.CurrentState.Name].EntryAction = st.EntryAction;

                    StateVertexNode stateNode = stateNodes[curState.Name];

                    foreach (GoLabeledLink link in stateNode.Presentation.DestinationLinks)
                    {
                        StateVertexNode destNode = (StateVertexNode)link.ToNode.UserObject;

                        if (st.NextState.Name.Equals(destNode.NodeName))
                        {
                            st.FromPort = stateNode.FindPortIndex(link.FromPort);
                            st.ToPort = destNode.FindPortIndex(link.ToPort);
                            st.LinkStyle = (int)link.Style;
                            st.Curviness = link.Curviness;
                            st.Orthogonal = link.Orthogonal;
                            st.AdjustingStyle = (int)link.AdjustingStyle;

                            List<OOSGPoint> points = new List<OOSGPoint>();

                            for (int i = 0; i < link.RealLink.PointsCount; i++)
                            {
                                PointF pt = link.RealLink.GetPoint(i);
                                points.Add(new OOSGPoint(pt.X, pt.Y));
                            }

                            st.Points = points;

                            break;
                        }
                    }
                    rslt.STT.Add(st);
                }
                //rslt.STT.AddRange(_STTWindow.StateTransitions);

                //Schedules
                rslt.Schedules.Clear();
                foreach (OOMMSchedule s in _SGDWindow.Schedules)
                {
                    rslt.Schedules.Add(s);
                }

                //Fucntion
                rslt.Functions = _FunctionWindow.Functions;
                return rslt;
            }
        }

        public List<OOSGState> States { get { return _SGDWindow.States; } }

        public List<OOSGMessage> Messages { get { return _SGDWindow.Messages; } }

        public OOSGState InitialState { get { return _SGDWindow.InitialState; } }

        #endregion

        #region Constructors
        public StateObjectModelEditor(OOSGStateObjectModel am)
        {
            InitializeComponent();

            this.vS2012LightTheme1 = new WeifenLuo.WinFormsUI.Docking.VS2012LightTheme();
            this.vS2015LightTheme1 = new WeifenLuo.WinFormsUI.Docking.VS2015LightTheme();
            dockPanel1.Theme = vS2015LightTheme1;

            _AM = am;
            _IsChanged = false;

            CreateLayout();

            _NodeFactory = new NodeFactory();
            _NodeFactory.Document = _SGDWindow.View.Doc;

            _SGDWindow.NodeFactory = _NodeFactory;

            _IsUpdating = true;

            _STTWindow.Update(am);
            _SGDWindow.Update(am);
            _SVWindow.Update(am);
            _FunctionWindow.Update(am);

            _IsUpdating = false;

            this.Text = _AM.Name + " ::: State Object Model Editor";
        }
        #endregion

        #region Methods
        private void CreateLayout()
        {
            _SGDWindow = new StateGraphDiagramWindow(this);
            _SGDWindow.Show(dockPanel1, DockState.Document);
            _SGDWindow.DockHandler.AllowEndUserDocking = true;
            _SGDWindow.DockHandler.CloseButtonVisible = false;
            _SGDWindow.DockHandler.CloseButton = false;
            _SGDWindow.View.DocumentChanged += new GoChangedEventHandler(OnDocumentChanged);
            _SGDWindow.ObjectSelected += OnSGDWindow_ObjectSelected;

            dockPanel1.DockBottomPortion = 0.5;

            _STTWindow = new StateTransitionTableWindow(this);
            _STTWindow.Show(dockPanel1, DockState.DockBottom);
            //_STTWindow.Show(dockPanel1, DockState.Document);
            _STTWindow.DockHandler.AllowEndUserDocking = false;
            _STTWindow.DockHandler.CloseButtonVisible = false;
            _STTWindow.DockHandler.CloseButton = false;
            
            _SVWindow = new StateVariableWindow(this);
            _SVWindow.Show(dockPanel1, DockState.DockBottom);
            _SVWindow.DockHandler.CloseButtonVisible = false;
            _SVWindow.DockHandler.CloseButton = false;

            _FunctionWindow = new FunctionWindow(this);
            _FunctionWindow.Show(dockPanel1, DockState.DockBottom);
            _FunctionWindow.DockHandler.CloseButtonVisible = false;
            _FunctionWindow.DockHandler.CloseButton = false;

            _PropertiesWindow = new STTPropertiesWindow(this);
            _PropertiesWindow.Show(dockPanel1, DockState.DockBottom);
            _PropertiesWindow.DockHandler.AllowEndUserDocking = true;
            _PropertiesWindow.DockHandler.CloseButtonVisible = false;
            _PropertiesWindow.DockHandler.CloseButton = false;

            _SGDWindow.Changed += new StateGraphDiagramChangedEvent(_STTWindow.OnChanged);
            _SGDWindow.Changed += new StateGraphDiagramChangedEvent(OnChanged);
            _FunctionWindow.Changed += new ChangedEventHandler(OnChanged);

            _SVWindow.Changed += new ChangedEventHandler(OnChanged);

            _STTWindow.Changed += new StateTransitionTableChangedEvent(_SGDWindow.OnSTTChanged);
            _STTWindow.Changed += new StateTransitionTableChangedEvent(OnSTTChanged);
            _SGDWindow.Changed += new StateGraphDiagramChangedEvent(_STTWindow.OnSGDChanged);

            _STTWindow.Activate();
        }

        private void OnChanged(ChangedTarget targetType,
                                              ChangedType changedType,
                                              object before, object after)
        {
            if (_IsUpdating)
                return;

            _IsChanged = true;

            if (targetType == ChangedTarget.StateVariable)
            {
                //우선 Atomic Model 을 변경
                if (changedType == ChangedType.Added)
                {
                    OOSGStateVariable newSV = (OOSGStateVariable)after;
                    _AM.AddStateVariable(newSV);
                }
                else if (changedType == ChangedType.Deleted)
                {
                    OOSGStateVariable oldSV = (OOSGStateVariable)before;
                    _AM.RemoveStateVariable(oldSV.Name);
                }
                else if (changedType == ChangedType.Modified)
                {
                    OOSGStateVariable newSV = (OOSGStateVariable)after;
                    OOSGStateVariable oldSV = (OOSGStateVariable)before;
                    _AM.ChangeStateVariable(oldSV, newSV);
                }
                //이에 따른 다른 model 및 view에 변경
                //_Parent.OnStateVariableChanged(_AM.Name, changedType, before, after);
            }
            else if (targetType == ChangedTarget.Parameter)
            {
                //우선 Atomic Model 을 변경
                if (changedType == ChangedType.Added)
                {
                    OOSGParameter newPM = (OOSGParameter)after;
                    _AM.AddParameter(newPM);
                }
                else if (changedType == ChangedType.Deleted)
                {
                    OOSGParameter oldPM = (OOSGParameter)before;
                    _AM.RemoveParameter(oldPM.Name);
                }
                else if (changedType == ChangedType.Modified)
                {
                    OOSGParameter newPM = (OOSGParameter)after;
                    OOSGParameter oldPM = (OOSGParameter)before;
                    _AM.ChangeParameter(oldPM, newPM);
                }
                //이에 따른 다른 model 및 view에 변경
                //_Parent.OnParameterChanged(_AM.Name, changedType, before, after);
            }
            else if (targetType == ChangedTarget.Message)
            {
                if (changedType == ChangedType.Deleted)
                {
                    OOSGMessage oldMsg = (OOSGMessage)before;
                    _AM.RemoveMessage(oldMsg.MName);
                }
                else if (changedType == ChangedType.Modified)
                {
                    OOSGMessage oldMsg = (OOSGMessage)before;
                    OOSGMessage newMsg = (OOSGMessage)after;

                    _AM.ChangeMessage(oldMsg, newMsg);
                }
                //_Parent.OnMessageChanged(_AM.Name, changedType, before, after);
            }
        }

        /// <summary>
        /// 해당 이름을 가진 Input Message 가 State Transition Table 에 사용 중이면 true, 그렇지 않으면 false를 반환한다.
        /// </summary>
        /// <param name="messageName"></param>
        /// <returns></returns>
        public bool IsInputEventUsed(string messageName)
        {
            return _STTWindow.IsInputEventUsed(messageName);
        }

        public bool IsStateUsed(string stateName)
        {
            return _STTWindow.IsStateUsed(stateName);
        }


        private void AMControl_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_IsChanged)
                this.DialogResult = System.Windows.Forms.DialogResult.OK;
            else
                this.DialogResult = System.Windows.Forms.DialogResult.Cancel;

            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void OnSTTChanged(ChangedTarget target, ChangedType action, object before, object after)
        {
            _IsChanged = true;
        }

        private void OnSGDWindow_ObjectSelected(OOMMModel model, object target)
        {
            _PropertiesWindow.Update(model, target);
        }

        private void OnDocumentChanged(object sender, GoChangedEventArgs e)
        {
            _IsChanged = true;
        }
        #endregion

    }
}
