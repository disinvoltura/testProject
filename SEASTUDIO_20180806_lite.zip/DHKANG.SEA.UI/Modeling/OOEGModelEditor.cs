﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DHKANG.OOEG.Model;
using WeifenLuo.WinFormsUI.Docking;
using System.Xml.Serialization;
using System.IO;
using DHKANG.OOEG.UI.OutputViews;
using DHKANG.OOEG.UI.Modeling;
using DHKANG.OOEG.UI.OutputView;
using DHKANG.OOEG.Model.Charts;

namespace DHKANG.OOEG.UI
{
    public partial class OOEGModelEditor : Form
    {
        #region Member Variables - Model Properties
        private string _Name = string.Empty;
        private string _Description = string.Empty;
        private string _Creator = string.Empty;
        #endregion

        #region Member Variables - Saving
        private string _FileName;
        private bool _IsChanged;
        #endregion

        #region Membe Variables - UI Components
        private Dictionary<string, DataEditorWindow> _DataEditorWindows;
        private OOEGDiagramWindow _DiagramWindow;
        private OutputWindow _OutputWindow;
        private ErrorWindow _ErrorWindow;
        private SpreadsheetWindow _SpreadsheetWindow;

        private ModelExplorerWindow _ModelExplorerWindow;
        private EventObjectTemplateWindow _EventObjectTemplateWindow;
        //private DataSourceWindow _DataSourceWindow;
        private OutputViewLibraryWindow _OutputViewLibraryWindow;
        private PropertiesWindow _PropertiesWindow;
        private PropertyWindow _PropertyWindow;//for output view, late change to PropertiesView
        //private EntityWindow _EntityWindow;

        private WeifenLuo.WinFormsUI.Docking.VS2012LightTheme vS2012LightTheme1;
        private WeifenLuo.WinFormsUI.Docking.VS2015LightTheme vS2015LightTheme1;
        
        #endregion

        #region Properties
        public string CurrentModelName
        {
            get { return _Name; }
        }

        public bool IsChanged
        {
            get { return _IsChanged; }
        }
        public string FileName
        {
            get { return _FileName; }
        }

        public List<OOEGEntity> CurrentEntities 
        {
            get { return Modeling.EntityManager.GetEntities(CurrentModelName); }
        }
        #endregion

        #region Constructors
        public OOEGModelEditor()
        {
            InitializeComponent();

            this.vS2012LightTheme1 = new WeifenLuo.WinFormsUI.Docking.VS2012LightTheme();
            this.vS2015LightTheme1 = new WeifenLuo.WinFormsUI.Docking.VS2015LightTheme();
            dockPanel1.Theme = vS2015LightTheme1;
            //dockPanel1.Theme = vS2012LightTheme1;

            _DataEditorWindows = new Dictionary<string, DataEditorWindow>();
            updateTitle();
            createDockableWindows();
        }

        public OOEGModelEditor(string name, string desc, string creator)
            : this()
        {
            _Name = name;
            _Description = desc;
            _Creator = creator;

            updateTitle();
        }
        #endregion

        #region Methods
        private bool _IsUpdating = false;
        public void Open(string fileName)
        {
            _IsUpdating = true;
            _FileName = fileName;

            OOEGEventGraphModel model = null;
            model = OOEGEventGraphModelFactory.Open(_FileName);
            if (model == null)
            {
                MessageBox.Show(this, "Cannot read the model from the file", "Error");
                return;
            }
                
            //Model Header
            _Name = model.Name;
            _Description = model.Description;
            _Creator = model.Creator;

            _DiagramWindow.Open(model);
            _ErrorWindow.CheckSyntax(model);
            //_EntityWindow.Update(model);
            _ModelExplorerWindow.Update(model);

            Modeling.EntityManager.SetEntities (_Name, model.Entities);

            updateTitle();

            _IsUpdating = false; 
        }

        public OOEGEventGraphModel BuildModel()
        {
            //Model Building
            OOEGEventGraphModel model = new OOEGEventGraphModel(_Name, _Description, _Creator);
            //추후 기존 model 재활용하는 방안으로 변경

            //TODO - 2015/08/09
            //Node: Node 와 Event Object Model 분리
            List<OOEGEventObjectModel> eventObjects = new List<OOEGEventObjectModel>();
            List<Node> nodelist = _DiagramWindow.GetEventObjectNodes();
            foreach (Node n in nodelist)
            {
                if (n is EventObjectNode)
                {
                    EventObjectNode eoNode = (EventObjectNode)n;

                    model.EventObjectNodes.Add(
                        new OOEGEventObjectNode(
                                eoNode.Model.ID, 
                                eoNode.NodeName, 
                                eoNode.Presentation.Position.X, 
                                eoNode.Presentation.Position.Y, 
                                eoNode.BackgroundColor.ToArgb()));

                    eventObjects.Add(eoNode.Model);
                }
            }

            List<DataSourceNode> dsNodeList = _DiagramWindow.GetDataSourceNodes();
            foreach (DataSourceNode n in dsNodeList)
            {
                OOEGDataSourceNode dsNode = 
                    new OOEGDataSourceNode(n.DataSource.ID, n.DataSource.Name, n.Position.X, n.Position.Y);
                
                model.DataSourceNodes.Add(dsNode);
            }

            List<TextNode> textNodeList = _DiagramWindow.GetTextNodes();
            foreach (TextNode n in textNodeList)
            {
                OOEGTextNode tn =
                    new OOEGTextNode(
                        n.TextValue,
                        n.Position.X,
                        n.Position.Y);

                tn.FontBold = n.Font.Bold;
                tn.FontItalic = n.Font.Italic;
                tn.FontName = n.Font.Name;
                tn.FontSize = n.Font.Size;
                tn.FontStrikeout = n.Font.Strikeout;
                tn.FontUnderline = n.Font.Underline;
                tn.FontColor = n.TextColor.ToArgb();

                model.Texts.Add(tn);
            }

            List<LabelNode> labelNodeList = _DiagramWindow.GetLabelNodes();
            foreach (LabelNode n in labelNodeList)
            {
                OOEGLabelNode ln =
                    new OOEGLabelNode(
                        n.NodeID,
                        n.LabelName,
                        n.EventObjectID,
                        n.StateVariableName,
                        n.Position.X,
                        n.Position.Y);

                ln.FontBold = n.Font.Bold;
                ln.FontItalic = n.Font.Italic;
                ln.FontName = n.Font.Name;
                ln.FontSize = n.Font.Size;
                ln.FontStrikeout = n.Font.Strikeout;
                ln.FontUnderline = n.Font.Underline;
                ln.FontColor = n.TextColor.ToArgb();

                model.Labels.Add(ln);
            }

            List<DataSetNode> datasetNodeList = _DiagramWindow.GetDataSetNodes();
            foreach (DataSetNode n in datasetNodeList)
            {
                OOEGDataSetNode ln =
                    new OOEGDataSetNode(
                        n.NodeID,
                        n.DataSetName,
                        n.XAxsisValue,
                        n.YAxisValue,
                        n.Description,
                        n.Position.X,
                        n.Position.Y);

                model.DataSetNodes.Add(ln);
            }

            List<StatisticsNode> statisticsNodeList = _DiagramWindow.GetStatisticsNodes();
            foreach (StatisticsNode n in statisticsNodeList)
            {
                OOEGStatisticsNode ln =
                    new OOEGStatisticsNode(
                        n.NodeID,
                        n.StatisticsName,
                        n.Source,
                        n.Type,
                        n.Description,
                        n.Position.X,
                        n.Position.Y);

                model.StatisticsNodes.Add(ln);
            }

            List<BarChart> barchartList = _DiagramWindow.GetBarChartNodes();
            foreach (BarChart n in barchartList)
            {
                OOEGSeriesCollection col = new OOEGSeriesCollection();

                foreach (string seriesName in n.Series.SeriesNames)
                {
                    Series s = n.Series[seriesName];

                    OOEGSeriesChartType scType = OOEGSeriesChartType.Bar;
                    /*
                    if (s.ChartType == SeriesChartType.Line)
                        scType = OOEGSeriesChartType.Line;
                    else if (s.ChartType == SeriesChartType.Spline)
                        scType = OOEGSeriesChartType.Spline;
                    else if (s.ChartType == SeriesChartType.StepLine)
                        scType = OOEGSeriesChartType.StepLine;
                    */

                    OOEGMarkerType mType = OOEGMarkerType.None;
                    /*
                    if (s.MarkerType == MarkerType.Diamond)
                        mType = OOEGMarkerType.Diamond;
                    else if (s.MarkerType == MarkerType.Oval)
                        mType = OOEGMarkerType.Oval;
                    else if (s.MarkerType == MarkerType.Rectangle)
                        mType = OOEGMarkerType.Rectangle;
                    else if (s.MarkerType == MarkerType.Triangle)
                        mType = OOEGMarkerType.Triangle;
                    */ 
                    OOEGSeriesAppearance app =
                        new OOEGSeriesAppearance(s.LineWidth, s.BackgroundColor, s.MarkerColor, s.LineColor, mType );
                    OOEGSeries ns = new OOEGSeries(s.Name, s.Value, scType, app);

                    col.Add(ns);
                }

                OOEGBarChart ln = new OOEGBarChart(n.ChartTitle, col, n.Left, n.Top, n.Width, n.Height);
                ln.Appearance = new OOEGChartAppearance(n.BackgroundColor, n.BorderColor, n.BorderWeight);

                model.BarCharts.Add(ln);
            }

            List<PieChart> piechartList = _DiagramWindow.GetPieChartNodes();
            foreach (PieChart n in piechartList)
            {
                OOEGSeriesCollection col = new OOEGSeriesCollection();

                foreach (string seriesName in n.Series.SeriesNames)
                {
                    Series s = n.Series[seriesName];

                    OOEGSeriesChartType scType = OOEGSeriesChartType.Bar;
                    OOEGMarkerType mType = OOEGMarkerType.None;
                    OOEGSeriesAppearance app = 
                        new OOEGSeriesAppearance(s.LineWidth, s.BackgroundColor, s.MarkerColor, s.LineColor, mType );
                    OOEGSeries ns = new OOEGSeries(s.Name, s.Value, scType, app);

                    col.Add(ns);
                }

                OOEGPieChart ln = new OOEGPieChart(n.ChartTitle, col, n.Left, n.Top, n.Width, n.Height);
                ln.Appearance = new OOEGChartAppearance(n.BackgroundColor, n.BorderColor, n.BorderWeight);

                model.PieCharts.Add(ln);
            }

            List<Plot> plotList = _DiagramWindow.GetPlotNodes();
            foreach (Plot n in plotList)
            {
                OOEGSeriesCollection col = new OOEGSeriesCollection();

                foreach (string seriesName in n.Series.SeriesNames)
                {
                    Series s = n.Series[seriesName];

                    OOEGSeriesChartType scType = OOEGSeriesChartType.Bar;
                    if (s.ChartType == SeriesChartType.Line)
                        scType = OOEGSeriesChartType.Line;
                    else if (s.ChartType == SeriesChartType.Spline)
                        scType = OOEGSeriesChartType.Spline;
                    else if (s.ChartType == SeriesChartType.StepLine)
                        scType = OOEGSeriesChartType.StepLine;

                    OOEGMarkerType mType = OOEGMarkerType.None;
                    if (s.MarkerType == MarkerType.Diamond)
                        mType = OOEGMarkerType.Diamond;
                    else if (s.MarkerType == MarkerType.Oval)
                        mType = OOEGMarkerType.Oval;
                    else if (s.MarkerType == MarkerType.Rectangle)
                        mType = OOEGMarkerType.Rectangle;
                    else if (s.MarkerType == MarkerType.Triangle)
                        mType = OOEGMarkerType.Triangle;
                    OOEGSeriesAppearance app = 
                        new OOEGSeriesAppearance(
                                s.LineWidth, s.BackgroundColor, 
                                s.MarkerColor, s.LineColor, mType);
                    OOEGSeries ns = new OOEGSeries(s.Name, s.Value, scType, app);

                    col.Add(ns);
                }

                OOEGPlot ln = new OOEGPlot(n.ChartTitle, col, n.Left, n.Top, n.Width, n.Height);
                ln.Appearance = new OOEGChartAppearance(n.BackgroundColor, n.BorderColor, n.BorderWeight);

                model.Plots.Add(ln);
            }

            List<TimePlot> timePlotList = _DiagramWindow.GetTimePlotNodes();
            foreach (TimePlot n in timePlotList)
            {
                OOEGSeriesCollection col = new OOEGSeriesCollection();

                foreach (string seriesName in n.Series.SeriesNames)
                {
                    Series s = n.Series[seriesName];

                    OOEGSeriesChartType scType = OOEGSeriesChartType.Bar;
                    if (s.ChartType == SeriesChartType.Line)
                        scType = OOEGSeriesChartType.Line;
                    else if (s.ChartType == SeriesChartType.Spline)
                        scType = OOEGSeriesChartType.Spline;
                    else if (s.ChartType == SeriesChartType.StepLine)
                        scType = OOEGSeriesChartType.StepLine;

                    OOEGMarkerType mType = OOEGMarkerType.None;
                    if (s.MarkerType == MarkerType.Diamond)
                        mType = OOEGMarkerType.Diamond;
                    else if (s.MarkerType == MarkerType.Oval)
                        mType = OOEGMarkerType.Oval;
                    else if (s.MarkerType == MarkerType.Rectangle)
                        mType = OOEGMarkerType.Rectangle;
                    else if (s.MarkerType == MarkerType.Triangle)
                        mType = OOEGMarkerType.Triangle;
                    OOEGSeriesAppearance app =
                        new OOEGSeriesAppearance(
                                s.LineWidth, s.BackgroundColor,
                                s.MarkerColor, s.LineColor, mType);
                    OOEGSeries ns = new OOEGSeries(s.Name, s.Value, scType, app);

                    col.Add(ns);
                }

                OOEGTimePlot ln = new OOEGTimePlot(n.ChartTitle, col, n.Left, n.Top, n.Width, n.Height);
                ln.Appearance = new OOEGChartAppearance(n.BackgroundColor, n.BorderColor, n.BorderWeight);

                model.TimePlots.Add(ln);
            }

            //Edges
            List<Link> linklist = _DiagramWindow.GetLinks();
            foreach (Link n in linklist)
            {
                if (n.LinkType == LinkType.SchedulingLink)
                {
                    Model.OOEGEventObjectSchedulingEdge link =
                    new OOEGEventObjectSchedulingEdge();

                    ObjectSchedulingLink osl = (ObjectSchedulingLink)n;

                    link.ID = osl.LinkID;
                    
                    link.MirrorEventObject = ((EventObjectNode)((MultiPortNode)osl.FromNode).UserObject).NodeGuid;
                    link.MirrorEventName = osl.FromEventName;
                    link.MirrorEventPort = ((MultiPortNode)n.FromNode).FindPortIndex(n.FromPort);                    

                    link.BoundaryEventObject = ((EventObjectNode)((MultiPortNode)osl.ToNode).UserObject).NodeGuid;
                    link.BoundaryEventName = osl.ToEventName;
                    link.BoundaryEventPort = ((MultiPortNode)n.ToNode).FindPortIndex(n.ToPort);

                    link.Parameters = osl.Parameters;
                    link.StrokeStyle = (int)n.Style;

                    model.EventObjectSchedulingEdges.Add(link);
                }
                else if (n.LinkType == LinkType.DataAssociationLink)
                {
                    Model.OOEGDataAssociationEdge link = new OOEGDataAssociationEdge();

                    DataAssociationLink dal = (DataAssociationLink)n;

                    link.ID = dal.LinkID;

                    link.SourceDataSource = ((DataSourceNode)dal.FromNode).DataSource.ID;
                    link.SourcePort = ((DataSourceNode)dal.FromNode).FindPortIndex(dal.FromPort);

                    link.TargetEventObject = ((EventObjectNode)((MultiPortNode)dal.ToNode).UserObject).NodeGuid;
                    link.TargetPort = ((MultiPortNode)n.ToNode).FindPortIndex(n.ToPort);

                    link.StrokeStyle = (int)n.Style;

                    foreach(OOEGDataMapper mapper in dal.DataMappers)
                    {
                        link.AddDataMapper(mapper);
                    }

                    model.DataAssociations.Add(link);
                }
                
            }

            //Event Object Models
            //List<OOEGEventObjectModel> eventObjects = _EventObjectTemplateWindow.EventObjects;
            model.EventObjectModels = eventObjects;

            //Templates
            //commented out @2016/10/24
            //List<OOEGTemplate> templates = _EventObjectTemplateWindow.Templates;
            //model.Templates = templates;
            
            //Entities
            List<OOEGEntity> entities = Modeling.EntityManager.GetEntities(_Name);
            //List<OOEGEntity> entities = Modeling.EntityManager.Entities;
            model.Entities = entities;

            //Data Sources
            List<OOEGDataSource> dataSources = _ModelExplorerWindow.GetDataSources(_Name);
            //List<OOEGDataSource> dataSources = _ModelExplorerWindow.DataSources;
            model.DataSources = dataSources;

            List<OOEGExperiment> experiments = _ModelExplorerWindow.GetExperiments(_Name);
            //List<OOEGExperiment> experiments = _ModelExplorerWindow.Experiments;
            model.Experiments = experiments;
            
            //Properties
            OOEGModelProperty p1 = 
                new OOEGModelProperty(
                    "ViewScale", 
                    _DiagramWindow.ViewScale);

            model.Properties.Add(p1);

            return model;
        }


        private void setChange(bool value)
        {
            _IsChanged = value;
            updateTitle();
        }

        public void GoTo(string eventObjectName)
        {
            _DiagramWindow.GoTo(eventObjectName);
        }

        public bool Save()
        {
            if (string.IsNullOrEmpty(_FileName))
                return false;

            OOEGEventGraphModel model = BuildModel();
            XmlSerializer serializer = new XmlSerializer(typeof(OOEGEventGraphModel));
            using (TextWriter writer = new StreamWriter(_FileName))
            {
                serializer.Serialize(writer, model);
            }

            setChange(false);

            _ErrorWindow.CheckSyntax(model);

            return false;
        }

        public bool SaveAs(string fileName)
        {
            //TODO
            _FileName = fileName;

            return Save();
        }

        public bool CheckSyntax()
        {
            OOEGEventGraphModel model = BuildModel();
            return _ErrorWindow.CheckSyntax(model);
        }

        public bool CheckSyntax(OOEGEventGraphModel model)
        {
            return _ErrorWindow.CheckSyntax(model);
        }

        private void updateTitle()
        {
            if (_IsChanged)
                this.Text = "OOEG Model Editor ::: " + _Name + "*";
            else
                this.Text = "OOEG Model Editor ::: " + _Name;

            if (_DiagramWindow != null)
                _DiagramWindow.Text = _Name;
        }

        private void createDockableWindows()
        {
            _DiagramWindow = new OOEGDiagramWindow();
            _DiagramWindow.Show(dockPanel1, DockState.Document);
            _DiagramWindow.DockHandler.AllowEndUserDocking = false;
            _DiagramWindow.DockHandler.CloseButtonVisible = false;
            _DiagramWindow.DockHandler.CloseButton = false;
            _DiagramWindow.SelectionChanged += new DiagramSelectionChangedEventHandler(_DiagramWindow_SelectionChanged);
            //_DiagramWindow.Changed += new DiagramChangedEvent(OnDiagramWindowChanged);
            _DiagramWindow.DiagramChanged += new DiagramChangedEventHandler(OnDiagramWindowChanged);

            _ErrorWindow = new ErrorWindow(this);
            //_ErrorWindow.Show(_OutputWindow.Pane, _OutputWindow);
            _ErrorWindow.Show(_DiagramWindow.Pane, DockAlignment.Bottom, 0.20);
            //_ErrorWindow.Show(_DiagramWindow.Pane, DockAlignment.Bottom, 0.20);
            //_ErrorWindow.Show(dockPanel1, DockState.DockBottom);
            //_ErrorWindow.Show(_DiagramWindow.Pane, DockAlignment.Bottom, 0.20);
            _ErrorWindow.DockHandler.CloseButtonVisible = false;
            _ErrorWindow.DockHandler.CloseButton = false;

            _OutputWindow = new OutputWindow();
            _OutputWindow.Show(_ErrorWindow.Pane, _ErrorWindow);
            //_OutputWindow.Show(_DiagramWindow.Pane, DockAlignment.Bottom, 0.20);
            //_OutputWindow.Show(dockPanel1, DockState.DockBottom);
            //_OutputWindow.Show(_DiagramWindow.Pane, DockAlignment.Bottom, 0.20);
            _OutputWindow.DockHandler.CloseButtonVisible = false;
            _OutputWindow.DockHandler.CloseButton = false;

            /*
            _SpreadsheetWindow = new SpreadsheetWindow();
            //_SpreadsheetWindow.Show(dockPanel1, DockState.DockBottom);
            _SpreadsheetWindow.Show(_OutputWindow.Pane, DockAlignment.Right, 0.56);
            _SpreadsheetWindow.DockHandler.CloseButtonVisible = false;
            _SpreadsheetWindow.DockHandler.CloseButton = false;
            _SpreadsheetWindow.DiagramWindow = _DiagramWindow;
            _SpreadsheetWindow.ValueChangeController.ValueChanged +=
                new SpreadsheetValueChangedEventHandler(OnSpreadsheetValueChanged);
            _SpreadsheetWindow.ObjectSelected += new SpreadsheetObjectSelectedEvent(OnSpreadsheetObjectSelected);
            */

            _PropertiesWindow = new PropertiesWindow();
            //_PropertiesWindow.Show(_SpreadsheetWindow.Pane, _SpreadsheetWindow);
            _PropertiesWindow.Show(_OutputWindow.Pane, DockAlignment.Right, 0.56);
            _PropertiesWindow.DockHandler.CloseButtonVisible = false;
            _PropertiesWindow.DockHandler.CloseButton = false;
            _PropertiesWindow.EntityProperties.EntityChanged += new EntityChangedEventHandler(OnEntityWindowChanged);
            _PropertiesWindow.CSVDataSourceProperties.DataSourceChanged += new DataSourceChangedEventHandler(OnDataSourceChanged);
            _PropertiesWindow.ExcelDataSourceProperties.DataSourceChanged += new DataSourceChangedEventHandler(OnDataSourceChanged);
            _PropertiesWindow.DBDataSourceProperties.DataSourceChanged += new DataSourceChangedEventHandler(OnDataSourceChanged);
            _DiagramWindow.ObjectSelected += new DiagramObjectSelectedEventHandler(_PropertiesWindow.Update);

            /*
            _DataEditorWindow = new DataEditorWindow();
            _DataEditorWindow.Show(dockPanel1, DockState.Document);
            //_DataEditorWindow.Show(_OutputWindow.Pane, DockAlignment.Right, 0.56);
            _DataEditorWindow.DockHandler.CloseButtonVisible = false;
            _DataEditorWindow.DockHandler.CloseButton = false;
            */
            /*
            _EntityWindow = new EntityWindow();
            _EntityWindow.Show(_SpreadsheetWindow.Pane, _SpreadsheetWindow);
            _EntityWindow.DockHandler.CloseButtonVisible = false;
            _EntityWindow.DockHandler.CloseButton = false;
            _EntityWindow.EntityChanged += new EntityChangedEventHandler(OnEntityWindowChanged);
            */

 
            /////////////////////////////////////////////////////////////////////////////////

            _ModelExplorerWindow = new ModelExplorerWindow(this);
            _ModelExplorerWindow.Show(dockPanel1, DockState.DockLeft);
            //_ModelExplorerWindow.Show(dockPanel1, DockState.DockRight);
            _ModelExplorerWindow.DockHandler.CloseButtonVisible = false;
            _ModelExplorerWindow.DockHandler.CloseButton = false;
            //_DiagramWindow.Changed += new DiagramChangedEvent(_ModelExplorerWindow.OnModelChanged);
            _DiagramWindow.DiagramChanged += new DiagramChangedEventHandler(_ModelExplorerWindow.OnDiagramChanged);
            _ModelExplorerWindow.GoTo += new GoToRequestedEventHandler(_DiagramWindow.GoTo);
            _ModelExplorerWindow.ObjectSelected += new ObjectSelectedEventHandler(_PropertiesWindow.Update);
            _ModelExplorerWindow.EditorOpenRequested += new EditorOpenRequestEventHandler(OnEditorOpenRequested);
            //_ModelExplorerWindow.EntitySelected += new EntitySelectedEventHandler(_EntityWindow.ShowEntity);
            _PropertiesWindow.EntityProperties.EntityChanged += new EntityChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.CSVDataSourceProperties.DataSourceChanged += new DataSourceChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.ExcelDataSourceProperties.DataSourceChanged += new DataSourceChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.DBDataSourceProperties.DataSourceChanged += new DataSourceChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.SimulationExperimentProperties.ExperimentChanged += new ExperimentChangedEventHandler(_ModelExplorerWindow.Update);
            _PropertiesWindow.ModelProperties.PropertyChanged += new ModelPropertiesChangedEventHandler(OnModelPropertyChanged);
            _PropertiesWindow.ModelProperties.PropertyChanged += new ModelPropertiesChangedEventHandler(_ModelExplorerWindow.Update);
            //_EntityWindow.EntityChanged += new EntityChangedEventHandler(_ModelExplorerWindow.Update);

            /*
            _PropertyWindow = new PropertyWindow();
            _PropertyWindow.Show(dockPanel1, DockState.DockLeft);
            //_PropertyWindow.Show(dockPanel1, DockState.DockRight);
            _PropertyWindow.DockHandler.CloseButtonVisible = false;
            _PropertyWindow.DockHandler.CloseButton = false;
            */
            /////////////////////////////////////////////////////////////////////////////////

            _EventObjectTemplateWindow = new EventObjectTemplateWindow();
            _EventObjectTemplateWindow.Show(dockPanel1, DockState.DockLeft);
            _EventObjectTemplateWindow.DockHandler.CloseButtonVisible = false;
            _EventObjectTemplateWindow.DockHandler.CloseButton = false;

            /*
            _DataSourceWindow = new DataSourceWindow();
            _DataSourceWindow.Show(dockPanel1, DockState.DockLeft);
            _DataSourceWindow.DockHandler.CloseButtonVisible = false;
            _DataSourceWindow.DockHandler.CloseButton = false;
            */

            _OutputViewLibraryWindow = new OutputViewLibraryWindow();
            _OutputViewLibraryWindow.Show(dockPanel1, DockState.DockLeft);
            _OutputViewLibraryWindow.DockHandler.CloseButtonVisible = false;
            _OutputViewLibraryWindow.DockHandler.CloseButton = false;

            _EventObjectTemplateWindow.Show();
            _ModelExplorerWindow.Show();
            _DiagramWindow.Show();
        }

        private void _DiagramWindow_SelectionChanged(string selectionType, string objectType)
        {
            //_SpreadsheetWindow.Update(selectionType, objectType);
        }

        private void OnSpreadsheetValueChanged(string type, int id, string propertyName, string newValue)
        {
            //모든 정보는 Diagram 에 가지고 있으므로, Diagram 내에서 수정하면 됨
            _DiagramWindow.ChangeProperty(type, id, propertyName, newValue);
        }

        private void OnSpreadsheetObjectSelected(string type, int id)
        {
            _DiagramWindow.GoTo(type, id);
        }

        private void OnDiagramWindowChanged(DiagramChangeType type, string modelName, object changedObject, object oldObject)
        {
            if (_IsUpdating)
                return;

            setChange(true);
        }

        private void OnEntityWindowChanged(OOEGEntity changedEntity)
        {
            if (_IsUpdating)
                return;

            setChange(true);
        }

        private void OnDataSourceChanged(OOEGDataSource ds)
        {
            if (_IsUpdating)
                return;

            setChange(true);
        }

        private void OnModelPropertyChanged(ModelPropertyType type, string modelName, string oldValue, string newValue)
        {
            if (type == ModelPropertyType.Name)
            {
                _Name = newValue;
            }else if (type == ModelPropertyType.Description)
            {
                _Description = newValue;
            }else if (type == ModelPropertyType.Creator)
            {
                _Creator = newValue;
            }

            updateTitle();
        }

        private void OnEditorOpenRequested(string objectName, object objectValue)
        {
            if (objectValue is OOEGDataSource)
            {
                OOEGDataSource ds = (OOEGDataSource)objectValue;

                if (_DataEditorWindows.ContainsKey(ds.Name))
                {
                    DataEditorWindow window = _DataEditorWindows[ds.Name];
                    window.UpdateData();
                    window.Focus();
                    window.BringToFront();
                    window.Activate();
                }
                else
                {
                    //open Data Source Editor 
                    DataEditorWindow window = new DataEditorWindow(ds);

                    window.Show(dockPanel1, DockState.Document);
                    window.DockHandler.AllowEndUserDocking = false;
                    window.DockHandler.CloseButtonVisible = true;
                    window.DockHandler.CloseButton = true;
                    window.FormClosed += DataEditorWindow_FormClosed;

                    _DataEditorWindows.Add(ds.Name, window);
                }
            }
            else if (objectValue is OOEGEventObjectModel)
            {
                //TODO open ETT editor
            }
        }

        private void DataEditorWindow_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (sender is DataEditorWindow)
            {
                string dsName = ((DataEditorWindow)sender).Text;
                if (_DataEditorWindows.ContainsKey(dsName))
                    _DataEditorWindows.Remove(dsName);
            } 
        }

        private void OOEGModelEditor_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_IsChanged)
            {
                DialogResult result = MessageBox.Show("Do you want to save the modified model before close the model?", "Confirm Message", MessageBoxButtons.YesNoCancel);
                if (result == DialogResult.Yes)
                {
                    Save();
                    e.Cancel = false;
                }
                else if (result == DialogResult.Cancel)
                    e.Cancel = true;
                else
                    e.Cancel = false;
            }
        }

        #endregion
    }
}
