﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DHKANG.SEA.UI
{
    public partial class D_Properties : Form
    {
        #region Properties
        public string ModelName
        {
            get { return txtName.Text; }
        }
        public string ModelDescription
        {
            get { return txtDesc.Text; }
        }
        public string ModelCreator
        {
            get { return txtCreator.Text; }
        }
        #endregion

        #region constructors
        public D_Properties()
        {
            InitializeComponent();
        }

        public D_Properties(string name, string desc, string creator)
            : this()
        {
            txtName.Text = name;
            txtDesc.Text = desc;
            txtCreator.Text = creator;
        }
        #endregion

        #region Button Click Event Handlers
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtName.Text))
                return;

            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }
        #endregion

        private void PropertieDialog_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                btnOK_Click(sender, new System.EventArgs());
            else if (e.KeyCode == Keys.Escape)
                btnClose_Click(sender, new System.EventArgs());
        }
    }
}
