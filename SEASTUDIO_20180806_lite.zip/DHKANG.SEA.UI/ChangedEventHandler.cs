﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.UI
{
    public enum ChangedType { Added, Deleted, Modified };
    public enum ChangedTarget { Message, StateVariable, Parameter, State, Event, Schedule};

    public delegate void ChangedEventHandler(ChangedTarget targetType,
                                              ChangedType changedType,
                                              object before, object after);
    
}
