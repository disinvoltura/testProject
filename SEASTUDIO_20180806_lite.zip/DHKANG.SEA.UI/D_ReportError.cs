﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DHKANG.SEA.UI
{
    public partial class D_ReportError : Form
    {
        private string _Activity;
        private Exception _Exception;

        public D_ReportError(string activity, Exception e)
        {
            InitializeComponent();

            _Activity = activity;
            _Exception = e;
        }

        private void D_ReportError_Load(object sender, EventArgs e)
        {
            txtActivity.Text = _Activity;
            txtMessage.Text = _Exception.ToString();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtMessage_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtActivity_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
