﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace DHKANG.Foundation.Utility
{
    public sealed class ReflectionHelper
    {
        public static object CreateObject(Type objectType, object[] args, Type[] argTypes)
        {
            ConstructorInfo constructorInfo = null;
            if (args != null && args.Length != 0)
            {
                if (argTypes == null)
                {
                    argTypes = new Type[args.Length];
                    for (int i = args.Length - 1; i >= 0; i--)
                    {
                        if (args[i] != null)
                        {
                            argTypes[i] = args[i].GetType();
                        }
                    }
                }

                constructorInfo = 
                    objectType.GetConstructor(BindingFlags.Public | BindingFlags.Instance, null, argTypes, null);
                if (constructorInfo == null)
                    throw new ArgumentException("Cannot find constructor with right arguments for type " + objectType.FullName);
            }

            object instance;
            try
            {
                if (constructorInfo != null)
                    return constructorInfo.Invoke(args);

                instance = Activator.CreateInstance(objectType);
            }
            catch (Exception ex)
            {
                if (ex is TargetInvocationException)
                    ex = ex.InnerException;

                throw new Exception("Cannot create an instance of type " + objectType.FullName, ex);
            }
            return instance;
        }
    }
}
