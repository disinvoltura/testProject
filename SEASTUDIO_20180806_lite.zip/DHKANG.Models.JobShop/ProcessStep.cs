﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.Plugins.JobShop
{
    public class ProcessStep
    {
        #region Member Variables
        private string _Name;
        private List<ProcessFlow> _Inputs;
        private List<ProcessFlow> _Outputs;
        #endregion

        #region Properties
        public string Name { get { return _Name; } set { _Name = value; } }
        public List<ProcessFlow> Inputs { get { return _Inputs; } set { _Inputs = value; } }
        public List<ProcessFlow> Outputs { get { return _Outputs; } set { _Outputs = value; } }
        #endregion

        #region Constructors
        public ProcessStep(string name)
        {
            _Name = name;
            _Inputs = new List<ProcessFlow>();
            _Outputs = new List<ProcessFlow>();
        }
        public ProcessStep(string name, List<ProcessFlow> inputs, List<ProcessFlow> outputs)
        {
            _Name = name;
            _Inputs = inputs;
            _Outputs = outputs;
        }
        #endregion

        #region Methods
        public override bool Equals(object obj)
        {
            bool rslt = false;
            if (obj is ProcessStep)
            {
                rslt = _Name.Equals(((ProcessStep)obj).Name);
            }
            return rslt;
            //return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return _Name.GetHashCode();
        }
        #endregion
    }
}
