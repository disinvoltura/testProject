﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.Plugins.JobShop
{
    public class Process
    {
        #region Member Variables
        private string _Name;
        private List<ProcessStep> _Steps;
        private List<ProcessFlow> _Flows;
        #endregion

        #region Properties
        public string Name { get { return _Name; } set { _Name = value; } }
        public List<ProcessStep> Steps { get { return _Steps; } set { _Steps = value; } }
        public List<ProcessFlow> Flows { get { return _Flows; } set { _Flows = value; } }
        #endregion

        #region Constructors
        public Process(string name)
        {
            _Name = name;
            _Steps = new List<ProcessStep>();
            _Flows = new List<ProcessFlow>();
        }

        public Process(string name, List<ProcessStep> steps, List<ProcessFlow> flows)
        {
            _Name = name;
            _Steps = steps;
            _Flows = flows;
        }
        #endregion

        #region Methods
        public void Add(ProcessStep step)
        {
            _Steps.Add(step);
        }

        public void Add(ProcessFlow flow)
        {
            _Flows.Add(flow);
        }

        public ProcessStep FindProcessStep(string name)
        {
            ProcessStep rslt = null;
            foreach(ProcessStep step in _Steps)
            {
                if (step.Name.Equals(name))
                {
                    rslt = step;
                    break;
                }
            }
            return rslt;
        }

        public ProcessFlow FindProcessFlow(string fromStep, string toStep)
        {
            ProcessFlow rslt = null;
            foreach(ProcessFlow flow in _Flows)
            {
                if (flow.From.Name.Equals(fromStep) &&
                    flow.To.Name.Equals(toStep))
                {
                    rslt = flow;
                    break;
                }
            }
            return rslt;
        }
        #endregion
    }
}
