﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.Plugins.JobShop
{
    public class ProcessFlow
    {
        #region Member Variables
        private ProcessStep _FromProcessStep;
        private ProcessStep _ToProcessStep;
        private bool _IsDeterministic;
        private float _Probability;
        #endregion

        #region Properties
        public ProcessStep From { get { return _FromProcessStep; } set { _FromProcessStep = value; } }
        public ProcessStep To { get { return _ToProcessStep; } set { _ToProcessStep = value; } }
        public bool IsDeterministic { get { return _IsDeterministic; } set { _IsDeterministic = value; } }
        public float Probability { get { return _Probability; } set { _Probability = value; } }

        #endregion

        #region Constructors
        public ProcessFlow(ProcessStep from, ProcessStep to)
        {
            _FromProcessStep = from;
            _ToProcessStep = to;
            _IsDeterministic = false;
            _Probability = 1.0f;
        }

        public ProcessFlow(ProcessStep from, ProcessStep to, float probability)
        {
            _FromProcessStep = from;
            _ToProcessStep = to;
            _IsDeterministic = true;
            _Probability = probability;
        }
        #endregion

        #region Methods
        public override bool Equals(object obj)
        {
            bool rslt = false;
            if (obj is ProcessFlow)
            {
                ProcessFlow target = (ProcessFlow)obj;

                if (target.From.Equals(this.From) && target.To.Equals(this.To))
                    rslt = true;
            }
            return rslt;
        }

        public override int GetHashCode()
        {
            return this.ToString().GetHashCode();
        }

        public override string ToString()
        {
            return String.Format("{0}.{1}", this.From, this.To);
        }
        #endregion
    }
}
