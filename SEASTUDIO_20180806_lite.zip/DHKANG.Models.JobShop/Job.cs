﻿using DHKANG.SEA.Simulation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.Plugins.JobShop
{
    public class Job: AbstractEntity
    {
        #region Member Variables
        private Dictionary<string, object> _Attributes;
        #endregion

        #region Properties
        public new object this[string attributeName]
        {
            get
            {
                object rslt = null;
                if (_Attributes.ContainsKey(attributeName))
                    rslt = _Attributes[attributeName];
                return rslt;
            }
            set
            {
                if (_Attributes.ContainsKey(attributeName))
                    _Attributes[attributeName] = value;
                else
                    _Attributes.Add(attributeName, value);
            }
        }
        #endregion

        #region Constructors
        public Job()
            : base("Job")
        {
            _Attributes = new Dictionary<string, object>();
        }

        public Job(string type)
            : base(type)
        {
            _Attributes = new Dictionary<string, object>();
        }
        #endregion

        #region Methods
        public override List<string> Attributes {
            get { return _Attributes.Keys.ToList(); }
        }

        public override object GetAttributeValue(string name)
        {
            object rslt = null;
            if (_Attributes.ContainsKey(name))
                rslt = _Attributes[name];

            return rslt;
        }
        #endregion
    }
}
