﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.StateObjects
{
    //public enum ParameterType { Integer, Double, DateTime, String, Boolean, RandomVariate, Position, Range };// Parameter 에서는 TimeQueue 를 지원하지 않음};

    public class OOSGParameter : ISerializable
    {
        #region Member Variables
        private string _Name;
        private string _Type;
        //private ParameterType _Type;
        private string _InitialValue; //later type casting is needed.

        private float _X;
        private float _Y;
        #endregion

        #region Properties
        public string Name { get { return _Name; } set { _Name = value; } }
        public string Type { get { return _Type; } set { _Type = value; } } 
        //public ParameterType Type { get { return _Type; } set { _Type = value; } } 
        public string InitialValue { get { return _InitialValue; } set { _InitialValue = value; } }

        public float X { get { return _X; } set { _X = value; } }
        public float Y { get { return _Y; } set { _Y = value; } }
        #endregion

        #region Constructors
        public OOSGParameter()
        {
        }

        public OOSGParameter(string name, string type, string initValue)
        {
            _Name = name;
            _Type = type;
            _InitialValue = initValue;
        }

        public OOSGParameter(SerializationInfo info, StreamingContext ctxt)
        {
            _Name = (string)info.GetValue("Name", typeof(string));
            _Type = (string)info.GetValue("Type", typeof(string));
            //_Type = (ParameterType)info.GetValue("Type", typeof(ParameterType));
            _InitialValue = (string)info.GetValue("InitialValue", typeof(string));
            _X = (float)info.GetValue("X", typeof(float));
            _Y = (float)info.GetValue("Y", typeof(float));
        }
        #endregion

        public OOSGParameter Clone()
        {
            OOSGParameter newParameter = new OOSGParameter((string)this.Name.Clone(), (string)this.Type.Clone(), (string)this.InitialValue.Clone());
            /*
            OOSGParameter newParameter =
                new OOSGParameter(
                    (string)this.Name.Clone(),
                    (ParameterType)Enum.Parse(typeof(ParameterType), this.Type.ToString()),
                    (string)this.InitialValue.Clone());
            */

            newParameter.X = _X;
            newParameter.Y = _Y;

            return newParameter;
        }

        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Name", _Name);
            info.AddValue("Type", _Type);
            info.AddValue("InitialValue", _InitialValue);
            info.AddValue("X", _X);
            info.AddValue("Y", _Y);
        }

    }
}
