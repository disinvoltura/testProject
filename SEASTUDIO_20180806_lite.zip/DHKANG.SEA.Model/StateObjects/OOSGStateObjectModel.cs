﻿using DHKANG.SEA.Model.StateObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.StateObjects
{
    [Serializable()]
    public class OOSGStateObjectModel : OOMMObjectModel, ISerializable
    {
        #region Member Variables
        //private Guid _ID;
        //private string _Name;
        //private string _Description;
        private bool _IsContainIntialState;
        private bool _HasFinalState;
        private List<OOSGState> _States;
        private List<OOSGStateVariable> _StateVariables;
        private List<OOSGParameter> _Parameters;
        private List<OOSGStateTransition> _STT;
        private List<OOSGMessage> _Messages;
        //private string _Functions;
        //private int _BackgroundColor;
        //private List<OOMMSchedule> _Schedules;
        //private List<OOMMEntityQueue> _EntityQueues;

        #endregion

        #region Properties
        //public Guid ID { get { return _ID; } set { _ID = value; } }
        //public string Name { get { return _Name; } set { _Name = value; } }
        //public string Description { get { return _Description; } set { _Description = value; } }

        public List<OOSGMessage> Messages
        {
            get { return _Messages; }
            set { _Messages = value; }
        }

        public IEnumerable<OOSGMessage> InputMesssages
        {
            get
            {
                IEnumerable<OOSGMessage> rslt =
                    from msg in _Messages
                    where msg.Type == MessageType.Input
                    select msg;

                return rslt;
            }
        }

        public IEnumerable<OOSGMessage> OutputMessages
        {
            get
            {
                IEnumerable<OOSGMessage> rslt =
                    from msg in _Messages
                    where msg.Type == MessageType.Output
                    select msg;

                return rslt;
            }
        }

        public List<OOSGState> States
        {
            get { return _States; }
            set { _States = value; }
        }

        public OOSGState InitialState
        {
            get
            {
                IEnumerable<OOSGState> rslt =
                    from s in _States
                    where s.Type == StateType.Initial
                    select s;


                if (rslt.Count<OOSGState>() > 0)
                {
                    List<OOSGState> initStates = rslt.ToList<OOSGState>();

                    return initStates[0];
                }
                else
                    return null;
            }
        }

        /// <summary>
        /// Key: Name of StateVariable, Value: StateVariable
        /// </summary>
        public List<OOSGStateVariable> StateVariables
        {
            get { return _StateVariables; }
            set { _StateVariables = value; }
        }

        /// <summary>
        /// Key: Name of a Parameter, Value: Parameter
        /// </summary>
        public List<OOSGParameter> Parameters
        {
            get { return _Parameters; }
            set { _Parameters = value; }
        }

        /// <summary>
        /// State Transition Table (STT)
        /// </summary>
        public List<OOSGStateTransition> STT
        {
            get { return _STT; }
        }

        /*
        public string Functions
        {
            get { return _Functions; }
            set { _Functions = value; }
        }
        public int BackgroundColor { get { return _BackgroundColor; } set { _BackgroundColor = value; } }
        */
        public bool IsContainIntialState { get { return _IsContainIntialState; } set { _IsContainIntialState = value; } }
        public bool HasFinalState { get { return _HasFinalState; } set { _HasFinalState = value; } }

        /*
        public List<OOMMSchedule> Schedules  { get { return _Schedules; } set { _Schedules = value; } }

        public List<OOMMEntityQueue> EntityQueues { get { return _EntityQueues; } set { _EntityQueues = value; } }
        */
        #endregion

        #region Constructors
        public OOSGStateObjectModel() : base()
        {
            /*
            _ID = Guid.NewGuid();
            _Name = string.Empty;
            _Description = string.Empty;
            _Functions = string.Empty;
            _Schedules = new List<OOMMSchedule>();
            _EntityQueues = new List<OOMMEntityQueue>();
            */

            IsContainIntialState = false;
            HasFinalState = false;

            _Messages = new List<OOSGMessage>();
            _States = new List<OOSGState>();
            _StateVariables = new List<OOSGStateVariable>();
            _Parameters = new List<OOSGParameter>();
            _STT = new List<OOSGStateTransition>();            
        }

        public OOSGStateObjectModel(string name) : base(name)
        {
            IsContainIntialState = false;
            HasFinalState = false;

            _Messages = new List<OOSGMessage>();
            _States = new List<OOSGState>();
            _StateVariables = new List<OOSGStateVariable>();
            _Parameters = new List<OOSGParameter>();
            _STT = new List<OOSGStateTransition>();
        }

        /*
        public OOMMEntityQueue FindEntityQueue(string name)
        {
            OOMMEntityQueue rslt = null;

            foreach (OOMMEntityQueue q in _EntityQueues)
            {
                if (q.Name.Equals(name))
                {
                    rslt = q;
                    break;
                }
            }

            return rslt;
        }

        public OOMMSchedule FindSchedule(string name)
        {
            OOMMSchedule rslt = null;

            foreach (OOMMSchedule s in _Schedules)
            {
                if (s.Name.Equals(name))
                {
                    rslt = s;
                    break;
                }
            }

            return rslt;
        }
        */

        public OOSGStateObjectModel(SerializationInfo info, StreamingContext ctxt)
        {
            //_ID = (Guid)info.GetValue("ID", typeof(Guid));
            //_Name = (string)info.GetValue("Name", typeof(string));
            //_Description = (string)info.GetValue("Description", typeof(string));

            _IsContainIntialState= (bool)info.GetValue("IsContainInitialState", typeof(bool));
            _HasFinalState= (bool)info.GetValue("HasFinalState", typeof(bool));
            _States= (List<OOSGState>)info.GetValue("States", typeof(SortedList<string, OOSGState>));
            _StateVariables = (List<OOSGStateVariable>)info.GetValue("StateVariables", typeof(SortedList<string, OOSGStateVariable>));
            _Parameters = (List<OOSGParameter>)info.GetValue("Parameters", typeof(SortedList<string, OOSGParameter>));
            _STT = (List<OOSGStateTransition>)info.GetValue("STT", typeof(List<OOSGStateTransition>));
            _Messages = (List<OOSGMessage>)info.GetValue("Messages", typeof(SortedList<string, OOSGMessage>));
            //_Functions = (string)info.GetValue("Functions", typeof(string));

            //_BackgroundColor = (int)info.GetValue("BackgroundColor", typeof(int));

            //try
            //{
            //    _Schedules = (List<OOMMSchedule>)info.GetValue("Schedules", typeof(List<OOMMSchedule>));
            //}
            //catch (Exception ex)
            //{
            //}

        }
        #endregion

        #region Methods
        public OOSGStateObjectModel Clone()
        {
            OOSGStateObjectModel rslt = new OOSGStateObjectModel(this.Name);

            rslt.Description = this.Description;
            rslt.IsContainIntialState = this.IsContainIntialState;
            rslt.HasFinalState = this.HasFinalState;

            this.States.ForEach(s => rslt.States.Add(s.Clone()));
            this.StateVariables.ForEach(sv => rslt.StateVariables.Add(sv.Clone()));
            this.Parameters.ForEach(p => rslt.Parameters.Add(p.Clone()));
            this.STT.ForEach(st => rslt.STT.Add(st.Clone()));
            this.Messages.ForEach(m => rslt.Messages.Add(m.Clone()));
            this.Schedules.ForEach(s => rslt.Schedules.Add(s.Clone()));

            rslt.Functions = this.Functions;
            rslt.BackgroundColor = this.BackgroundColor;

            return rslt;
        }

        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //info.AddValue("ID", _ID);
            //info.AddValue("Name", _Name);
            //info.AddValue("Description", _Description);

            info.AddValue("IsContainInitialState", _IsContainIntialState);
            info.AddValue("HasFinalState", _HasFinalState);

            info.AddValue("States", _States);
            info.AddValue("StateVariables", _StateVariables);
            info.AddValue("Parameters", _Parameters);
            info.AddValue("STT", _STT);
            info.AddValue("Messages", _Messages);
            //info.AddValue("Functions", _Functions);

            //info.AddValue("BackgroundColor", _BackgroundColor);
            //info.AddValue("Schedules", _Schedules);
        }

        public void AddParameter(OOSGParameter p)
        {
            if (ContainsParameter(p.Name))
                RemoveParameter(p.Name);
            _Parameters.Add(p);
        }

        public void RemoveParameter(string name)
        {
            IEnumerable<OOSGParameter> results = from p in _Parameters where (p.Name.Equals(name)) select p;
            if (results.Count<OOSGParameter>() > 0)
            {
                _Parameters.Remove(results.ElementAt(0));
            }
        }

        public bool ContainsParameter(string name)
        {
            IEnumerable<OOSGParameter> results = from p in _Parameters where (p.Name.Equals(name)) select p;
            bool rslt = results.Count() > 0;
            return rslt;
        }

        public OOSGParameter FindParameter(string name)
        {
            OOSGParameter rslt = null;
            IEnumerable<OOSGParameter> results = from p in _Parameters where (p.Name.Equals(name)) select p;
            if (results.Count() > 0)
            {
                rslt = results.ElementAt(0);
            }
            return rslt;
        }

        public void ChangeParameter(OOSGParameter oldPM, OOSGParameter newPM)
        {
            RemoveParameter(oldPM.Name);
            _Parameters.Add(newPM);
        }

        public void AddMessage(OOSGMessage msg)
        {
            if (ContainsMessage(msg.MName))
                RemoveMessage(msg.MName);

            _Messages.Add(msg);
        }

        public bool ContainsMessage(string name)
        {
            IEnumerable<OOSGMessage> results = from m in _Messages where (m.MName.Equals(name)) select m;
            return results.Count() > 0;
        }

        public void RemoveMessage(string name)
        {
            IEnumerable<OOSGMessage> results = from m in _Messages where (m.MName.Equals(name)) select m;
            if (results.Count<OOSGMessage>() > 0)
            {
                _Messages.Remove(results.ElementAt(0));
            }
        }

        public OOSGMessage FindMessage(string name)
        {
            OOSGMessage rslt = null;
            IEnumerable<OOSGMessage> results = from m in _Messages where (m.MName.Equals(name)) select m;
            if (results.Count() > 0)
            {
                rslt = results.ElementAt(0);
            }
            return rslt;
        }

        public void ChangeMessage(OOSGMessage oldMsg, OOSGMessage newMsg)
        {
            RemoveMessage(oldMsg.MName);
            _Messages.Add(newMsg);
        }

        public void AddStateVariable(OOSGStateVariable sv)
        {
            RemoveStateVariable(sv.Name);
            _StateVariables.Add(sv);
        }

        public OOSGStateVariable FindStateVariable(string name)
        {
            OOSGStateVariable rslt = null;
            IEnumerable<OOSGStateVariable> results = from sv in _StateVariables where (sv.Name.Equals(name)) select sv;
            if (results.Count() > 0)
            {
                rslt = results.ElementAt(0);
            }
            return rslt;
        }

        public void RemoveStateVariable(string name)
        {
            IEnumerable<OOSGStateVariable> results = from sv in _StateVariables where (sv.Name.Equals(name)) select sv;
            if (results.Count<OOSGStateVariable>() > 0)
            {
                _StateVariables.Remove(results.ElementAt(0));
            }
        }

        public void ChangeStateVariable(OOSGStateVariable oldSV, OOSGStateVariable newSV)
        {
            RemoveStateVariable(oldSV.Name);
            _StateVariables.Add(newSV);
        }

        public void ChangeState(OOSGState oldS, OOSGState newS)
        {
            RemoveState(oldS.Name);
            _States.Add(newS);
        }

        public void AddState(OOSGState state)
        {
            RemoveState(state.Name);
            _States.Add(state);
        }

        public OOSGState FindState(string name)
        {
            OOSGState rslt = null;
            IEnumerable<OOSGState> results = from s in _States where (s.Name.Equals(name)) select s;
            if (results.Count() > 0)
            {
                rslt = results.ElementAt(0);
            }
            return rslt;
        }

        public void RemoveState(string name)
        {
            IEnumerable<OOSGState> results = from s in _States where (s.Name.Equals(name)) select s;
            if (results.Count<OOSGState>() > 0)
            {
                _States.Remove(results.ElementAt(0));
            }
        }
        #endregion

    }
}
