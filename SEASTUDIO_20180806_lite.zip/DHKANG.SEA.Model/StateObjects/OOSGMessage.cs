﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.StateObjects
{
    public enum MessageType { Input, Output };

    public class OOSGMessage : ISerializable
    {
        #region Member Variables
        private string _Name;
        private MessageType _Type;
        private List<OOSGMessageParameter> _Parameters;
        private float _X;
        private float _Y;
        #endregion

        #region Properties 
        public string this[string name]
        {
            get
            {
                string rslt = string.Empty;
                OOSGMessageParameter p = FindParameter(name);
                if (p != null)
                    rslt = p.Value; 
                return rslt;
            }
        }

        public bool HasParameters { get { return _Parameters.Count > 0 ? true : false; } }
        public List<OOSGMessageParameter> Parameters { get { return _Parameters; } }
        public string DisplayName { get { return "(" + this.MName + ")?"; } }
        public string MName { get { return _Name; } set { _Name = value; } }
        public MessageType Type { get { return _Type; } set { _Type = value; } }
        public float X { get { return _X; } set { _X = value; } }
        public float Y { get { return _Y; } set { _Y = value; } }
        #endregion

        #region Constructors
        public OOSGMessage()
        {
            _Name = string.Empty;
            _Type = MessageType.Input;
            _Parameters = new List<OOSGMessageParameter>();
        }

        public OOSGMessage(string name, MessageType type)
        {
            _Name = name;
            _Type = type;
            _Parameters = new List<OOSGMessageParameter>();
        }

        public OOSGMessage(SerializationInfo info, StreamingContext ctxt)
        {
            _Name = (string)info.GetValue("Name", typeof(string));
            _Type = (MessageType)info.GetValue("Type", typeof(MessageType));
            _Parameters = (List<OOSGMessageParameter>)info.GetValue("Parameters", typeof(List<OOSGMessageParameter>));
            _X = (float)info.GetValue("X", typeof(float));
            _Y = (float)info.GetValue("Y", typeof(float));
        }

        #endregion

        #region Methods
        public void AddParameter(string paramName, string paramValue)
        {
            _Parameters.Add(new OOSGMessageParameter(paramName, paramValue));
        }

        public void AddParameter(OOSGMessageParameter mp)
        {
            _Parameters.Add(mp);
        }

        public void RemoveParamter(string paramName)
        {
            IEnumerable<OOSGMessageParameter> results = from p in _Parameters where p.Name.Equals(paramName) select p;
            if (results.Count<OOSGMessageParameter>()>0)
                _Parameters.Remove(results.ElementAt(0));
        }

        public bool ContainsParameter(string name)
        {
            IEnumerable<OOSGMessageParameter> results = from p in _Parameters where p.Name.Equals(name) select p;
            return results.Count<OOSGMessageParameter>() > 0;
        }
       
        public void RemoveAllParameters()
        {
            _Parameters.Clear();
        }

        public OOSGMessageParameter FindParameter(string name)
        {
            OOSGMessageParameter rslt = null;
            IEnumerable<OOSGMessageParameter> results = from p in _Parameters where p.Name.Equals(name) select p;
            if (results.Count<OOSGMessageParameter>()>0)
                rslt = results.ElementAt(0);
            return rslt;
        } 

        public void UpdateParamter(string paramName, string paramValue)
        {
            if (ContainsParameter(paramName))
            {
                OOSGMessageParameter p = FindParameter(paramName);
                p.Value = paramValue;
                //_Parameters[paramName] = paramValue;
            }
        }

        public OOSGMessage Clone()
        {
            OOSGMessage newMsg = new OOSGMessage(this.MName, this.Type);

            foreach (OOSGMessageParameter p in _Parameters)
                newMsg.AddParameter(p.Name, p.Value);

            return newMsg;
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Name", _Name);
            info.AddValue("Type", _Type);
            info.AddValue("Parameters", _Parameters);
            info.AddValue("X", _X);
            info.AddValue("Y", _Y);
        }
        #endregion
    }

    public class OOSGMessageParameter
    {
        private string _Name;
        private string _Value;

        public string Name { get { return _Name; } set { _Name = value; } }
        public string Value { get { return _Value; } set { _Value = value; } }

        public OOSGMessageParameter() { }

        public OOSGMessageParameter(string name, string value)
        {
            _Name = name;
            _Value = value;            
        }

        public OOSGMessageParameter(SerializationInfo info, StreamingContext ctxt)
        {
            _Name = (string)info.GetValue("Name", typeof(string));
            _Value = (string)info.GetValue("Value", typeof(string));
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Name", _Name);
            info.AddValue("Value", _Value);
        }
    }

    public class MessageComparer : IComparer<OOSGMessage>
    {
        public int Compare(OOSGMessage x, OOSGMessage y)
        {
            return x.MName.CompareTo(y.MName);
        }
    }
}
