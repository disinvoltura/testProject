﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.StateObjects
{
    /*
    public enum StateVariableType
    {
        int, double, DateTime, string, bool, TimeQueue, Position, Range, Custom
        //Integer, Double, DateTime, String, Boolean, TimeQueue,
        //Position, Range, Custom
    };
    */

    
    public static class OOSGStateVariableHelper {
        private static List<string> _ValueTypeList;

        public static string TIMEQUEUE = "TimeQueue";
        public static string INT = "int";
        public static string DOUBLE = "double";
        public static string FLOAT = "float";
        public static string BOOL = "bool";
        public static string STRING = "string";
        public static string DATETIME = "DateTime";
        public static string POSITION = "Position";
        public static string RANGE = "Range";
        public static string RANDOMVARIATE = "RandomVariate";
        public static string ENTITYQUEUE = "EntityQueue";
        public static string RESOURCE = "Resource";

        static OOSGStateVariableHelper()
        {
            _ValueTypeList = new List<string>();
            _ValueTypeList.Add("bool");
            _ValueTypeList.Add("float");
            _ValueTypeList.Add("double");
            _ValueTypeList.Add("int");
            _ValueTypeList.Add("string");
            _ValueTypeList.Add(DATETIME);
            _ValueTypeList.Add(ENTITYQUEUE);
            _ValueTypeList.Add(POSITION);
            _ValueTypeList.Add(RANDOMVARIATE);
            _ValueTypeList.Add(RANGE);
            _ValueTypeList.Add(RESOURCE);
            _ValueTypeList.Add(TIMEQUEUE);
        }

        public static bool IsCustomType(string valueType)
        {
            return !_ValueTypeList.Contains(valueType);
        }

        public static string DefaultValueType()
        {
            return "int";
        }

        public static List<string> ValueType()
        {
            return _ValueTypeList;
        }
    }

    [Serializable()]
    public class OOSGStateVariable : ISerializable
    {
        #region Member Variables
        private string _SVName;
        private string _Type;
        private bool _IsCustomType;
        private object _InitialValue;
        #endregion

        #region Properties
        public string Name { get { return _SVName; } set { _SVName = value; } }
        public string Type { get { return _Type; } set { _Type = value; } }
        public bool IsCustomType { get { return _IsCustomType; } set { _IsCustomType = value; } }
        //public StateVariableType Type { get { return _Type; } set { _Type = value; } }
        //public string CustomType { get { return _CustomType; } set { _CustomType = value; } } 
        public object InitialValue { get { return _InitialValue; } set { _InitialValue = value; } }
        #endregion

        #region Constructors
        public OOSGStateVariable() { }

        public OOSGStateVariable(string name, string type, object initValue)
        {
            _SVName = name;
            _Type = type;
            _InitialValue = initValue;
            _IsCustomType = OOSGStateVariableHelper.IsCustomType(type);
        }

        public OOSGStateVariable(string name, string type, bool isCustomType, object initValue)
        {
            _SVName = name;
            _Type = type;
            _InitialValue = initValue;
            _IsCustomType = isCustomType;
        }

        public OOSGStateVariable(SerializationInfo info, StreamingContext ctxt)
        {
            _SVName = (string)info.GetValue("Name", typeof(string));

            try
            {
                _Type = (string)info.GetValue("Type", typeof(string));
            }catch(Exception ex) { } 

            try
            {
                _IsCustomType = (bool)info.GetValue("IsCustomType", typeof(string));
            }
            catch (Exception ex) { }

            _InitialValue = (object)info.GetValue("InitialValue", typeof(object));
        }

        #endregion

        #region Methods
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Name", _SVName);
            info.AddValue("Type", _Type);
            info.AddValue("IsCustomType", _IsCustomType);
            info.AddValue("InitialValue", _InitialValue);
        }

        public OOSGStateVariable Clone()
        {
            OOSGStateVariable newSV = new OOSGStateVariable(this.Name, this.Type, this.IsCustomType, this.InitialValue);
            return newSV;
        }
        #endregion
    }
}
