﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.StateObjects
{
    public class OOSGDelay : ISerializable
    {
        #region Member Variables
        private string _Name;
        private string _DeltaName;
        #endregion

        #region Properties
        public string Name { get { return _Name; } set { _Name = value; } }
        public string DeltaName { get { return _DeltaName; } set { _DeltaName = value; } }
        #endregion

        #region Constructors
        public OOSGDelay()
        { }
        public OOSGDelay(string name)
        {
            DeltaName = "delta[" + name + "]";
            Name = name;
        }

        public OOSGDelay(SerializationInfo info, StreamingContext ctxt)
        {
            _Name = (string)info.GetValue("Name", typeof(string));
            _DeltaName = (string)info.GetValue("DeltaName", typeof(string));

        }

        #endregion

        #region Methods
        public OOSGDelay Clone()
        {
            OOSGDelay newDelay = new OOSGDelay((string)this.Name.Clone());

            return newDelay;
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Name", _Name);
            info.AddValue("DeltaName", _DeltaName);
        }

        public override bool Equals(object obj)
        {
            bool rslt = false;

            if (obj is OOSGDelay)
            {
                OOSGDelay target = (OOSGDelay)obj;
                if (this.Name.Equals(Name))
                    rslt = true;
            }
            return rslt;
        }
        #endregion

    }
}
