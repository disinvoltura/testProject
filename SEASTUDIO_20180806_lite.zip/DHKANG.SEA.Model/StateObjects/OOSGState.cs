﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.StateObjects
{
    public enum StateType { Regular, Initial, Transient, Final };

    public class OOSGState : ISerializable
    {
        #region Member Variables
        private string _Name;
        private StateType _Type;
        private string _EntryAction = string.Empty;
        private OOSGDelay _Delay;

        private float _X;
        private float _Y;
        #endregion

        #region Properties
        public string Name { get { return _Name; } set { _Name = value; } }
        public StateType Type { get { return _Type; } set { _Type = value; } }
        public string EntryAction { get { return _EntryAction; } set { _EntryAction = value; }}
        public OOSGDelay Delay { get { return _Delay; } set { _Delay = value; } }

        /// <summary>
        /// Center Postion's X of a State Vertex
        /// </summary>
        public float X { get { return _X; } set { _X = value; } }
        /// <summary>
        /// Center Position's Y of a State Vertex
        /// </summary>
        public float Y
        {
            get { return _Y; }
            set { _Y = value; }
        }
        #endregion

        #region Constructors
        public OOSGState() {
            _Delay = new OOSGDelay("");
        }

        public OOSGState(string name, StateType type, string entryAction, OOSGDelay delay)
        {
            _Name = name;
            _Type = type;
            _EntryAction = entryAction;
            _Delay = delay;
        }

        public OOSGState(string name, StateType type, string entryAction, OOSGDelay delay, float x, float y)
        {
            _Name = name;
            _Type = type;
            _EntryAction = entryAction;
            _Delay = delay;
            _X = x;
            _Y = y;
        }

        public OOSGState(SerializationInfo info, StreamingContext ctxt)
        {
            _Name = (string)info.GetValue("Name", typeof(string));
            _Type = (StateType)info.GetValue("Type", typeof(StateType));
            _EntryAction = (string)info.GetValue("EntryAction", typeof(string));
            _Delay = (OOSGDelay)info.GetValue("Delay", typeof(OOSGDelay));

            _X = (float)info.GetValue("X", typeof(float));
            _Y = (float )info.GetValue("Y", typeof(float));

        }
        #endregion

        #region Methods

        public OOSGState Clone()
        {
            OOSGDelay newDelay = null;
            if (this.Delay != null)
                newDelay = new OOSGDelay(this.Delay.Name);

            OOSGState newState = new OOSGState(
                (string)this.Name.Clone(),
                (StateType)Enum.Parse(typeof(StateType), this.Type.ToString()),
                (string)EntryAction.Clone(),
                newDelay, this.X, this.Y);

            return newState;
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Name", _Name);
            info.AddValue("Type", _Type);
            info.AddValue("EntryAction", _EntryAction);
            info.AddValue("Delay", _Delay);
            info.AddValue("X", _X);
            info.AddValue("Y", _Y);
        }

        public override bool Equals(object obj)
        {
            bool rslt = false;

            if (obj is OOSGState)
            {
                OOSGState target = (OOSGState)obj;

                if (this.Name.Equals(target.Name) &&
                    this.Type.Equals(target.Type) &&
                    this.EntryAction.Equals(target.EntryAction) &&
                    this.Delay.Equals(target.Delay))
                    rslt = true;
                    
            }
            return base.Equals(obj);
        }
        #endregion
    }
}
