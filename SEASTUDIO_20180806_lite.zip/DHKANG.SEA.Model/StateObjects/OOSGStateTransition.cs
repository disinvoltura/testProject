﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.StateObjects
{
    public class OOSGStateTransition : ISerializable
    {
        #region Member Variables
        private OOSGState _CurrentState;
        private string _EntryAction;
        private string _InputOrDelay;
        private string _InputAction;
        private string _Condition;
        private string _TransitionAction;
        private OOSGState _NextState;

        //Graph Properties
        public int FromPort;
        public int ToPort;
        public int LinkStyle;
        public int AdjustingStyle;
        public float Curviness;
        public bool Orthogonal;
        public List<OOSGPoint> Points;
        #endregion

        #region Properties
        public OOSGState CurrentState { get { return _CurrentState; } set { _CurrentState = value; } }
        public string EntryAction { get { return _EntryAction; } set { _EntryAction = value; } }
        public string InputOrDelay { get { return _InputOrDelay; } set { _InputOrDelay = value; } }
        public string InputAction { get { return _InputAction; } set { _InputAction = value; } }
        public string Condition { get { return _Condition; } set { _Condition = value; } }
        public string TransitionAction { get { return _TransitionAction; } set { _TransitionAction = value; } }
        public OOSGState NextState { get { return _NextState; } set { _NextState = value; } }
        #endregion

        #region Constructors
        public OOSGStateTransition()
        {
        }

        public OOSGStateTransition(OOSGState cState, string entryAction, string inputOrDelay, string inputAction, string condition, string transitionAction, OOSGState nextState)
        {
            _CurrentState = cState;
            _EntryAction = entryAction;
            _InputOrDelay = inputOrDelay;
            _InputAction = inputAction;
            _Condition = condition;
            _TransitionAction = transitionAction;
            _NextState = nextState;

            this.Points = new List<OOSGPoint>();
        }

        public OOSGStateTransition(OOSGState cState, string entryAction, string inputOrDelay, string inputAction, string condition, string transitionAction, OOSGState nextState, int fromPort, int toPort, int linkStyle)
            : this (cState, entryAction, inputOrDelay, inputAction, condition, transitionAction, nextState)
        {
            this.FromPort = fromPort;
            this.ToPort = toPort;
            this.LinkStyle = linkStyle;

            this.Points = new List<OOSGPoint>();

        }

        public OOSGStateTransition(SerializationInfo info, StreamingContext ctxt)
        {
            _CurrentState = (OOSGState)info.GetValue("CurrentState", typeof(OOSGState));
            _EntryAction = (string)info.GetValue("EntryAction", typeof(string));
            _InputOrDelay = (string)info.GetValue("InputOrDelay", typeof(string));
            _InputAction = (string)info.GetValue("InputAction", typeof(string));
            _Condition = (string)info.GetValue("Condition", typeof(string));
            _TransitionAction = (string)info.GetValue("TransitionAction", typeof(string));
            _NextState = (OOSGState)info.GetValue("NextState", typeof(OOSGState));

            //FromPort = (int)info.GetValue("FromPort", typeof(int));
            //ToPort = (int)info.GetValue("ToPort", typeof(int));
            //LinkStyle = (int)info.GetValue("LinkStyle", typeof(int));
            //AdjustingStyle = (int)info.GetValue("AdjustingStyle", typeof(int));
            //Curviness = (int)info.GetValue("Curviness", typeof(int));
            //Points = (List<OOSGPoint>)info.GetValue("Points", typeof(List<OOSGPoint>));

            try
            {
                FromPort = (int)info.GetValue("FromPort", typeof(int));
            }
            catch (Exception ex) { FromPort = 0; }

            try
            {
                ToPort = (int)info.GetValue("ToPort", typeof(int));
            }
            catch (Exception ex) { FromPort = 0; }

            try
            {
                LinkStyle = (int)info.GetValue("LinkStyle", typeof(int));
            }
            catch (Exception ex) { FromPort = 0; }

            try
            {
                Curviness = (float)info.GetValue("Curviness", typeof(float));
            }
            catch (Exception ex) { Curviness = 0; }

            try
            {
                AdjustingStyle = (int)info.GetValue("AdjustingStyle", typeof(int));
            }
            catch (Exception ex) { AdjustingStyle = 0; }

            try
            {
                Orthogonal = (bool)info.GetValue("Orthogonal", typeof(bool));
            }
            catch (Exception ex) { AdjustingStyle = 0; }


            try
            {
                Points = (List<OOSGPoint>)info.GetValue("Points", typeof(List<OOSGPoint>));
            }
            catch (Exception ex) { AdjustingStyle = 0; }
        }

        #endregion

        #region Methods
        public OOSGStateTransition Clone()
        {
            OOSGStateTransition st =
                new OOSGStateTransition(
                    this.CurrentState.Clone(),
                    this.EntryAction,
                    this.InputOrDelay,
                    this.InputAction,
                    this.Condition,
                    this.TransitionAction,
                    this.NextState != null ? this.NextState.Clone() : null, this.FromPort, this.ToPort, this.LinkStyle);

            st.AdjustingStyle = this.AdjustingStyle;
            st.Curviness = this.Curviness;
            st.Orthogonal = this.Orthogonal;

            foreach (OOSGPoint pt in this.Points)
            {
                st.Points.Add(new OOSGPoint(pt.X, pt.Y));
            }

            return st;
        }

        public override bool Equals(object obj)
        {
            bool rslt = true;
            if (obj is OOSGStateTransition)
            {
                OOSGStateTransition target = (OOSGStateTransition)obj;
                if (!this.CurrentState.Equals(target.CurrentState))
                    rslt = false;
                if (!this.EntryAction.Equals(target.EntryAction))
                    rslt = false;
                if (!this.InputOrDelay.Equals(target.InputOrDelay))
                    rslt = false;
                if (!this.InputAction.Equals(target.InputAction))
                    rslt = false;
                if (!this.Condition.Equals(target.Condition))
                    rslt = false;
                if (!this.TransitionAction.Equals(target.TransitionAction))
                    rslt = false;
                if (!this.NextState.Equals(target.NextState))
                    rslt = false;
            }
            else
            {
                rslt = false;
            }
            return rslt;
        }

        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("CurrentState", CurrentState);
            info.AddValue("EntryAction", EntryAction);
            info.AddValue("InputOrDelay", InputOrDelay);
            info.AddValue("InputAction", InputAction);
            info.AddValue("Condition", Condition);
            info.AddValue("TransitionAction", TransitionAction);
            info.AddValue("NextState", NextState);

            info.AddValue("FromPort", FromPort);
            info.AddValue("ToPort", ToPort);
            info.AddValue("LinkStyle", LinkStyle);

            info.AddValue("Curviness", Curviness);
            info.AddValue("Orthogonal", Orthogonal);
            info.AddValue("AdjustingStyle", AdjustingStyle);
            info.AddValue("Points", Points);
        }

        public override int GetHashCode()
        {
            return CurrentState.Name.GetHashCode();
        }

        public override string ToString()
        {
            return this.CurrentState.Name + "->" + this.NextState.Name + "(EA:" + this.EntryAction + ", Input/Delay:" + this.InputOrDelay + ", IA:" + this.InputAction + ", C:" + this.Condition + ", TA:" + this.TransitionAction + ")";
        }
        #endregion
    }

    public class OOSGPoint : ISerializable
    {
        #region Member Variables
        public float X;
        public float Y;
        #endregion

        #region Constructors
        public OOSGPoint() { }

        public OOSGPoint(float x, float y)
        {
            this.X = x;
            this.Y = y;
        }

        public OOSGPoint(SerializationInfo info, StreamingContext ctxt)
        {
            this.X = (float)info.GetValue("X", typeof(float));
            this.Y = (float)info.GetValue("Y", typeof(float));
        }
        #endregion

        #region ISerializable Method
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("X", X);
            info.AddValue("Y", Y);
        }
        #endregion
    }
}
