﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model.Entities
{
    [Serializable()]
    public class OOMMEntity: ISerializable
    {
        #region Member Variables
        private Guid _ID;
        private string _Name;
        private List<OOMMEntityAttribute> _Attributes;
        #endregion

        #region Properties
        public Guid ID { get { return _ID; } set { _ID = value; } }
        public string Name { get { return _Name; } set { _Name = value; } }
        public List<OOMMEntityAttribute> Attributes { get { return _Attributes; } set { _Attributes = value; } }

        public OOMMEntityAttribute this [string name]
        {
            get
            {
                OOMMEntityAttribute rslt = null;
                foreach(OOMMEntityAttribute attr in _Attributes)
                {
                    if (attr.Name.Equals(name))
                    {
                        rslt = attr; break;
                    }
                }
                return rslt;
            }
        }
        #endregion

        #region Constructors
        public OOMMEntity()
        {
            _ID = Guid.NewGuid();
            _Name = string.Empty;
            _Attributes = new List<OOMMEntityAttribute>();
        }

        public OOMMEntity(string name)
            : this()
        {
            _Name = name;
        }

        public OOMMEntity(string name, List<OOMMEntityAttribute> attributes)
            : this()
        {
            _Name = name;
            _Attributes = attributes;
        }

        public OOMMEntity(Guid id, string name, List<OOMMEntityAttribute> attributes)
        {
            _ID = id;
            _Name = name;
            _Attributes = attributes;
        }

        public OOMMEntity(SerializationInfo info, StreamingContext ctxt)
        {
            _ID = (Guid)info.GetValue("ID", typeof(Guid));
            _Name = (string)info.GetValue("Name", typeof(string));
            _Attributes = (List<OOMMEntityAttribute>)info.GetValue("Attributes", typeof(List<OOMMEntityAttribute>));
        }
        #endregion

        #region ISerializable Method
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("ID", _ID);
            info.AddValue("Name", _Name);
            info.AddValue("Attributes", _Attributes);
        }
        #endregion

        #region Methods
        public OOMMEntity Clone()
        {
            OOMMEntity rslt = new OOMMEntity((string)this.Name.Clone());
            this.Attributes.ForEach(a => rslt.Attributes.Add(a.Clone()));

            return rslt;
        }

        public override bool Equals(object obj)
        {
            bool rslt = false;
            if (obj is OOMMEntity)
            {
                rslt = _ID.Equals(((OOMMEntity)obj).ID);
            }
            return rslt;
        }

        public override int GetHashCode()
        {
            return _ID.GetHashCode();
        }
        #endregion

    }

}
