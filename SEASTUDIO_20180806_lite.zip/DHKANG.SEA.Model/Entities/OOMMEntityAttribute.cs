﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.Entities
{
    [Serializable()]
    public class OOMMEntityAttribute : ISerializable
    {
        #region Member Variables
        private string _Name;
        private string _Type;
        private string _InitialValue;

        #endregion

        #region Properties
        public string Name { get { return _Name; } set { _Name = value; } }
        public string Type { get { return _Type; } set { _Type = value; } }
        public string InitialValue { get { return _InitialValue; } set { _InitialValue = value; } }
        #endregion

        #region Constructors
        public OOMMEntityAttribute()
        {
            _Name = string.Empty;
            _Type = string.Empty;
            _InitialValue = string.Empty;
        }

        public OOMMEntityAttribute(string name, string type, string initialvalue)
        {
            _Name = name;
            _Type = type;
            _InitialValue = initialvalue;
        }

        public OOMMEntityAttribute(SerializationInfo info, StreamingContext ctxt)
        {
            _Name = (string)info.GetValue("Name", typeof(string));
            _Type = (string)info.GetValue("Type", typeof(string));
            _InitialValue = (string)info.GetValue("InitialValue", typeof(string));
        }
        #endregion

        #region Methods
        public OOMMEntityAttribute Clone()
        {
            OOMMEntityAttribute rslt = new OOMMEntityAttribute(
                                            (string)this.Name.Clone(),
                                            (string)this.Type.Clone(),
                                            (string)this.InitialValue.Clone());

            return rslt;
        }
        #endregion

        #region ISerializable Method
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Name", _Name);
            info.AddValue("Type", _Type);
            info.AddValue("InitialValue", _InitialValue);
        }
        #endregion
    }
}
