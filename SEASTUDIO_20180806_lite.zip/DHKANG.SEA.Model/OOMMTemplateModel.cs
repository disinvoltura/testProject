﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model.ActivityObjects;

namespace DHKANG.SEA.Model
{
    [Serializable()]
    public class OOMMTemplateModel : ISerializable
    {
        #region Member Variables
        private string _Name;
        private string _Description;
        private string _Creator;
        private string _FileName;

        private List<OOEGEventObjectModel> _EventObjects;
        private List<OOSGStateObjectModel> _StateObjects;
        private List<OOAGActivityObjectModel> _ActivityObjects;
        private List<OOMMModelProperty> _Properties;
        #endregion

        #region Properties
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        public string Description
        {
            get { return _Description; }
            set { _Description = value; }
        }

        public string Creator
        {
            get { return _Creator; }
            set { _Creator = value; }
        }

        public List<OOEGEventObjectModel> EventObjectModels
        {
            get { return _EventObjects; }
            set { _EventObjects = value; }
        }

        public List<OOSGStateObjectModel> StateObjectModels
        {
            get { return _StateObjects; }
            set { _StateObjects = value; }
        }

        public List<OOAGActivityObjectModel> ActivityObjectModels
        {
            get { return _ActivityObjects; }
            set { _ActivityObjects = value; }
        }

        public List<OOMMModelProperty> Properties
        {
            get { return _Properties; }
            set { _Properties = value; }
        }

        public string FileName
        {
            get { return _FileName; }
            set { _FileName = value; }
        }
        #endregion

        #region Constructors
        public OOMMTemplateModel()
        {
            _Name = string.Empty;
            _Description = string.Empty;
            _Creator = string.Empty;
            _EventObjects = new List<OOEGEventObjectModel>();
            _StateObjects = new List<OOSGStateObjectModel>();
            _ActivityObjects = new List<OOAGActivityObjectModel>();
            _Properties = new List<OOMMModelProperty>();
        }

        public OOMMTemplateModel(string name, string desc, string creator)
            : this()
        {
            _Name = name;
            _Description = desc;
            _Creator = creator;
        }

        public OOMMTemplateModel(SerializationInfo info, StreamingContext ctx)
        {
            _Name = (string)info.GetValue("Name", typeof(string));
            _Description = (string)info.GetValue("Description", typeof(string));
            _Creator = (string)info.GetValue("Creator", typeof(string));
            _EventObjects = (List<OOEGEventObjectModel>)info.GetValue("EventObjects", typeof(List<OOEGEventObjectModel>));
            _StateObjects = (List<OOSGStateObjectModel>)info.GetValue("StateObjects", typeof(List<OOSGStateObjectModel>));
            _ActivityObjects = (List<OOAGActivityObjectModel>)info.GetValue("ActivityObjects", typeof(List<OOAGActivityObjectModel>));
            _Properties = (List<OOMMModelProperty>)info.GetValue("Properties", typeof(List<OOMMModelProperty>));
        }            
        #endregion

        #region Methods
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Name", _Name);
            info.AddValue("Description", _Description);
            info.AddValue("Creator", _Creator);
            info.AddValue("EventObjects", _EventObjects);
            info.AddValue("StateObjects", _StateObjects);
            info.AddValue("ActivityObjects", _ActivityObjects);
            info.AddValue("Properties", _Properties);
        }

        /// <summary>
        /// Return an Event Object Model whose name is same as the given name
        /// </summary>
        /// <param name="targetName">Event Object Name</param>
        /// <returns></returns>
        public OOEGEventObjectModel FindEventObjectModel(string targetName)
        {
            OOEGEventObjectModel rslt = null;

            foreach (OOEGEventObjectModel model in _EventObjects)
            {
                if (model.Name == targetName)
                {
                    rslt = model;
                    break;
                }
            }
            return rslt;
        }

        public OOEGEventObjectModel FindEventObjectModel(Guid targetID)
        {
            OOEGEventObjectModel rslt = null;

            foreach (OOEGEventObjectModel model in _EventObjects)
            {
                if (model.ID == targetID)
                {
                    rslt = model;
                    break;
                }
            }
            return rslt;
        }

        public OOSGStateObjectModel FindStateObjectModel(string targetName)
        {
            OOSGStateObjectModel rslt = null;

            foreach (OOSGStateObjectModel model in _StateObjects)
            {
                if (model.Name == targetName)
                {
                    rslt = model;
                    break;
                }
            }
            return rslt;
        }

        public OOSGStateObjectModel FindStateObjectModel(Guid targetID)
        {
            OOSGStateObjectModel rslt = null;

            foreach (OOSGStateObjectModel model in _StateObjects)
            {
                if (model.ID == targetID)
                {
                    rslt = model;
                    break;
                }
            }
            return rslt;
        }

        public OOAGActivityObjectModel FindActivityObjectModel(string targetName)
        {
            OOAGActivityObjectModel rslt = null;

            foreach (OOAGActivityObjectModel model in _ActivityObjects)
            {
                if (model.Name == targetName)
                {
                    rslt = model;
                    break;
                }
            }
            return rslt;
        }

        public OOAGActivityObjectModel FindActivityObjectModel(Guid targetID)
        {
            OOAGActivityObjectModel rslt = null;

            foreach (OOAGActivityObjectModel model in _ActivityObjects)
            {
                if (model.ID == targetID)
                {
                    rslt = model;
                    break;
                }
            }
            return rslt;
        }

        public object FindProperty(string name)
        {
            object rslt = null;

            foreach(OOMMModelProperty property in _Properties)
            {
                if (property.Name.Equals(name))
                {
                    rslt = property.Value;
                    break;
                }
            }
            return rslt;
        }

        #endregion
    }
}
