﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Data;
using System.Xml;

namespace DHKANG.SEA.Model.Data
{
    [Serializable()]
    public class OOMMDataTable : ISerializable
    {
        #region Member Variables
        private string _Name;
        private DataSource _DataSource;
        private DataTable _DataTable;
        #endregion

        #region Properties
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        public DataSource DataSource
        {
            get { return _DataSource; }
            set { _DataSource = value; }
        }

        public DataTable DataTable
        {
            get { return _DataTable; }
            set { _DataTable = value; }
        }
        #endregion

        #region Constructors
        public OOMMDataTable(
            SerializationInfo info, 
            StreamingContext context)
        {
            _Name = (string)info.GetValue("Name", typeof(string));
            _DataSource = (DataSource)info.GetValue("DataSource", typeof(DataSource));
            _DataTable = (DataTable)info.GetValue("DataTable", typeof(DataTable));

        }

        public OOMMDataTable(string name)
        {
            _Name = name;
        }
        #endregion

        #region Methods
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Name", _Name);
            info.AddValue("DataSource", _DataSource);
            info.AddValue("DataTable", _DataTable);
        }
        #endregion
    }

    public class DataSource
    {
        #region Member Variable
        private string _DataSourceType;//Excel/Database/Manual
        private string _DataSourceConnectionString;
        private string _DataSourceTableName;
        private string _DataSourceQueryString;
        #endregion

        #region Properties
        public string Type { get { return _DataSourceType; } }
        public string ConnectionString { get { return _DataSourceConnectionString; } }
        public string TableName { get { return _DataSourceTableName; } }
        public string QueryString { get { return _DataSourceQueryString; } }
        #endregion

        #region Constructors
        public DataSource()
        {
            _DataSourceType = string.Empty;
            _DataSourceConnectionString = string.Empty;
            _DataSourceTableName = string.Empty;
            _DataSourceQueryString = string.Empty;
        }

        public DataSource(string type, string connectionString, string tableName, string queryString)
        {
            _DataSourceType = type;
            _DataSourceConnectionString = connectionString;
            _DataSourceTableName = tableName;
            _DataSourceQueryString = queryString;
        }

        public DataSource(SerializationInfo info, StreamingContext context)
        {
            _DataSourceType = (string)info.GetValue("Type", typeof(string));
            _DataSourceConnectionString = (string)info.GetValue("ConnectionString", typeof(string));
            _DataSourceTableName = (string)info.GetValue("TableName", typeof(string));
            _DataSourceQueryString = (string)info.GetValue("QueryString", typeof(string));
        }
        #endregion

        #region Methods
        private void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Type", _DataSourceType); 
            info.AddValue("ConnectionString", _DataSourceConnectionString); 
            info.AddValue("TableName", _DataSourceTableName); 
            info.AddValue("QueryString", _DataSourceQueryString); 
        }
        #endregion

    }
}
