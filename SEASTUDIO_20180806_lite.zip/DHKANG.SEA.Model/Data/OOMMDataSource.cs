﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model.Data
{
    [Serializable()]
    public enum OOMMDataSourceType { CSV, EXCEL, DATABASE };
    public enum OOMMDatabaseType { MYSQL, SQLSERVER, ORACLE};

    [Serializable()]
    public class OOMMDataSource : ISerializable
    {
        #region Member Variables
        private Guid _ID;
        private string _Name;
        private OOMMDataSourceType _DataType = OOMMDataSourceType.CSV;
        private OOMMDatabaseType _DBType = OOMMDatabaseType.MYSQL;
        private string _FileName;
        private List<string> _Sheets;

        private string _ConnectionString;
        private string _Query;

        #endregion

        #region Properties
        public Guid ID { get { return _ID; } set { _ID = value; } }
        public string Name { get { return _Name; } set { _Name = value; } }
        public OOMMDataSourceType Type { get { return _DataType; } set { _DataType = value; } }
        public string FileName { get { return _FileName; } set { _FileName = value; } }
        public List<string> Sheets { get { return _Sheets; } set { _Sheets = value; } }

        public string ConnectionString { get { return _ConnectionString; } set { _ConnectionString = value; } }
        public string Query { get { return _Query; } set { _Query = value; } }
        public OOMMDatabaseType DatabaseType { get { return _DBType; } set { _DBType = value; } }

        #endregion

        #region Constructors
        public OOMMDataSource()
        {
            _ID = Guid.NewGuid();
            _Name = string.Empty;
            _Sheets = new List<string>();
        }

        /// <summary>
        /// Default Constructor
        /// </summary>
        /// <param name="name"></param>
        /// <param name="type"></param>
        public OOMMDataSource(string name, OOMMDataSourceType type)
            : this()
        {
            _Name = name;
            _DataType = type;
        }

        /// <summary>
        /// Data Source for CSV
        /// </summary>
        /// <param name="name"></param>
        /// <param name="type"></param>
        /// <param name="filename"></param>
        public OOMMDataSource(string name, OOMMDataSourceType type, string filename)
            : this()
        {
            _Name = name;
            _DataType = type;
            _FileName = filename;
        }

        /// <summary>
        /// Data Source for Excel
        /// </summary>
        /// <param name="name"></param>
        /// <param name="type"></param>
        /// <param name="filename"></param>
        /// <param name="sheets"></param>
        public OOMMDataSource(string name, OOMMDataSourceType type, string filename, List<string> sheets)
            : this()
        {
            _Name = name;
            _DataType = type;
            _FileName = filename;
            _Sheets = sheets;
        }

        /// <summary>
        /// Data Source for Database
        /// </summary>
        /// <param name="name"></param>
        /// <param name="type"></param>
        /// <param name="connectionString"></param>
        /// <param name="query"></param>
        public OOMMDataSource(string name, OOMMDataSourceType type, OOMMDatabaseType dbType, string connectionString, string query)
            : this()
        {
            _Name = name;
            _DataType = type;
            _DBType = dbType;
            _ConnectionString = connectionString;
            _Query = query;
        }

        public OOMMDataSource(SerializationInfo info, StreamingContext ctxt)
        {
            _ID = (Guid)info.GetValue("ID", typeof(Guid));
            _Name = (string)info.GetValue("Name", typeof(string));
            _DataType = (OOMMDataSourceType)info.GetValue("Type", typeof(OOMMDataSourceType));
            _FileName = (string)info.GetValue("FileName", typeof(string));
            _Sheets = (List<string>)info.GetValue("Sheets", typeof(List<string>));

            _ConnectionString = (string)info.GetValue("ConnectionString", typeof(string));
            _Query = (string)info.GetValue("Query", typeof(string));
            _DBType = (OOMMDatabaseType)info.GetValue("DatabaseType", typeof(OOMMDatabaseType));
        }
        #endregion

        #region ISerializable Method
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("ID", _ID);
            info.AddValue("Name", _Name);
            info.AddValue("Type", _DataType);
            info.AddValue("FileName", _FileName);
            info.AddValue("Sheets", _Sheets);

            info.AddValue("ConnectionString", _ConnectionString);
            info.AddValue("Query", _Query);
            info.AddValue("DatabaseType", _DBType);
        }
        #endregion

        #region Methods
        public OOMMDataSource Clone()
        {
            OOMMDataSource rslt = null;
    
            if (this.Type == OOMMDataSourceType.CSV)
            {
                rslt = new OOMMDataSource(
                                (string)this.Name.Clone(), 
                                OOMMDataSourceType.CSV, 
                                (string)this.FileName.Clone());
            }else if (this.Type == OOMMDataSourceType.DATABASE)
            {
                rslt = new OOMMDataSource(
                                (string)this.Name.Clone(), 
                                OOMMDataSourceType.DATABASE, 
                                this.DatabaseType, 
                                (string)this.ConnectionString.Clone(), 
                                (string)this.Query.Clone());
            }else if (this.Type == OOMMDataSourceType.EXCEL)
            {
                List<string> sheets = new List<string>();
                this.Sheets.ForEach(s => sheets.Add((string)s.Clone()));
                rslt = new OOMMDataSource(
                                (string)this.Name.Clone(),
                                OOMMDataSourceType.EXCEL,
                                (string)this.FileName.Clone(),
                                sheets);
            }

            return rslt;
        }
        public override bool Equals(object obj)
        {
            bool rslt = false;
            if (obj is OOMMDataSource)
            {
                rslt = _ID.Equals(((OOMMDataSource)obj).ID);
            }
            return rslt;
        }

        public override int GetHashCode()
        {
            return _ID.GetHashCode();
        }
        #endregion
    }
}