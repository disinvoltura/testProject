﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model.Data
{
    [Serializable()]
    public class OOMMDataSourceNode: ISerializable
    {
        #region Member Variables
        private Guid _ID;//reference to Data Source
        private string _Name;//Name of Data Source
        private float _X;
        private float _Y;
        private int _BackgroundColor;

        #endregion

        #region Properties
        public Guid ID { get { return _ID; } set { _ID = value; } }
        public string Name { get { return _Name; } set { _Name = value; } }
        public float X { get { return _X; } set { _X = value; } }
        public float Y { get { return _Y; } set { _Y = value; } }
        public int BackgroundColor { get { return _BackgroundColor; } set { _BackgroundColor = value; } }
        #endregion

        #region Constructors
        public OOMMDataSourceNode()
        {
        }

        public OOMMDataSourceNode(Guid id, string name, float x, float y)
        {
            _ID = id;
            _Name = name;
            _X = x;
            _Y = y;
        }

        public OOMMDataSourceNode(Guid id, string name, float x, float y, int backgroundcolor)
            : this(id, name, x, y)
        {
            _BackgroundColor = backgroundcolor;
        }

        public OOMMDataSourceNode(SerializationInfo info, StreamingContext ctxt)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMDataSourceNode.ReadingSerializedObject()");
            
            _ID = (Guid)info.GetValue("ID", typeof(Guid));
            _Name = (string)info.GetValue("Name", typeof(string));
            _X = (float)info.GetValue("X", typeof(float));
            _Y = (float)info.GetValue("Y", typeof(float));
            _BackgroundColor = (int)info.GetValue("BackgroundColor", typeof(int));
        }
        #endregion

        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMDataSourceNode.GetObjectData()");
            
            info.AddValue("ID", _ID);
            info.AddValue("Name", _Name);
            info.AddValue("X", _X);
            info.AddValue("Y", _Y);
            info.AddValue("BackgroundColor", _BackgroundColor);
        }
    }
}
