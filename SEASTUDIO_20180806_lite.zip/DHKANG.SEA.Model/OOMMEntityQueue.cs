﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model
{
    public enum SelectionRule { FIFO, LIFO };
    [Serializable()]
    public class OOMMEntityQueue: ISerializable
    {
        #region Member Variables
        private Guid _NodeId;
        private string _Name;
        private SelectionRule _Rule;
        private List<OOMMObjectProperty> _Properties;
        private string _Desc;
        private float _X;
        private float _Y;

        #endregion

        #region Properties
        public Guid NodeID { get { return _NodeId; } set { _NodeId = value; } }
        public string Name { get { return _Name; } set { _Name = value; } }
        public string Description { get { return _Desc; } set { _Desc = value; } }
        public SelectionRule Rule { get { return _Rule; } set { _Rule = value; } }
        public List<OOMMObjectProperty> Properties { get { return _Properties; } set { _Properties = value; } }

        public float X { get { return _X; } set { _X = value; } }
        public float Y { get { return _Y; } set { _Y = value; } }

        #endregion

        #region Constructors
        public OOMMEntityQueue()
        {
            _NodeId = Guid.NewGuid();
            _Name = string.Empty;
            _Desc = string.Empty;
            _Rule = SelectionRule.FIFO;
            _Properties = new List<OOMMObjectProperty>();
        }

        public OOMMEntityQueue(string name)
        {
            _NodeId = Guid.NewGuid();
            _Name = name;
            _Desc = string.Empty;
            _Rule = SelectionRule.FIFO;
            _Properties = new List<OOMMObjectProperty>();
        }


        public OOMMEntityQueue(Guid nodeId, string name, SelectionRule rule, string desc, float x, float y)
            : this()
        {
            _NodeId = nodeId;
            _Name = name;
            _Rule = rule;
            _Desc = desc;
            _X = x;
            _Y = y;
        }

        public OOMMEntityQueue(Guid nodeId, string name, SelectionRule rule, string desc, List<OOMMObjectProperty> properties, float x, float y)
            : this(nodeId, name, rule, desc, x, y)
        {
            _Properties = properties;
        }

        public OOMMEntityQueue(SerializationInfo info, StreamingContext ctxt)
        {
            _NodeId = (Guid)info.GetValue("NodeId", typeof(Guid));
            _Name = (string)info.GetValue("Name", typeof(string));
            _Desc = (string)info.GetValue("Description", typeof(string));
            _Rule = (SelectionRule)info.GetValue("Rule", typeof(SelectionRule));
            _Properties = (List<OOMMObjectProperty>)info.GetValue("Properties", typeof(List<OOMMObjectProperty>));
            _X = (float)info.GetValue("X", typeof(float));
            _Y = (float)info.GetValue("Y", typeof(float));
        }
        #endregion

        #region Methods
        public OOMMEntityQueue Clone()
        {
            OOMMEntityQueue rslt = new OOMMEntityQueue(this.NodeID, this.Name, this.Rule, this.Description, this.X, this.Y);

            foreach (OOMMObjectProperty prop in this.Properties)
                rslt.Properties.Add(prop.Clone());

            return rslt;
        }

        public void AddProperty(OOMMObjectProperty value)
        {
            _Properties.Add(value);
        }

        public void AddProperty(string name, object value)
        {
            _Properties.Add(new OOMMObjectProperty(name, value));
        }
        #endregion

        #region ISerializable Method
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("NodeId", _NodeId);
            info.AddValue("Name", _Name);
            info.AddValue("Description", _Desc);
            info.AddValue("Rule", _Rule);
            info.AddValue("Properties", _Properties);
            info.AddValue("X", _X);
            info.AddValue("Y", _Y);
        }
        #endregion
    }
}
