﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Data;
using System.Runtime.Serialization;
using System.Drawing;

namespace DHKANG.SEA.Model.ActivityObjects
{
    [Serializable()]
    public class OOAGActivityObjectModel : OOMMObjectModel, ISerializable
    {
        #region Member Variables
        //public Guid ID;
        //public string Name;
        //public string Description;
        //public int BackgroundColor;

        public List<OOAGActivityTransition> ActivityTransitions;
        public List<OOAGQueue> Queues;
        public List<OOAGStateVariable> StateVariables;
        public List<OOAGArc> Arcs;
        #endregion

        #region Constructors
        public OOAGActivityObjectModel(): base()
        {
            //this.ID = Guid.NewGuid();
            this.ActivityTransitions = new List<OOAGActivityTransition>();
            this.Queues = new List<OOAGQueue>();
            this.StateVariables = new List<OOAGStateVariable>();
            this.Arcs = new List<OOAGArc>();
            this.BackgroundColor = Color.White.ToArgb();
        }

        public OOAGActivityObjectModel(string name, string desc) : base(name)
        {
            //this.Name = name;
            this.Description = desc;
        }

        /*
        public OOAGActivityObjectModel(Guid id, string name, string desc) : base()
        {
            this.ID = id;
            this.Name = name;
            this.Description = desc;
        }
        */

        public OOAGActivityObjectModel(SerializationInfo info, StreamingContext ctxt)
        {
            List<OOAGActivityTransition> evtTransitions = (List<OOAGActivityTransition>)info.GetValue("ActivityTransitions", typeof(List<OOAGActivityTransition>));

            List<OOAGQueue> stateVariables = (List<OOAGQueue>)info.GetValue("Queues", typeof(List<OOAGQueue>));

            List<OOAGStateVariable> parameters = (List<OOAGStateVariable>)info.GetValue("Variables", typeof(List<OOAGStateVariable>));

            List<OOAGArc> arcs = (List<OOAGArc>)info.GetValue("Arcs", typeof(List<OOAGArc>));

            ID = (Guid)info.GetValue("ID", typeof(Guid));
            Name = (string)info.GetValue("Name", typeof(string));
            Description = (string)info.GetValue("Description", typeof(string));

            try
            {
                BackgroundColor = (int)info.GetValue("BackgroundColor", typeof(int));
            }catch(Exception ex) { }
            
        }
        #endregion

        #region Queue Methods
        public bool ContainsQueue(string name)
        {
            OOAGQueue rslt = null;
            rslt = this.Queues.Find(q => q.Name.Equals(name));

            return rslt != null;
        }

        /*
        public void AddQueue(string name, string strType, int initvalue, string desc)
        {
            OOAGQueueType type = OOAGQueueType.Entity;
            if (strType.Equals("Resource") || strType.Equals("resource"))
                type = OOAGQueueType.Resource;
            else if (strType.Equals("Creator") || strType.Equals("creator"))
                type = OOAGQueueType.Creator;

            OOAGQueue queue = new OOAGQueue(name, type, initvalue, desc);
            //queue.Description = desc;

            this.Queues.Add(name, queue);
        }

        public void RemoveQueue(string name)
        {
            if (this.Queues.ContainsKey(name))
            {
                this.Queues.Remove(name);
            }
        }
        */
        #endregion

        #region Variable Methods
        public bool ContainsVariable(string name)
        {
            OOAGStateVariable rslt = null;
            rslt = this.StateVariables.Find(v => v.Name.Equals(name));

            return rslt != null;
        }

        /*
        public void AddVariable(string name, int row, int col, string type, string initvalue, string desc)
        {
            OOAGVariable variable = new OOAGVariable(name, row, col, type, initvalue, desc);
            this.Variables.Add(name, variable);
        }

        public void RemoveVariable(string name)
        {
            if (this.Variables.ContainsKey(name))
            {
                this.Variables.Remove(name);
            }
        }
        */
        #endregion

        #region Activity Transition
        public bool ContainsActivityTransition(string name)
        {
            OOAGActivityTransition rslt = null;
            rslt = this.ActivityTransitions.Find(at => at.Activity.Name.Equals(name));

            return rslt != null;
        }

        /*
        public void AddActivityTransition(string name, OOAGActivityTransition transition)
        {
            if (!this.ActivityTransitions.ContainsKey(name))
                this.ActivityTransitions.Add(name, transition);
        }

        public void RemoveActivityTransition(String name)
        {
            if (this.ActivityTransitions.ContainsKey(name))
                this.ActivityTransitions.Remove(name);
        }
        */
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("ID", this.ID);
            info.AddValue("Name", this.Name);
            info.AddValue("Description", this.Description);
            info.AddValue("ActivityTransitions", this.ActivityTransitions);
            info.AddValue("Queues", this.Queues);
            info.AddValue("Variables", this.StateVariables);
            info.AddValue("Arcs", this.Arcs);
            info.AddValue("BackgroundColor", this.BackgroundColor);
        }

        public OOAGQueue FindQueue(Guid id)
        {
            OOAGQueue rslt = null;
            rslt = this.Queues.Find(q => q.ID.Equals(id));

            return rslt;
        }

        public OOAGQueue FindQueue(string name)
        {
            OOAGQueue rslt = null;
            rslt = this.Queues.Find(q => q.Name.Equals(name));

            return rslt;
        }

        public OOAGActivity FindActivity(Guid id)
        {
            OOAGActivityTransition rslt = null;
            rslt = this.ActivityTransitions.Find(at => at.Activity.ID.Equals(id));

            return rslt.Activity;
        }

        public OOAGActivity FindActivity(string name)
        {
            OOAGActivityTransition rslt = null;
            rslt = this.ActivityTransitions.Find(at => at.Activity.Name.Equals(name));

            return rslt.Activity;
        }

        public OOAGStateVariable FindStateVariable(string name)
        {
            OOAGStateVariable rslt = null;
            rslt = this.StateVariables.Find(v => v.Name.Equals(name));

            return rslt;
        }

        #endregion

        #region Clone
        public OOAGActivityObjectModel Clone()
        {
            OOAGActivityObjectModel model = new OOAGActivityObjectModel(this.Name, this.Description);
            model.BackgroundColor = this.BackgroundColor;

            //activity transitions
            foreach (OOAGActivityTransition at in this.ActivityTransitions)
                model.ActivityTransitions.Add(at.Clone());

            //queues
            foreach (OOAGQueue q in this.Queues)
                model.Queues.Add(q.Clone());

            //state variables
            foreach (OOAGStateVariable sv in this.StateVariables)
                model.StateVariables.Add(sv.Clone());

            //arcs
            foreach (OOAGArc arc in this.Arcs)
                model.Arcs.Add(arc.Clone());

            return model;
        }
        #endregion
    }
}
