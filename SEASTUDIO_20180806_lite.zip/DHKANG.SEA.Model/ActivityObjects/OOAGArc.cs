﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.ActivityObjects
{
    public enum OOAGArcType { Resource, Entity };
    public enum OOAGArcStyle { Bezier, Line, RoundedLine, RoundedLineWithJumpOvers };
    public enum OOAGNodeType { Activity, Queue};

    public class OOAGArc
    {
        #region Member Variables
        private Guid _SourceId;
        private OOAGNodeType _SourceType;
        private Guid _DestinationId;
        private OOAGNodeType _DestinationType;
        private string _Condition = string.Empty;
        private OOAGArcType _Type;
        private int _Multiplicity;
        private float _Prob;
        private int _SourcePort;
        private int _DestinationPort;
        private OOAGArcStyle _Style;
        #endregion

        #region Properties
        public Guid SourceId { get { return _SourceId; } set { _SourceId = value; } }
        public OOAGNodeType SourceType  { get { return _SourceType; } set { _SourceType = value; } }
        public Guid DestinationId { get { return _DestinationId; } set { _DestinationId = value; } }
        public OOAGNodeType DestinationType { get { return _DestinationType; } set { _DestinationType = value; } }
        public OOAGArcType Type { get { return _Type; } set { _Type = value; } }
        public int Multiplicity { get { return _Multiplicity; } set { _Multiplicity = value; } }
        public float Probability { get { return _Prob; } set { _Prob = value; } }
        public string Condition { get { return _Condition; } set { _Condition = value; } }
        public int SourcePort { get { return _SourcePort; } set { _SourcePort = value; } }
        public int DestinationPort { get { return _DestinationPort; } set { _DestinationPort = value; } }
        public OOAGArcStyle Style { get { return _Style; } set { _Style = value; } }
        #endregion

        #region Constructors
        public OOAGArc()
        {

        }

        public OOAGArc(Guid sourceId, OOAGNodeType sourceType, Guid destId, OOAGNodeType destType, OOAGArcType type, int sourcePort, int destPort, OOAGArcStyle style, float prob)
        {
            _SourceId = sourceId;
            _SourceType = sourceType;
            _DestinationId = destId;
            _DestinationType = destType;
            _SourcePort = sourcePort;
            _DestinationPort = destPort;
            _Type = type;
            _Multiplicity = 1;
            _Style = style;
            _Prob = prob;
            _Condition = string.Empty;
        }

        public OOAGArc(Guid sourceId, OOAGNodeType sourceType, Guid destId, OOAGNodeType destType, OOAGArcType type, int sourcePort, int destPort, OOAGArcStyle style)
        {
            _SourceId = sourceId;
            _SourceType = sourceType;
            _DestinationId = destId;
            _DestinationType = destType;
            _SourcePort = sourcePort;
            _DestinationPort = destPort;
            _Type = type;
            _Multiplicity = 1;
            _Style = style;
            _Prob = 0.0f;
            _Condition = string.Empty;
        }

        public OOAGArc(Guid sourceId, OOAGNodeType sourceType, Guid destId, OOAGNodeType destType, OOAGArcType type, int sourcePort, int destPort, int multiplicity, float prob, string condition)
        {
            _SourceId = sourceId;
            _SourceType = sourceType;
            _DestinationId = destId;
            _DestinationType = destType;
            _SourcePort = sourcePort;
            _DestinationPort = destPort;
            _Type = type;
            _Multiplicity = multiplicity;
            _Prob = prob;
            _Condition = condition;
        }

        public OOAGArc(Guid sourceId, OOAGNodeType sourceType, Guid destId, OOAGNodeType destType, OOAGArcType type, int sourcePort, int destPort, OOAGArcStyle style, int multiplicity)
        {
            _SourceId = sourceId;
            _SourceType = sourceType;
            _DestinationId = destId;
            _DestinationType = destType;
            _SourcePort = sourcePort;
            _DestinationPort = destPort;
            _Style = style;
            _Type = type;
            _Multiplicity = multiplicity;
            _Condition = string.Empty;
        }

        public OOAGArc(Guid sourceId, OOAGNodeType sourceType, Guid destId, OOAGNodeType destType, OOAGArcType type, int sourcePort, int destPort, OOAGArcStyle style, int multiplicity, string condition)
        {
            _SourceId = sourceId;
            _SourceType = sourceType;
            _DestinationId = destId;
            _DestinationType = destType;
            _SourcePort = sourcePort;
            _DestinationPort = destPort;
            _Style = style;
            _Type = type;
            _Multiplicity = multiplicity;
            _Condition = condition;
        }

        #endregion

        #region Methods
        public OOAGArc Clone()
        {
            OOAGArc rslt = new OOAGArc(this.SourceId, this.SourceType, this.DestinationId, this.DestinationType, this.Type, this.SourcePort, this.DestinationPort, this.Style);
            rslt.Condition = this.Condition;
            rslt.Multiplicity = this.Multiplicity;
            rslt.Probability = this.Probability;

            return rslt;
        }

        public override bool Equals(object obj)
        {
            OOAGArc target = (OOAGArc)obj;
            if (target == null)
                return false;
            return (this.SourceId == target.SourceId &&
                this.DestinationId == target.DestinationId);
        }

        public override int GetHashCode()
        {
            return (_SourceId + "_" + _DestinationId).GetHashCode();
        }
        public override string ToString()
        {
            return (_SourceId + "_" + _DestinationId);
        }
        #endregion
    }
}
