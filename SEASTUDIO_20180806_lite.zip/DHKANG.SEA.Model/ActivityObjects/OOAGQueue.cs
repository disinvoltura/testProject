﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace DHKANG.SEA.Model.ActivityObjects
{

    public enum OOAGQueueType {Creator, Entity, Resource};
    [Serializable()]
    public class OOAGQueue : ISerializable
    {
        #region Member Variables
        public Guid ID;
        /// <summary>
        /// Name of Queue
        /// </summary>
        private string _Name;

        public string Name
        {
            get { return _Name; }
            set { string oldValue = _Name;
                _Name = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Name", oldValue, value);
            }
        }
        public string Parameters;
        public OOAGQueueType Type;
        /// <summary>
        /// Initial Value of Queue
        /// </summary>
        public string InitialValue;
        public string Description;

        /// <summary>
        /// Center Postion's X
        /// </summary>
        public float X;
        /// <summary>
        /// Center Position's Y
        /// </summary>
        public float Y;
        #endregion

        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Constructors
        public OOAGQueue()
        {
            this.ID = Guid.NewGuid();
            this.Name = string.Empty;
            this.Parameters = string.Empty;
            this.Type = OOAGQueueType.Entity;
        }

        public OOAGQueue(string name): this()
        {
            this.Name = name;
        }

        public OOAGQueue(string name, string parameters, OOAGQueueType type, string value, string desc)
            : this()
        {
            this.Name = name;
            this.Parameters = parameters;
            this.Type = type;

            this.InitialValue = value;
            this.Description = desc;
        }

        public OOAGQueue(string name, string parameters, OOAGQueueType type, string value, string desc, float x, float y)
            : this(name, parameters, type, value, desc)
        {
            
            this.X = x;
            this.Y = y;
        }

        public OOAGQueue(Guid id, string name, string parameters, OOAGQueueType type, string value, string desc, float x, float y)
        {
            this.ID = id;
            this.Name = name;
            this.Parameters = parameters;
            this.Type = type;
            this.InitialValue = value;
            this.Description = desc;

            this.X = x;
            this.Y = y;
        }

        public OOAGQueue(SerializationInfo info, StreamingContext ctxt)
        {
            ID = (Guid)info.GetValue("ID", typeof(Guid));
            Name = (string)info.GetValue("Name", typeof(string));
            Parameters = (string)info.GetValue("Parameters", typeof(string));
            Type = (OOAGQueueType)info.GetValue("Type", typeof(OOAGQueueType));
            InitialValue = (string)info.GetValue("InitialValue", typeof(string));
            Description = (string)info.GetValue("Description", typeof(string));

            X = (float)info.GetValue("X", typeof(float));
            Y = (float)info.GetValue("Y", typeof(float));
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("ID", ID);
            info.AddValue("Name", Name);
            info.AddValue("Parameters", Parameters);
            info.AddValue("Type", Type);
            info.AddValue("InitialValue", InitialValue);
            info.AddValue("Description", Description);
            info.AddValue("X", X);
            info.AddValue("Y", Y);
        }
        #endregion

        #region Methods
        public OOAGQueue Clone()
        {
            OOAGQueue rslt = new OOAGQueue(
                                 this.ID, this.Name, this.Parameters, this.Type, this.InitialValue, this.Description, this.X, this.Y);
            return rslt;
        }

        #endregion 
    }
}
