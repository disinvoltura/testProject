﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace DHKANG.SEA.Model.ActivityObjects
{
    [Serializable()]
    public class OOAGStateVariable : ISerializable
    {
        #region Member Variables
        /// <summary>
        /// Name of Variable
        /// </summary>
        public string Name;

        public int Row;
        public int Col;
        /// <summary>
        /// Type of Variable Value
        /// </summary>
        public string ValueType;

        /// <summary>
        /// Initial Value of Variable
        /// </summary>
        public string InitialValue;

        public string Description;
        #endregion

        #region Constructors
        public OOAGStateVariable()
        {
        }

        public OOAGStateVariable(string name, int row, int col, string valueType, string initialvalue, string description)
        {
            this.Name = name;
            this.Row = row;
            this.Col = col;
            this.ValueType = valueType;
            this.InitialValue = initialvalue;
            this.Description = description;
        }

        public OOAGStateVariable(SerializationInfo info, StreamingContext ctxt)
        {
            this.Name = (string)info.GetValue("Name", typeof(string));
            this.Row = (int)info.GetValue("Row", typeof(int));
            this.Col = (int)info.GetValue("Col", typeof(int));
            this.ValueType = (string)info.GetValue("ValueType", typeof(string));
            this.InitialValue = (string)info.GetValue("InitialValue", typeof(string));
            this.Description = (string)info.GetValue("Description", typeof(string));

        }
        #endregion

        #region Methods
        public OOAGStateVariable Clone()
        {
            OOAGStateVariable rslt = new OOAGStateVariable(
                                        this.Name, this.Row, this.Col, this.ValueType, this.InitialValue, this.Description);
            return rslt;
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Name", this.Name);
            info.AddValue("Row", this.Row);
            info.AddValue("Col", this.Col);
            info.AddValue("ValueType", this.ValueType);
            info.AddValue("InitialValue", this.InitialValue);
            info.AddValue("Description", this.Description);
        }
        #endregion
    }
}
