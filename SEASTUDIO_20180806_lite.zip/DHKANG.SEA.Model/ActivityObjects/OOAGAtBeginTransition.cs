﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace DHKANG.SEA.Model.ActivityObjects
{
    [Serializable()]
    public class OOAGAtBeginTransition : ISerializable
    {
        #region Member Variables
        /// <summary>
        /// At-begin Condition
        /// </summary>
        public string Condition;

        /// <summary>
        /// At-begin Action
        /// </summary>
        public string Action;
        #endregion

        #region Constructor
        public OOAGAtBeginTransition()
        {
            this.Condition = string.Empty;
            this.Action = string.Empty;
        }

        /// <summary>
        /// Constructor of At-begin Transition
        /// </summary>
        /// <param name="condition">At-begin Condition</param>
        /// <param name="action">At-begin Action</param>
        public OOAGAtBeginTransition(string condition, string action)
        {
            this.Condition = condition;
            this.Action = action;
        }

        public OOAGAtBeginTransition(SerializationInfo info, StreamingContext ctxt)
        {
            this.Condition = (string)info.GetValue("Condition", typeof(string));
            this.Action = (string)info.GetValue("Action", typeof(string));
        }
        #endregion

        #region Methods
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Condition", Condition);
            info.AddValue("Action", Action);
        }

        public OOAGAtBeginTransition Clone()
        {
            OOAGAtBeginTransition rslt = new OOAGAtBeginTransition(this.Condition, this.Action);
            return rslt;
        }
        #endregion
    }
}
