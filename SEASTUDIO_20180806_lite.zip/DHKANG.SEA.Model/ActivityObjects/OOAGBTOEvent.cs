﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace DHKANG.SEA.Model.ActivityObjects
{
    [Serializable()]
    public class OOAGBTOEvent : ISerializable
    {
        #region Member Variables
        /// <summary>
        /// BTO Event Name
        /// </summary>
        public string Name;
        /// <summary>
        /// BTO Event Time
        /// </summary>
        public string Time;
        #endregion

        #region Constructors
        /// <summary>
        /// Constructor of ATTBTOEvent
        /// </summary>
        public OOAGBTOEvent()
        {
            this.Name = string.Empty;
            this.Time = string.Empty;
        }

        /// <summary>
        /// Constructor of ATTBTOEvent
        /// </summary>
        /// <param name="name">BTO Event Name</param>
        /// <param name="time">BTO Event Time</param>
        public OOAGBTOEvent(string name, string time)
        {
            this.Name = name;
            this.Time = time;
        }

        public OOAGBTOEvent(SerializationInfo info, StreamingContext ctxt)
        {
            this.Name = (string)info.GetValue("Name", typeof(string));
            this.Time = (string)info.GetValue("Time", typeof(string));
        }
        #endregion

        #region Methods
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Name", this.Name);
            info.AddValue("Time", this.Time);
        }

        public OOAGBTOEvent Clone()
        {
            OOAGBTOEvent rslt = new OOAGBTOEvent(this.Name, this.Time);
            return rslt;
        }
        #endregion
    }
}
