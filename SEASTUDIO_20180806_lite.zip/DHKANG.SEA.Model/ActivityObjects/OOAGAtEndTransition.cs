﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace DHKANG.SEA.Model.ActivityObjects
{
    [Serializable()]
    public class OOAGAtEndTransition: ISerializable
    {
        #region Member Variables
        /// <summary>
        /// Arc No
        /// </summary>
        public int Arc;
        /// <summary>
        /// At-end Condition
        /// </summary>
        public string Condition;
        /// <summary>
        /// At-end Action
        /// </summary>
        public string Action;
        /// <summary>
        /// Influenced Activity
        /// </summary>
        public string InfluencedActivity;
        #endregion

        #region Constructors
        /// <summary>
        /// Consturctor of ATTAtEndTransition
        /// </summary>
        public OOAGAtEndTransition()
        {
            this.Condition = string.Empty;
            this.Action = string.Empty;
            this.InfluencedActivity = string.Empty;
        }

        /// <summary>
        /// Consturctor of ATTAtEndTransition
        /// </summary>
        /// <param name="arc">Arc No.</param>
        /// <param name="condition">At-end Condition</param>
        /// <param name="action">At-end Action</param>
        /// <param name="ia">Influenced Activity</param>
        public OOAGAtEndTransition(int arc, string condition, string action, string ia)
        {
            this.Arc = arc;
            this.Condition = condition;
            this.Action = action;
            this.InfluencedActivity = ia;
        }

        public OOAGAtEndTransition(SerializationInfo info, StreamingContext ctxt)
        {
            this.Arc = (int)info.GetValue("Arc", typeof(int));
            this.Condition = (string)info.GetValue("Condition", typeof(string));
            this.Action = (string)info.GetValue("Action", typeof(string));
            this.InfluencedActivity = (string)info.GetValue("InfluencedActivity", typeof(string));
        }
        #endregion

        #region Methods
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Arc", this.Arc);
            info.AddValue("Condition", this.Condition);
            info.AddValue("Action", this.Action);
            info.AddValue("InfluencedActivity", this.InfluencedActivity);
        }

        public OOAGAtEndTransition Clone()
        {
            return new OOAGAtEndTransition(this.Arc, this.Condition, this.Action, this.InfluencedActivity);
        }
        #endregion

    }
}
