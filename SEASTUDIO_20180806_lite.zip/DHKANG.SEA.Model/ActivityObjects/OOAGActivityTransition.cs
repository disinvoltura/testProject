﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace DHKANG.SEA.Model.ActivityObjects
{
    [Serializable()]
    public class OOAGActivityTransition : ISerializable
    {
        #region Member Variables
        public OOAGActivity Activity;
        public OOAGAtBeginTransition AtBegin;
        public OOAGBTOEvent BTOEvent;
        public List<OOAGAtEndTransition> AtEnds;
        #endregion

        #region Constructors
        /// <summary>
        /// constructor of OOAGActivityTransition
        /// </summary>
        public OOAGActivityTransition()
        {
            this.Activity = new OOAGActivity();
            this.AtBegin = new OOAGAtBeginTransition();
            this.BTOEvent = new OOAGBTOEvent();
            this.AtEnds = new List<OOAGAtEndTransition>();
        }

        public OOAGActivityTransition(SerializationInfo info, StreamingContext ctxt)
        {
            this.Activity = (OOAGActivity)info.GetValue("Activity", typeof(OOAGActivity));
            this.AtBegin = (OOAGAtBeginTransition)info.GetValue("AtBegin", typeof(OOAGAtBeginTransition));
            this.BTOEvent = (OOAGBTOEvent)info.GetValue("BTOEvent", typeof(OOAGBTOEvent)); 
            this.AtEnds = (List<OOAGAtEndTransition>)info.GetValue("AtEndTransitions", typeof(List<OOAGAtEndTransition>));
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Activity", Activity);
            info.AddValue("AtBegin", AtBegin);
            info.AddValue("BTOEvent", BTOEvent);
            info.AddValue("AtEndTransitions", AtEnds);
        }
        #endregion

        #region Methods
        public OOAGActivityTransition Clone()
        {
            OOAGActivityTransition rslt = new OOAGActivityTransition();

            rslt.Activity = this.Activity.Clone();
            rslt.AtBegin = this.AtBegin.Clone();
            rslt.BTOEvent = this.BTOEvent.Clone();

            foreach (OOAGAtEndTransition ae in this.AtEnds)
                rslt.AtEnds.Add(ae.Clone());

            return rslt;
        }
        #endregion
    }
}
