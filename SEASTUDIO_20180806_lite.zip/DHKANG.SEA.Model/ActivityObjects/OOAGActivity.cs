﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.ActivityObjects
{
    [Serializable()]
    public class OOAGActivity : ISerializable
    {
        #region Member Variable
        public Guid ID;
        private string _Name;
        public string Parameters;
        public bool IsEnabled;
        public string TimeDelay;

        /// <summary>
        /// Center Postion's X of an Event Vertex
        /// </summary>
        public float X;
        /// <summary>
        /// Center Position's Y of an Event Vertex
        /// </summary>
        public float Y;
        #endregion

        #region Properties
        public string Name
        {
            get { return _Name; }
            set
            {
                string oldValue = _Name;
                _Name = value;
                if (PropertyChanged != null && PropertyChanged.GetInvocationList().Length > 0)
                    this.PropertyChanged(this, "Name", oldValue, value);
            }
        }
        #endregion

        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Constructors
        public OOAGActivity()
        {
            this.ID = Guid.NewGuid();
            this.Name = string.Empty;
            this.Parameters = string.Empty;
            this.TimeDelay = string.Empty;
        }

        public OOAGActivity(string name, string parameters, string timeDelay)
            : this()
        {
            this.Name = name;
            this.Parameters = parameters;
            this.TimeDelay = timeDelay;
        }

        public OOAGActivity(string name, string parameters, string timeDelay, float x, float y):
            this(name, parameters, timeDelay)
        {
            this.X = x;
            this.Y = y;
        }

        public OOAGActivity(Guid id, string name, string parameters, string timeDelay, float x, float y) 
        {
            this.ID = id;
            this.Name = name;
            this.Parameters = parameters;
            this.TimeDelay = timeDelay;
            this.X = x;
            this.Y = y;
        }

        public OOAGActivity(SerializationInfo info, StreamingContext ctxt)
        {
            ID = (Guid)info.GetValue("ID", typeof(Guid));
            Name = (string)info.GetValue("Name", typeof(string));
            Parameters = (string)info.GetValue("Parameters", typeof(string));
            TimeDelay = (string)info.GetValue("TimeDelay", typeof(string));
            X = (float)info.GetValue("X", typeof(float));
            Y = (float)info.GetValue("Y", typeof(float));
        }
        #endregion

        #region Methods
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("ID", ID);
            info.AddValue("Name", Name);
            info.AddValue("Parameters", Parameters);
            info.AddValue("TimeDelay", TimeDelay);
            info.AddValue("X", X);
            info.AddValue("Y", Y);
        }

        public OOAGActivity Clone()
        {
            OOAGActivity newEvent = new OOAGActivity(
                this.ID,
                (string)this.Name.Clone(),
                (string)this.Parameters.Clone(),
                (string)this.TimeDelay.Clone(),
                this.X, this.Y);

            return newEvent;
        }

        #endregion
    }
}
