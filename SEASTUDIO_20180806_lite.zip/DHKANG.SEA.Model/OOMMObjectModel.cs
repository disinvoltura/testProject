﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model
{
    /// <summary>
    /// Object-oriented Multi-formalism Model's Object Model
    /// </summary>
    [Serializable]
    public class OOMMObjectModel
    {
        #region Member Variables
        private Guid _ID;
        private string _Name;
        private string _Description; 
        private string _Functions; 
        private int _BackgroundColor;
        private List<OOMMSchedule> _Schedules;
        private List<OOMMEntityQueue> _EntityQueues;
        #endregion

        #region Properties
        public Guid ID { get { return _ID; } set { _ID = value; } }
        public string Name { get { return _Name; } set { _Name = value; } }
        public string Description { get { return _Description; } set { _Description = value; } }
        public int BackgroundColor { get { return _BackgroundColor; } set { _BackgroundColor = value; } }
        public string Functions { get { return _Functions; } set { _Functions = value; } }

        public List<OOMMSchedule> Schedules
        {
            get { return _Schedules; }
            set { _Schedules = value; }
        }

        public List<OOMMEntityQueue> EntityQueues 
        {
            get { return _EntityQueues; }
            set { _EntityQueues = value; }
        }

        public OOMMObjectModel()
        {
            _ID = Guid.NewGuid();
            _Name = string.Empty;
            _Description = string.Empty;
            _Schedules = new List<OOMMSchedule>();
            _EntityQueues = new List<OOMMEntityQueue>();

            _BackgroundColor = Color.White.ToArgb();
        }

        public OOMMObjectModel(string name) : this()
        {
            _Name = name;
        }
        #endregion

        #region Methods
        public OOMMEntityQueue FindEntityQueue(string name)
        {
            OOMMEntityQueue rslt = null;

            foreach (OOMMEntityQueue q in _EntityQueues)
            {
                if (q.Name.Equals(name))
                {
                    rslt = q;
                    break;
                }
            }

            return rslt;
        }

        public OOMMSchedule FindSchedule(string name)
        {
            OOMMSchedule rslt = null;

            foreach (OOMMSchedule s in _Schedules)
            {
                if (s.Name.Equals(name))
                {
                    rslt = s;
                    break;
                }
            }

            return rslt;
        }
        #endregion
    }
}
