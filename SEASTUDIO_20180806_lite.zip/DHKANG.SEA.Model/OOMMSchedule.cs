﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model
{
    public enum ScheduleType { Integer, Float, Expression};
    public enum ScheduleTimeUnit { Seconds, Minutes, Hours, Days}
    [Serializable()]
    public class OOMMSchedule: ISerializable
    {
        #region Member Variables
        private Guid _NodeId;
        private string _Name;
        private ScheduleType _Type;
        private ScheduleTimeUnit _TimeUnit;
        private List<OOMMScheduleValue> _Values;
        private string _Desc;
        private float _X;
        private float _Y;

        #endregion

        #region Properties
        public Guid NodeID { get { return _NodeId; } set { _NodeId = value; } }
        public string Name { get { return _Name; } set { _Name = value; } }
        public string Description { get { return _Desc; } set { _Desc = value; } }
        public ScheduleType Type { get { return _Type; } set { _Type = value; } }
        public ScheduleTimeUnit TimeUnit { get { return _TimeUnit; } set { _TimeUnit = value; } }
        public List<OOMMScheduleValue> Values { get { return _Values; } set { _Values = value; } }

        public float X { get { return _X; } set { _X = value; } }
        public float Y { get { return _Y; } set { _Y = value; } }

        #endregion

        #region Constructors
        public OOMMSchedule()
        {
            _Name = string.Empty;
            _Desc = string.Empty;
            _Type = ScheduleType.Integer;//for capacity
            _TimeUnit = ScheduleTimeUnit.Seconds;
            _Values = new List<OOMMScheduleValue>();
        }
        public OOMMSchedule(Guid nodeId, string name, ScheduleType type, ScheduleTimeUnit tu, string desc, float x, float y)
        {
            _NodeId = nodeId;
            _Name = name;
            _Type = type;
            _TimeUnit = tu;
            _Desc = desc;
            _X = x;
            _Y = y;
            _Values = new List<OOMMScheduleValue>();
        }

        public OOMMSchedule(Guid nodeId, string name, ScheduleType type, ScheduleTimeUnit tu, string desc, List<OOMMScheduleValue> values, float x, float y)
            : this(nodeId, name, type, tu, desc, x, y)
        {
            _Values = values;
        }

        public OOMMSchedule(SerializationInfo info, StreamingContext ctxt)
        {
            _NodeId = (Guid)info.GetValue("NodeId", typeof(Guid));
            _Name = (string)info.GetValue("Name", typeof(string));
            _Desc = (string)info.GetValue("Description", typeof(string));
            _Type = (ScheduleType)info.GetValue("Type", typeof(ScheduleType));
            _TimeUnit = (ScheduleTimeUnit)info.GetValue("TimeUnit", typeof(ScheduleTimeUnit));
            _Values = (List<OOMMScheduleValue>)info.GetValue("Values", typeof(List<OOMMScheduleValue>));

            _X = (float)info.GetValue("X", typeof(float));
            _Y = (float)info.GetValue("Y", typeof(float));
        }
        #endregion

        #region Methods
        public OOMMSchedule Clone()
        {
            OOMMSchedule rslt = new OOMMSchedule(this.NodeID, this.Name, this.Type, this.TimeUnit, this.Description, this.X, this.Y);

            foreach (OOMMScheduleValue sv in this.Values)
                rslt.Values.Add(sv.Clone());

            return rslt;
        }

        public void Add(OOMMScheduleValue value)
        {
            _Values.Add(value);
        }

        public void Add(string duration, string value)
        {
            _Values.Add(new OOMMScheduleValue(duration, value));
        }
        #endregion

        #region ISerializable Method
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("NodeId", _NodeId);
            info.AddValue("Name", _Name);
            info.AddValue("Description", _Desc);
            info.AddValue("Type", _Type);
            info.AddValue("TimeUnit", _TimeUnit);
            info.AddValue("Values", _Values);

            info.AddValue("X", _X);
            info.AddValue("Y", _Y);

        }
        #endregion
    }

    [Serializable()]
    public class OOMMScheduleValue : ISerializable
    {
        #region Member Variable
        private string _Duration;
        private string _Value;
        #endregion

        #region Properties
        public string Duration { get { return _Duration; } set { _Duration = value; } }
        public string Value { get { return _Value; } set { _Value = value; } }
        #endregion

        #region Constructors
        public OOMMScheduleValue()
        {

        }

        public OOMMScheduleValue(string duration, string value)
        {
            _Duration = duration;
            _Value = value;
        }

        public OOMMScheduleValue(SerializationInfo info, StreamingContext ctxt)
        {
            _Duration = (string)info.GetValue("Duration", typeof(string));
            _Value= (string)info.GetValue("Value", typeof(string));
        }
        #endregion

        #region Methods
        public OOMMScheduleValue Clone()
        {
            OOMMScheduleValue rslt = new OOMMScheduleValue(this.Duration, this.Value);
            return rslt;
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Duration", _Duration);
            info.AddValue("Value", _Value);
        }
        #endregion
    }
}
