﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model.OID;
using DHKANG.SEA.Model.OID.Charts;
using DHKANG.SEA.Model.Data;
using DHKANG.SEA.Model.OID.Data;
using DHKANG.SEA.Model.OID.Presentation;
using DHKANG.SEA.Model.Entities;
using DHKANG.SEA.Model.Experiments;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model.ActivityObjects;

namespace DHKANG.SEA.Model
{
    public delegate void PropertyChangedEventHandler(object target, string propertyName, object oldPropertyValue, object newPropertyValue);

    [Serializable()]
    public class OOMMModel: ISerializable
    {
        #region Member Variables
        private Guid _ID;
        private string _Name;
        private string _Description;
        private string _Creator;
        private string _FileName;

        private List<OOMMModelProperty> _Properties;

        private List<OOEGEventObjectModel> _EventObjects;
        private List<OOSGStateObjectModel> _StateObjects;
        private List<OOAGActivityObjectModel> _ActivityObjects;

        //Entities
        private List<OOMMEntity> _Entities;

        //Data
        private List<OOMMDataSource> _DataSources;

        //Object-scheduling diagram
        private OOMMObjectInteractionDiagram _ObjectInteractionDiagram;

        private List<OOMMDataTable> _DataTableList;
        private List<OOMMUserClass> _UserClasses;

        //TODO remove the following variables
        private List<OOMMObjectNode> _ObjectNodes;
        private List<OOMMDataSourceNode> _DataSourceNodes;
        private List<OOMMTextNode> _Texts;
        private List<OOMMLabelNode> _Labels;
        private List<OOMMObjectInteractionEdge> _Edges;
        private List<OOMMDataAssociationEdge> _DataAssociations;
        private List<OOMMDataSetNode> _DataSetNodes;
        private List<OOMMStatisticsNode> _StatisticsNodes;
        private List<OOMMBarChart> _BarCharts;
        private List<OOMMPieChart> _PieCharts;
        private List<OOMMPlot> _Plots;
        private List<OOMMTimePlot> _TimePlots;

        //Experiments
        private List<OOMMExperiment> _Experiments;
        #endregion

        #region Properties
        public Guid ID
        {
            get
            {
                if (_ID.ToString() == "00000000-0000-0000-0000-000000000000")
                    _ID = Guid.NewGuid(); return _ID;
            }
            set { _ID = value; }
        }

        public List<OOMMModelProperty> Properties { get { return _Properties; } set { _Properties = value; } }
        public string Name { get { return _Name; } set { _Name = value; } }
        public string Description { get { return _Description; } set { _Description = value; } }
        public string Creator { get { return _Creator; } set { _Creator = value; } }
        public List<OOEGEventObjectModel> EventObjectModels { get { return _EventObjects; } set { _EventObjects = value; } }
        public List<OOSGStateObjectModel> StateObjectModels { get { return _StateObjects; } set { _StateObjects = value; } }
        public List<OOAGActivityObjectModel> ActivityObjectModels { get { return _ActivityObjects; } set { _ActivityObjects = value; } }

        public List<OOMMExperiment> Experiments { get { return _Experiments; } set { _Experiments = value; } }
        public List<OOMMDataSource> DataSources { get { return _DataSources; } set { _DataSources = value; } }
        public List<OOMMEntity> Entities { get { return _Entities; } set { _Entities = value; } }
        public List<OOMMUserClass> UserClasses { get { return _UserClasses; } set { _UserClasses = value; } }

        public string FileName { get { return _FileName; } set { _FileName = value; } }

        public OOMMObjectInteractionDiagram ObjectInteractionDiagram { get { return _ObjectInteractionDiagram; } set { _ObjectInteractionDiagram = value; } }
        //TODO remove the following properties
        public List<OOMMObjectNode> ObjectNodes { get { return _ObjectNodes; } set { _ObjectNodes = value; } }
        public List<OOMMDataSourceNode> DataSourceNodes { get { return _DataSourceNodes; } set { _DataSourceNodes = value; } }
        public List<OOMMObjectInteractionEdge> EventObjectSchedulingEdges { get { return _Edges; } set { _Edges = value; } }
        public List<OOMMDataAssociationEdge> DataAssociations { get { return _DataAssociations; } set { _DataAssociations = value; } }
        public List<OOMMTextNode> Texts { get { return _Texts; } set { _Texts = value; } }
        public List<OOMMLabelNode> Labels { get { return _Labels; } set { _Labels = value; } }
        public List<OOMMDataSetNode> DataSetNodes { get { return _DataSetNodes; } set { _DataSetNodes = value; } }
        public List<OOMMStatisticsNode> StatisticsNodes { get { return _StatisticsNodes; } set { _StatisticsNodes = value; } }
        public List<OOMMBarChart> BarCharts { get { return _BarCharts; } set { _BarCharts = value; } }
        public List<OOMMPieChart> PieCharts { get { return _PieCharts; } set { _PieCharts = value; } }
        public List<OOMMPlot> Plots { get { return _Plots; } set { _Plots = value; } }
        public List<OOMMTimePlot> TimePlots { get { return _TimePlots; } set { _TimePlots = value; } }
        
        /*
        public List<OOEGTemplate> Templates
        {
            get { return _Templates; }
            set { _Templates = value; }
        }
        */
        #endregion

        #region Constructors
        public OOMMModel()
        {
            _Name = string.Empty;
            _Description = string.Empty;
            _Creator = string.Empty;
            _EventObjects = new List<OOEGEventObjectModel>();
            _StateObjects = new List<OOSGStateObjectModel>();
            _ActivityObjects = new List<OOAGActivityObjectModel>();

            _Experiments = new List<OOMMExperiment>();
            _ObjectInteractionDiagram = new OOMMObjectInteractionDiagram();
            _UserClasses = new List<OOMMUserClass>();
            _FileName = string.Empty;

            _Properties = new List<OOMMModelProperty>();
            _Entities = new List<OOMMEntity>();
            _DataSources = new List<OOMMDataSource>();

            //TODO remove the followings...
            _Edges = new List<OOMMObjectInteractionEdge>();
            _Texts = new List<OOMMTextNode>();
            _Labels = new List<OOMMLabelNode>();            
            _ObjectNodes = new List<OOMMObjectNode>();
            _DataSourceNodes = new List<OOMMDataSourceNode>();
            _DataAssociations = new List<OOMMDataAssociationEdge>();
            _DataSetNodes = new List<OOMMDataSetNode>();
            _StatisticsNodes = new List<OOMMStatisticsNode>();
            _BarCharts = new List<OOMMBarChart>();
            _PieCharts = new List<OOMMPieChart>();
            _Plots = new List<OOMMPlot>();
            _TimePlots = new List<OOMMTimePlot>();
            
        }

        public OOMMModel(string name, string desc, string creator)
            : this()
        {
            _ID = Guid.NewGuid();
            _Name = name;
            _Description = desc;
            _Creator = creator;
        }

        public OOMMModel(SerializationInfo info, StreamingContext ctx)
        {
            _ID = (Guid)info.GetValue("ID", typeof(Guid));
            _Name = (string)info.GetValue("Name", typeof(string));
            _Description = (string)info.GetValue("Description", typeof(string));
            _Creator = (string)info.GetValue("Creator", typeof(string));
            _EventObjects = (List<OOEGEventObjectModel>)info.GetValue("EventObjectModels", typeof(List<OOEGEventObjectModel>));
            _StateObjects = (List<OOSGStateObjectModel>)info.GetValue("StateObjectModels", typeof(List<OOSGStateObjectModel>));
            try { _ActivityObjects = (List<OOAGActivityObjectModel>)info.GetValue("ActivityObjectModels", typeof(List<OOAGActivityObjectModel>)); } catch (Exception e) { }

            _Edges = (List<OOMMObjectInteractionEdge>)info.GetValue("Edges", typeof(List<OOMMObjectInteractionEdge>));
            _Texts = (List<OOMMTextNode>)info.GetValue("Texts", typeof(List<OOMMTextNode>));

            try { _Labels = (List<OOMMLabelNode>)info.GetValue("Labels", typeof(List<OOMMLabelNode>)); } catch (Exception e) { }

            try { _Properties = (List<OOMMModelProperty>)info.GetValue("Properties", typeof(List<OOMMModelProperty>)); } catch (Exception e) { }

            try { _ObjectNodes = (List<OOMMObjectNode>)info.GetValue("ObjectNodes", typeof(List<OOMMObjectNode>)); } catch (Exception e) { }

            try { _Entities = (List<OOMMEntity>)info.GetValue("Entities", typeof(List<OOMMEntity>)); } catch (Exception e) { }
            try { _DataSources = (List<OOMMDataSource>)info.GetValue("DataSources", typeof(List<OOMMDataSource>)); } catch (Exception e) { }
            try { _DataAssociations = (List<OOMMDataAssociationEdge>)info.GetValue("DataAssociations", typeof(List<OOMMDataAssociationEdge>)); } catch (Exception e) { }
            try { _DataSourceNodes = (List<OOMMDataSourceNode>)info.GetValue("DataSourceNodes", typeof(List<OOMMDataSourceNode>)); } catch (Exception e) { }

            try { _DataSetNodes = (List<OOMMDataSetNode>)info.GetValue("DataSetNodes", typeof(List<OOMMDataSourceNode>)); } catch (Exception e) { }
            try { _StatisticsNodes = (List<OOMMStatisticsNode>)info.GetValue("StatisticsNodes", typeof(List<OOMMDataSourceNode>)); } catch (Exception e) { }

            try { _BarCharts = (List<OOMMBarChart>)info.GetValue("BarCharts", typeof(List<OOMMBarChart>)); } catch (Exception e) { }
            try { _PieCharts = (List<OOMMPieChart>)info.GetValue("PieCharts", typeof(List<OOMMPieChart>)); } catch (Exception e) { }
            try { _Plots = (List<OOMMPlot>)info.GetValue("Plots", typeof(List<OOMMPlot>)); } catch (Exception e) { }
            try { _TimePlots = (List<OOMMTimePlot>)info.GetValue("TimePlots", typeof(List<OOMMTimePlot>)); } catch (Exception e) { }

            try { _Experiments = (List<OOMMExperiment>)info.GetValue("Experiments", typeof(List<OOMMExperiment>)); } catch (Exception e) { }

            try { _ObjectInteractionDiagram = (OOMMObjectInteractionDiagram)info.GetValue("ObjectInteractionDiagram", typeof(OOMMObjectInteractionDiagram)); } catch (Exception e) { }

            try { _ID = (Guid)info.GetValue("ID", typeof(Guid)); } catch (Exception e) { _ID = Guid.NewGuid(); }
            try { _FileName = (string)info.GetValue("FileName", typeof(string)); } catch (Exception e) {}

            try { _UserClasses = (List<OOMMUserClass>)info.GetValue("UserClasses", typeof(List<OOMMUserClass>)); } catch (Exception e) { }

            if (_ID.ToString() == "00000000-0000-0000-0000-000000000000")
                _ID = Guid.NewGuid();

        }
        #endregion

        #region Methods
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("ID", _ID);
            info.AddValue("Name", _Name);
            info.AddValue("Description", _Description);
            info.AddValue("Creator", _Creator);
            info.AddValue("EventObjectModels", _EventObjects);
            info.AddValue("StateObjectModels", _StateObjects);
            info.AddValue("ActivityObjectModels", _ActivityObjects);
            info.AddValue("Edges", _Edges);
            info.AddValue("Texts", _Texts);
            info.AddValue("Labels", _Labels);
            info.AddValue("Properties", _Properties);

            info.AddValue("UserClasses", _UserClasses);
            info.AddValue("Entities", _Entities);
            info.AddValue("DataSources", _DataSources);

            info.AddValue("Experiments", _Experiments);
            info.AddValue("ObjectInteractionDiagram", _ObjectInteractionDiagram);
            info.AddValue("ID", _ID);
            info.AddValue("FileName", _FileName);

            //TODO remove the followings:
            //info.AddValue("EOTemplates", _Templates);
            info.AddValue("ObjectNodes", _ObjectNodes);            
            info.AddValue("DataSourceNodes", _DataSourceNodes);
            info.AddValue("DataAssociations", _DataAssociations);
            info.AddValue("DataSetNodes", _DataSetNodes);
            info.AddValue("StatisticsNodes", _StatisticsNodes);
            info.AddValue("BarCharts", _BarCharts);
            info.AddValue("PieCharts", _PieCharts);
            info.AddValue("Plots", _Plots);
            info.AddValue("TimePlots", _Plots);
        }

        /// <summary>
        /// Return an Event Object Model whose name is same as the given name
        /// </summary>
        /// <param name="targetName">Event Object Name</param>
        /// <returns></returns>
        public OOEGEventObjectModel FindEventObjectModel(string targetName)
        {
            OOEGEventObjectModel rslt = null;

            foreach (OOEGEventObjectModel model in _EventObjects)
            {
                if (model.Name == targetName)
                {
                    rslt = model;
                    break;
                }
            }
            return rslt;
        }

        public OOEGEventObjectModel FindEventObjectModel(Guid targetID)
        {
            OOEGEventObjectModel rslt = null;

            foreach (OOEGEventObjectModel model in _EventObjects)
            {
                if (model.ID == targetID)
                {
                    rslt = model;
                    break;
                }
            }
            return rslt;
        }

        public OOAGActivityObjectModel FindActiviyObjectModel(string targetName)
        {
            OOAGActivityObjectModel rslt = null;

            foreach (OOAGActivityObjectModel model in _ActivityObjects)
            {
                if (model.Name == targetName)
                {
                    rslt = model;
                    break;
                }
            }
            return rslt;
        }

        public OOAGActivityObjectModel FindActiviyObjectModel(Guid targetID)
        {
            OOAGActivityObjectModel rslt = null;

            foreach (OOAGActivityObjectModel model in _ActivityObjects)
            {
                if (model.ID == targetID)
                {
                    rslt = model;
                    break;
                }
            }
            return rslt;
        }

        public OOSGStateObjectModel FindStateObjectModel(string targetName)
        {
            OOSGStateObjectModel rslt = null;

            foreach (OOSGStateObjectModel model in _StateObjects)
            {
                if (model.Name == targetName)
                {
                    rslt = model;
                    break;
                }
            }
            return rslt;
        }

        public OOSGStateObjectModel FindStateObjectModel(Guid targetID)
        {
            OOSGStateObjectModel rslt = null;

            foreach (OOSGStateObjectModel model in _StateObjects)
            {
                if (model.ID == targetID)
                {
                    rslt = model;
                    break;
                }
            }
            return rslt;
        }

        public OOAGActivityObjectModel FindActivityObjectModel(string targetName)
        {
            OOAGActivityObjectModel rslt = null;

            foreach (OOAGActivityObjectModel model in _ActivityObjects)
            {
                if (model.Name == targetName)
                {
                    rslt = model;
                    break;
                }
            }
            return rslt;
        }

        public OOAGActivityObjectModel FindActivityObjectModel(Guid targetID)
        {
            OOAGActivityObjectModel rslt = null;

            foreach (OOAGActivityObjectModel model in _ActivityObjects)
            {
                if (model.ID == targetID)
                {
                    rslt = model;
                    break;
                }
            }
            return rslt;
        }

        public OOMMExperiment FindExperiment(string targetName)
        {
            OOMMExperiment rslt = null;

            foreach (OOMMExperiment model in _Experiments)
            {
                if (model.Name == targetName)
                {
                    rslt = model;
                    break;
                }
            }
            return rslt;
        }

        public OOMMExperiment FindExperiment(Guid targetID)
        {
            OOMMExperiment rslt = null;

            foreach (OOMMExperiment model in _Experiments)
            {
                if (model.ID == targetID)
                {
                    rslt = model;
                    break;
                }
            }
            return rslt;
        }

        public object FindProperty(string name)
        {
            object rslt = null;

            foreach (OOMMModelProperty property in _Properties)
            {
                if (property.Name.Equals(name))
                {
                    rslt = property.Value;
                    break;
                }
            }
            return rslt;
        }

        public void SetProperty(string name, object value)
        {
            bool isNew = true;
            foreach (OOMMModelProperty property in _Properties)
            {
                if (property.Name.Equals(name))
                {
                    property.Value = value;
                    isNew = false;
                    break;
                }
            }

            if (isNew)
            {
                _Properties.Add(new OOMMModelProperty(name, value));
            }
        }

        public bool ContainEntity(string name)
        {
            bool rslt = false;

            foreach (OOMMEntity entity in _Entities)
            {
                if (entity.Name.Equals(name))
                {
                    rslt = true;
                    break;
                }
            }

            return rslt;

        }
        public OOMMEntity FindEntity(string name)
        {
            OOMMEntity rslt = null;

            foreach (OOMMEntity entity in _Entities)
            {
                if (entity.Name.Equals(name))
                {
                    rslt = entity;
                    break;
                }
            }

            return rslt;
        }

        public OOMMUserClass FindUserClass(string name)
        {
            OOMMUserClass rslt = null;

            foreach (OOMMUserClass value in _UserClasses)
            {
                if (value.Name.Equals(name))
                {
                    rslt = value;
                    break;
                }
            }

            return rslt;
        }

        public OOMMDataSource FindDataSource(string targetName)
        {
            OOMMDataSource rslt = null;

            foreach (OOMMDataSource model in _DataSources)
            {
                if (model.Name == targetName)
                {
                    rslt = model;
                    break;
                }
            }
            return rslt;
        }

        public OOMMDataSource FindDataSource(Guid targetID)
        {
            OOMMDataSource rslt = null;

            foreach (OOMMDataSource model in _DataSources)
            {
                if (model.ID == targetID)
                {
                    rslt = model;
                    break;
                }
            }
            return rslt;
        }
        #endregion
    }
}
