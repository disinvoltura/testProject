﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.OOEG.Model
{
    [Serializable()]
    public class OOEGSimulationExperiment: ISerializable
    {
        #region Member Variables
        private float _EOSTime;
        private bool _UseRandSeed;
        private int _RandSeed;
        #endregion

        #region Properties
        public float EOSTime { get { return _EOSTime; } set { _EOSTime = value; } }
        public bool UseRandSeed { get { return _UseRandSeed; } set { _UseRandSeed = value; } }
        public int RandSeed { get { return _RandSeed; } set { _RandSeed = value; } }
        #endregion

        #region Constructors
        public OOEGSimulationExperiment()
            : base()
        {
            _EOSTime = 0;
            _UseRandSeed = true;
            _RandSeed = 0;
        }
        
        /// <summary>
        /// Default Constructor
        /// </summary>
        public OOEGSimulationExperiment(string name, float eosTime)
            : base(name, OOEGExperimentType.SIMULATION)
        {
            _EOSTime = eosTime;
            _UseRandSeed = true;
        }
 
        /// <summary>
        /// Default Constructor
        /// </summary>
        public OOEGSimulationExperiment(string name, float eosTime, bool useRandSeed, int randSeed)
            : base(name, OOEGExperimentType.SIMULATION)
        {
            _EOSTime = eosTime;
            _UseRandSeed = useRandSeed;
            _RandSeed = randSeed;
        }

        public OOEGSimulationExperiment(SerializationInfo info, StreamingContext ctxt)
            : base(info, ctxt)
        {
            _EOSTime = (float)info.GetValue("EOSTime", typeof(float));
            _UseRandSeed = (bool)info.GetValue("UseRandSeed", typeof(bool));
            _RandSeed = (int)info.GetValue("RandSeed", typeof(int));
        }
        #endregion

        #region ISerializable Method
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        //void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("ID", _ID);
            info.AddValue("Name", _Name);
            info.AddValue("Type", _Type);

            info.AddValue("EOSTime", _EOSTime);
            info.AddValue("UseRandSeed", _UseRandSeed);
            info.AddValue("RandSeed", _RandSeed);
        }
        #endregion

        #region Methods
        public override bool Equals(object obj)
        {
            bool rslt = false;
            if (obj is OOEGExperiment)
            {
                rslt = _ID.Equals(((OOEGExperiment)obj).ID);
            }
            return rslt;
        }

        public override int GetHashCode()
        {
            return _ID.GetHashCode();
        }
        #endregion
    }
}