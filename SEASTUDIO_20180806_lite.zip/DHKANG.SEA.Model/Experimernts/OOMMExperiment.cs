﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model.Experiments
{
    [Serializable()]
    public enum OOMMExperimentType { SIMULATION, WHATIF, OPTIMIZATION };
    public enum OOMMTimeUnit { Weeks, Days, Hours, Minutes, Seconds};

    [Serializable()]
    public class OOMMExperiment: ISerializable
    {
        #region Member Variables
        protected Guid _ID;
        protected string _Name;
        protected OOMMExperimentType _Type = OOMMExperimentType.SIMULATION;
        #endregion

        #region Member Variables - Simulation Experiment
        private float _EOSTime;
        private OOMMTimeUnit _EOSTimeUnit;
        private bool _UseRandSeed;
        private int _RandSeed;
        private bool _FastForward; //only used in simulation setting (not stored)
        private bool _Parallel; //only used in simulation setting (not stored)
        #endregion

        #region Properties
        public Guid ID { get { return _ID; } set { _ID = value; } }
        public string Name { get { return _Name; } set { _Name = value; } }
        public OOMMExperimentType Type { get { return _Type; } set { _Type = value; } }
        #endregion

        #region Properties - Simulation Experiment
        public float EOSTime { get { return _EOSTime; } set { _EOSTime = value; } }
        public OOMMTimeUnit EOSTimeUnit { get { return _EOSTimeUnit; } set { _EOSTimeUnit = value; } }
        public bool UseRandSeed { get { return _UseRandSeed; } set { _UseRandSeed = value; } }
        public bool FastForward { get { return _FastForward; } set { _FastForward = value; } }
        public bool Parallel { get { return _Parallel; } set { _Parallel = value; } }
        public int RandSeed { get { return _RandSeed; } set { _RandSeed = value; } }
        #endregion

        #region Constructors
        public OOMMExperiment()
        {
            _ID = Guid.NewGuid();
            _Name = string.Empty;
            _EOSTimeUnit = OOMMTimeUnit.Seconds;
        }

        public OOMMExperiment(string name, float eosTime, OOMMTimeUnit timeUnit, bool useRandSeed, int randSeed)
            : this()
        {
            _Name = name;
            _Type = OOMMExperimentType.SIMULATION;
            _EOSTime = eosTime;
            _EOSTimeUnit = timeUnit;
            _UseRandSeed = useRandSeed;
            _RandSeed = randSeed;
        }

        public OOMMExperiment(Guid id, string name, float eosTime, OOMMTimeUnit timeUnit, bool useRandSeed, int randSeed)
           : this()
        {
            _ID = id;
            _Name = name;
            _Type = OOMMExperimentType.SIMULATION;
            _EOSTime = eosTime;
            _EOSTimeUnit = timeUnit;
            _UseRandSeed = useRandSeed;
            _RandSeed = randSeed;
        }

        public OOMMExperiment(SerializationInfo info, StreamingContext ctxt)
        {
            _ID = (Guid)info.GetValue("ID", typeof(Guid));
            _Name = (string)info.GetValue("Name", typeof(string));
            _Type = (OOMMExperimentType)info.GetValue("Type", typeof(OOMMExperimentType));

            _EOSTime = (float)info.GetValue("EOSTime", typeof(float));
            _EOSTimeUnit = (OOMMTimeUnit)info.GetValue("EOSTimeUnit", typeof(OOMMTimeUnit));
            _UseRandSeed = (bool)info.GetValue("UseRandSeed", typeof(bool));
            _RandSeed = (int)info.GetValue("RandSeed", typeof(int));
        }
        #endregion

        #region ISerializable Method
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("ID", _ID);
            info.AddValue("Name", _Name);
            info.AddValue("Type", _Type);

            info.AddValue("EOSTime", _EOSTime);
            info.AddValue("EOSTimeUnit", _EOSTimeUnit);
            info.AddValue("UseRandSeed", _UseRandSeed);
            info.AddValue("RandSeed", _RandSeed);
        }
        #endregion

        #region Methods
        public OOMMExperiment Clone()
        {
            OOMMExperiment rslt = new OOMMExperiment(this.Name, this.EOSTime, this.EOSTimeUnit, this.UseRandSeed, this.RandSeed);
            return rslt;
        }

        public override bool Equals(object obj)
        {
            bool rslt = false;
            if (obj is OOMMExperiment)
            {
                rslt = _ID.Equals(((OOMMExperiment)obj).ID);
            }
            return rslt;
        }

        public override int GetHashCode()
        {
            return _ID.GetHashCode();
        }
        #endregion
    }
}