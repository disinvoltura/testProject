﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model
{
    [Serializable()]
    public class OOMMRandomVariate : ISerializable
    {
        #region Member Variables
        private string _Expression;

        #endregion

        #region Properties
        public string Expression
        {
            get { return _Expression; }
        }
        #endregion

        #region Constructors
        public OOMMRandomVariate(string expr)
        {
            _Expression = expr;
        }

        public OOMMRandomVariate(SerializationInfo info, StreamingContext ctxt)
        {
            _Expression = (string)info.GetValue("Expr", typeof(string));
        }
        #endregion

        #region ISerializable Method
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Expr", _Expression);
        }
        #endregion
    }
}
