﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model
{
    [Serializable()]
    public class OOMMTemplate: ISerializable
    {
        #region Member Variables
        private string _Name;
        private string _Description;
        private string _Creator;

        //Key: name, value: Guid
        private Dictionary<string, Guid> _EventObjects;
        private Dictionary<string, Guid> _StateObjects;
        private Dictionary<string, Guid> _ActivityObjects;
        #endregion

        #region Properties
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        public string Description
        {
            get { return _Description; }
            set { _Description = value; }
        }

        public string Creator
        {
            get { return _Creator; }
            set { _Creator = value; }
        }

        public Dictionary<string, Guid> EventObjectModels
        {
            get { return _EventObjects; }
            set { _EventObjects = value; }
        }

        public Dictionary<string, Guid> StateObjectModels
        {
            get { return _StateObjects; }
            set { _StateObjects = value; }
        }

        public Dictionary<string, Guid> ActivityObjectModels
        {
            get { return _ActivityObjects; }
            set { _ActivityObjects = value; }
        }
        #endregion

        #region Constructors
        public OOMMTemplate()
        {
            _Name = string.Empty;
            _Description = string.Empty;
            _Creator = string.Empty;
            _EventObjects = new Dictionary<string, Guid>();
            _StateObjects = new Dictionary<string, Guid>();
            _ActivityObjects = new Dictionary<string, Guid>();
        }

        public OOMMTemplate(string name, string desc, string creator)
            : this()
        {
            _Name = name;
            _Description = desc;
            _Creator = creator;
        }

        public OOMMTemplate(SerializationInfo info, StreamingContext ctx)
        {
            _Name = (string)info.GetValue("Name", typeof(string));
            _Description = (string)info.GetValue("Description", typeof(string));
            _Creator = (string)info.GetValue("Creator", typeof(string));
            _EventObjects = (Dictionary<string,Guid>)info.GetValue("EventObjects", typeof(Dictionary<string,Guid>));
            _StateObjects = (Dictionary<string,Guid>)info.GetValue("StateObjects", typeof(Dictionary<string,Guid>));
            _ActivityObjects = (Dictionary<string,Guid>)info.GetValue("ActivityObjects", typeof(Dictionary<string,Guid>));
        }            
        #endregion

        #region Methods
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Name", _Name);
            info.AddValue("Description", _Description);
            info.AddValue("Creator", _Creator);
            info.AddValue("EventObjects", _EventObjects);
            info.AddValue("StateObjects", _StateObjects);
            info.AddValue("ActivityObjects", _ActivityObjects);
        }

        #endregion
    }
}
