﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model
{
    [Serializable()]
    public class OOMMModelProperty : ISerializable
    {
        #region Member Variables
        private string _Name;
        private object _Value;
        #endregion

        #region Properties
        public string Name { get {return _Name; } set {_Name = value;}}
        public object Value { get { return _Value;} set {_Value = value;}}
        #endregion 

        #region constructors
        public OOMMModelProperty()
        { }

        public OOMMModelProperty(string name, object value)
        {
            _Name = name;
            _Value = value;
        }
        
        public OOMMModelProperty(SerializationInfo info, StreamingContext ctxt)
        {
            _Name = (string)info.GetValue("Name", typeof(string));
            _Value = (object)info.GetValue("Value", typeof(object));
        }
        #endregion

        #region Methods
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Name", _Name);
            info.AddValue("Value", _Value);
        }
        #endregion
    }
}
