﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model
{
    public static class OOMMStateVariableHelper
    {
        private static List<string> _ValueTypeList;
        private static List<string> _PrimitiveValueTypeList;

        public static string TIMEQUEUE = "TimeQueue";
        public static string INT = "int";
        public static string DOUBLE = "double";
        public static string FLOAT = "float";
        public static string BOOL = "bool";
        public static string STRING = "string";
        public static string DATETIME = "DateTime";
        public static string POSITION = "Position";
        public static string RESOURCE = "Resource";
        public static string RANGE = "Range";
        public static string RANDOMVARIATE = "RandomVariate";
        public static string ENTITYQUEUE = "EntityQueue";
        public static string QUEUE = "Queue";

        static OOMMStateVariableHelper()
        {
            _ValueTypeList = new List<string>();
            _ValueTypeList.Add("bool");
            _ValueTypeList.Add("float");
            _ValueTypeList.Add("double");
            _ValueTypeList.Add("int");
            _ValueTypeList.Add("string");
            _ValueTypeList.Add("DateTime");
            _ValueTypeList.Add("TimeQueue");
            _ValueTypeList.Add("Position");
            _ValueTypeList.Add("Resource");
            _ValueTypeList.Add("Range");
            _ValueTypeList.Add("RandomVariate");
            _ValueTypeList.Add("EntityQueue");
            _ValueTypeList.Add("Queue");

            _PrimitiveValueTypeList = new List<string>() { "int", "float", "double", "string", "bool" ,"randomvariate"};

        }

        public static bool IsPrimitiveType(string valueType)
        {
            return _PrimitiveValueTypeList.Contains(valueType.ToLower());
        }

        public static bool IsCustomType(string valueType)
        {
            return !_ValueTypeList.Contains(valueType);
        }

        public static string DefaultValueType()
        {
            return "int";
        }

        public static List<string> ValueType()
        {
            return _ValueTypeList;
        }
    }
}
