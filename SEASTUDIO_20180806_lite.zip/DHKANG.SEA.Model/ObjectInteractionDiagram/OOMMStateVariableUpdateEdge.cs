﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.OID
{
    [Serializable()]
    public class OOMMStateVariableUpdateEdge : ISerializable
    {
        #region Member Variables
        private int _ID;
        private string _SourceStateVariable;//name of state variable
        private Guid _SourceEventObject; //ID of Event Object Model (from)
        private int _SourceEventPort;
        private string _DestStateVariable;
        private Guid _DestEventObject; //ID of Event Object Model (to)
        private int _DestEventPort;
        private int _StrokeStyle;

        private LinkType _Type;

        #endregion

        #region Properties
        public int ID { get { return _ID; } set { _ID = value; } }

        public string SourceStateVariable { get { return _SourceStateVariable; } set { _SourceStateVariable = value; } }
        public Guid SourceEventObject { get { return _SourceEventObject; } set { _SourceEventObject = value; } }
        public int SourceEventPort { get { return _SourceEventPort; } set { _SourceEventPort = value; } }
        public string DestinationStateVariable { get { return _DestStateVariable; } set { _DestStateVariable = value; } }
        public Guid DestinationEventObject { get { return _DestEventObject; } set { _DestEventObject = value; } }
        public int DestinationEventPort { get { return _DestEventPort; } set { _DestEventPort = value; } }
        public LinkType Type { get { return _Type; } set { _Type = value; } }
        public int StrokeStyle { get { return _StrokeStyle; } set { _StrokeStyle = value; } }

        #endregion

        #region Constructors
        public OOMMStateVariableUpdateEdge()
        {
            _SourceStateVariable = string.Empty;
            _DestStateVariable = string.Empty;
            _Type = LinkType.StateVariableUpdateLink;
            _StrokeStyle = 0;
        }

        public OOMMStateVariableUpdateEdge(
            int id, string srcSV, Guid srcEventObject, int srcEventPort, 
            string destSV, Guid destEventObject, int destEventPort, int strokeStyle)
        {
            _ID = id;
            _SourceStateVariable = srcSV;
            _SourceEventObject = srcEventObject;
            _SourceEventPort = srcEventPort;
            _DestStateVariable = destSV;
            _DestEventObject = destEventObject;
            _DestEventPort = destEventPort;
            _StrokeStyle = strokeStyle;

            _Type = LinkType.StateVariableUpdateLink;
        }

        public OOMMStateVariableUpdateEdge(SerializationInfo info, StreamingContext ctxt)
        {
            _ID = (int)info.GetValue("ID", typeof(int));
            _SourceStateVariable = (string)info.GetValue("SourceStateVariable", typeof(string));
            _SourceEventObject = (Guid)info.GetValue("SourceEventObject", typeof(Guid));
            _SourceEventPort = (int)info.GetValue("SourceEventPort", typeof(int));
            _DestStateVariable = (string)info.GetValue("DestinationStateVariable", typeof(string));
            _DestEventObject = (Guid)info.GetValue("DestinationEventObject", typeof(Guid));
            _DestEventPort = (int)info.GetValue("DestinationEventPort", typeof(int));
            _StrokeStyle = (int)info.GetValue("StrokeStyle", typeof(int));

            _Type = LinkType.StateVariableUpdateLink;
        }

        #endregion

        #region ISerializable Method
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("ID", _ID);
            info.AddValue("SourceStateVariable", _SourceStateVariable);
            info.AddValue("SourceEventObject", _SourceEventObject);
            info.AddValue("SourceEventPort", _SourceEventPort);
            info.AddValue("DestinationStateVariable", _DestStateVariable);
            info.AddValue("DestinationEventObject", _DestEventObject);
            info.AddValue("DestinationEventPort", _DestEventPort);
            info.AddValue("StrokeStyle", _StrokeStyle);
        }
        #endregion
    }

}
