﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.OID
{
    [Serializable()]
    public class OOMMDimension: ISerializable
    {
        #region Member Variables
        private float _X;
        private float _Y;
        private float _W;
        private float _H;
        #endregion

        #region Properties
        public float X { get { return _X; } set { _X = value; } }
        public float Y { get { return _Y; } set { _Y = value; } }
        public float Width { get { return _W; } set { _W = value; } }
        public float Height { get { return _H; } set { _H = value; } }
        #endregion

        #region Constructors
        public OOMMDimension()
        {

        }

        public OOMMDimension(float x, float y, float w, float h)
        {
            _X = x;
            _Y = y;
            _W = w;
            _H = h;
        }

        public OOMMDimension(SerializationInfo info, StreamingContext ctxt)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMDimension.ReadingSerializedObject()");

            _X = (float)info.GetValue("X", typeof(float));
            _Y = (float)info.GetValue("Y", typeof(float));
            _W = (float)info.GetValue("W", typeof(float));
            _H = (float)info.GetValue("H", typeof(float));
        }
        #endregion

        #region methods
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMDimension.GetObjectData()");

            info.AddValue("X", _X);
            info.AddValue("Y", _Y);
            info.AddValue("W", _W);
            info.AddValue("H", _H);
        }

        #endregion

    }
}
