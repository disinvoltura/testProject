﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model.OID
{
    public enum LinkType { SchedulingLink, DataAssociationLink, StateVariableUpdateLink };

    [Serializable()]
    public class OOMMObjectInteractionEdge : ISerializable
    {
        #region Member Variables
        private int _ID;
        private string _MirrorTriggerName;//event name or message name
        private Guid _MirrorObject; //ID of Object Model (from)
        private int _MirrorPort;
        private string _BoundaryTriggerName;//event name or message name
        private Guid _BoundaryObject; //ID of Object Model (to)
        private int _BoundaryPort;
        private string _Parameters;
        private int _StrokeStyle;
        
        private LinkType _Type;

        #endregion

        #region Properties
        public int ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        public string MirrorTriggerName
        {
            get { return _MirrorTriggerName; }
            set { _MirrorTriggerName = value; }
        }

        public Guid MirrorObject
        {
            get { return _MirrorObject; }
            set { _MirrorObject = value; }
        }
        public int MirrorPort
        {
            get { return _MirrorPort; }
            set { _MirrorPort = value; }
        }
        public string BoundaryTriggerName
        {
            get { return _BoundaryTriggerName; }
            set { _BoundaryTriggerName = value; }
        }

        public Guid BoundaryObject
        {
            get { return _BoundaryObject; }
            set { _BoundaryObject = value; }
        }
        public int BoundaryPort
        {
            get { return _BoundaryPort; }
            set { _BoundaryPort = value; }
        }
        public string Parameters
        {
            get { return _Parameters; }
            set { _Parameters = value; }
        }
        public LinkType Type { get { return _Type; } set { _Type = value; } }
        public int StrokeStyle
        {
            get
            {
                return _StrokeStyle;
            }
            set { _StrokeStyle = value; }
        } 
        #endregion

        #region Constructors
        public OOMMObjectInteractionEdge()
        {
            _MirrorTriggerName = string.Empty;
            _BoundaryTriggerName = string.Empty;
            _Type = LinkType.SchedulingLink;
            _StrokeStyle = 0;
        }

        public OOMMObjectInteractionEdge(
            int id, string mirrorEventName, Guid mirrorEventObject, int mirrorEventPort, string parameters,
            string boundaryEventName, Guid boundaryEventObject, int boundaryEventPort, int strokeStyle)
        {
            _ID = id;
            _MirrorTriggerName = mirrorEventName;
            _MirrorObject = mirrorEventObject;
            _MirrorPort = mirrorEventPort;
            _BoundaryTriggerName = boundaryEventName;
            _BoundaryObject = boundaryEventObject;
            _BoundaryPort = boundaryEventPort;
            _Parameters = parameters;
            _StrokeStyle = strokeStyle;

            _Type = LinkType.SchedulingLink;
        }

        public OOMMObjectInteractionEdge(SerializationInfo info, StreamingContext ctxt)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMObjectSchedulingEdge.ReadingSerializedObject()");

            _ID = (int)info.GetValue("ID", typeof(int));
            _MirrorTriggerName = (string)info.GetValue("MirrorTriggerName", typeof(string));
            _MirrorObject = (Guid)info.GetValue("MirrorObject", typeof(Guid));
            _BoundaryTriggerName = (string)info.GetValue("BoundaryTriggerName", typeof(string));
            _BoundaryObject = (Guid)info.GetValue("BoundaryObject", typeof(Guid));

            _Type = LinkType.SchedulingLink;

            try
            {
                _Parameters = (string)info.GetValue("Parameters", typeof(string));
            }
            catch (Exception ex)
            {
                _Parameters = string.Empty;
            }

            try
            {
                _MirrorPort = (int)info.GetValue("MirrorPort", typeof(int));
            }catch(Exception ex)
            {
                _MirrorPort = 1;
            }

            try
            {
                _BoundaryPort = (int)info.GetValue("BoundaryPort", typeof(int));
            }catch(Exception ex)
            {
                _BoundaryPort = 1;
            }

            try
            {
                _StrokeStyle = (int)info.GetValue("StrokeStyle", typeof(int));
            }catch(Exception ex)
            {
                _StrokeStyle = 0;
            }
        }

        #endregion

        #region ISerializable Method
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMObjectSchedulingEdge.GetObjectData()");

            info.AddValue("ID", _ID);
            info.AddValue("MirrorTriggerName", _MirrorTriggerName);
            info.AddValue("MirrorObject", _MirrorObject);
            info.AddValue("MirrorPort", _MirrorPort);
            info.AddValue("BoundaryTriggerName", _BoundaryTriggerName);
            info.AddValue("BoundaryObject", _BoundaryObject);
            info.AddValue("BoundaryPort", _BoundaryPort);
            info.AddValue("Parameters", _Parameters);
            info.AddValue("StrokeStyle", _StrokeStyle);
        }
        #endregion
    }
}
