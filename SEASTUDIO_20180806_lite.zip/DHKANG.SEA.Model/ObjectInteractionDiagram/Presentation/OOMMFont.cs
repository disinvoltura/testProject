﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.OID.Presentation
{
    public class OOMMFont : ISerializable
    {
        #region Member Variables
        private float _FontSize = 10.0f;
        private bool _FontBold = false;
        private bool _FontItalic = false;
        private bool _FontUnderline = false;
        private bool _FontStrikeout = false;
        private int _FontColor = -16777216;
        private string _FontName = "Arial";  //FontFamily
        #endregion

        #region Properties
        public float Size { get { return _FontSize; } set { _FontSize = value; } }
        public bool Bold { get { return _FontBold; } set { _FontBold = value; } }
        public bool Italic { get { return _FontItalic; } set { _FontItalic = value; } }
        public bool Underline { get { return _FontUnderline; } set { _FontUnderline = value; } }
        public bool Strikeout { get { return _FontStrikeout; } set { _FontStrikeout = value; } }
        public int Color { get { return _FontColor; } set { _FontColor = value; } }
        public string Name { get { return _FontName; } set { _FontName = value; } }

        #endregion

        #region Constructors
        public OOMMFont()
        {
        }

        public OOMMFont(string fontName, int fontColor, float fontsize)
        {
            _FontName = fontName;
            _FontColor = fontColor;
            _FontSize = fontsize;
        }

        public OOMMFont(string fontName, int fontColor, float fontsize, bool bold, bool italic, bool underline, bool strikeout)
            : this(fontName, fontColor, fontsize)
        {
            _FontSize = fontsize;
            _FontBold = bold;
            _FontItalic = italic;
            _FontUnderline = underline;
            _FontStrikeout = strikeout;
        }

        public OOMMFont(SerializationInfo info, StreamingContext ctxt)
        {
            _FontSize = (float)info.GetValue("FontSize", typeof(float));
            _FontBold = (bool)info.GetValue("FontBold", typeof(bool));
            _FontItalic = (bool)info.GetValue("FontItalic", typeof(bool));
            _FontUnderline = (bool)info.GetValue("FontUnderline", typeof(bool));
            _FontStrikeout = (bool)info.GetValue("FontStrikeout", typeof(bool));
            _FontColor = (int)info.GetValue("FontColor", typeof(int));
            _FontName = (string)info.GetValue("FontName", typeof(string));
        }
        #endregion

        #region Methods
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("FontBold", _FontBold);
            info.AddValue("FontItalic", _FontItalic);
            info.AddValue("FontUnderline", _FontUnderline);
            info.AddValue("FontStrikeout", _FontStrikeout);
            info.AddValue("FontColor", _FontColor);
            info.AddValue("FontName", _FontName);
            info.AddValue("FontSize", _FontSize);
        }
        #endregion

    }
}
