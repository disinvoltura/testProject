﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model.OID.Presentation
{
    [Serializable()]
    public class OOMMTextNode : ISerializable
    {
        #region Member Variables
        private string _Text;
        private float _X;
        private float _Y;
        private OOMMFont _Font;
        private int _BackColor = -1;
        private int _BorderColor;//no use up to now.
        private bool _TransparentBackground = false;
        #endregion

        #region Properties
        public string Text { get { return _Text; } set { _Text = value; } }
        public float X { get { return _X; } set { _X = value; } }
        public float Y { get { return _Y; } set { _Y = value; } }

        public OOMMFont Font{ get { return _Font; } set { _Font= value; } }
        public bool TransparentBackground{ get { return _TransparentBackground; } set { _TransparentBackground = value; } }

        public int BackColor { get { return _BackColor; } set { _BackColor = value; } }
        public int BorderColor { get { return _BorderColor; } set { _BorderColor = value; } }
        #endregion

        #region Constructors
        public OOMMTextNode()
        {
        }

        public OOMMTextNode(string textvalue, float x, float y)
        {
            _Text= textvalue;
            _X = x;
            _Y = y;
        }

        public OOMMTextNode(SerializationInfo info, StreamingContext ctxt)
        {
            _Text = (string)info.GetValue("Text", typeof(string));
            _X = (float)info.GetValue("X", typeof(float));
            _Y = (float)info.GetValue("Y", typeof(float));

            _Font = (OOMMFont)info.GetValue("Font", typeof(OOMMFont));

            _TransparentBackground = (bool)info.GetValue("TransparentBackground", typeof(bool));

            _BackColor = (int)info.GetValue("BackColor", typeof(int));
            _BorderColor = (int)info.GetValue("BorderColor", typeof(int));
        }
        #endregion

        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Text", _Text);
            info.AddValue("X", _X);
            info.AddValue("Y", _Y);

            info.AddValue("Font", _Font);
            info.AddValue("BackColor", _BackColor);
            info.AddValue("BorderColor", _BorderColor);
            info.AddValue("TransparentBackground", _TransparentBackground);
        }
    }
}
