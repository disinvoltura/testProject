﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model.OID.Presentation
{
    [Serializable()]
    public class OOMMLabelNode : ISerializable
    {
        #region Member Variables
        private Guid _NodeId;
        private string _LabelName;

        private Guid _ObjectID;
        private string _StateVariableName;
        private float _X;
        private float _Y;
        private int _BackColor = -1;
        private int _BorderColor;//no use up to now.
        private bool _TransparentBackground = false;
        private OOMMFont _Font;
        #endregion

        #region Properties
        public Guid NodeID { get { return _NodeId; } set { _NodeId = value; } }
        public string LabelName { get { return _LabelName; } set { _LabelName = value; } }

        public string StateVariableName { get { return _StateVariableName; } set { _StateVariableName = value; } }
        public Guid ObjectID { get { return _ObjectID; } set { _ObjectID = value; } }
        public float X { get { return _X; } set { _X = value; } }
        public float Y { get { return _Y; } set { _Y = value; } }

        public OOMMFont Font { get { return _Font; } set { _Font = value; } }

        public bool TransparentBackground { get { return _TransparentBackground; } set { _TransparentBackground = value; } }
        public int BackColor { get { return _BackColor; } set { _BackColor = value; } }
        public int BorderColor { get { return _BorderColor; } set { _BorderColor = value; } }
        #endregion

        #region Constructors
        public OOMMLabelNode()
        {
        }

        public OOMMLabelNode(Guid nodeid, string name, Guid objectID, string stateVariableName, float x, float y)
        {
            _NodeId = nodeid;
            _LabelName = name;

            _ObjectID = objectID;
            _StateVariableName = stateVariableName;
            _X = x;
            _Y = y;
        }

        public OOMMLabelNode(SerializationInfo info, StreamingContext ctxt)
        {
            try
            {
                _NodeId = (Guid)info.GetValue("NodeId", typeof(Guid));
            }
            catch (Exception ex)
            {
                _NodeId = Guid.NewGuid();
            }

            try
            {
                _LabelName = (string)info.GetValue("LabelName", typeof(string));
            }
            catch (Exception ex)
            {
                _LabelName = "Variable";
            }

            _ObjectID = (Guid)info.GetValue("ObjectID", typeof(Guid));
            _StateVariableName = (string)info.GetValue("StateVariableName", typeof(string));
            _X = (float)info.GetValue("X", typeof(float));
            _Y = (float)info.GetValue("Y", typeof(float));

            _TransparentBackground = (bool)info.GetValue("TransparentBackground", typeof(bool));
            _Font = (OOMMFont)info.GetValue("Font", typeof(OOMMFont));

            _BackColor = (int)info.GetValue("BackColor", typeof(int));
            _BorderColor = (int)info.GetValue("BorderColor", typeof(int));
        }
        #endregion

        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("NodeId", _NodeId);
            info.AddValue("LabelName", _LabelName);

            info.AddValue("ObjectID", _ObjectID);
            info.AddValue("StateVariableName", _StateVariableName);
            info.AddValue("X", _X);
            info.AddValue("Y", _Y);

            info.AddValue("Font", _Font);
            info.AddValue("BackColor", _BackColor);
            info.AddValue("BorderColor", _BorderColor);
            info.AddValue("TransparentBackground", _TransparentBackground);
        }
    }
}
