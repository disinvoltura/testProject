﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model.OID
{
    public enum ObjectNodeType { EventObject, StateObject, ActivityObject };

    [Serializable()]
    public class OOMMObjectNode: ISerializable, IComparable
    {
        #region Member Variables
        private Guid _ModelID;//reference to Event Object Model
        private Guid _NodeID;
        private ObjectNodeType _Type;
        private string _Name;//Name of Event Object Model
        private float _X;
        private float _Y;
        private int _BackgroundColor;

        private List<OOMMObjectStateVariable> _StateVariables;
        #endregion

        #region Properties
        public Guid NodeID { get { return _NodeID; } set { _NodeID = value; } }
        /// <summary>
        /// Event Object Model ID
        /// </summary>
        public Guid ModelID { get { return _ModelID; } set { _ModelID = value; } }
        public string Name { get { return _Name; } set { _Name = value; } }
        public float X { get { return _X; } set { _X = value; } }
        public float Y { get { return _Y; } set { _Y = value; } }
        public int BackgroundColor { get { return _BackgroundColor; } set { _BackgroundColor = value; } }
        public List<OOMMObjectStateVariable> StateVariables {  get { return _StateVariables; } set { _StateVariables = value; } }
        public ObjectNodeType Type { get { return _Type; } set { _Type = value; } }
        #endregion

        #region Constructors
        public OOMMObjectNode()
        {
            _StateVariables = new List<OOMMObjectStateVariable>();
        }

        public OOMMObjectNode(Guid nodeId, string name, Guid modelId, ObjectNodeType type, float x, float y)
            : this()
        {
            _NodeID = nodeId;
            _ModelID = modelId;
            _Name = name;
            _Type = type;
            _X = x;
            _Y = y;
        }

        public OOMMObjectNode(Guid nodeId, string name, Guid modelId, ObjectNodeType type, float x, float y, int backgroundcolor)
            : this(nodeId, name, modelId, type, x, y)
        {
            _BackgroundColor = backgroundcolor;
        }

        public OOMMObjectNode(SerializationInfo info, StreamingContext ctxt)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMObjectNode.ReadingSerializedObject()");

            try
            {
                _NodeID = (Guid)info.GetValue("NodeID", typeof(Guid));
            }catch(Exception e) { }
            try
            {
                _ModelID = (Guid)info.GetValue("ModelID", typeof(Guid));
            }
            catch (Exception e) { }

            _Name = (string)info.GetValue("Name", typeof(string));
            _X = (float)info.GetValue("X", typeof(float));
            _Y = (float)info.GetValue("Y", typeof(float));
            _Type = (ObjectNodeType)info.GetValue("Type", typeof(ObjectNodeType));
            _BackgroundColor = (int)info.GetValue("BackgroundColor", typeof(int));

            _StateVariables = 
                (List<OOMMObjectStateVariable>)
                    info.GetValue("StateVariables", typeof(List<OOMMObjectStateVariable>));
        }
        #endregion

        public void AddStateVariable(OOMMObjectStateVariable sv)
        {
            _StateVariables.Add(sv);
        }

        public void AddStateVariable(string name, string value)
        {
            _StateVariables.Add(new OOMMObjectStateVariable(name, value));
        }

        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMObjectNode.GetObjectData()");

            info.AddValue("NodeID", _NodeID);
            info.AddValue("ModelID", _ModelID);
            info.AddValue("Name", _Name);
            info.AddValue("Type", _Type);
            info.AddValue("X", _X);
            info.AddValue("Y", _Y);
            info.AddValue("BackgroundColor", _BackgroundColor);
            info.AddValue("StateVariables", _StateVariables);
        }

        public int CompareTo(object obj)
        {
            int rslt = 0;
            if (obj is OOMMObjectNode)
            {
                rslt = this.NodeID.CompareTo(((OOMMObjectNode)obj).NodeID);
            }

            return rslt;
        }
    }
}
