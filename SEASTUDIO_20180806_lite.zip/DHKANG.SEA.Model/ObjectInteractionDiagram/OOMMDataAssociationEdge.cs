﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model.OID
{
    //TODO 추후 Data Input and Output 을 구분해서 고려해보자.
    public enum DataAssociationType { Input, Output};
    public enum DataMappingType { Script, Auto};
    [Serializable()]
    public class OOMMDataMapper : ISerializable
    {
        #region Member Variables
        private string _Name;
        private string _Code;
        private DataMappingType _Type;

        //추후 auto는 구현
        #endregion

        #region Properties
        public string Name { get { return _Name;  } set { _Name = value; } }
        public string Code { get { return _Code;  } set { _Code = value; } }
        public DataMappingType Type { get { return _Type;  } set { _Type = value; } }
        #endregion

        #region Constructors
        public OOMMDataMapper()
        {
            _Type = DataMappingType.Script;
        }

        public OOMMDataMapper(string name, string code)
        {
            _Name = name;
            _Code = code;
            _Type = DataMappingType.Script;
        }

        public OOMMDataMapper(SerializationInfo info, StreamingContext ctxt)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMDataMapper.ReadingSerializedObject()");

            _Name = (string)info.GetValue("Name", typeof(string));
            _Code = (string)info.GetValue("Code", typeof(string));
            _Type = (DataMappingType)info.GetValue("Type", typeof(DataMappingType));
        }
        #endregion

        #region Methods
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMDataMapper.GetObjectData()");

            info.AddValue("Name", _Name);
            info.AddValue("Code", _Code);
            info.AddValue("Type", _Type);
        }

        public override int GetHashCode()
        {
            return _Name.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            bool rslt = false;
            if (obj is OOMMDataMapper)
            {
                if (_Name.Equals(((OOMMDataMapper)obj).Name))
                    rslt = true;
            }
            return rslt;
        }
        #endregion
    }

    [Serializable()]
    public class OOMMDataAssociationEdge : ISerializable
    {
        #region Member Variables
        private int _ID;
        //sourcebase.GetHashCode();
        private Guid _SourceDataSource; //ID of Data Source
        private int _SourcePort;

        //destination
        private Guid _TargetEventObject; //ID of Event Object Model (to)
        private int _TargetPort;
        
        private DataAssociationType _Type;
        private int _StrokeStyle;

        private List<OOMMDataMapper> _Mapping;
        #endregion

        #region Properties
        public int ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        public Guid SourceDataSource
        {
            get { return _SourceDataSource; }
            set { _SourceDataSource = value; }
        }
        public int SourcePort 
        {
            get { return _SourcePort; }
            set { _SourcePort = value; }
        }

        public Guid TargetEventObject 
        {
            get { return _TargetEventObject; }
            set { _TargetEventObject = value; }
        }

        public int TargetPort 
        {
            get { return _TargetPort; }
            set { _TargetPort = value; }
        }

        public DataAssociationType Type { get { return _Type; } set { _Type = value; } }

        public int StrokeStyle
        {
            get { return _StrokeStyle; }
            set { _StrokeStyle = value; }
        } 

        public List<OOMMDataMapper> DataMappers
        {
            get { return _Mapping; }
            set { _Mapping = value; }
        }
        #endregion

        #region Constructors
        public OOMMDataAssociationEdge()
        {
            _Type = DataAssociationType.Input;
            _StrokeStyle = 0;
            _Mapping = new List<OOMMDataMapper>();
        }

        public OOMMDataAssociationEdge(
            int id, Guid sourceObject, int sourcePort,
            Guid targetObject, int targetPort, int strokeStyle)
        {
            _ID = id;

            _SourceDataSource = sourceObject;
            _SourcePort = sourcePort;
            _TargetEventObject = targetObject;
            _TargetPort = targetPort;
            _StrokeStyle = strokeStyle;

            _Type = DataAssociationType.Input;
            _Mapping = new List<OOMMDataMapper>();

        }

        public OOMMDataAssociationEdge(SerializationInfo info, StreamingContext ctxt)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMDatAssociationEdge.ReadingSerializedObject()");

            _ID = (int)info.GetValue("ID", typeof(int));
            _SourceDataSource= (Guid)info.GetValue("SourceObject", typeof(Guid));
            _SourcePort = (int)info.GetValue("SourcePort", typeof(int));
            _TargetEventObject = (Guid)info.GetValue("TargetObject", typeof(Guid));
            _TargetPort = (int)info.GetValue("TargetPort", typeof(int));
            _StrokeStyle = (int)info.GetValue("StrokeStyle", typeof(int));
            _Mapping = (List<OOMMDataMapper>)info.GetValue("Mappers", typeof(List<OOMMDataMapper>));

            _Type = DataAssociationType.Input;
        }
        #endregion

        #region Methods
        public void AddDataMapper(OOMMDataMapper mapper)
        {
            _Mapping.Add(mapper);
        }

        public void RemoveDataMapper(string name)
        {
            OOMMDataMapper rslt = null;
            foreach(OOMMDataMapper mapper in _Mapping)
            {
                if (mapper.Name.Equals(name))
                {
                    rslt = mapper; break;
                }
            }

            if (rslt != null)
                _Mapping.Remove(rslt);
        }
        #endregion

        #region ISerializable Method
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMDatAssociationEdge.GetObjectData()");

            info.AddValue("ID", _ID);
            info.AddValue("SourceObject", _SourceDataSource);
            info.AddValue("SourcePort", _SourcePort);
            info.AddValue("TargetObject", _TargetEventObject);
            info.AddValue("TargetPort", _TargetPort);
            info.AddValue("StrokeStyle", _StrokeStyle);
            info.AddValue("Mappers", _Mapping);
        }
        #endregion
    }
}