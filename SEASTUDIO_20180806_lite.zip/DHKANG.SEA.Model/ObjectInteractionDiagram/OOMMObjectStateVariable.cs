﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model.OID
{
    [Serializable()]
    public class OOMMObjectStateVariable : ISerializable
    {
        #region Member Variables
        private string _Name;
        private string _Value;

        public string Name { get { return _Name; } set { _Name = value; } }
        public string Value { get { return _Value; } set { _Value = value; } }
        #endregion

        #region Constructors
        public OOMMObjectStateVariable()
        {
            _Name = string.Empty;
            _Value = string.Empty;
        }

        public OOMMObjectStateVariable(string name, string value)
            : this()
        {
            this._Name = name;
            this._Value = value;
        }

        public OOMMObjectStateVariable(SerializationInfo info, StreamingContext ctxt)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMObjectStateVariable.ReadingSerializedObject()");
            
            _Name = (string)info.GetValue("Name", typeof(string));
            _Value = (string)info.GetValue("Value", typeof(string));
        }
        #endregion

        #region ISerializable Method
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMObjectStateVariable.GetObjectData()");
            
            info.AddValue("Name", _Name);
            info.AddValue("Value", _Value);
        }
        #endregion

    }

}
