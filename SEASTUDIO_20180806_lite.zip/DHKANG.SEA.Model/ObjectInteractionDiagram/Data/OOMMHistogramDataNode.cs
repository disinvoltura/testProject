﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model.OID.Data
{
    [Serializable()]
    public class OOMMHistogramDataNode : ISerializable
    {
        #region Member Variables
        private Guid _NodeID;
        private string _Name;
        private string _Value;
        private string _Decsription;
        private float _X;
        private float _Y;
        
        #endregion

        #region Properties
        public string Name { get { return _Name; } set { _Name = value; } }
        public Guid NodeID { get { return _NodeID; } set { _NodeID = value; } }
        public float X { get { return _X; } set { _X = value; } }
        public float Y { get { return _Y; } set { _Y = value; } }
        
        public string Value { get { return _Value; } set { _Value = value; } }
        public string Description { get { return _Decsription; } set { _Decsription = value; } }
        #endregion

        #region Constructors
        public OOMMHistogramDataNode()
        {
        }

        public OOMMHistogramDataNode(
            Guid nodeid, string name, string value, string description, float x, float y)
        {
            _NodeID = nodeid;
            _Name = name;
            _Value = value;
            _Decsription = description;
            _X = x;
            _Y = y;
        }

        public OOMMHistogramDataNode(SerializationInfo info, StreamingContext ctxt)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMHistogramDataNode.ReadingSerializedObject()");
            
            _NodeID = (Guid)info.GetValue("NodeID", typeof(Guid));
            _Name = (string)info.GetValue("Name", typeof(string));
            _X = (float)info.GetValue("X", typeof(float));
            _Y = (float)info.GetValue("Y", typeof(float));

            _Value = (string)info.GetValue("Value", typeof(string));
            _Decsription = (string)info.GetValue("Decsription", typeof(string));
        }
        #endregion

        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMHistogramDataNode.GetObjectData()");
            
            info.AddValue("NodeID", _NodeID);
            info.AddValue("Name", _Name);
            info.AddValue("X", _X);
            info.AddValue("Y", _Y);

            info.AddValue("Value", _Value);
            info.AddValue("Decsription", _Decsription);
        }
    }
}
