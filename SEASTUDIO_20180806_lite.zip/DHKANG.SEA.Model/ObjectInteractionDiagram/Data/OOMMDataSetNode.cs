﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model.OID.Data
{
    [Serializable()]
    public class OOMMDataSetNode : ISerializable
    {
        #region Member Variables
        private Guid _NodeID;
        private string _DataSetName;
        private string _XAxisValue;
        private string _YAxisValue;
        private string _Decsription;
        private float _X;
        private float _Y;
        
        #endregion

        #region Properties
        public string DataSetName { get { return _DataSetName; } set { _DataSetName = value; } }
        public Guid NodeID { get { return _NodeID; } set { _NodeID = value; } }
        public float X { get { return _X; } set { _X = value; } }
        public float Y { get { return _Y; } set { _Y = value; } }
        
        public string XAxisValue { get { return _XAxisValue; } set { _XAxisValue = value; } }
        public string YAxisValue { get { return _YAxisValue; } set { _YAxisValue = value; } }
        public string Description { get { return _Decsription; } set { _Decsription = value; } }
        #endregion

        #region Constructors
        public OOMMDataSetNode()
        {
        }

        public OOMMDataSetNode(
            Guid nodeid, string datasetName, string xaxisValue, string yaxisValue, string description, 
            float x, float y)
        {
            _NodeID = nodeid;
            _DataSetName = datasetName;
            _XAxisValue = xaxisValue;
            _YAxisValue = yaxisValue;
            _Decsription = description;
            _X = x;
            _Y = y;
        }

        public OOMMDataSetNode(SerializationInfo info, StreamingContext ctxt)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMDataSetNode.ReadingSerializedObject()");
            
            _NodeID = (Guid)info.GetValue("NodeID", typeof(Guid));
            _DataSetName = (string)info.GetValue("DataSetName", typeof(string));
            _X = (float)info.GetValue("X", typeof(float));
            _Y = (float)info.GetValue("Y", typeof(float));

            _XAxisValue = (string)info.GetValue("XAxisValue", typeof(string));
            _YAxisValue = (string)info.GetValue("YAxisValue", typeof(string));
            _Decsription = (string)info.GetValue("Decsription", typeof(string));
        }
        #endregion

        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMDataSetNode.GetObjectData()");
            
            info.AddValue("NodeID", _NodeID);
            info.AddValue("DataSetName", _DataSetName);
            info.AddValue("X", _X);
            info.AddValue("Y", _Y);

            info.AddValue("XAxisValue", _XAxisValue);
            info.AddValue("YAxisValue", _YAxisValue);
            info.AddValue("Decsription", _Decsription);
        }
    }
}
