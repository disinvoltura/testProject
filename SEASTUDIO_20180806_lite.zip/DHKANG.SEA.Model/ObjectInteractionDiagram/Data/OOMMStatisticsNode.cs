﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model.OID.Data
{
    public enum StatisticsType { Tally, TimeDependent, Counter };
    
    [Serializable()]
    public class OOMMStatisticsNode : ISerializable
    {
        #region Member Variables
        private Guid _NodeID;
        private string _Name;
        private string _Source;
        private StatisticsType _Type;
        private string _Decsription;
        private float _X;
        private float _Y;

        #endregion

        #region Properties
        public Guid NodeID { get { return _NodeID; } set { _NodeID = value; } }

        public string StatisticsName { get { return _Name; } set { _Name = value; } }      
        public string Source { get { return _Source; } set { _Source = value; } }
        public StatisticsType Type { get { return _Type; } set { _Type = value; } }
        public string Description { get { return _Decsription; } set { _Decsription = value; } }

        public float X { get { return _X; } set { _X = value; } }
        public float Y { get { return _Y; } set { _Y = value; } }
        #endregion

        #region Constructors
        public OOMMStatisticsNode()
        {
        }

        public OOMMStatisticsNode(
            Guid nodeid, string name, string source, StatisticsType type, string description, 
            float x, float y)
        {
            _NodeID = nodeid;
            _Name = name;
            _Source = source;
            _Type = type;
            _Decsription = description;

            _X = x;
            _Y = y;
        }

        public OOMMStatisticsNode(SerializationInfo info, StreamingContext ctxt)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMStatisticsNode.ReadingSerializedObject()");
            
            _NodeID = (Guid)info.GetValue("NodeID", typeof(Guid));
            _Name = (string)info.GetValue("Name", typeof(string));

            _Source = (string)info.GetValue("Source", typeof(string));
            _Type = (StatisticsType)info.GetValue("Type", typeof(StatisticsType));
            _Decsription = (string)info.GetValue("Decsription", typeof(string));

            _X = (float)info.GetValue("X", typeof(float));
            _Y = (float)info.GetValue("Y", typeof(float));
        }
        #endregion

        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMStatisticsNode.GetObjectData()");
            
            info.AddValue("NodeID", _NodeID);
            info.AddValue("Name", _Name);
            
            info.AddValue("Source", _Source);
            info.AddValue("Type", _Type);
            info.AddValue("Decsription", _Decsription);

            info.AddValue("X", _X);
            info.AddValue("Y", _Y);
        }
    }
}
