﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.OID.Charts
{
    [Serializable()]
    public class OOMMScatterChart: OOMMChart //ISerializable
    {
        #region Member Variables
        /*
        private string _Title;
        private string _Desc;
        private OOMMSeriesCollection _SeriesList;
        private OOMMDimension _Dimension;
        private OOMMChartAppearance _Appearance;
        */
        #endregion

        #region Properties
        /*
        public string Title { get { return _Title; } set { _Title = value; } }
        public string Description { get { return _Desc; } set { _Desc = value; } }
        public OOMMDimension Dimension {  get { return _Dimension; } set { _Dimension = value; } }
        public OOMMSeriesCollection Series {  get { return _SeriesList; } set { _SeriesList = value; } }
        public OOMMChartAppearance Appearance {  get { return _Appearance; } set { _Appearance = value; } }
        */
        #endregion

        #region Constructors
        public OOMMScatterChart()
            : base()
        {
            /*
            _Dimension = new OOMMDimension();
            _SeriesList = new OOMMSeriesCollection();
            _Appearance = new OOMMChartAppearance();
            */
        }

        public OOMMScatterChart(string title, string desc, OOMMSeriesCollection series, float x, float y, float w, float h)
            : base(title, desc, series, x, y, w, h)
        {
            /*
            _Title = title;
            _Desc = desc;
            _SeriesList = series;
            _Dimension = new OOMMDimension(x, y, w, h);
            _Appearance = new OOMMChartAppearance();
            */
        }
        
        public OOMMScatterChart(string title, string desc, OOMMSeriesCollection series, Color bgColor, Color borderColor, int borderWeight, float x, float y, float w, float h)
            : base(title, desc, series, bgColor, borderColor, borderWeight, x, y, w, h)
        {
            /*
            _Title = title;
            _Desc = desc;
            _SeriesList = series;
            _Dimension = new OOMMDimension(x, y, w, h);
            _Appearance = new OOMMChartAppearance(bgColor, borderColor, borderWeight);
            */
        }

        /*
        public OOMMTimePlot(SerializationInfo info, StreamingContext ctxt)
        {
            System.Diagnostics.Debug.WriteLine("OOMMTimePlot.ReadingSerializedObject()");

            _Title = (string)info.GetValue("Title", typeof(string));
            _Dimension = (OOMMDimension)info.GetValue("Dimension", typeof(OOMMDimension));
            _SeriesList = (OOMMSeriesCollection)info.GetValue("Series", typeof(OOMMSeriesCollection));
            _Appearance = (OOMMChartAppearance)info.GetValue("Appearance", typeof(OOMMChartAppearance));
        }
        */
        #endregion

        #region Methods
        /*
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            System.Diagnostics.Debug.WriteLine("OOMMTimePlot.GetObjectData()");

            info.AddValue("Title", _Title);
            info.AddValue("Dimension", _Dimension);
            info.AddValue("Series", _SeriesList);
            info.AddValue("Appearance", _Appearance);
        }
        */
        #endregion
    }
}
