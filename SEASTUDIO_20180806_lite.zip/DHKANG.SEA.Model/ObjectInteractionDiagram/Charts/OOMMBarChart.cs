﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.OID.Charts
{
    public enum OOMMChartDirection { Horizontal, Vertical };
    [Serializable()]
    public class OOMMBarChart : OOMMChart
    {
        #region Member Variables
        private bool _IsStacked = false;
        private OOMMChartDirection _Direction = OOMMChartDirection.Vertical;
        #endregion

        #region Properties
        public OOMMChartDirection Direction { get { return _Direction; } set { _Direction = value; } }
        public bool IsStacked { get { return _IsStacked; } set { _IsStacked = value; } }
        #endregion

        #region Constructors
        public OOMMBarChart() :
            base()
        {
        }

        public OOMMBarChart(string title, string desc, OOMMSeriesCollection series, float x, float y, float w, float h)
            : base(title, desc, series, x, y, w, h)
        {
        }
        
        public OOMMBarChart(string title, string desc, OOMMSeriesCollection series, Color bgColor, Color borderColor, int borderWeight, float x, float y, float w, float h)
            : base(title, desc, series, bgColor, borderColor, borderWeight, x,y, w, h)
        {
        }

        /*
        public OOMMBarChart(SerializationInfo info, StreamingContext ctxt)
        {
            System.Diagnostics.Debug.WriteLine("BarChart.ReadingSerializedObject()");

            _Direction = (OOMMChartDirection)info.GetValue("Direction", typeof(OOMMChartDirection));
            _IsStacked = (bool)info.GetValue("IsStacked", typeof(bool));
        }
        */
        #endregion

        #region Methods
        #endregion
    }
}
