﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.OID.Charts
{
    [Serializable()]
    public class OOMMPieChart : OOMMChart
    {
        #region Member Variables
        #endregion

        #region Properties
        #endregion

        #region Constructors
        public OOMMPieChart()
            : base()
        {
        }

        public OOMMPieChart(string title, string desc, OOMMSeriesCollection series, float x, float y, float w, float h)
            : base(title, desc, series, x, y, w, h)
        {
        }

        public OOMMPieChart(string title, string desc, OOMMSeriesCollection series, Color bgColor, Color borderColor, int borderWeight, float x, float y, float w, float h)
            : base(title, desc, series, bgColor, borderColor, borderWeight, x, y, w, h)
        {
        }

        /*
        public OOMMPieChart(SerializationInfo info, StreamingContext ctxt)
        {
            System.Diagnostics.Debug.WriteLine("OOMMPieChart.ReadingSerializedObject()");

            _Title = (string)info.GetValue("Title", typeof(string));
            _Dimension = (OOMMDimension)info.GetValue("Dimension", typeof(OOMMDimension));
            _SeriesList = (OOMMSeriesCollection)info.GetValue("Series", typeof(OOMMSeriesCollection));
            _Appearance = (OOMMChartAppearance)info.GetValue("Appearance", typeof(OOMMChartAppearance));
        }
        */
        #endregion

        #region Methods
        /*
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            System.Diagnostics.Debug.WriteLine("OOMMPieChart.GetObjectData()");

            info.AddValue("Title", _Title);
            info.AddValue("Dimension", _Dimension);
            info.AddValue("Series", _SeriesList);
            info.AddValue("Appearance", _Appearance);
        }
        */
        #endregion
    }
}
