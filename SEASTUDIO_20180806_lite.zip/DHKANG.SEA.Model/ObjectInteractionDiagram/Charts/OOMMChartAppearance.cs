﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.OID.Charts
{
    [Serializable()]
    public class OOMMChartAppearance : ISerializable
    {
        #region Member Variables
        private string _BackgroundColor = System.Drawing.ColorTranslator.ToHtml(Color.Black);
        private string _NameColor= System.Drawing.ColorTranslator.ToHtml(Color.Black);
        private string _DescriptionColor= System.Drawing.ColorTranslator.ToHtml(Color.Black);
        private string _BorderColor = ColorTranslator.ToHtml(Color.Black);
        private float _BorderWeight = 1;
        #endregion

        #region Properties
        public string BackgroundColor { get { return _BackgroundColor; } set { _BackgroundColor = value; } }
        public string NameColor { get { return _NameColor; } set { _NameColor = value; } }
        public string DescriptionColor { get { return _DescriptionColor; } set { _DescriptionColor = value; } }
        public string BorderColor { get { return _BorderColor; } set { _BorderColor = value; } }
        public float BorderWeight { get { return _BorderWeight; } set { _BorderWeight = value; } }

        #endregion

        #region Constructors
        public OOMMChartAppearance() { }

        public OOMMChartAppearance(Color bgColor, Color borderColor, float borderWeight)
        {
            _BackgroundColor = ColorTranslator.ToHtml(bgColor);
            _BorderColor = ColorTranslator.ToHtml(borderColor);
            _BorderWeight = borderWeight;
        }

        public OOMMChartAppearance(Color bgColor, Color nameColor, Color descColor, Color borderColor, float borderWeight)
        {
            _BackgroundColor = ColorTranslator.ToHtml(bgColor);
            _NameColor = ColorTranslator.ToHtml(nameColor);
            _DescriptionColor = ColorTranslator.ToHtml(descColor);
            _BackgroundColor = ColorTranslator.ToHtml(bgColor);
            _BorderColor = ColorTranslator.ToHtml(borderColor);
            _BorderWeight = borderWeight;
        }

        public OOMMChartAppearance(SerializationInfo info, StreamingContext ctxt)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMChartAppearance.ReadingSerializedObject()");

            _BackgroundColor = (string)info.GetValue("BackgroundColor", typeof(string));
            _NameColor = (string)info.GetValue("NameColor", typeof(string));
            _DescriptionColor = (string)info.GetValue("DescriptionColor", typeof(string));
            _BorderColor = (string)info.GetValue("BorderColor", typeof(string));
            _BorderWeight = (int)info.GetValue("BorderWeight", typeof(int));
        }
        #endregion

        #region Methods
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMChartAppearance.GetObjectData()");

            info.AddValue("BackgroundColor", _BackgroundColor);
            info.AddValue("BorderColor", _BorderColor);
            info.AddValue("BorderWeight", _BorderWeight);
        }
        #endregion
    }
}
