﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.OID.Charts
{
    [Serializable()]
    public class OOMMSeriesCollection : ISerializable
    {
        #region member variables
        private List<OOMMSeries> _SeriesList;
        #endregion

        #region Properties
        public List<OOMMSeries> Values { get { return _SeriesList; } set { _SeriesList = value; } }
        public int Count {  get { return _SeriesList.Count; } }
        #endregion

        #region Constructors
        public OOMMSeriesCollection()
        {
            _SeriesList = new List<OOMMSeries>();
        }

        public OOMMSeriesCollection(List<OOMMSeries> series)
        {
            _SeriesList = series;
        }

        public OOMMSeriesCollection(SerializationInfo info, StreamingContext ctxt)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMSeriesCollection.ReadingSerializedObject()");

            _SeriesList = (List<OOMMSeries>)info.GetValue("Values", typeof(List<OOMMSeries>));
        }

        #endregion

        #region Methods
        public void Add(OOMMSeries s)
        {
            _SeriesList.Add(s);
        }

        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMSeriesCollection.GetObjectData()");

            info.AddValue("Values", _SeriesList);
        }

        #endregion
    }
}
