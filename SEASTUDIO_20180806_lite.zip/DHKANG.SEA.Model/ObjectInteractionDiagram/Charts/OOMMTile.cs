﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.OID.Charts
{
    public enum TileShape { Rectangle, RoundedRectangle, Circle}
    [Serializable()]
    public class OOMMTile: ISerializable
    {
        #region Member Variables
        private string _Name;
        private string _Value;
        private Guid _TargetObjectId = Guid.Empty;
        private string _TargetObject = string.Empty;
        private string _TargetVariable = string.Empty;
        private string _InitialValue = string.Empty;
        private float _MaxValue;
        private TileShape _Shape = TileShape.Rectangle;
        private OOMMDimension _Dimension;

        private int _BackgroundColor;
        private int _NameColor;
        private int _ValueColor;
        private int _BorderColor;

        #endregion

        #region Properties
        public string Name { get { return _Name; } set { _Name = value; } }
        public string Value { get { return _Value; } set { _Value = value; } }

        public Guid TargetObjectId { get { return _TargetObjectId; } set { _TargetObjectId = value; } }
        public string TargetObject { get { return _TargetObject; } set { _TargetObject = value; } }
        public string TargetVariable { get { return _TargetVariable; } set { _TargetVariable = value; } }
        public string InitialValue { get { return _InitialValue; } set { _InitialValue = value; } }
        public TileShape Shape { get { return _Shape; } set { _Shape = value; } }
        public OOMMDimension Dimension {  get { return _Dimension; } set { _Dimension = value; } }
        public float MaxValue { get { return _MaxValue; } set { _MaxValue = value; } }

        public int BackgroundColor { get { return _BackgroundColor; } set { _BackgroundColor = value; } }
        public int NameColor { get { return _NameColor; } set { _NameColor = value; } }
        public int ValueColor { get { return _ValueColor; } set { _ValueColor = value; } }
        public int BorderColor { get { return _BorderColor; } set { _BorderColor = value; } }

        #endregion

        #region Constructors
        public OOMMTile()
        {
            _Dimension = new OOMMDimension();
            _BackgroundColor = System.Drawing.Color.FromArgb(114, 102, 186).ToArgb();
            _NameColor = Color.FromArgb(205, 207, 233).ToArgb();
            _ValueColor = System.Drawing.Color.White.ToArgb();
            _BorderColor = System.Drawing.Color.FromArgb(0, 192, 239).ToArgb();
        }

        public OOMMTile(string name, string value, float x, float y, float w, float h)
            : base()
        {
            _Name = name;
            _Value = value;
            _Dimension = new OOMMDimension(x, y, w, h);
        }
        
        public OOMMTile(string name, string value, Color bgColor, Color nameColor, Color valueColor, Color borderColor, float x, float y, float w, float h)
            : base()
        {
            _Name = name;
            _Value = value;
            _Dimension = new OOMMDimension(x, y, w, h);
            _BackgroundColor = bgColor.ToArgb();
            _NameColor = nameColor.ToArgb();
            _ValueColor = valueColor.ToArgb();
            _BorderColor = borderColor.ToArgb();
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            _Name = (string)info.GetValue("Name", typeof(string));
            _Value = (string)info.GetValue("Value", typeof(string));

            _TargetObjectId = (Guid)info.GetValue("TargetObjectId", typeof(Guid));
            _TargetObject = (string)info.GetValue("TargetObject", typeof(string));
            _TargetVariable = (string)info.GetValue("TargetVariable", typeof(string));
            _InitialValue = (string)info.GetValue("InitialValue", typeof(string));

            _Dimension = (OOMMDimension)info.GetValue("Dimension", typeof(OOMMDimension));
            _BackgroundColor = (int)info.GetValue("BackgroundColor", typeof(int));
            _NameColor = (int)info.GetValue("NameColor", typeof(int));
            _ValueColor = (int)info.GetValue("ValueColor", typeof(int));
            _BorderColor = (int)info.GetValue("BorderColor", typeof(int));
        }

        /*
        public OOMMTile(SerializationInfo info, StreamingContext ctxt)
        {
            System.Diagnostics.Debug.WriteLine("OOMMChart.ReadingSerializedObject()");

            _Title = (string)info.GetValue("Title", typeof(string));
            _Dimension = (OOMMDimension)info.GetValue("Dimension", typeof(OOMMDimension));
            _SeriesList = (OOMMSeriesCollection)info.GetValue("Series", typeof(OOMMSeriesCollection));
            _Appearance = (OOMMChartAppearance)info.GetValue("Appearance", typeof(OOMMChartAppearance));
        }
        */

        #endregion

        #region Methods
        /*
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            System.Diagnostics.Debug.WriteLine("OOMMChart.GetObjectData()");

            info.AddValue("Title", _Title);
            info.AddValue("Dimension", _Dimension);
            info.AddValue("Series", _SeriesList);
            info.AddValue("Appearance", _Appearance);
        }
        */
        #endregion
    }
}
