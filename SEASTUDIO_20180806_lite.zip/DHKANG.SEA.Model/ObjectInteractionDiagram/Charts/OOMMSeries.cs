﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.OID.Charts
{
    public enum OOMMSeriesChartType
    {
        Bar, Spline, StepLine, Line, Donut, Pie, Histogram, Scatter, BoxWhisker
    }

    public enum OOMMMarkerType
    {
        None, Oval, Rectangle, Triangle, Diamond
    }

    [Serializable()]
    public class OOMMSeries : ISerializable
    {
        #region Member Variables
        private string _Name;
        private string _Value;
        private OOMMSeriesChartType _ChartType = OOMMSeriesChartType.Bar;
        private OOMMSeriesAppearance _Appearance;
        #endregion

        #region Properties
        public string Name { get { return _Name; } set { _Name = value; } }
        public string Value { get { return _Value; } set { _Value = value; } }
        public OOMMSeriesChartType Type { get { return _ChartType; } set { _ChartType = value; } }
        public OOMMSeriesAppearance Appearance { get { return _Appearance; } set { _Appearance = value; } }
        #endregion

        #region Constructors
        public OOMMSeries()
        {
            _Appearance = new OOMMSeriesAppearance();
        }

        public OOMMSeries(string name, string value, OOMMSeriesChartType type, OOMMSeriesAppearance appearance) 
        {
            _Name = name;
            _Value = value;
            _ChartType = type;
            _Appearance= appearance;
        }

        public OOMMSeries(SerializationInfo info, StreamingContext ctxt)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMSeries.ReadingSerializedObject()");

            _Name = (string)info.GetValue("Name", typeof(string));
            _Value = (string)info.GetValue("Value", typeof(string));
            _ChartType = (OOMMSeriesChartType)info.GetValue("Type", typeof(OOMMSeriesChartType));
            _Appearance = (OOMMSeriesAppearance)info.GetValue("Appearance", typeof(OOMMSeriesAppearance));
        }
        #endregion

        #region Methods
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMSeries.GetObjectData()");

            info.AddValue("Name", _Name);
            info.AddValue("Value", _Value);
            info.AddValue("Type", _ChartType);
            info.AddValue("Appearance", _Appearance);
        }

        #endregion
    }

    [Serializable()]
    public class OOMMSeriesAppearance: ISerializable
    {
        #region Member Variables
        private int _LineWidth = 2;
        private string _BackgroundColor;
        private string _MarkerColor;
        private string _LineColor;
        private OOMMMarkerType _MarkerType = OOMMMarkerType.Diamond;
        #endregion

        #region Properties
        public string MarkerColor { get { return _MarkerColor; } set { _MarkerColor = value; } }
        public string LineColor { get { return _LineColor; } set { _LineColor = value; } }
        public OOMMMarkerType MarkerType { get { return _MarkerType; } set { _MarkerType = value; } }
        public string BackgroundColor { get { return _BackgroundColor; } set { _BackgroundColor = value; } }
        public int LineWidth { get { return _LineWidth; } set { _LineWidth = value; } }
        #endregion

        #region Constructors
        public OOMMSeriesAppearance()
        {
        }

        public OOMMSeriesAppearance(int lineWidth, Color bgColor, Color markerColor, Color lineColor, OOMMMarkerType markerType)
        {
            _BackgroundColor = ColorTranslator.ToHtml(bgColor);
            _MarkerColor = ColorTranslator.ToHtml(markerColor);
            _LineColor = ColorTranslator.ToHtml(lineColor);
            _LineWidth = lineWidth;
            _MarkerType = markerType;
        }

        public OOMMSeriesAppearance(SerializationInfo info, StreamingContext ctxt)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMSeriesAppearance.ReadingSerializedObject()");

            _LineWidth = (int)info.GetValue("LineWidth", typeof(int));
            _BackgroundColor = (string)info.GetValue("BackgroundColor", typeof(string));
            _MarkerColor = (string)info.GetValue("MarkerColor", typeof(string));
            _LineColor = (string)info.GetValue("LineColor", typeof(string));
            _MarkerType = (OOMMMarkerType)info.GetValue("MarkerType", typeof(OOMMMarkerType));
        }
        #endregion

        #region Methods
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMSeriesAppearance.GetObjectData()");

            info.AddValue("LineWidth", _LineWidth);
            info.AddValue("BackgroundColor", _BackgroundColor);
            info.AddValue("MarkerColor", _MarkerColor);
            info.AddValue("LineColor", _LineColor);
            info.AddValue("MarkerType", _MarkerType);
        }
        #endregion

    }
}
