﻿using DHKANG.SEA.Model.OID.Charts;
using DHKANG.SEA.Model.OID;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.Model.Data;
using DHKANG.SEA.Model.OID.Presentation;
using DHKANG.SEA.Model.OID.Data;
using DHKANG.SEA.Model.EventObjects;
using System.Drawing;

namespace DHKANG.SEA.Model.OID
{
    public class OOMMObjectInteractionDiagram: ISerializable
    {
        public static readonly string ZOOM_SCALE = "ViewScale";
        public static readonly string GRID_VISIBILITY = "GridVisibility";

        #region Member Variables
        private List<OOMMDataSourceNode> _DataSourceNodes;
        private List<OOMMTextNode> _Texts;
        private List<OOMMLabelNode> _Labels;
        private List<OOMMObjectInteractionEdge> _Edges;
        private List<OOMMDataAssociationEdge> _DataAssociations;
        private List<OOMMStateVariableUpdateEdge> _StateVariableUpdateEdges;

        private List<OOMMDataTable> _DataTableList;

        private List<OOMMDataSetNode> _DataSetNodes;
        private List<OOMMHistogramDataNode> _HistogramDataNodes;
        private List<OOMMStatisticsNode> _StatisticsNodes;

        private List<OOMMBarChart> _BarCharts;
        private List<OOMMPieChart> _PieCharts;
        private List<OOMMPlot> _Plots;
        private List<OOMMTimePlot> _TimePlots;
        private List<OOMMScatterChart> _ScatterCharts;
        private List<OOMMHistogram> _Histograms;
        private List<OOMMDonutChart> _DonutCharts;
        private List<OOMMBoxWhiskerChart> _BoxWhiskerCharts;
        private List<OOMMTile> _Tiles;

        private List<OOMMObjectNode> _ObjectNodes;
        #endregion

        #region Properties
        public List<OOMMDataSourceNode> DataSourceNodes { get { return _DataSourceNodes; } set { _DataSourceNodes = value; } }
        public List<OOMMObjectInteractionEdge> ObjectInteractionEdges { get { return _Edges; } set { _Edges = value; } }
        public List<OOMMDataAssociationEdge> DataAssociations { get { return _DataAssociations; } set { _DataAssociations = value; } }
        public List<OOMMStateVariableUpdateEdge> StateVariableUpdateEdges { get { return _StateVariableUpdateEdges; } set { _StateVariableUpdateEdges = value; } }
        public List<OOMMTextNode> Texts { get { return _Texts; } set { _Texts = value; } }
        public List<OOMMLabelNode> Labels { get { return _Labels; } set { _Labels = value; } }
        public List<OOMMDataSetNode> DataSetNodes { get { return _DataSetNodes; } set { _DataSetNodes = value; } }
        public List<OOMMHistogramDataNode> HistogramDataNodes { get { return _HistogramDataNodes; } set { _HistogramDataNodes = value; } }
        public List<OOMMStatisticsNode> StatisticsNodes { get { return _StatisticsNodes; } set { _StatisticsNodes = value; } }
        public List<OOMMBarChart> BarCharts { get { return _BarCharts; } set { _BarCharts = value; } }
        public List<OOMMPieChart> PieCharts { get { return _PieCharts; } set { _PieCharts = value; } }
        public List<OOMMPlot> Plots { get { return _Plots; } set { _Plots = value; } }
        public List<OOMMTimePlot> TimePlots { get { return _TimePlots; } set { _TimePlots = value; } }
        public List<OOMMDonutChart> DonutCharts { get { return _DonutCharts; } set { _DonutCharts = value; } }
        public List<OOMMScatterChart> ScatterCharts { get { return _ScatterCharts; } set { _ScatterCharts = value; } }
        public List<OOMMBoxWhiskerChart> BoxWhiskerCharts { get { return _BoxWhiskerCharts; } set { _BoxWhiskerCharts = value; } }
        public List<OOMMHistogram> Histograms { get { return _Histograms; } set { _Histograms = value; } }
        public List<OOMMTile> Tiles { get { return _Tiles; } set { _Tiles = value; } }

        public List<OOMMObjectNode> ObjectNodes { get { return _ObjectNodes; } set { _ObjectNodes = value; } }

        #endregion

        #region Constructors
        public OOMMObjectInteractionDiagram()
        {
            _Edges = new List<OOMMObjectInteractionEdge>();
            _Texts = new List<OOMMTextNode>();
            _Labels = new List<OOMMLabelNode>();
            _ObjectNodes = new List<OOMMObjectNode>();
            _DataSourceNodes = new List<OOMMDataSourceNode>();
            _DataAssociations = new List<OOMMDataAssociationEdge>();
            _StateVariableUpdateEdges = new List<OOMMStateVariableUpdateEdge>();

            _DataSetNodes = new List<OOMMDataSetNode>();
            _HistogramDataNodes = new List<OOMMHistogramDataNode>();
            _StatisticsNodes = new List<OOMMStatisticsNode>();

            _BarCharts = new List<OOMMBarChart>();
            _PieCharts = new List<OOMMPieChart>();
            _Plots = new List<OOMMPlot>();
            _TimePlots = new List<OOMMTimePlot>();

            _DonutCharts = new List<OOMMDonutChart>();
            _Histograms = new List<OOMMHistogram>();
            _ScatterCharts = new List<OOMMScatterChart>();
            _Tiles = new List<OOMMTile>();
            _BoxWhiskerCharts = new List<OOMMBoxWhiskerChart>();

            _ObjectNodes = new List<OOMMObjectNode>();
        }

        public OOMMObjectInteractionDiagram(SerializationInfo info, StreamingContext ctx)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMObjectInteractionDiagram.ReadingSerializedObject()");

            _Edges = (List<OOMMObjectInteractionEdge>)info.GetValue("Edges", typeof(List<OOMMObjectInteractionEdge>));
            _Texts = (List<OOMMTextNode>)info.GetValue("Texts", typeof(List<OOMMTextNode>));
            try { _Labels = (List<OOMMLabelNode>)info.GetValue("Labels", typeof(List<OOMMLabelNode>)); } catch (Exception e) { }

            try { _DataAssociations = (List<OOMMDataAssociationEdge>)info.GetValue("DataAssociations", typeof(List<OOMMDataAssociationEdge>)); } catch (Exception e) { }
            try { _StateVariableUpdateEdges = (List<OOMMStateVariableUpdateEdge>)info.GetValue("StateVariableUpdateEdges", typeof(List<OOMMStateVariableUpdateEdge>)); } catch (Exception e) { }
            try { _DataSourceNodes = (List<OOMMDataSourceNode>)info.GetValue("DataSourceNodes", typeof(List<OOMMDataSourceNode>)); } catch (Exception e) { }

            try { _DataSetNodes = (List<OOMMDataSetNode>)info.GetValue("DataSetNodes", typeof(List<OOMMDataSetNode>)); } catch (Exception e) { }
            try { _HistogramDataNodes = (List<OOMMHistogramDataNode>)info.GetValue("HistogramDataNodes", typeof(List<OOMMHistogramDataNode>)); } catch (Exception e) { }
            try { _StatisticsNodes = (List<OOMMStatisticsNode>)info.GetValue("StatisticsNodes", typeof(List<OOMMDataSourceNode>)); } catch (Exception e) { }

            try { _BarCharts = (List<OOMMBarChart>)info.GetValue("BarCharts", typeof(List<OOMMBarChart>)); } catch (Exception e) { }
            try { _PieCharts = (List<OOMMPieChart>)info.GetValue("PieCharts", typeof(List<OOMMPieChart>)); } catch (Exception e) { }
            try { _Plots = (List<OOMMPlot>)info.GetValue("Plots", typeof(List<OOMMPlot>)); } catch (Exception e) { }
            try { _TimePlots = (List<OOMMTimePlot>)info.GetValue("TimePlots", typeof(List<OOMMTimePlot>)); } catch (Exception e) { }

            try { _DonutCharts = (List<OOMMDonutChart>)info.GetValue("DonutCharts", typeof(List<OOMMDonutChart>)); } catch (Exception e) { }
            try { _Histograms = (List<OOMMHistogram>)info.GetValue("Histograms", typeof(List<OOMMHistogram>)); } catch (Exception e) { }
            try { _ScatterCharts = (List<OOMMScatterChart>)info.GetValue("ScatterCharts", typeof(List<OOMMScatterChart>)); } catch (Exception e) { }
            try { _Tiles = (List<OOMMTile>)info.GetValue("Tiles", typeof(List<OOMMTile>)); } catch (Exception e) { }
            try { _BoxWhiskerCharts = (List<OOMMBoxWhiskerChart>)info.GetValue("BoxWhiskerCharts", typeof(List<OOMMBoxWhiskerChart>)); } catch (Exception e) { }

            try { _ObjectNodes = (List<OOMMObjectNode>)info.GetValue("ObjectNodes", typeof(List<OOMMObjectNode>)); } catch (Exception e) { }
        }
        #endregion

        #region Methods
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOMMDiagram.GetObjectData()");

            info.AddValue("Edges", _Edges);
            info.AddValue("Texts", _Texts);
            info.AddValue("Labels", _Labels);
            info.AddValue("DataSourceNodes", _DataSourceNodes);
            info.AddValue("DataAssociations", _DataAssociations);
            info.AddValue("StateVariableUpdateEdges", _StateVariableUpdateEdges);

            info.AddValue("DataSetNodes", _DataSetNodes);
            info.AddValue("HistogramDataNodes", _HistogramDataNodes);
            info.AddValue("StatisticsNodes", _StatisticsNodes);

            info.AddValue("BarCharts", _BarCharts);
            info.AddValue("PieCharts", _PieCharts);
            info.AddValue("Plots", _Plots);
            info.AddValue("TimePlots", _Plots);
            info.AddValue("DonutCharts", _DonutCharts);
            info.AddValue("Histograms", _Histograms);
            info.AddValue("ScatterCharts", _ScatterCharts);
            info.AddValue("BoxWhiskerCharts", _BoxWhiskerCharts);
            info.AddValue("Tiles", _Tiles);
            
            info.AddValue("ObjectNodes", _ObjectNodes);
        }

        public OOMMDataSetNode FindDataSetNode(Guid id)
        {
            OOMMDataSetNode rslt = null;
            try
            {
                rslt = (from element in _DataSetNodes
                        orderby element
                        where element.NodeID.Equals(id)
                        select element).First<OOMMDataSetNode>();
            }
            catch (Exception ex) { }

            return rslt;
        }

        public OOMMDataSetNode FindDataSetNode(string name)
        {
            OOMMDataSetNode rslt = null;
            try
            {
                rslt = (from element in _DataSetNodes
                        orderby element
                        where element.DataSetName.Equals(name)
                        select element).First<OOMMDataSetNode>();
            }
            catch (Exception ex) { }

            return rslt;
        }

        public OOMMHistogramDataNode FindHistogramDataNode(Guid id)
        {
            OOMMHistogramDataNode rslt = null;
            try
            {
                rslt = (from element in _HistogramDataNodes
                        orderby element
                        where element.NodeID.Equals(id)
                        select element).First<OOMMHistogramDataNode>();
            }
            catch (Exception ex) { }

            return rslt;
        }

        public OOMMHistogramDataNode FindHistogramDataNode(string name)
        {
            OOMMHistogramDataNode rslt = null;
            try
            {
                rslt = (from element in _HistogramDataNodes
                        orderby element
                        where element.Name.Equals(name)
                        select element).First<OOMMHistogramDataNode>();
            }
            catch (Exception ex) { }

            return rslt;
        }

        public OOMMObjectNode FindObjectNode(Guid id)
        {
            OOMMObjectNode rslt = null;
            try
            {
                rslt = (from element in _ObjectNodes
                        orderby element
                        where element.NodeID.Equals(id) 
                        select element).First<OOMMObjectNode>();
            }
            catch (Exception ex) { }

            return rslt;
        }

        public OOMMObjectNode FindObjectNode(string name)
        {
            OOMMObjectNode rslt = null;

            foreach(OOMMObjectNode node in  _ObjectNodes){
                if (node.Name.Equals(name))
                {
                    rslt = node; break;
                }
            }
            return rslt;
        }

        public void ChangeBackgroundColor(Guid objectModelId, Color newValue)
        {
            foreach (OOMMObjectNode objectNode in this.ObjectNodes)
            {
                if (objectNode.ModelID.Equals(objectModelId))
                {
                    objectNode.BackgroundColor = ((Color)newValue).ToArgb();
                }
            }

        }
        #endregion

    }
}
