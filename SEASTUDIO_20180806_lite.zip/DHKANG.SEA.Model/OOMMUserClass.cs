﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model
{
    [Serializable()]
    public class OOMMUserClass : ISerializable
    {
        #region Member Variables
        private Guid _ID;
        private string _Name;
        private bool _AdvancedEdit;//if true, the user will define the body of the class.
        private string _ClassBody;
        private bool _Inherited;
        private string _InheritedClass;

        private List<OOMMUserClassProperty> _Properties;
        private List<OOMMUserClassMethod> _Methods;
        #endregion

        #region Propertis
        public Guid ID { get { return _ID; } set { _ID = value; } }
        public string Name { get { return _Name; } set { _Name = value; } }
        public bool AdvancedEdit { get { return _AdvancedEdit; } set { _AdvancedEdit = value; } }
        public string ClassBody { get { return _ClassBody; } set { _ClassBody = value; } }

        public List<OOMMUserClassProperty> Properties { get { return _Properties; } set { _Properties = value; } }
        public List<OOMMUserClassMethod> Methods { get { return _Methods; } set { _Methods = value; } }

        public bool Inherited { get { return _Inherited; } set { _Inherited = value; } }
        public string InheritedClass { get { return _InheritedClass; } set { _InheritedClass = value; } }
        #endregion

        #region Constructors
        public OOMMUserClass(Guid id, string name, string body)
        {
            _ID = id;
            _Name = name;
            _ClassBody = body;

            _AdvancedEdit = true;
            _Properties = new List<OOMMUserClassProperty>();
            _Methods = new List<OOMMUserClassMethod>();

            _Inherited = false;
            _InheritedClass = string.Empty;
        }

        public OOMMUserClass(Guid id, string name, List<OOMMUserClassProperty> properties, List<OOMMUserClassMethod> methods)
        {
            _ID = id;
            _Name = name;
            _Properties = properties;
            _Methods = methods;

            _AdvancedEdit = false;

            _Inherited = false;
            _InheritedClass = string.Empty;
        }

        public OOMMUserClass()
        {
            _ID = Guid.NewGuid();
            _Name = string.Empty;
            _AdvancedEdit = false;
            _ClassBody = string.Empty;
            _Properties = new List<OOMMUserClassProperty>();
            _Methods = new List<OOMMUserClassMethod>();

            _Inherited = false;
            _InheritedClass = string.Empty;
        }

        public OOMMUserClass(string name, List<OOMMUserClassProperty> properties, List<OOMMUserClassMethod> methods) : this()
        {
            _Name = name;
            _Properties = properties;
            _Methods = methods;
        }

        public OOMMUserClass(string name, string body) : this()
        {
            _Name = name;
            _AdvancedEdit = true;
            _ClassBody = body;
        }

        public OOMMUserClass(SerializationInfo info, StreamingContext ctxt)
        {
            _Name = (string)info.GetValue("Name", typeof(string));
            _AdvancedEdit = (bool)info.GetValue("AdvancedEdit", typeof(bool));
            _ClassBody = (string)info.GetValue("ClassBody", typeof(string));
            _Properties = (List<OOMMUserClassProperty>)info.GetValue("Properties", typeof(List<OOMMUserClassProperty>));
            _Methods = (List<OOMMUserClassMethod>)info.GetValue("Methods", typeof(List<OOMMUserClassMethod>));

            _Inherited = (bool)info.GetValue("Inherited", typeof(bool));
            _InheritedClass = (string)info.GetValue("InheritedClass", typeof(string));
        }

        #endregion

        #region Methods
        public OOMMUserClass Clone()
        {
            OOMMUserClass rslt = null;
            if (this.AdvancedEdit)
            {
                rslt = new OOMMUserClass((string)this.Name.Clone(), (string)this.ClassBody.Clone());
            }
            else
            {
                List<OOMMUserClassProperty> properties = new List<OOMMUserClassProperty>();
                List<OOMMUserClassMethod> methods = new List<OOMMUserClassMethod>();

                _Properties.ForEach(p => properties.Add(p.Clone()));
                _Methods.ForEach(m => methods.Add(m.Clone()));

               rslt = new OOMMUserClass((string)this.Name.Clone(), properties, methods);
            }

            return rslt;
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Name", _Name);
            info.AddValue("AdvancedEdit", _AdvancedEdit);
            info.AddValue("ClassBody", _ClassBody);
            info.AddValue("Properties", _Properties);
            info.AddValue("Methods", _Methods);

            info.AddValue("Inherited", _Inherited);
            info.AddValue("InheritedClass", _InheritedClass);
        }

        public bool HasProperty(string name)
        {
            OOMMUserClassProperty rslt = _Properties.Find(p => p.Name.Equals(name));

            return rslt != null ? true : false;
        }

        public bool HasMethod(string name)
        {
            OOMMUserClassMethod rslt = _Methods.Find(p => p.Name.Equals(name));

            return rslt != null ? true : false;
        }

        public void RemoveProperty(string name)
        {
            _Properties.RemoveAll(p => p.Name.Equals(name));
        }

        public void RemoveMethod(string name)
        {
            _Methods.RemoveAll(p => p.Name.Equals(name));
        }

        #endregion
    }
    public enum AccessorType { Public, Protected, Private };

    public class OOMMUserClassProperty : ISerializable
    {
        #region Member Variables
        private string _Name;
        private string _ValueType;
        private AccessorType _Accessor;
        private string _InitialValue;
        #endregion

        #region Propertis
        public string Name { get { return _Name; } set { _Name = value; } }
        public string ValueType { get { return _ValueType; } set { _ValueType = value; } }
        public AccessorType Accessor { get { return _Accessor; } set { _Accessor = value; } }
        public string InitialValue { get { return _InitialValue; } set { _InitialValue = value; } }

        #endregion

        #region Constructors
        public OOMMUserClassProperty()
        {
            _Name = string.Empty;
            _ValueType = string.Empty;
            _Accessor = AccessorType.Public;
            _InitialValue = string.Empty;
        }

        public OOMMUserClassProperty(string name, string valueType, AccessorType accessor, string initialValue)
        {
            _Name = name;
            _ValueType = valueType;
            _Accessor = accessor;
            _InitialValue = initialValue;
        }

        public OOMMUserClassProperty(SerializationInfo info, StreamingContext ctxt)
        {
            _Name = (string)info.GetValue("Name", typeof(string));
            _ValueType = (string)info.GetValue("ValueType", typeof(string));
            _Accessor = (AccessorType)info.GetValue("Accessor", typeof(AccessorType));
            _InitialValue = (string)info.GetValue("InitialValue", typeof(string));
        }
        #endregion

        #region Methods
        public OOMMUserClassProperty Clone()
        {
            OOMMUserClassProperty rslt = null;

            AccessorType at = AccessorType.Private;
            if (this.Accessor == AccessorType.Public)
                at = AccessorType.Public;
            rslt = new OOMMUserClassProperty(
                        (string)this.Name.Clone(),
                        (string)this.ValueType.Clone(),
                        at,
                        string.IsNullOrEmpty(this.InitialValue) ? string.Empty : (string)this.InitialValue);

            return rslt;
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Name", _Name);
            info.AddValue("ValueType", _ValueType);
            info.AddValue("Accessor", _Accessor);
            info.AddValue("InitialValue", _InitialValue);
        }
        #endregion
    }

    public class OOMMUserClassMethod : ISerializable
    {
        #region Member Variables
        private string _Name;
        private AccessorType _Accessor;
        private string _ReturnType;
        private string _Parameters;
        private string _MethodBody;
        #endregion

        #region Propertis
        public string Name { get { return _Name; } set { _Name = value; } }
        public string ReturnType { get { return _ReturnType; } set { _ReturnType = value; } }
        public string MethodBody { get { return _MethodBody; } set { _MethodBody = value; } }
        public string Parameters { get { return _Parameters; } set { _Parameters = value; } }
        public AccessorType Accessor { get { return _Accessor; } set { _Accessor = value; } }

        #endregion

        #region Constructors
        public OOMMUserClassMethod()
        {
            _Name = string.Empty;
            _Accessor = AccessorType.Private;
            _ReturnType = string.Empty;
            _Parameters = string.Empty;
            _MethodBody = string.Empty;
        }

        public OOMMUserClassMethod(string name, AccessorType accessor, string parameters, string methodBody, string returnType)
        {
            _Name = name;
            _Accessor = accessor;
            _Parameters = parameters;
            _MethodBody = methodBody;
            _ReturnType = returnType;
        }

        public OOMMUserClassMethod(SerializationInfo info, StreamingContext ctxt)
        {
            _Name = (string)info.GetValue("Name", typeof(string));
            _Accessor = (AccessorType)info.GetValue("Accessor", typeof(AccessorType));
            _Parameters = (string)info.GetValue("Parameters", typeof(string));
            _MethodBody = (string)info.GetValue("MethodBody", typeof(string));
            _ReturnType = (string)info.GetValue("ReturnType", typeof(string));
        }
        #endregion

        #region Methods
        public OOMMUserClassMethod Clone()
        {
            OOMMUserClassMethod rslt = new OOMMUserClassMethod(
                                            (string)this.Name.Clone(),
                                            (AccessorType)this.Accessor,
                                            (string)this.Parameters.Clone(),
                                            (string)this.MethodBody.Clone(),
                                            (string)this.ReturnType.Clone());
            return rslt;
        }
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Name", _Name);
            info.AddValue("Parameters", _Parameters);
            info.AddValue("MethodBody", _MethodBody);
            info.AddValue("ReturnType", _ReturnType);
        }
        #endregion
    }
}
