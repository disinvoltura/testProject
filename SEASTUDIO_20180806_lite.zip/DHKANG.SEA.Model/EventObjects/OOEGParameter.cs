﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Model.EventObjects
{
    [Serializable()]
    public class OOEGParameter : ISerializable
    {
        #region Member Variables
        private string _Name;
        private int _Row;
        private int _Col;
        private string _ValueType;
        private string _InitialValue;
        private string _Description;

        public string Name { get { return _Name; } set { _Name = value; } }
        public int Row { get { return _Row; } set { _Row = value; } }
        public int Col { get { return _Col; } set { _Col = value; } }
        public string ValueType { get { return _ValueType; } set { _ValueType = value; } }
        public string InitialValue { get { return _InitialValue; } set { _InitialValue = value; } }
        public string Description { get { return _Description; } set { _Description = value; } }
        #endregion

        #region Constructors
        public OOEGParameter()
        {
            _Name = string.Empty;
            _Description = string.Empty;
            _ValueType = string.Empty;
            _InitialValue = string.Empty;
        }

        //public OOEGParameter(string name, string vt, string iv, string desc)
        public OOEGParameter(string name, int row, int col, string vt, string iv, string desc)
            : this()
        {
            this._Name = name;
            this._Row = row;
            this._Col = col;
            this._ValueType = vt;
            this._InitialValue = iv;
            this._Description = desc;
        }

        public OOEGParameter(SerializationInfo info, StreamingContext ctxt)
        {
            //System.Diagnostics.Debug.WriteLine("OOEGParameter.ReadingSerializedObject()");

            _Name = (string)info.GetValue("Name", typeof(string));
            _ValueType = (string)info.GetValue("ValueType", typeof(string));
            _InitialValue = (string)info.GetValue("InitialValue", typeof(string));
            _Description = (string)info.GetValue("Description", typeof(string));
            _Row = (int)info.GetValue("Row", typeof(int));
            _Col = (int)info.GetValue("Col", typeof(int));
        }
        #endregion

        #region ISerializable Method
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOEGParameter.GetObjectData()");

            info.AddValue("Name", _Name);
            info.AddValue("ValueType", _ValueType);
            info.AddValue("InitialValue", _InitialValue);
            info.AddValue("Description", _Description);
            info.AddValue("Row", _Row);
            info.AddValue("Col", _Col);
        }
        #endregion

        public OOEGParameter Clone()
        {
            OOEGParameter rslt = new OOEGParameter(this.Name, this.Row, this.Col, this.ValueType, this.InitialValue, this.Description);
            return rslt;
        }
    }
}
