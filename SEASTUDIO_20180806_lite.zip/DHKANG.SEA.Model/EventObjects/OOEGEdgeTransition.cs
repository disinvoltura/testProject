﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;


namespace DHKANG.SEA.Model.EventObjects
{

    [Serializable()]
    public class OOEGPoint : ISerializable
    {
        #region Member Variables
        public float X;
        public float Y;
        #endregion

        #region Constructors
        public OOEGPoint() { }

        public OOEGPoint(float x, float y)
        {
            this.X = x;
            this.Y = y;
        }

        public OOEGPoint(SerializationInfo info, StreamingContext ctxt)
        {
            this.X = (float)info.GetValue("X", typeof(float));
            this.Y = (float)info.GetValue("Y", typeof(float));
        }
        #endregion

        #region ISerializable Method
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("X", X);
            info.AddValue("Y", Y);
        }
        #endregion
    }

    [Serializable()]
    public class OOEGEdgeTransition : ISerializable
    {
        public int EdgeNo;
        public string Condition = string.Empty;
        public string Delay = string.Empty;
        //public OOEGRandomVariate Delay;
        public string Parameters = string.Empty;
        public string NextEvent = string.Empty; //Destination Event
        public bool IsCancelingEdge = false;

        //Graph Properties
        public int FromPort;
        public int ToPort;
        public int LinkStyle;
        public int AdjustingStyle;
        public float Curviness;
        public List<OOEGPoint> Points;

        #region Constructors
        public OOEGEdgeTransition()
        {
        }

        public OOEGEdgeTransition(
            int edgeNo, string condition, string delay, string parameters, bool isCancelingEdge, string nextEvent, int fromPort, int toPort, int linkStyle)
        {
            this.EdgeNo = edgeNo;
            this.Condition = condition;
            this.Delay = delay;
            this.Parameters = parameters;
            this.IsCancelingEdge = isCancelingEdge;
            this.NextEvent = nextEvent;
            this.FromPort = fromPort;
            this.ToPort = toPort;
            this.LinkStyle = linkStyle;

            this.Points = new List<OOEGPoint>();
        }

        public OOEGEdgeTransition(
            int edgeNo, string condition, string delay, string parameters, bool isCancelingEdge, string nextEvent)
            //int edgeNo, string condition, string delay, string parameters, string nextEvent)
            //int edgeNo, string condition, OOEGRandomVariate delay, string parameters, string nextEvent)
        {
            this.EdgeNo = edgeNo;
            this.Condition = condition;
            this.Delay = delay;
            this.Parameters = parameters;
            this.IsCancelingEdge = isCancelingEdge;
            this.NextEvent = nextEvent;
        }

        public OOEGEdgeTransition(SerializationInfo info, StreamingContext ctxt)
        {
            //System.Diagnostics.Debug.WriteLine("OOEGEdgeTransition.ReadSerializedObject()");
            
            EdgeNo = (int)info.GetValue("EdgeNo", typeof(int));
            Condition = (string)info.GetValue("Condition", typeof(string));
            Delay = (string)info.GetValue("Delay", typeof(string));
            //Delay = (OOEGRandomVariate)info.GetValue("Delay", typeof(OOEGRandomVariate));
            Parameters = (string)info.GetValue("Parameters", typeof(string));
            NextEvent = (string)info.GetValue("NextEvent", typeof(string));

            try
            {
                IsCancelingEdge = (bool)info.GetValue("IsCancelingEdge", typeof(bool));
            }catch(Exception ex)
            {
                IsCancelingEdge = false;
            }

            try
            {
                FromPort = (int)info.GetValue("FromPort", typeof(int));
            }
            catch (Exception ex) { FromPort = 0;  }

            try
            {
                ToPort = (int)info.GetValue("ToPort", typeof(int));
            }
            catch (Exception ex) { FromPort = 0;  }

            try
            {
                LinkStyle = (int)info.GetValue("LinkStyle", typeof(int));
            }
            catch (Exception ex) { FromPort = 0;  }

            try
            {
                Curviness = (float)info.GetValue("Curviness", typeof(float));
            }
            catch (Exception ex) { Curviness = 0;  }

            try
            {
                AdjustingStyle = (int)info.GetValue("AdjustingStyle", typeof(int));
            }
            catch (Exception ex) { AdjustingStyle = 0;  }

            try
            {
                Points = (List<OOEGPoint>)info.GetValue("Points", typeof(List<OOEGPoint>));
            }
            catch (Exception ex) { AdjustingStyle = 0;  }

        }
        #endregion

        #region ISerializable Method
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOEGEdgeTransition.GetObjectData()");
            
            info.AddValue("EdgeNo", EdgeNo);
            info.AddValue("Condition", Condition);
            info.AddValue("Delay", Delay);
            info.AddValue("Parameters", Parameters);
            info.AddValue("IsCancelingEdge", IsCancelingEdge);
            info.AddValue("NextEvent", NextEvent);
            info.AddValue("FromPort", FromPort);
            info.AddValue("ToPort", ToPort);
            info.AddValue("LinkStyle", LinkStyle);

            info.AddValue("Curviness", Curviness);
            info.AddValue("AdjustingStyle", AdjustingStyle);
            info.AddValue("Points", Points);
        }
        #endregion
    }
}
