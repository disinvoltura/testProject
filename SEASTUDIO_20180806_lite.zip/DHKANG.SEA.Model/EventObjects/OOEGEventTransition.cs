﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Permissions;

namespace DHKANG.SEA.Model.EventObjects
{
    [Serializable()]
    public class OOEGEventTransition : ISerializable
    {
        #region Member Variables
        private int _No;
        private OOEGEvent _Event; //Originating Event
        private string _Action;
        private bool _InitialEvent;

        private List<OOEGEdgeTransition> _Edges;
        #endregion

        #region Properties
        public int No { get { return _No; } set { _No = value; } }
        public OOEGEvent Event { get { return _Event; } set { _Event = value; } }
        public string Action { get { return _Action; } set { _Action = value; } }
        public List<OOEGEdgeTransition> Edges { get { return _Edges; } set { _Edges = value; } }
        public bool InitialEvent { get { return _InitialEvent; } set { _InitialEvent = value; } }
        #endregion

        #region Constructors
        public OOEGEventTransition()
        {
            _Edges = new List<OOEGEdgeTransition>();
            _Action = string.Empty;
            _InitialEvent = false;

        }

        public OOEGEventTransition(int eventNo, OOEGEvent currentEvent, string stateChange)
            : this()
        {
            _No = eventNo;
            _Event = currentEvent;
            _Action = stateChange;
        }

        protected OOEGEventTransition(SerializationInfo info, StreamingContext ctxt)
        {
            //System.Diagnostics.Debug.WriteLine("OOEGEventTransition.ReadSerializedObject()");

            _No = (int)info.GetValue("No", typeof(int));
            _Event = (OOEGEvent)info.GetValue("Event", typeof(OOEGEvent));
            _Action = (string)info.GetValue("Action", typeof(string));
            _Edges = (List<OOEGEdgeTransition>)info.GetValue("Edges", typeof(List<OOEGEdgeTransition>));
            _InitialEvent = (bool)info.GetValue("InitialEvent", typeof(bool));
        }
        #endregion

        #region ISerializable Method
        [SecurityPermissionAttribute(SecurityAction.Demand,SerializationFormatter = true)]
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOEGEventTransition.GetObjectData()");
            
            info.AddValue("No", _No);
            info.AddValue("Event", _Event);
            info.AddValue("Action", _Action);
            info.AddValue("Edges", _Edges);
            info.AddValue("InitialEvent", _InitialEvent);
        }
        #endregion

        public OOEGEventTransition Clone()
        {
            OOEGEventTransition rslt = new OOEGEventTransition(this.No, this.Event.Clone(), this.Action);
            rslt.InitialEvent = this.InitialEvent;

            foreach (OOEGEdgeTransition edge in this.Edges)
                rslt.Edges.Add(edge);

            return rslt;
        }
    }
}
