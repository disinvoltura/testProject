﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model.EventObjects
{
    public enum OOEGEventType { Regular, Initial, Boundary, Mirror}
    [Serializable()]
    public class OOEGEvent : ISerializable
    {
        #region Member Variables
        public int ID;
        public string Name;
        public string Parameters;
        public OOEGEventType Type = OOEGEventType.Regular;

        /// <summary>
        /// Center Postion's X of an Event Vertex
        /// </summary>
        public float X;
        /// <summary>
        /// Center Position's Y of an Event Vertex
        /// </summary>
        public float Y;
        #endregion

        #region Constructors
        public OOEGEvent()
        {
            this.Name = string.Empty;
            this.Parameters = string.Empty;
            this.Type = OOEGEventType.Regular;
        }

        public OOEGEvent(int id, string name, string parameters, OOEGEventType type)
        {
            this.ID = id;
            this.Name = name;
            this.Parameters = parameters;
            this.Type = type;
        }

        public OOEGEvent(int id, string name, string parameters, OOEGEventType type, float x, float y)
            : this(id, name, parameters, type)
        {
            this.X = x;
            this.Y = y;
        }

        public OOEGEvent(SerializationInfo info, StreamingContext ctxt)
        {
            //System.Diagnostics.Debug.WriteLine("OOEGEvent.ReadSerializedObject()");
            
            ID = (int)info.GetValue("ID", typeof(int));
            
            Name = (string)info.GetValue("Name", typeof(string));
            Parameters = (string)info.GetValue("Parameters", typeof(string));

            Type = (OOEGEventType)info.GetValue("Type", typeof(OOEGEventType));

            X = (float)info.GetValue("X", typeof(float));
            Y = (float)info.GetValue("Y", typeof(float));
        }
        #endregion

        #region ISerializable Method
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOEGEvent.GetObjectData()");
            
            info.AddValue("ID", ID);
            info.AddValue("Name", Name);
            info.AddValue("Parameters", Parameters);
            info.AddValue("Type", Type);
            info.AddValue("X", X);
            info.AddValue("Y", Y);
        }
        #endregion

        #region Methods
        public OOEGEvent Clone()
        {
            OOEGEvent newEvent = new OOEGEvent(
                this.ID,
                (string)this.Name.Clone(),
                (string)this.Parameters.Clone(),
                (OOEGEventType)Enum.Parse(typeof(OOEGEventType), this.Type.ToString()),
                this.X, this.Y);

            return newEvent;
        }
        #endregion
    }
}
