﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DHKANG.SEA.Model.EventObjects
{
    [Serializable()]
    public class OOEGEventObjectModel : OOMMObjectModel, ISerializable
    {
        #region Member Variables
        //private Guid _ID;
        //private string _Name;
        //private string _Description; //Model Header 로 Name, Creator, Description 을 만드는 것을 고려해볼 것
        private List<OOEGEventTransition> _EventTransitions;
        private List<OOEGStateVariable> _StateVariables;
        private List<OOEGParameter> _Parameters;
        //private List<OOMMSchedule> _Schedules;
        //private List<OOMMEntityQueue> _EntityQueues;
        //private string _Functions;

        private List<String> _BoundaryEvents;

        private float _X;
        private float _Y;
        //private int _BackgroundColor;

        private string _InitialEventName;
        #endregion

        #region Properties
        /*
        public Guid ID { get { return _ID; } set { _ID = value; } }

        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        public string Description
        {
            get { return _Description; }
            set { _Description = value; }
        }

        public List<OOMMSchedule> Schedules
        {
            get { return _Schedules; }
            set { _Schedules = value; }
        }

        public List<OOMMEntityQueue> EntityQueues
        {
            get { return _EntityQueues; }
            set { _EntityQueues = value; }
        }

        public int BackgroundColor
        {
            get { return _BackgroundColor; }
            set { _BackgroundColor = value; }
        }

        public string Functions { get { return _Functions; } set { _Functions = value; } }

        */

        public List<OOEGEventTransition> EventTransitions
        {
            get { return _EventTransitions; }
            set { _EventTransitions = value; }
        }

        public List<OOEGStateVariable> StateVariables
        {
            get { return _StateVariables; }
            set { _StateVariables = value; }
        }

        public List<OOEGParameter> Parameters
        {
            get { return _Parameters; }
            set { _Parameters = value; }
        }


        public float X
        {
            get { return _X; }
            set { _X = value; }
        }

        public float Y
        {
            get { return _Y; }
            set { _Y = value; }
        }

        public string InitialEventName
        {
            get { return _InitialEventName; }
            set { _InitialEventName = value; }
        }

        public List<string> BoundaryEvents
        {
            get { return _BoundaryEvents; }
            set { _BoundaryEvents = value; }
        }

        #endregion

        #region Constructors
        public OOEGEventObjectModel() : base()
        {
            /*
            _ID = Guid.NewGuid();
            _Name = string.Empty;
            _Description = string.Empty;
            this._Schedules = new List<OOMMSchedule>();
            */
            _InitialEventName = string.Empty;
            this._EventTransitions = new List<OOEGEventTransition>();
            this._StateVariables = new List<OOEGStateVariable>();
            this._Parameters = new List<OOEGParameter>();
        }

        public OOEGEventObjectModel(string name) : base(name)
        {
            _InitialEventName = string.Empty;
            this._EventTransitions = new List<OOEGEventTransition>();
            this._StateVariables = new List<OOEGStateVariable>();
            this._Parameters = new List<OOEGParameter>();
            //_Name = name;
        }

        public OOEGEventObjectModel(SerializationInfo info, StreamingContext ctxt)
        {
            /*
            System.Diagnostics.Debug.WriteLine("OOEGEventObjectModel.ReadSerializedObject()");

            List<OOEGEventTransition> evtTransitions =
                (List<OOEGEventTransition>)info.GetValue("EventTransitions", typeof(List<OOEGEventTransition>));

            List<OOEGStateVariable> stateVariables =
                (List<OOEGStateVariable>)info.GetValue("StateVariables", typeof(List<OOEGStateVariable>));

            List<OOEGParameter> parameters =
                (List<OOEGParameter>)info.GetValue("Parameters", typeof(List<OOEGParameter>));

            _ID = (Guid)info.GetValue("ID", typeof(Guid));
            _Name = (string)info.GetValue("Name", typeof(string));
            _Description = (string)info.GetValue("Description", typeof(string));
            _X = (float)info.GetValue("X", typeof(float));
            _Y = (float)info.GetValue("Y", typeof(float));
            _InitialEventName = (string)info.GetValue("InitialEventName", typeof(string));

            try
            {
                _BackgroundColor = (int)info.GetValue("BackgroundColor", typeof(int));
            }
            catch (Exception ex)
            {
            }
            try
            {
                _Functions = (string)info.GetValue("Functions", typeof(string));
            }
            catch (Exception ex)
            {
            }

            try
            {
                _Schedules = (List<OOMMSchedule>)info.GetValue("Schedules", typeof(List<OOMMSchedule>));
            }
            catch (Exception ex)
            {
            }
            */
        }
        #endregion

        #region State Variable Methods
        public bool ContainsStateVariable(string name)
        {
            bool rslt = false;
            foreach (OOEGStateVariable sv in _StateVariables)
            {
                if (sv.Name.Equals(name))
                {
                    rslt = true;
                    break;
                }
            }
            return rslt;
        }

        #endregion

        #region Event Transition Methods
        public bool ContainEventTransition(string name)
        {
            bool rslt = false;

            foreach (OOEGEventTransition transition in _EventTransitions)
            {
                if (transition.Event.Name.Equals(name))
                {
                    rslt = true;
                    break;
                }
            }
            return rslt;
        }

        public void AddEventTransition(OOEGEventTransition transition)
        {
            _EventTransitions.Add(transition);

        }

        public void RemoveEventTransition(string name)
        {
            int idx = -1;
            for (int i = 0; i < _EventTransitions.Count; i++)
            {
                if (_EventTransitions[i].Event.Name.Equals(name))
                {
                    idx = i;
                    break;
                }
            }
            if (idx >= 0)
                _EventTransitions.RemoveAt(idx);
        }

        public OOEGEventTransition GetEventTransition(string name)
        {
            OOEGEventTransition rslt = null;

            foreach (OOEGEventTransition transition in _EventTransitions)
            {
                if (transition.Event.Name.Equals(name))
                {
                    rslt = transition;
                    break;
                }
            }
            return rslt;
        }

        public OOEGStateVariable GetStateVariable(string name)
        {
            OOEGStateVariable rslt = null;

            foreach (OOEGStateVariable sv in _StateVariables)
            {
                if (sv.Name.Equals(name))
                {
                    rslt = sv;
                    break;
                }
            }

            return rslt;
        }

        public OOEGStateVariable FindStateVariable(string name)
        {
            OOEGStateVariable rslt = null;

            foreach (OOEGStateVariable sv in _StateVariables)
            {
                if (sv.Name.Equals(name))
                {
                    rslt = sv;
                    break;
                }
            }

            return rslt;
        }

        public void RemoveStateVariable(string name)
        {
            int idx = -1;
            for (int i = 0; i < _StateVariables.Count; i++)
            {
                OOEGStateVariable sv = _StateVariables[i];
                if (sv.Name.Equals(name))
                {
                    idx = i;
                    break;
                }
            }
            if (idx >= 0)
                _StateVariables.RemoveAt(idx);

        }


        public OOEGParameter GetParameter(string name)
        {
            OOEGParameter rslt = null;

            foreach (OOEGParameter p in _Parameters)
            {
                if (p.Name.Equals(name))
                {
                    rslt = p;
                    break;
                }
            }

            return rslt;
        }

        public void RemoveParameter(string name)
        {
            int idx = -1;
            for (int i = 0; i < _Parameters.Count; i++)
            {
                OOEGParameter p = _Parameters[i];
                if (p.Name.Equals(name))
                {
                    idx = i;
                    break;
                }
            }
            if (idx >= 0)
                _Parameters.RemoveAt(idx);

        }

        #endregion

        #region ISerializable Method
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            //System.Diagnostics.Debug.WriteLine("OOEGEventObjectModel.GetObjectData()");
            /*
            info.AddValue("EventTransitions", _EventTransitions);
            info.AddValue("StateVariables", _StateVariables);
            info.AddValue("Parameters", _Parameters);
            info.AddValue("Schedules", _Schedules);
            info.AddValue("ID", _ID);
            info.AddValue("Name", _Name);
            info.AddValue("Description", _Description);
            info.AddValue("X", _X);
            info.AddValue("Y", _Y);
            info.AddValue("InitialEventName", _InitialEventName);
            info.AddValue("BackgroundColor", _BackgroundColor);
            info.AddValue("Functions", _Functions);
            */
        }
        #endregion

        public OOEGEventObjectModel Clone()
        {
            OOEGEventObjectModel rslt = new OOEGEventObjectModel(this.Name);

            rslt.Description = this.Description;

            foreach (OOEGEventTransition et in this.EventTransitions)
                rslt.EventTransitions.Add(et.Clone());

            foreach (OOEGStateVariable sv in this.StateVariables)
                rslt.StateVariables.Add(sv.Clone());

            foreach (OOEGParameter p in this.Parameters)
                rslt.Parameters.Add(p.Clone());

            foreach (OOMMSchedule s in this.Schedules)
                rslt.Schedules.Add(s.Clone());

            rslt.Functions = this.Functions;

            rslt.InitialEventName = this.InitialEventName;

            rslt.BackgroundColor = this.BackgroundColor;

            return rslt;
        }
    }



}
