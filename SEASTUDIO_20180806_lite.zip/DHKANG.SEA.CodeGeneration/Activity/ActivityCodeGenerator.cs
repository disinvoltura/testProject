﻿using DHKANG.SEA.Model;
using DHKANG.SEA.Model.ActivityObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DHKANG.SEA.CodeGeneration
{
    public class ActivityCodeGenerator
    {
        private string _N = Environment.NewLine;
        private string _Q = "\""; //quotation
        private string _L = "{";
        private string _R = "}";
        private string _T = "\t";
        private string _S = "#region";
        private string _E = "#endregion";
        private string _C = ";";
        private string _U = " = ";

        private OOAGActivityObjectModel _Model;
        private bool _IsTrajectory = false;

        public ActivityCodeGenerator()
        {

        }

        /*
        public string Generate(OOAGActivityObjectModel model, bool trajectory, string eosCondition)
        {
            _Model = model;
            _IsTrajectory = trajectory;

            string code = "";

            code += generateHeader();
            code += generateConstructor();
            code += generateMembers();
            //code += generateObserverGetter();
            code += generateVariableGetter();
            code += generateRunMethod(eosCondition);
            //code += generateCollectFunction();
            code += generateActivityRoutines();
            code += generateEventRoutines();
            code += generateInitializeRoutine();

            code += "}\r\n";
            return code; 
        }
        */

        public string GenerateActivityObjectSimulator(OOAGActivityObjectModel aoModel, OOMMModel model, bool fastForwardRun)
        {
            _Model = aoModel;
            _IsTrajectory = false;

            string code = "";

            code += generateHeader();
            code += generateConstructor();
            code += generateMembers();
            //code += generateObserverGetter();
            code += generateVariableGetter();
            code += generateVariableSetter();
            //code += generateRunMethod();
            //code += generateCollectFunction();
            code += generateActivityRoutines();
            code += generateEventRoutines();
            code += generateInitializeRoutines();
            //code += generateInitializeRoutine();

            code += "}\r\n";
            return code;
        }
        public string Generate(OOAGActivityObjectModel model, bool trajectory)
        {
            _Model = model;
            _IsTrajectory = trajectory;

            string code = "";

            code += generateHeader();
            code += generateConstructor();
            code += generateMembers();
            //code += generateObserverGetter();
            code += generateVariableGetter();
            code += generateVariableSetter();
            //code += generateRunMethod();
            //code += generateCollectFunction();
            code += generateActivityRoutines();
            code += generateEventRoutines();
            code += generateInitializeRoutines();

            code += "}\r\n";
            return code;
        }
        
        private string generateHeader()
        {
            string rslt = "";

            rslt += "using System;\r\n";
            rslt += "using System.Collections.Generic;\r\n";
            rslt += "using System.Text;\r\n";
            rslt += "using DHKANG.SEA.Simulation;\r\n";
            rslt += "using DHKANG.Foundation.RandomVariate;\r\n";
            rslt += "using DHKANG.Foundation.DataCollection;\r\n";
            rslt += "using DHKANG.SEA.Simulation.Activities;\r\n";
            rslt += "using DHKANG.SEA.Simulation.Events;\r\n";
            rslt += "using DHKANG.SEA.Simulation.Data;\r\n";
            rslt += "\r\n";

            string name = _Model.Name.Trim().Replace(" ", "").Replace("-","");
            rslt += @"public class " + name + "Simulator: ActivityObjectSimulator { \r\n";

            return rslt;
        }

        private string generateConstructor()
        {
            string rslt = "";
            string name = _Model.Name.Trim().Replace(" ", "").Replace("-","");
            rslt = "\t" + "public " + name + "Simulator(string name) : base(name) " + _L + _N;

            foreach (OOAGStateVariable sv in _Model.StateVariables)
            {
                string svName = getCleanClassName(sv.Name);
                //cbEditor.StandardValues = new string[] { "int", "float", "double", "string", "RandomVariate" };
                if (sv.Row == 1 && sv.Col == 1)
                {
                    if (sv.ValueType == "RandomVariate")
                    {
                        rslt += getTab(2) + string.Format("{0} = RandomVariateGenerator.GetRandomVariate(\"{1}\")" + _C + _N, svName, sv.InitialValue);
                    }
                    else if (sv.ValueType == "Queue")
                    {
                        rslt += getTab(2) + string.Format("{0} = new Queue<AbstractEntity>()" + _C + _N, svName);
                    }
                    else if (sv.ValueType == "EntityQueue")
                    {
                        rslt += getTab(2) + string.Format("{0} = new EntityQueue(this, \"{1}\")" + _C + _N, svName, sv.Name);
                    }
                    else if (sv.ValueType == "ParameterVariable")
                    {
                        rslt += getTab(2) + string.Format("{0} = new ParameterVariable(this, \"{1}\")" + _C + _N, svName, sv.Name);
                    }
                    else if (sv.ValueType == "Resource")
                    {
                        rslt += getTab(2) + string.Format("{0} = new Resource(this, \"{1}\")" + _C + _N, svName, sv.Name);
                    }
                    else if (sv.ValueType == "string")
                    {
                        rslt += getTab(2) + string.Format("{0} = \"{1}\"" + _C + _N, svName, sv.InitialValue);
                    }
                    else if (sv.ValueType == "int" || sv.ValueType == "float" || sv.ValueType == "double")
                    {
                        if (string.IsNullOrEmpty(sv.InitialValue))
                        {
                            rslt += getTab(2) + string.Format("{0} = {1}" + _C + _N, svName, 0);
                        }
                        else
                        {
                            rslt += getTab(2) + string.Format("{0} = {1}" + _C + _N, svName, sv.InitialValue);
                        }
                    }
                    else
                    {
                        rslt += getTab(2) + string.Format("{0} = new {1}()" + _C + _N, svName, sv.ValueType);
                    }
                }
                else if (sv.Row == 1 && sv.Col > 1)
                {
                    if (sv.ValueType == "RandomVariate")
                    {
                        string[] cells = sv.InitialValue.Replace("{", "").Replace("}", "").Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                        rslt += getTab(2) + string.Format("{0} = new RandomVariate[{1}]" + _C + _N, svName, sv.Col);
                        for (int p = 0; p < sv.Col; p++)
                        {
                            rslt += getTab(2) + string.Format("{0}[{1}] = RandomVariateGenerator.GetRandomVariate(\"{2}\")" + _C + _N, svName, p, cells[p]);
                        }
                    }
                    else if (sv.ValueType == "string")
                    {
                        //string[] cells = sv.InitialValue.Replace("{", "").Replace("}", "").Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                        //추후 모든 element에 ""가 필요할 수 있음
                        rslt += getTab(2) + string.Format("{0} = new string[]{{1}}" + _C + _N, svName, sv.InitialValue);
                    }
                    else
                    {
                        rslt += getTab(2) + string.Format("{0} = new {1}[]{2}" + _C + _N, svName, sv.ValueType, sv.InitialValue);
                    }
                }
                else
                {
                    if (sv.ValueType == "RandomVariate")
                    {
                        rslt += getTab(2) + string.Format("{0} = new RandomVariate[{1},{2}]" + _C + _N, svName, sv.Row, sv.Col);
                        string[] rows = sv.InitialValue.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                        //_Row; _Col;
                        for (int k = 0; k < rows.Length; k++)
                        {
                            if (k >= sv.Row)
                                break;

                            string row = rows[k].Replace("{", "").Replace("}", "");
                            string[] cells = row.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                            for (int p = 0; p < cells.Length; p++)
                            {
                                if (p < sv.Col)
                                {
                                    rslt += getTab(2) + string.Format("{0}[{1},{2}] = RandomVariateGenerator.GetRandomVariate(\"{3}\")" + _C + _N, svName, k, p, cells[p]);
                                }
                            }
                        }
                    }
                    else
                    {
                        rslt += getTab(2) + string.Format("{0} = new {1}[]{{2}}" + _C + _N, svName, sv.ValueType, sv.InitialValue);
                    }
                }
            }

            rslt += getTab(1) + _R + _N; ;
            return rslt;
        }

        private string generateMembers()
        {
            string rslt = "";

            foreach (OOAGQueue queue in _Model.Queues)
            {
                rslt += "\t" + "private int " + queue.Name + ";\r\n";
                //rslt += "\t" + "private ATTQueueObserver " + queue.Name + "_Observer;\r\n";
            }

            foreach (OOAGStateVariable sv in _Model.StateVariables)
            {
                string svName = getCleanClassName(sv.Name);
                //cbEditor.StandardValues = new string[] { "int", "float", "double", "string", "RandomVariate" };
                if (sv.Row == 1 && sv.Col == 1)
                {
                    if (sv.ValueType.Equals("Queue"))
                        rslt += getTab(1) + string.Format("private {0} {1}" + _C + _N, "Queue<AbstractEntity>", svName);
                    else
                        rslt += getTab(1) + string.Format("private {0} {1}" + _C + _N, sv.ValueType, svName);
                }
                else if (sv.Row == 1 && sv.Col > 1)
                {
                    rslt += getTab(1) + string.Format("private {0}[] {1}" + _C + _N, sv.ValueType, svName);
                }
                else
                {
                    rslt += getTab(1) + string.Format("private {0}[,] {1}" + _C + _N, sv.ValueType, svName);
                }
            }
            rslt += "\t\r\n";
            

            rslt += "\r\n";
            return rslt;
        }
        /*
        private string generateObserverGetter()
        {
            string rslt = "";

            rslt += "\t" + "public override ATTQueueObserver GetObserver(string name) { \r\n";
            foreach (string key in _Model.Queues.Keys)
            {
                ATTQueue queue = _Model.Queues[key];
                rslt += "\t\t" + "if (name.Equals(\"" + queue.Name + "\")) \r\n";
                rslt += "\t\t\t" + "return " + queue.Name + "_Observer;\r\n";
            }

            rslt += "\t\t" + "return null;\r\n";
            rslt += "\t}\r\n";
            rslt += "\r\n";

            return rslt;
        }
        */
        private string generateVariableGetter()
        {
            string rslt = "";

            string svlist = string.Empty;
            rslt += getTab(1) + "public override object GetStateVariable(string name) ";
            rslt += getTab(1) + _L + _N;
            rslt += getTab(2) + "object rslt = null" + _C + _N;

            List<String> svNameList = new List<String>();
            for (int i = 0; i < _Model.StateVariables.Count; i++)
            {
                OOAGStateVariable sv = _Model.StateVariables[i];
                string svName = getCleanClassName(sv.Name);
                if (i == 0)
                {
                    rslt += getTab(2) + "if (name.Equals(\"" + sv.Name + "\"))" + _N;
                    rslt += getTab(3) + "rslt = " + svName + _C + _N;
                }
                else
                {
                    rslt += getTab(2) + "else if (name.Equals(\"" + sv.Name + "\"))" + _N;
                    rslt += getTab(3) + "rslt = " + svName + _C + _N;
                }

                svNameList.Add(sv.Name);
            }

            for (int i = 0; i < _Model.Queues.Count; i++)
            {
                OOAGQueue q = _Model.Queues[i];
                string svName = getCleanClassName(q.Name);
                if (i == 0 && _Model.StateVariables.Count == 0)
                {
                    rslt += getTab(2) + "if (name.Equals(\"" + q.Name + "\"))" + _N;
                    rslt += getTab(3) + "rslt = " + svName + _C + _N;
                }
                else
                {
                    rslt += getTab(2) + "else if (name.Equals(\"" + q.Name + "\"))" + _N;
                    rslt += getTab(3) + "rslt = " + svName + _C + _N;
                }

                svNameList.Add(q.Name);
            }

            for(int i = 0; i < svNameList.Count; i++) { 
                if (i < svNameList.Count - 1)
                    svlist += string.Format("\"{0}\",", svNameList[i]);
                else
                    svlist += string.Format("\"{0}\"", svNameList[i]);
            }

            rslt += getTab(2) + "return rslt" + _C + _N;
            rslt += getTab(1) + _R + _N;

            rslt += getTab(1) + "public override List<string> StateVariables " + _N;
            rslt += getTab(1) + _L + _N;
            rslt += getTab(2) + "get { return new List<string>(){" + svlist + "};} " + _N; ;
            rslt += getTab(1) + _R + _N;

            return rslt;
        }

        private string generateVariableSetter()
        {
            string rslt = "";

            string svlist = string.Empty;
            rslt += getTab(1) + "public override void SetStateVariable(string name, object value) ";
            rslt += getTab(1) + _L + _N;

            for (int i = 0; i < _Model.StateVariables.Count; i++)
            {
                OOAGStateVariable sv = _Model.StateVariables[i];
                string svName = getCleanClassName(sv.Name);
                if (i == 0)
                {
                    rslt += getTab(2) + "if (name.Equals(\"" + sv.Name + "\"))" + _N;
                    //rslt += getTab(3) + svName + " = value" + _C + _N;
                }
                else
                {
                    rslt += getTab(2) + "else if (name.Equals(\"" + sv.Name + "\"))" + _N;
                    //rslt += getTab(3) + svName + " = value" + _C + _N;
                }

                if (sv.Row == 1 && sv.Col == 1)
                {
                    rslt += getTab(3) + string.Format("{0} = ({1})value", svName, sv.ValueType) + _C + _N;
                }
                else if (sv.Row == 1 && sv.Col > 1)
                {
                    rslt += getTab(3) + string.Format("{0} = ({1})value", svName, sv.ValueType + "[]") + _C + _N;
                }
                else
                {
                    rslt += getTab(3) + string.Format("{0} = ({1})value", svName, sv.ValueType + "[,]") + _C + _N;
                }
            }

            for (int i = 0; i < _Model.Queues.Count; i++)
            {
                OOAGQueue q = _Model.Queues[i];
                string svName = getCleanClassName(q.Name);
                if (i == 0 && _Model.StateVariables.Count == 0)
                {
                    rslt += getTab(2) + "if (name.Equals(\"" + q.Name + "\"))" + _N;
                }
                else
                {
                    rslt += getTab(2) + "else if (name.Equals(\"" + q.Name + "\"))" + _N;
                }

                rslt += getTab(3) + string.Format("{0} = ({1})value", svName, "int") + _C + _N;
            }


            rslt += getTab(1) + _R + _N;
            return rslt;
        }

        private string generateRunMethod()
        {
            string rslt = "";

            rslt = "\t" + "public override void Run() { \r\n";
            rslt += "\t\t" + "//Initialization step \r\n";
            //rslt += "\t\t" + "Clock = 0; \r\n";
            foreach (OOAGQueue queue in _Model.Queues)
            {
                rslt += "\t\t" + queue.Name + " = " + queue.InitialValue + ";\r\n";
                //rslt += "\t\t" + queue.Name + "_Observer = new ATTQueueObserver(\"" + queue.Name + "\", " + queue.InitialValue + ");\r\n";
            }

            /*
            rslt += "\r\n";
            foreach (string key in _Model.Variables.Keys)
            {
                ATTVariable variable = _Model.Variables[key];

                if (variable.Row == 1 && variable.Col == 1)
                    rslt += "\t\t" + variable.Name + " = " + variable.InitialValue.Replace("{", "").Replace("}", "") + ";\r\n";
                else if (variable.Row == 1 && variable.Col > 1)
                    rslt += "\t\t" + variable.Name + " = new " + variable.ValueType + "[] " + variable.InitialValue + ";\r\n";
                else
                {
                    rslt += "\t\t" + variable.Name + " = {" + variable.InitialValue.Replace(";", ",") + "};\r\n";
                }
            }
            */

            rslt += "\r\n";
            //enabled activity
            foreach (OOAGActivityTransition transition in _Model.ActivityTransitions)
            {
                if (transition.Activity.IsEnabled)
                {
                    rslt += "\t\t" + "StoreActivity(\"" + transition.Activity.Name + "\");\r\n";
                }
            }
            rslt += "\t" + "} \r\n";
            rslt += "\r\n";
 
            /*
            rslt += "\t\t" + "//Simulation step \r\n";
            rslt += "\t\t" + "do { \r\n";

            rslt += "\t\t" + "\t while (CAL.Count > 0) {\r\n";
            rslt += "\t\t" + "\t\tstring activity = RetrieveActivity();\r\n";
            rslt += "\t\t" + "\t\tCollect(1, activity);\r\n";
            rslt += "\t\t" + "\t\tswitch (activity) { \r\n ";

            foreach (string key in _Model.ActivityTransitions.Keys)
            {
                ATTActivityTransition transition = _Model.ActivityTransitions[key];

                rslt += "\t\t" + "\t\t\tcase \"" + key + "\": { \r\n";
                rslt += "\t\t" + "\t\t\t\tExecute_" + getValidActivityName(key) + "_ActivityRoutine(Clock);\r\n";
                rslt += "\t\t" + "\t\t\t\tbreak;\r\n";
                rslt += "\t\t" + "\t\t\t} \r\n";
            }

            rslt += "\t\t" + "\t\t}\r\n";
            rslt += "\t\t" + "\t}\r\n";
            rslt += "\t\t" + "\tACDEvent evt = RetrieveEvent();\r\n";
            rslt += "\t\t" + "\tif (evt == null) break;\r\n";
            rslt += "\t\t" + "\tCollect(2, evt.ToString());\r\n";
            rslt += "\t\t" + "\tClock = evt.Time;\r\n";
            rslt += "\t\t" + "\tswitch (evt.Name) { \r\n ";
            foreach (string key in _Model.ActivityTransitions.Keys)
            {
                ATTActivityTransition transition = _Model.ActivityTransitions[key];

                rslt += "\t\t" + "\t\tcase \"" + transition.BTOEvent.Name + "\": { \r\n";
                rslt += "\t\t" + "\t\t\tExecute_" + getValidEventName(transition.BTOEvent.Name) + "_EventRoutine();\r\n";
                rslt += "\t\t" + "\t\t\tbreak;\r\n";
                rslt += "\t\t" + "\t\t}\r\n";
            }

            rslt += "\t\t" + "\t}\r\n";
            rslt += "\t\t" + "\tCollect(3, evt.ToString());\r\n";
            rslt += "\t\t" + "} while (Clock <= eosTime);\r\n";

            rslt += "\t" + "} \r\n";
            rslt += "\r\n";
            */

            return rslt;
        }

        /*
        private string generateCollectFunction()
        {
            string rslt = "";

            rslt = "\t" + "private void Collect(int phase, string current) { \r\n";

            foreach (string key in _Model.Queues.Keys)
            {
                ATTQueue queue = _Model.Queues[key];
                rslt += "\t\t" + queue.Name + "_Observer.Collect(Clock, " + queue.Name + "); \r\n";
            }

            if (_IsTrajectory)
            {
                rslt += "\t\t" + "Trajectory tr = new Trajectory(phase, this.Clock, current, CALtoString(), FELtoString());\r\n";

                foreach (string key in _Model.Queues.Keys)
                {
                    ATTQueue queue = _Model.Queues[key];
                    rslt += "\t\t" + "tr.Queues.Add(\"" + queue.Name + "\", " + queue.Name + ");\r\n";
                }

                foreach (string key in _Model.Variables.Keys)
                {
                    ATTVariable variable = _Model.Variables[key];
                    if (variable.Row == 1 && variable.Col == 1) //우선 단일 변수만 취급
                        rslt += "\t\t" + "tr.Variables.Add(\"" + variable.Name + "\", " + variable.Name + ");\r\n";
                }

                rslt += "\t\t" + "Trajectories.Add(tr);";
            }

            rslt += "\t}\r\n";
            rslt += "\r\n";

            return rslt;
        }
        */

        //private string generateCollectFunction()
        //{
        //    string rslt = "";

        //    rslt = "\t" + "private void Collect() { \r\n";


        //    foreach (string key in _Table.Queues.Keys)
        //    {
        //        ATTQueue queue = _Table.Queues[key];
        //        rslt += "\t\t" + queue.Name + "_Observer.Collect(Clock, " + queue.Name + "); \r\n";
        //    }
        //    rslt += "\t}\r\n";
        //    rslt += "\r\n";

        //    return rslt;
        //}

        private string getCondition(string rawCondition)
        {
            //"&" --> "&&"
            string condition = rawCondition;
            if (condition.Contains("&") && !condition.Contains("&&"))
                condition = condition.Replace("&", "&&");

            if (condition.Contains("|") && !condition.Contains("||"))
                condition = condition.Replace("|", "||");

            return condition;
        }

        private string getValidActivityName(string name)
        {
            name = name.Replace(" ", "").Replace("-", "_");
            return name;
        }

        private string getValidEventName(string name)
        {
            name = name.Replace(" ", "").Replace("-", "_");
            return name;
        }

        private string generateActivityRoutines()
        {
            string rslt = "";
            //1. override ExecuteActivity(SimActivity nextActivity, double now);
            rslt += getTab(1) + "public override void ExecuteActivity(SimActivity nextActivity, double now)" + _L + _N;
            //rslt += getTab(2) + "switch(nextActivity.Name)" + _L + _N;
            bool first = false;
            foreach (OOAGActivityTransition transition in _Model.ActivityTransitions)
            {
                if (!first)
                {
                    rslt += getTab(2) + "if (nextActivity.Name.Equals(\"" + transition.Activity.Name + "\"))" + _N;
                    first = true;
                }else
                    rslt += getTab(2) + "else if (nextActivity.Name.Equals(\"" + transition.Activity.Name + "\"))" + _N;
                
                rslt += getTab(3) + "Execute_" + getValidActivityName(transition.Activity.Name) + "_ActivityRoutine(now)" + _C + _N;
                /*
                rslt += getTab(3) + "case: \"" + transition.Activity.Name + "\"" + _L + _N;
                rslt += getTab(4) + "Execute_" + getValidActivityName(transition.Activity.Name) + "_ActivityRoutine(now)" + _C + _N;
                rslt += getTab(4) + "break" + _C + _N;
                rslt += getTab(3) + _R + _N;
                */
            }
            //rslt += getTab(2) + _R + _N;
            rslt += getTab(1) + _R + _N;
            rslt += _N;

            //2. individual activity routine...            
            foreach (OOAGActivityTransition transition in _Model.ActivityTransitions)
            {
                rslt += "\tprivate void Execute_" + getValidActivityName(transition.Activity.Name) + "_ActivityRoutine(double clock) { \r\n";

                rslt += "\t\t" + "if (" + getCondition(transition.AtBegin.Condition) + ") { \r\n";

                string atBeginAction = transition.AtBegin.Action.Trim();
                if (!atBeginAction.EndsWith(";"))
                    atBeginAction += ";";
                rslt += "\t\t\t" + atBeginAction + "\r\n";

                if (string.IsNullOrEmpty(transition.Activity.TimeDelay))
                    rslt += "\t\t\t" + "double nextTime = clock + 0;\r\n";
                else
                    rslt += "\t\t\t" + "double nextTime = clock + " + transition.Activity.TimeDelay + ";\r\n";

                rslt += "\t\t\t" + "ScheduleLocalEvent(\"" + transition.Activity.Name + "\", \"" + transition.BTOEvent.Name + "\", clock, nextTime); \r\n";
                //rslt += "\t\t\t" + "ScheduleLocalEvent(\"" + transition.BTOEvent.Name + "\", nextTime); \r\n";
                //rslt += "\t\t\t" + "ScheduleNextEvent(nextTime, \"" + transition.BTOEvent.Name + "\"); \r\n";
                //rslt += "\t\t\t" + "EnterActivity(\"" + transition.Activity.Name+ "\", clock, nextTime); \r\n";
                rslt += "\t\t}\r\n";

                rslt += "\t}\r\n";
                rslt += "\r\n";
            }
            return rslt;
        }

        private string generateInitializeRoutines()
        {
            string rslt = "";
            rslt += getTab(1) + "public override void Execute_Initialize_Routine(Dictionary<string, object> args)" + _L + _C + _N;
            foreach (OOAGQueue queue in _Model.Queues)
            {
                rslt += "\t\t" + queue.Name + " = " + queue.InitialValue + ";\r\n";
            }
            rslt += "\r\n";
            //enabled activity
            foreach (OOAGActivityTransition transition in _Model.ActivityTransitions)
            {
                if (transition.Activity.IsEnabled)
                {
                    rslt += "\t\t" + "StoreActivity(\"" + transition.Activity.Name + "\");\r\n";
                }
            }
            rslt += getTab(1) + _R + _N;
            return rslt;
        }

        private string generateEventRoutines()
        {
            Dictionary<string, OOAGActivityTransition> sortedActivities = new Dictionary<string, OOAGActivityTransition>();

            string rslt = "";
            //1. override void ExecuteLocalEvent(LocalEvent nextEvent, double now);
            rslt += getTab(1) + "public override void ExecuteLocalEvent(LocalEvent nextEvent, double now)" + _L + _C + _N;
            bool first = false;
            foreach (OOAGActivityTransition transition in _Model.ActivityTransitions)
            {
                if (!first)
                {
                    rslt += getTab(2) + "if(nextEvent.Name.Equals(\"" + transition.BTOEvent.Name + "\"))" + _N;
                    first = true;
                }else
                    rslt += getTab(2) + "else if(nextEvent.Name.Equals(\"" + transition.BTOEvent.Name + "\"))" + _N;

                rslt += getTab(3) + "Execute_" + getValidEventName(transition.BTOEvent.Name) + "_EventRoutine(now)" + _C + _N;
                sortedActivities.Add(transition.Activity.Name, transition);
            }

            /*
            rslt += getTab(2) + "switch(nextEvent.Name)" + _L + _N;
            foreach (OOAGActivityTransition transition in _Model.ActivityTransitions)
            {
                rslt += getTab(3) + "case: \"" + transition.BTOEvent.Name + "\"" + _L + _N;
                rslt += getTab(4) + "Execute_" + getValidEventName(transition.BTOEvent.Name) + "_EventRoutine(now)" + _C + _N;
                rslt += getTab(4) + "break" + _C + _N;
                rslt += getTab(3) + _R + _N;

                sortedActivities.Add(transition.Activity.Name, transition);
            }
            rslt += getTab(2) + _R + _N;
            */
            rslt += getTab(1) + _R + _N;
            rslt += _N;

            //2. individual event routine
            foreach (OOAGActivityTransition transition in _Model.ActivityTransitions)
            {
                rslt += "\t" + "private void Execute_" + getValidEventName(transition.BTOEvent.Name) + "_EventRoutine(double now) { \r\n";

                int count = 0;
                foreach (OOAGAtEndTransition endTransition in transition.AtEnds)
                {
                    if (count == 0)
                        rslt += "\t\t" + "if (" + getCondition(endTransition.Condition) + ") { \r\n";
                    else if (count > 0)
                        rslt += "\t\t" + "if (" + getCondition(endTransition.Condition) + ") { \r\n";

                    bool canceled = false;
                    if (!string.IsNullOrEmpty(endTransition.Action))
                    {
                        string action = endTransition.Action.Trim();
                        if (!action.EndsWith(";"))
                            action += ";";

                        if (action.ToLower().Contains("cancel"))
                        {
                            int startIndex = action.ToLower().IndexOf("cancel");
                            int endIndex = startIndex + 6;

                            if (!string.IsNullOrEmpty(endTransition.InfluencedActivity))
                            {
                                if (sortedActivities.ContainsKey(endTransition.InfluencedActivity))
                                {
                                    OOAGActivityTransition infAct = sortedActivities[endTransition.InfluencedActivity];
                                    string btoEventName = infAct.BTOEvent.Name;
                                    action = action.Substring(0, startIndex) +
                                             "CancelEvent(\"" + btoEventName + "\")" +
                                             action.Substring(endIndex);
                                }else{
                                    action = action.Substring(0, startIndex) + action.Substring(endIndex);
                                }
                                canceled = true;
                            }
                            else
                            {
                                action = action.Substring(0, startIndex) + action.Substring(endIndex);
                            }
                        }

                        rslt += "\t\t\t" + action + "\r\n";
                    }

                    if (!string.IsNullOrEmpty(endTransition.InfluencedActivity) && !canceled)
                    {
                        string[] iaList = endTransition.InfluencedActivity.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                        foreach (string iaName in iaList)
                        {
                            string trimeIAName = iaName.Trim();
                            rslt += "\t\t\t" + "StoreActivity(\"" + trimeIAName + "\");\r\n";
                        }
                    }

                    rslt += "\t\t} \r\n";
                    rslt += "\r\n";

                    count++;
                }

                rslt += "\t}\r\n";
                rslt += "\r\n";
            }

            return rslt;
        }

        private string getCleanClassName(string name)
        {
            string cleanName = name.Replace(" ", "").Replace("(", "").Replace(")", "").Replace("-", "");
            return cleanName;
        }

        private string getTab(int count)
        {
            string tab = string.Empty;
            for (int i = 0; i < count; i++)
                tab += _T;
            return tab;
        }


        private string generateInitializeRoutine()
        {
            string rslt = "";
            //enabled activity
            foreach (OOAGActivityTransition transition in _Model.ActivityTransitions)
            {
                if (transition.Activity.IsEnabled)
                {
                    rslt += "\t\t" + "StoreActivity(\"" + transition.Activity.Name + "\");\r\n";
                }
            }

            return rslt;

        }

    }
}
