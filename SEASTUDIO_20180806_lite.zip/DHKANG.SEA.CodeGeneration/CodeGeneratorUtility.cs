﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.CodeGeneration
{
    public static class CodeGeneratorUtility
    {
        public static List<string> RemoveOperator(string str)
        {
            str = str.Replace(";", "").Replace(",", "");//dhkang 2011/4/25

            List<string> variables = new List<string>();
            string[] opers = { "{", "}", "[", "]", "++", "--", "==", "(", ")", "if", "If", "IF", "else", "ELSE", "Else", "<", "<=", ">=", ">", "+=", "-=", "*=", "/=", "+", "-", "*", "/", "^", "=", "%" };
            string[] splitStr = str.Split(opers, StringSplitOptions.RemoveEmptyEntries);
            foreach (string s in splitStr)
            {
                if (string.IsNullOrEmpty(s.Trim()))
                    continue;

                if (isReal(s) == false && variables.Contains(s) == false)
                    variables.Add(s);
            }
            return variables;
        }

        /// <summary>
        /// Left Operand 와 Right Operand를 구분하여, Right Operand가 변수인 경우만 처리한다.
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static List<string> RemoveOperatorOnly(string str)
        {
            str = str.Replace(";", "").Replace(",", "");//dhkang 2011/4/25

            List<string> variables = new List<string>();
            string[] opers = { "{", "}", "[", "]", "++", "--", "==", "(", ")", "if", "If", "IF", "else", "ELSE", "Else", "<", "<=", ">=", ">", "+=", "-=", "*=", "/=", "+", "-", "*", "/", "^", "=", "%" };
            string[] splitStr = str.Split(opers, StringSplitOptions.RemoveEmptyEntries);

            foreach (string s in splitStr)
            {
                string trimed = s.Trim();
                if (!string.IsNullOrEmpty(trimed))
                    variables.Add(trimed);
            }

            return variables;
        }

        public static bool isReal(string str)
        {
            double dVal = 0.0;
            return double.TryParse(str, out dVal);
            /*
            int firstCharacter = str[0];
            if (firstCharacter <= 57 && firstCharacter >= 48)
                return true;
            else
                return false;
            */
        }
    }
}
