﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DHKANG.SEA.Model.StateObjects;

namespace DHKANG.SEA.CodeGeneration
{
    public enum KeyWords { OVER, STOP, NULL, SyncManager, Simulator };

    public class TEFSMConverter
    {
        private static string _Q = "\""; //quotation
        private static string _CN = "Clock = Now;";
        private static string _L = "!(TAR[∞, {";
        private static string _L2 = "?(MDP[";
        private static string _L3 = "!(TAR[Now + ";
        private static string _R = "}])";
        private static string _R2 = "])";
        private static string _R3 = ", {";
        private static string _C = ";";

        public static OOSGStateObjectModel Convert(OOSGStateObjectModel am)
        {
            OOSGStateObjectModel newAM = new OOSGStateObjectModel(am.Name);

            newAM.HasFinalState = am.HasFinalState;
            newAM.IsContainIntialState = am.IsContainIntialState;

            foreach (OOSGState state in am.States)
            {
                newAM.AddState(state.Clone());
            }

            foreach (OOSGStateVariable sv in am.StateVariables)
                newAM.AddStateVariable(sv.Clone());

            foreach (OOSGParameter p in am.Parameters)
                newAM.AddParameter(p.Clone());

            newAM.BackgroundColor = am.BackgroundColor;

            foreach (OOSGStateTransition st in am.STT)
            {
                OOSGStateTransition newST = new OOSGStateTransition(
                    st.CurrentState,
                    convertEntryAction(getSTT(st.CurrentState, am), am),
                    convertInput(st.InputOrDelay),
                    convertInputAction(st.InputAction),
                    st.Condition,
                    convertTransitionAction(st.TransitionAction),
                    st.NextState);
                newAM.STT.Add(newST);
            }

            //OVER state 추가 및 OVER state에 연결되는 STT 추가
            if (!newAM.HasFinalState)
            {
                OOSGState overState = new OOSGState(KeyWords.OVER.ToString(), StateType.Final, string.Empty, null);
                if (newAM.FindState(overState.Name) != null)
                    newAM.AddState(overState);
                foreach (OOSGState state in am.States)
                {
                    string fI = _L2 + _Q + KeyWords.OVER.ToString() + _Q + _R2;
                    if (!state.Name.Equals(KeyWords.OVER.ToString()))
                    {
                        OOSGStateTransition newFST = new OOSGStateTransition(state,
                           convertEntryAction(getSTT(state, am), am), fI, string.Empty, string.Empty, string.Empty, overState);
                        newAM.STT.Add(newFST);
                    }
                }
            }

            //STOP state 추가 및 STOP state에 연결되는 STT 추가
            OOSGState stopState = new OOSGState(KeyWords.STOP.ToString(), StateType.Final, string.Empty, null);
            if (newAM.FindState(stopState.Name) != null)
                newAM.AddState(stopState);
            foreach (OOSGState state in am.States)
            {
                string fEA = _CN;
                fEA += _L + _Q + KeyWords.STOP.ToString() + _Q + _R;
                string fI = _L2 + _Q + KeyWords.STOP.ToString() + _Q + _R2;
                if (state.Type == StateType.Final && !state.Name.Equals(KeyWords.STOP.ToString()))
                {
                    OOSGStateTransition newFST = new OOSGStateTransition(state,
                        fEA, fI, string.Empty, string.Empty, string.Empty, stopState);
                    newAM.STT.Add(newFST);
                }
            }

            foreach (OOSGMessage msg in am.Messages)
            {
                OOSGMessage newMsg = new OOSGMessage(msg.MName, msg.Type);

                if (msg.Parameters.Count > 0)
                {
                    foreach (OOSGMessageParameter mp in msg.Parameters)
                        newMsg.AddParameter(mp.Name, mp.Value);
                }

                newAM.AddMessage(newMsg);
            }
            return newAM;
        }

        private static string convertEntryAction(List<OOSGStateTransition> sts, OOSGStateObjectModel am)
        {
            string newEA = string.Empty;
            if (sts.Count > 0 && sts[0].EntryAction.Equals(string.Empty) == false)
            {
                //newEA += sts[0].EntryAction;

                string[] tas = sts[0].EntryAction.Split(';');
                //string[] tas = sts[0].EntryAction.Replace(',', ';').Split(';'); //commented out by D.H. Kang at 2012.09.10

                List<string> messages = new List<string>();
                int index = 0;
                foreach (string t in tas)
                {
                    if (t.Contains("!"))
                    {
                        List<string> temp = CodeGeneratorUtility.RemoveOperator(t.Replace("!", ""));
                        string tStr = "!(MSR[" + _Q + temp[0] + _Q + _R2;
                        if (index != tas.Length - 1)
                            tStr += _C;
                        newEA += tStr;
                    }
                    else
                    {
                        if (index == tas.Length - 1)
                            newEA += t;
                        else
                            newEA += t + _C;
                    }
                    index++;
                }
            }
            if (newEA.Equals(string.Empty) == false && newEA.EndsWith(_C) == false)
                newEA += _C;
            newEA += _CN;
            string delay = string.Empty;
            List<string> inputs = new List<string>();
            getTARParam(out delay, out inputs, sts);
            if (!am.HasFinalState)
                inputs.Add(KeyWords.OVER.ToString());

            if (delay.Equals(string.Empty))
                newEA += _L;
            else if (delay.ToLower().Contains("nexttime") || delay.ToLower().Contains("mu"))
                newEA += "!(TAR[" + delay + _R3;
            else
                newEA += _L3 + delay + _R3;

            if (inputs.Count > 0)
            {
                int index = 0;
                foreach (string s in inputs)
                {
                    if (index == inputs.Count - 1)
                        newEA += _Q + s + _Q + _R;
                    else
                        newEA += _Q + s + _Q + ", ";
                    index++;
                }
            }
            else
            {
                if (sts[0].CurrentState.Type == StateType.Final)
                    newEA += _Q + KeyWords.STOP.ToString() + _Q + _R;
                else
                {
                    if (am.HasFinalState)
                        newEA += _Q + KeyWords.NULL.ToString() + _Q + _R;
                }
            }
            return newEA;
        }

        private static string convertInput(string id)
        {
            string newID = string.Empty;
            if (id.Equals(string.Empty) == false)
            {
                if (id.Contains("?"))
                {
                    List<string> temp = CodeGeneratorUtility.RemoveOperator(id.Replace("?", ""));
                    newID = _L2 + _Q + temp[0] + _Q + _R2;
                }
                else
                    newID = "?(TAG)";
            }
            else
                newID = "?(MDP[\"STOP\"])";
            return newID;
        }

        private static string convertInputAction(string sia)
        {
            string newIA = string.Empty;
            string[] ias = sia.Split(';');
            //string[] ias = sia.Replace(',', ';').Split(';');//commented out by D.H. Kang at 2012.09.10

            List<string> messages = new List<string>();
            int index = 0;
            foreach (string t in ias)
            {
                string ia = t.Trim();
                if (ia.Contains("!"))
                {
                    List<string> temp = CodeGeneratorUtility.RemoveOperator(ia.Replace("!", ""));
                    string tStr = "!(MSR[" + _Q + temp[0] + _Q + _R2;
                    if (index != ias.Length - 1)
                        tStr += _C;
                    newIA += tStr;
                }
                else
                {
                    if (index == ias.Length - 1)
                        newIA += ia;
                    else
                        newIA += ia + _C;
                }
                index++;
            }

            return newIA;
        }

        private static string convertTransitionAction(string ta)
        {
            string newTA = string.Empty;
            string[] tas = ta.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
            //string[] tas = ta.Replace(',', ';').Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries); //commented out by D.H. Kang at 2012.09.10

            List<string> messages = new List<string>();
            int index = 0;
            foreach (string t in tas)
            {
                string tt = t.Trim();
                if (tt.Contains("!"))
                {
                    List<string> temp = CodeGeneratorUtility.RemoveOperator(tt.Replace("!", ""));
                    string tStr = "!(MSR[" + _Q + temp[0] + _Q + _R2;
                    if (index != tas.Length - 1)
                        tStr += _C;
                    newTA += tStr;
                }
                else
                {
                    if (index == tas.Length - 1)
                        newTA += tt;
                    else
                        newTA += tt + _C;
                }
                index++;
            }

            return newTA;
        }

        private static List<OOSGStateTransition> getSTT(OOSGState s, OOSGStateObjectModel atomic)
        {
            List<OOSGStateTransition> list = new List<OOSGStateTransition>();
            foreach (OOSGStateTransition st in atomic.STT)
            {
                if (st.CurrentState.Name.Equals(s.Name))
                    list.Add(st);
            }
            return list;
        }

        private static void getTARParam(out string delay, out List<string> input, List<OOSGStateTransition> stt)
        {
            delay = string.Empty;
            input = new List<string>();
            foreach (OOSGStateTransition st in stt)
            {
                if (st.InputOrDelay != string.Empty && st.InputOrDelay.Contains("["))
                {
                    int start = st.InputOrDelay.IndexOf('[');
                    int end = st.InputOrDelay.IndexOf(']');
                    delay = st.InputOrDelay.Substring(start + 1, end - start - 1);

                }
                else if (st.InputOrDelay != string.Empty && st.InputOrDelay.Contains("?"))
                {
                    List<string> temp = CodeGeneratorUtility.RemoveOperator(st.InputOrDelay.Replace("?", ""));
                    foreach (string s in temp)
                    {
                        if (input.Contains(s) == false)
                            input.Add(s);
                    }
                }
            }
        }
    }
}
