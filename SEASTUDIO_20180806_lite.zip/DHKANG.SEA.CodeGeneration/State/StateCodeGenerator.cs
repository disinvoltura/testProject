﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DHKANG.SEA.Model.StateObjects;
using DHKANG.SEA.Model.OID;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.OID.Charts;

namespace DHKANG.SEA.CodeGeneration
{
    public class StateCodeGenerator
    {
        #region Member Variables
        private string _N = Environment.NewLine;
        private string _Q = "\""; //quotation
        private string _L = "{";
        private string _R = "}";
        private string _T = "\t";
        private string _S = "#region";
        private string _E = "#endregion";
        private string _C = ";";
        private string _U = " = ";
        private bool _needRandom = false;
        private SortedList<string, string> _variables;//private parameter
        private OOSGStateObjectModel _CurrentAM;
        private OOMMModel _Model;
        private bool _isRan = true;
        #endregion

        #region Constructors

        #endregion

        #region Methods
        public string GenearteStateObjectSimulatorCode(OOSGStateObjectModel atomic, OOMMModel model, bool fastForwardRun)
        {
            _CurrentAM = atomic;
            _Model = model;
            string code = string.Empty;
            _variables = new SortedList<string, string>();
            code = generateHeaderComment(getCleanAtomicModelName(atomic.Name)) + _N + _N;
            code += generateConstructor(atomic) + _N;
            // code += generateConstructor(atomic.Name, atomic) + _N;
            code += generateCurrentStateProperty() + _N;
            code += generateOverrideMethod(atomic) + _N;
            code += generateStateVariableMethods(atomic) + _N;
            code += getTab(2) + _S + " StateX Methods" + _N;
            foreach (OOSGState s in atomic.States)
            {
                if (!s.Name.Equals(KeyWords.STOP.ToString()))
                {
                    code += generateStateMethods(atomic, s) + _N;
                    code += generateStateXMethods(atomic, s) + _N;
                }
            }

            code += getOverStateMethod(atomic) + _N;
            code += getOverStateXMethod(atomic) + _N;

            code += _N + getTab(2) + _E + _N;
            if (_needRandom)
                code += generateRandomMethod() + _N;

            if (!string.IsNullOrEmpty(atomic.Functions))
            {
                code += getTab(2) + _S + " Functions" + _N;
                code += atomic.Functions;
                code += _N + getTab(2) + _E + _N;
            }

            code += getTab(1) + _R + _N;
            //code += _R;
            return code;
        }

        public string GenearteStateObjectSimulatorCode(string simName, OOSGStateObjectModel atomic)
        {
            _CurrentAM = atomic;
            string code = string.Empty;
            _variables = new SortedList<string, string>();
            code = generateHeaderComment(getCleanAtomicModelName(atomic.Name)) + _N + _N;
            code += generateConstructor(atomic) + _N;
            //code += generateConstructor(simName, atomic) + _N;
            code += generateCurrentStateProperty() + _N;
            code += generateOverrideMethod(atomic) + _N;
            code += generateStateVariableMethods(atomic) + _N;
            code += getTab(2) + _S + " StateX Methods" + _N;
            foreach (OOSGState s in atomic.States)
            {
                if (!s.Name.Equals(KeyWords.STOP.ToString()))
                {
                    code += generateStateMethods(atomic, s) + _N;
                    code += generateStateXMethods(atomic, s) + _N;
                }
            }

            code += getOverStateMethod(atomic) + _N;
            code += getOverStateXMethod(atomic) + _N;

            code += _N + getTab(2) + _E + _N;
            if (_needRandom)
                code += generateRandomMethod() + _N;

            if (!string.IsNullOrEmpty(atomic.Functions))
            {
                code += getTab(2) + _S + " Functions" + _N;
                code += atomic.Functions;
                code += _N + getTab(2) + _E + _N;
            }

            code += getTab(1) + _R + _N;
            code += _R;
            return code;
        }

        private string getOverStateMethod(OOSGStateObjectModel atomic)
        {
            string code = string.Empty;

            code += getTab(2) + "private void State_OVER(double now)" + _N;
            code += getTab(2) + _L + _N;
            code += getTab(3) + "STATE" + _U + getCleanAtomicModelName(atomic.Name) + "State.OVER" + _C + _N + _N;
            code += getTab(3) + "//Entry Action: " + "OVER"+ _N;
            code += getTab(3) + "_Clock = now" + _C + _N;
            code += getTab(3) + "Send_TAR(double.MaxValue, \"STOP\")" + _C + _N;
            code += getTab(2) + _R + _N;

            return code;
        }

        private string getOverStateXMethod(OOSGStateObjectModel atomic)
        {
            string code = string.Empty;

            code += _N + getTab(2) + "private void EXT_State_OVER(INPUT input)" + _N;
            code += getTab(2) + _L + _N;
            code += getTab(3) + "if (input.Type == InputType.MDP) { " + _N;
            code += getTab(4) + "MDP mdp = input.Record as MDP;" + _N;
            code += getTab(4) + "if (mdp.Name.Equals(\"STOP\")) {" + _N;
            code += getTab(5) + "State_STOP(mdp.Now); //Next State" + _N;
            code += getTab(4) + "}else " + _N;
            code += getTab(5) + "WriteError(\"No matching message.\", \"EXT_State_OVER()\");" + _N;
            code += getTab(3) + "} else" + _N;
            code += getTab(4) + "WriteError(\"No matching input.\", \"EXT_State_OVER()\");" + _N;
            code += getTab(2) + _R + _N;

            return code;
        }
        #endregion

        #region Utility Methods
        private string CleanAOName(string aoName)
        {
            return aoName.Replace(" ", "_").Replace("-", "_");
        }

        private string getNamespace(string name)
        {
            //string namespaceName = name.Replace(" ", "").Replace("-", "");
            string namespaceName = name.Replace(" ", "").Replace("(", "").Replace(")", "").Replace("-", "");

            return namespaceName;
        }

        private string getCleanAtomicModelName(string amName)
        {
            string cleanAMName = amName.Replace(" ", "").Replace("(", "").Replace(")", "").Replace("-", "");
            return cleanAMName;
        }

        #endregion

        #region local methods for generating code
        private string generateHeaderComment(string name)
        {
            string commentTemplate =
@"/* 
 * This code is automatically generated by State Graph Simulator, Copyright (C) Donghun Kang, VMS Laboratory.
 * Date: {0}
 * Time: {1}
 * Model Name: {2}
 *
 */
using System;
using System.Collections.Generic;
using System.Collections;
using System.Threading;
using System.Runtime.Remoting.Contexts;
using Troschuetz.Random;
using DHKANG.Foundation.Logging;
using DHKANG.Foundation.RandomVariate;
using DHKANG.Foundation.DataCollection;
using DHKANG.SEA.Simulation;
using DHKANG.SEA.Simulation.States;
using DHKANG.SEA.Simulation.Observers;
";
            string comment = string.Format(commentTemplate, DateTime.Now.ToString("yyyy-MM-dd"), DateTime.Now.ToString("HH:mm"), name);
            return comment;
        }

        private string generateConstructor(OOSGStateObjectModel atomic)
        //private string generateConstructor(string simName, OOSGStateObjectModel atomic)
        {
            //string namespaceName = getNamespace(simName);

            string constructor = "";
            //string constructor = "namespace " + namespaceName + _N;
            //constructor += _L + _N;
            constructor += getTab(1) + "public enum " + getCleanAtomicModelName(atomic.Name) + "State " + _L + " ";
            //int index = 0;
            foreach (OOSGState s in atomic.States)
            {
                constructor += s.Name + ", ";
                //if (index < atomic.States.Count - 1)
                //    constructor += s.Name + ", ";
                //else
                //    constructor += s.Name;
                //index++;
            }
            constructor += "OVER, STOP";
            constructor += " " + _R + _C + _N + _N;
            constructor += getTab(1) + "public class " + getCleanAtomicModelName(atomic.Name) + "Simulator : StateObjectSimulator " + _N;
            constructor += getTab(1) + _L + _N;
            constructor += getTab(2) + _S + " Variables and Constructor" + _N;
            constructor += getTab(2) + "public " + getCleanAtomicModelName(atomic.Name) + "State STATE" + _C + _N;

            foreach (OOSGParameter pm in atomic.Parameters) //Parameters
            {
                if (pm.Type.Equals(OOSGStateVariableHelper.INT))
                {
                    constructor += getTab(2) + "public int " + pm.Name + _C + _N;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.STRING))
                {
                    constructor += getTab(2) + "public string " + pm.Name + _C + _N;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.DOUBLE))
                {
                    constructor += getTab(2) + "public double " + pm.Name + _C + _N;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.DATETIME))
                {
                    constructor += getTab(2) + "public DateTime " + pm.Name + _C + _N;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.BOOL))
                {
                    constructor += getTab(2) + "public bool " + pm.Name + _C + _N;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.RANDOMVARIATE))
                {
                    constructor += getTab(2) + "public RandomVariate " + pm.Name + _C + _N;
                }
                else
                {
                    constructor += getTab(2) + "public " + pm.Type.ToString() + " " + pm.Name + _C + _N;
                }
            }

            foreach (OOSGStateVariable sv in atomic.StateVariables) //state variable (public)
            {
                constructor += getTab(2) + "public " + sv.Type + " " + sv.Name + _C + _N;
            }

            foreach (OOSGStateTransition st in atomic.STT) //probability (private)
            {
                if (st.Condition.Contains("%"))
                {
                    if (_needRandom == false)
                        _needRandom = true;
                    List<string> vars = CodeGeneratorUtility.RemoveOperatorOnly(st.Condition);

                    if (vars.Count == 1)
                    {
                        if (CodeGeneratorUtility.isReal(vars[0]) == false)
                        {
                            string name = "_prob" + vars[0];
                            if (_variables.ContainsKey(name) == false)
                            {
                                constructor += getTab(2) + "private double " + name + _C + _N;
                                _variables.Add(name, "double");
                            }
                        }
                    }
                }
            }


            constructor += getTab(2) + "public " + getCleanAtomicModelName(atomic.Name) + "Simulator(string name)" + _N;
            constructor += getTab(3) + " : base (name)" + _N;
            constructor += getTab(2) + _L + _N;

            //Parameters
            foreach (OOSGParameter pm in atomic.Parameters)
            {
                if (pm.Type.Equals(OOSGStateVariableHelper.INT))
                {
                    if (pm.InitialValue == null || string.IsNullOrEmpty(pm.InitialValue.ToString()))
                        constructor += getTab(3) + pm.Name + _U + "0" + _C + _N;
                    else if (pm.InitialValue.ToString().ToLower().Contains("maxvalue"))
                        constructor += getTab(3) + pm.Name + _U + pm.InitialValue.ToString() + _C + _N;
                    else if (pm.InitialValue.ToString().ToLower().Contains("minvalue"))
                        constructor += getTab(3) + pm.Name + _U + pm.InitialValue.ToString() + _C + _N;
                    else
                        constructor += getTab(3) + pm.Name + _U + int.Parse(pm.InitialValue.ToString()) + _C + _N;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.STRING))
                {
                    if (pm.InitialValue == null || string.IsNullOrEmpty(pm.InitialValue.ToString()))
                        constructor += getTab(3) + pm.Name + _U + "" + _C + _N;
                    else
                        constructor += getTab(3) + pm.Name + _U + pm.InitialValue.ToString() + _C + _N;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.DOUBLE))
                {
                    if (pm.InitialValue == null || string.IsNullOrEmpty(pm.InitialValue.ToString()))
                        constructor += getTab(3) + pm.Name + _U + "0.0" + _C + _N;
                    else if (pm.InitialValue.ToString().ToLower().Contains("maxvalue"))
                        constructor += getTab(3) + pm.Name + _U + pm.InitialValue.ToString() + _C + _N;
                    else if (pm.InitialValue.ToString().ToLower().Contains("minvalue"))
                        constructor += getTab(3) + pm.Name + _U + pm.InitialValue.ToString() + _C + _N;
                    else
                        constructor += getTab(3) + pm.Name + _U + double.Parse(pm.InitialValue.ToString()) + _C + _N;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.DATETIME))
                {
                    if (pm.InitialValue == null || string.IsNullOrEmpty(pm.InitialValue.ToString()))
                        constructor += getTab(3) + pm.Name + _C + _N;
                    else
                        constructor += getTab(3) + pm.Name + _U + DateTime.Parse(pm.InitialValue.ToString()) + _C + _N;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.BOOL))
                {
                    if (pm.InitialValue == null || string.IsNullOrEmpty(pm.InitialValue.ToString()))
                        constructor += getTab(3) + pm.Name + _U + "true" + _C + _N;
                    else
                        constructor += getTab(3) + pm.Name + _U + pm.InitialValue.ToString() + _C + _N;
                }
                else if (pm.Type.Equals(OOSGStateVariableHelper.RANDOMVARIATE))
                {
                    if (pm.InitialValue == null || string.IsNullOrEmpty(pm.InitialValue.ToString()))
                        constructor += getTab(3) + pm.Name + _U + "null" + _C + _N;
                    else
                    {
                        constructor += getTab(3) + pm.Name + _U + "RandomVariateGenerator.GetRandomVariate(\"" + pm.InitialValue.ToString() + "\")" + _C + _N;
                    }
                }
                else
                {
                    if (pm.InitialValue == null || string.IsNullOrEmpty(pm.InitialValue))
                        constructor += getTab(3) + pm.Name + _U + " new " + pm.Type.ToString() + "()" + _C + _N;
                    else
                        constructor += getTab(3) + pm.Name + _U + " new " + pm.Type.ToString() + "(" + pm.InitialValue + ")" + _C + _N;
                }
            }

            //State Variables
            foreach (OOSGStateVariable sv in atomic.StateVariables) //state variable (public)
            {
                if (sv.Type == OOSGStateVariableHelper.INT)
                {
                    if (sv.InitialValue == null || string.IsNullOrEmpty(sv.InitialValue.ToString()))
                        constructor += getTab(3) + sv.Name + _U + "0" + _C + _N;
                    else if (sv.InitialValue.ToString().ToLower().Contains("maxvalue"))
                        constructor += getTab(3) + sv.Name + _U + " int.MaxValue" + _C + _N;
                    else if (sv.InitialValue.ToString().ToLower().Contains("minvalue"))
                        constructor += getTab(3) + sv.Name + _U + " int.MinValue" + _C + _N;
                    else
                        constructor += getTab(3) + sv.Name + _U + sv.InitialValue.ToString() + _C + _N;
                    //break;
                }
                else if (sv.Type == OOSGStateVariableHelper.STRING)
                {
                    if (sv.InitialValue == null || string.IsNullOrEmpty(sv.InitialValue.ToString()))
                        constructor += getTab(3) + sv.Name + _U + "" + _C + _N;
                    else
                        constructor += getTab(3) + sv.Name + _U + sv.InitialValue.ToString() + _C + _N;
                    //break;
                }
                else if (sv.Type == OOSGStateVariableHelper.DOUBLE)
                {
                    if (sv.InitialValue == null || string.IsNullOrEmpty(sv.InitialValue.ToString()))
                        constructor += getTab(3) + sv.Name + _U + "0.0" + _C + _N;
                    else if (sv.InitialValue.ToString().ToLower().Contains("maxvalue"))
                        constructor += getTab(3) + sv.Name + _U + " double.MaxValue" + _C + _N;
                    else if (sv.InitialValue.ToString().ToLower().Contains("minvalue"))
                        constructor += getTab(3) + sv.Name + _U + " double.MinValue" + _C + _N;
                    else
                        constructor += getTab(3) + sv.Name + _U + sv.InitialValue.ToString() + _C + _N;
                    //break;
                }
                else if (sv.Type == OOSGStateVariableHelper.DATETIME)
                {
                    if (sv.InitialValue == null || string.IsNullOrEmpty(sv.InitialValue.ToString()))
                        constructor += getTab(3) + sv.Name + _C + _N;
                    else
                        constructor += getTab(3) + sv.Name + _U + " DateTime.Parse( " + sv.InitialValue.ToString() + ")" + _C + _N;
                    //break;
                }
                else if (sv.Type == OOSGStateVariableHelper.BOOL)
                {
                    if (sv.InitialValue == null || string.IsNullOrEmpty(sv.InitialValue.ToString()))
                        constructor += getTab(3) + sv.Name + _U + "true" + _C + _N;
                    else
                        constructor += getTab(3) + sv.Name + _U + sv.InitialValue.ToString() + _C + _N;
                    //constructor += getTab(3) + sv.SVName + _U + bool.Parse(sv.InitialValue.ToString()) + _C + _N;
                    //break;
                }
                else if (sv.Type == OOSGStateVariableHelper.TIMEQUEUE)
                {
                    constructor += getTab(3) + sv.Name + _U + " new TimeQueue(this, \"" + sv.Name + "\")" + _C + _N;
                    //break;
                }
                else if (sv.Type == OOSGStateVariableHelper.RANDOMVARIATE)
                {
                    constructor += getTab(3) + string.Format("{0} = RandomVariateGenerator.GetRandomVariate(\"{1}\")" + _C + _N, sv.Name, sv.InitialValue);
                    //break;
                }
                else if (sv.Type == OOSGStateVariableHelper.ENTITYQUEUE)
                {
                    constructor += getTab(3) + string.Format("{0} = new EntityQueue(this, \"{1}\")" + _C + _N, sv.Name, sv.Name);
                    OOMMEntityQueue q = _CurrentAM.FindEntityQueue(sv.Name);
                    if (q != null)
                    {
                        constructor += getTab(3) + string.Format("Dictionary<string, object> {0}_args = new Dictionary<string, object>()" + _C + _N, sv.Name);
                        constructor += getTab(3) + string.Format("{0}_args[\"rule\"] = \"{1}\"" + _C + _N, sv.Name, q.Rule.ToString());
                        constructor += getTab(3) + string.Format("{0}.Initialize({0}_args)" + _C + _N, sv.Name);
                    }

                    constructor += getTab(3) + string.Format("this.SimulationEnded += {0}.OnSimulationEnded" + _C + _N, sv.Name);
                }
                else if (sv.Type == OOSGStateVariableHelper.RESOURCE)
                {
                    constructor += getTab(3) + string.Format("{0} = new Resource(this, \"{1}\")" + _C + _N, sv.Name, sv.Name);
                }
                else
                {
                    if (_Model.ContainEntity(sv.Type))
                    {
                        constructor += getTab(3) + sv.Name + _U + " new " + sv.Type.ToString() + "()" + _C + _N;
                    }
                    else
                    {
                        if (sv.Type.Contains("["))
                        {
                            if (sv.InitialValue != null)
                                constructor += getTab(3) + sv.Name + _U + " new " + sv.Type + sv.InitialValue + _C + _N;
                        }
                        else
                        {
                            if (sv.InitialValue == null || string.IsNullOrEmpty(sv.InitialValue.ToString()))
                                constructor += getTab(3) + sv.Name + _U + " new " + sv.Type.ToString() + "()" + _C + _N;
                            else
                                constructor += getTab(3) + sv.Name + _U + " new " + sv.Type.ToString() + "(" + sv.InitialValue + ")" + _C + _N;
                        }
                    }
                }
            }
            constructor += getTab(2) + _R + _N;
            constructor += getTab(2) + _E + _N;
            return constructor;
        }

        private string generateOverrideMethod(OOSGStateObjectModel atomic)
        {
            string method = string.Empty;
            method = getTab(2) + "public override void Run()" + _N;
            method += getTab(2) + _L + _N;
            method += getTab(3) + "State_" + getInitialState(atomic.States) + "(0.0)" + _C + _N;
            method += getTab(2) + _R + _N + _N;

            method += getTab(2) + "public override void ExternalInput(INPUT input)" + _N;
            method += getTab(2) + _L + _N;
            method += getTab(3) + "switch (STATE)" + _N;
            method += getTab(3) + _L + _N;
            foreach (OOSGState s in atomic.States)
            {
                if (s.Name.Equals(KeyWords.STOP.ToString())) //STOP 제외
                    continue;
                method += getTab(4) + "case " + getCleanAtomicModelName(atomic.Name) + "State." + s.Name + ":" + _N;
                method += getTab(5) + "EXT_State_" + s.Name + "(input)" + _C + _N;
                method += getTab(5) + "break" + _C + _N;
            }
            method += getTab(4) + "default:" + _N;
            method += getTab(5) + "WriteError(" + _Q + "No matching state." + _Q + ", " + _Q + "ExternalInput()" + _Q + ")" + _C + _N;
            method += getTab(5) + "break" + _C + _N;
            method += getTab(3) + _R + _N;
            method += getTab(2) + "this.NotifyStateObservers(new StateObjectStateObservedEvent(this.Clock, this))" + _C + _N;
            method += getTab(2) + _R + _N;
            return method;
        }

        private string generateCurrentStateProperty()
        {
            string property = string.Empty;

            property += getTab(2) + "public override string CurrentState" + _N;
            property += getTab(2) + _L + _N;
            property += getTab(3) + "get { return this.STATE.ToString();}" + _N;
            property += getTab(2) + _R + _N;

            return property;
        }

        private string generateStateVariableMethods(OOSGStateObjectModel atomic)
        {
            string method = string.Empty;
            method += getTab(2) + "public override object GetStateVariable(string name)" + _N;
            method += getTab(2) + _L + _N;

            string properties = string.Empty;
            if (atomic.StateVariables.Count > 0)
            {
                //int count = 0;
                foreach (OOSGStateVariable sv in atomic.StateVariables)
                {
                    method += getTab(3) + "if (name.Equals(\"" + sv.Name + "\"))" + _N;
                    method += getTab(4) + "return this." + sv.Name + _C + _N;

                    if (sv.Type == OOSGStateVariableHelper.TIMEQUEUE)
                    {
                        properties += getTab(2) + "public double " + sv.Name + "_Tau { get { return " + sv.Name + ".Tau;} set { " + sv.Name + ".Tau = value;}}";
                    }
                }
            }

            //todo BAR CHART
            foreach (OOMMPieChart pc in _Model.ObjectInteractionDiagram.PieCharts)
            {
                foreach (OOMMSeries s in pc.Series.Values)
                {
                    //string svName = getCleanAtomicModelName(pc.Title) + "_" + s.Name;
                    string objectName = s.Value.Split(new char[] { '.' }, StringSplitOptions.RemoveEmptyEntries)[0];

                    OOMMObjectNode node = _Model.ObjectInteractionDiagram.FindObjectNode(objectName);
                    if (!node.ModelID.Equals(_CurrentAM.ID))
                    {
                        continue;
                    }
                    string svName = pc.Title + "_" + s.Name;
                    string svValue = s.Value.Substring(s.Value.IndexOf('.') + 1);
                    method += getTab(3) + "if (name.Equals(\"" + svName + "\"))" + _N;
                    method += getTab(4) + "return this." + svValue + _C + _N;
                }
            }

            method += getTab(3) + "return null" + _C + _N;
            method += getTab(2) + _R + _N;

            method += properties + _N;

            //////////////////////////////////////
            string svlist = string.Empty;
            method += getTab(2) + "public override void SetStateVariable(string name, object value)" + _N;
            method += getTab(2) + _L + _N;
            if (atomic.StateVariables.Count > 0)
            {
                int count = 0;
                foreach (OOSGStateVariable sv in atomic.StateVariables)
                {
                    string strType = getStateVariableType(sv);
                    method += getTab(3) + "if (name.Equals(\"" + sv.Name + "\"))" + _N;
                    method += getTab(4) + "this." + sv.Name + " = (" + strType + ")value" + _C + _N;

                    if (count < atomic.StateVariables.Count - 1)
                        svlist += string.Format("\"{0}\",", sv.Name);
                    else
                        svlist += string.Format("\"{0}\"", sv.Name);
                    count++;
                }
            }
            method += getTab(2) + _R + _N;

            method += getTab(1) + "public override List<string> StateVariables " + _N;
            method += getTab(1) + _L + _N;
            method += getTab(2) + "get { return new List<string>(){" + svlist + "};} " + _N; ;
            method += getTab(1) + _R + _N;


            return method;
        }

        private string getStateVariableType(OOSGStateVariable sv)
        {
            string strType = sv.Type;
            return strType;
        }

        private static string getInputMessageName(string inputEvent)
        {
            string name = string.Empty;
            if (string.IsNullOrEmpty(inputEvent))
                return string.Empty;

            if (inputEvent.EndsWith("?"))
            {
                //"(msg)?"
                name = inputEvent.Substring(1, inputEvent.Length - 3);
                //name = inputEvent.Substring(2, inputEvent.Length - 3);
            }
            return name;
        }

        private OOSGState _CurrentState;
        private string generateStateMethods(OOSGStateObjectModel atomic, OOSGState state)
        {
            _CurrentState = state;
            string code = string.Empty;
            List<OOSGStateTransition> stt = getSTT(state, atomic);

            string strInputMessages = string.Empty;
            List<string> inputMsgList = new List<string>();
            foreach (OOSGStateTransition st in stt)
            {
                if (st.InputOrDelay.EndsWith("?"))
                {
                    string msgName = getInputMessageName(st.InputOrDelay);
                    if (!string.IsNullOrEmpty(msgName))
                    {
                        if (!inputMsgList.Contains(msgName))
                        {
                            strInputMessages += "\"" + msgName + "\",";
                            inputMsgList.Add(msgName);
                        }
                    }
                }
            }
            if (state.Type == StateType.Final)
                strInputMessages += "\"STOP\"";
            else
            {
                strInputMessages += "\"OVER\"";
                //if (!string.IsNullOrEmpty(strInputMessages))
                //    strInputMessages = strInputMessages.Substring(0, strInputMessages.Length - 1);
            }

            //StateType.Final.ToString
            string stateName = getCleanAtomicModelName(atomic.Name) + "State." + state.Name;
            code += getTab(2) + "private void State_" + state.Name + "(double now)" + _N;
            code += getTab(2) + _L + _N;
            code += getTab(3) + "System.Diagnostics.Debug.WriteLine(\"[\" + this.ID + \"] State_" + state.Name + "(\" + now + \")\")" + _C + _N;
            
            code += getTab(3) + "STATE" + _U + stateName + _C + _N;
            code += getTab(3) + "EnterState(" + stateName + ".ToString(), now)" + _C + _N + _N;
            code += getTab(3) + "//Entry Action: " + state.Name + _N;
            code += getTab(3) + "_Clock = now" + _C + _N;
            //code += state.EntryAction;

            _CurrentInput = "";
            code += convertAction(3, state.EntryAction) + _N;
            code += getTab(3) + "OnEntryActionPerformed(now, \"" + stateName + "\")" + _C + _N;

            //final state
            if (state.Type != StateType.Final)
            {
                //Send_TAR
                if (state.Delay == null || string.IsNullOrEmpty(state.Delay.Name))
                {
                    code += getTab(3) + "Send_TAR(double.MaxValue," + strInputMessages + ")" + _C + _N;
                }
                else
                {
                    if (state.Delay.Name.ToLower().Contains(".mu") ||
                        state.Delay.Name.ToLower().Contains(".nexttime"))
                        code += getTab(3) + "Send_TAR(" + state.Delay.Name + ", " + strInputMessages + ")" + _C + _N;
                    else
                        code += getTab(3) + "Send_TAR(_Clock + " + state.Delay.Name + ", " + strInputMessages + ")" + _C + _N;
                }
            }
            else
            {
                code += getTab(3) + "Send_TAR(double.MaxValue," + strInputMessages + ")" + _C + _N;
            }

            code += getTab(2) + _R + _N;

            return code;
        }

        private string _CurrentInput;
        private string generateStateXMethods(OOSGStateObjectModel atomic, OOSGState state)
        {
            _CurrentState = state;
            List<OOSGStateTransition> stt = getSTT(state, atomic);

            string code = string.Empty;
            code += _N + getTab(2) + "private void EXT_State_" + state.Name + "(INPUT input)" + _N;
            code += getTab(2) + _L + _N;
            code += getTab(3) + "System.Diagnostics.Debug.WriteLine(\"[\" + this.ID + \"] EXT_State_" + state.Name + "()\")" + _C + _N;

            if (state.Type == StateType.Final)
            {
                code += getTab(3) + "if (input.Type == InputType.MDP) { " + _N;
                code += getTab(4) + "MDP mdp = input.Record as MDP;" + _N;
                code += getTab(4) + "if (mdp.Name.Equals(\"STOP\")) {" + _N;
                code += getTab(5) + "State_STOP(mdp.Now); //Next State" + _N;
                code += getTab(4) + "}else " + _N;
                code += getTab(5) + "WriteError(\"No matching message.\", \"EXT_State_OVER()\");" + _N;
                code += getTab(3) + "} else" + _N;
                code += getTab(4) + "WriteError(\"No matching input.\", \"EXT_State_OVER()\");" + _N;
            }
            else
            {
                OOSGStateTransition overStateTransition = new OOSGStateTransition(state, "", "(OVER)?", "", "", "", new OOSGState("OVER", StateType.Regular, "", new OOSGDelay("")));
                stt.Add(overStateTransition);
                int mdpCount = 0;
                int tagCount = 0;
                string codeMdp = string.Empty;
                string codeTAG = string.Empty;

                Dictionary<string, string> mdpCodeList = new Dictionary<string, string>();
                Dictionary<string, string> tagCodeList = new Dictionary<string, string>();
                List<string> trueCondMDPList = new List<string>();//
                for (int i = 0; i < stt.Count; i++)
                {
                    OOSGStateTransition st = stt[i];

                    if (st.InputOrDelay.EndsWith("?")) //MDP
                    {
                        _CurrentInput = "mdp";
                        string ifterm = "if";
                        if (mdpCount > 0)
                            ifterm = "else if ";

                        string mdpInput = getInputMessageName(st.InputOrDelay);
                        string codeMdpSnippet = string.Empty;
                        if (mdpCodeList.ContainsKey(mdpInput))
                        {
                            string condition = string.IsNullOrEmpty(st.Condition) ? "true" : st.Condition;
                            codeMdpSnippet += getTab(5) + "//Transition Condition: " + state.Name + ";" + st.InputOrDelay + ";" + st.Condition + _N;
                            codeMdpSnippet += getTab(5) + "else if (" + condition + ") { " + _N;
                            if (!string.IsNullOrEmpty(st.TransitionAction))
                            {
                                codeMdpSnippet += getTab(6) + "//Transition Action: " + state.Name + ";" + st.InputOrDelay + _N;
                                codeMdpSnippet += convertAction(6, st.TransitionAction) + _N;
                                codeMdpSnippet += getTab(6) + "OnTransitionActionPerformed(mdp.Now,\"" + state.Name + "\", \"" + st.NextState.Name + "\")" + _C + _N;
                                //codeMdpSnippet += getTab(6) + st.TransitionAction + _N;
                            }
                            codeMdpSnippet += getTab(6) + "//Next State" + _N;
                            codeMdpSnippet += getTab(6) + "State_" + st.NextState.Name + "(mdp.Now)" + _C + _N;
                            codeMdpSnippet += getTab(5) + _R + _N;

                            mdpCodeList[mdpInput] = mdpCodeList[mdpInput] + codeMdpSnippet;
                        }
                        else
                        {
                            string condition = string.IsNullOrEmpty(st.Condition) ? "true" : st.Condition;
                            if (condition.Equals("true"))
                                trueCondMDPList.Add(mdpInput);

                            codeMdpSnippet += getTab(4) + "//Input Event: " + state.Name + ";" + st.InputOrDelay + _N;
                            codeMdpSnippet += getTab(4) + ifterm + "(mdp.Name.Equals(\"" + mdpInput + "\")){" + _N;

                            //handle mesage parameters
                            OOSGMessage message = _CurrentAM.FindMessage(mdpInput);

                            string msgDataCode = string.Empty;

                            if (message != null && message.Parameters.Count > 0)
                            {
                                foreach (OOSGMessageParameter p in message.Parameters)
                                {
                                    string svName = p.Value;
                                    if (string.IsNullOrEmpty(svName))
                                        continue;

                                    OOSGStateVariable sv = _CurrentAM.FindStateVariable(svName);
                                    if (sv == null)
                                        continue;

                                    string strType = _CurrentAM.FindStateVariable(svName).Type;
                                    msgDataCode += getTab(5) + "if (mdp.Data.ContainsKey(\"" + p.Name + "\"))" + _N;
                                    msgDataCode += getTab(5) + _L + _N;
                                    msgDataCode += getTab(6) + "this." + svName + " = (" + strType + ")mdp.Data[\"" + p.Name + "\"]" + _C + _N;

                                    //msgDataCode += getTab(6) + "if (this." + svName + " is AbstractEntity)" + _N;
                                    if (_Model.FindEntity(sv.Type) != null)
                                    msgDataCode += getTab(6) + "this." + svName + ".Enter(this.ID, \"" + st.CurrentState.Name + "\", mdp.Now)" + _C + _N;
                                    msgDataCode += getTab(5) + _R + _N;
                                }
                            }

                            if (!string.IsNullOrEmpty(msgDataCode))
                            {
                                codeMdpSnippet += getTab(5) + "//Message Parameters" + _N;
                                codeMdpSnippet += msgDataCode;
                                codeMdpSnippet += getTab(5) + _N;
                            }

                            if (!string.IsNullOrEmpty(st.InputAction))
                            {
                                codeMdpSnippet += getTab(5) + "//Input Action: " + state.Name + ";" + st.InputOrDelay + _N;
                                codeMdpSnippet += convertAction(5, st.InputAction) + _N;
                                codeMdpSnippet += getTab(5) + "OnInputActionPerformed(mdp.Now, \""+ state.Name + "\", \"" + st.InputOrDelay + "\")" + _C + _N;
                                //codeMdpSnippet += getTab(5) + st.InputAction + _N;
                            }
                            codeMdpSnippet += getTab(5) + "//Transition Condiiton: " + state.Name + ";" + st.InputOrDelay + ";" + st.Condition + _N;
                            codeMdpSnippet += getTab(5) + "if (" + condition + ") { " + _N;
                            if (!string.IsNullOrEmpty(st.TransitionAction))
                            {
                                codeMdpSnippet += getTab(6) + "//Transition Action: " + state.Name + ";" + st.InputOrDelay + ";" + st.Condition + _N;
                                codeMdpSnippet += convertAction(6, st.TransitionAction) + _N;
                                codeMdpSnippet += getTab(6) + "OnTransitionActionPerformed(mdp.Now, \"" + state.Name + "\", \"" + st.NextState.Name + "\")" + _C + _N;
                                //codeMdpSnippet += getTab(6) + st.TransitionAction + _N;
                            }
                            codeMdpSnippet += getTab(6) + "//Next State" + _N;
                            codeMdpSnippet += getTab(6) + "State_" + st.NextState.Name + "(mdp.Now)" + _C + _N;
                            codeMdpSnippet += getTab(5) + _R + _N;

                            mdpCodeList.Add(mdpInput, codeMdpSnippet);
                            mdpCount++;
                        }
                    }
                    else //TAG
                    {
                        _CurrentInput = "tag";
                        string ifterm = "if";
                        if (tagCount > 0)
                            ifterm = "else if ";

                        if (string.IsNullOrEmpty(st.InputOrDelay))
                            continue;

                        string tagInput = st.InputOrDelay.Substring(6, st.InputOrDelay.Length - 7);
                        string codeTagSnippet = string.Empty;
                        if (tagCodeList.ContainsKey(tagInput))
                        {
                            string condition = string.IsNullOrEmpty(st.Condition) ? "true" : st.Condition;

                            codeTagSnippet += getTab(4) + "//Transition Condition: " + state.Name + ";" + st.InputOrDelay + ";" + st.Condition + _N;
                            codeTagSnippet += getTab(4) + "else if (" + condition + ") { " + _N;
                            codeTagSnippet += getTab(5) + "//Transition Action: " + state.Name + ";" + st.InputOrDelay + ";" + st.Condition + _N;
                            codeTagSnippet += convertAction(5, st.TransitionAction) + _N;
                            codeTagSnippet += getTab(5) + "OnTransitionActionPerformed(tag.Now, \"" + state.Name + "\", \"" + st.NextState.Name + "\")" + _C + _N;
                            //codeTagSnippet += getTab(5) + st.TransitionAction + _N;
                            codeTagSnippet += getTab(5) + "//Next State" + _N;
                            codeTagSnippet += getTab(5) + "State_" + st.NextState.Name + "(tag.Now)" + _C + _N;
                            codeTagSnippet += getTab(4) + _R + _N;

                            tagCodeList[tagInput] = tagCodeList[tagInput] + codeTagSnippet;
                        }
                        else
                        {
                            string condition = string.IsNullOrEmpty(st.Condition) ? "true" : st.Condition;

                            if (!string.IsNullOrEmpty(st.InputAction))
                            {
                                codeTagSnippet += getTab(4) + "//Input Action: " + state.Name +";" + st.InputOrDelay + _N;
                                codeTagSnippet += convertAction(4, st.InputAction) + _N;
                                codeTagSnippet += getTab(4) + "OnInputActionPerformed(tag.Now, \"" + state.Name + "\", \"" + st.InputOrDelay + "\")" + _C + _N;
                                //codeTagSnippet += getTab(4) + st.InputAction + _N;
                            }
                            codeTagSnippet += getTab(4) + "//Transition Condition: " + state.Name + ";" + st.InputOrDelay + ";" + st.Condition + _N;
                            codeTagSnippet += getTab(4) + "if (" + condition + ") { " + _N;
                            if (!string.IsNullOrEmpty(st.TransitionAction))
                            {
                                codeTagSnippet += getTab(5) + "//Transition Action: " + state.Name + ";" + st.InputOrDelay + ";" + st.Condition + _N;
                                codeTagSnippet += convertAction(5, st.TransitionAction) + _N;
                                codeTagSnippet += getTab(5) + "OnTransitionActionPerformed(tag.Now, \"" + state.Name + "\", \"" + st.NextState.Name +"\")" + _C + _N;
                                //codeTagSnippet += getTab(5) + st.TransitionAction + _N;
                            }
                            codeTagSnippet += getTab(5) + "//Next State" + _N;
                            codeTagSnippet += getTab(5) + "State_" + st.NextState.Name + "(tag.Now)" + _C + _N;
                            codeTagSnippet += getTab(4) + _R + _N;

                            tagCodeList.Add(tagInput, codeTagSnippet);
                            tagCount++;
                        }
                    }
                }

                foreach (string mdp in mdpCodeList.Keys)
                {
                    codeMdp += mdpCodeList[mdp];
                    if (!mdpCodeList.ContainsKey(mdp))
                    {
                        //dead state when unhandled condition happens.
                        codeMdp += getTab(5) + "else {" + _N;
                        codeMdp += getTab(6) + "//Next State" + _N;
                        codeMdp += getTab(6) + "State_DEAD(mdp.Now)" + _C + _N;
                        codeMdp += getTab(5) + _R + _N;

                    }
                    codeMdp += getTab(4) + _R + _N;
                }

                foreach (string tag in tagCodeList.Keys)
                {
                    codeTAG += tagCodeList[tag];
                }

                if (tagCount > 0)
                {
                        //dead state when unhandled condition happens.
                    string tagHeader = getTab(3) + "if (input.Type == InputType.TAG) {" + _N;
                    tagHeader += getTab(4) + "TAG tag = input.Record as TAG" + _C + _N;
                    codeTAG = tagHeader + codeTAG;

                    //dead state
                    if (tagCodeList.Count > 0)
                    { 
                        codeTAG += getTab(4) + "else { " + _N;
                        codeTAG += getTab(5) + "//Dead State" + _N;
                        codeTAG += getTab(5) + "State_DEAD(tag.Now)" + _C + _N;
                        codeTAG += getTab(4) + _R + _N;
                    }
                    codeTAG += getTab(3) + _R + _N;
                    code += codeTAG;
                }

                if (mdpCount > 0)
                {
                    string ifterm = "if";
                    if (tagCount > 0)
                        ifterm = "else if ";

                    string mdpHeader = getTab(3) + ifterm + " (input.Type == InputType.MDP) {" + _N;
                    mdpHeader += getTab(4) + "MDP mdp = input.Record as MDP" + _C + _N;
                    codeMdp = mdpHeader + codeMdp;
                    codeMdp += getTab(3) + _R + _N;
                    code += codeMdp;
                }
            }

            code += getTab(2) + _R + _N;

            return code;
        }

        //TODO
        //Action 에서 Message Out 처리할 것!!!
        //?(msg) -> Send_MSR(msg);
        //또는 parameter가 있는 경우 처리

        private string generateRandomMethod()
        {
            string random = string.Empty;
            random += getTab(2) + "private double Gen_Random()" + _N;
            random += getTab(2) + _L + _N;
            random += getTab(3) + "ContinuousUniformDistribution cud" + _U + "new ContinuousUniformDistribution()" + _C + _N;
            random += getTab(3) + "cud.Alpha" + _U + "0" + _C + _N;
            random += getTab(3) + "cud.Beta" + _U + "1" + _C + _N;
            random += getTab(3) + "return cud.NextDouble()" + _C + _N;
            random += getTab(2) + _R;
            return random;
        }
        #endregion

        #region local method
        private string getInitialState(IList<OOSGState> states)
        {
            string initialS = string.Empty;
            foreach (OOSGState s in states)
            {
                if (s.Type == StateType.Initial)
                {
                    initialS = s.Name;
                    break;
                }
            }
            return initialS;
        }

        private List<OOSGStateTransition> getSTT(OOSGState s, OOSGStateObjectModel atomic)
        {
            List<OOSGStateTransition> list = new List<OOSGStateTransition>();
            foreach (OOSGStateTransition st in atomic.STT)
            {
                if (st.CurrentState.Name.Equals(s.Name))
                    list.Add(st);
            }
            return list;
        }

        private string convertAction(int tab, string action)
        {
            string newAction = action;
            //"(msg)! --> Send_MSR(....
            string pattern = @"\(\s*\b\w+\s*\)\!";
            //bool rslt = System.Text.RegularExpressions.Regex.IsMatch(expr, pattern, System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            System.Text.RegularExpressions.MatchCollection list = System.Text.RegularExpressions.Regex.Matches(newAction, pattern);

            while (list != null && list.Count > 0)
            {
                System.Text.RegularExpressions.Match match = list[0];

                string msgName = match.Value.Substring(1, match.Value.Length - 3);

                OOSGMessage msg = _CurrentAM.FindMessage(msgName);
                if (msg != null)
                {
                    string newStr = string.Empty;
                    if (msg.Parameters.Count > 0)
                    {
                        newStr = getTab(tab) + "MessageData msg" + msgName + " = new MessageData(\"" + msgName + "\")" + _C + _N;
                        foreach (OOSGMessageParameter p in msg.Parameters)
                        {
                            newStr += getTab(tab) + "msg" + msgName + "[\"" + p.Name + "\"] = this." + p.Value + _C + _N;

                            OOSGStateVariable sv = _CurrentAM.FindStateVariable(p.Value);
                            if (sv != null && _Model.FindEntity(sv.Type) != null)
                            {
                                string nowExpr = "now";
                                if (!string.IsNullOrEmpty(_CurrentInput))
                                    nowExpr = _CurrentInput + ".Now";
                                newStr += getTab(tab) + p.Value + ".Leave(this.ID, \"" + _CurrentState.Name + "\", " + nowExpr + ")" + _C + _N;
                            }
                        }
                        newStr += getTab(tab) + "Send_MSR(msg" + msgName + ")" + _C + _N;

                        //return newStr;
                    }
                    else
                    {
                        newStr = getTab(tab) + "Send_MSR(\"" + msgName + "\");" + _N;
                    }

                    newAction = newAction.Substring(0, match.Index) + newStr + newAction.Substring(match.Index + match.Length);
                    //newAction = newAction.Replace("!(" + msgName + ");", newStr);
                    list = System.Text.RegularExpressions.Regex.Matches(newAction, pattern);
                }
                else
                {//the message is undefined
                    break;
                }
            }
            if (!newAction.EndsWith(";"))
                newAction += ";";
            return newAction;

            //while (newAction.Contains("!("))
            //{
            //    int s = newAction.IndexOf("!(");
            //    int e = newAction.IndexOf(";", s);

            //    string msgName = newAction.Substring(s + 2, e - s - 3);

            //    VMS.StateGraph.Model.Message msg = _CurrentAM.FindMessage(msgName);
            //    if (msg != null)
            //    {
            //        string newStr = string.Empty;
            //        if (msg.Parameters.Count > 0)
            //        {
            //            newStr = getTab(tab) + "MessageData msg" + msgName + " = new MessageData(\"" + msgName + "\")" + _C + _N;
            //            foreach (string pName in msg.Parameters.Keys)
            //            {
            //                string pValue = (string)msg.Parameters[pName];
            //                newStr += getTab(tab) + "msg" + msgName + "[\"" + pName + "\"] = this." + pValue + _C + _N;
            //            }
            //            newStr += getTab(tab) + "Send_MSR(msg" + msgName + ")" + _C + _N;

            //            return newStr;
            //        }
            //        else
            //        {
            //            newStr = getTab(tab) + "Send_MSR(\"" + msgName + "\");" + _N;
            //        }

            //        newAction = newAction.Replace("!(" + msgName + ");", newStr);
            //    }
            //}

            //return newAction;
        }

        private string convertKeyword(int tab, string str)
        {
            string newStr = str.Trim();

            if (newStr.Contains("!(TAR["))
                newStr = newStr.Replace("!(TAR[", "Send_TAR(");
            if (newStr.Contains("!(MSR["))
            {
                int mStart = newStr.IndexOf("[") + 2;
                int mEnd = newStr.IndexOf("]") - 1;
                string msgName = newStr.Substring(mStart, mEnd - mStart);
                OOSGMessage msg = _CurrentAM.FindMessage(msgName);

                if (msg != null)
                {
                    if (msg.Parameters.Count > 0)
                    {
                        newStr = getTab(tab) + "MessageData msg" + msgName + " = new MessageData(\"" + msgName + "\")" + _C + _N;
                        foreach (OOSGMessageParameter p in msg.Parameters)
                        {
                            newStr += getTab(tab) + "msg" + msgName + "[\"" + p.Name + "\"] = this." + p.Value + _C + _N;
                        }
                        newStr += getTab(tab) + "Send_MSR(msg" + msgName + ")" + _C + _N;

                        return newStr;
                    }
                    else
                    {
                        newStr = newStr.Replace("!(MSR[", "Send_MSR(");
                    }

                }
                else
                {
                    newStr = newStr.Replace("!(MSR[", "Send_MSR(");
                }

            }
            if (newStr.Contains("Now +"))
            {
                newStr = newStr.Replace("Now +", "_Clock +");
                string[] temp = newStr.Split(',');

                if (temp[0].Contains("_Clock +"))
                {
                    string tmp = temp[0].Replace(" ", "");
                    int index = tmp.LastIndexOf('+') + 1;
                    string var = tmp.Substring(index);

                    if (CodeGeneratorUtility.isReal(var) == false)
                    {
                        if (tmp.ToLower().Contains("nexttime"))
                        {

                        }
                        else if (tmp.ToLower().Contains("beta") ||
                                  tmp.ToLower().Contains("expo") ||
                                  tmp.ToLower().Contains("normal") ||
                                  tmp.ToLower().Contains("weib") ||
                                  tmp.ToLower().Contains("erlang") ||
                                  tmp.ToLower().Contains("student") ||
                                  tmp.ToLower().Contains("uniform") ||
                                  tmp.ToLower().Contains("tri"))
                        {
                            //TODO
                            //e.g expo(ts)..-.-

                        }
                        else
                        {
                            string tauStr = tmp.Substring(0, index) + var;
                            newStr = tauStr + newStr.Substring(temp[0].Length);
                        }
                    }
                }
            }

            if (newStr.Contains("∞"))
                newStr = newStr.Replace("∞", "double.MaxValue");
            if (newStr.Contains("Clock = Now"))
                newStr = newStr.Replace("Clock = Now", "_Clock = now;");
            if (newStr.Contains("Now"))
                newStr = newStr.Replace("Now", "now");
            if (newStr.Contains("])"))
                newStr = newStr.Replace("])", ");");
            if (newStr.Contains(_L))
                newStr = newStr.Replace(_L, "");
            if (newStr.Contains(_R))
                newStr = newStr.Replace(_R, "");
            if (!newStr.EndsWith(_C))
                newStr += _C;

            if (newStr.Contains("++"))
            {
                string varName = newStr.Substring(0, newStr.IndexOf("++"));

                if (_variables.ContainsKey(varName))
                {
                    string varType = _variables[varName];
                    if (varType == "TimeQueue") //Enum.GetName(typeof(StateVariableType), StateVariableType.TimeQueue))
                    {
                        newStr = varName + " += mdp.Now;";
                    }
                }
                else if (_CurrentAM.FindStateVariable(varName) != null)
                {
                    OOSGStateVariable sv = _CurrentAM.FindStateVariable(varName);
                    if (sv.Type == OOSGStateVariableHelper.TIMEQUEUE)
                    {
                        newStr = varName + " += mdp.Now";
                    }
                }
            }

            if (!newStr.StartsWith("\t"))
                newStr = getTab(tab) + newStr;
            return newStr;
        }


        private string getTab(int count)
        {
            string tab = string.Empty;
            for (int i = 0; i < count; i++)
                tab += _T;
            return tab;
        }
        #endregion
    }
}
