﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DHKANG.SEA.Model.EventObjects;
using DHKANG.SEA.Model;
using DHKANG.SEA.Model.Data;
using DHKANG.SEA.Model.OID;
using DHKANG.SEA.Model.Entities;
using DHKANG.SEA.Model.OID.Charts;

namespace DHKANG.SEA.CodeGeneration
{
    public class EventCodeGenerator
    {
        #region Member Variables
        private string _N = Environment.NewLine;
        private string _Q = "\""; //quotation
        private string _L = "{";
        private string _R = "}";
        private string _T = "\t";
        private string _S = "#region";
        private string _E = "#endregion";
        private string _C = ";";
        private string _U = " = ";
        private bool _needRandom = false;
        private SortedList<string, string> _variables;//private parameter
        private OOMMModel _Model;
        private OOEGEventObjectModel _EOModel;
        private bool _IsFastForwardRun = false;
        private bool _isRan = true;


        private int _LineNumFunctions;
        #endregion

        #region Properties
        public int FunctionLineNo { get { return _LineNumFunctions; } }
        #endregion

        #region Constructors
        public EventCodeGenerator(OOMMModel model)
        {
            _Model = model;
        }
        #endregion

        #region Event Object Simulator Methods
        public string GenerateEventObjectSimulatorCode(OOEGEventObjectModel model, bool includeEventTransitions)
        {
            _EOModel = model;

            string code = string.Empty;

            code += generateHeader();
            code += generateMembers();
            code += generateConstructor();

            if (includeEventTransitions)
                code += generateEventRoutineMethod();

            code += generateAbstractMethods();

            string[] tmp = code.Split(
                new string[] { _N },
                StringSplitOptions.None);
            _LineNumFunctions = tmp.Length;

            //code += generateDataMapperMethod();
            code += generateInitializeDataMappers();

            code += generateFunctions();

            code += _R;
            return code;
        }

        public string GenerateEventObjectSimulatorCode(OOEGEventObjectModel model, bool includeEventTransitions, bool fastForwardRun)
        {
            _EOModel = model;
            _IsFastForwardRun = fastForwardRun;

            string code = string.Empty;

            code += generateHeader();
            code += generateMembers();
            code += generateConstructor();

            if (includeEventTransitions)
                code += generateEventRoutineMethod();

            code += generateAbstractMethods();

            string[] tmp = code.Split(
                new string[] { _N },
                StringSplitOptions.None);
            _LineNumFunctions = tmp.Length;

            //code += generateDataMapperMethod();
            code += generateInitializeDataMappers();
            code += generateFunctions();

            code += _R;
            return code;
        }

        public string GenerateEventObjectSimulatorCode(string name, OOMMModel model, bool includeEventTransitions)
        {
            _Model = model;
            _EOModel = model.FindEventObjectModel(name);

            string code = string.Empty;

            code += generateHeader();
            code += generateMembers();
            code += generateConstructor();

            if (includeEventTransitions)
                code += generateEventRoutineMethod();

            code += generateAbstractMethods();
            //code += generateDataMapperMethod();
            code += generateInitializeDataMappers();
            code += generateFunctions();

            code += _R;
            return code;
        }

        private string generateHeader()
        {
            string rslt = "";

            List<string> usings = getUsings();
            foreach (string usingStatement in usings)
                rslt += usingStatement;
            //rslt += "using System;\r\n";
            //rslt += "using System.Collections.Generic;\r\n";
            //rslt += "using System.Text;\r\n";
            //rslt += "using DHKANG.OOEG.Simulation;\r\n";
            //rslt += "using DHKANG.OOEG.Simulation.Data;\r\n";
            rslt += "\r\n";

            string className = getCleanClassName(_EOModel.Name);
            rslt += @"public class " + className + "Simulator: EventObjectSimulator " + _L + _N;

            return rslt;
        }

        private List<string> getUsings()
        {
            List<string> rslt = new List<string>();

            rslt.Add("using System;\r\n");
            rslt.Add("using System.Data;\r\n");
            rslt.Add("using System.Collections.Generic;\r\n");
            rslt.Add("using System.Text;\r\n");
            rslt.Add("using DHKANG.Foundation.RandomVariate;\r\n");
            rslt.Add("using DHKANG.Foundation.DataCollection;\r\n");
            rslt.Add("using DHKANG.SEA.Simulation;\r\n");
            rslt.Add("using DHKANG.SEA.Simulation.Events;\r\n");
            rslt.Add("using DHKANG.SEA.Simulation.Data;\r\n");
            //rslt.Add("using DHKANG.Plugins.JobShop;\r\n");

            //foreach(string type in MainUI.App.PluginsSetting.PluginsNamespaces)
            //{
            //    rslt.Add(String.Format("using {0};\r\n", type));
            //}
            return rslt;
        }

        private string generateConstructor()
        {
            string rslt = "";
            string className = getCleanClassName(_EOModel.Name);
            rslt = getTab(1) + "public " + className + "Simulator(string name) : base(name) " + _L + _N;

            //Initialize State Variables
            foreach (OOEGStateVariable sv in _EOModel.StateVariables)
            {
                string svName = getCleanClassName(sv.Name);
                if (sv.Row == 1 && sv.Col == 1)
                {
                    if (sv.ValueType == OOMMStateVariableHelper.RANDOMVARIATE)
                    {
                        rslt += getTab(2) + string.Format("{0} = RandomVariateGenerator.GetRandomVariate(\"{1}\")" + _C + _N, svName, sv.InitialValue);
                    }
                    else if (sv.ValueType == OOMMStateVariableHelper.QUEUE)
                    {
                        rslt += getTab(2) + string.Format("{0} = new Queue<AbstractEntity>()" + _C + _N, svName);
                    }
                    else if (sv.ValueType == OOMMStateVariableHelper.ENTITYQUEUE)
                    {
                        rslt += getTab(2) + string.Format("{0} = new EntityQueue(this, \"{1}\")" + _C + _N, svName, sv.Name);
                        OOMMEntityQueue q = _EOModel.FindEntityQueue(svName);
                        if (q != null)
                        {
                            rslt += getTab(2) + string.Format("Dictionary<string, object> {0}_args = new Dictionary<string, object>()" + _C + _N, svName);
                            rslt += getTab(2) + string.Format("{0}_args[\"rule\"] = \"{1}\"" + _C + _N, svName, q.Rule.ToString());
                            rslt += getTab(2) + string.Format("{0}.Initialize({0}_args)" + _C + _N, svName);
                        }
                        rslt += getTab(2) + string.Format("this.SimulationEnded += {0}.OnSimulationEnded" + _C + _N, svName);
                    }
                    else if (sv.ValueType == "ParameterVariable")
                    {
                        rslt += getTab(2) + string.Format("{0} = new ParameterVariable(this, \"{1}\")" + _C + _N, svName, sv.Name);
                    }
                    else if (sv.ValueType == OOMMStateVariableHelper.RESOURCE)
                    {
                        rslt += getTab(2) + string.Format("{0} = new Resource(this, \"{1}\")" + _C + _N, svName, sv.Name);
                    }
                    else if (sv.ValueType == OOMMStateVariableHelper.STRING)
                    {
                        rslt += getTab(2) + string.Format("{0} = \"{1}\"" + _C + _N, svName, sv.InitialValue);
                    }
                    else if (sv.ValueType == OOMMStateVariableHelper.BOOL)
                    {
                        if (string.IsNullOrEmpty(sv.InitialValue) || sv.InitialValue.ToString().Equals("0"))
                            sv.InitialValue = "false";
                        rslt += getTab(2) + string.Format("{0} = bool.Parse(\"{1}\")" + _C + _N, svName, sv.InitialValue);
                    }
                    else if (sv.ValueType == OOMMStateVariableHelper.INT ||
                             sv.ValueType == OOMMStateVariableHelper.FLOAT ||
                             sv.ValueType == OOMMStateVariableHelper.DOUBLE)
                    {
                        if (string.IsNullOrEmpty(sv.InitialValue))
                        {
                            rslt += getTab(2) + string.Format("{0} = {1}" + _C + _N, svName, 0);
                        }
                        else
                        {
                            rslt += getTab(2) + string.Format("{0} = {1}" + _C + _N, svName, sv.InitialValue);
                        }
                    }
                    else
                    {
                        rslt += getTab(2) + string.Format("{0} = new {1}()" + _C + _N, svName, sv.ValueType);
                    }
                }
                else if (sv.Row == 1 && sv.Col > 1)
                {
                    if (sv.ValueType == OOMMStateVariableHelper.RANDOMVARIATE)
                    {
                        string[] cells = sv.InitialValue.Replace("{", "").Replace("}", "").Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                        rslt += getTab(2) + string.Format("{0} = new RandomVariate[{1}]" + _C + _N, svName, sv.Col);
                        for (int p = 0; p < sv.Col; p++)
                        {
                            rslt += getTab(2) + string.Format("{0}[{1}] = RandomVariateGenerator.GetRandomVariate(\"{2}\")" + _C + _N, svName, p, cells[p]);
                        }
                    }
                    else if (sv.ValueType == OOMMStateVariableHelper.STRING)
                    {
                        //string[] cells = sv.InitialValue.Replace("{", "").Replace("}", "").Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                        //추후 모든 element에 ""가 필요할 수 있음
                        rslt += getTab(2) + string.Format("{0} = new string[]{{1}}" + _C + _N, svName, sv.InitialValue);
                    }
                    else if (sv.ValueType == OOMMStateVariableHelper.ENTITYQUEUE)
                    {
                        rslt += getTab(2) + string.Format("{0} = new EntityQueue[{1}]" + _C + _N, svName, sv.Col);
                        for (int i = 0; i < sv.Col; i++)
                        {
                            rslt += getTab(2) + string.Format("{0}[{1}] = new EntityQueue(this, \"{2}\")" + _C + _N, svName, i, sv.Name + "_" + i);
                            rslt += getTab(2) + string.Format("this.SimulationEnded += {0}[{1}].OnSimulationEnded" + _C + _N, svName, i);
                        }
                    }
                    else if (sv.ValueType == OOMMStateVariableHelper.RESOURCE)
                    {
                        rslt += getTab(2) + string.Format("{0} = new Resource[{1}]" + _C + _N, svName, sv.Col);
                        for (int i = 0; i < sv.Col; i++)
                        {
                            rslt += getTab(2) + string.Format("{0}[{1}] = new Resource(this, \"{2}\")" + _C + _N, svName, i, sv.Name + "_" + i);
                        }
                    }
                    else
                    {
                        rslt += getTab(2) + string.Format("{0} = new {1}[]{2}" + _C + _N, svName, sv.ValueType, sv.InitialValue);
                    }
                }
                else
                {
                    if (sv.ValueType == OOMMStateVariableHelper.RANDOMVARIATE)
                    {
                        rslt += getTab(2) + string.Format("{0} = new RandomVariate[{1},{2}]" + _C + _N, svName, sv.Row, sv.Col);
                        string[] rows = sv.InitialValue.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                        //_Row; _Col;
                        for (int k = 0; k < rows.Length; k++)
                        {
                            if (k >= sv.Row)
                                break;

                            string row = rows[k].Replace("{", "").Replace("}", "");
                            string[] cells = row.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                            for (int p = 0; p < cells.Length; p++)
                            {
                                if (p < sv.Col)
                                {
                                    rslt += getTab(2) + string.Format("{0}[{1},{2}] = RandomVariateGenerator.GetRandomVariate(\"{3}\")" + _C + _N, svName, k, p, cells[p]);
                                }
                            }
                        }
                    }
                    else
                    {
                        string initialValue = sv.InitialValue.Replace(';', ',');
                        rslt += getTab(2) + string.Format("{0} = new {1}[{2},{3}]{{{4}}}" + _C + _N, svName, sv.ValueType, sv.Row, sv.Col, initialValue);
                    }
                }
            }

            foreach (OOMMSchedule s in _EOModel.Schedules)
            {
                string varName = getCleanClassName(s.Name);
                string valueType = "ScheduleValueType.Integer";
                if (s.Type == ScheduleType.Float)
                    valueType = "ScheduleValueType.Float";
                else if (s.Type == ScheduleType.Expression)
                    valueType = "ScheduleValueType.Expression";

                rslt += getTab(1) + string.Format("{0} = new ScheduleObject(\"{1}\", {2})" + _C + _N, varName, s.Name, valueType);
                //rslt += getTab(1) + string.Format("{0} = new ScheduleObject(\"{1}\", ScheduleValueType.Float)" + _C + _N, varName, s.Name);
                //rslt += getTab(1) + string.Format("{0} = new ScheduleObject(\"{1}\", ScheduleValueType.Expression)" + _C + _N, varName, s.Name);
                rslt += getTab(1) + string.Format("{0}.Simulator = this" + _C + _N, varName);

                foreach (OOMMScheduleValue sv in s.Values)
                {
                    int seconds = 0;
                    int intValue = 0;
                    if (int.TryParse(sv.Duration, out intValue))
                    {
                        if (s.TimeUnit == ScheduleTimeUnit.Minutes)
                            seconds = intValue * 60;
                        else if (s.TimeUnit == ScheduleTimeUnit.Hours)
                            seconds = intValue * 3600;
                        else if (s.TimeUnit == ScheduleTimeUnit.Days)
                            seconds = intValue * 86400;
                    }

                    rslt += getTab(1) + string.Format("{0}.Add({1}, \"{2}\")" + _C + _N, varName, seconds, sv.Value);
                }
            }

            rslt += getTab(1) + _R + _N; ;
            return rslt;
        }

        private string generateMembers()
        {
            string rslt = "";

            foreach (OOEGStateVariable sv in _EOModel.StateVariables)
            {
                string svName = getCleanClassName(sv.Name);
                if (sv.Row == 1 && sv.Col == 1)
                {
                    if (sv.ValueType.Equals(OOMMStateVariableHelper.QUEUE))
                        rslt += getTab(1) + string.Format("private {0} {1}" + _C + _N, "Queue<AbstractEntity>", svName);
                    else
                        rslt += getTab(1) + string.Format("private {0} {1}" + _C + _N, sv.ValueType, svName);
                }
                else if (sv.Row == 1 && sv.Col > 1)
                {
                    rslt += getTab(1) + string.Format("private {0}[] {1}" + _C + _N, sv.ValueType, svName);
                }
                else
                {
                    rslt += getTab(1) + string.Format("private {0}[,] {1}" + _C + _N, sv.ValueType, svName);
                }
            }

            foreach (OOMMDataAssociationEdge dae in _Model.DataAssociations)
            {
                if (!dae.TargetEventObject.Equals(_EOModel.ID))
                    continue;

                OOMMDataSource ds = _Model.FindDataSource(dae.SourceDataSource);
                string varName = getCleanClassName(ds.Name);
                if (ds.Type == OOMMDataSourceType.CSV)
                {
                    rslt += getTab(1) + string.Format("private {0} {1}" + _C + _N, "CSVDataSource", varName);
                }
                else if (ds.Type == OOMMDataSourceType.EXCEL)
                {
                    rslt += getTab(1) + string.Format("private {0} {1}" + _C + _N, "ExcelDataSource", varName);
                }
                else if (ds.Type == OOMMDataSourceType.DATABASE)
                {
                    rslt += getTab(1) + string.Format("private {0} {1}" + _C + _N, "DBDataSource", varName);
                }
            }

            foreach (OOMMSchedule s in _EOModel.Schedules)
            {
                string varName = getCleanClassName(s.Name);
                rslt += getTab(1) + string.Format("private {0} {1}" + _C + _N, "ScheduleObject", varName);
            }

            rslt += _N;

            return rslt;
        }

        private string generateAbstractMethods()
        {
            string rslt = "";

            //rslt += generateRunMethod();
            rslt += generateExecuteLocalEventMethod();
            rslt += generateInitializeMethod();
            //rslt += generateFireSchedulingArcMethod();
            rslt += generateGetStateVariableMethod();
            rslt += generateSetStateVariableMethod();

            return rslt;
        }

        private string generateRunMethod()
        {
            string rslt = "";

            rslt += getTab(1) + "public override void Run() ";
            rslt += getTab(1) + _L + _N;

            //schedule initial events
            for (int i = 0; i < _EOModel.EventTransitions.Count; i++)
            {
                OOEGEventTransition et = _EOModel.EventTransitions[i];
                if (et.InitialEvent)
                {
                    rslt += getTab(2) + "ScheduleLocalEvent(\"" + et.Event.Name + "\", 0)" + _C + _N;
                }
            }

            rslt += getTab(2) + "initializeDataMappers()" + _C + _N;

            rslt += getTab(1) + _R + _N;
            return rslt;
        }

        private string generateInitializeDataMappers()
        {
            string rslt = "";
            string rslt2 = "";

            rslt += getTab(1) + "private void initializeDataMappers() ";
            rslt += getTab(1) + _L + _N;

            //initialize data source and mappers
            OOMMObjectInteractionDiagram diagram = _Model.ObjectInteractionDiagram;
            foreach (OOMMDataAssociationEdge dae in diagram.DataAssociations)
            {
                OOMMObjectNode targetNode = null;
                targetNode = diagram.FindObjectNode(dae.TargetEventObject);

                if (targetNode == null || !targetNode.ModelID.Equals(_EOModel.ID))
                    continue;

                OOMMDataSource ds = _Model.FindDataSource(dae.SourceDataSource);
                string dsName = getCleanClassName(ds.Name);
                rslt += getTab(2) + "if (this.ID.Equals(\"" + targetNode.Name + "\"))" + _L + _N;
                rslt += getTab(3) + "DataSource " + dsName + " = DataSourceManager.Find(\"" + ds.Name + "\")" + _C + _N;
                rslt += getTab(3) + "if (" + dsName + " != null) " + _L + _N;
                foreach (OOMMDataMapper mapper in dae.DataMappers)
                {
                    string mapperName = getCleanClassName(mapper.Name);
                    rslt += getTab(4) + "initializeDataMapper_" + mapperName + "(" + dsName + ".Data)" + _C + _N;

                    rslt2 += getTab(1) + "private void initializeDataMapper_" + mapperName + "(DataTable " + dsName + ")" + _L + _N;
                    rslt2 += getTab(2) + mapper.Code + _N;
                    rslt2 += getTab(1) + _R + _N;
                    rslt2 += getTab(1) + _N;
                }
                rslt += getTab(3) + _R + _N;
                rslt += getTab(2) + _R + _N;
            }
            rslt += getTab(1) + _R + _N;

            rslt += getTab(1) + _N;

            rslt += rslt2;

            return rslt;
        }

        private string generateExecuteLocalEventMethod()
        {
            string rslt = "";
            rslt += getTab(1) + "public override void ExecuteLocalEvent(LocalEvent e, double now) " + _N;
            rslt += getTab(1) + _L + _N;

            if (_EOModel.EventTransitions.Count > 0)
            {
                rslt += getTab(2) + "if(e.ObjectName == this.ID)" + _N;
                rslt += getTab(2) + _L + _N;

                //rslt += getTab(3) + "RemoveLocalEvent(e)" + _C + _N;
                //rslt += getTab(3) + "_LEL.RetrieveEvent()" + _C + _N;

                //rslt += getTab(3) + "ArchiveLocalEvent(e)" + _C + _N;
                /*
                if (!_IsFastForwardRun)
                { 
                    rslt += getTab(3) + "ArchiveLocalEvent(e)" + _C + _N;
                }
                */
                rslt += getTab(3) + "_CurrentEvent = e" + _C + _N;
                rslt += getTab(3) + "switch(e.Name)" + _N;
                rslt += getTab(3) + _L + _N;

                foreach (OOEGEventTransition et in _EOModel.EventTransitions)
                {
                    if (string.IsNullOrEmpty(et.Event.Parameters))
                    {
                        rslt += getTab(4) + "case \"" + et.Event.Name + "\": " + _L + "EventRoutine_" + getCleanClassName(et.Event.Name) + "(e.Time)" + _C + "break" + _C + _R + _N;
                    }
                    else
                    {
                        string[] paramlist =
                            et.Event.Parameters.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                        string paramValues = string.Empty;

                        for (int i = 0; i < paramlist.Length; i++)
                        {
                            OOEGStateVariable sv = _EOModel.GetStateVariable(paramlist[i]);
                            if (sv == null)
                                continue;
                            paramValues += "(" + sv.ValueType + ")e.Parameters[" + i + "]";
                            //paramValues += "(" + sv.ValueType + ")e.Parameters[\"" + paramlist[i] + "\"]";
                            if (i < paramlist.Length - 1)
                                paramValues += ",";
                        }

                        rslt += getTab(4) + "case \"" + et.Event.Name + "\": " + _L + "EventRoutine_" + getCleanClassName(et.Event.Name) + "(e.Time, " + paramValues + ")" + _C + "break" + _C + _R + _N;
                    }
                }

                rslt += getTab(3) + _R + _N;

                rslt += getTab(2) + _R + _N;
            }

            rslt += getTab(1) + _R + _N;
            return rslt;
        }

        private string generateInitializeMethod()
        {
            string rslt = "";
            rslt += getTab(1) + "public override void Execute_Initializ_Routine(Dictionary<string, object> args) ";
            rslt += getTab(1) + _L + _N;

            //Initialize Last Value List () to set up the observers
            rslt += getTab(2) + "initializeLastValueList()" + _C + _N;
            rslt += getTab(2) + "initializeDataMappers()" + _C + _N;

            //schedule initial events
            for (int i = 0; i < _EOModel.EventTransitions.Count; i++)
            {
                OOEGEventTransition et = _EOModel.EventTransitions[i];
                if (et.InitialEvent || et.Event.Type == OOEGEventType.Initial)
                {
                    rslt += getTab(2) + "ScheduleLocalEvent(\"" + et.Event.Name + "\", 0)" + _C + _N;
                }
            }
            /*
            //Data Sources
            foreach (OOEGDataSource ds in _OOEGModel.DataSources)
            {
                string varName = getCleanClassName(ds.Name);

                if (ds.Type == OOEGDataSourceType.CSV)
                {
                    rslt += getTab(2) + string.Format("DataSourceManager.LoadCSV(\"{0}\", @\"{1}\")" + _C + _N, ds.Name, ds.FileName);
                    rslt += getTab(2) + string.Format("CSVDataSource {0} = (CSVDataSource)DataSourceManager.Find(\"{1}\")" + _C + _N, varName, ds.Name);
                }
                else if (ds.Type == OOEGDataSourceType.EXCEL)
                {
                    rslt += getTab(2) + string.Format("List<string> sheets_{0} = new List<string>()" + _C + _N, varName);

                    foreach(string sheetName in ds.Sheets)
                    {
                        rslt += getTab(2) + string.Format("sheets_{0}.Add(\"{1}\")" + _C + _N, varName, sheetName);

                    }
                    rslt += getTab(2) + string.Format("DataSourceManager.LoadExcel(\"{0}\", @\"{1}\", sheets_{2})" + _C + _N, ds.Name, ds.FileName, varName);
                    rslt += getTab(2) + string.Format("ExcelDataSource {0} = (ExcelDataSource)DataSourceManager.Find(\"{1}\")" + _C + _N, varName, ds.Name);
                }
                else if (ds.Type == OOEGDataSourceType.DATABASE)
                {
                    //TODO
                    //rslt += getTab(1) + string.Format("DBDataSource {0} = (DBDataSource)DataSourceManager.Find(\"{1}\")" + _C + _N, varName, ds.Name);
                }
            }

            //Data Mappers
            foreach (OOEGDataAssociationEdge dae in _OOEGModel.DataAssociations)
            {
                if (!dae.TargetEventObject.Equals(_EOModel.ID))
                    continue;

                OOEGDataSource ds = _OOEGModel.FindDataSource(dae.SourceDataSource);
                string varName = getCleanClassName(ds.Name);

                foreach (OOEGDataMapper mapper in dae.DataMappers)
                {
                    string mapperName = getCleanClassName(mapper.Name);
                    
                    rslt += getTab(2) + string.Format("initializeDataMapper{0}({1})" + _C + _N, mapperName, varName);
                }
            }
            */

            rslt += getTab(1) + _R + _N;

            return rslt;
        }

        private string generateFireSchedulingArcMethod()
        {
            string rslt = "";
            rslt += getTab(1) + "public override void FireSchedulingArc(ApplicationMessage msg) ";
            rslt += getTab(1) + _L + _N;

            rslt += getTab(1) + _R + _N;

            return rslt;
        }

        /*
        private string generateDataMapperMethod()
        {
            string rslt = "";

            foreach (OOEGDataAssociationEdge dae in _OOEGModel.DataAssociations)
            {
                if (!dae.TargetEventObject.Equals(_EOModel.ID))
                    continue;

                OOEGDataSource ds = _OOEGModel.FindDataSource(dae.SourceDataSource);
                string varName = getCleanClassName(ds.Name);                
                
                foreach(OOEGDataMapper mapper in dae.DataMappers)
                {
                    string mapperName = getCleanClassName(mapper.Name);
                    rslt += getTab(1) + string.Format("public void initializeDataMapper{0}(DataSource {1})" + _N, mapperName, varName);
                    rslt += getTab(1) + _L + _N;
                    rslt += getTab(1) + mapper.Code;
                    rslt += getTab(1) + _R + _N;
                    rslt += getTab(1) + _N;
                }
            }
            return rslt;
        }
        */

        private string generateFunctions()
        {
            string rslt = "";

            rslt += getTab(1) + "#region Functions" + _N;

            rslt += _EOModel.Functions;

            rslt += getTab(1) + "#endregion" + _N;

            return rslt;
        }

        private string generateGetStateVariableMethod()
        {
            string rslt = "";

            string svlist = string.Empty;
            rslt += getTab(1) + "public override object GetStateVariable(string name) ";
            rslt += getTab(1) + _L + _N;
            rslt += getTab(2) + "object rslt = null" + _C + _N;

            for (int i = 0; i < _EOModel.StateVariables.Count; i++)
            {
                OOEGStateVariable sv = _EOModel.StateVariables[i];

                if (sv.Col == 1 && sv.Row == 1)
                {
                    string svName = getCleanClassName(sv.Name);
                    if (i == 0)
                    {
                        rslt += getTab(2) + "if (name.Equals(\"" + sv.Name + "\"))" + _N;
                        rslt += getTab(3) + "rslt = " + svName + _C + _N;
                    }
                    else
                    {
                        rslt += getTab(2) + "else if (name.Equals(\"" + sv.Name + "\"))" + _N;
                        rslt += getTab(3) + "rslt = " + svName + _C + _N;
                    }

                    if (i < _EOModel.StateVariables.Count - 1)
                        svlist += string.Format("\"{0}\",", sv.Name);
                    else
                        svlist += string.Format("\"{0}\"", sv.Name);
                }
                else if (sv.Row == 1 && sv.Col > 1)
                {
                    string svName = getCleanClassName(sv.Name);
                    if (i == 0)
                    {
                        rslt += getTab(2) + "if (name.Equals(\"" + sv.Name + "\"))" + _N;
                        rslt += getTab(3) + "rslt = " + svName + _C + _N;
                    }
                    else
                    {
                        rslt += getTab(2) + "else if (name.Equals(\"" + sv.Name + "\"))" + _N;
                        rslt += getTab(3) + "rslt = " + svName + _C + _N;
                    }

                    svlist += string.Format("\"{0}\",", sv.Name);

                    for (int k = 0; k < sv.Col; k++)
                    {
                        rslt += getTab(2) + "else if (name.Equals(\"" + sv.Name + "[" + k + "]" + "\"))" + _N;
                        rslt += getTab(3) + "rslt = " + svName + "[" + k + "]" + _C + _N;

                        if (i == (_EOModel.StateVariables.Count - 1) && k == (sv.Col - 1))
                            svlist += string.Format("\"{0}\"", sv.Name + "[" + k + "]");
                        else
                            svlist += string.Format("\"{0}\",", sv.Name + "[" + k + "]");
                    }
                }
                else
                {
                    string svName = getCleanClassName(sv.Name);
                    if (i == 0)
                    {
                        rslt += getTab(2) + "if (name.Equals(\"" + sv.Name + "\"))" + _N;
                        rslt += getTab(3) + "rslt = " + svName + _C + _N;
                    }
                    else
                    {
                        rslt += getTab(2) + "else if (name.Equals(\"" + sv.Name + "\"))" + _N;
                        rslt += getTab(3) + "rslt = " + svName + _C + _N;
                    }

                    svlist += string.Format("\"{0}\",", sv.Name);

                    for (int p = 0; p < sv.Row; p++)
                    {
                        for (int k = 0; k < sv.Col; k++)
                        {
                            rslt += getTab(2) + "else if (name.Equals(\"" + sv.Name + "[" + p + "," + k + "]" + "\"))" + _N;
                            rslt += getTab(3) + "rslt = " + svName + "[" + p + "," + k + "]" + _C + _N;

                            if (i == (_EOModel.StateVariables.Count - 1) && p == (sv.Row - 1) && k == (sv.Col - 1))
                                svlist += string.Format("\"{0}\"", sv.Name + "[" + p + "," + k + "]");
                            else
                                svlist += string.Format("\"{0}\",", sv.Name + "[" + p + "," + k + "]");
                        }
                    }
                }

            }

            //foreach (OOMMPieChart pc in _Model.ObjectInteractionDiagram.PieCharts)
            //{
            //    foreach (OOMMSeries s in pc.Series.Values)
            //    {
            //        //string svName = getCleanAtomicModelName(pc.Title) + "_" + s.Name;
            //        string objectName = s.Value.Split(new char[] { '.' }, StringSplitOptions.RemoveEmptyEntries)[0];

            //        OOMMObjectNode node = _Model.ObjectInteractionDiagram.FindObjectNode(objectName);
            //        if (!node.ModelID.Equals(_EOModel.ID))
            //        {
            //            continue;
            //        }
            //        string svName = pc.Title + "_" + s.Name;
            //        string svValue = s.Value.Substring(s.Value.IndexOf('.') + 1);
            //        rslt += getTab(2) + "if (name.Equals(\"" + svName + "\"))" + _N;
            //        rslt += getTab(3) + "rslt = " + svValue + _C + _N;
            //    }
            //}

            rslt += getTab(2) + "return rslt" + _C + _N;
            rslt += getTab(1) + _R + _N;

            rslt += getTab(1) + "public override List<string> StateVariables " + _N;
            rslt += getTab(1) + _L + _N;
            rslt += getTab(2) + "get { return new List<string>(){" + svlist + "};} " + _N; ;
            rslt += getTab(1) + _R + _N;

            return rslt;
        }

        private string generateSetStateVariableMethod()
        {
            string rslt = "";

            string svlist = string.Empty;
            rslt += getTab(1) + "public override void SetStateVariable(string name, object value) ";
            rslt += getTab(1) + _L + _N;

            for (int i = 0; i < _EOModel.StateVariables.Count; i++)
            {
                OOEGStateVariable sv = _EOModel.StateVariables[i];
                string svName = getCleanClassName(sv.Name);
                if (i == 0)
                    rslt += getTab(2) + "if (name.Equals(\"" + sv.Name + "\"))" + _N;
                else
                    rslt += getTab(2) + "else if (name.Equals(\"" + sv.Name + "\"))" + _N;

                if (sv.Row == 1 && sv.Col == 1)
                {
                    rslt += getTab(3) + string.Format("{0} = ({1})value", svName, sv.ValueType) + _C + _N;
                }
                else if (sv.Row == 1 && sv.Col > 1)
                {
                    rslt += getTab(3) + string.Format("{0} = ({1})value", svName, sv.ValueType + "[]") + _C + _N;
                }
                else
                {
                    rslt += getTab(3) + string.Format("{0} = ({1})value", svName, sv.ValueType + "[,]") + _C + _N;
                }
            }

            rslt += getTab(1) + _R + _N;

            return rslt;
        }

        private string generateEventRoutineMethod()
        {
            string rslt = "";

            List<string> entities = new List<string>();
            foreach (OOMMEntity entity in _Model.Entities)
            {
                entities.Add(entity.Name);
            }

            Dictionary<string, OOEGEvent> events = new Dictionary<string, OOEGEvent>();

            foreach (OOEGEventTransition et in _EOModel.EventTransitions)
            {
                events.Add(et.Event.Name, et.Event);
            }

            foreach (OOEGEventTransition et in _EOModel.EventTransitions)
            {
                if (string.IsNullOrEmpty(et.Event.Parameters))
                    rslt += getTab(1) + string.Format("private void EventRoutine_{0}(double now)", getCleanClassName(et.Event.Name)) + _N;
                else
                {
                    string[] paramlist = et.Event.Parameters.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    string paramNames = string.Empty;
                    for (int i = 0; i < paramlist.Length; i++)
                    {
                        OOEGStateVariable sv = _EOModel.GetStateVariable(paramlist[i]);
                        if (sv == null)
                            continue;

                        paramNames += string.Format("{0} {1}", sv.ValueType, sv.Name);
                        if (i < paramlist.Length - 1)
                            paramNames += ",";
                    }
                    if (string.IsNullOrEmpty(paramNames))
                        rslt += getTab(1) + string.Format("private void EventRoutine_{0}(double now)" + _N, getCleanClassName(et.Event.Name));
                    else
                        rslt += getTab(1) + string.Format("private void EventRoutine_{0}(double now, {1})" + _N, getCleanClassName(et.Event.Name), paramNames);
                }
                rslt += getTab(1) + _L + _N;

                if (et.Event.Type == OOEGEventType.Mirror)
                {
                    int tabIndent = 2;
                    if (string.IsNullOrEmpty(et.Event.Parameters))
                        rslt += getTab(tabIndent) + string.Format("Send_MSR(\"{0}\")" + _C + _N, et.Event.Name);
                    else
                    {
                        //MessageData md = new MessageData("a");
                        //md[""] = ;

                        rslt += getTab(tabIndent) + string.Format("MessageData md = new MessageData(\"{0}\")" + _C + _N, et.Event.Name);

                        string[] paramlist = et.Event.Parameters.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                        for (int i = 0; i < paramlist.Length; i++)
                        {
                            rslt += getTab(tabIndent) + string.Format("md[\"{0}\"] = {1}" + _C + _N, paramlist[i], paramlist[i]);
                        }
                        rslt += getTab(tabIndent) + "Send_MSR(md)" + _C + _N;
                    }

                    rslt += getTab(1) + _R + _N;
                    rslt += getTab(1) + _N;

                    continue;

                }
                //Abstract Entity
                if (!string.IsNullOrEmpty(et.Event.Parameters))
                {
                    string[] paramlist = et.Event.Parameters.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    string paramNames = string.Empty;
                    List<string> entityList = new List<string>();
                    for (int i = 0; i < paramlist.Length; i++)
                    {
                        string paramName = paramlist[i];
                        OOEGStateVariable sv = _EOModel.GetStateVariable(paramName);
                        if (sv == null)
                            continue;

                        paramNames += sv.Name;
                        if (i < paramlist.Length - 1)
                            paramNames += ",";

                        if (entities.Contains(sv.ValueType))
                        {
                            entityList.Add(sv.Name);
                        }
                    }

                    foreach (string entityName in entityList)
                    {
                        rslt += getTab(2) + string.Format("{0}.Enter(this.ID,\"{1}\",now, {2})", entityName, et.Event.Name, paramNames) + _C + _N;
                    }
                }

                //State Change
                rslt += getTab(2) + "//state change: " + et.Event.Name + _N;
                rslt += getTab(2) + et.Action + ";";
                rslt += getTab(2) + _N;

                //Schedule Next Event
                int nextLocalEventNo = 1;
                foreach (OOEGEdgeTransition edge in et.Edges)
                {
                    if (string.IsNullOrEmpty(edge.NextEvent))
                        continue;

                    bool hasCondition = !edge.Condition.ToLower().Equals("true");

                    if (hasCondition)
                    {
                        rslt += getTab(2) + "//transition condition: " + et.Event.Name + ";" + edge.Condition + _N;
                        rslt += getTab(2) + "if (" + edge.Condition + ")" + _N;
                        rslt += getTab(2) + _L + _N;
                    }

                    int tabIndent = 2;
                    if (hasCondition)
                        tabIndent = 3;
                    if (edge.IsCancelingEdge)
                    {
                        rslt += getTab(tabIndent) + string.Format("CancelLocalEvent(\"{0}\")" + _C + _N, edge.NextEvent);
                    }
                    else
                    {
                        OOEGEvent nextEvent = events[edge.NextEvent];
                        if (nextEvent == null)
                            continue;

                        if (nextEvent.Type == OOEGEventType.Regular)
                        {
                            rslt += getTab(tabIndent) + "//delay: " + et.Event.Name + ";" + edge.Condition + _N;
                            if (string.IsNullOrEmpty(edge.Parameters))
                                rslt += getTab(tabIndent) + string.Format("ScheduleLocalEvent(\"{0}\", now + {1})" + _C + _N, edge.NextEvent, edge.Delay);
                            else
                            {
                                //rslt += getTab(3) + string.Format("ScheduleLocalEvent(\"{0}\", now + {1}, {2})" + _C + _N, edge.NextEvent, edge.Delay, edge.Parameters);
                                rslt += getTab(tabIndent) + string.Format("LocalEvent le{0} = new LocalEvent(this.ID, \"{1}\", now + {2})" + _C + _N, nextLocalEventNo, edge.NextEvent, edge.Delay);

                                string[] paramlist = edge.Parameters.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                                for (int i = 0; i < paramlist.Length; i++)
                                {
                                    rslt += getTab(tabIndent) + string.Format("le{0}.Parameters.Add({1})" + _C + _N, nextLocalEventNo, paramlist[i]);
                                }
                                rslt += getTab(tabIndent) + string.Format("ScheduleLocalEvent(le{0})", nextLocalEventNo) + _C + _N;

                                nextLocalEventNo++;
                            }
                        }
                        else if (nextEvent.Type == OOEGEventType.Mirror)
                        {
                            if (string.IsNullOrEmpty(edge.Delay) || edge.Delay.Equals("0"))
                            {
                                //대안 1: 바로 Send_MSR
                                if (string.IsNullOrEmpty(edge.Parameters))
                                    rslt += getTab(tabIndent) + string.Format("Send_MSR(\"{0}\")" + _C + _N, nextEvent.Name);
                                else
                                {
                                    //MessageData md = new MessageData("a");
                                    //md[""] = ;

                                    rslt += getTab(tabIndent) + string.Format("MessageData md = new MessageData(\"{0}\")" + _C + _N, nextEvent.Name);

                                    string[] paramlist = edge.Parameters.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                                    for (int i = 0; i < paramlist.Length; i++)
                                    {
                                        rslt += getTab(tabIndent) + string.Format("md[\"{0}\"] = {1}" + _C + _N, paramlist[i], paramlist[i]);
                                    }
                                    rslt += getTab(tabIndent) + "Send_MSR(md)" + _C + _N;
                                }
                            }
                            else
                            {
                                if (string.IsNullOrEmpty(edge.Parameters))
                                    rslt += getTab(tabIndent) + string.Format("ScheduleLocalEvent(\"{0}\", now + {1})" + _C + _N, edge.NextEvent, edge.Delay);
                                else
                                {
                                    //rslt += getTab(3) + string.Format("ScheduleLocalEvent(\"{0}\", now + {1}, {2})" + _C + _N, edge.NextEvent, edge.Delay, edge.Parameters);
                                    rslt += getTab(tabIndent) + string.Format("LocalEvent le{0} = new LocalEvent(this.ID, \"{1}\", now + {2})" + _C + _N, nextLocalEventNo, edge.NextEvent, edge.Delay);

                                    string[] paramlist = edge.Parameters.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                                    for (int i = 0; i < paramlist.Length; i++)
                                    {
                                        rslt += getTab(tabIndent) + string.Format("le{0}.Parameters.Add({1})" + _C + _N, nextLocalEventNo, paramlist[i]);
                                    }
                                    rslt += getTab(tabIndent) + string.Format("ScheduleLocalEvent(le{0})", nextLocalEventNo) + _C + _N;

                                    nextLocalEventNo++;
                                }
                            }
                            /*
                            //대안 2: MirrorEvent로 schedule -> 결국 Send_MSR로 변환됨
                            if (string.IsNullOrEmpty(edge.Parameters))
                                rslt += getTab(3) + string.Format("ScheduleMirrorEvent(\"{0}\", \"{1}\", now + {1})" + _C + _N, "", edge.NextEvent, edge.Delay);
                            else
                            {
                                rslt += getTab(3) + string.Format("LocalEvent le = new LocalEvent(\"\", \"{0}\", now + {1})" + _C + _N, edge.NextEvent, edge.Delay);

                                string[] paramlist = edge.Parameters.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                                for (int i = 0; i < paramlist.Length; i++)
                                {
                                    rslt += getTab(3) + string.Format("le.Parameters.Add({0})" + _C + _N, paramlist[i]);
                                }
                                rslt += getTab(3) + "ScheduleLocalEvent(le)" + _C + _N;
                            }
                            */
                        }
                    }

                    if (hasCondition)
                        rslt += getTab(2) + _R + _N;

                }
                /*
                List<OOEGEventObjectSchedulingEdge> outgoingEdges = _OOEGModel.FindOutgoingEdges(_EOModel.Name);
                foreach (OOEGEventObjectSchedulingEdge edge in outgoingEdges)
                {
                    if (!et.Event.Name.Equals(edge.MirrorEventName))
                        continue;

                    string boundaryEventObjectName = "";
                    foreach (OOEGEventObjectNode node in _OOEGModel.EventObjectNodes)
                    {
                        if (node.NodeID.Equals(edge.BoundaryEventObject))
                        {
                            boundaryEventObjectName = node.Name;
                        }
                    }
                    //string boundaryEventObjectName = _OOEGModel.FindEventObjectModel(edge.BoundaryEventObject).Name;
                    if (string.IsNullOrEmpty(edge.Parameters))
                        rslt += getTab(2) + string.Format("ScheduleMirrorEvent(\"{0}\", \"{1}\", now)", boundaryEventObjectName, edge.BoundaryEventName) + _C + _N;
                    else
                        rslt += getTab(2) + string.Format("ScheduleMirrorEvent(\"{0}\", \"{1}\", now, {2})", boundaryEventObjectName, edge.BoundaryEventName, edge.Parameters) + _C + _N;

                    //ScheduleMirrorEvent("Conveyor", "EOC", now, eqpid, cst);
                }
                */
                rslt += getTab(1) + _R + _N;
                rslt += getTab(1) + _N;
            }

            return rslt;
        }
        #endregion

        #region Entity methods
        public string GenerateEntityCodes(OOMMModel model)
        {
            string rslt = string.Empty;

            rslt += "using System;\r\n";
            rslt += "using System.Collections.Generic;\r\n";
            rslt += "using System.Text;\r\n";
            rslt += "using DHKANG.SEA.Simulation;\r\n";
            rslt += "using DHKANG.SEA.Simulation.Events;\r\n";
            rslt += "\r\n";

            foreach (OOMMEntity entity in model.Entities)
            {
                string className = getCleanClassName(entity.Name);
                rslt += @"public class " + className + ": AbstractEntity" + _L + _N;

                //Member Variables
                foreach (OOMMEntityAttribute attr in entity.Attributes)
                {
                    string varName = getCleanClassName(attr.Name);
                    rslt += getTab(1) + string.Format("public {0} {1}" + _C + _N, attr.Type, varName);
                }
                rslt += _N;

                //Constructors
                rslt += "\t" + "public " + className + "() : base(\"" + entity.Name + "\") " + _L + _R + _N;
                rslt += _N;

                //Abstract Methods
                rslt += getTab(1) + "public override object GetAttributeValue(string name) ";
                rslt += getTab(1) + _L + _N;
                rslt += getTab(2) + "object rslt = null" + _C + _N;

                string attrlist = string.Empty;
                for (int i = 0; i < entity.Attributes.Count; i++)
                {
                    OOMMEntityAttribute attr = entity.Attributes[i];
                    string varName = getCleanClassName(attr.Name);
                    if (i == 0)
                    {
                        rslt += getTab(2) + "if (name.Equals(\"" + attr.Name + "\"))" + _N;
                        rslt += getTab(3) + "rslt = " + varName + _C + _N;
                    }
                    else
                    {
                        rslt += getTab(2) + "else if (name.Equals(\"" + attr.Name + "\"))" + _N;
                        rslt += getTab(3) + "rslt = " + varName + _C + _N;
                    }

                    if (i < entity.Attributes.Count - 1)
                        attrlist += string.Format("\"{0}\",", attr.Name);
                    else
                        attrlist += string.Format("\"{0}\"", attr.Name);
                }

                rslt += getTab(2) + "return rslt" + _C + _N;
                rslt += getTab(1) + _R + _N;

                rslt += getTab(1) + "public override List<string> Attributes " + _N;
                rslt += getTab(1) + _L + _N;
                rslt += getTab(2) + "get { return new List<string>(){" + attrlist + "};} " + _N; ;
                rslt += getTab(1) + _R + _N;

                rslt += _R + _N;
            }

            return rslt;
        }

        public string GenerateEntityCode(OOMMEntity entity)
        {
            string rslt = string.Empty;

            rslt += "using System;\r\n";
            rslt += "using System.Collections.Generic;\r\n";
            rslt += "using System.Text;\r\n";
            rslt += "using DHKANG.SEA.Simulation;\r\n";
            rslt += "using DHKANG.SEA.Simulation.Events;\r\n";
            rslt += "\r\n";

            string className = getCleanClassName(entity.Name);
            rslt += @"public class " + className + ": AbstractEntity" + _L + _N;

            //Member Variables
            foreach (OOMMEntityAttribute attr in entity.Attributes)
            {
                string varName = getCleanClassName(attr.Name);
                rslt += getTab(1) + string.Format("public {0} {1}" + _C + _N, attr.Type, varName);
            }
            rslt += _N;

            //Constructors
            rslt += "\t" + "public " + className + "() : base(\"" + entity.Name + "\") " + _L + _R + _N;
            rslt += _N;

            //Abstract Methods
            rslt += getTab(1) + "public override object GetAttributeValue(string name) ";
            rslt += getTab(1) + _L + _N;
            rslt += getTab(2) + "object rslt = null" + _C + _N;

            string attrlist = string.Empty;
            for (int i = 0; i < entity.Attributes.Count; i++)
            {
                OOMMEntityAttribute attr = entity.Attributes[i];
                string varName = getCleanClassName(attr.Name);
                if (i == 0)
                {
                    rslt += getTab(2) + "if (name.Equals(\"" + attr.Name + "\"))" + _N;
                    rslt += getTab(3) + "rslt = " + varName + _C + _N;
                }
                else
                {
                    rslt += getTab(2) + "else if (name.Equals(\"" + attr.Name + "\"))" + _N;
                    rslt += getTab(3) + "rslt = " + varName + _C + _N;
                }

                if (i < entity.Attributes.Count - 1)
                    attrlist += string.Format("\"{0}\",", attr.Name);
                else
                    attrlist += string.Format("\"{0}\"", attr.Name);
            }

            rslt += getTab(2) + "return rslt" + _C + _N;
            rslt += getTab(1) + _R + _N;

            rslt += getTab(1) + "public override List<string> Attributes " + _N;
            rslt += getTab(1) + _L + _N;
            rslt += getTab(2) + "get { return new List<string>(){" + attrlist + "};} " + _N; ;
            rslt += getTab(1) + _R + _N;

            rslt += _R + _N;

            return rslt;
        }
        #endregion

        #region Utility Methods
        private string getCleanClassName(string name)
        {
            string cleanName = name.Replace(" ", "").Replace("(", "").Replace(")", "").Replace("-", "");
            return cleanName;
        }

        private string getTab(int count)
        {
            string tab = string.Empty;
            for (int i = 0; i < count; i++)
                tab += _T;
            return tab;
        }
        #endregion
    }
}
