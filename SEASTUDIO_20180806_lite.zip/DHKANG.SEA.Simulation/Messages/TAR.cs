﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public class TAR : Message
    {
        public double Time;
        public List<string> Inputs;

        public TAR(double time, List<string> inputs, AtomicObjectSimulator fsm)
            : base(fsm)
        {
            Time = time;
            Inputs = inputs;

            Type = InputType.TAR;
        }


        public override string ToString()
        {
            string rslt = "TAR: " + this.Time + ", " + this.Inputs + ", " + this.FSM.ID;
            return rslt;
        }
    }
}
