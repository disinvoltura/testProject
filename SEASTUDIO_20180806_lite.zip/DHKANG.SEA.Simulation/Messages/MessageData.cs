﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public class MessageData
    {
        #region Member Variables
        private string _Name;
        private Hashtable _Parameters;
        #endregion

        #region Properties
        public string MessageName
        {
            get { return _Name; }
            set { _Name = value; }
        }

        public int Count
        {
            get { return _Parameters.Count; }
        }

        public object this[string parameterName]
        {
            get
            {
                object rslt = null;
                if (_Parameters.ContainsKey(parameterName))
                    rslt = _Parameters[parameterName];

                return rslt;
            }
            set
            {
                if (_Parameters.ContainsKey(parameterName))
                    _Parameters[parameterName] = value;
                else
                    _Parameters.Add(parameterName, value);
            }
        }

        public ICollection Keys { get { return _Parameters.Keys; } }
        public ICollection Values { get { return _Parameters.Values; } }
        #endregion

        #region Constructors
        public MessageData(string name)
        {
            _Name = name;
            _Parameters = new Hashtable();
        }
        #endregion

        #region Methods
        public bool ContainsKey(string parameterName)
        {
            return _Parameters.ContainsKey(parameterName);
        }

        public MessageData Clone()
        {
            MessageData md = new MessageData(_Name);
            foreach (string key in _Parameters.Keys)
            {
                object value = _Parameters[key];
                md[key] = value;
            }

            return md;
        }

        public override string ToString()
        {
            string rslt = string.Empty;

            rslt += _Name;
            rslt += "(";

            int count = 0;
            foreach (string key in _Parameters.Keys)
            {
                object pValue = _Parameters[key];

                rslt += pValue.ToString();

                if (count < (_Parameters.Count - 1))
                    rslt += ",";

                count++;
            }
            rslt += ")";

            return rslt;
        }

        public string ToString(bool withKey)
        {
            string rslt = string.Empty;

            if (withKey)
            {
                rslt += _Name;
                rslt += "(";

                int count = 0;
                foreach (string key in _Parameters.Keys)
                {
                    object pValue = _Parameters[key];

                    rslt += key + ":" + pValue.ToString();

                    if (count < (_Parameters.Count - 1))
                        rslt += ",";

                    count++;
                }
                rslt += ")";

            }
            else
            {
                rslt = this.ToString();
            }
            return rslt;
        }
        #endregion

    }
}
