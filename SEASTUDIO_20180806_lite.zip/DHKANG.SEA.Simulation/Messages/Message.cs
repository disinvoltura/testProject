﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public enum KeyWords { OVER, STOP, NULL, SyncManager, Simulator };

    public delegate void LogHandler(string sender, string msg, double time);
    public delegate void MessageLogHandler(double time, string type, string amName, string msg, MessageData msgData);
    //public delegate void SimulationEndEventHandler();
    //public delegate void StateChangedEventHandler(SimStateChangedEvent evt);
    //public delegate void MessageDeliveryPacketArrivedEventHandler(SimMessageDeliveredEvent evt);
    //public delegate void MessageSendRequestedEventHandler(SimMessageRequestedEvent evt);

    public abstract class Message
    {
        public AtomicObjectSimulator FSM;
        public InputType Type;

        public Message(AtomicObjectSimulator fsm)
        {
            FSM = fsm;
        }
    }
}
