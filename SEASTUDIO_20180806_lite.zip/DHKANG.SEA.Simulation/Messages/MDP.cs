﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public class MDP : Message
    {
        public string Name;
        public double Now;
        public MessageData Data;
        public string FromFSM; //only for data-collection purpose;
        public double now { get { return this.Now; } }

        public MDP(string msg, double now, AtomicObjectSimulator fsm)
            : base(fsm)
        {
            this.Name = msg;
            this.Now = now;
            this.Data = new MessageData(msg);

            this.Type = InputType.MDP;
        }

        public MDP(MessageData msgData, double now, AtomicObjectSimulator fsm)
            : base(fsm)
        {
            this.Name = msgData.MessageName;
            this.Now = now;
            this.Data = msgData;

            this.Type = InputType.MDP;
        }

        public override string ToString()
        {
            string rslt = string.Empty;

            rslt = Data.ToString();

            return rslt;
        }

        public string ToString(bool withKey)
        {
            string rslt = string.Empty;

            rslt = Data.ToString(withKey);

            return rslt;
        }
    }
}
