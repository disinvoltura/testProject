﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public class MSR : Message
    {
        public string Msg;
        public int CurrentEventorStateId;
        public MessageData MsgData;

        public MSR(string msg, AtomicObjectSimulator fsm)
            : base(fsm)
        {
            this.Msg = msg;
            this.MsgData = new MessageData(msg);
            this.Type = InputType.MSR;
        }

        public MSR(MessageData msgData, AtomicObjectSimulator fsm)
            : base(fsm)
        {
            this.Msg = msgData.MessageName;
            this.MsgData = msgData;
            this.Type = InputType.MSR;
        }

        public override string ToString()
        {
            string rslt = string.Empty;

            rslt = MsgData.ToString();

            return rslt;
        }

        public string ToString(bool withKey)
        {
            string rslt = string.Empty;

            rslt = MsgData.ToString(withKey);

            return rslt;
        }
    }
}
