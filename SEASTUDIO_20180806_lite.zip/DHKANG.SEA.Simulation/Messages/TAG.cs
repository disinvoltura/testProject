﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public class TAG : Message
    {
        public double Now;
        public TAG(double now, AtomicObjectSimulator fsm)
            : base(fsm)
        {
            Now = now;

            Type = InputType.TAG;
        }

        public override string ToString()
        {
            String rslt = "TAG: " + this.Now + ", " + this.FSM.ID;
            return rslt;            
        }
    }
}
