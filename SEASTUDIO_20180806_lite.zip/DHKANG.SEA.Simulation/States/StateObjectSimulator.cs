﻿using DHKANG.SEA.Simulation.Observers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation.States
{
    public abstract class StateObjectSimulator : AtomicObjectSimulator
    {
        #region Memeber Variables
        public abstract string CurrentState { get; }

        protected SimState _CurrentState;
        private List<SimState> _StateTraces;
        private string _LastState;
        private double _LastStateEnteredTime;
        private StateTimeCollection _StateStayTimes;//cumulative staying time at each staet

        private Dictionary<string, StateObserver> _StateObservers;

        public event SimulationEndEventHandler SimulationEnded;
        #endregion

        #region Properties
        public StateTimeCollection States
        {
            get { return _StateStayTimes; }
        }

        public List<SimState> StateTraces
        {
            get { return _StateTraces; }
        }
        #endregion

        #region Constructors
        public StateObjectSimulator(string id) : base(id)
        {
            _StateObservers = new Dictionary<string, StateObserver>();

            _LastState = string.Empty;
            _LastStateEnteredTime = 0;
            _StateStayTimes = new StateTimeCollection();
            _StateTraces = new List<SimState>();
        }
        #endregion

        #region Data Collection Methods
        protected void EnterState(string stateName, double now)
        {
            if (_LastState != string.Empty)
            {
                double stayTime = now - _LastStateEnteredTime;
                if (stayTime > 0)
                {
                    if (_StateStayTimes.ContainsKey(_LastState))
                    {
                        _StateStayTimes[_LastState].StayTime = _StateStayTimes[_LastState].StayTime + stayTime;
                    }
                    else
                    {
                        _StateStayTimes.Add(_LastState, stayTime);
                    }
                }
            }
            _CurrentState = new SimState(stateName, now, this);
            _CurrentEventorStateId = _CurrentState.ID;
            if (_SM.Mode == SMMode.Scaled)
                _StateTraces.Add(_CurrentState);
            StateObjectStateChangedEvent e = new StateObjectStateChangedEvent(now, stateName, this);
            NotifyObservers(e);

            _LastState = stateName;
            _LastStateEnteredTime = now;
        }

        protected void OnEntryActionPerformed(double now, string stateName)
        {
            CheckStateVariableValueChanges(new StateObjectEntryActionPerformedEvent(now, stateName, this));
        }

        protected void OnInputActionPerformed(double time, string state, string input)
        {
            CheckStateVariableValueChanges(new StateObjectInputActionPerformedEvent(time, state, input, this));
        }

        protected void OnTransitionActionPerformed(double time, string fromState, string toState)
        {
            CheckStateVariableValueChanges(new StateObjectTransitionActionPerformedEvent(time, fromState, toState, this));
        }
        #endregion

        #region State Methods
        /// <summary>
        /// when the state object confronts with unhandled condition upon TAG or MDP, it will enter the state, dead. 
        /// </summary>
        /// <param name="now"></param>
        public void State_DEAD(double now)
        {
            EnterState("DEAD", now);

            _SM.Stop();
            //exception or event?
        }
        public virtual void State_STOP(double now)
        {
            EnterState("STOP", now);
            //if (Logged != null && Logged.GetInvocationList() != null)
            //    Logged(ID, KeyWords.STOP.ToString(), now);
        }

        public override void OnSimulationEnded(double now)
        {
            System.Diagnostics.Debug.WriteLine("State_STOP(" + now + ")");
            Debug("State_STOP(" + now + ")");

            double stayTime = now - _LastStateEnteredTime;
            _StateStayTimes[_LastState].StayTime = _StateStayTimes[_LastState].StayTime + stayTime;

            System.Diagnostics.Debug.WriteLine("state percentage: " + this.ID);
            Debug("state percentage: " + this.ID);
            foreach (string state in _StateStayTimes.Keys)
            {
                double totalStayTime = _StateStayTimes[state].StayTime;
                double percentage = totalStayTime / now * 100;

                System.Diagnostics.Debug.WriteLine(" - " + state + ":" + totalStayTime + ", " + percentage + " %");
            }

            if (this.SimulationEnded != null && this.SimulationEnded.GetInvocationList().Length > 0)
                this.SimulationEnded(now);
        }
        #endregion

        public void WriteLog(double time, string msg)
        {
            Debug("[" + time + "] " + msg);
            //if (Logged != null && Logged.GetInvocationList() != null)
            //    Logged(ID, msg, time);
        }

        public void WriteError(string msg, string function)
        {
            Error("[" + function + "] " + msg);
            //if (Logged != null && Logged.GetInvocationList() != null)
            //    Logged(ID, msg + " at " + function, _Clock);
        }

        #region Atomic Object Simulator Methods
        public override void Initialize(Dictionary<String, Object> args)
        {
        }
        #endregion

        #region Observer Methods
        public void NotifyStateObservers(StateObjectStateObservedEvent e)
        {
            foreach (StateObserver obs in _StateObservers.Values)
            {
                obs.Update(e);
            }
        }

        public void NotifyStateObservers(StateObjectStateChangedEvent e)
        {
            foreach (StateObserver obs in _StateObservers.Values)
            {
                obs.Update(e);
            }
        }

        public override SimObserver GetObserver(string name)
        {
            if (_StateObservers.ContainsKey(name))
                return _StateObservers[name];
            else
                return null;
        }

        public override void RegisterObserver(SimObserver obs)
        {
            if (obs is StateObserver)
                RegisterStateObserver((StateObserver)obs);
            else if (obs is StateVariableObserver)
                RegisterStateVariableObserver((StateVariableObserver)obs);
        }

        public void RegisterStateObserver(StateObserver obs)
        {
            if (_StateObservers == null)
                _StateObservers = new Dictionary<string, StateObserver>();

            _StateObservers.Add(obs.Name, obs);
        }

        public void RemoveStateObserver(StateObserver obs)
        {
            _StateObservers.Remove(obs.Name);
        }

        public override void NotifyObservers(ObservedEvent e)
        {
            if (e is StateVariableObservedEvent)
            {
                NotifyStateVariableObservers((StateVariableObservedEvent)e);
            }
            else if (e is StateObjectStateChangedEvent)
            {
                NotifyStateObservers((StateObjectStateChangedEvent)e);
            }
        }

        public override void RemoveObserver(SimObserver obs)
        {
            if (obs is StateObserver)
            {
                RemoveStateObserver((StateObserver)obs);
            }
            else if (obs is StateVariableObserver)
            {
                RemoveStateVariableObserver((StateVariableObserver)obs);
            }
        }

        #endregion
    }

    public class StateTimeCollection
    {
        private Dictionary<string, StateTime> _Times;

        public StateTimeCollection()
        {
            _Times = new Dictionary<string, StateTime>();
        }

        public bool ContainsKey(string key)
        {
            return _Times.ContainsKey(key);
        }

        public List<string> Keys
        {
            get { return _Times.Keys.ToList<string>(); }
        }

        public void Add(StateTime st)
        {
            _Times.Add(st.Name, st);
        }

        public void Add(string name, double time)
        {
            _Times.Add(name, new StateTime(name, time));
        }
        public StateTime this[string name]
        {
            get
            {
                StateTime rslt = null;
                if (_Times.ContainsKey(name))
                    rslt = _Times[name];
                else
                {
                    rslt = new StateTime(name);
                }

                return rslt;
            }
            set
            {
                if (_Times.ContainsKey(name))
                    _Times[name] = value;
                else
                {
                    _Times.Add(name, value);
                }
            }
        }
    }

    public class StateTime
    {
        private string _Name;
        private double _StayTime;

        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        public double StayTime
        {
            get { return _StayTime; }
            set { _StayTime = value; }
        }

        public double Time
        {
            get { return _StayTime; }
            set { _StayTime = value; }
        }


        public StateTime(string name)
        {
            _Name = name;
            _StayTime = 0;
        }

        public StateTime(string name, double statyTime)
            : this(name)
        {
            _StayTime = statyTime;
        }
    }

}
