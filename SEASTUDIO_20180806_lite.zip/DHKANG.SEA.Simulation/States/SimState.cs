﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation.States
{
    public class SimState : SimObject
    {
        private double _Time;//Entered Time

        public double Time { get { return _Time; } }

        public SimState(string name, double time) : base(name)
        {
            _Time = time;
        }

        public SimState(string name, double time, AtomicObjectSimulator aos) : base(aos, name)
        {
            _Time = time;
        }
        
    }
}
