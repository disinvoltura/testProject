﻿using DHKANG.SEA.Simulation.Observers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public class SimExperiment
    {
        #region Static Variables
        private static int _ExpCount = 0;
        #endregion

        #region Member Variables
        private SimulationEngine _Simulator;
        private int _RandSeed;

        private string _Name;
        private DateTime _RunStartTime;
        private DateTime _RunFinishTime;
        private double _RunLength;

        private List<SimObserver> _Observers;
        //private List<SimExperimentParameter> _Parameters;
        #endregion

        #region Properties
        public SimulationEngine Simulator
        {
            get { return _Simulator; }
        }

        public string Name
        {
            get { return _Name; }
        }

        public DateTime RunStartTime
        {
            get { return _RunStartTime; }
            set { _RunStartTime = value; }
        }

        public DateTime RunFinishTime
        {
            get { return _RunFinishTime; }
            set { _RunFinishTime = value; }
        }

        public double RunLength
        {
            get { return _RunLength; }
            set { _RunLength = value; }
        }

        public int RandomSeed
        {
            get { return _RandSeed; }
            set { _RandSeed = value; }
        }
        #endregion

        #region Constructors
        public SimExperiment(
            SimulationEngine simulator,
            double runLength,
            int seed)
        {
            SimExperiment._ExpCount++;
            _Name = "Simulation Run #" + SimExperiment._ExpCount;

            _Simulator = simulator;
            _RunLength = runLength;
            _RandSeed = seed;
        }
        #endregion
    }
}
