﻿using DHKANG.Foundation.DataCollection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public class TimeQueueItem
    {
        private double _EnqueuedTime;
        private double _DequeuedTime;

        public double EnqueuedTime {   get { return _EnqueuedTime; } }
        public double DequeuedTime { get { return _DequeuedTime; } }
        public double ElapsedTime {  get { return _DequeuedTime - _EnqueuedTime; } }

        public TimeQueueItem(double enqueueTime, double dequeueTime)
        {
            _EnqueuedTime = enqueueTime;
            _DequeuedTime = dequeueTime;
        }
    }

    public class TimeQueue
    {
        #region Member Variables
        private string _Name;
        private List<TimeQueueItem> _TimeDelays;
        private AtomicObjectSimulator _AtomicSimulator;
        private double _Tau;

        /// <summary>
        /// the number of arrived entities
        /// </summary>
        private int _NoIn;
        /// <summary>
        /// the number of departed entities
        /// </summary>
        private int _NoOut;

        /// <summary>
        /// Statistics for Queue Length
        /// </summary>
        private TimeDependentStatistics _QLStat;
        /// <summary>
        /// Statistics for Waiting Time
        /// </summary>
        private SampleStatistics _WTStat;
        #endregion

        #region Properties
        public string Name { get { return _Name; } }
        public int Count { get { return _TimeDelays.Count; } }
        public List<TimeQueueItem> Values { get { return _TimeDelays; } }
        public double Tau
        {
            get { return _Tau; }
            set { _Tau = value; }
        }
        public int NoIn {  get { return _NoIn; } }
        public int NoOut { get { return _NoOut; } }
        public TimeDependentStatistics QueueLength { get { return _QLStat; } }
        public SampleStatistics WaitingTime { get { return _WTStat; } }

        #endregion

        #region Constructors
        public TimeQueue()
        {
            _TimeDelays = new List<TimeQueueItem>();
            _WTStat = new SampleStatistics("");
            _QLStat = new TimeDependentStatistics("");
        }

        public TimeQueue(string name, double tau) : this()
        {
            _Name = name;
            _Tau = tau;
        }

        public TimeQueue(double tau): this()
        {
            _Tau = tau;
        }

        public TimeQueue(AtomicObjectSimulator at) : this()
        {
            _AtomicSimulator = at;
        }

        public TimeQueue(AtomicObjectSimulator at, string name) : this(at)
        {
            _Name = name;
            _QLStat = new TimeDependentStatistics(_Name);
            _WTStat = new SampleStatistics(_Name);
        }

        public TimeQueue(AtomicObjectSimulator at, double tau): this(at)
        {
            _Tau = tau;
        }

        public TimeQueue(AtomicObjectSimulator at, string name, double tau): this()
        {
            _AtomicSimulator = at;
            _Name = name;
            _Tau = tau;
            _QLStat = new TimeDependentStatistics(_Name);
            _WTStat = new SampleStatistics(_Name);
        }

        #endregion

        #region Operator Overloading
        public static TimeQueue operator +(TimeQueue x, double tc)
        {
            x.AddNewConveyTime(tc);
            return x;
        }

        public static TimeQueue operator --(TimeQueue x)
        {
            x.RemoveAt(0);
            return x;
        }

        public static bool operator <(TimeQueue x, int value)
        {
            return x.Count < value;
        }

        public static bool operator >(TimeQueue x, int value)
        {
            return x.Count > value;
        }

        public static bool operator >(int value, TimeQueue x)
        {
            return x.Count < value;
        }

        public static bool operator <(int value, TimeQueue x)
        {
            return x.Count > value;
        }

        public static bool operator ==(TimeQueue x, int value)
        {
            return x.Count == value;
        }

        public static bool operator ==(int value, TimeQueue x)
        {
            return x.Count == value;
        }

        public static bool operator !=(TimeQueue x, int value)
        {
            return x.Count != value;
        }

        public static bool operator !=(int value, TimeQueue x)
        {
            return x.Count != value;
        }

        public static bool operator >=(TimeQueue x, int value)
        {
            return x.Count >= value;
        }

        public static bool operator >=(int value, TimeQueue x)
        {
            return x.Count <= value;
        }

        public static bool operator <=(TimeQueue x, int value)
        {
            return x.Count <= value;
        }

        public static bool operator <=(int value, TimeQueue x)
        {
            return x.Count >= value;
        }

        #endregion

        #region Methods
        public double NextTime { get { return getNextTime(); } }

        public double mu { get { return getNextTime(); } }

        public double Mu { get { return getNextTime(); } }

        public double MU { get { return getNextTime(); } }

        private double getNextTime()
        {
            return (_TimeDelays.Count > 0) ? _TimeDelays[0].DequeuedTime : double.MaxValue;
        }

        public void AddNewConveyTime(double tc)
        {
            double value = this._AtomicSimulator.SM.Clock + tc;
            TimeQueueItem item = new TimeQueueItem(this._AtomicSimulator.SM.Clock, value);
            this.Add(item);

        }

        public void Add(TimeQueueItem value)
        {
            //insertion sorting
            bool isInserted = false;
            for(int i = 0; i < _TimeDelays.Count; i++)
            {
                if (value.DequeuedTime < _TimeDelays[i].DequeuedTime)
                {
                    _TimeDelays.Insert(i, value);
                    isInserted = true;
                    break;
                }
            }
            if (!isInserted)
                _TimeDelays.Add(value);

            _QLStat.Add(EntityManager.Clock, this.Count);
            _NoIn++;

        }

        public void RemoveAt(int index)
        {
            TimeQueueItem removedItem = null;
            if (_TimeDelays.Count > 0)
            {
                removedItem = _TimeDelays[index];
                _TimeDelays.RemoveAt(index);
            }
            else
            {
                System.Diagnostics.Trace.WriteLine("Illegal removal operation of TimeQueue at <" + _AtomicSimulator.ID + ">");
            }

            if (removedItem != null)
            {
                _QLStat.Add(EntityManager.Clock, this.Count);
                _NoOut++;

                if (removedItem.ElapsedTime > 0)
                    _WTStat.Add(EntityManager.Clock, removedItem.ElapsedTime);
            }
        }

        #endregion
    }
}