﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation.Dispatching
{
    public class FIFOJobSelection : JobSelectionRule
    {
        private Queue<AbstractEntity> _Queue;

        public override int Count { get { return _Queue.Count; } }
        public override List<AbstractEntity> Values
        {
            get { return _Queue.ToList<AbstractEntity>(); }
        }

        public FIFOJobSelection(AtomicObjectSimulator parent, string name, EntityQueue queue) : base(parent, name, queue)
        {
            _Queue = new Queue<AbstractEntity>();
        }

        public override void Enqueue(AbstractEntity value)
        {
            _Queue.Enqueue(value);
        }

        public override AbstractEntity Dequeue()
        {
            AbstractEntity rslt = null;
            try
            {
                rslt = _Queue.Dequeue();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("While running the simulation, it encountered an exception that cannot be handled: ");
                System.Diagnostics.Debug.WriteLine(ex.ToString());
            }
            return rslt;
        }
       
    }
}
