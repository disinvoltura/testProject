﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public abstract class JobSelectionRule : DispatchingRule
    {
        #region Member Variables
        private EntityQueue _Queue;
        #endregion

        #region Properties
        public abstract int Count { get; }
        public abstract List<AbstractEntity> Values { get; }
        #endregion

        public JobSelectionRule(AtomicObjectSimulator parent, string name, EntityQueue queue)
            : base(parent, name)
        {
            _Queue = queue;
        }

        public abstract void Enqueue(AbstractEntity value);
        public abstract AbstractEntity Dequeue();
    }
}
