﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public class ResourceSelectionRule : DispatchingRule
    {
        public ResourceSelectionRule(AtomicObjectSimulator parent, string name) : base(parent, name)
        {
        }
    }
}
