﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public abstract class DispatchingRule : SimObject
    {
        #region Member Variables
        protected Dictionary<string, object> _Parameters;
        #endregion

        #region Constructors
        public DispatchingRule(AtomicObjectSimulator parent, string name) 
            : base(parent, name)
        {
            _Parameters = new Dictionary<string, object>();
        }
        #endregion

        #region Methods
        public void Initialize(Dictionary<string, object> args)
        {
            foreach (string key in args.Keys)
            {
                _Parameters.Add(key, args[key]);
            }
        }

        public object getParameter(string name)
        {
            object rslt = null;
            if (_Parameters.ContainsKey(name))
                rslt = _Parameters[name];
            return rslt;
        }
        #endregion

        #region Abstract Methods

        #endregion


    }
}
