﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation.Dispatching
{
    public class LIFOJobSelection : JobSelectionRule
    {
        private List<AbstractEntity> _Queue;

        public override int Count { get { return _Queue.Count; } }
        public override List<AbstractEntity> Values
        {
            get { return _Queue; }
        }

        public LIFOJobSelection(AtomicObjectSimulator parent, string name, EntityQueue queue) : base(parent, name, queue)
        {
            _Queue = new List<AbstractEntity>();
        }

        public override void Enqueue(AbstractEntity value)
        {
            _Queue.Add(value);
        }

        public override AbstractEntity Dequeue()
        {
            AbstractEntity rslt = null;
            try
            {
                if (_Queue.Count > 0)
                {
                    int lastPos = _Queue.Count - 1;
                    rslt = _Queue[lastPos];
                    _Queue.RemoveAt(lastPos);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("While running the simulation, it encountered an exception that cannot be handled: ");
                System.Diagnostics.Debug.WriteLine(ex.ToString());
            }
            return rslt;
        }
       
    }
}
