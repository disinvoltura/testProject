﻿using DHKANG.SEA.Simulation.Activities;
using DHKANG.SEA.Simulation.Events;
using DHKANG.SEA.Simulation.States;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public enum EngineState { Initialized, Running, Paused, Stopped };

    public class SimulationEngine
    {
        #region Member Variables
        private Dictionary<string, AtomicObjectSimulator> _AtomicSimulators;
        private List<ObjectCoupling> _CouplingList;
        private SynchronizationManager _SM;
        private double _ScaleFactor;
        private double _EOSTime;

        private Dictionary<string, object> _Args;
        private EngineState _State;
        private ISimulationView _View;
        #endregion

        #region Events
        public event SimulationEndEventHandler SimulationEnded;
        public event SimulationClockAdvancedEventHandler ClockAdvanced;
        //public event SimulationClockAdvancingEventHandler ClockAdvancing;
        #endregion

        #region Properties
        public double Clock {  get { double rslt = -1; if (_SM != null) rslt = _SM.Clock; return rslt; } }
        public ISimulationView View { get { return _View; } set { _View = value; } }
        public EngineState State { get { return _State; } }
        public List<MessageTrace> MessageTraces {  get { return _SM.MessageTraces; } }
        public AtomicObjectSimulator this[string id]
        {
            get
            {
                AtomicObjectSimulator rslt = null;
                if (_AtomicSimulators.ContainsKey(id))
                    rslt = _AtomicSimulators[id];

                return rslt;
            }
        }

        public List<AtomicObjectSimulator> Objects
        {
            get {
                return _AtomicSimulators.Values.ToList<AtomicObjectSimulator>();
            }
        }

        public double ScaleFactor
        {
            set
            {
                _ScaleFactor = value;

                if (_SM != null)
                    _SM.ScaleFactor = value;
            }
            get { return _ScaleFactor; }
        }
        #endregion

        #region Constructors
        public SimulationEngine()
        {
            _AtomicSimulators = new Dictionary<string, AtomicObjectSimulator>();
            _CouplingList = new List<Simulation.SimulationEngine.ObjectCoupling>();
        }
        #endregion

        #region Methods
        public void Initialize(Dictionary<string, object> args)
        {
            _Args = args;
            _State = EngineState.Initialized;

            /*
            foreach (string id in _AtomicSimulators.Keys)
            {
                AtomicObjectSimulator aos = _AtomicSimulators[id];
                aos.Initialize(args);
            }
            */
        }

        public void Abort()
        {
            _State = EngineState.Stopped;
            _SM.Stop();
        }

        public void Pause()
        {
            _State = EngineState.Paused;
            _SM.Pause();
        }

        public void Resume()
        {
            _State = EngineState.Running;
            _SM.Resume();
        }

        public void Add(AtomicObjectSimulator ats)
        {
            _AtomicSimulators.Add(ats.ID, ats);
        }

        public void AddObjectSchedulingRelation(string from, string triggerName, string to, string catchName)
        {
            _CouplingList.Add(new ObjectCoupling(from, triggerName, to, catchName)); 
        }

        public void AddObjectSchedulingRelation(string from, string triggerName, string parameters, string to, string catchName)
        {
            _CouplingList.Add(new ObjectCoupling(from, triggerName, parameters, to, catchName));
        }

        public void Start(double eosTime)
        {
            _EOSTime = eosTime;

            if (_ScaleFactor > 0)
                _SM = new SynchronizationManager(_AtomicSimulators.Count, _ScaleFactor);
            else
                _SM = new SynchronizationManager(_AtomicSimulators.Count);

            //add message coupling
            foreach (ObjectCoupling cc in _CouplingList)
                _SM.AddCoupling(cc.FromID, cc.TriggerName, cc.Parameters, cc.ToID, cc.CatchName);

            //start sm
            //_SM.ClockAdvancing += OnClockAdvancing;
            _SM.ClockAdvanced += OnClockAdvanced;
            _SM.SimulationEnded += OnSimulationEnded;
            _SM.ScaleFactor = _ScaleFactor;
            _SM.Start(_EOSTime);

            //start atomic simulaltors
            startAtomicObjectSimulators();

            _State = EngineState.Running;
        }


        public void Start(double eosTime, ISimulationView view)
        {
            _View = view;
            _EOSTime = eosTime;

            if (_ScaleFactor > 0)
                _SM = new SynchronizationManager(_AtomicSimulators.Count, _ScaleFactor, view);
            else
                _SM = new SynchronizationManager(_AtomicSimulators.Count);

            //add message coupling
            foreach (ObjectCoupling cc in _CouplingList)
                _SM.AddCoupling(cc.FromID, cc.TriggerName, cc.Parameters, cc.ToID, cc.CatchName);

            //start sm
            //_SM.ClockAdvancing += OnClockAdvancing;
            _SM.ClockAdvanced += OnClockAdvanced;
            _SM.SimulationEnded += OnSimulationEnded;
            _SM.ScaleFactor = _ScaleFactor;
            _SM.Start(_EOSTime);

            //start atomic simulaltors
            startAtomicObjectSimulators();

            _State = EngineState.Running;
        }

        public void Start(double eosTime, bool parallelRun)
        {
            _EOSTime = eosTime;

            _SM = new SynchronizationManager(_AtomicSimulators.Count, parallelRun);

            //add message coupling
            foreach (ObjectCoupling cc in _CouplingList)
                _SM.AddCoupling(cc.FromID, cc.TriggerName, cc.Parameters, cc.ToID, cc.CatchName);

            //start sm
            //_SM.ClockAdvancing += OnClockAdvancing;
            _SM.ClockAdvanced += OnClockAdvanced;
            _SM.SimulationEnded += OnSimulationEnded;
            _SM.ScaleFactor = _ScaleFactor;
            _SM.Start(_EOSTime);

            //start atomic simulaltors
            startAtomicObjectSimulators();

            _State = EngineState.Running;
        }

        private void startAtomicObjectSimulators()
        {
            foreach (AtomicObjectSimulator ats in _AtomicSimulators.Values)
            {
                if (ats is EventObjectSimulator)
                {
                    ats.SM = _SM;
                    ats.Initialize(_Args);
                    ats.Start();
                }
            }
            foreach (AtomicObjectSimulator ats in _AtomicSimulators.Values)
            {
                if (ats is StateObjectSimulator)
                {
                    ats.SM = _SM;
                    ats.Initialize(_Args);
                    ats.Start();
                }
                else if (ats is ActivityObjectSimulator)
                {
                    ats.SM = _SM;
                    ats.Initialize(_Args);
                    ats.Start();
                }
            }
        }
        /*
        private void OnClockAdvancing(double clock)
        {
            if (this.ClockAdvancing != null && this.ClockAdvancing.GetInvocationList().Length > 0)
                this.ClockAdvancing(clock);
        }
        */

        private void OnClockAdvanced(double clock)
        {
            if (this.ClockAdvanced != null && this.ClockAdvanced.GetInvocationList().Length > 0)
                this.ClockAdvanced(clock);
        }

        private void OnSimulationEnded(double now)
        {
            _State = EngineState.Stopped;
            System.Diagnostics.Debug.WriteLine("Simulation Ended.");

            if (this.SimulationEnded != null && this.SimulationEnded.GetInvocationList().Length > 0)
            {
                this.SimulationEnded(now);
            }
        }
        #endregion

        private class ObjectCoupling
        {
            public string FromID;
            public string TriggerName;
            public string ToID;
            public string CatchName;
            public string Parameters;//e.g. {P1:P1}, {P2:P3},... used for mapping parameters from source to dest
               
            public ObjectCoupling(string from, string triggerName, string to, string catchName)
            {
                this.FromID = from;
                this.TriggerName = triggerName;
                this.ToID = to;
                this.CatchName = catchName;
            }

            public ObjectCoupling(string from, string triggerName, string parameters, string to, string catchName)
            {
                this.FromID = from;
                this.TriggerName = triggerName;
                this.ToID = to;
                this.CatchName = catchName;
            }
        }
    }
}
