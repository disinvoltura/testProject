﻿using DHKANG.SEA.Simulation;
using DHKANG.SEA.Simulation.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public enum EntityStatus { Active, Disposed }
    public abstract class AbstractEntity : SimObject
    {
        #region Member Variables
        private int _EntityID;
        private string _Type = "Entity";
        private double _CreatedTime;
        private double _DisposedTime;


        private List<EntityTrace> _EventTraces;
        private EntityTrace _LastEventTrace;
        private EntityStatus _Status;

        private static int NextID = 1;
        #endregion

        #region Member Variables for Queues
        private double _QueueEnterTime;
        private EntityQueue _Queue; //current queue 
        #endregion

        #region Properties
        public int EntityID { get { return _EntityID; } }
        public string Type { get { return _Type; } }
        public string Value { get { return ""; } }
        public EntityStatus Status { get { return _Status; } }
        public List<EntityTrace> EventTraces { get { return _EventTraces; } }
        public EntityTrace LastEventTrace { get { return _LastEventTrace; } }
        public object this[string name] { get { return GetAttributeValue(name); } }
        public double CreatedTime { get { return _CreatedTime; } }
        public double DisposedTime { get { return _DisposedTime; } }

        public double ElapsedTime
        {
            get
            {
                double elapsedTime = 0;

                if (_QueueEnterTime < 0)
                    elapsedTime = 0;
                else if (EntityManager.Clock >= _QueueEnterTime)
                    elapsedTime = EntityManager.Clock - _QueueEnterTime;

                return elapsedTime;
            }
        }

        public override string ToString()
        {
            string rslt = _Name + ": ";

            for (int i = 0; i < Attributes.Count; i++)
            {
                string attrName = Attributes[i];
                rslt += "{" + attrName + ", " + GetAttributeValue(attrName) + "}";

                if (i < (Attributes.Count - 1))
                {
                    rslt += ";";
                }
            }

            return rslt;
        }

        public List<EntityAttribute> EntityAttributes
        {
            get
            {
                List<EntityAttribute> attrlist = new List<EntityAttribute>();
                int attrID = 1;
                List<string> names = this.Attributes;
                foreach (string name in names)
                {
                    attrlist.Add(new EntityAttribute(attrID, name, GetAttributeValue(name)));
                }

                return attrlist;
            }
        }
        #endregion

        #region Constructors
        public AbstractEntity() :
            base()
        {
            _EntityID = AbstractEntity.NextID++;
            _Name = "Entity " + _EntityID;
            _Status = EntityStatus.Active;
            _CreatedTime = EntityManager.Clock;
            _EventTraces = new List<EntityTrace>();

            EntityManager.Add(this);
        }

        public AbstractEntity(string type) : base()
        {
            _Type = type;

            _EntityID = AbstractEntity.NextID++;
            _Name = _Type + " " + _EntityID;
            _Status = EntityStatus.Active;
            _CreatedTime = EntityManager.Clock;
            _EventTraces = new List<EntityTrace>();

            EntityManager.Add(this);
        }

        #endregion

        #region Abstract Methods
        /// <summary>
        /// all the names of the attributes that the entity has
        /// </summary>
        public abstract List<string> Attributes { get; }
        /// <summary>
        /// return the value of the attribute whose name is equal to <para>name</para>.
        /// </summary>
        /// <param name="name">Atrribute Name</param>
        /// <returns>Attribute Value</returns>
        public abstract object GetAttributeValue(string name);
        #endregion

        #region Methods for Event Tracing
        public void Enter(LocalEvent e)
        {
            EntityTrace trace = null;
            if (e.Parameters.Count > 0)
            {
                string parameters = string.Empty;
                for (int i = 0; i < e.Parameters.Count; i++)
                {
                    object pm = e.Parameters[i];
                    parameters += pm.ToString();
                    if (i < e.Parameters.Count - 1)
                        parameters += ", ";
                }
                trace = new EntityTrace(EntityTraceType.Enter, e.ObjectName, e.Name, e.Time, parameters);
            }
            else
            {
                trace = new EntityTrace(EntityTraceType.Enter, e.ObjectName, e.Name, e.Time);
            }

            if (trace != null)
                _EventTraces.Add(trace);
        }

        public void Enter(string objectName, string operationName, double time)
        {
            EntityTrace trace = null;
            trace = new EntityTrace(EntityTraceType.Enter, objectName, operationName, time);
            _EventTraces.Add(trace);

            _LastEventTrace = trace;

        }

        public void Leave(LocalEvent e)
        {
            EntityTrace trace = new EntityTrace(EntityTraceType.Leave, e.ObjectName, e.Name, e.Time);
            _EventTraces.Add(trace);
        }

        public void Leave(string objectName, string operationName, double time)
        {
            EntityTrace trace = null;
            trace = new EntityTrace(EntityTraceType.Leave, objectName, operationName, time);
            _EventTraces.Add(trace);
            _LastEventTrace = trace;

        }
        #endregion

        #region Methods for Queues
        public void Enqueue(EntityQueue queue)
        {
            _QueueEnterTime = EntityManager.Clock;
            _Queue = queue;
        }

        public void Dequeue(EntityQueue queue)
        {
            //_QueueEnterTime = -1;
            _Queue = null;
        }
        #endregion

        #region Methods
        public void Dispose()
        {
            _Status = EntityStatus.Disposed;
            _DisposedTime = EntityManager.Clock;

            string objectName = "";
            string opName = "";
            if (_LastEventTrace != null)
            {
                objectName = _LastEventTrace.ObjectName;
                opName = _LastEventTrace.OperationName;
            }
            EntityTrace trace = new EntityTrace(EntityTraceType.Dispose, objectName, opName, _DisposedTime);
            _EventTraces.Add(trace);
            _LastEventTrace = trace;

            EntityManager.Dispose(this);
        }

        //public void Enter(string objectName, string eventName, double time)
        //{

        //    EntityTrace m = new EntityTrace(EntityTraceType.Enter, objectName, eventName, time);
        //    _EventTraces.Add(m);

        //    _LastEventTrace = m;
        //}

        public void Enter(string objectName, string eventName, double time, params object[] parameters)
        {
            EntityTrace trace = null;
            if (parameters != null && parameters.Length > 0)
            {
                string strParameters = string.Empty;
                for (int i = 0; i < parameters.Length; i++)
                {
                    object pm = parameters[i];
                    strParameters += pm.ToString();
                    if (i < parameters.Length - 1)
                        strParameters += ", ";
                }
                trace = new EntityTrace(EntityTraceType.Enter, objectName, eventName, time, strParameters);
            }
            else
            {
                trace = new EntityTrace(EntityTraceType.Enter, objectName, eventName, time);
            }

//            EntityEventTrace m = new EntityEventTrace(EntityEventTraceType.Enter, objectName, eventName, time);
            _EventTraces.Add(trace);

            _LastEventTrace = trace;
        }

        //public void Leave(string objectName, string eventName, double time)
        //{

        //    EntityTrace m = new EntityTrace(EntityTraceType.Leave, objectName, eventName, time);
        //    _EventTraces.Add(m);

        //    _LastEventTrace = m;
        //}
        #endregion
    }

    public class EntityAttribute
    {
        private int _ID;
        private string _Name;
        private object _Value;

        public EntityAttribute(int id, string name, object value)
        {
            _ID = id;
            _Name = name;
            _Value = value;
        }

        public string ID { get { return ""; } }
        //public int ID { get { return _ID; } }

        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        public object Value
        {
            get { return _Value; }
            set { _Value = value; }
        }

        public string Type { get { return ""; } }
        public string CreatedTime { get { return ""; } }
        public string DisposedTime { get { return ""; } }
        public string Status { get { return ""; } }
    }

    public enum EntityTraceType { Create, Enter, Leave, Dispose};

    public class EntityTrace
    {
        #region Member Variables
        private string _ObjectName;
        private string _OperationName; //event/state/activity/queue
        private double _Time;
        private string _Parameters = string.Empty;
        private EntityTraceType _Type = EntityTraceType.Enter;
        #endregion

        #region Properties
        public EntityTraceType Type { get { return _Type; } }
        public string ObjectName { get { return _ObjectName; } }
        public string OperationName { get { return _OperationName; } }
        public double Time { get { return _Time; } }
        public string Parameters { get { return _Parameters; } }
        #endregion

        #region Constructors
        public EntityTrace(EntityTraceType type, string objectName, string operationName, double time)
        {
            _ObjectName = objectName;
            _OperationName = operationName;
            _Time = time;
            _Type = type;
        }

        public EntityTrace(EntityTraceType type, string objectName, string operationName, double time, string parameters)
        {
            _ObjectName = objectName;
            _OperationName = operationName;
            _Time = time;
            _Type = type;
            _Parameters = parameters;
        }

        #endregion

        #region Methods
        public override int GetHashCode()
        {
            string obj = _ObjectName + "." + _OperationName + "@" + _Time + ":" + _Type;
            return obj.GetHashCode();
        }
        public override string ToString()
        {
            string obj = _ObjectName + "." + _OperationName + "@" + _Time + ":" + _Type;
            return obj;
        }
        public override bool Equals(object obj)
        {
            return this.ToString().Equals(obj.ToString());
        }
        #endregion
    }
}