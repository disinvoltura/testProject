﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public class SimObject
    {
        #region Member Variables
        private static int _NextID;
        private int _ID;
        protected string _Name;
        private AtomicObjectSimulator _Parent;
        private object _UserObject;
        #endregion

        #region Properties
        public int ID { get { return _ID; } }
        public string Name { get { return _Name; } }
        public AtomicObjectSimulator Parent { get { return _Parent; } set { _Parent = value; } }
        public object UserObject { get { return _UserObject;  } set { _UserObject = value; } }
        #endregion

        public SimObject(AtomicObjectSimulator parent)
        {
            _Parent = parent;
            _ID = _NextID++;
            _Name = "SimObject " + _ID;
        }

        public SimObject()
        {
            _ID = _NextID++;
            _Name = "SimObject " + _ID;
        }

        public SimObject(AtomicObjectSimulator parent, string name)
        {
            _Parent = parent;
            _ID = _NextID++;
            _Name = name;
        }

        public SimObject(string name)
        {
            _ID = _NextID++;
            _Name = name;
        }

    }
}
