﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public class MessageTrace 
    {
        #region Member Variables
        private string _FromObjectId;
        private int _FromEventorStateId;

        private string _ToObjectId;
        private int _ToEventorStateId;

        private string _Message;

        private double _Time;
        #endregion

        #region Properties
        public string FromObjectId { get { return _FromObjectId; } }
        public int FromEventOrStateId { get { return _FromEventorStateId; } }
        public string ToObjectId { get { return _ToObjectId; } }
        public string Message {  get { return _Message; } }
        public int ToEventOrStateId { get { return _ToEventorStateId; } }
        public double Time {  get { return _Time; } }
        #endregion

        #region Constructors
        public MessageTrace(string fromObjectId, int fromEventorStateId, string message, string toObjectId, int toEventorStateId, double time)
        {
            _FromObjectId = fromObjectId;
            _FromEventorStateId = fromEventorStateId;
            _Message = message;
            _ToObjectId = toObjectId;
            _ToEventorStateId = toEventorStateId;
            _Time = time;
        }

        #endregion

        #region Methods
        public override bool Equals(object obj)
        {
            bool rslt = false;
            if (obj is MessageTrace)
            {
                MessageTrace target = (MessageTrace)obj;
                if (target.FromObjectId.Equals(_FromObjectId) &&
                    target.FromEventOrStateId.Equals(_FromEventorStateId) &&
                    target.Message.Equals(_Message) &&
                    target.ToObjectId.Equals(_ToObjectId) &&
                    target.ToEventOrStateId.Equals(_ToEventorStateId) &&
                    target.Time.Equals(_Time))
                    rslt = true;
            }
            return rslt;
        }

        public override int GetHashCode()
        {
            string rslt = _FromObjectId + "." + _FromEventorStateId + "->" + _ToObjectId + "." + _ToEventorStateId + "@" + _Time;
            return rslt.GetHashCode();
        }
        #endregion
    }
}
