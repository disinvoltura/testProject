﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.ATT.Simulation
{
    public class ATTQueueObserver
    {
        private string _QueueName;
        private int _LastValue;
        private List<ATTQueueValueChangedEvent> _Events;

        private List<double> _WaitingTimes;
        private Queue<double> _EnqueuedTimes;
        private double _SumWT;
        private double _minWT;
        private double _maxWT;

        public string Name
        {
            get { return _QueueName; }
        }

        public double AverageWaitingTime
        {
            get
            {
                double rslt = 0;
                rslt = _SumWT / _WaitingTimes.Count;
                return rslt;
            }
        }
        
        public double MinimumWaitingTime
        {
            get { return _minWT; }
        }

        public double MaximumWaitingTime
        {
            get { return _maxWT; }
        }

        public List<ATTQueueValueChangedEvent> Events
        {
            get { return _Events; }
        }

        public ATTQueueObserver(string queueName, int initialValue)
        {
            _QueueName = queueName;
            _LastValue = initialValue;
            _Events = new List<ATTQueueValueChangedEvent>();
            _WaitingTimes = new List<double>();
            _EnqueuedTimes = new Queue<double>();
            _SumWT = 0;
            _minWT = double.MaxValue;
            _maxWT = double.MinValue;

            ATTQueueValueChangedEvent evt = new ATTQueueValueChangedEvent(0, initialValue);
            Events.Add(evt);

            for (int i = 0; i < initialValue; i++)
                _EnqueuedTimes.Enqueue(0);

        }

        public void Collect(double time, int queueValue)
        {
            if (_LastValue != queueValue)
            {
                ATTQueueValueChangedEvent evt = new ATTQueueValueChangedEvent(time, queueValue);
                _Events.Add(evt);

                if (queueValue > _LastValue) 
                {
                    //Enqueued 
                    for(int i = _LastValue ; i < queueValue; i++)
                        _EnqueuedTimes.Enqueue(time);
                }
                else
                {
                    //Dequeued
                    int multiplicity = _LastValue - queueValue;
                    for (int i = 0; i < multiplicity; i++)
                    {
                        double et = _EnqueuedTimes.Dequeue();
                        double wt = time - et;
                        _WaitingTimes.Add(wt);
                        _SumWT += wt;

                        if (wt < _minWT)
                            _minWT = wt;
                        if (wt > _maxWT)
                            _maxWT = wt;
                    }
                }

                _LastValue = queueValue;
            }
        }
    }

    public class ATTQueueValueChangedEvent
    {
        private double _Time;
        private int _Value;

        public double Time { get { return _Time; } }
        public int Value { get { return _Value; } }

        public ATTQueueValueChangedEvent(double time, int queueValue)
        {
            _Time = time;
            _Value = queueValue;
        }
    }
}
