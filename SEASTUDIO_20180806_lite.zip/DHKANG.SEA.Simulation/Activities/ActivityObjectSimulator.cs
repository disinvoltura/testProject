﻿using DHKANG.SEA.Simulation.Events;
using DHKANG.SEA.Simulation.Observers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation.Activities
{
    public abstract class ActivityObjectSimulator : AtomicObjectSimulator
    {
        #region Member Variables
        private TAG curTAG;
        private EventScheduler _Scheduler = null;
        private ActivityScheduler _CAL = null;
        protected String[] _RemoteEvents;
        protected Dictionary<string, string> _BoundaryEvents;//key: event name, value: activity name
        //protected List<string> _BoundaryEvents;
        protected LocalEvent _CurrentEvent;
        private Dictionary<string, List<string>> _InfluencedActivities;

        private Dictionary<string, ActivityObserver> _ActivityObservers;

        private SimActivity _CurrentActivity;
        private List<SimActivity> _Traces;

        #endregion

        #region Properties
        public object this[string name]
        {
            get { return this.GetStateVariable(name); }
            set { this.SetStateVariable(name, value); }
        }

        public String[] RemoteEvents
        {
            get { return _RemoteEvents; }
            set { _RemoteEvents = value; }
        }

        public List<SimActivity> Traces
        {
            get { return _Traces; }
        }
        #endregion

        #region Constructors
        public ActivityObjectSimulator(string id) : base(id)
        {
            _InfluencedActivities = new Dictionary<string, List<string>>();

            _BoundaryEvents = new Dictionary<string, string>();

            _ActivityObservers = new Dictionary<string, ActivityObserver>();
            _Traces = new List<SimActivity>();
        }
        #endregion

        #region Atomic Object Simulator Methods
        public void AddMirrorEvent(string boundaryEventName, string boundaryActivityName)
        {
            if (!_BoundaryEvents.ContainsKey(boundaryEventName))
                _BoundaryEvents.Add(boundaryEventName, boundaryActivityName);
        }

        public override void ExternalInput(INPUT input)
        {
            if (input.Type == InputType.TAG)
            {
                TAG tag = input.Record as TAG;
                curTAG = tag;

                bool rslt = false;
                do
                {
                    rslt = handleNextEvents(curTAG.Now);
                } while (!rslt);

            }
            else if (input.Type == InputType.MDP)//activity의 시작을 trigger?
            {
                MDP mdp = input.Record as MDP;

                if (mdp.Name.Equals("STOP"))
                {
                    this.Stop();
                    return;
                }                

                string queueName = mdp.Name;
                int targetQueue = (int)GetStateVariable(queueName);
                targetQueue++;
                SetStateVariable(queueName, targetQueue);
                
                //influenced activities -> CAL
                List<string> influencedActivities = GetInfluencedActivities(queueName);
                influencedActivities.ForEach(a => _CAL.StoreActivity(a));
                //execute activityu in cal
                executeActivitiesInCAL();

                //execute the end of activities
                bool rslt = false;
                do
                {
                    rslt = handleNextEvents(mdp.Now);
                } while (!rslt);

                //
                /*
                //System.Diagnostics.Debug.WriteLine("[" + this.ID + "] ExternalInput(" + mdp.Name+")");
                SimEvent nextEvent = null;
                // mdp.Msg: event name
                // mdp.MsgData: LocalEvent
                if (mdp.Data.ContainsKey("event"))
                {
                    nextEvent = (SimEvent)mdp.Data["event"];
                }
                else
                {
                    //Transform the message into SimEvent sent from State Object Simulator
                    nextEvent = new LocalEvent(this.ID, mdp.Name, mdp.Now);
                    foreach (object value in mdp.Data.Values)
                    {
                        nextEvent.Parameters.Add(value);
                    }
                }

                _Scheduler.ScheduleEvent(nextEvent);
                bool rslt = false;
                do
                {
                    rslt = handleNextEvents(nextEvent.Time);
                } while (!rslt);
                */
            }
        }

        private bool handleNextEvents(double tagTime)
        {
            SimEvent nextEvent = _Scheduler.PeekEvent();
            if (nextEvent == null)
            {
                Send_TAR(double.MaxValue, _RemoteEvents);
                return true; //irregular abort;
            }

            if (nextEvent.Time > tagTime)
            {
                Send_TAR(nextEvent.Time, _RemoteEvents);
                return true;
            }
            else
            {
                nextEvent = _Scheduler.RetrieveNextEvent();
                //System.Diagnostics.Debug.WriteLine("[" + this.ID + "] Execute an event: " + nextEvent.ToString());

                _CurrentEvent = (LocalEvent)nextEvent;
                SimActivity currentActivity = (SimActivity)_CurrentEvent.UserObject;
                _CurrentEventorStateId = currentActivity.ID;
                //_CurrentEventorStateId = _CurrentEvent.ID;

                try
                {
                    ExecuteLocalEvent((LocalEvent)nextEvent, _Scheduler.Clock);
                }catch(Exception ex)
                {
                    OnExceptionCaught(nextEvent, ex);
                }

                _Scheduler.ArchiveLocalEvent((LocalEvent)nextEvent);

                executeActivitiesInCAL();

                NotifyActivityObservers(new Observers.ActivityObjectActivityChangedEvent(nextEvent.Time, nextEvent.Name, this));

                if (_BoundaryEvents.ContainsKey(_CurrentEvent.Name))
                {
                    string activityName = _BoundaryEvents[_CurrentEvent.Name];
                    MessageData md = new MessageData(activityName);
                    //MessageData md = new MessageData(_CurrentEvent.Name);
                    md["activity"] = _CurrentEvent;
                    Send_MSR(md);
                }
                //TODO
                //send message
                //activity 가 object scheduling 에 속한 경우...

                /*
                if (_Scheduler.HasBoundaryEvents())
                {
                    List<SimEvent> boundaryEvents = _Scheduler.GetBoundaryEvents();
                    foreach (SimEvent e in boundaryEvents)
                    {
                        MessageData md = new MessageData(e.Name);
                        md["event"] = e;
                        Send_MSR(md);
                    }
                    _Scheduler.RemoveBoundaryEvents();
                }
                */
            }

            return false;
        }

        private void executeActivitiesInCAL()
        {
            while (_CAL.Count > 0)
            {
                SimActivity activity = _CAL.RetrieveActivity();
                printVariableValues();

                try
                {
                    ExecuteActivity(activity, _Scheduler.Clock);
                }catch(Exception ex)
                {
                    OnExceptionCaught(activity, ex);
                }
            }
        }

        private void printVariableValues()
        {
            System.Diagnostics.Debug.WriteLine("State Variables in " + this.ID + " at " + this.Clock);
            foreach(string svName in this.StateVariables)
            {
                object svValue = this.GetStateVariable(svName);
                System.Diagnostics.Debug.WriteLine(" - " + svName + ": " + svValue.ToString());
            }
        }

        public override void Initialize(Dictionary<string, object> args)
        {
            _Scheduler = new EventScheduler(this.ID);
            _Scheduler.Initialize(args);

            _CAL = new ActivityScheduler(this);
            _Traces = new List<SimActivity>();

            Execute_Initialize_Routine(args); //add candidate activity initially
        }

        public override void OnSimulationEnded(double now)
        {

        }

        public override void Run()
        {
            _Clock = 0;

            //if (_CAL.Count > 0)
            //{
                while (_CAL.Count > 0)
                {
                    SimActivity activity = _CAL.RetrieveActivity();
                    ExecuteActivity(activity, _Clock);
                }
            //}

            SimEvent nextEvent = _Scheduler.PeekEvent();
            if (nextEvent != null)
            {
                Send_TAR(nextEvent.Time, _RemoteEvents);
            }else { 
                Send_TAR(double.MaxValue, _RemoteEvents);
            }
        }
        #endregion

        #region Abstract Methods

        /// <summary>
        /// store initial activity
        /// </summary>
        /// <param name="args"></param>
        public abstract void Execute_Initialize_Routine(Dictionary<string, object> args);
        public abstract void ExecuteLocalEvent(LocalEvent nextEvent, double now);

        //execute_arrive_activityroutine(clock)//
        public abstract void ExecuteActivity(SimActivity nextActivity, double now);

        #endregion

        #region Influenced Activities Methods
        public void AddInfluencedActivities(string queueName, params string[] influencedActivities)
        {
            List<string> iaList = new List<string>();
            iaList.AddRange(influencedActivities);

            _InfluencedActivities.Add(queueName, iaList);
        }

        protected List<string> GetInfluencedActivities(string queueName)
        {
            List<string> rslt = new List<string>();
            if (_InfluencedActivities.ContainsKey(queueName))
                rslt = _InfluencedActivities[queueName];
            return rslt;
        }

        #endregion
      
        #region Event Scheduling Methods{
        protected void ScheduleLocalEvent(string eventName, double time)
        {
            _Scheduler.ScheduleLocalEvent(eventName, time);
        }

        protected void ScheduleLocalEvent(string activityName, string eventName, double now, double scheduledTime)
        {
            SimActivity activity = EnterActivity(activityName, now, scheduledTime);
            LocalEvent scheduledEvent = _Scheduler.ScheduleLocalEvent(eventName, scheduledTime);
            scheduledEvent.UserObject = activity;
        }

        protected void ScheduleMirrorEvent(string objectid, string eventName, double time, params object[] parameters)
        {
            _Scheduler.ScheduleMirrorEvent(objectid, eventName, time, parameters);
        }

        protected void ScheduleMirrorEvent(string objectid, string eventName, double time)
        {
            _Scheduler.ScheduleMirrorEvent(objectid, eventName, time);
        }
        #endregion

        #region Activity Traces
        protected SimActivity EnterActivity(string activityName, double start, double end)
        {
            SimActivity activity = new SimActivity(this, activityName);
            activity.Start = start;
            activity.End = end;

            if (_SM.Mode == SMMode.Scaled)
                _Traces.Add(activity);

            return activity;
        }

        /*
        protected void ExitActivity(string activityName, double now)
        {
        //not easy to identify the activity (without any id)
            
        }
        */

        #endregion
        
        #region Candidate Activity Scheduling Methods
        public void StoreActivity(string activityName)
        {
            SimActivity activity = new SimActivity(this, activityName);
            _CAL.StoreActivity(activity);
        }

        public void StoreActivity(string activityName, int priority)
        {
            SimActivity activity = new SimActivity(this, activityName, priority);
            _CAL.StoreActivity(activity);
        }
        #endregion

        #region Observers
        public void NotifyActivityObservers(ActivityObjectActivityChangedEvent e)
        {
            foreach (ActivityObserver obs in _ActivityObservers.Values)
            {
                obs.Update(e);
            }

            CheckStateVariableValueChanges(e);
        }

        public override SimObserver GetObserver(string name)
        {
            if (_ActivityObservers.ContainsKey(name))
                return _ActivityObservers[name];
            else
                return null;
        }

        public override void RegisterObserver(SimObserver obs)
        {
            if (obs is ActivityObserver)
                RegisterActivityObserver((ActivityObserver)obs);
            else if (obs is StateVariableObserver)
                RegisterStateVariableObserver((StateVariableObserver)obs);
        }

        public void RegisterActivityObserver(ActivityObserver obs)
        {
            if (_ActivityObservers == null)
                _ActivityObservers = new Dictionary<string, ActivityObserver>();

            _ActivityObservers.Add(obs.Name, obs);
        }

        public void RemoveActivityObserver(ActivityObserver obs)
        {
            _ActivityObservers.Remove(obs.Name);
        }

        public override void NotifyObservers(ObservedEvent e)
        {
            if (e is StateVariableObservedEvent)
            {
                NotifyStateVariableObservers((StateVariableObservedEvent)e);
            }
            else if (e is StateObjectStateChangedEvent)
            {
                NotifyActivityObservers((ActivityObjectActivityChangedEvent)e);
            }
        }

        public override void RemoveObserver(SimObserver obs)
        {
            if (obs is StateObserver)
            {
                RemoveActivityObserver((ActivityObserver)obs);
            }
            else if (obs is StateVariableObserver)
            {
                RemoveStateVariableObserver((StateVariableObserver)obs);
            }
        }

        #endregion
    }
}
