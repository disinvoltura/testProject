﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.Simulation;

namespace DHKANG.SEA.Simulation.Activities
{
    public class ActivityScheduler : SimObject
    {
        private List<SimActivity> _CAL;

        public int Count {  get { return _CAL.Count; } }

        public ActivityScheduler(ActivityObjectSimulator parent) 
            : base (parent, "CAL")
        {
            _CAL = new List<SimActivity>();
        }

        public SimActivity RetrieveActivity()
        {
            SimActivity rslt = null;

            if (_CAL.Count > 0)
            {
                rslt = _CAL[0];
                _CAL.RemoveAt(0);
            }

            return rslt;
        }

        public void StoreActivity(string activityName)
        {
            SimActivity activity = new SimActivity(
                                        (ActivityObjectSimulator)this.Parent, 
                                        activityName);
            this.StoreActivity(activity);
        }

        public void StoreActivity(SimActivity activity)
        {
            //추후 priority 주어야 함
            if (_CAL.Count == 0)
            {
                _CAL.Add(activity);
            }
            else
            {
                bool inserted = false;
                for (int i = 0; i < _CAL.Count; i++)
                {
                    if (activity.Name == _CAL[i].Name)
                        return;
                    if (activity.Priority > _CAL[i].Priority)
                    {
                        _CAL.Insert(i, activity);
                        inserted = true;
                        break;
                    }
                }
                if (!inserted)
                    _CAL.Add(activity);
            }
        }

        public override string ToString()
        {
            string rslt = "";
            for (int i = 0; i < _CAL.Count; i++)
            {
                rslt += _CAL[i].Name;
                if (i < _CAL.Count - 1)
                    rslt += ",";
            }
            return rslt;
        }
    }
}