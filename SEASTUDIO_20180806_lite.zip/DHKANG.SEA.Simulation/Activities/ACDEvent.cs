﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.ATT.Simulation
{
    public class ACDEvent
    {
        #region Member Variables
        protected string _Name;
        protected double _Time;
        protected int _Priority;//Priority of Event
         #endregion

        #region Properties
        public string Name
        {
            get { return _Name; }
        }

        public double Time
        {
            get { return _Time; }
        }

        public int Priority
        {
            get { return _Priority; }
        }

        #endregion

        #region Constructors
        public ACDEvent(double time, string name)
        {
            _Name = name;
            _Time = time;
            _Priority = 100;
        }

        public ACDEvent(double time, string name, int priority)
            : this(time, name)
        {
            _Priority = priority;
        }

        #endregion

        #region Methods
        
        public override string ToString()
        {
            return Name + "(" + Math.Round(Time, 4) + ")";
            //return Name + "(" + Time + ")";
        }
        #endregion
    }
}
