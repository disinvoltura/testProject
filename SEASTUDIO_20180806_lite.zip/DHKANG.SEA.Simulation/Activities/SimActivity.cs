﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DHKANG.SEA.Simulation;

namespace DHKANG.SEA.Simulation.Activities
{
    public class SimActivity : SimObject
    {
        #region Member Variables
        protected int _Priority;//Priority of Event
        protected double _Start;
        protected double _End;
        #endregion

        #region Properties
        public int Priority
        {
            get { return _Priority; }
        }

        /// <summary>
        /// start time of an activity
        /// </summary>
        public double Start { get { return _Start; } set { _Start = value; } }
        /// <summary>
        /// end time of an activity
        /// </summary>
        public double End {  get { return _End; } set { _End = value; } }
        #endregion

        #region Constructors
        public SimActivity(ActivityObjectSimulator parent, string name) : base(parent, name)
        {
            _Priority = 100;
        }

        public SimActivity(ActivityObjectSimulator parent, string name, int priority)
            : this(parent, name)
        {
            _Priority = priority;
        }

        #endregion

        #region Methods

        public override string ToString()
        {
            return this.Name + "(" + Priority + ")";
        }
        #endregion
    }
}
