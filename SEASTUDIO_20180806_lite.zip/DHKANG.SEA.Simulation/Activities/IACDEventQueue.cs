﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VMS.ATT.Simulation
{
    public interface IACDEventQueue
    {
        int Count
        {
            get;
        }

        void Enqueue(ACDEvent evt);

        ACDEvent Dequeue();

        void Clear();
    }
}
