﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;

namespace VMS.ATT.Simulation
{
    public abstract class AbstractACDSimulator
    {
        public double Clock;

        public double CLK
        {
            get { return this.Clock; }
        }

        public List<ACDActivity> CAL;
        public ACDPriorityEventQueue FEL;
        public List<Trajectory> Trajectories;
        public AbstractACDSimulator()
        {
            this.CAL = new List<ACDActivity>();
            this.FEL = new ACDPriorityEventQueue();
            this.Trajectories = new List<Trajectory>();
        }

        public abstract void Run();
        public abstract object GetVariable(string name);
        public abstract ATTQueueObserver GetObserver(string name);

        #region CAL Methods
        public string RetrieveActivity()
        {
            ACDActivity activity = CAL[0];
            CAL.RemoveAt(0);

            return activity.Name;
        }

        public void StoreActivity(string activityName)
        {
            ACDActivity activity = new ACDActivity(activityName);
            this.StoreActivity(activity);
        }

        public void StoreActivity(ACDActivity  activity)
        {
            //추후 priority 주어야 함
            if (CAL.Count == 0)
            {
                CAL.Add(activity);
            }
            else
            {
                bool inserted = false;
                for (int i = 0; i < CAL.Count; i++)
                {
                    if (activity.Name == CAL[i].Name)
                        return;
                    if (activity.Priority > CAL[i].Priority)
                    {
                        CAL.Insert(i, activity);
                        inserted = true;
                        break;
                    }
                }
                if (!inserted)
                    CAL.Add(activity);
            }

        }
        #endregion

        #region FEL Methods
        public void ScheduleNextEvent(double time, string name)
        {
            ACDEvent evt = new ACDEvent(time, name);
            this.ScheduleNextEvent(evt);
        }

        public void ScheduleNextEvent(ACDEvent evt)
        {
            FEL.Enqueue(evt);
        }

        public ACDEvent GetNextEvent()
        {
            ACDEvent nextEvent = FEL.Dequeue();
            return nextEvent;
        }

        public ACDEvent RetrieveEvent()
        {
            ACDEvent nextEvent = FEL.Dequeue();
            return nextEvent;
        }

        public void CancelEvent(string name)
        {
            FEL.Cancel(name);
        }
        #endregion

        #region Random Variate Generation Methods

        protected double Rnd()
        {
            return RandomVariateGenerator.Uniform();
        }

        protected double Normal(double mu, double sigma)
        {
            return RandomVariateGenerator.Normal(mu, sigma);
        }

        protected double normal(double mu, double sigma)
        {
            return RandomVariateGenerator.Normal(mu, sigma);
        }

        protected double Beta(double alpha, double beta)
        {
            return RandomVariateGenerator.Beta(alpha, beta);
        }

        protected double beta(double alpha, double beta)
        {
            return RandomVariateGenerator.Beta(alpha, beta);
        }

        protected double exponential(double lambda)
        {
            return RandomVariateGenerator.Exponential(lambda);
        }

        protected double Exp(double mu)
        {
            return RandomVariateGenerator.Exponential(1 / mu);
        }

        protected double exp(double mu)
        {
            return RandomVariateGenerator.Exponential(1 / mu);
        }

        protected double expo(double lambda)
        {
            return RandomVariateGenerator.Exponential(lambda);
        }

        protected double Exponential(double lambda)
        {
            return RandomVariateGenerator.Exponential(lambda);
        }

        protected double Weibull(double alpha, double lambda)
        {
            return RandomVariateGenerator.Weibull(alpha, lambda);
        }

        protected double weib(double alpha, double lambda)
        {
            return RandomVariateGenerator.Weibull(alpha, lambda);
        }

        protected double Weib(double alpha, double lambda)
        {
            return RandomVariateGenerator.Weibull(alpha, lambda);
        }

        protected double weibull(double alpha, double lambda)
        {
            return RandomVariateGenerator.Weibull(alpha, lambda);
        }

        protected double Erlang(int alpha, double lambda)
        {
            return RandomVariateGenerator.Erlang(alpha, lambda);
        }

        protected double erlang(int alpha, double lambda)
        {
            return RandomVariateGenerator.Erlang(alpha, lambda);
        }

        protected double studentt(int nu)
        {
            return RandomVariateGenerator.StudentT(nu);

        }
        protected double StudentT(int nu)
        {
            return RandomVariateGenerator.StudentT(nu);
        }

        protected double student(int nu)
        {
            return RandomVariateGenerator.StudentT(nu);
        }

        protected double Student(int nu)
        {
            return RandomVariateGenerator.StudentT(nu);
        }

        protected double Triangular(double a, double b, double g)
        {
            return RandomVariateGenerator.Triangular(a, b, g);
        }

        protected double triangular(double a, double b, double g)
        {
            return RandomVariateGenerator.Triangular(a, b, g);
        }
        
        protected double tri(double a, double b, double g)
        {
            return RandomVariateGenerator.Triangular(a, b, g);
        }

        protected double Tri(double a, double b, double g)
        {
            return RandomVariateGenerator.Triangular(a, b, g);
        }

        protected double Uniform()
        {
            return RandomVariateGenerator.Uniform();
        }

        protected double uniform()
        {
            return RandomVariateGenerator.Uniform();
        }

        protected double Uni(double a, double b)
        {
            return a + (b - a) * RandomVariateGenerator.Uniform();
        }

        protected double uni(double a, double b)
        {
            return a + (b - a) * RandomVariateGenerator.Uniform();
        }

        protected double Uniform(double a, double b)
        {
            return a + (b - a) * RandomVariateGenerator.Uniform();
        }

        protected double uniform(double a, double b)
        {
            return a + (b - a) * RandomVariateGenerator.Uniform();
        }

        protected double Unif(double a, double b)
        {
            return a + (b - a) * RandomVariateGenerator.Uniform();
        }

        protected double unif()
        {
            return RandomVariateGenerator.Uniform();
        }

        protected double unif(double a, double b)
        {
            return a + (b - a) * RandomVariateGenerator.Uniform();
        }

        #endregion

        protected string CALtoString()
        {
            string rslt = "";
            for (int i = 0; i < this.CAL.Count; i++)
            {
                rslt += this.CAL[i].Name;
                if (i < this.CAL.Count - 1)
                    rslt += ",";
            }
            return rslt;
        }

        protected string FELtoString()
        {
            string rslt = "";
            for (int i = 0; i < this.FEL.Count; i++)
            {
                rslt += this.FEL.Items[i].ToString();
                if (i < this.FEL.Count - 1)
                    rslt += ",";
            }
            return rslt;
        }
    }
}
