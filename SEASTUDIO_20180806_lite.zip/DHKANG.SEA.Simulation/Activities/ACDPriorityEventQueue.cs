﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace VMS.ATT.Simulation
{
    public class ACDPriorityEventQueue : IACDEventQueue
    {
        #region ACDEventQueue Members
        private List<ACDEvent> _events;

        #endregion

        #region Properties
        public int Count
        {
            get { return _events.Count; }
        }

        public List<ACDEvent> Items
        {
            get { return _events; }
        }

        #endregion

        #region Constructors
        public ACDPriorityEventQueue()
        {
            _events = new List<ACDEvent>();
        }

        #endregion

        #region Methods
        /// <summary>
        /// Enqueue an event into priority queue
        /// </summary>
        /// <param name="evt"></param>
        public void Enqueue(ACDEvent evt)
        {
            //Time, Priority순
            if (_events.Count == 0)
                _events.Add(evt);
            else
            {
                bool isInserted = false;
                for (int i = 0; i < _events.Count; i++)
                {
                    ACDEvent target = _events[i];
                    
                    if (evt.Time < target.Time)
                    {
                        _events.Insert(i, evt);
                        isInserted = true;
                        break;
                    }
                    else if (evt.Time == target.Time)
                    {
                        if (evt.Priority > target.Priority)
                        {
                            _events.Insert(i, evt);
                            isInserted = true;
                            break;
                        }
                    }
                }

                if (!isInserted)
                    _events.Add(evt);
            }
            ///////////////////////////////////////////////////
            //TODO
            ///////////////////////////////////////////////////
            //1. List.Sort 활용해서 구현해볼 것!!!
            //   - ACDEventComparer 구현해야함
        }

        /// <summary>
        /// return the first event in the queue
        /// </summary>
        /// <returns></returns>
        public ACDEvent Dequeue()
        {
            ACDEvent rslt = null;
            if (_events.Count > 0)
            {
                rslt = _events[0];
                _events.RemoveAt(0);
            }
            return rslt;
        }

        public bool Cancel(string name)
        {
            bool rslt = false;
           if (_events.Count == 0)
               return rslt;

            int count = _events.Count;
            for (int i = 0; i < count; i++)
            {
                if (_events[i].Name.Equals(name))
                {
                    rslt = true;
                    _events.RemoveAt(i);
                    break;
                }
            }

            return rslt;
        }

        public void Clear()
        {
            _events.Clear();
        }

        #endregion
    }
}
