﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using DHKANG.Foundation.RandomVariate;
using DHKANG.SEA.Simulation.Observers;
using System.Collections;
using DHKANG.Foundation.Logging;

namespace DHKANG.SEA.Simulation
{
    public delegate void SimulationExceptionEvent(AtomicObjectSimulator aos, object target, Exception ex);

    public abstract class AtomicObjectSimulator
    {
        #region Member Variables
        private string _ID;

        protected Thread _THREAD;
        //protected double _Clock;
        protected SynchronizationManager _SM;
        protected List<string> _Inputs;

        protected int _CurrentEventorStateId;

        private Dictionary<string, List<StateVariableObserver>> _StateVariableObservers;
        protected double _Clock;

        private Logger _Logger = LogManager.GetLogger("Debug");
        #endregion

        #region Properties
        public SynchronizationManager SM
        {
            set { _SM = value; }
            get { return _SM; }
        }
        public double Clock
        {
            get { if (_SM != null) return _SM.Clock; else return -1; }
        }
        public String ID { get { return _ID; } }
        public int CurrentEventorStateId {  get { return _CurrentEventorStateId; } }

        //public double Clock { get { return _Clock; } }
        #endregion

        #region Events
        public event SimulationExceptionEvent ExceptionCaught;
        #endregion

        #region Abstract Methods
        public abstract void ExternalInput(INPUT input);
        public abstract void Run();

        public abstract object GetStateVariable(string name);
        public abstract void SetStateVariable(string name, object value);
        public abstract List<string> StateVariables { get; }
        public abstract void OnSimulationEnded(double now);
        public abstract void Initialize(Dictionary<String, Object> args);

        #endregion

        public AtomicObjectSimulator(string id)
        {
            _ID = id;
            //_Clock = 0.0;
            _Inputs = new List<string>();
            _StateVariableObservers = new Dictionary<string, List<StateVariableObserver>>();
            _LastValueList = new Dictionary<string, object>();
            _Logger = LogManager.GetLogger("Debug");
        }

        #region Methods
        protected void OnExceptionCaught(object target, Exception ex)
        {
            if (ExceptionCaught != null && ExceptionCaught.GetInvocationList().Length > 0)
            {
                ExceptionCaught(this, target, ex);
            }
        }

        public void Start()
        {
            _THREAD = new Thread(new ThreadStart(Run)); 
            //_THREAD = new Thread(new ThreadStart(Run), 1024000);
            if (_THREAD != null)
            {
                System.Diagnostics.Debug.WriteLine("AtomicSimulator[" + this._ID + "].start");
                _THREAD.Start();
            }
        }

        /*
        protected void NotifyStateChangedEvent(SimStateChangedEvent evt)
        {
            StateChanged(evt);
        }*/

        public void Stop()
        {
            try
            {
                if (_THREAD.IsAlive)
                    _THREAD.Abort();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
                //Logged(ID, ex.Message + " at Stop()", _Clock);
            }
        }

        /// <summary>
        /// wrapper Method for Send TAR
        /// </summary>
        /// <param name="time">next time (advanced time)</param>
        /// <param name="inputs">waiting messages</param>
        public void Send_TAR(double time, params string[] inputs)
        {
            System.Diagnostics.Debug.WriteLine("[" + this.ID + "] Send_TAR(" + time + ", " + inputs);
            Debug("[" + this.ID + "] Send_TAR(" + time + ", " + inputs);
            _Inputs.Clear();
            if (inputs != null)
            {
                foreach (string s in inputs)
                    _Inputs.Add(s);
            }

            /*
            if (time == double.MaxValue)
                Logged(this.ID, "TAR(inf)->SM", _Clock);
            else
                Logged(this.ID, "TAR(" + time.ToString() + "->SM", _Clock);
            */

            TAR tar = new TAR(time, _Inputs, this);
            _SM.Send_Output(InputType.TAR, tar);

            /*
            if (StateChanged != null && StateChanged.GetInvocationList().Length > 0)
            {
                SimStateChangedEvent evt = new SimStateChangedEvent(_Clock, this, this.CurrentState);
                StateChanged(evt);
                //StateChanged(_Clock, this);
            }
             */
        }

        /// <summary>
        /// wrapper Method for Send MSR
        /// </summary>
        /// <param name="msg">sending message</param>
        public void Send_MSR(string msg)
        {
            System.Diagnostics.Debug.WriteLine("[" + this.ID + "] Send_MSR(" + msg+ ")");
            Debug("[" + this.ID + "] Send_MSR(" + msg + ")");

            //Logged(this.ID, "MSR(" + msg + ")->SM", _SM.Clock);

            MSR msr = new MSR(msg, this);
            msr.CurrentEventorStateId = _CurrentEventorStateId;

            /*
            if (MessageSent != null && MessageSent.GetInvocationList().Length > 0)
            {
                SimMessageRequestedEvent evt = new SimMessageRequestedEvent(_SM.Clock, this, msr);
                MessageSent(evt);
            }
            */
            _SM.Send_Output(InputType.MSR, msr);
        }

        public void Send_MSR(MessageData msg)
        {
            System.Diagnostics.Debug.WriteLine("[" + this.ID + "] Send_MSR(" + msg.MessageName + ")");
            Debug("[" + this.ID + "] Send_MSR(" + msg.MessageName + ")");

            //Logged(this.ID, "MSR(" + msg.ToString() + ")->SM", _SM.Clock);

            //System.Diagnostics.Debug.WriteLine("[" + this.ID + "@" + _SM.Clock + "] SEND_MSR: " + msg.ToString());
            MSR msr = new MSR(msg, this);
            msr.CurrentEventorStateId = _CurrentEventorStateId;

            /*
            if (MessageSent != null && MessageSent.GetInvocationList().Length > 0)
            {
                SimMessageRequestedEvent evt = new SimMessageRequestedEvent(_SM.Clock, this, msr);
                MessageSent(evt);
            }
            */

            _SM.Send_Output(InputType.MSR, msr);
        }

        public void Send_Output(InputType type, Message msg)
        {
            /*
            if (type == InputType.MDP)
            {
                if (MessageDelivered != null && MessageDelivered.GetInvocationList().Length > 0)
                {
                    MDP mdp = (MDP)msg;
                    SimMessageDeliveredEvent evt = new SimMessageDeliveredEvent(mdp.Now, this, mdp);
                    MessageDelivered(evt);
                }
            }
            */

            if (type == InputType.MDP)
                Debug("[" + this.ID + "] A message is delivered: " + ((MDP)msg).Name);
            else if (type == InputType.TAG)
                Debug("[" + this.ID + "] Time adanvce is granted: " + ((TAG)msg).Now);

            INPUT input = new INPUT(type, msg);
            if (input != null)
            {
                try
                {
                    ExternalInput(input);
                }catch(Exception ex)
                {
                    OnExceptionCaught(msg, ex);
                }

                //this.NotifyStateObservers(new StateObjectStateObservedEvent(this.Clock, this, null));
                //this.NotifyEventObservers(new EventObjectLocalEventObservedEvent(this.Clock, _ObjectList[e.ObjectName], e));
            }
        }

        #endregion

        #region Observer Methods
        public List<StateVariableObserver> GetStateVariableObserver(string svName)
        {
            List<StateVariableObserver> rslt = null;
            if (_StateVariableObservers.ContainsKey(svName))
                rslt = _StateVariableObservers[svName];
            else
            {
                System.Diagnostics.Debug.WriteLine("[" + this.ID + ".GetStateVariableObserver] state variable <" + svName + ">'s observer cannot be found.");
            }
            return rslt;
        }

        public abstract void RegisterObserver(SimObserver obs);
        /*
        public void RegisterObserver(SimObserver obs)
        {
            if (obs is EventObserver)
                RegisterEventObserver((EventObserver)obs);
            else if (obs is StateVariableObserver)
                RegisterStateVariableObserver((StateVariableObserver)obs);
        }
        */

        protected void initializeLastValueList()
        {
            foreach (string svName in this.StateVariables)
            {
                object newValue = this.GetStateVariable(svName);
                if (newValue is ICollection)
                    _LastValueList.Add(svName, ((ICollection)newValue).Count);
                else if (newValue is EntityQueue)
                    _LastValueList.Add(svName, ((EntityQueue)newValue).Count);
                else if (newValue is Resource)
                    _LastValueList.Add(svName, ((Resource)newValue).InUse);
                else
                    _LastValueList.Add(svName, newValue);
            }
        }

        private Dictionary<string, object> _LastValueList;
       

        protected void CheckStateVariableValueChanges(ObservedEvent e)
        {
            foreach (string svName in this.StateVariables)
            {
                object newValue = this.GetStateVariable(svName);

                bool issueEvent = false;
                if (newValue != null)
                {
                    if (!_LastValueList.ContainsKey(svName))
                    {
                        if (newValue is Array)
                        {
                            continue;
                        }
                        else if (newValue is ICollection)
                            _LastValueList.Add(svName, ((ICollection)newValue).Count);
                        else if (newValue is EntityQueue)
                            _LastValueList.Add(svName, ((EntityQueue)newValue).Count);
                        else if (newValue is TimeQueue)
                            _LastValueList.Add(svName, ((TimeQueue)newValue).Count);
                        else if (newValue is Resource)
                            _LastValueList.Add(svName, ((Resource)newValue).InUse);
                        else
                            _LastValueList.Add(svName, newValue);
                        issueEvent = true;
                    }
                    else
                    {
                        object lastValue = _LastValueList[svName];
                        if (newValue is Array)
                        {
                            continue;
                        }
                        else if (newValue is ICollection)
                        {
                            if (lastValue == null || lastValue.ToString() != ((ICollection)newValue).Count.ToString())
                            {
                                _LastValueList[svName] = ((ICollection)newValue).Count;
                                issueEvent = true;
                            }
                        }
                        else if (newValue is EntityQueue)
                        {
                            if (lastValue == null || lastValue.ToString() != ((EntityQueue)newValue).Count.ToString())
                            {
                                _LastValueList[svName] = ((EntityQueue)newValue).Count;
                                issueEvent = true;
                            }
                        }
                        else if (newValue is TimeQueue)
                        {
                            if (lastValue == null || lastValue.ToString() != ((TimeQueue)newValue).Count.ToString())
                            {
                                _LastValueList[svName] = ((TimeQueue)newValue).Count;
                                issueEvent = true;
                            }
                        }
                        else if (newValue is Resource)
                        {
                            if (lastValue == null || lastValue.ToString() != ((Resource)newValue).InUse.ToString())
                            {
                                _LastValueList[svName] = ((Resource)newValue).InUse;
                                issueEvent = true;
                            }
                        }
                        else
                        {
                            if (lastValue == null || lastValue.ToString() != newValue.ToString())
                            {
                                _LastValueList[svName] = newValue;
                                issueEvent = true;
                            }
                        }
                    }
                }

                if (issueEvent)
                {
                    StateVariableObservedEvent sve = new StateVariableObservedEvent(e.Time, this, svName, newValue);
                    //StateVariableObservedEvent sve = new StateVariableObservedEvent( e.Time, this, e.Event, svName, newValue);
                    NotifyStateVariableObservers(sve);
                }
            }
        }

        public void RegisterStateVariableObserver(StateVariableObserver obs)
        {
            if (_StateVariableObservers == null)
                _StateVariableObservers = new Dictionary<string, List<StateVariableObserver>>();

            if (_StateVariableObservers.ContainsKey(obs.StateVariableName))
            {
                List<StateVariableObserver> observers = _StateVariableObservers[obs.StateVariableName];
                observers.Add(obs);
                _StateVariableObservers[obs.StateVariableName] = observers;
            }
            else
            {
                List<StateVariableObserver> observers = new List<StateVariableObserver>();
                observers.Add(obs);
                _StateVariableObservers.Add(obs.StateVariableName, observers);
            }

            //initial event at simulation clock 0.
            obs.Update(new StateVariableObservedEvent(0, this, obs.StateVariableName, this.GetStateVariable(obs.StateVariableName)));
        }

        public void RegisterStateVariableObserver(StateVariableObserver obs, string svName)
        {
            if (_StateVariableObservers == null)
                _StateVariableObservers = new Dictionary<string, List<StateVariableObserver>>();

            if (_StateVariableObservers.ContainsKey(svName))
            {
                List<StateVariableObserver> observers = _StateVariableObservers[svName];
                observers.Add(obs);
                _StateVariableObservers[svName] = observers;
            }
            else
            {
                List<StateVariableObserver> observers = new List<StateVariableObserver>();
                observers.Add(obs);
                _StateVariableObservers.Add(svName, observers);
            }

            //initial event at simulation clock 0.
            obs.Update(new StateVariableObservedEvent(0, this, svName, this.GetStateVariable(svName)));
        }

        public void FinalizeStateVariableObservers()
        {
            foreach (string svName in _StateVariableObservers.Keys)
            {
                List<StateVariableObserver> observers = _StateVariableObservers[svName];

                //last value on the eos time

                StateVariableObservedEvent evt = new StateVariableObservedEvent(_SM.Clock, this, svName, this.GetStateVariable(svName));
                //StateVariableObservedEvent evt = new StateVariableObservedEvent(_SM.Clock, this, null, svName, this.GetStateVariable(svName));

                foreach (StateVariableObserver obs in observers)
                {
                    obs.Update(evt);
                    obs.Finalize(_SM.Clock);
                }
            }
        }

        public void RemoveStateVariableObserver(StateVariableObserver obs)
        {
            List<StateVariableObserver> observers = _StateVariableObservers[obs.StateVariableName];
            observers.Remove(obs);
            _StateVariableObservers[obs.StateVariableName] = observers;
        }

        public void NotifyStateVariableObservers(StateVariableObservedEvent e)
        {
            //DateTime dt1 = DateTime.Now;
            if (_StateVariableObservers.ContainsKey(e.StateVariableName))
            {
                List<StateVariableObserver> observers = _StateVariableObservers[e.StateVariableName];
                foreach (StateVariableObserver obs in observers)
                {
                    obs.Update(e);
                }
            }
            //DateTime dt2 = DateTime.Now;
            //System.Diagnostics.Debug.WriteLine("[" + this.Name + ".NotifySVObservers] time to execute:" + dt2.Subtract(dt1).TotalMilliseconds  + " seconds.");
            //System.Diagnostics.Debug.WriteLine(dt2.Subtract(dt1).TotalMilliseconds);
        }


        /*
        public void NotifyObservers(ObservedEvent e)
        {
            if (e is EventObjectLocalEventObservedEvent)
            {
                NotifyEventObservers((EventObjectLocalEventObservedEvent)e);
            }
            else if (e is StateVariableObservedEvent)
            {
                NotifyStateVariableObservers((StateVariableObservedEvent)e);
            }else if (e is StateObjectStateChangedEvent)
            {
                NotifyStateObservers((StateObjectStateChangedEvent)e);
            }
        }
        */

        #region Abstract Methods
        public abstract void NotifyObservers(ObservedEvent e);
        public abstract void RemoveObserver(SimObserver obs);
        public abstract SimObserver GetObserver(string name);
        #endregion

        /*
        public void RemoveObserver(SimObserver obs)
        {
            if (obs is EventObserver)
            {
                DeleteEventObserver((EventObserver)obs);
            }
            else if (obs is StateVariableObserver)
            {
                DeleteStateVariableObserver((StateVariableObserver)obs);
            }
        }
        */
        #endregion

        #region Random Variate Generation Methods

        protected double Rnd()
        {
            return RandomVariateGenerator.Uniform();
        }

        protected double Normal(double mu, double sigma)
        {
            return RandomVariateGenerator.Normal(mu, sigma);
        }

        protected double normal(double mu, double sigma)
        {
            return RandomVariateGenerator.Normal(mu, sigma);
        }

        protected double Beta(double alpha, double beta)
        {
            return RandomVariateGenerator.Beta(alpha, beta);
        }

        protected double beta(double alpha, double beta)
        {
            return RandomVariateGenerator.Beta(alpha, beta);
        }

        protected double exponential(double lambda)
        {
            return RandomVariateGenerator.Exponential(lambda);
        }

        protected double Exp(double mu)
        {
            return RandomVariateGenerator.Exponential(1 / mu);
        }

        protected double exp(double mu)
        {
            return RandomVariateGenerator.Exponential(1 / mu);
        }

        protected double expo(double lambda)
        {
            return RandomVariateGenerator.Exponential(lambda);
        }

        protected double Exponential(double lambda)
        {
            return RandomVariateGenerator.Exponential(lambda);
        }

        protected double Weibull(double alpha, double lambda)
        {
            return RandomVariateGenerator.Weibull(alpha, lambda);
        }

        protected double weib(double alpha, double lambda)
        {
            return RandomVariateGenerator.Weibull(alpha, lambda);
        }

        protected double Weib(double alpha, double lambda)
        {
            return RandomVariateGenerator.Weibull(alpha, lambda);
        }

        protected double weibull(double alpha, double lambda)
        {
            return RandomVariateGenerator.Weibull(alpha, lambda);
        }

        protected double Erlang(int alpha, double lambda)
        {
            return RandomVariateGenerator.Erlang(alpha, lambda);
        }

        protected double erlang(int alpha, double lambda)
        {
            return RandomVariateGenerator.Erlang(alpha, lambda);
        }

        protected double studentt(int nu)
        {
            return RandomVariateGenerator.StudentT(nu);

        }
        protected double StudentT(int nu)
        {
            return RandomVariateGenerator.StudentT(nu);
        }

        protected double student(int nu)
        {
            return RandomVariateGenerator.StudentT(nu);
        }

        protected double Student(int nu)
        {
            return RandomVariateGenerator.StudentT(nu);
        }

        protected double Triangular(double a, double b, double g)
        {
            return RandomVariateGenerator.Triangular(a, b, g);
        }

        protected double triangular(double a, double b, double g)
        {
            return RandomVariateGenerator.Triangular(a, b, g);
        }

        protected double tri(double a, double b, double g)
        {
            return RandomVariateGenerator.Triangular(a, b, g);
        }

        protected double Tri(double a, double b, double g)
        {
            return RandomVariateGenerator.Triangular(a, b, g);
        }

        protected double Uniform()
        {
            return RandomVariateGenerator.Uniform();
        }

        protected double uniform()
        {
            return RandomVariateGenerator.Uniform();
        }

        protected double Uni(double a, double b)
        {
            return a + (b - a) * RandomVariateGenerator.Uniform();
        }

        protected double uni(double a, double b)
        {
            return a + (b - a) * RandomVariateGenerator.Uniform();
        }

        protected double Uniform(double a, double b)
        {
            return a + (b - a) * RandomVariateGenerator.Uniform();
        }

        protected double uniform(double a, double b)
        {
            return a + (b - a) * RandomVariateGenerator.Uniform();
        }

        protected double Unif(double a, double b)
        {
            return a + (b - a) * RandomVariateGenerator.Uniform();
        }

        protected double unif()
        {
            return RandomVariateGenerator.Uniform();
        }

        protected double unif(double a, double b)
        {
            return a + (b - a) * RandomVariateGenerator.Uniform();
        }

        #endregion

        #region Logging
        public void Log(string value)
        {
            _Logger.Log(LogLevel.Debug, value);
        }

        public void Debug(string value)
        {
            _Logger.Log(LogLevel.Debug, value);
        }

        public void Error(string value)
        {
            _Logger.Log(LogLevel.Error, value);
        }

        public void Info(string value)
        {
            _Logger.Log(LogLevel.Informational, value);
        }

        public void Warning(string value)
        {
            _Logger.Log(LogLevel.Warning, value);
        }
        #endregion
    }
}
