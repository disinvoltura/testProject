﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public static class EntityManager
    {
        #region Member Variables
        private static Dictionary<int, AbstractEntity> _Entities;
        private static Dictionary<int, AbstractEntity> _OngoinEntities;
        private static Dictionary<int, AbstractEntity> _DisposedEntities;
        private static SimulationEngine _Simulator;
        #endregion

        #region Properties
        public static Dictionary<int, AbstractEntity> Entities { get { return _Entities; } }
        public static Dictionary<int, AbstractEntity> ActiveEntities { get { return _OngoinEntities; } }
        public static Dictionary<int, AbstractEntity> DisposedEntities { get { return _DisposedEntities; } }
        public static double Clock { get {
                if (_Simulator != null)
                    return _Simulator.Clock;
                else
                    return 0;
            } }
        #endregion

        #region Constructors
        static EntityManager()
        {
            _Entities = new Dictionary<int, Simulation.AbstractEntity>();
            _OngoinEntities = new Dictionary<int, AbstractEntity>();
            _DisposedEntities = new Dictionary<int, AbstractEntity>();
        }
        #endregion

        #region Methods
        public static void Initialize(SimulationEngine simulator)
        {
            _Simulator = simulator;
            _Entities = new Dictionary<int, AbstractEntity>();
            _OngoinEntities = new Dictionary<int, AbstractEntity>();
            _DisposedEntities = new Dictionary<int, AbstractEntity>();
        }

        public static void Add(AbstractEntity entity)
        {
            _Entities.Add(entity.ID, entity);
            _OngoinEntities.Add(entity.ID, entity);
        }

        public static void Dispose(AbstractEntity entity)
        {
            _OngoinEntities.Remove(entity.ID);
            _DisposedEntities.Add(entity.ID, entity);
        }
        #endregion
    }
}
