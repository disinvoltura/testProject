﻿using DHKANG.SEA.Simulation.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public class ParameterVariable<T> : SimObject
    {
        private Dictionary<string, T> _Values;

        public T this[string name]
        {
            get { return _Values[name]; }
            set {
                if (_Values.ContainsKey(name))
                    _Values[name] = value;
                else
                    _Values.Add(name, value);
            }
        }

        public int Count
        {
            get { return _Values.Count; }
        }

        public ParameterVariable(EventObjectSimulator parent, string name) : base(parent, name) {
            _Values = new Dictionary<string, T>(); 
        }

 
        public ParameterVariable(EventObjectSimulator parent) : base(parent) {
            _Values = new Dictionary<string, T>(); 
        }

        public void Clear()
        {
            _Values.Clear();
        }

        public void Add(string name, T value)
        {
            _Values.Add(name, value);
        }

        public bool Remove(string name)
        {
            return _Values.Remove(name);
        }

        public bool ContainsKey(string name)
        {
            return _Values.ContainsKey(name);
        }
    }
}
