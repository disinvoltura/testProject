﻿using DHKANG.SEA.Simulation.Activities;
using DHKANG.SEA.Simulation.Observers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation.Events
{
    public abstract class EventObjectSimulator : AtomicObjectSimulator
    {
        #region Member Variables
        private TAG curTAG;
        private EventScheduler _Scheduler = null;
        protected String[] _RemoteEvents;

        protected LocalEvent _CurrentEvent;
        //which event schedules an event? (key: scheduling event's ID, Value: Scheduled event's ID
        //private Dictionary<int, int> _SchedulingRelations;
        private List<SchedulingTrace> _SchedulingTraces;

        private Dictionary<string, EventObserver> _EventObservers;
        #endregion

        public event SimulationEndEventHandler SimulationEnded;

        #region Properties
        public String[] RemoteEvents
        {
            get { return _RemoteEvents; }
            set { _RemoteEvents = value; }
        }

        public LocalEvent CurrentEvent
        {
            get { return _CurrentEvent; }
        }

        public List<SchedulingTrace> SchedulingTraces
        {
            get { return _SchedulingTraces; }
        }

        public EventList<SimEvent> FEL { get { return _Scheduler.FEL; } }
        public EventList<LocalEvent> AEL { get { return _Scheduler.AEL; } }
        public List<SimEventTrace> EventTraces { get { return _Scheduler.EventTraces; } }

        #endregion

        #region Constructors
        public EventObjectSimulator(string id) : base(id)
        {
            _RemoteEvents = new string[0];

            _EventObservers = new Dictionary<string, EventObserver>();

        }
        #endregion

        #region Methods
        public override void ExternalInput(INPUT input)
        {
            if (input.Type == InputType.TAG)
            {
                TAG tag = input.Record as TAG;
                curTAG = tag;

                bool rslt = false;
                do
                {
                    rslt = handleNextEvents(curTAG.Now);
                } while (!rslt);

            }
            else if (input.Type == InputType.MDP)
            {
                MDP mdp = input.Record as MDP;

                //System.Diagnostics.Debug.WriteLine("[" + this.ID + "] ExternalInput(" + mdp.Name+")");
                SimEvent nextEvent = null;
                // mdp.Msg: event name
                // mdp.MsgData: LocalEvent
                if (mdp.Data.ContainsKey("event"))
                {
                    nextEvent = (SimEvent)mdp.Data["event"];
                }
                else
                {
                    //Transform the message into SimEvent sent from State/Activity Object Simulator
                    nextEvent = new LocalEvent(this.ID, mdp.Name, mdp.Now);
                    foreach (object value in mdp.Data.Values)
                    {
                        nextEvent.Parameters.Add(value);
                    }
                }

                _Scheduler.ScheduleEvent(nextEvent);
                bool rslt = false;
                do

                {
                    rslt = handleNextEvents(nextEvent.Time);
                } while (!rslt);

            }
        }

        private bool handleNextEvents(double tagTime)
        {
            //System.Diagnostics.Debug.WriteLine("EventGraphSimulator<" + this.ID + ">.handleNextEvents(" + tagTime + ")");
            SimEvent nextEvent = _Scheduler.PeekEvent();
            if (nextEvent == null)
            {
                //System.Diagnostics.Debug.WriteLine("EventGraphSimulator<" + this.ID + ">.handleNextEvents: aborted irregularly.");

                Send_TAR(double.MaxValue, _RemoteEvents);
                return true; //irregular abort;
            }

            if (nextEvent.Time > tagTime)
            {
                //System.Diagnostics.Debug.WriteLine("EventGraphSimulator<" + this.ID + ">.handleNextEvents: next time(" + nextEvent.Name + ", " + nextEvent.Time + ") is beyond the TAG time.");
                Send_TAR(nextEvent.Time, _RemoteEvents);
                return true;
            }
            else
            {
                nextEvent = _Scheduler.RetrieveNextEvent();
                //System.Diagnostics.Debug.WriteLine("[" + this.ID + "] Execute an event: " + nextEvent.ToString());

                _CurrentEvent = (LocalEvent)nextEvent;
                _CurrentEventorStateId = _CurrentEvent.ID;
                try
                {
                    ExecuteLocalEvent((LocalEvent)nextEvent, _Scheduler.Clock);
                }catch(Exception ex)
                {
                    OnExceptionCaught(nextEvent, ex);
                }
                if (_SM.Mode == SMMode.Scaled)
                    _Scheduler.ArchiveLocalEvent((LocalEvent)nextEvent);

                if (_Scheduler.HasBoundaryEvents())
                {
                    List<SimEvent> boundaryEvents = _Scheduler.GetBoundaryEvents();
                    foreach (SimEvent e in boundaryEvents)
                    {
                        MessageData md = new MessageData(e.Name);
                        md["event"] = e;
                        Send_MSR(md);
                    }
                    _Scheduler.RemoveBoundaryEvents();
                }

                CheckStateVariableValueChanges(new EventObjectLocalEventObservedEvent(_CurrentEvent.Time, this, _CurrentEvent));

            }

            return false;
        }

        protected EventScheduler Scheduler
        {
            get { return _Scheduler; }
        }

        public override void Initialize(Dictionary<String, Object> args)
        {
            _Scheduler = new EventScheduler(this.ID);
            _Scheduler.Initialize(args);

            Execute_Initializ_Routine(args);
        }

        protected void CancelLocalEvent(string eventName)
        {
            _Scheduler.CancelEvent(eventName);
        }

        protected void ScheduleLocalEvent(LocalEvent evt)
        {
            _Scheduler.ScheduleLocalEvent(evt);
        }

        protected void ScheduleLocalEvent(string eventName, double time)
        {
            _Scheduler.ScheduleLocalEvent(eventName, time);
        }

        protected void ScheduleMirrorEvent(string objectid, string eventName, double time, params object[] parameters)
        {
            _Scheduler.ScheduleMirrorEvent(objectid, eventName, time, parameters);
        }

        protected void ScheduleMirrorEvent(string objectid, string eventName, double time)
        {
            _Scheduler.ScheduleMirrorEvent(objectid, eventName, time);
        }

        public override void Run()
        {
            SimEvent nextEvent = _Scheduler.PeekEvent();
            if (nextEvent != null)
            {
                Send_TAR(nextEvent.Time, _RemoteEvents);
            }
            else
            {
                //how to send the TAR with no scheduled time?
                //here, according to the event scheduling among the event objects, the inputs should be provided
                //The inputs should be provided by the event graph model.
                Send_TAR(double.MaxValue, _RemoteEvents);
                //Send_TAR(double.MaxValue, "Enter");
            }
        }

        public override void OnSimulationEnded(double now)
        {
            if (this.SimulationEnded != null && this.SimulationEnded.GetInvocationList().Length > 0)
                this.SimulationEnded(now);
        }
        #endregion

        #region Abstract Methods
        public abstract void ExecuteLocalEvent(LocalEvent nextEvent, double now);

        public abstract void Execute_Initializ_Routine(Dictionary<string, object> args);
        #endregion

        #region Observer Methods
        public void NotifyEventObservers(EventObjectLocalEventObservedEvent e)
        {
            foreach (EventObserver obs in _EventObservers.Values)
            {
                obs.Update(e);
            }

            CheckStateVariableValueChanges(e);
        }

        public override SimObserver GetObserver(string name)
        {
            if (_EventObservers.ContainsKey(name))
                return _EventObservers[name];
            else
                return null;
        }

        public override void RegisterObserver(SimObserver obs)
        {
            if (obs is EventObserver)
                RegisterEventObserver((EventObserver)obs);
            else if (obs is StateVariableObserver)
                RegisterStateVariableObserver((StateVariableObserver)obs);
        }

        public void RegisterEventObserver(EventObserver obs)
        {
            if (_EventObservers == null)
                _EventObservers = new Dictionary<string, EventObserver>();

            _EventObservers.Add(obs.Name, obs);
        }

        public void RemoveEventObserver(EventObserver obs)
        {
            _EventObservers.Remove(obs.Name);
        }

        public override void NotifyObservers(ObservedEvent e)
        {
            if (e is EventObjectLocalEventObservedEvent)
            {
                NotifyEventObservers((EventObjectLocalEventObservedEvent)e);
            }
            else if (e is StateVariableObservedEvent)
            {
                NotifyStateVariableObservers((StateVariableObservedEvent)e);
            }
        }

        public override void RemoveObserver(SimObserver obs)
        {
            if (obs is EventObserver)
            {
                RemoveEventObserver((EventObserver)obs);
            }
            else if (obs is StateVariableObserver)
            {
                RemoveStateVariableObserver((StateVariableObserver)obs);
            }
        }
        #endregion
    }
}
