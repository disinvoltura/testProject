﻿using DHKANG.SEA.Simulation.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DHKANG.SEA.Simulation.Events
{
    public enum EOSMode { StopAtTime, StopOnEvents }

    public class EndOfSimulation
    {
        #region Member Variables
        private EOSMode _Mode;

        private double _EOSTime;
        private string _ObjectName;
        private string _EventName;
        private int _EventFrequency;
        private int _EventCount;

        private bool _IsAborted;
        private EventScheduler _Scheduler;
        #endregion

        #region Properties
        public EOSMode Mode
        {
            get { return _Mode; }
        }

        public double EOSTime
        {
            get { return _EOSTime; }
        }

        public bool IsAborted
        {
            get { return _IsAborted; }
        }

        /// <summary>
        /// return true if the EOS condition satisfies
        /// </summary>
        public bool StopCondition
        {
            get
            {
                if (_IsAborted)
                    return true;

                if (_Mode == EOSMode.StopAtTime)
                    return evaluateStopAtTime();
                else
                    return evaluateStopOnEvent();
            }
        }
        #endregion

        #region Constructors
        public EndOfSimulation(EventScheduler scheduler)
        {
            _Scheduler = scheduler;
            _IsAborted = false;

            _EventCount = 0;
        }
        #endregion

        #region Methods
        private bool evaluateStopAtTime()
        {
            bool rslt = false;

            SimEvent nextEvent = _Scheduler.PeekEvent();
            if (nextEvent != null && nextEvent.Time > _EOSTime)
                rslt = true;
            
            //if (_Scheduler.Clock > _EOSTime)

            return rslt;
        }

        private bool evaluateStopOnEvent()
        {
            bool rslt = false;

            return rslt;
        }

        /// <summary>
        /// Declare that the simulation ends when the simulation clock rearches the EOS time.
        /// </summary>
        /// <param name="eosTime">End-of-simulation Time</param>
        public void StopAtTime(double eosTime)
        {
            _Mode = EOSMode.StopAtTime;
            _EOSTime = eosTime;
        }

        /// <summary>
        /// Declare that the simulation ends when an coordinator's event occurs a certain number of times.
        /// </summary>
        /// <param name="eventName">Name of an event that belongs to Coordinator</param>
        /// <param name="frequency">Number of the event occurrence</param>
        public void StopOnEvent(string eventName, int frequency)
        {
            _Mode = EOSMode.StopOnEvents;

            _ObjectName = "Coordinator";
            _EventName = eventName;
            _EventFrequency = frequency;
        }

        /// <summary>
        /// Declare that the simulation ends when an object's event occurs a certain number of times.
        /// </summary>
        /// <param name="objectName">Name of an object</param>
        /// <param name="eventName">Name of an event</param>
        /// <param name="frequency">Number of the event occurrence</param>
        public void StopOnEvent(string objectName, string eventName, int frequency)
        {
            _Mode = EOSMode.StopOnEvents;

            _ObjectName = "Coordinator";
            _EventName = eventName;
            _EventFrequency = frequency;
        }

        public void Abort()
        {
            _IsAborted = true;
        }

        public bool CanSchedule(SimEvent e)
        {
            bool rslt = false;

            if (_Mode == EOSMode.StopAtTime)
            {
                if (e.Time <= _EOSTime)
                    rslt = true;

            }else if (_Mode == EOSMode.StopOnEvents)
            {
                rslt = true;
            }

            return rslt;
        }
        #endregion
    }
}
