﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation.Events
{
    public class EventScheduler
    {
        #region Member Variables
        /// <summary>
        /// Future Event List
        /// </summary>
        protected EventList<SimEvent> _FEL;

        //Archived Event List for debugging
        protected EventList<LocalEvent> _AEL;
        protected List<SimEventTrace> _EventTraces;

        /// <summary>
        /// evaluate the end-of-simulation condition
        /// </summary>
        protected EndOfSimulation _EOS;

        /// <summary>
        /// Simulation Clock
        /// </summary>
        protected double _Clock;

        /// <summary>
        /// Simulation Arguments 
        /// </summary>
        private Dictionary<string, object> _Args;

        /// <summary>
        /// contains the local events that schedule the event objects in other region.
        /// </summary>
        protected List<SimEvent> _BoundaryEvents;

        protected string _Parent;

        #endregion

        #region Properties
        public EventList<SimEvent> FEL
        {
            get { return _FEL; }
        }

        public List<SimEventTrace> EventTraces
        {
            get { return _EventTraces; }
        }

        public double Clock
        {
            get { return _Clock; }
        }

        public Dictionary<string, object> Arguments
        {
            get { return _Args; }
            set { _Args = value; }
        }

        /// <summary>
        /// Archived Event List
        /// </summary>
        public EventList<LocalEvent> AEL
        {
            get { return _AEL; }
        }
        /*
        /// <summary>
        /// Archived Event List
        /// </summary>
        public EventList<LocalEvent> EventTraces
        {
            get { return _AEL; }
        }
        */
        #endregion

        #region Constructors
        public EventScheduler(string parent)
        {
            _Parent = parent;
        }

        #endregion


        #region Initialization Methods
        public void Initialize(Dictionary<string, object> args)
        {
            _Args = args;
            _Clock = 0;

            _AEL = new EventList<LocalEvent>("AEL");
            _FEL = new EventList<SimEvent>("FEL");
            _EOS = new EndOfSimulation(this);
            _EventTraces = new List<SimEventTrace>();
            _BoundaryEvents = new List<SimEvent>();

            if (args != null)
            {
                if (args.ContainsKey("EOSTime"))
                {
                    int eosTime = int.Parse(args["EOSTime"].ToString());
                    StopAtTime(eosTime);
                }
            }

        }
        #endregion

        #region Event List Methods

        public void ArchiveLocalEvent(LocalEvent e)
        {
            _AEL.ScheduleEvent(e);

            SimEventTrace trace = null;
            if (e.Parameters.Count > 0)
            {
                string parameters = string.Empty;
                for (int i = 0; i < e.Parameters.Count; i++)
                {
                    object pm = e.Parameters[i];
                    parameters += pm.ToString();
                    if (i < e.Parameters.Count - 1)
                        parameters += ", ";
                }
                trace = new SimEventTrace(e.ID, e.Name, e.ObjectName, e.Time, parameters);
            }
            else
            {
                trace = new SimEventTrace(e.ID, e.Name, e.ObjectName, e.Time);
            }
            if (trace != null)
                _EventTraces.Add(trace);
        }

        public void CancelEvent(SimEvent e)
        {
            _FEL.CancelEvent(e);
        }

        public void CancelEvent(string eventName)
        {
            _FEL.CancelEvent(eventName);
        }

        public SimEvent PeekEvent()
        {
            SimEvent e = _FEL.PeekEvent();
            return e;
        }

        public SimEvent RetrieveEvent()
        {
            SimEvent e = _FEL.RetrieveEvent();

            return e;
        }

        /// <summary>
        /// Retrieve next event and advance the clock to the scheduled time of the next event.
        /// </summary>
        /// <returns></returns>
        public SimEvent RetrieveNextEvent()
        {
            SimEvent e = _FEL.RetrieveEvent();
            _Clock = e.Time;
            return e;
        }

        public void ScheduleEvent(SimEvent evt)
        {
            _FEL.ScheduleEvent(evt);
        }

        /*
        public void ScheduleEvent(string eventName, double time)
        {
            _FEL.ScheduleEvent(new SimEvent(eventName, time));
        }

        public void ScheduleEvent(string eventName, double eventTime, params object[] parameters)
        {
            SimEvent evt = new SimEvent(eventName, eventTime);

            if (parameters.Length > 0)
            {
                foreach (object param in parameters)
                    evt.Add(param);
            }
            //evt.Parameters.AddRange(parameters);

            _FEL.ScheduleEvent(evt);
        }
        */

        public LocalEvent ScheduleLocalEvent(string eventName, double time)
        {
            LocalEvent e = new LocalEvent(this._Parent, eventName, time);
            ScheduleLocalEvent(e);

            return e;
        }

        public void ScheduleLocalEvent(string eventName, double time, params object[] parameters)
        {
            LocalEvent e = new LocalEvent(this._Parent, eventName, time);
            foreach (object param in parameters)
                e.Parameters.Add(param);

            ScheduleLocalEvent(e);
        }

        public void ScheduleMirrorEvent(string objectid, string eventName, double time)
        {
            LocalEvent e = new LocalEvent(objectid, eventName, time);
            ScheduleLocalEvent(e);
        }

        public void ScheduleMirrorEvent(string objectid, string eventName, double time, params object[] parameters)
        {
            LocalEvent e = new LocalEvent(objectid, eventName, time);
            foreach (object param in parameters)
                e.Parameters.Add(param);

            ScheduleLocalEvent(e);
        }

        public void ScheduleLocalEvent(LocalEvent e)
        {
            if (e.ObjectName.Equals(_Parent))
            {
                _FEL.ScheduleEvent(e);
            }
            else
            {
                _BoundaryEvents.Add(e);
            }
        }
        #endregion

        #region EOS methods
        /// <summary>
        /// Declare that the simulation ends when the simulation clock rearches the EOS time.
        /// </summary>
        /// <param name="eosTime">End-of-simulation Time</param>
        public void StopAtTime(double time)
        {
            _EOS.StopAtTime(time);
        }

        /// <summary>
        /// Declare that the simulation ends when an coordinator's event occurs a certain number of times.
        /// </summary>
        /// <param name="eventName">Name of an event that belongs to Coordinator</param>
        /// <param name="frequency">Number of the event occurrence</param>
        public void StopOnEvent(string eventName, int frequency)
        {
            _EOS.StopOnEvent(eventName, frequency);
        }

        /// <summary>
        /// Declare that the simulation ends when an object's event occurs a certain number of times.
        /// </summary>
        /// <param name="objectName">Name of an object</param>
        /// <param name="eventName">Name of an event</param>
        /// <param name="frequency">Number of the event occurrence</param>
        public void StopOnEvent(string objectName, string eventName, int frequency)
        {
            _EOS.StopOnEvent(objectName, eventName, frequency);
        }

        public bool StopCondition
        {
            get { return _EOS.StopCondition; }
        }
        #endregion


        #region BoundaryEvents

        public bool HasBoundaryEvents()
        {
            return _BoundaryEvents.Count > 0;
        }

        public List<SimEvent> GetBoundaryEvents()
        {
            return _BoundaryEvents;
        }

        public void RemoveBoundaryEvents()
        {
            _BoundaryEvents.Clear();
        }

        #endregion
    }

    public class SimEventTrace
    {
        #region Member Variables
        private int _EventID;
        private string _EventName;
        private string _ObjectName;
        private double _EventTime;
        private string _EventParameters;
        #endregion

        #region Properties
        public int ID { get { return _EventID; } }
        public string EventName { get { return _EventName; } }
        public string ObjectName { get { return _ObjectName; } }
        public double Time { get { return _EventTime; } }
        public string Parameters { get { return _EventParameters; } }
        #endregion

        #region Constructors
        public SimEventTrace(int id, string eventName, string objectName, double time, string parameters)
        {
            _EventID = id;
            _EventName = eventName;
            _ObjectName = objectName;
            _EventTime = time;
            _EventParameters = parameters;
        }

        public SimEventTrace(int id, string eventName, string objectName, double time)
        {
            _EventID = id;
            _EventName = eventName;
            _ObjectName = objectName;
            _EventTime = time;
        }
        #endregion
    }
}
