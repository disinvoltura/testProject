﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DHKANG.SEA.Simulation.Events
{
    public class EventList<T> where T : SimEvent
    {
        #region Member Variables
        private string _Name;
        private List<T> _Events;
        #endregion

        #region Properties
        public int Count
        {
            get { return _Events.Count; }
        }
        public string Name
        {
            get { return _Name; }
        }
        public List<T> Values { get { return _Events; } }
        #endregion

        #region Indexer
        public T this[int idx]
        {
            get { return _Events[idx]; }
        }
        #endregion

        #region Constructors
        public EventList(string name)
        {
            _Events = new List<T>();
        }
        #endregion

        #region Methods
        public void Initialize()
        {
            _Events.Clear();
        }

        //public int Max = 0;
        //public double TimeCost = 0;
        public void ScheduleEvent(T evt)
        {
           // #if DEBUG
            //DateTime dt1 = DateTime.Now;
           // #endif
            
            if (_Events.Count == 0)
                _Events.Add(evt);
            else
            {
                bool isInserted = false;
                for (int i = 0; i < _Events.Count; i++)
                {
                    if (evt.Time < _Events[i].Time)
                    {
                        _Events.Insert(i, evt);
                        isInserted = true;
                        break;
                    }
                    else if (evt.Time == _Events[i].Time && evt.Priority > _Events[i].Priority)
                    {
                        _Events.Insert(i, evt);
                        isInserted = true;
                        break;
                    }
                }
                if (!isInserted)
                    _Events.Add(evt);
            }

            //if (_Events.Count > Max)
            //    Max = _Events.Count;

            //#if DEBUG
            //DateTime dt2 = DateTime.Now;
            //double timeToSchedule = dt2.Subtract(dt1).Seconds;
            //TimeCost+= timeToSchedule;
            //if (timeToSchedule >= 0.5)
            //    System.Diagnostics.Debug.WriteLine("[" + this.Name + "] ScheduleEvent took " +  timeToSchedule + " seconds.");
            //#endif 

        }

        //public void ScheduleEvent(T evt)
        //{
        //    if (_Events.Count == 0)
        //        _Events.Add(evt);
        //    else
        //    {
        //        bool isInserted = false;
        //        for (int i = 0; i < _Events.Count; i++)
        //        {
        //            if (evt.Time < _Events[i].Time)
        //            {
        //                _Events.Insert(i, evt);
        //                isInserted = true;
        //                break;
        //            }
        //        }
        //        if (!isInserted)
        //            _Events.Add(evt);
        //    }
        //}

        public bool CancelEvent(T cancelingEvent)
        {
            List<T> canceledEvents =
                (from evt in _Events
                 where evt.Name == cancelingEvent.Name
                 orderby evt.Time ascending
                 select evt).ToList<T>();

            bool rslt = false;
            if (canceledEvents != null && canceledEvents.Count > 0)
            {
                rslt = _Events.Remove(canceledEvents[0]);
            }

            return rslt;

        }

        public void CancelEvent(string eventName)
        {
            List<T> canceledEvents =
                (from evt in _Events
                 where evt.Name == eventName
                 orderby evt.Time ascending
                 select evt).ToList<T>();

            if (canceledEvents != null && canceledEvents.Count > 0)
                _Events.Remove(canceledEvents[0]);

        }

        public T RetrieveEvent()
        {
            T rslt = null;

            if (_Events.Count > 0)
            {
                rslt = _Events[0];
                _Events.RemoveAt(0);
            }

            return rslt;
        }

        public T PeekEvent()
        {
            T rslt = null;

            if (_Events.Count > 0)
            {
                rslt = _Events[0];
            }

            return rslt;
        }

        public override string ToString()
        {
            string rslt = string.Empty;

            for(int i = 0 ; i < _Events.Count; i++)
            {
                rslt += _Events[i].ToString();
                if (i < _Events.Count - 1)
                    rslt += ";"; 
            }

            return rslt;
        }

        public string ToShortString()
        {
            string rslt = string.Empty;

            for(int i = 0 ; i < _Events.Count; i++)
            {
                rslt += _Events[i].ToShortString();
                if (i < _Events.Count - 1)
                    rslt += ";"; 
            }

            return rslt;
        }
        #endregion
    }
}
