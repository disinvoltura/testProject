﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public static class DatabaseHelper
    {
        public static readonly string DATABASE_MYSQL = "MYSQL";
        public static readonly string DATABASE_SQLSERVER = "SQLSERVER";
        public static readonly string DATABASE_ORACLE = "ORACLE";

        public static bool TestDatabaseConnection(string dbtype, string connectionString)
        {
            if (dbtype.Equals(DatabaseHelper.DATABASE_MYSQL))
                return TestMySqlConnection(connectionString);
            else if (dbtype.Equals(DatabaseHelper.DATABASE_ORACLE))
                return TestOracleConnection(connectionString);
            else if (dbtype.Equals(DatabaseHelper.DATABASE_SQLSERVER))
                return TestSqlServerConnection(connectionString);

            return false;
        }

        private static bool TestMySqlConnection(string connectionString)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    return true;
                }
                catch (SqlException)
                {
                    return false;
                }
            }
        }

        private static bool TestSqlServerConnection(string connectionString)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    return true;
                }
                catch (SqlException)
                {
                    return false;
                }
            }
        }

        private static bool TestOracleConnection(string connectionString)
        {
            //TODO revise accordingly
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    return true;
                }
                catch (SqlException)
                {
                    return false;
                }
            }
        }
    }
}
