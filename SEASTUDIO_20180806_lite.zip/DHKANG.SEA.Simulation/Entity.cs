﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.OOEG.Simulation
{
    public class Entity
    {
        private static int InternalID;
        #region Member Variables
        private int _ID;
        private string _Name;
        private Dictionary<string, object> _Attributes;

        #endregion

        #region Properties
        public object this[string name]
        {
            get { return _Attributes[name]; }
            set { _Attributes[name] = value; }
        }
        #endregion

        #region Constructors
        public Entity()
        {
            _ID = Entity.InternalID++;
            _Name = "Entity " + _ID;
            _Attributes = new Dictionary<string, object>();
        }
        #endregion

        #region Methods
        public object getAttribute(string name)
        {
            object rslt = null;
            if (_Attributes.ContainsKey(name))
                rslt = _Attributes[name];
            return rslt;
        }

        public void setAttribute(string name, object value)
        {
            if (_Attributes.ContainsKey(name))
                _Attributes[name] = value;
            else
                _Attributes.Add(name, value);
        }
        #endregion

    }
}
