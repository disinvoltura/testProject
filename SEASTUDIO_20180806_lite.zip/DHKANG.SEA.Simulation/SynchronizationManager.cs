﻿using DHKANG.SEA.Simulation.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public enum SMState { START, FIND_TAG, RECEIVE, GET_MDP, STOP };
    public enum SMMode { FastForward, Scaled, Parallel };
    public class SynchronizationManager
    {
        #region Member Variables
        private Thread _THREAD;
        private SMState _STATE;
        private SMMode _Mode = SMMode.FastForward;

        private int _Na; //# of FSM
        private double _Now;
        private int _n;
        private int _m;

        private SortedList<string, TAR> _TAR_T; //key: ID of FSM, value: TAR
        private SortedList<string, double> _TAR_TMap; //key: ID of FSM, value: time of TAR
        private double[] _TIME; //time of TAR

        private List<TAR> _FEL;

        private List<MSR> _MSR_Q;
        private List<MDP> _MDP_Q;
        private List<INPUT> _inputs;

        //private List<MessageCoupling> _MCL;
        private Dictionary<string, List<MessageCoupling>> _MCL;

        private List<MessageTrace> _MessageTraces;
        private double _EOSTime;

        private ISimulationView _View;

        #endregion

        #region Member Variables for Scaled Real-time Execution
        private double _ScaleFactor = 0;
        private System.Timers.Timer _Timer;
        #endregion

        #region Events
        public event SimulationEndEventHandler SimulationEnded;
        //public event LogHandler Logged;
        //public event MessageLogHandler MessageLogged;
        public event SimulationClockAdvancedEventHandler ClockAdvanced;
        public event SimulationClockAdvancingEventHandler ClockAdvancing;

        #endregion

        #region Properties
        public double Clock
        {
            get { return _Now; }
        }

        public SMMode Mode
        {
            get { return _Mode; }
        }

        public SMState STATE
        {
            get { return _STATE; }
        }

        public List<MessageTrace> MessageTraces { get { return _MessageTraces; } }

        public double ScaleFactor
        {
            get { return _ScaleFactor; }
            set
            {
                _ScaleFactor = Math.Round(value, 2);
            }
        }
        #endregion

        #region Constructor

        public SynchronizationManager(int na, bool isParllel) : this(na)
        {
            if (isParllel)
            {
                _Mode = SMMode.Parallel;
            }
        }

        public SynchronizationManager(int na)
        {
            _Mode = SMMode.FastForward;
            _Na = na;
            _Now = 0.0;
            _n = 0;

            _TAR_T = new SortedList<string, TAR>(_Na);
            _TAR_TMap = new SortedList<string, double>(_Na);
            _TIME = new double[_Na];
            _FEL = new List<TAR>();

            _MSR_Q = new List<MSR>();
            _MDP_Q = new List<MDP>();
            _inputs = new List<INPUT>();

            //_MCL = new List<MessageCoupling>();
            _MCL = new Dictionary<string, List<MessageCoupling>>();
            _MessageTraces = new List<MessageTrace>();

            _THREAD = new Thread(new ThreadStart(DoRun));//dhkang 2010.09.11

            //Scaled Real-time Executiion
            _ScaleFactor = 0;
        }

        public SynchronizationManager(int na, double scalefactor)
            : this(na)
        {
            _ScaleFactor = scalefactor;
            if (scalefactor > 0)
            {
                _Timer = new System.Timers.Timer();
                _Timer.AutoReset = false;
                _Timer.Elapsed += new System.Timers.ElapsedEventHandler(OnTimerEllapsed);
                _Mode = SMMode.Scaled;
            }
            else if (scalefactor == 0)
            {
                _Mode = SMMode.FastForward;
            }
        }

        public SynchronizationManager(int na, double scalefactor, ISimulationView view)
            : this(na)
        {
            _ScaleFactor = scalefactor;
            _View = view;

            if (scalefactor > 0)
            {
                _Timer = new System.Timers.Timer();
                _Timer.AutoReset = false;
                _Timer.Elapsed += new System.Timers.ElapsedEventHandler(OnTimerEllapsed);
                _Mode = SMMode.Scaled;
            }
            else if (scalefactor == 0)
            {
                _Mode = SMMode.FastForward;
            }
        }

        #endregion

        private string _NextState;

        #region for debug (remove later
        private DateTime _StartTime;

        #endregion

        private void DoRun()
        {
            _NextState = "Start";

            while (STATE != SMState.STOP)
            {
                if (_NextState == "Start")
                    State_Start();
                else if (_NextState == "Find_TAG")
                    State_Find_TAG();
                else if (_NextState == "Receive")
                    State_Receive();
                else if (_NextState == "Get_MDP")
                    State_Get_MDP();
                else if (_NextState == "STOP")
                    State_Stop();
            }
        }

        private void DoFastForwardRun()
        {
            _NextState = "Start";

            while (STATE != SMState.STOP)
            {
                if (_NextState == "Start")
                    State_Start();
                else if (_NextState == "Find_TAG")
                    State_Find_TAG_FastForward();
                else if (_NextState == "Receive")
                    State_Receive();
                else if (_NextState == "Get_MDP")
                    State_Get_MDP();
                else if (_NextState == "STOP")
                    State_Stop();
            }
        }

        private void DoScaledRun()
        {
            _NextState = "Start";

            while (STATE != SMState.STOP)
            {
                if (_NextState == "Start")
                    State_Start();
                else if (_NextState == "Find_TAG")
                    State_Find_TAG_Scaled();
                else if (_NextState == "Receive")
                    State_Receive();
                else if (_NextState == "Get_MDP")
                    State_Get_MDP();
                else if (_NextState == "STOP")
                    State_Stop();
            }
        }


        private void DoParallelRun()
        {
            _NextState = "Start";

            while (STATE != SMState.STOP)
            {
                if (_NextState == "Start")
                    State_Start();
                else if (_NextState == "Find_TAG")
                    State_Find_TAG_Parallel();
                else if (_NextState == "Receive")
                    State_Receive();
                else if (_NextState == "Get_MDP")
                    State_Get_MDP();
                else if (_NextState == "STOP")
                    State_Stop();
            }
        }

        #region Public Methods
        public void Start(double eosTime)
        {
            _EOSTime = eosTime;

            _StartTime = DateTime.Now;
            if (_Mode == SMMode.FastForward)
            {
                _THREAD = new Thread(new ThreadStart(DoRun));//dhkang 2010.09.11
            }
            else if (_Mode == SMMode.Scaled)
            {
                _THREAD = new Thread(new ThreadStart(DoScaledRun));//dhkang 2010.09.11
            }
            else if (_Mode == SMMode.Parallel)
            {
                _THREAD = new Thread(new ThreadStart(DoParallelRun));//dhkang 2010.09.11
            }
            if (_THREAD != null)
                _THREAD.Start();
        }

        public void Stop()
        {
            System.Diagnostics.Debug.WriteLine("[SM] stopped.");

            if (_TAR_T.Count > 0)
            {
                foreach (TAR tar in _TAR_T.Values)
                    tar.FSM.Stop();
            }
            try
            {
                if (_THREAD.ThreadState.Equals(ThreadState.Running))
                    //if (_THREAD.ThreadState.ToString().Equals(ThreadState.Running.ToString()))
                    _THREAD.Abort();
                else if (_THREAD.ThreadState.Equals(ThreadState.Suspended))
                {
                    _THREAD.Resume(); _THREAD.Abort();
                }
                else
                {
                    _THREAD.Suspend();
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.ToString());
            }

            _STATE = SMState.STOP;
        }

        public void Pause()
        {
            System.Diagnostics.Debug.WriteLine("[SM] paused.");
            if (_THREAD.IsAlive)
                _THREAD.Suspend();
        }

        public void Resume()
        {
            System.Diagnostics.Debug.WriteLine("[SM] resumed.");

            if (_THREAD.ThreadState == ThreadState.Suspended)
                _THREAD.Resume();
        }

        public void Send_Output(InputType type, Message msg)
        {
            INPUT input = new INPUT(type, msg);
            if (input != null)
            {
                _inputs.Add(input);

                if (type == InputType.MSR)
                {
                    MSR msr = (MSR)msg;
                    //Logged("MSR", msr.FSM.ID + "->" + "MSR(" + msr.MsgData.ToString() + ")", _Now);
                    //MessageLogged(_Now, "MSR", msr.FSM.ID, msr.Msg, msr.MsgData);
                }
                else if (type == InputType.TAR)
                {
                    TAR tar = (TAR)msg;
                    //Logged("TAR", tar.FSM.ID, _Now);
                }
            }
        }
        #endregion

        #region State Methods
        private void State_Start()
        {
            System.Diagnostics.Debug.WriteLine("[SM] State_Start()");

            _STATE = SMState.START;
            while (_n < _Na)
            {
                INPUT INPUT = Get_Input();
                if (INPUT != null && INPUT.Type == InputType.TAR)
                {
                    TAR tar = INPUT.Record as TAR;
                    _TAR_T.Add(tar.FSM.ID, tar);
                    _TAR_TMap.Add(tar.FSM.ID, tar.Time);
                    schedule_TAR(tar);
                    _n++;

                    //System.Diagnostics.Debug.WriteLine(tar.ToString());
                }
            }

            double t1 = DateTime.Now.Subtract(_StartTime).TotalSeconds;
            System.Diagnostics.Debug.WriteLine("[SM] SyncManager gets all TARs from atomic simulators (" + t1 + ").");
            _NextState = "Find_TAG"; //dhkang 2010.09.11
            //State_Find_TAG();
        }

        private void State_Find_TAG()
        {
            System.Diagnostics.Debug.WriteLine("[SM] State_Find_TAG()");

            _STATE = SMState.FIND_TAG;

            //List<TAG> tags = new List<TAG>();
            TAG tag = null;
            bool founded = false;

            //Find(out tag, out founded);

            if (_FEL.Count == 0 || _FEL[0].Time == double.MaxValue)
            {
                tag = null;
                //tags = null;
                founded = false;

                System.Diagnostics.Debug.WriteLine("[SM] - No TAG is found");
            }
            else
            {

                TAR tar = retrieve_TAR();
                tag = new TAG(tar.Time, tar.FSM);

                /*
                List<TAR> tars = retrieve_TAR_Parallel();
                foreach(TAR tar in tars)
                {
                    TAG tag = new TAG(tar.Time, tar.FSM);
                    tags.Add(tag);
                }
                */
                founded = true;

                System.Diagnostics.Debug.WriteLine("[SM] - TAG is found (" + tar.Time + "," + tar.FSM.ID + " is found");
                //System.Diagnostics.Debug.WriteLine("[SM] - TAG is found (" + tars.Count + ")");
                //foreach(TAR tar in tars)
                //    System.Diagnostics.Debug.WriteLine("[SM] - TAG (" + tar.Time +"," + tar.FSM.ID +" is found");
            }

            double nextTime = _Now;
            if (founded && tag != null)
            {
                if (tag.FSM.ID.ToLower().Equals("terminator") ||
                    tag.Now > _EOSTime)
                    DoStop();
                else
                {
                    DoAdvaneTime(tag);
                }

                if (tag.Now > nextTime)
                {
                    nextTime = tag.Now;

                    if (ClockAdvanced != null && ClockAdvanced.GetInvocationList().Length > 0)
                    {
                        //System.Diagnostics.Trace.WriteLine("[SM] Clock advanced to " + tag.Now);
                        ClockAdvanced(nextTime);
                    }
                }
            }
            else
            {
                DoStop();
            }

            /*
            if (founded && tags != null && tags.Count>0)// != null)
            {
                if (tags[0].Now > _EOSTime)
                {
                    System.Diagnostics.Debug.Write("End of Simulation...");
                    DoStop();
                }
                else
                {
                    DoAdvaneTime(tags);
                }

                nextTime = tags[0].Now;
                if (ClockAdvanced != null && ClockAdvanced.GetInvocationList().Length > 0)
                {
                    //System.Diagnostics.Trace.WriteLine("[SM] Clock advanced to " + tag.Now);
                    ClockAdvanced(nextTime);
                }
            }
            else
            {
                DoStop();
            }
            */
        }

        private void State_Find_TAG_FastForward()
        {
            System.Diagnostics.Debug.WriteLine("[SM] State_Find_TAG_Fastforward()");

            _STATE = SMState.FIND_TAG;

            TAG tag = null;
            bool founded = false;
            if (_FEL.Count == 0 || _FEL[0].Time == double.MaxValue)
            {
                tag = null;
                founded = false;

                System.Diagnostics.Debug.WriteLine("[SM] - No TAG is found");
            }
            else
            {
                TAR tar = retrieve_TAR();
                tag = new TAG(tar.Time, tar.FSM);
                founded = true;

                System.Diagnostics.Debug.WriteLine("[SM] - TAG is found (" + tar.Time + "," + tar.FSM.ID + " is found");
            }

            double nextTime = _Now;
            if (founded && tag != null)
            {
                //if (tag.FSM.ID.ToLower().Equals("terminator") ||
                if (tag.Now > _EOSTime)
                    DoStop();
                else
                {
                    //DoAdvaneFastForwardTime(tag);
                    _Now = tag.Now;
                    tag.FSM.Send_Output(InputType.TAG, tag);
                    _m = 1;

                    _NextState = "Receive";
                }

                if (tag.Now > nextTime)
                {
                    nextTime = tag.Now;

                    if (ClockAdvanced != null && ClockAdvanced.GetInvocationList().Length > 0)
                    {
                        ClockAdvanced(nextTime);
                    }
                }
            }
            else
            {
                DoStop();
            }
        }

        private void State_Find_TAG_Scaled()
        {
            System.Diagnostics.Debug.WriteLine("[SM] State_Find_TAG_Scaled()");

            _STATE = SMState.FIND_TAG;

            TAG tag = null;
            bool founded = false;

            if (_FEL.Count == 0 || _FEL[0].Time == double.MaxValue)
            {
                tag = null;
                founded = false;

                System.Diagnostics.Debug.WriteLine("[SM] - No TAG is found");
            }
            else
            {
                TAR tar = retrieve_TAR();
                tag = new TAG(tar.Time, tar.FSM);

                founded = true;

                System.Diagnostics.Debug.WriteLine("[SM] - TAG is found (" + tar.Time + "," + tar.FSM.ID + " is found");
                printTARTable();
            }

            double nextTime = _Now;
            if (founded && tag != null)
            {
                //if (tag.FSM.ID.ToLower().Equals("terminator") ||
                if (tag.Now > _EOSTime)
                    DoStop();
                else
                {
                    DoAdvanceScaledTime(tag);
                }

                if (tag.Now > nextTime)
                {
                    nextTime = tag.Now;

                    if (ClockAdvanced != null && ClockAdvanced.GetInvocationList().Length > 0)
                    {
                        ClockAdvanced(nextTime);
                    }

                    double prog = (tag.Now - _LastViewUpdateClock) / _EOSTime;
                    if (prog > 0.01)
                    {
                        _View.UpdateView(tag.Now);
                        _LastViewUpdateClock = tag.Now;
                    }

                }
            }
            else
            {
                DoStop();
            }
        }
        private double _LastViewUpdateClock;

        private void State_Find_TAG_Parallel()
        {
            //System.Diagnostics.Debug.WriteLine("[SM] State_Find_TAG()");

            _STATE = SMState.FIND_TAG;

            List<TAG> tags = new List<TAG>();
            bool founded = false;

            if (_FEL.Count == 0 || _FEL[0].Time == double.MaxValue)
            {
                tags = null;
                founded = false;

                System.Diagnostics.Debug.WriteLine("[SM] - No TAG is found");
            }
            else
            {
                List<TAR> tars = retrieve_TAR_Parallel();
                foreach (TAR tar in tars)
                {
                    TAG tag = new TAG(tar.Time, tar.FSM);
                    tags.Add(tag);
                }
                founded = true;

                /*
                System.Diagnostics.Debug.WriteLine("[SM] - TAG is found (" + tars.Count + ") ---------------");
                foreach(TAR tar in tars)
                    System.Diagnostics.Debug.WriteLine("[SM] - TAG (" + tar.Time +"," + tar.FSM.ID +" is found");
                */
            }

            double nextTime = _Now;
            if (founded && tags != null)
            {
                if (tags[0].Now > _EOSTime)
                    DoStop();
                else
                {
                    //DoAdvanceParallelTime(tag);
                    _Now = tags[0].Now;

                    /*
                    Parallel.ForEach(tags, (tag) =>
                    {
                        tag.FSM.Send_Output(InputType.TAG, tag);
                    });
                    */

                    foreach (TAG tag in tags)
                    {
                        tag.FSM.Send_Output(InputType.TAG, tag);
                    }
                    _m = tags.Count;

                    _NextState = "Receive"; //dhkang 2010.09.11
                }

                if (tags[0].Now > nextTime)
                {
                    nextTime = tags[0].Now;

                    if (ClockAdvanced != null && ClockAdvanced.GetInvocationList().Length > 0)
                    {
                        //System.Diagnostics.Trace.WriteLine("[SM] Clock advanced to " + tag.Now);
                        ClockAdvanced(nextTime);
                    }
                }
            }
            else
            {
                DoStop();
            }

            /*
            if (founded && tags != null && tags.Count>0)// != null)
            {
                if (tags[0].Now > _EOSTime)
                {
                    System.Diagnostics.Debug.Write("End of Simulation...");
                    DoStop();
                }
                else
                {
                    DoAdvaneTime(tags);
                }

                nextTime = tags[0].Now;
                if (ClockAdvanced != null && ClockAdvanced.GetInvocationList().Length > 0)
                {
                    //System.Diagnostics.Trace.WriteLine("[SM] Clock advanced to " + tag.Now);
                    ClockAdvanced(nextTime);
                }
            }
            else
            {
                DoStop();
            }
            */
        }

        private void DoStop()
        {
            foreach (TAR tar in _TAR_T.Values)
            {
                MDP mdp = new MDP(KeyWords.STOP.ToString(), _Now, tar.FSM);
                tar.FSM.Send_Output(InputType.MDP, mdp);

                //Logged("MDP", "SyncManager > (STOP) > " + tar.FSM.ID, _Now);
                //MessageLogged(_Now, "MDP", tar.FSM.ID, "STOP", null);
            }

            _NextState = "STOP"; //dhkang 2010.09.11

        }

        private TAG _CurrentTAG;
        private bool _IsInterrupted;
        private DateTime _LastStartTime;
        private double _ScaledTimeDelay;
        private bool _IsScaledRealTime = false;

        private int _RealTimeStep = 100;//milliseconds

        private void DoAdvaneTime(TAG tag)
        {
            do
            {
                if (_ScaleFactor == 0)
                    break;

                double actualTimeDelay = ((tag.Now - _Now) * 1000);
                double scaledTimeDelay = (int)(actualTimeDelay / _ScaleFactor);

                double elapsedTimeDelay = 0;
                if (scaledTimeDelay > _RealTimeStep)
                {
                    elapsedTimeDelay = _RealTimeStep * _ScaleFactor / 1000; ;
                    Thread.Sleep(_RealTimeStep);
                }
                else if (scaledTimeDelay > 0 && scaledTimeDelay <= _RealTimeStep)
                {
                    Thread.Sleep((int)scaledTimeDelay);
                    break;
                }
                else if (scaledTimeDelay == 0)
                    break;

                _Now += elapsedTimeDelay;
            } while (true);

            _Now = tag.Now;
            tag.FSM.Send_Output(InputType.TAG, tag);
            _m = 1;

            _NextState = "Receive"; //dhkang 2010.09.11
            //State_Receive();
        }

        private void DoAdvanceFastForwardTime(TAG tag)
        {
            _Now = tag.Now;
            tag.FSM.Send_Output(InputType.TAG, tag);
            _m = 1;

            _NextState = "Receive"; //dhkang 2010.09.11
        }

        private void DoAdvanceScaledTime(TAG tag)
        {
            do
            {
                double actualTimeDelay = ((tag.Now - _Now) * 1000);
                double scaledTimeDelay = (int)(actualTimeDelay / _ScaleFactor);

                double elapsedTimeDelay = 0;
                if (scaledTimeDelay > _RealTimeStep)
                {
                    elapsedTimeDelay = _RealTimeStep * _ScaleFactor / 1000; ;
                    Thread.Sleep(_RealTimeStep);
                }
                else if (scaledTimeDelay > 0 && scaledTimeDelay <= _RealTimeStep)
                {
                    Thread.Sleep((int)scaledTimeDelay);
                    break;
                }
                else if (scaledTimeDelay == 0)
                    break;

                _Now += elapsedTimeDelay;
            } while (true);

            _Now = tag.Now;
            tag.FSM.Send_Output(InputType.TAG, tag);
            _m = 1;

            _NextState = "Receive"; //dhkang 2010.09.11
        }

        private void DoAdvanceParallelTime(List<TAG> tags)
        {
            //Logged("TAG", "TAG(" + _Now + ")->" + tag.FSM.ID, _Now);

            _Now = tags[0].Now;

            foreach (TAG tag in tags)
            {
                tag.FSM.Send_Output(InputType.TAG, tag);
            }
            _m = tags.Count;

            _NextState = "Receive"; //dhkang 2010.09.11
            //State_Receive();
        }

        private void OnTimerEllapsed(object obj, System.Timers.ElapsedEventArgs args)
        {
            if (_CurrentTAG != null)
            {
                _Now = _CurrentTAG.Now;
                _CurrentTAG.FSM.Send_Output(InputType.TAG, _CurrentTAG);
                _m = 1;

                _CurrentTAG = null;
                _NextState = "Receive"; //dhkang 2010.09.11
                //State_Receive();
            }
        }

        private void State_Receive()
        {
            System.Diagnostics.Debug.WriteLine("[SM] State_Receive()");

            _STATE = SMState.RECEIVE;
            INPUT input = null;
            while (true)
            {
                input = Get_Input();
                if (input != null && (input.Type == InputType.MSR || input.Type == InputType.TAR))
                    break;
            }

            if (input.Type == InputType.MSR)
            {
                MSR msr = input.Record as MSR;
                _MSR_Q.Add(msr); //msr -> MSR_Q (enqueue)

                _NextState = "Receive"; //dhkang 2010.09.11    
            }
            else if (input.Type == InputType.TAR)
            {
                TAR tar = input.Record as TAR;
                _m--;

                updateTABLE(tar);

                if (_m == 0)
                {
                    _NextState = "Get_MDP"; //dhkang 2010.09.11
                    //State_Get_MDP();
                }
                else
                {
                    _NextState = "Receive"; //dhkang 2010.09.11
                    //State_Receive();
                }
            }
        }

        private void State_Get_MDP()
        {
            System.Diagnostics.Debug.WriteLine("[SM] State_Get_MDP()");

            _STATE = SMState.GET_MDP;

            Get_MDP(out _m);

            if (_m > 0)
            {
                for (int i = 0; i < _m; i++)
                {
                    MDP mdp = _MDP_Q[0]; //mdp <- MDP_Q (dequeue)
                    _MDP_Q.RemoveAt(0);

                    //Logged("MDP", "MDP(" + mdp.Msg + ")->" + mdp.FSM.ID, _Now);
                    //MessageLogged(_Now, "MDP", mdp.FSM.ID, mdp.Msg, mdp.MsgData.Clone());

                    remove_TAR(mdp.FSM.ID);
                    mdp.FSM.Send_Output(InputType.MDP, mdp);
                }

                _NextState = "Receive"; //dhkang 2010.09.11
                //State_Receive();
            }
            else
            {
                _NextState = "Find_TAG"; //dhkang 2010.09.11
                //State_Find_TAG();
            }
        }

        private void State_Stop()
        {
            System.Diagnostics.Debug.WriteLine("[SM] State_Stop()");

            _STATE = SMState.STOP;
            //Logged(KeyWords.SyncManager.ToString(), KeyWords.STOP.ToString(), Clock);

            foreach (TAR t in _TAR_T.Values)
            {
                t.FSM.OnSimulationEnded(_Now);
            }

            double t1 = DateTime.Now.Subtract(_StartTime).TotalSeconds;
            System.Diagnostics.Debug.WriteLine("[SM] state_stop ( " + t1 + ").");

            if (SimulationEnded.GetInvocationList().Length > 0)
                SimulationEnded(_Now);
        }
        #endregion

        #region Local Methods
        private INPUT Get_Input()
        {
            if (_inputs.Count > 0)
            {
                try
                {
                    if (_inputs[0] != null)
                    {
                        INPUT input = new INPUT(_inputs[0].Type, _inputs[0].Record);
                        _inputs.RemoveAt(0);
                        return input;
                    }
                    else return null;
                }
                catch (Exception ex)
                {
                    //Logged(KeyWords.SyncManager.ToString(), ex.Message + " at Get_Input()", _Now);
                    return null;
                }
            }
            else return null;
        }

        private void Find(out TAG tag, out bool founded)
        {
            tag = null;
            founded = false;

            int i = 0;
            foreach (double time in _TAR_TMap.Values)
            {
                _TIME[i] = time;
                i++;
            }
            Array.Sort(_TIME);

            if (_TIME[0] != double.MaxValue)
            {
                founded = true;
                string key = _TAR_TMap.Keys[_TAR_TMap.IndexOfValue(_TIME[0])];
                tag = new TAG(_TIME[0], _TAR_T[key].FSM);
            }
            else //deadlock check
            {
                foreach (TAR tar in _TAR_T.Values)
                {
                    if (tar.Time == double.MaxValue)
                    {
                        foreach (string s in tar.Inputs)
                        {
                            if (s.ToUpper() != KeyWords.NULL.ToString() && s.ToUpper() != KeyWords.STOP.ToString())
                            {
                                //System.Diagnostics.Debug.WriteLine(tar.FSM.ID + " waits for " + s.ToString() + " but deadlock is occurred in Select() method at " + _Now);
                                //Logged(KeyWords.SyncManager.ToString(), tar.FSM.ID + " waits for " + s.ToString() + " but deadlock is occurred at Select()", _Now);
                            }
                        }
                    }
                }
            }
        }

        public void AddCoupling(MessageCoupling MC)
        {
            //_MCL.Add(MC);

            string key = MC.Source_ID + "_" + MC.Source_Msg;
            if (_MCL.ContainsKey(key))
            {
                List<MessageCoupling> list = _MCL[key];
                list.Add(MC);
            }
            else
            {
                List<MessageCoupling> list = new List<MessageCoupling>();
                list.Add(MC);
                _MCL.Add(key, list);
            }
        }

        public void AddCoupling(string S_ID, string S_Msg, string D_ID, string D_Msg)
        {
            MessageCoupling MCL = new MessageCoupling(S_ID, S_Msg, D_ID, D_Msg);
            this.AddCoupling(MCL);
            //_MCL.Add(MCL);
        }

        public void AddCoupling(string S_ID, string S_Msg, string parameters, string D_ID, string D_Msg)
        {
            MessageCoupling MCL = new MessageCoupling(S_ID, S_Msg, parameters, D_ID, D_Msg);
            this.AddCoupling(MCL);
            //_MCL.Add(MCL);
        }

        private void Get_MDP(out int m)
        {
            m = 0;
            while (_MSR_Q.Count > 0 && m == 0)
            {
                MSR MSR = _MSR_Q[0]; //MSR<-MSR-Q (dequeue)
                _MSR_Q.RemoveAt(0);

                if (MSR.Msg.Equals("OVER"))
                {
                    //terminator가 OVER 를 보낼 경우
                    foreach (TAR t in _TAR_T.Values)
                    {
                        if (t.Inputs.Contains(MSR.Msg))
                        {
                            MDP MDP = null;
                            if (MSR.MsgData.Count > 0)
                                MDP = new MDP(MSR.MsgData, _Now, t.FSM);
                            else
                                MDP = new MDP(MSR.Msg, _Now, t.FSM);

                            _MDP_Q.Add(MDP);
                            m++;
                        }
                    }
                }
                else
                {
                    string key = MSR.FSM.ID + "_" + MSR.Msg;
                    if (_MCL.ContainsKey(key))
                    {
                        List<MessageCoupling> targetMCL = _MCL[key];
                        foreach (MessageCoupling MC in targetMCL)
                        {
                            //TAR t에 실제로 기다리고 있는지 확인하고 
                            //확인되면 바로 MDP 만들어서 보내준다. 
                            if (!_TAR_T.ContainsKey(MC.Destination_ID))
                            {
                                System.Diagnostics.Trace.WriteLine("[SM] invalid message coupling: (" + MC.Source_ID + "," + MC.Destination_ID + ")");
                                continue;
                            }

                            TAR t = _TAR_T[MC.Destination_ID];

                            if (t == null)
                                continue;

                            if (t.Inputs.Contains(MC.Destination_Msg))
                            {
                                MDP MDP = null;
                                if (MSR.MsgData.Count > 0)
                                {
                                    MSR.MsgData.MessageName = MC.Destination_Msg;

                                    if (MC.HasParameters)
                                    {
                                        MDP = new Simulation.MDP(MSR.MsgData.MessageName, _Now, t.FSM);

                                        foreach (string sp in MC.Parameters.Keys)
                                        {
                                            string dp = MC.Parameters[sp];
                                            MDP.Data[dp] = MSR.MsgData[sp];
                                        }
                                    }
                                    else
                                    {
                                        MDP = new MDP(MSR.MsgData, _Now, t.FSM);
                                    }
                                }
                                else
                                {
                                    MDP = new MDP(MC.Destination_Msg, _Now, t.FSM);
                                }

                                MDP.FromFSM = MSR.FSM.ID;
                                _MDP_Q.Add(MDP);
                                m++;

                                if (_Mode == SMMode.Scaled)
                                {
                                    MessageTrace mt = null;
                                    int currentEventOrStateId;
                                    //Transform Message into Event
                                    if (t.FSM is EventObjectSimulator)
                                    {
                                        SimEvent nextEvent = null;
                                        nextEvent = new LocalEvent(t.FSM.ID, MDP.Name, MDP.Now);
                                        foreach (object value in MDP.Data.Values)
                                        {
                                            nextEvent.Parameters.Add(value);
                                        }
                                        MDP.Data["event"] = nextEvent;
                                        currentEventOrStateId = nextEvent.ID;
                                    }
                                    else
                                    {
                                        currentEventOrStateId = t.FSM.CurrentEventorStateId;
                                    }
                                    mt = new MessageTrace(
                                        MSR.FSM.ID,
                                        MSR.CurrentEventorStateId,
                                        MC.Destination_Msg,
                                        t.FSM.ID,
                                        currentEventOrStateId,
                                        _Now);

                                    _MessageTraces.Add(mt);
                                }
                            }
                        }
                    }
                }
            }
        }

        private void Get_MDP1(out int m)
        {
            m = 0;
            while (_MSR_Q.Count > 0 && m == 0)
            {
                MSR MSR = _MSR_Q[0]; //MSR<-MSR-Q (dequeue)
                _MSR_Q.RemoveAt(0);
                foreach (TAR t in _TAR_T.Values)
                {
                    if (t.Inputs.Contains(MSR.Msg))
                    {
                        MDP MDP = null;
                        if (MSR.MsgData.Count > 0)
                            MDP = new MDP(MSR.MsgData, _Now, t.FSM);
                        else
                            MDP = new MDP(MSR.Msg, _Now, t.FSM);

                        _MDP_Q.Add(MDP);
                        m++;
                    }
                }
            }
        }

        private void updateTABLE(TAR tar)
        {
            _TAR_T[tar.FSM.ID] = tar;
            _TAR_TMap[tar.FSM.ID] = tar.Time;

            schedule_TAR(tar);
        }

        private void schedule_TAR(TAR tar)
        {
            if (_FEL.Count == 0)
            {
                _FEL.Add(tar);
            }
            else
            {
                bool isInserted = false;
                for (int i = 0; i < _FEL.Count; i++)
                {
                    if (tar.Time < _FEL[i].Time)
                    {
                        _FEL.Insert(i, tar);
                        isInserted = true;
                        break;
                    }
                    else if (tar.Time == _FEL[i].Time)
                    {
                        if (_FEL[i].FSM.ID.ToLower() == "terminator")
                        {
                            _FEL.Insert(i, tar);
                            isInserted = true;
                            break;
                        }
                    }
                }

                if (!isInserted)
                {
                    _FEL.Add(tar);
                }
            }
        }

        private TAR retrieve_TAR()
        {
            TAR rslt = null;

            if (_FEL.Count > 0)
            {
                rslt = _FEL[0];
                _FEL.RemoveAt(0);

            }

            return rslt;
        }

        private void printTARTable()
        {
            foreach(TAR t in _FEL)
            {
                string inputs = "";
                t.Inputs.ForEach(ti => inputs += ti + ",");
                System.Diagnostics.Debug.WriteLine(t.FSM.ID + ", @" + t.Time + ", " + inputs);
            }
        }

        private List<TAR> retrieve_TAR_Parallel()
        {
            List<TAR> rslt = new List<TAR>();

            if (_FEL.Count > 0)
            {
                TAR firstTAR = _FEL[0];

                bool endSearch = false;
                do
                {
                    if (firstTAR.Time.Equals(_FEL[0].Time))
                    {
                        rslt.Add(_FEL[0]);
                        _FEL.RemoveAt(0);
                    }
                    else
                        endSearch = true;
                } while (!endSearch && _FEL.Count > 0);
            }

            return rslt;
        }


        private void remove_TAR(string id)
        {
            int idx = -1;
            for (int i = 0; i < _FEL.Count; i++)
            {
                if (_FEL[i].FSM.ID == id)
                {
                    idx = i;
                    break;
                }
            }
            if (idx >= 0)
                _FEL.RemoveAt(idx);
        }
        #endregion
    }
}
