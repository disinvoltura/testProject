﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public class MessageCoupling
    {
        #region Member Variables
        public string Source_ID;
        public string Source_Msg;
        public string Destination_ID;
        public string Destination_Msg;
        public Dictionary<string, string> Parameters;
        #endregion

        #region Properties
        /// <summary>
        /// return true if the parameter mappings exist
        /// </summary>
        public bool HasParameters
        {
            get { return this.Parameters.Count > 0 ? true : false; }
        }
        #endregion

        #region Constructors
        public MessageCoupling(string sId, string sMsg, string dId, string dMsg)
        {
            this.Source_ID = sId;
            this.Source_Msg = sMsg;
            this.Destination_ID = dId;
            this.Destination_Msg = dMsg;
            this.Parameters = new Dictionary<string, string>();
        }

        public MessageCoupling(string sId, string sMsg, string parameters, string dId, string dMsg)
            : this(sId, sMsg, dId, dMsg)
        {
            if (string.IsNullOrEmpty(parameters))
                return;

            this.Parameters = new Dictionary<string, string>();
            string[] pairs = parameters.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach(string p in pairs)
            {
                string[] prs = p.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
                this.Parameters.Add(prs[0], prs[1]);
            }
        }
        #endregion
    }
}
