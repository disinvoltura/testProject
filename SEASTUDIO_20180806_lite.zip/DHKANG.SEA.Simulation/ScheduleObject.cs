﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public enum ScheduleValueType { Integer, Float, Expression};

    public class ScheduleObject
    {
        #region Member Variables
        private string _Name;
        private ScheduleValueType _Type;
        private List<ScheduleValue> _Values;

        private AtomicObjectSimulator _Simulator;

        private int _LastValueIndex = 0;
        #endregion

        #region Properties
        public string Name { get { return _Name; } }
        public AtomicObjectSimulator Simulator
        {
            set { _Simulator = value; }
        }

        /*
        public float Value
        {
            get
            {
                //TODO 추후 속도 개선 필요: 
                double now = _Simulator.Clock;
                float rslt = 0.0f;

                double duration = 0;
                double nextDuration = 0;
                for(int i = 0; i  < _Values.Count; i++)
                {
                    nextDuration += _Values[i].Duration;

                    if (now >=duration && now < nextDuration)
                    {
                        if (_Type == ScheduleValueType.Integer)
                        {
                            int intVal = 0;
                            if (int.TryParse(_Values[i].Value, out intVal))
                            {
                                rslt = intVal; break;
                            }
                        }else if (_Type == ScheduleValueType.Float)
                        {
                            float floatVal = 0;
                            if (float.TryParse(_Values[i].Value, out floatVal))
                            {
                                rslt = floatVal; break;
                            }
                        }else if (_Type == ScheduleValueType.Expression)
                        {
                            //exp(9)?
                        }
                    }

                    duration += _Values[i].Duration;
                }

                return rslt;
            }
        }
        */

        private double _Duration;
        private double _NextDuration;

        public float Value
        {
            get
            {
                double now = _Simulator.SM.Clock;
                float rslt = 0.0f;

                do
                {
                    if (now >= _Duration && now < _NextDuration)
                    {
                        if (_Type == ScheduleValueType.Integer)
                        {
                            int intVal = 0;
                            if (int.TryParse(_Values[_LastValueIndex].Value, out intVal))
                            {
                                rslt = intVal; break;
                            }
                        }
                        else if (_Type == ScheduleValueType.Float)
                        {
                            float floatVal = 0;
                            if (float.TryParse(_Values[_LastValueIndex].Value, out floatVal))
                            {
                                rslt = floatVal; break;
                            }
                        }
                        else if (_Type == ScheduleValueType.Expression)
                        {
                            //exp(9)?
                        }
                    }
                    _Duration += _Values[_LastValueIndex].Duration;
                    _LastValueIndex++;
                    if (_LastValueIndex < _Values.Count)
                        _NextDuration+= _Values[_LastValueIndex].Duration;
                } while (_LastValueIndex < _Values.Count);

                return rslt;
            }
        }
        #endregion

        #region Constructors
        public ScheduleObject(string name, ScheduleValueType type)
        {
            _Name = name;
            _Type = type;
            _Values = new List<ScheduleValue>();
        }
        #endregion

        #region Methods
        /// <summary>
        /// add a schedule value 
        /// </summary>
        /// <param name="duration">duration in seconds</param>
        /// <param name="value"></param>
        public void Add(int duration, string value)
        {
            if (_Values.Count == 0)
            {
                _Duration = 0;
                _NextDuration = duration;
                _LastValueIndex = 0;
            }
            _Values.Add(new ScheduleValue(duration, value));
        }
        #endregion

        #region Operator Overriding Methods
        public static bool operator ==(ScheduleObject x, ScheduleObject y)
        {
            if (x.Value == 0 || y.Value == 0) return false;
            return x.Value == y.Value ? true : false;
        }

        public static bool operator !=(ScheduleObject x, ScheduleObject y)
        {
            if (x.Value == 0 || y.Value == 0) return false;
            return x.Value == y.Value ? false : true;
        }

        public static bool operator <(ScheduleObject x, ScheduleObject y)
        {
            return x.Value < y.Value;
        }

        public static bool operator >(ScheduleObject x, ScheduleObject y)
        {
            return x.Value > y.Value;
        }

        public static bool operator <(int x, ScheduleObject y)
        {
            return x < y.Value;
        }

        public static bool operator >(int x, ScheduleObject y)
        {
            return x > y.Value;
        }

        public static bool operator <(ScheduleObject x, int y)
        {
            return x.Value < y;
        }

        public static bool operator >(ScheduleObject x, int y)
        {
            return x.Value > y;
        }

        public static bool operator <(float x, ScheduleObject y)
        {
            return x < y.Value;
        }

        public static bool operator >(float x, ScheduleObject y)
        {
            return x > y.Value;
        }

        public static bool operator <(ScheduleObject x, float y)
        {
            return x.Value < y;
        }

        public static bool operator >(ScheduleObject x, float y)
        {
            return x.Value > y;
        }
        #endregion

        public override bool Equals(object obj)
        {
            if (obj is ScheduleObject)
            {
                return this._Name.Equals(((ScheduleObject)obj).Name);
            }
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return this._Name.GetHashCode();
        }
    }

    public class ScheduleValue
    {
        public int Duration;
        public string Value;

        public ScheduleValue(int duration, string value)
        {
            this.Duration = duration;
            this.Value = value;
        }
    }
}
