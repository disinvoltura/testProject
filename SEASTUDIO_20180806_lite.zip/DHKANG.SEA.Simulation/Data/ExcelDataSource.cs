﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation.Data
{
    public class ExcelDataSource: DataSource
    {
        #region Member Variables
        private string _FileName;
        private List<string> _Sheets;
        private DataTable _Data;
        #endregion

        #region Properties
        public override DataTable Data { get { return _Data; } }
        public string FileName {  get { return _FileName; } }
        public List<string> Sheets {  get { return _Sheets; } }
        #endregion

        #region Constructors
        public ExcelDataSource(string name, string filename, List<string> sheets)
            : base(name)
        {
            _FileName = filename;
            _Sheets = sheets;
        }
        #endregion

        #region Methods
        public void Load()
        {
            _Data = getDataTable();
        }

        private DataTable getDataTable()
        {
            DataTable table = null;

            table = new DataTable(_Name);
            string conStr = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + _FileName + ";Extended Properties=" + '"' + "Excel 12.0;HDR=YES;" + '"';
            //string conStr = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + _FileName + ";Extended Properties=" + '"' + "Excel 12.0;HDR=YES;" + '"';
            OleDbConnection excelConnection = new OleDbConnection(conStr);

            OleDbDataAdapter da = new OleDbDataAdapter();
            excelConnection.Open();

            OleDbCommand cmd = new OleDbCommand("SELECT * FROM [" + _Sheets[0] + "$]", excelConnection);

            da.SelectCommand = cmd;

            try
            {
                da.Fill(table);
            }
            catch (OleDbException e)
            { }

            excelConnection.Close();
            excelConnection.Dispose();
            return table;
        }
        #endregion
    }
}
