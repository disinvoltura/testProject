﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation.Data
{
    public abstract class DataSource
    {
        #region Member Variables
        protected string _Name;
        #endregion

        #region Properties
        public string Name { get { return _Name; } }
        public abstract DataTable Data { get; }
        #endregion

        #region Constructors
        public DataSource(string name)
        {
            _Name = name;
        }
        #endregion

        #region Methods
        #endregion
    }
}
