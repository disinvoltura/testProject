﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation.Data
{
    public static class DataSourceManager
    {
        #region Member Variables
        private static Dictionary<string, DataSource> _DataSources;
        #endregion

        #region Properties
        public static DataSource Find(string name)
        {
            DataSource rslt = null;
            if (_DataSources.ContainsKey(name))
               rslt = _DataSources[name];
            return rslt;
        }

        public static bool Contains(string name)
        {
            return _DataSources.ContainsKey(name);
        }
        #endregion

        #region Constructors
        static DataSourceManager() {
            _DataSources = new Dictionary<string, DataSource>();
        }
        #endregion

        #region Methods
        public static CSVDataSource LoadCSV(string dataSourceName, string fileName)
        {
            if (_DataSources.ContainsKey(dataSourceName))
                return (CSVDataSource)_DataSources[dataSourceName];

            CSVDataSource ds = new CSVDataSource(dataSourceName, fileName);
            ds.Load();

            _DataSources.Add(dataSourceName, ds);

            return ds;
        }

        public static ExcelDataSource LoadExcel(string dataSourceName, string fileName, List<string> sheets)
        {
            if (_DataSources.ContainsKey(dataSourceName))
                return (ExcelDataSource)_DataSources[dataSourceName];

            ExcelDataSource ds = new ExcelDataSource(dataSourceName, fileName, sheets);
            ds.Load();

            _DataSources.Add(dataSourceName, ds);

            return ds;
        }

        public static DBDataSource LoadDatabase(string dataSourceName, string dbType, string connectionString, string query)
        {
            DBDataSource ds = new DBDataSource(dataSourceName, dbType, connectionString, query);
            ds.Load();

            _DataSources.Add(dataSourceName, ds);

            return ds;
        }
        
        public static void Clear()
        {
            _DataSources.Clear();
        }
        #endregion
    }
}
