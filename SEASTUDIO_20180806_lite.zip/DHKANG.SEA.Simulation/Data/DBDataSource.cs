﻿using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace DHKANG.SEA.Simulation.Data
{
    public class DBDataSource : DataSource
    {
        public static readonly string DATABASE_MYSQL = "MYSQL";
        public static readonly string DATABASE_SQLSERVER= "SQLSERVER";
        public static readonly string DATABASE_ORACLE = "ORACLE";

        #region Member Variables
        private string _DBType;
        private string _ConnectionString;
        private string _Query;
        private DataTable _Data;
        #endregion

        #region Properties
        public string Query { get { return _Query; } }
        public string ConnectionString { get { return _ConnectionString; } }
        public override DataTable Data { get { return _Data; } }
        #endregion

        #region Constructors
        public DBDataSource(string name, string dbType, string connectionString, string query)
            : base(name)
        {
            _DBType = dbType;
            _ConnectionString = connectionString;
            _Query = query;            
        }
        #endregion

        #region Methods
        public void Load()
        {
            if (_DBType.Equals(DBDataSource.DATABASE_SQLSERVER))
                _Data = getDataTableFromSQLServer();
            else if (_DBType.Equals(DBDataSource.DATABASE_MYSQL))
                _Data = getDataTableFromMySql();
            else if (_DBType.Equals(DBDataSource.DATABASE_ORACLE))
                _Data = getDataTableFromOracle();
        }

        private DataTable getDataTableFromMySql()
        {
            MySqlConnection conn = new MySqlConnection(_ConnectionString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand(_Query, conn);

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            return dt;            
        }

        private DataTable getDataTableFromOracle()
        {
            //TODO revise accordingly.
            SqlConnection conn = new SqlConnection(_ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(_Query, conn);

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            return dt;            
        }

        private DataTable getDataTableFromSQLServer()
        {
            SqlConnection conn = new SqlConnection(_ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(_Query, conn);

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            return dt;            
        }

        /*
        private void getdatatable()
        {
            SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["BarManConnectionString"].ConnectionString);
            conn.Open();
            string query = "SELECT * FROM [EventOne] ";

            SqlCommand cmd = new SqlCommand(query, conn);

            DataTable t1 = new DataTable();
            using (SqlDataAdapter a = new SqlDataAdapter(cmd))
            {
                a.Fill(t1);
            }
            return t1;
        }
        */

        #endregion
    }
}
