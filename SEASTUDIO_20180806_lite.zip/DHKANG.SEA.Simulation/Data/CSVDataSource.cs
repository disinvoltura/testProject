﻿using LumenWorks.Framework.IO.Csv;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation.Data
{
    public class CSVDataSource : DataSource
    {
        #region Member Variables
        private string _FileName;
        private DataTable _Data;
        #endregion

        #region Properties
        public string FileName { get { return _FileName; } }
        public override DataTable Data { get { return _Data; } }
        #endregion

        #region Constructors
        public CSVDataSource(string name, string filename)
            : base(name)
        {
            _FileName = filename;
        }
        #endregion

        #region Methods
        public void Load()
        {
            _Data = getDataTable();
        }

        private DataTable getDataTable()
        {
            DataTable table = null;

            table = new DataTable(_Name);
            using (CsvReader csv = new CsvReader(new StreamReader(_FileName), false))
            {
                int fieldCount = csv.FieldCount;

                for (int k = 1; k <= fieldCount; k++)
                {
                    string columnName = "Column " + k;
                    table.Columns.Add(columnName);
                }
                //string[] headers = csv.GetFieldHeaders();
                while (csv.ReadNextRecord())
                {
                    DataRow row = table.NewRow();
                    for (int i = 0; i < fieldCount; i++)
                    {
                        row[i] = csv[i];
                        //System.Diagnostics.Debug.WriteLine(string.Format("{0} = {1};", i, csv[i]));
                        //System.Diagnostics.Debug.WriteLine(string.Format("{0} = {1};", headers[i], csv[i]));
                    }

                    table.Rows.Add(row);
                }
            }
            return table;
        }
        #endregion
    }
}
