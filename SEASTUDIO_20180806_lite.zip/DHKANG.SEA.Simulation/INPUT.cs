﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public enum InputType { TAR, TAG, MSR, MDP };

    public class INPUT
    {
        public InputType Type;
        public Message Record;

        public INPUT(InputType type, Message record)
        {
            Type = type;
            Record = record;
        }
    }
}
