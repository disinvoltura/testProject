﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public delegate void SimulationEndEventHandler(double clock);
    public delegate void SimulationClockAdvancingEventHandler(double clock);
    public delegate void SimulationClockAdvancedEventHandler(double clock);

}
