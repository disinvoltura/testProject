﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public class SchedulingTrace
    {
        #region Member Variables
        private int _SchedulingEventID;
        private int _ScheduledEventID;
        private String _ScheduledObject;
        #endregion

        #region Properties
        public int SchedulingEventID { get { return _SchedulingEventID; } }
        public int ScheduledEventID { get { return _ScheduledEventID; } }
        public string ScheduledObject { get { return _ScheduledObject; } }
        public bool IsMirrorEvent
        {
            get { return _ScheduledObject != null && _ScheduledObject.Length > 0; }
        }
        #endregion

        #region Constructors
        public SchedulingTrace(int schedulingEventID, int scheduledEventID)
        {
            _SchedulingEventID = schedulingEventID;
            _ScheduledEventID = scheduledEventID;
        }

        public SchedulingTrace(int schedulingEventID, string scheduledObject, int scheduledEventID)
        {
            _SchedulingEventID = schedulingEventID;
            _ScheduledObject = scheduledObject;
            _ScheduledEventID = scheduledEventID;
        }
        #endregion

        #region Methods
        public override bool Equals(object obj)
        {
            bool rslt = false;
            if (obj is SchedulingTrace)
            {
                SchedulingTrace target = (SchedulingTrace)obj;
                if (target.ScheduledEventID.Equals(_ScheduledEventID) &&
                    target.SchedulingEventID.Equals(_SchedulingEventID))
                    rslt = true;
            }
            return rslt;
        }

        public override int GetHashCode()
        {
            string rslt = _SchedulingEventID + "->" + _ScheduledEventID;
            return rslt.GetHashCode();
        }
        #endregion
    }
}
