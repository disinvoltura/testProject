﻿using DHKANG.SEA.Simulation.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DHKANG.SEA.Simulation.Observers
{
    public class ObservedEvent
    {
        private static int NextID = 0;
        #region Member Variables
        //private string _Name;
        protected int _ID;
        protected double _Time;
        protected SimEvent _Event;
        //private EventObjectSimulator _EventObject;
        #endregion

        #region Properties
        //public string Name
        //{
        //    get { return _Name; }
        //}

        public int ID {  get { return _ID; } }
        public double Time { get { return _Time; } }

        /*
        public SimEvent Event 
        {
            get { return _Event; }
        }
        */
        #endregion

        #region Constructors
        public ObservedEvent(double time)
        {
            _ID = NextID++;
            _Time = time;
        }
        /*
        public ObservedEvent(double time, SimEvent evt)
        {
            _Time = time;
            _Event = evt;
            //_EventObject = eventobject;
        }
        */
        /*
        public ObservedEvent(double time, EventObjectSimulator eventobject)
        {
            _Time = time;
            _EventObject = eventobject;
        }
         * */
        #endregion

        #region Methods

        #endregion
    }
}
