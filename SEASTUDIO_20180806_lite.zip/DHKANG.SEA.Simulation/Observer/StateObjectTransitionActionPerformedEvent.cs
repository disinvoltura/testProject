﻿using DHKANG.SEA.Simulation.Events;
using DHKANG.SEA.Simulation.States;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DHKANG.SEA.Simulation.Observers
{
    public class StateObjectTransitionActionPerformedEvent: ObservedEvent
    {
        #region Member Variables
        private string _ObjectName;
        private string _FromState;//changed state
        private string _ToState;//changed state
        private string _Input;
        #endregion

        #region Properties
        public string ObjectName { get { return _ObjectName; } }
        public string FromState { get { return _FromState; } }
        public string ToState { get { return _ToState; } }
        #endregion

        #region Constructors
        public StateObjectTransitionActionPerformedEvent(double time, string fromState, string toState, StateObjectSimulator stateObject)
            : base (time)
        {
            _ObjectName = stateObject.ID;
            _FromState = fromState;
            _ToState = toState;
        }

        #endregion

        #region Methods

        #endregion
    }
}
