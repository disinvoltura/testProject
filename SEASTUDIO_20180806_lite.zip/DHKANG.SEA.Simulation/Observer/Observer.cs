﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DHKANG.SEA.Simulation.Observers
{
    public abstract class SimObserver: IDisposable
    {
        #region Member Variables
        private string _Name;

        #endregion

        #region Properties
        public string Name
        {
            get { return _Name; }
        }
        #endregion

        #region Constructors
        public SimObserver(string name)
        {
            _Name = name;
        }
        #endregion

        #region Methods
        public abstract void Update(ObservedEvent e);

        public abstract void Finalize(double eosTime);

        public abstract void Clear();

        public override bool Equals(object obj)
        {
            bool rslt = false;
            if (obj is SimObserver)
            {
                SimObserver obs = (SimObserver)obj;
                rslt = this.Name.Equals(obs.Name); 
            }

            return rslt;
        }

        public abstract void Dispose();
        #endregion
    }
}
