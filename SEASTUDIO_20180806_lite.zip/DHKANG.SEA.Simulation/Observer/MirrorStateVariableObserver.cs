﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation.Observers
{
    public class MirrorStateVariableObserver : StateVariableObserver
    {
        /// <summary>
        /// Destination Event Object Simulator
        /// </summary>
        private AtomicObjectSimulator _DestEO;
        /// <summary>
        /// Destination State Variable's Name
        /// </summary>
        private string _DestSV;

        public MirrorStateVariableObserver(
                string srcEventObjectName, string srcStateVariableName, 
                AtomicObjectSimulator destEO, string destStateVariableName)
            : base(srcEventObjectName + "." + srcStateVariableName, srcEventObjectName, srcStateVariableName)
        {
            _DestEO = destEO;
            _DestSV = destStateVariableName;
        }

        public override void Clear()
        {
        }

        public override void Dispose()
        {
        }

        public override void Finalize(double eosTime)
        {
        }

        public override void Update(ObservedEvent e)
        {
            if (e is StateVariableObservedEvent)
                Update((StateVariableObservedEvent)e);
        }

        public override void Update(StateVariableObservedEvent e)
        {
            if (e.StateVariableName.Equals(this.StateVariableName))
            {
                if (e.StateVariableValue is EntityQueue)
                    _DestEO.SetStateVariable(_DestSV, ((EntityQueue)e.StateVariableValue).Count);
                else
                    _DestEO.SetStateVariable(_DestSV, e.StateVariableValue);
            }
        }
    }
}
