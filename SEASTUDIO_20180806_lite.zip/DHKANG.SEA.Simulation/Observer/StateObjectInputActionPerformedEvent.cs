﻿using DHKANG.SEA.Simulation.Events;
using DHKANG.SEA.Simulation.States;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DHKANG.SEA.Simulation.Observers
{
    public class StateObjectInputActionPerformedEvent: ObservedEvent
    {
        #region Member Variables
        private string _ObjectName;
        private string _State;//changed state
        private string _Input;
        #endregion

        #region Properties
        public string ObjectName { get { return _ObjectName; } }
        public string State { get { return _State; } }
        public string Input { get { return _Input; } }
        #endregion

        #region Constructors
        public StateObjectInputActionPerformedEvent(double time, string state, string input, StateObjectSimulator stateObject)
            : base (time)
        {
            _ObjectName = stateObject.ID;
            _State = state;
            _Input = input;
        }

        #endregion

        #region Methods

        #endregion
    }
}
