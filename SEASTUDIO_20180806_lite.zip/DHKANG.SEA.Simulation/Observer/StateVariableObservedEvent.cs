﻿using DHKANG.SEA.Simulation.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DHKANG.SEA.Simulation.Observers
{
    public class StateVariableObservedEvent: ObservedEvent
    {
        #region Member Variables
        private AtomicObjectSimulator _AOS;
        private string _SVName;
        private object _SVValue;
        #endregion

        #region Properties
        public string StateVariableName
        {
            get { return _SVName; }
        }

        public object StateVariableValue
        {
            get { return _SVValue; }
        }

        public string AtomicObjectName
        {
            get { return _AOS.ID; }
        }
        #endregion

        #region Constructors
        public StateVariableObservedEvent(double time, AtomicObjectSimulator eventobject, string svName, object svValue)
            : base(time)
        {
            _AOS = eventobject;
            _SVName = svName;
            _SVValue = svValue;
        }
        #endregion

        #region Methods

        #endregion
    }
}
