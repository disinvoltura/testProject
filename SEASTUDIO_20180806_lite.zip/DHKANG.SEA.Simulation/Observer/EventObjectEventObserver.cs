﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.Simulation;

namespace DHKANG.SEA.Simulation.Observers
{
    public class EventObjectEventObserver: EventObserver
    {
        #region Member Variables
        private string _EventObjectName;
        private List<EventObjectLocalEventObservedEvent> _Events;
        #endregion

        #region Properties
        public List<EventObjectLocalEventObservedEvent> Events
        {
            get { return _Events; }
        }
        #endregion

        #region Constructors
        public EventObjectEventObserver(string eventObjectName)
            : base(eventObjectName)
        {
            _EventObjectName = eventObjectName;
            _Events = new List<EventObjectLocalEventObservedEvent>();
        }
        #endregion

        #region Methods
        public override void Update(ObservedEvent e)
        {
            if (e is EventObjectLocalEventObservedEvent)
            _Events.Add((EventObjectLocalEventObservedEvent)e);
        }

        public override void Finalize(double eosTime)
        {
        }

        public override void Clear()
        {
            _Events.Clear();
        }

        public override void Dispose()
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}
