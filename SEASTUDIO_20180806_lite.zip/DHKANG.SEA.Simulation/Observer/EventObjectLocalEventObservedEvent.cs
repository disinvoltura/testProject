﻿using DHKANG.SEA.Simulation.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DHKANG.SEA.Simulation.Observers
{
    public class EventObjectLocalEventObservedEvent: ObservedEvent
    {
        #region Member Variables
        private EventObjectSimulator _EOSimulator;
        private SimEvent _Event;
        private string _LEL;
        private Dictionary<string, object> _StateVariables;
        //추후 value 를 string type으로 변환해야 할 수도 있음
        #endregion

        #region Properties
        public SimEvent Event { get { return _Event; } }

        public Dictionary<string, object> StateVariables
        {
            get { return _StateVariables; }
        }

        public string LEL
        {
            get { return _LEL;}
        }
        #endregion

        #region Constructors
        public EventObjectLocalEventObservedEvent(double time, EventObjectSimulator eventobject, SimEvent e)
            : base (time)
        {
            _EOSimulator = eventobject;
            _Event = e;
            //_LEL = eventobject.LEL.ToShortString();
            _StateVariables = new Dictionary<string, object>();

            foreach(string svName in eventobject.StateVariables)
            {
                object svValue = eventobject.GetStateVariable(svName);

                _StateVariables.Add(svName, svValue);
            }
        }
        #endregion

        #region Methods

        #endregion
    }
}
