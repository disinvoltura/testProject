﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DHKANG.SEA.Simulation.Observers
{ 
    public class Source<T> where T : SimObserver
    {
        #region Member Variables
        private Dictionary<string, T> _Observers;
        #endregion

        #region Properties

        #endregion

        #region Constructors
        public Source()
        {
            _Observers = new Dictionary<string, T>();
        }
        #endregion

        #region Methods
        public void AddObserver(T ob)
        {
            if (!_Observers.ContainsKey(ob.Name))
                _Observers.Add(ob.Name, ob);
        }

        public void RemoveObserver(T ob)
        {
            if (_Observers.ContainsKey(ob.Name))
                _Observers.Remove(ob.Name);
        }

        public void NotifyObservers(ObservedEvent e)
        {
            foreach (SimObserver ob in _Observers.Values)
            {
                ob.Update(e);
            }
        }
        #endregion
    }
}
