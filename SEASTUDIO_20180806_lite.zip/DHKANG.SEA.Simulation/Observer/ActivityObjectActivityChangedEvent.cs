﻿using DHKANG.SEA.Simulation.Activities;
using DHKANG.SEA.Simulation.Events;
using DHKANG.SEA.Simulation.States;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DHKANG.SEA.Simulation.Observers
{
    public class ActivityObjectActivityChangedEvent: ObservedEvent
    {
        #region Member Variables
        private string _ObjectName;
        private string _ActivityName;//changed state
        #endregion

        #region Properties
        public string ObjectName { get { return _ObjectName; } }
        public string ActivityName { get { return _ActivityName; } }
        #endregion

        #region Constructors
        public ActivityObjectActivityChangedEvent(double time, string activityName, ActivityObjectSimulator activityObject)
            : base (time)
        {
            _ObjectName = activityObject.ID;
            _ActivityName = activityName;
        }
        #endregion

        #region Methods

        #endregion
    }
}
