﻿using DHKANG.SEA.Simulation.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DHKANG.SEA.Simulation.Observers
{
    public class CoordinatorEventObservedEvent: ObservedEvent
    {
        #region Member Variables
        private SimEvent _Event;
        #endregion

        #region Properties
        public SimEvent Event { get { return _Event; } }
        #endregion

        #region Constructors
        public CoordinatorEventObservedEvent(double time, SimEvent e)
            : base (time)
        {
            _Event = e;
        }
        #endregion

        #region Methods

        #endregion
    }
}
