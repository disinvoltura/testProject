﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DHKANG.SEA.Simulation.Observers
{
    public abstract class ActivityObserver: SimObserver
    {
        #region Member Variables

        #endregion

        #region Properties

        #endregion

        #region Constructors
        public ActivityObserver(string name)
            : base(name)
        {
        }
        #endregion

        #region Methods
        //public abstract void Update(ObservedEvent e);
        //public abstract void Update(EventObjectLocalEventObservedEvent e);
        /*public override void Update(ObservedEvent e)
        {
            if (e != null && e is EventObjectLocalEventObservedEvent)
                this.Update((EventObjectLocalEventObservedEvent)e);
        }*/
        #endregion
    }
}
