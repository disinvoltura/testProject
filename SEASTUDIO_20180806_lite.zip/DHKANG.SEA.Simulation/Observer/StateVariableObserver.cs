﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DHKANG.SEA.Simulation.Observers
{
    public abstract class StateVariableObserver: SimObserver
    {
        #region Member Variables
        private string _ObjectName;
        private string _StateVariableName;
        #endregion

        #region Properties
        public string ObjectName { get { return _ObjectName; } set { _ObjectName = value; } }
        public string StateVariableName { get { return _StateVariableName; } set { _StateVariableName = value; } }
        #endregion

        #region Constructors
        public StateVariableObserver(string name, string objectName, string statevariableName)
            : base(name)
        {
            _ObjectName = objectName;
            _StateVariableName = statevariableName;
        }

        #endregion

        #region Methods
        public abstract void Update(StateVariableObservedEvent e);
        #endregion
    }
}
