﻿using DHKANG.SEA.Simulation.Events;
using DHKANG.SEA.Simulation.States;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DHKANG.SEA.Simulation.Observers
{
    public class StateObjectStateObservedEvent: ObservedEvent
    {
        #region Member Variables
        private StateObjectSimulator _SOSimulator;
        private Dictionary<string, object> _StateVariables;
        #endregion

        #region Properties
        public Dictionary<string, object> StateVariables
        {
            get { return _StateVariables; }
        }
        #endregion

        #region Constructors
        public StateObjectStateObservedEvent(double time, StateObjectSimulator stateObject)
            : base (time)
        {
            _SOSimulator = stateObject;
            _StateVariables = new Dictionary<string, object>();

            foreach(string svName in _SOSimulator.StateVariables)
            {
                object svValue = _SOSimulator.GetStateVariable(svName);

                _StateVariables.Add(svName, svValue);
            }
        }
        #endregion

        #region Methods

        #endregion
    }
}
