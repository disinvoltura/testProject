﻿using DHKANG.SEA.Simulation.Events;
using DHKANG.SEA.Simulation.States;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DHKANG.SEA.Simulation.Observers
{
    public class StateObjectEntryActionPerformedEvent: ObservedEvent
    {
        #region Member Variables
        private string _ObjectName;
        private string _State;//changed state
        #endregion

        #region Properties
        public string ObjectName { get { return _ObjectName; } }
        public string State { get { return _State; } }
        #endregion

        #region Constructors
        public StateObjectEntryActionPerformedEvent(double time, string state, StateObjectSimulator stateObject)
            : base (time)
        {
            _ObjectName = stateObject.ID;
            _State = state;
        }
        #endregion

        #region Methods

        #endregion
    }
}
