﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.SEA.Simulation;

namespace DHKANG.SEA.Simulation.Observers
{
    public class SimulationCoordinatorEventObserver: EventObserver
    {
        #region Member Variables
        private List<ObservedEvent> _Events;
        #endregion

        #region Properties
        public List<ObservedEvent> Events
        {
            get { return _Events; }
        }
        #endregion

        #region Constructors
        public SimulationCoordinatorEventObserver()
            : base("SC")
        {
            _Events = new List<ObservedEvent>();
        }
        #endregion

        #region Methods
        public override void Update(ObservedEvent e)
        {
            _Events.Add(e);
        }

        public override void Finalize(double eosTime)
        {
        }

        public override void Clear()
        {
            _Events.Clear();
        }

        public override void Dispose()
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}
