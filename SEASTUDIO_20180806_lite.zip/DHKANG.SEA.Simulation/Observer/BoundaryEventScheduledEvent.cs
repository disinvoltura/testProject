﻿using DHKANG.SEA.Simulation.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DHKANG.SEA.Simulation.Observers
{
    public class BoundaryEventScheduledEvent: ObservedEvent
    {
        #region Member Variables
        protected double _Time;
        protected SimEvent _MirrorEvent;
        protected SimEvent _BoundaryEvent;
        #endregion

        #region Properties
        public double Time
        {
            get { return _Time; }
        }

        public SimEvent MirrorEvent 
        {
            get { return _MirrorEvent; }
        }

        public SimEvent BoundaryEvent
        {
            get { return _BoundaryEvent;}
        }
        #endregion

        #region Constructors
        public BoundaryEventScheduledEvent(double time, SimEvent mirrorEvent, SimEvent boundaryEvent)
            : base(time)
        {
            _Time = time;
            _MirrorEvent = mirrorEvent;
            _BoundaryEvent = boundaryEvent;
        }

        /*
        public ObservedEvent(double time, EventObjectSimulator eventobject)
        {
            _Time = time;
            _EventObject = eventobject;
        }
         * */
        #endregion

        #region Methods

        #endregion
    }
}
