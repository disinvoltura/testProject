﻿using DHKANG.Foundation.DataCollection;
using DHKANG.SEA.Simulation.Dispatching;
using DHKANG.SEA.Simulation.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DHKANG.SEA.Simulation
{
    public class EntityQueue : SimObject
    {
        #region Member Variables
        private JobSelectionRule _JSR;

        /// <summary>
        /// Statistics for Waiting Time
        /// </summary>
        private SampleStatistics _WTStat;
        /// <summary>
        /// Statistics for Queue Length
        /// </summary>
        private TimeDependentStatistics _QLStat;
        /// <summary>
        /// No. Entities entered
        /// </summary>
        private int _NoEntered;
        /// <summary>
        ///No. Entities left
        /// </summary>
        private int _NoLeft;
        #endregion

        #region Properties
        public SampleStatistics WaitingTime { get { return _WTStat; } }
        public TimeDependentStatistics QueueLength { get { return _QLStat; } }

        public int Count { get { return _JSR.Count; } }

        public JobSelectionRule Rule { get { return _JSR; } set { _JSR = value; } }

        public List<AbstractEntity> Values { get { return _JSR.Values; } }
        public int EntitiesEntered { get { return _NoEntered; } }
        public int EntitiesLeft { get { return _NoLeft; } }
        #endregion 

        public EntityQueue(AtomicObjectSimulator parent, string name) : base(parent, name)
        {
            _JSR = new FIFOJobSelection(parent, name, this);

            _WTStat = new SampleStatistics(name);
            _QLStat = new TimeDependentStatistics(name);
        }

        public void Initialize(Dictionary<string, object> args)
        {
            if (args.ContainsKey("rule"))
            {
                string ruleName = (string)args["rule"];
                if (ruleName.Equals("FIFO"))
                {
                    _JSR = new FIFOJobSelection(this.Parent, this.Name, this);
                }else if (ruleName.Equals("LIFO"))
                {
                    _JSR = new LIFOJobSelection(this.Parent, this.Name, this);
                }
            }
        }
        /*
        public EntityQueue(AtomicObjectSimulator parent) : base(parent)
        {
        }
        */

        #region Methods
        public void Add(AbstractEntity value)
        {
            this.Enqueue(value);
            //value.Enqueue(this);
            //_JSR.Enqueue(value);
        }

        public void Enqueue(AbstractEntity value)
        {
            value.Enqueue(this);
            _JSR.Enqueue(value);

            _QLStat.Add(EntityManager.Clock, _JSR.Count);
            _NoEntered++;
        }

        public AbstractEntity Remove()
        {
            return Dequeue();
        }

        public AbstractEntity Dequeue()
        {
            AbstractEntity rslt = null;
            rslt = _JSR.Dequeue();

            double elapsedTime = 0;
            if (rslt != null)
            {
                elapsedTime = rslt.ElapsedTime;
                rslt.Dequeue(this);
                if (this.Parent is EventObjectSimulator)
                    rslt.Enter(((EventObjectSimulator)this.Parent).CurrentEvent);
            }

            _QLStat.Add(EntityManager.Clock, _JSR.Count);
            if (elapsedTime > 0)
                _WTStat.Add(EntityManager.Clock, elapsedTime);

            _NoLeft++;

            return rslt;
        }

        public void OnSimulationEnded(double now)
        {
            _WTStat.Finalize(now);
            //System.Diagnostics.Debug.WriteLine("Waiting Time statistics at " + this.Name);
            //System.Diagnostics.Debug.WriteLine(" - mean: " + _WTStat.Mean);
            //System.Diagnostics.Debug.WriteLine(" - min: " + _WTStat.Minimum);
            //System.Diagnostics.Debug.WriteLine(" - max: " + _WTStat.Maximum);
            //System.Diagnostics.Debug.WriteLine(" - samples: " + _WTStat.Count);
            _QLStat.Calculate();
            //System.Diagnostics.Debug.WriteLine("Queue Length statistics at " + this.Name);
            //System.Diagnostics.Debug.WriteLine(" - mean: " + _QLStat.Mean);
            //System.Diagnostics.Debug.WriteLine(" - min: " + _QLStat.Minimum);
            //System.Diagnostics.Debug.WriteLine(" - max: " + _QLStat.Maximum);
            //System.Diagnostics.Debug.WriteLine(" - samples: " + _QLStat.Count);
        }
        #endregion

        #region Operator Overloading
        public static EntityQueue operator +(EntityQueue x, AbstractEntity value)
        {
            x.Enqueue(value);
            return x;
        }

        public static bool operator <(EntityQueue x, int value)
        {
            return x.Count < value;
        }

        public static bool operator >(EntityQueue x, int value)
        {
            return x.Count > value;
        }

        public static bool operator >(int value, EntityQueue x)
        {
            return x.Count < value;
        }

        public static bool operator <(int value, EntityQueue x)
        {
            return x.Count > value;
        }

        public static bool operator ==(EntityQueue x, int value)
        {
            return x.Count == value;
        }

        public static bool operator ==(int value, EntityQueue x)
        {
            return x.Count == value;
        }

        public static bool operator !=(EntityQueue x, int value)
        {
            return x.Count != value;
        }

        public static bool operator !=(int value, EntityQueue x)
        {
            return x.Count != value;
        }

        public static bool operator >=(EntityQueue x, int value)
        {
            return x.Count >= value;
        }

        public static bool operator >=(int value, EntityQueue x)
        {
            return x.Count <= value;
        }

        public static bool operator <=(EntityQueue x, int value)
        {
            return x.Count <= value;
        }

        public static bool operator <=(int value, EntityQueue x)
        {
            return x.Count >= value;
        }

        #endregion
    }
    
}
