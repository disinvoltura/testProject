﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DHKANG.Foundation.DataCollection;

namespace DHKANG.SEA.Simulation
{
    public class Resource : SimObject
    {
        #region Member Variables
        private int _Capacity;
        private int _InUse;
        private int _InReserve;//no. units in the reserved.

        private int _SeizeCount;
        private List<AbstractEntity> _SeizedEntities;
        private List<AbstractEntity> _SeizingEntities;
        #endregion

        #region Properties
        public int Capacity { get { return _Capacity; }  set { _Capacity = value; } }
        public int InUse { get { return _InUse; } }
        public int InReserve { get { return _InReserve; } }
        #endregion

        #region statistics
        private double _LastTime;
        private Dictionary<int, double> _LastTimes;
        private double _Sum;
        private CounterStatistics _Tally;
        private TimeDependentStatistics _TD;
        #endregion

        #region Properties - Statistics
        public double Utilization
        {
            get
            {
                double util = 0;
                util = (_Sum / EntityManager.Clock / _Capacity) * 100; 
                return util;
            }
        }

        public TimeDependentStatistics Usage { get { return _TD; } }
        public double AverageUsage
        {
            get { return _TD.Mean; }
        }
        public int SeizeCount { get { return _SeizeCount; } }
        /// <summary>
        /// List of entities seized
        /// </summary>
        public List<AbstractEntity> SeizedEntities { get { return _SeizedEntities; } }

        /// <summary>
        /// currently being seized entities
        /// </summary>
        public List<AbstractEntity> SeizingEntities { get { return _SeizingEntities; } }
        #endregion

        #region Constructors
        public Resource(AtomicObjectSimulator parent, string name, int capacity) : base(parent)
        {
            _Capacity = capacity;
            _InUse = 0;

            _LastTime = 0;
            _LastTimes = new Dictionary<int, double>();
            _Sum = 0;
            _Tally = new CounterStatistics(_Name);
            _TD = new TimeDependentStatistics(_Name);

            _SeizedEntities = new List<AbstractEntity>();
            _SeizingEntities = new List<AbstractEntity>();
        }

        public Resource(AtomicObjectSimulator parent, string name) : base(parent, name)
        {
            _Capacity = 1;
            _InUse = 0;

            _LastTime = 0;
            _LastTimes = new Dictionary<int, double>();
            _Sum = 0;
            _Tally = new CounterStatistics(_Name);
            _TD = new TimeDependentStatistics(_Name);

            _SeizedEntities = new List<AbstractEntity>();
            _SeizingEntities = new List<AbstractEntity>();
        }

        public Resource(AtomicObjectSimulator parent, int capacity) : base(parent)
        {
            _Name = "Resource" + this.ID;
            _Capacity = capacity;
            _InUse = 0;

            _LastTime = 0;
            _LastTimes = new Dictionary<int, double>();
            _Sum = 0;
            _Tally = new CounterStatistics(_Name);
            _TD = new TimeDependentStatistics(_Name);

            _SeizedEntities = new List<AbstractEntity>();
            _SeizingEntities = new List<AbstractEntity>();
        }

        public Resource(AtomicObjectSimulator parent) : base(parent)
        {
            _Name = "Resource" + this.ID;
            //_Name = "Resource" + _NextID++;
            _Capacity = 1;
            _InUse = 0;

            _LastTime = 0;
            _LastTimes = new Dictionary<int, double>();
            _Sum = 0;
            _Tally = new CounterStatistics(_Name);
            _TD = new TimeDependentStatistics(_Name);

            _SeizedEntities = new List<AbstractEntity>();
            _SeizingEntities = new List<AbstractEntity>();
        }
 
        public Resource(string name, int capacity) : base(name)
        {
            _Capacity = capacity;
            _InUse = 0;

            _LastTime = 0;
            _LastTimes = new Dictionary<int, double>();
            _Sum = 0;
            _Tally = new CounterStatistics(_Name);
            _TD = new TimeDependentStatistics(_Name);

            _SeizedEntities = new List<AbstractEntity>();
            _SeizingEntities = new List<AbstractEntity>();
        }

        public Resource(string name) : this(name, 1)
        {
            /*
            _Capacity = 1;
            _InUse = 0;

            _LastTime = 0;
            _LastTimes = new Dictionary<int, double>();
            _Sum = 0;
            _Tally = new CounterStatistics(_Name);
            _TD = new TimeDependentStatistics(_Name);

            _SeizedEntities = new List<AbstractEntity>();
            _SeizingEntities = new List<AbstractEntity>();
            */
        }

        public Resource(int capacity) : this()
        {
            _Name = "Resource" + this.ID;
            _Capacity = capacity;
            /*
            _InUse = 0;

            _LastTime = 0;
            _LastTimes = new Dictionary<int, double>();
            _Sum = 0;
            _Tally = new CounterStatistics(_Name);
            _TD = new TimeDependentStatistics(_Name);

            _SeizedEntities = new List<AbstractEntity>();
            _SeizingEntities = new List<AbstractEntity>();
            */
        }

        public Resource() : base()
        {
            _Name = "Resource" + this.ID;
            //_Name = "Resource" + _NextID++;
            _Capacity = 1;
            _InUse = 0;

            _LastTime = 0;
            _LastTimes = new Dictionary<int, double>();
            _Sum = 0;
            _Tally = new CounterStatistics(_Name);
            _TD = new TimeDependentStatistics(_Name);

            _SeizedEntities = new List<AbstractEntity>();
            _SeizingEntities = new List<AbstractEntity>();
        }
        #endregion

        #region Methods
        public bool IsIdle()
        {
            return (_InUse  + _InReserve) < _Capacity;
        }

        public bool IsReserved()
        {
            return _InReserve > 0;
        }

        //onle for single-unit resource
        public void Reserve()
        {
            _InReserve++;

            if (_InUse + _InReserve > _Capacity)
            {
                System.Diagnostics.Debug.WriteLine("[ResourceVariable] " + _Name + " while reserving, we encounter a over-capacitized issue; cannot reserve beyond its capacity");
            }
        }

        public void Seize()
        {
            if (_InReserve > 0)
                _InReserve--;

            if (_InUse < _Capacity)
            {
                _InUse++;

                _TD.Add(EntityManager.Clock, _InUse);
                _LastTime = EntityManager.Clock;
                _SeizeCount++;
            }
            else
            {
                System.Diagnostics.Debug.WriteLine("[ResourceVariable] " + _Name + " resource has no more available unit");
                //errors....
            }

        }

        //onle for single-unit resource
        public void Release()
        {
            _InUse--;

            _TD.Add(EntityManager.Clock, _InUse);

            double elapsedTime = EntityManager.Clock - _LastTime;
            _Sum += elapsedTime;
        }


        public void Seize(AbstractEntity entity)
        {
            if (_InReserve > 0)
                _InReserve--;

            if (_InUse < _Capacity)
            {
                _InUse++;

                _TD.Add(EntityManager.Clock, _InUse);
                _LastTimes.Add(entity.ID, EntityManager.Clock);

                _SeizingEntities.Add(entity);
            }
            else
            {
                System.Diagnostics.Debug.WriteLine("[ResourceVariable] " + _Name + " resource has no more available unit");
                //errors....
            }
        }

        public void Release(AbstractEntity entity)
        {
            _InUse--;

            _TD.Add(EntityManager.Clock, _InUse);

            double elapsedTime = EntityManager.Clock - _LastTimes[entity.ID];
            _Sum += elapsedTime;
            _LastTimes.Remove(entity.ID);

            if (_SeizingEntities.Contains(entity))
            {
                _SeizingEntities.Remove(entity);
            }

            _SeizedEntities.Add(entity);
            _SeizeCount++;
        }
        #endregion
    }
}
