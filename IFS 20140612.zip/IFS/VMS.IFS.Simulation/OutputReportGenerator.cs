﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.DataModel.OutputData;
using VMS.IFS.DataModel;
using VMS.IFS.Models;
using VMS.IFS.OuputDataCollection;
using VMS.IFS.Engine;

namespace VMS.IFS.Simulation
{
    public class OutputReportGenerator: IDisposable
    {
        #region Member Variables
        private Factory _Factory;
        
        private Dictionary<string, object> _RunOptions;

        private CassetteObserver _cstObs;
        private EquipmentObserver _eqpObs;
        private FabInObserver _fabInObs;
        private FabOutObserver _fabOutObs;

        //CassetteObserver로 기능 이관 (D. KAng, 2013.11.12)
        //private CassetteTATObserver _tatObs;
        private FabWipObserver _fabWipObs;

        private StockerWipObserver _stockerWipObs;
        private ConveyorWipObserver _conveyorObs;

        private StockerObserver _stockerObs;
        private TransportLoadObserver _stkLoadObs;

        private CassetteMovingObserver _movingTimeObs;
        private CraneWaitingTimeObserver _CraneWaitingTimeObs;
        

        private Dictionary<string, Observer> _Observers;
        #endregion

        #region Properties
        public CassetteObserver CassetteObserver
        {
            get { return _cstObs; }
        }

        public EquipmentObserver EquipmentObserver
        {
            get { return _eqpObs; }
        }

        public FabInObserver FabInObserver
        {
            get { return _fabInObs; }
        }

        public FabOutObserver FabOutObserver
        {
            get { return _fabOutObs; }
        }

        //public CassetteTATObserver CassetteTATObserver
        //{
        //    get { return _tatObs; }
        //}

        public FabWipObserver FabWIPObserver
        {
            get { return _fabWipObs; }
        }

        public StockerWipObserver StockerWIPObserver
        {
            get { return _stockerWipObs; }
        }

        public ConveyorWipObserver ConveyorWIPObserver
        {
            get { return _conveyorObs; }
        }

        public StockerObserver StockerObserver
        {
            get { return _stockerObs; }
        }

        public CassetteMovingObserver MovingTimeObserver
        {
            get { return _movingTimeObs; }
        }

        public CraneWaitingTimeObserver CraneWaitingTimeObserver
        {
            get { return _CraneWaitingTimeObs; }
        }

        public TransportLoadObserver StockerLoadObserver
        {
            get { return _stkLoadObs; }
        }
        /// <summary>
        /// Return an observer
        /// </summary>
        /// <param name="?"></param>
        /// <returns></returns>
        public Observer this[string name]
        {
            get
            {
                Observer rslt = null;
                if (_Observers.ContainsKey(name))
                    rslt = _Observers[name];

                return rslt;
            }
        }

        #endregion

        #region Constructors
        public OutputReportGenerator(Factory factory, Dictionary<string, object> runOptions)
        {
            _Factory = factory;
            _RunOptions = runOptions;
        }
        #endregion

        #region Methods
        public void Initialize()
        {
            _Observers = new Dictionary<string, Observer>();

            _cstObs = new CassetteObserver(_Factory, _RunOptions);
            _eqpObs = new EquipmentObserver(_Factory, _RunOptions);
            _fabInObs = new FabInObserver(_Factory, _RunOptions);
            _fabOutObs = new FabOutObserver(_Factory, _RunOptions);
            //_tatObs = new CassetteTATObserver(_RunOptions);
            _fabWipObs = new FabWipObserver(_Factory, _RunOptions);

            _stockerObs = new StockerObserver(_Factory, _RunOptions);
            _stockerWipObs = new StockerWipObserver(_Factory, _RunOptions);
            _conveyorObs = new ConveyorWipObserver(_Factory, _RunOptions);
            _movingTimeObs = new CassetteMovingObserver(_Factory, _RunOptions);
            _CraneWaitingTimeObs = new CraneWaitingTimeObserver(_Factory, _RunOptions);
            _stkLoadObs = new TransportLoadObserver(_Factory, _RunOptions);

            _Observers.Add(_cstObs.Name, _cstObs);
            _Observers.Add(_eqpObs.Name, _eqpObs);
            _Observers.Add(_fabInObs.Name, _fabInObs);
            _Observers.Add(_fabOutObs.Name, _fabOutObs);
            //_Observers.Add(_tatObs.Name, _tatObs);
            _Observers.Add(_fabWipObs.Name, _fabWipObs);
            _Observers.Add(_stockerObs.Name, _stockerObs);
            _Observers.Add(_stockerWipObs.Name, _stockerWipObs);
            _Observers.Add(_conveyorObs.Name, _conveyorObs);
            _Observers.Add(_movingTimeObs.Name, _movingTimeObs);
            _Observers.Add(_CraneWaitingTimeObs.Name, _CraneWaitingTimeObs);
            _Observers.Add(_stkLoadObs.Name, _stkLoadObs);

            InitializeWIP();
        }

        private void InitializeWIP()
        {
            int count = 0;

            //Commented Out by D. Kang (2013.11.11) for later implementation
            /*
            foreach (string eqpid in _Factory.MasterData.EQP.UnilineCells)
            {
                foreach (Cassette cst in _Factory.UniInlineCell.B[eqpid].Cassettes)
                {
                    int cid = cst.ID;
                    CassetteLog log = new CassetteLog(0, cst.RBID, cst.J, cst.ID, CassetteState.Arrived, cst.C, cst.P, cst.D);
                    _cstObs.addCassetteLog(cid, log);

                    string key = string.Format("{0}.{1}", cst.J, cst.P);
                    _cstObs.enQueue(key);

                    count++;
                }

                foreach (Cassette cst in _Factory.UniInlineCell.VirtualQueue[eqpid].Cassettes)
                {
                    int cid = cst.ID;
                    CassetteLog log = new CassetteLog(0, cst.RBID, cst.J, cst.ID, CassetteState.Arrived, cst.C, cst.P, cst.D);
                    _cstObs.addCassetteLog(cid, log);

                    string key = string.Format("{0}.{1}", cst.J, cst.P);
                    _cstObs.enQueue(key);
                    
                    count++;
                }
            }

            foreach (string eqpid in _Factory.MasterData.EQP.BilineCells)
            {
                foreach (Cassette cst in _Factory.BiInlineCell.IQ[eqpid].Cassettes)
                {
                    int cid = cst.ID;
                    CassetteLog log = new CassetteLog(0, cst.RBID, cst.J, cst.ID, CassetteState.Arrived, cst.C, cst.P, cst.D);
                    _cstObs.addCassetteLog(cid, log);

                    string key = string.Format("{0}.{1}", cst.J, cst.P);
                    _cstObs.enQueue(key);

                    count++;
                }

                foreach (Cassette cst in _Factory.BiInlineCell.VirtualQueue[eqpid].Cassettes)
                {
                    int cid = cst.ID;
                    CassetteLog log = new CassetteLog(0, cst.RBID, cst.J, cst.ID, CassetteState.Arrived, cst.C, cst.P, cst.D);
                    _cstObs.addCassetteLog(cid, log);

                    string key = string.Format("{0}.{1}", cst.J, cst.P);
                    _cstObs.enQueue(key);

                    count++;
                }
            }

            foreach (string eqpid in _Factory.MasterData.EQP.Ovens)
            {
                foreach (Cassette cst in _Factory.Oven.B[eqpid].Cassettes)
                {
                    int cid = cst.ID;
                    CassetteLog log = new CassetteLog(0, cst.RBID, cst.J, cst.ID, CassetteState.Arrived, cst.C, cst.P, cst.D);
                    _cstObs.addCassetteLog(cid, log);

                    string key = string.Format("{0}.{1}", cst.J, cst.P);
                    _cstObs.enQueue(key);

                    count++;
                }

                foreach (Cassette cst in _Factory.Oven.VirtualQueue[eqpid].Cassettes)
                {
                    int cid = cst.ID;
                    CassetteLog log = new CassetteLog(0, cst.RBID, cst.J, cst.ID, CassetteState.Arrived, cst.C, cst.P, cst.D);
                    _cstObs.addCassetteLog(cid, log);

                    string key = string.Format("{0}.{1}", cst.J, cst.P);
                    _cstObs.enQueue(key);

                    count++;
                }
            }

            foreach (string eqpid in _Factory.MasterData.EQP.Chambers)
            {
                foreach (Cassette cst in _Factory.Chamber.B[eqpid].Cassettes)
                {
                    int cid = cst.ID;
                    CassetteLog log = new CassetteLog(0, cst.RBID, cst.J, cst.ID, CassetteState.Arrived, cst.C, cst.P, cst.D);
                    _cstObs.addCassetteLog(cid, log);

                    string key = string.Format("{0}.{1}", cst.J, cst.P);
                    _cstObs.enQueue(key);

                    count++;
                }

                foreach (Cassette cst in _Factory.Chamber.VirtualQueue[eqpid].Cassettes)
                {
                    int cid = cst.ID;
                    CassetteLog log = new CassetteLog(0, cst.RBID, cst.J, cst.ID, CassetteState.Arrived, cst.C, cst.P, cst.D);
                    _cstObs.addCassetteLog(cid, log);
                    
                    string key = string.Format("{0}.{1}", cst.J, cst.P);
                    _cstObs.enQueue(key);

                    count++;
                }
            }

            _fabWipObs.Initialize(count);
            */

            //TODO
            //STOCKER WIP
        }

        public void Finish()
        {
            foreach (Observer obs in _Observers.Values)
            {
                obs.Finalize(_Factory.Clock);
            }
        }

        public OutputDataSet Transduce()
        {
            //Generate Output Data
            OutputDataSet _OutputData = new OutputDataSet();

            double eosTime = _Factory.Clock;

            //shiftTime: in seconds
            double shiftTime = (int)_RunOptions[SimulationArguments.UnitTime] * 3600;
            int noShifts = (int)(eosTime / shiftTime);
            if ((eosTime % shiftTime) > 0)
                noShifts++;
            //int noShifts = (int)(eosTime / shiftTime) + 1;

            foreach (string eqpid in _Factory.MasterData.EQP.Keys)
            {
                //EQPOutput
                _OutputData.EQPOutputDataTable.Columns.Add(eqpid);
            }

            foreach (string stkid in _Factory.MasterData.Stocker.Keys)
            {
                if (stkid == "FabIn" || stkid == "FabOut")
                    continue;

                _OutputData.StockerWIPDataTable.Columns.Add(stkid, typeof(int));
                _OutputData.StockerShiftTransportLoadDataTable.Columns.Add(stkid, typeof(int));
            }

            foreach (string convid in _Factory.MasterData.Conveyor.Keys)
            {
                if (convid.StartsWith("FabIn") || convid.EndsWith("FabOut"))
                    continue;

                _OutputData.ConveyorWIPDataTable.Columns.Add(convid, typeof(int));
            }

            //ProcessingStepOut/ProcessingStepWIP
            List<string> stepOutKeys = new List<string>(); //이런 형태로 다른 output data 도 간결하게 정리할 것!!!
            foreach (string productid in _Factory.MasterData.Product.Products)
            {
                IEnumerable<string> steplist = _Factory.MasterData.BOP.ProductSteps[productid];

                foreach (string stepid in steplist)
                {
                    string key = string.Format("{0}.{1}", productid, stepid);
                    stepOutKeys.Add(key);

                    _OutputData.ProcessingStepOutputDataTable.Columns.Add(key);
                    _OutputData.ProcessingStepWIPDataTable.Columns.Add(key);

                    //StepTATChart
                    if (!_OutputData.StepTATChartDataTable.Columns.Contains(stepid))
                    {
                        _OutputData.StepTATChartDataTable.Columns.Add(stepid);
                    }
                }
            }

            //ProductInOut
            foreach (string productid in _Factory.MasterData.Product.Products)
            {
                _OutputData.ProductInOutDataTable.Columns.Add(productid + " In", typeof(int));
                _OutputData.ProductInOutDataTable.Columns.Add(productid + " Out", typeof(int));

                //product 별 shift 별 average TAT - 3/20 김현식
                _OutputData.ShiftProductTATDataTable.Columns.Add(productid, typeof(double));
            }
            //product 별 shift 별 average TAT - 3/20 김현식
            _OutputData.ShiftProductTATDataTable.Columns.Add("Total", typeof(double));

            for (int i = 1; i <= noShifts; i++)
            {
                //FabInOut
                OutputDataSet.FabInOutDataTableRow row1 =
                    _OutputData.FabInOutDataTable.NewFabInOutDataTableRow();

                row1.Shift = i.ToString();
                row1.Fab_In = _fabInObs.Statistics[i].ToString();
                row1.Fab_Out = _fabOutObs.Statistics[i].ToString();

                _OutputData.FabInOutDataTable.Rows.Add(row1);

                //FabWIP
                OutputDataSet.FabWIPDataTableRow row3 =
                    _OutputData.FabWIPDataTable.NewFabWIPDataTableRow();

                row3.Shift = i.ToString();
                row3.WIP= _fabWipObs.ShiftFabWIP[i].ToString();

                _OutputData.FabWIPDataTable.Rows.Add(row3);


                //EQPOutput
                OutputDataSet.EQPOutputDataTableRow row2 = _OutputData.EQPOutputDataTable.NewEQPOutputDataTableRow();
                row2.Shift = i.ToString();
                foreach (string eqpid in _Factory.MasterData.EQP.Keys)
                {
                    TimeBucketTallyStatistics stat = _eqpObs.GetTimeBucketOutData(eqpid);
                    if (stat != null)
                        row2[eqpid] = stat[i];
                    else
                        row2[eqpid] = 0;
                }

                _OutputData.EQPOutputDataTable.Rows.Add(row2);

                //StockerWIP and Transport Load
                OutputDataSet.StockerWIPDataTableRow row4 = _OutputData.StockerWIPDataTable.NewStockerWIPDataTableRow();
                row4.Shift = i;
                OutputDataSet.StockerShiftTransportLoadDataTableRow row6 = _OutputData.StockerShiftTransportLoadDataTable.NewStockerShiftTransportLoadDataTableRow();
                row6.Shift = i;
                foreach (string stkid in _Factory.MasterData.Stocker.Keys)
                {
                    if (stkid == "FabIn" || stkid == "FabOut")
                        continue;

                    if (_stockerWipObs.ShiftWIP.ContainsKey(stkid))
                    {
                        TimeBucketDependentStatistics shiftStat = _stockerWipObs.ShiftWIP[stkid];
                        if (shiftStat != null)
                            row4[stkid] = shiftStat[i];
                        else
                            row4[stkid] = 0;
                    }

                    if (_stkLoadObs.Transport.ContainsKey(stkid))
                    {
                        TimeBucketTallyStatistics shiftLoadStat = _stkLoadObs.Transport[stkid];
                        if (shiftLoadStat != null)
                            row6[stkid] = shiftLoadStat[i];
                        else
                            row6[stkid] = 0;
                    }
                }
                _OutputData.StockerWIPDataTable.Rows.Add(row4);
                _OutputData.StockerShiftTransportLoadDataTable.Rows.Add(row6);

                //ConveyorWIP
                OutputDataSet.ConveyorWIPDataTableRow row5 = _OutputData.ConveyorWIPDataTable.NewConveyorWIPDataTableRow();
                row5.Shift = i;
                foreach (string convid in _Factory.MasterData.Conveyor.Keys)
                {
                    if (convid.StartsWith("FabIn") || convid.EndsWith("FabOut"))
                        continue;

                    if (_conveyorObs.ShiftWIP.ContainsKey(convid))
                    {
                        TimeBucketDependentStatistics shiftStat = _conveyorObs.ShiftWIP[convid];

                        if (shiftStat != null)
                            row5[convid] = shiftStat[i];
                        else
                            row5[convid] = 0;
                    }
                }
                _OutputData.ConveyorWIPDataTable.Rows.Add(row5);

                OutputDataSet.ProcessingStepOutputDataTableRow rowOut
                    = _OutputData.ProcessingStepOutputDataTable.NewProcessingStepOutputDataTableRow();
                rowOut["Shift"] = i.ToString();
                OutputDataSet.ProcessingStepWIPDataTableRow rowWIP =
                    _OutputData.ProcessingStepWIPDataTable.NewProcessingStepWIPDataTableRow();
                rowWIP["Shift"] = i.ToString();
                foreach (string key in stepOutKeys)
                {
                    TimeBucketTallyStatistics statOut = null;
                    if (_cstObs.StepOut.ContainsKey(key))
                    {
                        statOut = _cstObs.StepOut[key];
                        rowOut[key] = statOut[i];
                    }
                    else
                    {
                        rowOut[key] = 0;
                    }

                    TimeBucketDependentStatistics statWip = null;
                    if (_cstObs.StepWIP.ContainsKey(key))
                    {
                        statWip = _cstObs.StepWIP[key];
                        rowWIP[key] = statWip[i];
                    }
                    else
                    {
                        rowWIP[key] = 0;
                    }
                }

                //ProcessingStepOut
                _OutputData.ProcessingStepOutputDataTable.Rows.Add(rowOut);
                //ProcessingStepWIP
                _OutputData.ProcessingStepWIPDataTable.Rows.Add(rowWIP);

                //ProductInOut
                OutputDataSet.ProductInOutDataTableRow rowInOut =
                    _OutputData.ProductInOutDataTable.NewProductInOutDataTableRow();
                rowInOut.Shift = i.ToString();

                //product 별 shift 별 average TAT - 3/20 김현식
                OutputDataSet.ShiftProductTATDataTableRow rowTAT =
                    _OutputData.ShiftProductTATDataTable.NewShiftProductTATDataTableRow();
                rowTAT.Shift = i.ToString();

                foreach (string productid in _Factory.MasterData.Product.Products)
                {
                    TimeBucketTallyStatistics inStat = _fabInObs[productid];
                    if (inStat != null)
                        rowInOut[productid + " In"] = inStat[i];
                    else
                        rowInOut[productid + " In"] = 0;
                    TimeBucketTallyStatistics outStat = _fabOutObs[productid];
                    if (outStat != null)
                        rowInOut[productid + " Out"] = outStat[i];
                    else
                        rowInOut[productid + " Out"] = 0;

                    //product 별 shift 별 average TAT - 3/20 김현식
                    if (_cstObs.TBTAT.ContainsKey(productid))
                    {
                        AverageInTimeBucketStatistics tatStat = _cstObs.TBTAT[productid];
                        if (tatStat[i] != 0)
                        {
                            rowTAT[productid] = Math.Round(tatStat.Mean(i), 2);
                        }
                        else
                        {
                            rowTAT[productid] = 0;
                        }
                    }
                }
                _OutputData.ProductInOutDataTable.Rows.Add(rowInOut);

                //product 별 shift 별 average TAT - 3/20 김현식
                AverageInTimeBucketStatistics tatStat2 = _cstObs.TBTAT["Total"];
                if (tatStat2[i] != 0)
                {
                    rowTAT["Total"] = Math.Round(tatStat2.Mean(i), 2);
                }
                else
                {
                    rowTAT["Total"] = 0;
                }
                _OutputData.ShiftProductTATDataTable.Rows.Add(rowTAT);
            }            

            //EQPUtilization
            foreach (string eqpid in _eqpObs.Equipments)
            {
                OutputDataSet.EQPUtilizationDataTableRow row =
                    _OutputData.EQPUtilizationDataTable.NewEQPUtilizationDataTableRow();
                row.EQP_ID = eqpid;
                row.Run = _eqpObs[eqpid].Run.ToString();
                row.Idle = _eqpObs[eqpid].Idle.ToString();
                row.Setup = _eqpObs[eqpid].Setup.ToString();

                _OutputData.EQPUtilizationDataTable.Rows.Add(row);
            }

            //DueDatesatisfaction
            foreach (string rbid in _Factory.MasterData.ReleaseBatch.ReleaseBatches)
            {
                ReleaseBatch rb = _Factory.MasterData.ReleaseBatch[rbid];

                int noGlasses = 0;

                if (_fabOutObs.NumberOfSatisfiedCassettes.ContainsKey(rb.ReleaseBatchID))
                    noGlasses = _fabOutObs.NumberOfSatisfiedCassettes[rb.ReleaseBatchID];
                double ratio = Math.Round((double)noGlasses / (double)rb.Quantity, 2);

                OutputDataSet.DueDateSatisfactionDataTableRow row =
                    _OutputData.DueDateSatisfactionDataTable.NewDueDateSatisfactionDataTableRow();

                row.Release_Batch_ID = rb.ReleaseBatchID;
                row.Product_ID = rb.ProductID;
                row.Quantity = rb.Quantity.ToString();
                row.Due_Date = rb.DueDate.ToString();
                row.Satisfaction_Ratio = ratio.ToString();

                _OutputData.DueDateSatisfactionDataTable.Rows.Add(row);
            }

            //ProductStepTAT            
            foreach (string productid in _Factory.MasterData.Product.Products)
            {
                IEnumerable<string> steps = _Factory.MasterData.BOP.ProductSteps[productid];                

                OutputDataSet.StepTATChartDataTableRow row4StepTATChart = _OutputData.StepTATChartDataTable.NewStepTATChartDataTableRow();
                row4StepTATChart.Product_ID = productid;
                foreach (string stepid in steps)
                {
                    SampleStatistics stat = _cstObs[productid, stepid];

                    double tat = 0;
                    if (stat != null)
                        tat = Math.Round(stat.Mean, 2);
                    OutputDataSet.ProductStepTATDataTableRow row =
                        _OutputData.ProductStepTATDataTable.NewProductStepTATDataTableRow();

                    row.Product_ID = productid;
                    row.Step_ID = stepid;
                    row.Average_TAT = tat.ToString();
                    _OutputData.ProductStepTATDataTable.Rows.Add(row);                    

                    row4StepTATChart[stepid] = tat.ToString();                   
                }
                _OutputData.StepTATChartDataTable.Rows.Add(row4StepTATChart);
            }

            //ProductTAT
            foreach (string productid in _Factory.MasterData.Product.Products)
            {
                SampleStatistics stat = _cstObs[productid];

                double tat = 0;
                if (stat != null)
                    tat = Math.Round(stat.Mean, 2);

                OutputDataSet.ProductTATDataTableRow row =
                    _OutputData.ProductTATDataTable.NewProductTATDataTableRow();

                row.Product_ID = productid;
                row.Total_TAT = tat.ToString();
                _OutputData.ProductTATDataTable.Rows.Add(row);
            }

            //Release Batch
            if (_Factory.FabIn.ReleaseCassettes.Count > 0)
            {
                Dictionary<string, int> sumData = new Dictionary<string,int>();
                for(int i = 0; i < _Factory.FabIn.ReleaseCassettes.Count; i++)
                {
                    Cassette cst = _Factory.FabIn.ReleaseCassettes[i];

                    string key = cst.ReleaseDate + "." + cst.J;

                    if (sumData.ContainsKey(key))
                    {
                        sumData[key] = sumData[key] + cst.N;
                    }else{
                        sumData.Add(key, cst.N);
                    }
                }

                foreach(string key in sumData.Keys)
                {
                    string[] splitData = key.Split('.');

                    int releaseDate = int.Parse(splitData[0]);
                    string productid = splitData[1];
                    int qty = sumData[key];

                    OutputDataSet.ReleaseBatchDataTableRow row =
                        _OutputData.ReleaseBatchDataTable.NewReleaseBatchDataTableRow();

                    row.DateTime = _Factory.MasterData.ReferenceStartDate.AddSeconds(releaseDate);
                    row.ProductID = productid;
                    row.Quantity = qty;

                    _OutputData.ReleaseBatchDataTable.Rows.Add(row);
                }
            }

            //Fabout Plan
            DateTime endDate = _Factory.MasterData.ReferenceStartDate.AddSeconds(_Factory.Clock);
            foreach (DateTime date in _Factory.MasterData.FabOutPlan.Data.Keys)
            {
                List<FabOutPlan> plans = _Factory.MasterData.FabOutPlan.Data[date];

                if (_OutputData.FabOutPlanDataTable.Columns.Count == 1)
                {
                    foreach (FabOutPlan fop in plans)
                    {
                        _OutputData.FabOutPlanDataTable.Columns.Add(fop.ProductID);
                    }
                }

                OutputDataSet.FabOutPlanDataTableRow row =  _OutputData.FabOutPlanDataTable.NewFabOutPlanDataTableRow();
                row.Date = date;
                if (row.Date > endDate)
                    continue;

                foreach (FabOutPlan fop in plans)
                {
                    int planedQty = fop.TargetQuantity;
                    int actualQty = 0;
                    int baseShift = 0;
                    TimeSpan ts = date.Subtract(_Factory.MasterData.ReferenceStartDate);
                    baseShift = ((int)ts.TotalDays) * 3 + 1;
                    //9/8:0  -> 1, 2, 3
                    //9/9:1  -> 4, 5, 6
                    //9/10:2 -> 7, 8, 9
                    if (_fabOutObs[fop.ProductID] != null)
                    {
                        int glasspercst = _Factory.MasterData.Product[fop.ProductID].GlassQuantity;
                        for (int i = baseShift; i <= baseShift + 2; i++)//start with 1st shift
                            actualQty += _fabOutObs[fop.ProductID][i] * glasspercst;
                    }
                    row[fop.ProductID] = actualQty + "/" + planedQty;
                }

                _OutputData.FabOutPlanDataTable.Rows.Add(row);
            }

            //GanttChart
            foreach (string eqpid in _eqpObs.Equipments)
            {
                EquipmentHistory eh = _eqpObs[eqpid];
                EquipmentLog lastLog = null;
                EquipmentLog lastRunLog = null;
                foreach (EquipmentLog log in eh.Logs)
                {
                    if (lastLog == null)
                    {
                        lastLog = log;
                        continue;
                    }

                    if (lastLog.State == EquipmentState.Idle)
                    {
                        lastLog = log;
                        continue;
                    }

                    if (lastLog.Time == log.Time && lastLog.State == log.State)
                    {
                        continue;
                    }

                    //addeda 2014/03/18 by D. Kang
                    if (lastLog.Time == log.Time)
                    {
                        lastLog = log;
                        continue;
                    }

                    if (lastLog.State == log.State && lastLog.CassetteID == log.CassetteID)
                    {
                        continue;                            
                    }

                    OutputDataSet.EQPGanttChartDataTableRow row =
                        _OutputData.EQPGanttChartDataTable.NewEQPGanttChartDataTableRow();
                    row.EQPID = eqpid;
                    if (lastLog.State == EquipmentState.Busy)
                        row.Category = "Run";
                    else if (lastLog.State == EquipmentState.Setup)
                        row.Category = "Setup";
                    row.StartTime = _Factory.MasterData.ReferenceStartDate.AddSeconds(lastLog.Time);
                    row.EndTime = _Factory.MasterData.ReferenceStartDate.AddSeconds(log.Time);

                    _OutputData.EQPGanttChartDataTable.Rows.Add(row);

                    lastLog = log;

                    if (log.State == EquipmentState.Busy)
                        lastRunLog = log;
                }
            }

            //Stocker Utilization and Transport Load
            foreach (string stkid in _stockerObs.Stockers)
            {
                OutputDataSet.STKUtilizationDataTableRow row =
                    _OutputData.STKUtilizationDataTable.NewSTKUtilizationDataTableRow();
                row.STK_ID = stkid;
                row.Idle = _stockerObs[stkid].Idle.ToString();
                row.Retrieval = _stockerObs[stkid].Retrieval.ToString();
                row.Delivery = _stockerObs[stkid].Delivery.ToString();

                _OutputData.STKUtilizationDataTable.Rows.Add(row);

                OutputDataSet.STKTransportLoadDataTableRow row2 =
                    _OutputData.STKTransportLoadDataTable.NewSTKTransportLoadDataTableRow();
                row2.STK_ID = stkid;
                if (_stkLoadObs.SI2Port.ContainsKey(stkid))
                    row2.SI2Port = (int)_stkLoadObs.SI2Port[stkid].ValueChanges[_stkLoadObs.SI2Port[stkid].ValueChanges.Count - 1].Value;
                else
                    row2.SI2Port = 0;
                if (_stkLoadObs.SI2Buf.ContainsKey(stkid))
                    row2.SI2Buf = (int)_stkLoadObs.SI2Buf[stkid].ValueChanges[_stkLoadObs.SI2Buf[stkid].ValueChanges.Count - 1].Value;
                else
                    row2.SI2Buf = 0;
                if (_stkLoadObs.SI2SO.ContainsKey(stkid))
                    row2.SI2SO = (int)_stkLoadObs.SI2SO[stkid].ValueChanges[_stkLoadObs.SI2SO[stkid].ValueChanges.Count - 1].Value;
                else
                    row2.SI2SO = 0;
                if (_stkLoadObs.Buf2Port.ContainsKey(stkid))
                    row2.Buf2Port = (int)_stkLoadObs.Buf2Port[stkid].ValueChanges[_stkLoadObs.Buf2Port[stkid].ValueChanges.Count - 1].Value;
                else
                    row2.Buf2Port = 0;
                if (_stkLoadObs.Buf2SO.ContainsKey(stkid))
                    row2.Buf2SO = (int)_stkLoadObs.Buf2SO[stkid].ValueChanges[_stkLoadObs.Buf2SO[stkid].ValueChanges.Count - 1].Value;
                else
                    row2.Buf2SO = 0;
                if (_stkLoadObs.Port2Buf.ContainsKey(stkid))
                    row2.Port2Buf = (int)_stkLoadObs.Port2Buf[stkid].ValueChanges[_stkLoadObs.Port2Buf[stkid].ValueChanges.Count - 1].Value;
                else
                    row2.Port2Buf = 0;
                if (_stkLoadObs.Port2SO.ContainsKey(stkid))
                    row2.Port2SO = (int)_stkLoadObs.Port2SO[stkid].ValueChanges[_stkLoadObs.Port2SO[stkid].ValueChanges.Count - 1].Value;
                else
                    row2.Port2SO = 0;
                if (_stkLoadObs.Port2Port.ContainsKey(stkid))
                    row2.Port2Port = (int)_stkLoadObs.Port2Port[stkid].ValueChanges[_stkLoadObs.Port2Port[stkid].ValueChanges.Count - 1].Value;
                else
                    row2.Port2Port = 0;
                if (_stkLoadObs.EmptyCassette.ContainsKey(stkid))
                    row2.Empty = (int)_stkLoadObs.EmptyCassette[stkid].ValueChanges[_stkLoadObs.EmptyCassette[stkid].ValueChanges.Count - 1].Value;
                else
                    row2.Empty = 0;

                _OutputData.STKTransportLoadDataTable.Rows.Add(row2);
            }

            //Moving Time 
            foreach (string key in _movingTimeObs.Keys)
            {
                string[] names = key.Split(new char[] { '.' }, StringSplitOptions.RemoveEmptyEntries);

                SampleStatistics stat = _movingTimeObs[key];

                OutputDataSet.CassetteMovingTimeDataTableRow row =
                    _OutputData.CassetteMovingTimeDataTable.NewCassetteMovingTimeDataTableRow();
                row.ProductID = names[0];
                row.FromStepID = names[1];
                row.ToStepID = names[2];
                row.AverageMovingTime = Math.Round(stat.Mean,2);
                row.MinMovingTime = Math.Round(stat.Minimum, 2);
                row.MaxMovingTime = Math.Round(stat.Maximum, 2);
                
                _OutputData.CassetteMovingTimeDataTable.Rows.Add(row);
            }

            //Crane Waiting Time
            foreach (string key in _CraneWaitingTimeObs.Keys)
            {
                SampleStatistics stat = _CraneWaitingTimeObs[key];

                OutputDataSet.STKCraneWaitingTimeDataTableRow row =
                    _OutputData.STKCraneWaitingTimeDataTable.NewSTKCraneWaitingTimeDataTableRow();
                row.STK_ID = key;
                row.Average = Math.Round(stat.Mean, 2);
                row.Min = Math.Round(stat.Minimum, 2);
                row.Max = Math.Round(stat.Maximum, 2);

                _OutputData.STKCraneWaitingTimeDataTable.Rows.Add(row);
            }

            //Transport Load



            return _OutputData;
        }
        #endregion

        public void Dispose()
        {
            Dispose(true);
        }

        private bool IsDisposed;
        protected virtual void Dispose(bool isDisposing)
        {
            if (IsDisposed) return;
            if (isDisposing)
            {
                // Dispose all Managed Resources
                //_Observers.Clear();

                string[] names = _Observers.Keys.ToArray<string>();
                for (int i = names.Length-1; i > 0; i--)
                {
                    _Observers[names[i]].Dispose();
                    _Observers.Remove(names[i]);
                }
                //foreach (Observer obs in _Observers.Values)
                //{
                //    //obs.Clear();
                //    obs.Dispose();
                //}
                //_Observers.Clear();
            }
            IsDisposed = true;
            GC.SuppressFinalize(this);
        } 

    }
}
