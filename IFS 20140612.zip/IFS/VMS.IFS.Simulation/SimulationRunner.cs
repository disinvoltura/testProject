﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.IFS.DataModel.OutputData;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.DataModel;
using VMS.IFS.Models;
using VMS.IFS.OuputDataCollection;
using VMS.IFS.Engine;
//using VMS.IFS.DecisionLogics;
using VMS.Foundation.Logging;

namespace VMS.IFS.Simulation
{
    public delegate void SimulationEndedEventHandler();

    public class SimulationRunner: IDisposable
    {
        #region Member Variables
        private string _Name;

        private Dictionary<string, object> _RunOptions;
        public InputDataSet _InputData;

        private Factory _Factory;
        private OutputReportGenerator _oprGen;

        private DateTime _SimStartTime;
        private DateTime _SimEndTime;

        //private Dictionary<string, Observer> _Observers;

        //private OutputDataSet _OutputData;

        private bool _IsAborted = false;
        private bool _IsCompleted = false;
        #endregion

        #region Events
        public event SimulationEndedEventHandler SimulationEnded;
        #endregion

        #region Properties
        public Factory Factory { get { return _Factory; } }

        public OutputReportGenerator OutputReportGenerator
        {
            get { return _oprGen; }
        }

        public string Name { get { return _Name; } }

        public Dictionary<string, object> RunOptions
        {
            get { return _RunOptions; }
        }

        public bool IsAborted { get { return _IsAborted; } }
        public bool IsCompleted { get { return _IsCompleted; } }
        #endregion

        #region Constructors
        public SimulationRunner(string name, InputDataSet ids, Dictionary<string, object> runOptions)
        {
            _InputData = ids;
            _RunOptions = runOptions;
            //_Observers = new Dictionary<string, Observer>();
        }
        #endregion

        #region Methods
        public void Stop()
        {
            _IsAborted = true;
            _Factory.Stop();
        }

        public void Run()
        {
            bool logging = (bool)_RunOptions[SimulationArguments.Logging];
            
            doInitialize();
            doSetExpFrame();
            
            if (logging)
                doSetLogger();
            
            doRun();

            if (!_IsAborted)
            {
                doFinalize();
                //doGenerateOutputData();
            }

            _IsCompleted = true;
        }

        /// <summary>
        /// Initialize all nencessary objects
        /// </summary>
        private void doInitialize()
        {
            _Factory = new Factory("LCD Fab");
            _Factory.Initialize(_InputData, _RunOptions);

            //RTD
            _Factory.RTD.Initialize(_RunOptions);

            //MCS

            //OutputReport Generator
            _oprGen = new OutputReportGenerator(_Factory, _RunOptions);
            _oprGen.Initialize();
        }

        /// <summary>
        /// Setup all observers, which require to register to event object simulators of interest.
        /// </summary>
        private void doSetExpFrame()
        {   
            //Cassette Observer
            _Factory.UniInlineCell.RegisterObserver(_oprGen.CassetteObserver);
            _Factory.BiInlineCell.RegisterObserver(_oprGen.CassetteObserver);
            _Factory.Chamber.RegisterObserver(_oprGen.CassetteObserver);
            _Factory.Oven.RegisterObserver(_oprGen.CassetteObserver);
            _Factory.Stocker.RegisterObserver(_oprGen.CassetteObserver);
            _Factory.Conveyor.RegisterObserver(_oprGen.CassetteObserver);
            _Factory.FabIn.RegisterObserver(_oprGen.CassetteObserver);
            _Factory.FabOut.RegisterObserver(_oprGen.CassetteObserver);

            //Equipment Observer
            _Factory.UniInlineCell.RegisterObserver(_oprGen.EquipmentObserver);
            _Factory.BiInlineCell.RegisterObserver(_oprGen.EquipmentObserver);
            _Factory.Chamber.RegisterObserver(_oprGen.EquipmentObserver);
            _Factory.Oven.RegisterObserver(_oprGen.EquipmentObserver);

            //FabIn Observer
            _Factory.FabIn.RegisterObserver(_oprGen.FabInObserver); 

            //FabOut Observer
            _Factory.FabOut.RegisterObserver(_oprGen.FabOutObserver);

            //_Factory.FabIn.AddObserver(_oprGen.CassetteTATObserver);
            //_Factory.FabOut.AddObserver(_oprGen.CassetteTATObserver);

            //FabWIP Observer
            _Factory.FabIn.RegisterObserver(_oprGen.FabWIPObserver);
            _Factory.FabOut.RegisterObserver(_oprGen.FabWIPObserver);

            //Stocker WIP Observer
            _Factory.Stocker.RegisterObserver(_oprGen.StockerWIPObserver);
            _Factory.Conveyor.RegisterObserver(_oprGen.StockerWIPObserver);
            _Factory.BiInlineCell.RegisterObserver(_oprGen.StockerWIPObserver);
            
            //Conveyor WIP Observer
            _Factory.Stocker.RegisterObserver(_oprGen.ConveyorWIPObserver);
            _Factory.Conveyor.RegisterObserver(_oprGen.ConveyorWIPObserver);

            //Stocker Observer
            _Factory.Stocker.RegisterObserver(_oprGen.StockerObserver);

            //CassetteMovingTime Observer
            _Factory.UniInlineCell.RegisterObserver(_oprGen.MovingTimeObserver);
            _Factory.BiInlineCell.RegisterObserver(_oprGen.MovingTimeObserver);
            _Factory.Chamber.RegisterObserver(_oprGen.MovingTimeObserver);
            _Factory.Oven.RegisterObserver(_oprGen.MovingTimeObserver);
            _Factory.FabOut.RegisterObserver(_oprGen.MovingTimeObserver);

            //CraneWaitingTime Observer
            _Factory.Stocker.RegisterObserver(_oprGen.CraneWaitingTimeObserver);
            _Factory.FabOut.RegisterObserver(_oprGen.CraneWaitingTimeObserver);

            //TransportLoad Observer
            _Factory.Stocker.RegisterObserver(_oprGen.StockerLoadObserver);
        }

        private void doSetLogger()
        {
            VMS.Foundation.Logging.SimpleFormatter formatter = new VMS.Foundation.Logging.SimpleFormatter();
            formatter.WriteLoggerInfo = false;
            formatter.WriteTimeStamp = false;

            Logger logger = LogManager.GetLogger("SimulationCoordinator");
            logger.Level = LogLevel.Always;
            logger.AddHandler(new VMS.Foundation.Logging.FileLogHandler("SimulationCoordinator", formatter));

            Logger logger2 = LogManager.GetLogger("SimulationData");
            logger2.Level = LogLevel.Always;
            logger2.AddHandler(new VMS.Foundation.Logging.FileLogHandler("SimulationData", formatter));

            Logger logger3 = LogManager.GetLogger("JobSelectionRule");
            logger3.Level = LogLevel.Always;
            logger3.AddHandler(new VMS.Foundation.Logging.FileLogHandler("JobSelectionRule", formatter));

            Logger logger4 = LogManager.GetLogger("MachineSelectionRule");
            logger4.Level = LogLevel.Always;
            logger4.AddHandler(new VMS.Foundation.Logging.FileLogHandler("MachineSelectionRule", formatter));
         
            //Log RunOptions
            logger.Info("Run Options --------------------------------------");
            foreach (string key in _RunOptions.Keys)
            {
                string log = string.Format("{0} = {1}", key, _RunOptions[key].ToString());
                logger.Info(log);
            }
            logger.Info("--------------------------------------------------");

        }

        private void doRun()
        {
            Logger logger = LogManager.GetLogger("SimulationCoordinator");

            //Run
            _SimStartTime = DateTime.Now;
            logger.Info("Starts at " + _SimStartTime.ToString());
            
            _Factory.Run();

            _SimEndTime = DateTime.Now;
            logger.Info("Ends at " + _SimEndTime.ToString());
            
        }

        private void doFinalize()
        {
            //Finalize Observer
            _oprGen.Finish();

            //Shutdown Loggers
            LogManager.Shutdown();

            //GC.Collect();
        }

        /*
        private void doGenerateOutputData()
        {
            //Generate Output Data
            _OutputData = new OutputDataSet();
            _OutputData = _oprGen.Transduce();
        }
        */

        public void Dispose()
        {
            Dispose(true);
        }

        private bool IsDisposed;
        protected virtual void Dispose(bool isDisposing)
        {
          if(IsDisposed) return;
          if(isDisposing)
          {
                // Dispose all Managed Resources
                //_Factory;
                //_oprGen;
              _Factory.Dispose();
              _oprGen.Dispose();
              _InputData.Dispose();
              
             // LogManager.Shutdown();
          }
          IsDisposed = true;
          GC.SuppressFinalize(this);
        } 

        #endregion
    }
}
