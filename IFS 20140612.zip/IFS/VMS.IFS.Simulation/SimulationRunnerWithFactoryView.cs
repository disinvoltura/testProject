﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.IFS.DataModel.OutputData;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.DataModel;
using VMS.IFS.Models;
using VMS.IFS.OuputDataCollection;
using VMS.IFS.Engine;
//using VMS.IFS.DecisionLogics;
using VMS.Foundation.Logging;

namespace VMS.IFS.UI
{
    public class SimulationRunnerWithFactoryView
    {
        #region Member Variables
        private Dictionary<string, object> _RunOptions;
        public InputDataSet _InputData;

        private Factory _Factory;
        private OutputReportGenerator _oprGen;

        private DateTime _SimStartTime;
        private DateTime _SimEndTime;

        private Dictionary<string, Observer> _Observers;

        private OutputDataSet _OutputData;

        private FabViewSimulator _FVSimulator;
        private FactoryViewWindow _Window;
        #endregion

        #region Properties
        public Factory Factory { get { return _Factory; } }
        public OutputDataSet OutputData
        {
            get { return _OutputData; }
        }

        public Dictionary<string, object> RunOptions
        {
            get { return _RunOptions; }
        }
        #endregion

        /// <summary>
        /// Return an observer
        /// </summary>
        /// <param name="?"></param>
        /// <returns></returns>
        public Observer this[string name]
        {
            get
            {
                return _oprGen[name];
            }   
        }

        #region Constructors
        public SimulationRunnerWithFactoryView(InputDataSet ids, Dictionary<string, object> runOptions, FactoryViewWindow w)
        {
            _InputData = ids;
            _RunOptions = runOptions;
            _Window = w;
            _Observers = new Dictionary<string, Observer>();
        }
        #endregion

        #region Methods
        public bool Run()
        {
            bool rslt = true;
            bool logging = (bool)_RunOptions[SimulationArguments.Logging];
            
            doInitialize();
            doSetExpFrame();
            
            if (logging)
                doSetLogger();
            
            doRun();            
            doFinalize();
            doGenerateOutputData();            

            return rslt;
        }

        private void doInitialize()
        {
            _Factory = new Factory("LCD Fab");
            _Factory.Initialize(_InputData, _RunOptions);

            _FVSimulator = new FabViewSimulator(_Factory, _Window);
            _Factory.SimulationCoordinator.AddEventObjectSimulator(_FVSimulator);
            
            //RTD
            _Factory.RTD.Initialize(_RunOptions);

            //MCS

            //OutputReport Generator
            _oprGen = new OutputReportGenerator(_Factory, _RunOptions);
            _oprGen.Initialize();
        }

        private void doSetExpFrame()
        {   
            //Cassette Observer
            _Factory.UniInlineCell.AddObserver(_oprGen.CassetteObserver);
            _Factory.BiInlineCell.AddObserver(_oprGen.CassetteObserver);
            _Factory.Chamber.AddObserver(_oprGen.CassetteObserver);
            _Factory.Oven.AddObserver(_oprGen.CassetteObserver);
            _Factory.Stocker.AddObserver(_oprGen.CassetteObserver);
            _Factory.Conveyor.AddObserver(_oprGen.CassetteObserver);
            _Factory.FabIn.AddObserver(_oprGen.CassetteObserver);
            _Factory.FabOut.AddObserver(_oprGen.CassetteObserver);

            //Equipment Observer
            _Factory.UniInlineCell.AddObserver(_oprGen.EquipmentObserver);
            _Factory.BiInlineCell.AddObserver(_oprGen.EquipmentObserver);
            _Factory.Chamber.AddObserver(_oprGen.EquipmentObserver);
            _Factory.Oven.AddObserver(_oprGen.EquipmentObserver);

            //FabIn Observer
            _Factory.FabIn.AddObserver(_oprGen.FabInObserver);
            //FabOut Observer
            _Factory.FabOut.AddObserver(_oprGen.FabOutObserver);

            //_Factory.FabIn.AddObserver(_oprGen.CassetteTATObserver);
            //_Factory.FabOut.AddObserver(_oprGen.CassetteTATObserver);

            //FabWIP Observer
            _Factory.FabIn.AddObserver(_oprGen.FabWIPObserver);
            _Factory.FabOut.AddObserver(_oprGen.FabWIPObserver);

            //Stocker WIP Observer
            _Factory.Stocker.AddObserver(_oprGen.StockerWIPObserver);
            _Factory.Conveyor.AddObserver(_oprGen.StockerWIPObserver);
            
            //Conveyor WIP Observer
            _Factory.Stocker.AddObserver(_oprGen.ConveyorWIPObserver);
            _Factory.Conveyor.AddObserver(_oprGen.ConveyorWIPObserver);

            //Stocker Observer
            _Factory.Stocker.AddObserver(_oprGen.StockerObserver);

            //CassetteMovingTime Observer
            _Factory.UniInlineCell.AddObserver(_oprGen.MovingTimeObserver);
            _Factory.BiInlineCell.AddObserver(_oprGen.MovingTimeObserver);
            _Factory.Chamber.AddObserver(_oprGen.MovingTimeObserver);
            _Factory.Oven.AddObserver(_oprGen.MovingTimeObserver);
            _Factory.FabOut.AddObserver(_oprGen.MovingTimeObserver);

            //CraneWaitingTime Observer
            _Factory.Stocker.AddObserver(_oprGen.CraneWaitingTimeObserver);
            _Factory.FabOut.AddObserver(_oprGen.CraneWaitingTimeObserver);

            //TransportLoad Observer
            _Factory.Stocker.AddObserver(_oprGen.StockerLoadObserver);
        }

        private void doSetLogger()
        {
            VMS.Foundation.Logging.SimpleFormatter formatter = new VMS.Foundation.Logging.SimpleFormatter();
            formatter.WriteLoggerInfo = false;
            formatter.WriteTimeStamp = false;

            Logger logger = LogManager.GetLogger("SimulationCoordinator");
            logger.Level = LogLevel.Always;
            logger.AddHandler(new VMS.Foundation.Logging.FileLogHandler("SimulationCoordinator", formatter));

            Logger logger2 = LogManager.GetLogger("SimulationData");
            logger2.Level = LogLevel.Always;
            logger2.AddHandler(new VMS.Foundation.Logging.FileLogHandler("SimulationData", formatter));

            Logger logger3 = LogManager.GetLogger("JobSelectionRule");
            logger3.Level = LogLevel.Always;
            logger3.AddHandler(new VMS.Foundation.Logging.FileLogHandler("JobSelectionRule", formatter));

            Logger logger4 = LogManager.GetLogger("MachineSelectionRule");
            logger4.Level = LogLevel.Always;
            logger4.AddHandler(new VMS.Foundation.Logging.FileLogHandler("MachineSelectionRule", formatter));
         
            //Log RunOptions
            logger.Info("Run Options --------------------------------------");
            foreach (string key in _RunOptions.Keys)
            {
                string log = string.Format("{0} = {1}", key, _RunOptions[key].ToString());
                logger.Info(log);
            }
            logger.Info("--------------------------------------------------");

        }

        private void doRun()
        {
            Logger logger = LogManager.GetLogger("SimulationCoordinator");

            //Run
            _SimStartTime = DateTime.Now;
            logger.Info("Starts at " + _SimStartTime.ToString());
            
            _Factory.Run();

            _SimEndTime = DateTime.Now;
            logger.Info("Ends at " + _SimEndTime.ToString());
            
        }

        private void doFinalize()
        {
            //Finalize Observer
            _oprGen.Finish();

            //Shutdown Loggers
            LogManager.Shutdown();
        }

        private void doGenerateOutputData()
        {
            //Generate Output Data
            _OutputData = new OutputDataSet();
            _OutputData = _oprGen.Transduce();
        }
        #endregion
    }
}
