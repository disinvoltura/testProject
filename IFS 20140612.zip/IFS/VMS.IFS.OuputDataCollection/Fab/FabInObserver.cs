﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.Models;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.OuputDataCollection
{
    public class FabInObserver : FactoryEventObserver
    {
        #region Member Variables
        private TimeBucketTallyStatistics _Tally;
        //Number of cassettes that released into the fab per shift
        private Dictionary<string, TimeBucketTallyStatistics> _ProductTally;

        //Time Units per a shift (in hours)
        private int _ShiftTime;
        #endregion

        #region Properties
        public TimeBucketTallyStatistics Statistics
        {
            get { return _Tally; }
        }

        public TimeBucketTallyStatistics this[string productid]
        {
            get {
                TimeBucketTallyStatistics rslt = null;
                if (_ProductTally.ContainsKey(productid))
                    rslt = _ProductTally[productid];
                return rslt; 
            }
        }
        #endregion

        #region Constructors
        public FabInObserver(Factory factory, Dictionary<string, object> runOptions)
            : base("FabInObserver", factory)
        {
            _ShiftTime =(int)runOptions[SimulationArguments.UnitTime]; 
            _Tally = new TimeBucketTallyStatistics(
                        "Number of FabIn Cassettes", _ShiftTime);

            _ProductTally = new Dictionary<string, TimeBucketTallyStatistics>();
        }

        #endregion

        #region Methods
        public override void Clear()
        {
            _Tally.Clear();

            string[] products = _ProductTally.Keys.ToArray<string>();
            for (int i = products.Length - 1; i > 0; i--)
            {
                _ProductTally[products[i]].Dispose();
                _ProductTally.Remove(products[i]);
            }

            //foreach (string key in _ProductTally.Keys)
            //    _ProductTally[key].Clear();

        }

        //public override void Update(ObservedEvent e)
        public override void Update(EventObservedEvent evt)
        {
            //EventObservedEvent evt = (EventObservedEvent)e;

            if ((evt.EventObject.Name == "FabIn") &&
                (evt.Event.Name == "Move"))
            {
                _Tally.Add(evt.Time);

                if (evt.Event is FactoryLocalEvent)
                {
                    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;

                    string prodid = fle.Cassette.J;
                    if (_ProductTally.ContainsKey(prodid))
                    {
                        TimeBucketTallyStatistics stat = _ProductTally[prodid];
                        stat.Add(evt.Time);
                        _ProductTally[prodid] = stat;
                    }
                    else
                    {
                        TimeBucketTallyStatistics stat = new TimeBucketTallyStatistics(prodid + ".ShiftTally", _ShiftTime);
                        stat.Add(evt.Time);
                        _ProductTally.Add(prodid, stat);
                    }
                }
            }
        }

        public override void Finalize(double eosTime)
        {

        }

        public override void Dispose()
        {
            Dispose(true);
        }

        private bool IsDisposed;
        protected virtual void Dispose(bool isDisposing)
        {
            if (IsDisposed) return;
            if (isDisposing)
            {
                // Dispose all Managed Resources
                this.Clear();
            }
            IsDisposed = true;
            GC.SuppressFinalize(this);
        } 



        #endregion
    }
}
