﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.Models;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.OuputDataCollection
{
    public class FabOutObserver : FactoryEventObserver
    {
        #region Member Variables
        private TimeBucketTallyStatistics _Tally;

        // Key: release batch id, value: number of glasses finished within due date
        private Dictionary<string, int> _DueDates;

        //Number of cassettes that exit the fab per shift
        private Dictionary<string, TimeBucketTallyStatistics> _ProductTally;
        
        //Time Units per a shift (in hours)
        private int _TimeBucket;
        #endregion

        #region Properties
        public TimeBucketTallyStatistics Statistics
        {
            get { return _Tally; }
        }

        public TimeBucketTallyStatistics this[string productid]
        {
            get
            {
                TimeBucketTallyStatistics rslt = null;
                if (_ProductTally.ContainsKey(productid))
                    rslt = _ProductTally[productid];
                return rslt;
            }
        }

        /// <summary>
        /// Number of cassettes that satisfy the due date
        /// </summary>
        public Dictionary<string, int> NumberOfSatisfiedCassettes
        {
            get
            {
                return _DueDates;
            }
        }
        #endregion

        #region Constructors
        public FabOutObserver(Factory factory, Dictionary<string, object> runOptions)
            : base("FabOutObserver", factory)
        {
            _TimeBucket = (int)runOptions[SimulationArguments.UnitTime]; 

            _Tally = new TimeBucketTallyStatistics(
                            "Number of FabOut Cassettes",
                            _TimeBucket);

            _ProductTally = new Dictionary<string, TimeBucketTallyStatistics>();

            _DueDates = new Dictionary<string, int>();
        }
        #endregion

        #region Methods
        public override void Clear()
        {
            _Tally.Clear();
            _DueDates.Clear();

            string[] products = _ProductTally.Keys.ToArray<string>();
            for (int i = products.Length - 1; i > 0; i--)
            {
                _ProductTally[products[i]].Dispose();
                _ProductTally.Remove(products[i]);
            }

            //foreach (string key in _ProductTally.Keys)
            //    _ProductTally[key].Clear();
            //_ProductTally.Clear();
        }

        //public override void Update(ObservedEvent e)
        public override void Update(EventObservedEvent evt)
        {
            //EventObservedEvent evt = (EventObservedEvent)e;
            if ((evt.EventObject.Name == "FabOut") && 
                (evt.Event.Name == "CFO"))
            {
                _Tally.Add(evt.Time);

                if (evt.Event is FactoryLocalEvent)
                {
                    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                    Cassette cst = (Cassette)fle[0];
                    
                    if (fle.Time <= cst.DueDate)
                    {
                        if (_DueDates.ContainsKey(cst.RBID))
                            _DueDates[cst.RBID] = _DueDates[cst.RBID] + cst.N;
                        else
                            _DueDates.Add(cst.RBID, cst.N);
                    }

                    string prodid = cst.J;
                    if (_ProductTally.ContainsKey(prodid))
                    {
                        TimeBucketTallyStatistics stat = _ProductTally[prodid];
                        stat.Add(evt.Time);
                        _ProductTally[prodid] = stat;
                    }
                    else
                    {
                        TimeBucketTallyStatistics stat = new TimeBucketTallyStatistics(prodid + ".ShiftTally", _TimeBucket);
                        stat.Add(evt.Time);
                        _ProductTally.Add(prodid, stat);
                    }
                }
            }
        }

        public override void Finalize(double eosTime)
        {
            
        }

        public override void Dispose()
        {
            Dispose(true);
        }

        private bool IsDisposed;
        protected virtual void Dispose(bool isDisposing)
        {
            if (IsDisposed) return;
            if (isDisposing)
            {
                // Dispose all Managed Resources
                this.Clear();
            }
            IsDisposed = true;
            GC.SuppressFinalize(this);
        } 

        #endregion
    }
}
