﻿using System;
using System.Collections.Generic;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.Models;
namespace VMS.IFS.OuputDataCollection
{
    public abstract class FactoryEventObserver: EventObserver
    {
        #region Member Variables
        private Factory _Factory;

        #endregion

        #region Properties
        public Factory Factory { get { return _Factory; } }
        #endregion

        #region Constructors
        public FactoryEventObserver(string name, Factory factory)
            : base(name)
        {
            _Factory = factory;
        }
        #endregion

        #region Methods
        #endregion
    }
}
