﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.OuputDataCollection
{
    public class TimeDependentStatistics: Statistics
    {
        #region Member Variables
        //private List<ValueChange> _ValueChanges;
        private double _Mean;
        private double _Variance;

        private double _Diff;
        private double _LastTime;
        private double _StartTime;
        #endregion

        #region Properties
        public double Mean
        {
            get { return _Mean; }
        }

        public double Variance
        {
            get { return _Variance; }
        }

        public double StandarDeviation
        {
            get { return Math.Sqrt(this.Variance); }
        }
        #endregion

        #region Constructors
        public TimeDependentStatistics(string name)
            : base(name)
        {
            _Mean = 0;
            _Variance = 0;

            _Diff = 0;
            _StartTime = 0;
            _LastTime = 0;
        }
        #endregion

        #region Methods
        public override void Add(double time, double val)
        {
            base.Add(time, val);

            if (this.Count == 1)
            {
                _Mean = _Diff;
                _Variance = 0;
            }else if (time > _LastTime)
            {
                double factor = 1.0 - (_LastTime - time) / (time - _StartTime);
                _Mean += _Diff * factor;
                _Variance += factor * ((1.0 - factor) * _Diff * _Diff - _Variance);
            }
            _Diff = val - _Mean;
            _LastTime = time;
        }
        #endregion

    }

}