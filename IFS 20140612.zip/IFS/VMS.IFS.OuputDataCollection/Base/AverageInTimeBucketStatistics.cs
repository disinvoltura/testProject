﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.OuputDataCollection
{
    //product 별 shift 별 average TAT - 3/20 김현식
    public class AverageInTimeBucketStatistics : Statistics
    {
        #region Member Variables        
        private Dictionary<int, double> _TimeBucketValues;
        private Dictionary<int, int> _TimeBucketCounts;
        private int _TimeBucket; //in seconds
        private int currentTimeBucket = 1;        

        public double this[int shift]
        {
            get
            {
                double rslt = 0;
                if (_TimeBucketValues.ContainsKey(shift))
                    rslt = _TimeBucketValues[shift];
                return rslt;
            }
        }

        private Dictionary<int, double> _Mean;
        private Dictionary<int, double> _Variance;
        private Dictionary<int, double> _TBMinValue;
        private Dictionary<int, double> _TBMaxValue;

        private double _Diff;
        private double _LastTime;
        private double _StartTime;
        #endregion

        #region Properties
        public double Mean(int shift)
        {
            return _Mean[shift];
        }

        public double Variance(int shift)
        {
            return _Variance[shift];
        }

        public double StandarDeviation(int shift)
        {
            return Math.Sqrt(this.Variance(shift));
        }        
        #endregion

        #region Constructors
        public AverageInTimeBucketStatistics(string name, int timebucket)
            : base(name)
        {            
            _TimeBucket = timebucket * 3600;
            _TimeBucketValues = new Dictionary<int, double>();
            _TimeBucketCounts = new Dictionary<int, int>();

            _Mean = new Dictionary<int,double>();
            _Variance = new Dictionary<int, double>();
            _TBMinValue = new Dictionary<int, double>();
            _TBMaxValue = new Dictionary<int, double>();

            _Diff = 0;
            _StartTime = 0;
            _LastTime = 0;
        }
        #endregion

        #region Methods
        public override void Add(double time, double val)
        {
            base.Add(time, val);

            int timeBucket = (int)(time / _TimeBucket) + 1;

            if (_TimeBucketValues.ContainsKey(timeBucket))
            {
                _TimeBucketValues[timeBucket] += val;
                _TimeBucketCounts[timeBucket]++;
                if (val < _TBMinValue[timeBucket])
                    _TBMinValue[timeBucket] = val;
                if (val > _TBMaxValue[timeBucket])
                    _TBMaxValue[timeBucket] = val;

                double factor = (double)1 / _TimeBucketCounts[timeBucket];
                _Diff = val - _Mean[timeBucket];                   
                _Mean[timeBucket] += _Diff * factor;
                _Variance[timeBucket] += factor * ((1.0 - factor) * _Diff * _Diff - _Variance[timeBucket]);
            }
            else
            {
                _TimeBucketValues.Add(timeBucket, val);
                _TimeBucketCounts.Add(timeBucket, 1);                
                _TBMinValue.Add(timeBucket, val);
                _TBMaxValue.Add(timeBucket, val);

                _Mean.Add(timeBucket, val);
                _Variance.Add(timeBucket, 0);
            }            
        }

        public override void Clear()
        {
            base.Clear();

            _TimeBucketValues.Clear();
            _TimeBucketCounts.Clear();

            _Mean.Clear();
            _Variance.Clear();
            _TBMinValue.Clear();
            _TBMaxValue.Clear();
        }

        public override void Dispose()
        {
            Dispose(true);
        }

        private bool IsDisposed;
        protected virtual void Dispose(bool isDisposing)
        {
            if (IsDisposed) return;
            if (isDisposing)
            {
                // Dispose all Managed Resources
                this.Clear();
            }
            IsDisposed = true;
            GC.SuppressFinalize(this);
        } 


        #endregion    
    }
}
