﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.OuputDataCollection
{
    public class TallyStatistics : Statistics
    {
        #region Member Variables
        #endregion

        #region Properties

        #endregion

        #region Constructors
        public TallyStatistics(string name)
            : base(name)
        {
        }
        #endregion

        #region Methods
        public void Add(double time)
        {
            base.Add(time, this.Count + 1);
        }
        #endregion
    }

    
}
