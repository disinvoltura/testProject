﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.OuputDataCollection
{
    public class TimeBucketDependentStatistics: Statistics
    {
        #region Member Variables
        private Dictionary<int, double> _TimeBucketValues;
        private int _TimeBucket; //in seconds
        private int currentTimeBucket = 1;

        public double this[int shift]
        {
            get
            {
                double rslt = 0;
                if (_TimeBucketValues.ContainsKey(shift))
                    rslt = _TimeBucketValues[shift];
                return rslt;
            }
        }

        private double _Mean;
        private double _Variance;

        private double _Diff;
        private double _LastTime;
        private double _StartTime;
        #endregion

        #region Properties
        public double Mean
        {
            get { return _Mean; }
        }

        public double Variance
        {
            get { return _Variance; }
        }

        public double StandarDeviation
        {
            get { return Math.Sqrt(this.Variance); }
        }
        #endregion

        #region Constructors
        public TimeBucketDependentStatistics(string name, int timebucket)
            : base(name)
        {
            _TimeBucket = timebucket * 3600;
            _TimeBucketValues = new Dictionary<int, double>();

            _Mean = 0;
            _Variance = 0;

            _Diff = 0;
            _StartTime = 0;
            _LastTime = 0;
        }
        #endregion

        #region Methods
        public override void Add(double time, double val)
        {
            base.Add(time, val);

            if (this.Count == 1)
            {
                _Mean = _Diff;
                _Variance = 0;
            }else if (time > _LastTime)
            {
                double factor = 1.0 - (_LastTime - time) / (time - _StartTime);
                _Mean += _Diff * factor;
                _Variance += factor * ((1.0 - factor) * _Diff * _Diff - _Variance);
            }
            _Diff = val - _Mean;
            _LastTime = time;

            int timeBucket = (int)(time / _TimeBucket) + 1;
            if (timeBucket > currentTimeBucket)
            {
                double lastVal = 0;
                if (_TimeBucketValues.ContainsKey(currentTimeBucket))
                    lastVal = _TimeBucketValues[currentTimeBucket];

                while (timeBucket > (currentTimeBucket+1))
                {
                    currentTimeBucket++;
                    _TimeBucketValues.Add(currentTimeBucket, lastVal);
                }
                _TimeBucketValues.Add(timeBucket, val);
                currentTimeBucket = timeBucket;
            }
            else
            {
                _TimeBucketValues[currentTimeBucket] = val;
            }
        }

        public override void Clear()
        {
            base.Clear();

            _TimeBucketValues.Clear();
        }

        public override void Dispose()
        {
            Dispose(true);
        }

        private bool IsDisposed;
        protected virtual void Dispose(bool isDisposing)
        {
            if (IsDisposed) return;
            if (isDisposing)
            {
                // Dispose all Managed Resources
                this.Clear();
            }
            IsDisposed = true;
            GC.SuppressFinalize(this);
        } 


        #endregion

    }

}