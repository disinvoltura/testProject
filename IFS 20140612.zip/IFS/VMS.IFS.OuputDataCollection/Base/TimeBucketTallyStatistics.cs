﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.OuputDataCollection
{
    public class TimeBucketTallyStatistics : Statistics
    {
        #region Member Variables
        private Dictionary<int, int> _ShiftTallies;
        private int _ShiftTime; //in seconds
        #endregion

        #region Properties
        public int this[int shift]
        {
            get {
                int rslt = 0;
                if (_ShiftTallies.ContainsKey(shift))
                    rslt = _ShiftTallies[shift];
                return rslt; }
        }

        #endregion

        #region Constructors
        public TimeBucketTallyStatistics(string name, int shiftTime)
            : base(name)
        {
            _ShiftTallies = new Dictionary<int, int>();
            _ShiftTime = shiftTime * 3600;
        }
        #endregion

        #region Methods
        public void Add(double time)
        {
            base.Add(time, this.Count + 1);

            int shift = (int)(time / _ShiftTime) + 1;
            if (_ShiftTallies.ContainsKey(shift))
            {
                _ShiftTallies[shift] = _ShiftTallies[shift] + 1;
            }
            else
            {
                _ShiftTallies.Add(shift, 1);
            }
        }

        public void Clear()
        {
            base.Clear();

            _ShiftTallies.Clear();
        }
        #endregion
    }
}
