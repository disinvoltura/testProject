﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.Models;

namespace VMS.IFS.OuputDataCollection
{
    public class CassetteTATObserver : FactoryEventObserver
    {
        #region Member Variables
        //Key: cassette id, value: pair of fabin and fabout time
        private Dictionary<int, double[]> _Data;

        //Key: product id, value: sample stat for a product
        private Dictionary<string, SampleStatistics> _Stats;

        private string _FabInObjectName = "FabIn";
        private string _FabInEventName = "Move";
        private string _FabOutObjectName = "FabOut";
        private string _FabOutEventname = "CFO";
        #endregion

        #region Properties
        public SampleStatistics this[string productid]
        {
            get
            {
                SampleStatistics rslt = null;
                if (_Stats.ContainsKey(productid))
                    rslt = _Stats[productid];
                return rslt;
            }
        }
        #endregion

        #region Constructors
        public CassetteTATObserver(Factory factory, Dictionary<string, object> runOptions)
            : base("TATObserver", factory)
        {
            _Data = new Dictionary<int, double[]>();
            _Stats = new Dictionary<string, SampleStatistics>();
        }
        #endregion

        #region Methods
        public override void Clear()
        {
            _Data.Clear();

            string[] products = _Stats.Keys.ToArray<string>();
            for (int i = products.Length - 1; i >= 0; i--)
            {
                _Stats[products[i]].Dispose();
                _Stats.Remove(products[i]);
            }
            //foreach (string key in _Stats.Kys)
            //    _Stats[key].Clear();
            //_Stats.Clear();
        }

        //public override void Update(ObservedEvent e)
        public override void Update(EventObservedEvent evt)
        {
            //EventObservedEvent evt = (EventObservedEvent)e;
            
            if (evt.EventObject.Name == _FabInObjectName &&
                evt.Event.Name == _FabInEventName)
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                Cassette cst = (Cassette)fle.Cassette;
                //DataModel.Cassette cst = (DataModel.Cassette)fle[0];
                double[] times = new double[] { evt.Time, 0 };

                _Data.Add(cst.ID, times);
            }
            else if (evt.EventObject.Name == _FabOutObjectName &&
                     evt.Event.Name == _FabOutEventname)
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                Cassette cst = (Cassette)fle[0];
                if (_Data.ContainsKey(cst.ID))
                {
                    double[] times = _Data[cst.ID];
                    times[1] = fle.Time;

                    if (_Stats.ContainsKey(cst.J))
                    {
                        SampleStatistics stat = _Stats[cst.J];
                        stat.Add(fle.Time, times[1] - times[0]); //seconds
                        _Stats[cst.J] = stat;
                    }
                    else
                    {
                        SampleStatistics stat = new SampleStatistics("Product TAT: " + cst.J);
                        stat.Add(fle.Time, times[1] - times[0]); //seconds
                        _Stats.Add(cst.J, stat);
                    }
                }
            }
        }

        public override void Finalize(double eosTime)
        {
            foreach (string productid in _Stats.Keys)
            {
                SampleStatistics stat = _Stats[productid];
                stat.Finalize(eosTime);
            }
        }

        public override void Dispose()
        {
            Dispose(true);
        }

        private bool IsDisposed;
        protected virtual void Dispose(bool isDisposing)
        {
            if (IsDisposed) return;
            if (isDisposing)
            {
                // Dispose all Managed Resources
                this.Clear();
            }
            IsDisposed = true;
            GC.SuppressFinalize(this);
        } 

        #endregion
    }
}
