﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.OuputDataCollection
{
    public class CassetteLog: IComparable<CassetteLog>
    {
        #region Member Variables
        private int _CID;
        private double _Time;
        private CassetteState _State;        
        private string _Equipment;
        private string _J;
        private string _P;
        private string _A;
        private string _B;
        private string _C;
        private string _D;
        private string _R;
        private string _RBID;
        #endregion

        #region Properties
        public int CassetteID
        {
            get { return _CID; }
        }
        /// <summary>
        /// The time when the cassette's state changes.
        /// </summary>
        public double Time { get { return _Time; } }
        /// <summary>
        /// Changed State of a Cassette
        /// </summary>
        public CassetteState State { get { return _State; } }
        /// <summary>
        /// Equipment ID
        /// </summary>
        public string Equipment { get { return _Equipment; } }
        public string ProcessingStep
        {
            get { return _P; }
        }
        public string NextEquipment
        {
            get { return _A; }
        }

        public string BeforeEquipment
        {
            get { return _B; }
        }
        public string CurrentEquipment
        {
            get { return _C; }
        }
        public string DestinationEquipment
        {
            get { return _D; }
        }
        public string ReleaseBatchID
        {
            get { return _RBID; }
        }
        public string ProductID
        {
            get { return _J; }
        }
        public string Route
        {
            get { return _R; }
        }
        #endregion

        #region Constructors
        public CassetteLog(double time, Cassette cst, CassetteState state,string eqpid)
        {
            _Time = time;
            _RBID = cst.RBID;
            _J = cst.J;
            _CID = cst.ID;
            _State = state;
            _Equipment = eqpid;
            _P = cst.P;
            _D = cst.D;

            _A = cst.A;
            _B = cst.B;
            _C = cst.C;
            if (cst.Route != null)
                _R = cst.Route.ToString();
        }
        #endregion

        #region Methods

        #endregion
        public int CompareTo(CassetteLog other)
        {
            return this.Time.CompareTo(other.Time);
        }
    }
}
