﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.OuputDataCollection
{
    public enum CassetteState
    {
        /// <summary>
        /// Released Into the Fab
        /// </summary>
        FabIn, 
        /// <summary>
        /// Loaded into Equipment (glass processing)
        /// </summary>
        Loaded, 
        /// <summary>
        /// Unloaded from the Equipment (CD)
        /// </summary>
        Unloaded, 
        /// <summary>
        /// Arrived into In-Port of the Equipment
        /// </summary>
        Arrived, 
        /// <summary>
        /// Departed from the Fab
        /// </summary>
        FabOut, 
        /// <summary>
        /// Started for Conveying
        /// </summary>
        ConveyStarted, 
        /// <summary>
        /// Ended for Conveying
        /// </summary>
        ConveyEnded, 
        /// <summary>
        /// Arrived on the Stocker In-Port
        /// </summary>
        ArrivedOnSI, 
        /// <summary>
        /// Arrived on the Stocker Buffer
        /// </summary>
        ArrivedOnSB,
        /// <summary>
        /// Arrived on the Stocker Out-port
        /// </summary>
        ArrivedOnSO,
        /// <summary>
        /// Started for Delivery by a stocker crane
        /// </summary>
        DeliverStarted,
        /// <summary>
        /// Ended for Delivery by a stocker crane
        /// </summary>
        DeliverEnded
    };
}
