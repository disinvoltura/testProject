﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.OuputDataCollection
{
    public class CassetteHistory: IDisposable
    {
        #region Member Variables
        private int _CID;
        private string _J;
        private CassetteLog _Current;
        private List<CassetteLog> _Logs;
        private bool _IsFabOut;

        #endregion

        #region Properties
        public int CassetteID
        {
            get { return _CID; }
        }

        public string ProductID
        {
            get { return _J; }
        }
        public CassetteLog Current
        {
            get { return _Current; }
        }

        public List<CassetteLog> Logs
        {
            get { return _Logs; }
        }

        public bool IsFabOut { get { return _IsFabOut; } }

        #endregion

        #region Constructors
        /// <summary>
        /// Maanges the history of a cassette
        /// </summary>
        /// <param name="cid">Cassette ID</param>
        /// <param name="j">Product ID</param>
        public CassetteHistory(int cid)
        {
            _CID = cid;
            _IsFabOut = false;
            _Logs = new List<CassetteLog>();
        }

        #endregion

        #region Methods
        public void Clear()
        {
            _Logs.Clear();
        }

        public void Add(CassetteLog log)
        {
            if (_Logs.Count == 0)
                _J = log.ProductID;

            _Logs.Add(log);
            _Current = log;

            if (log.State == CassetteState.FabOut)
                _IsFabOut = true;
        }


        public void Dispose()
        {
            Dispose(true);
        }

        private bool IsDisposed;
        protected virtual void Dispose(bool isDisposing)
        {
            if (IsDisposed) return;
            if (isDisposing)
            {
                // Dispose all Managed Resources
                this.Clear();
            }
            IsDisposed = true;
            GC.SuppressFinalize(this);
        } 
        #endregion

        
    }
}
