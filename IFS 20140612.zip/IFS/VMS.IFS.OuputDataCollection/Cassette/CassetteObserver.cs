﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.Models;

namespace VMS.IFS.OuputDataCollection
{
    /// <summary>
    /// Observe the processing histroy of cassettes
    /// </summary>
    public class CassetteObserver : FactoryEventObserver
    {
        #region Member Variables
        private Dictionary<int, CassetteHistory> _Data;

        //Key: ProductID.StepID, Value: TAT
        private Dictionary<string, SampleStatistics> _ProdStepTATData;
        private Dictionary<int, double> _LastCDTime;

        //Key: ProductID.StepID, Value: Count
        private Dictionary<string, TimeBucketTallyStatistics> _ProdStepOutData;

        private Dictionary<string, TimeBucketDependentStatistics> _TBProdStepWipData;

        //WIp....
        private Dictionary<string, int> _ProdStepWipData;

        #region Member Variables for Product TAT
        //Key: cassette id, value: pair of fabin and fabout time
        private Dictionary<int, double[]> _ProdTATData;
        //Key: product id, value: sample stat for a product
        private Dictionary<string, SampleStatistics> _ProdTATStats;

        //product 별 shift 별 average TAT - 3/20 김현식
        private Dictionary<string, AverageInTimeBucketStatistics> _ProdTBTATStats;

        #endregion

        //Time Units per a shift (in hours)
        private int _TimeBucket;
        #endregion

        #region Properties
        /// <summary>
        /// List of Cassette IDs
        /// </summary>
        public List<int> Cassettes
        {
            get { return _Data.Keys.ToList<int>(); }
        }

        public Dictionary<string, TimeBucketTallyStatistics> StepOut
        {
            get { return _ProdStepOutData; }
        }

        public Dictionary<string, SampleStatistics> StepTAT
        {
            get { return _ProdStepTATData; }
        }

        public Dictionary<string, TimeBucketDependentStatistics> StepWIP
        {
            get { return _TBProdStepWipData; }
        }

        //product 별 shift 별 average TAT - 3/20 김현식
        public Dictionary<string, AverageInTimeBucketStatistics> TBTAT
        {
            get { return _ProdTBTATStats; }
        }

        /// <summary>
        /// Product/Step TAT
        /// </summary>
        /// <param name="productid"></param>
        /// <param name="stepid"></param>
        /// <returns></returns>
        public SampleStatistics this[string productid, string stepid]
        {
            get
            {
                SampleStatistics rslt = null;
                string key = string.Format("{0}.{1}", productid, stepid);
                if (_ProdStepTATData.ContainsKey(key))
                    rslt = _ProdStepTATData[key];

                return rslt;
            }
        }

        /// <summary>
        /// Product TAT
        /// </summary>
        /// <param name="productid"></param>
        /// <returns></returns>
        public SampleStatistics this[string productid]
        {
            get
            {
                SampleStatistics rslt = null;
                if (_ProdTATStats.ContainsKey(productid))
                    rslt = _ProdTATStats[productid];
                return rslt;
            }
        }

        public CassetteHistory this[int cid]
        {
            get
            {
                CassetteHistory rslt = null;
                if (_Data.ContainsKey(cid))
                    rslt = _Data[cid];

                return rslt;
            }
        }
        #endregion

        #region Constructors
        public CassetteObserver(Factory factory, Dictionary<string, object> runOptions)
            : base("CassetteObserver", factory)
        {
            _TimeBucket = (int)runOptions[SimulationArguments.UnitTime]; 

            _Data = new Dictionary<int, CassetteHistory>();
            _ProdStepTATData = new Dictionary<string, SampleStatistics>();
            _LastCDTime = new Dictionary<int, double>();
            _ProdStepOutData = new Dictionary<string, TimeBucketTallyStatistics>();
            _ProdStepWipData = new Dictionary<string, int>();
            _TBProdStepWipData =
                new Dictionary<string, TimeBucketDependentStatistics>();

            _ProdTATData = new Dictionary<int, double[]>();
            _ProdTATStats = new Dictionary<string, SampleStatistics>();
            
            //product 별 shift 별 average TAT - 3/20 김현식
            _ProdTBTATStats = new Dictionary<string, AverageInTimeBucketStatistics>();
            _ProdTBTATStats.Add("Total", new AverageInTimeBucketStatistics("Total", _TimeBucket));

            _DeliverStartEventList = new List<string>() { "PV2X", "PC2X", "SI2X", "PO2X", "PI2X", "PU2X" };
        }

        private List<string> _DeliverStartEventList;
        #endregion

        #region Methods
        public override void Clear()
        {
            string[] productStepID = _ProdStepTATData.Keys.ToArray<string>();
            for (int i = productStepID.Length - 1; i >= 0; i--)
            {
                _ProdStepTATData[productStepID[i]].Dispose();
                _ProdStepTATData.Remove(productStepID[i]);
            }

            productStepID = _ProdStepOutData.Keys.ToArray<string>();
            for (int i = productStepID.Length - 1; i >= 0; i--)
            {
                _ProdStepOutData[productStepID[i]].Dispose();
                _ProdStepOutData.Remove(productStepID[i]);
            }

            productStepID = _TBProdStepWipData.Keys.ToArray<string>();
            for (int i = productStepID.Length - 1; i >= 0; i--)
            {
                _TBProdStepWipData[productStepID[i]].Dispose();
                _TBProdStepWipData.Remove(productStepID[i]);
            }

            productStepID = _ProdStepWipData.Keys.ToArray<string>();
            for (int i = productStepID.Length - 1; i >= 0; i--)
            {
                //_ProdStepWipData[productStepID[i]].Dispose();
                _ProdStepWipData.Remove(productStepID[i]);
            }

            string[] products = _ProdTATStats.Keys.ToArray<string>();
            for (int i = products.Length - 1; i >= 0; i--)
            {
                _ProdTATStats[products[i]].Dispose();
                _ProdTATStats.Remove(products[i]);
                
                //product 별 shift 별 average TAT - 3/20 김현식
                _ProdTBTATStats[products[i]].Dispose();
                _ProdTBTATStats.Remove(products[i]);
            }

            int[] cassettes = _Data.Keys.ToArray<int>();
            for (int i = cassettes.Length - 1; i >= 0; i--)
            {
                _Data[cassettes[i]].Dispose();
                _Data.Remove(cassettes[i]);
            }

            cassettes = _ProdTATData.Keys.ToArray<int>();
            for (int i = cassettes.Length - 1; i >= 0; i--)
            {
                //_ProdTATData[cassettes[i]].cle.d.Dispose();
                _ProdTATData.Remove(cassettes[i]);
            }


            //foreach (int key in _Data.Keys)
            //    _Data[key].Clear();
            //_Data.Clear();

            //foreach (string key in _ProdStepTATData.Keys)
            //    _ProdStepTATData[key].Clear();
            //_ProdStepTATData.Clear();

            //foreach (string key in _ProdStepOutData.Keys)
            //    _ProdStepOutData[key].Clear();
            //_ProdStepOutData.Clear();

            //foreach (string key in _TBProdStepWipData.Keys)
            //    _TBProdStepWipData[key].Clear();
            //_TBProdStepWipData.Clear();

            //_ProdStepWipData.Clear();
            //_ProdTATData.Clear();
            //_ProdTATStats.Clear();

        }

        //public override void Update(ObservedEvent e)
        public override void Update(EventObservedEvent evt)
        {
            //EventObservedEvent evt = (EventObservedEvent)e;

            CassetteLog log = null;
            int cid = 0;

            if (evt.Event is FactoryLocalEvent)
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                
                if (evt.Event.Name.Equals("CD"))
                {
                    //Log Unloaded Cassette
                    cid = fle.Cassette.ID;
                    log = new CassetteLog(fle.Time, fle.Cassette, CassetteState.Unloaded, fle.EQPID);

                    string key = string.Format("{0}.{1}", _Data[cid].Current.ProductID, _Data[cid].Current.ProcessingStep);

                    //ProductStep TAT
                    //double stepTAT = e.Time - _Data[cid].Current.Time;
                    double stepTAT = evt.Time - _LastCDTime[cid];
                    addProdStepTAT(key, evt.Time, stepTAT);
                    _LastCDTime[cid] = evt.Time;

                    //ProductStep Output
                    addProdStepOut(key, evt.Time);

                    //ProductStep WIP
                    deQueue(key);
                    addProdStepWip(key, evt.Time, _ProdStepWipData[key]);

                    string nextKey = string.Format("{0}.{1}", fle.Cassette.J, fle.Cassette.P);
                    enQueue(nextKey);
                    addProdStepWip(nextKey, evt.Time, _ProdStepWipData[nextKey]);

                    addCassetteLog(cid, log);
                }
                else if (evt.Event.Name.StartsWith("X2PU") || evt.Event.Name.StartsWith("X2PC") || evt.Event.Name.StartsWith("X2PV") || evt.Event.Name.StartsWith("X2PI"))
                {
                    //Arrive Cassette to the queue of next equipment
                    cid = fle.Cassette.ID;
                    log = new CassetteLog(fle.Time, fle.Cassette, CassetteState.Arrived, fle.EQPID);
                    addCassetteLog(cid, log);

                    //ProductStep WIP
                    if (Factory.MasterData.BOP.GetFirstStepID(fle.Cassette.J) == fle.Cassette.P)
                    {
                        string key = string.Format("{0}.{1}", fle.Cassette.J, fle.Cassette.P);
                        //string key = string.Format("{0}.{1}", _Data[cid].Current.ProductID, _Data[cid].Current.ProcessingStep);
                        enQueue(key);
                        addProdStepWip(key, evt.Time, _ProdStepWipData[key]);
                    }
                }
                else if (evt.EventObject.Name == "FabIn" && evt.Event.Name == "Move")
                {
                    cid = fle.Cassette.ID;
                    log = new CassetteLog(evt.Time, fle.Cassette, CassetteState.FabIn, "FabIn");
                    addCassetteLog(cid, log);

                    _LastCDTime.Add(cid, evt.Time);

                    //Product TAT
                    Cassette cst = (Cassette)fle.Cassette;
                    collectProductTATonFabIn(evt.Time, cst);
                }                
                else if (evt.EventObject.Name == "FabOut" && evt.Event.Name == "CFO")
                {
                    Cassette cst = (Cassette)fle[0];
                    log = new CassetteLog(evt.Time, cst, CassetteState.FabOut, "FabOut");
                    addCassetteLog(cst.ID, log);

                    //Product TAT
                    collectProductTATonFabOut(evt.Time, cst);

                    //product 별 shift 별 average TAT - 3/20 김현식
                    addProdTBTAT(cst.J, evt.Time, _ProdTATData[cst.ID][1] - _ProdTATData[cst.ID][0]);
                    //System.Diagnostics.Debug.WriteLine(e.Time + "\t" + cst.ID + "\t" + cst.J + "\t" + _ProdTATData[cst.ID][0] + "\t" + _ProdTATData[cst.ID][1]);
                }
                else if (evt.EventObject.Name == "Conveyor" && evt.Event.Name == "SOC")
                {
                    cid = fle.Cassette.ID;
                    log = new CassetteLog(evt.Time, fle.Cassette, CassetteState.ConveyStarted, fle.EQPID);
                    addCassetteLog(cid, log);
                }
                else if (evt.EventObject.Name == "Conveyor" && evt.Event.Name == "EOC")
                {
                    cid = fle.Cassette.ID;
                    log = new CassetteLog(evt.Time, fle.Cassette, CassetteState.ConveyEnded, fle.EQPID);
                    addCassetteLog(cid, log);
                }
                else if (evt.EventObject.Name == "Conveyor" && evt.Event.Name == "X2SO")
                {
                    cid = fle.Cassette.ID;
                    log = new CassetteLog(evt.Time, fle.Cassette, CassetteState.ArrivedOnSO, fle.EQPID);
                    addCassetteLog(cid, log);
                }
                else if (evt.EventObject.Name == "InlineStocker" && evt.Event.Name == "C2SI")
                {
                    string stkid = (string)fle[0];
                    string convid = (string)fle[1];
                    Cassette cst = Factory.Stocker.SI.GetCassette(stkid, convid);

                    log = new CassetteLog(evt.Time, cst, CassetteState.ArrivedOnSI, stkid + "." + convid);
                    addCassetteLog(cst.ID, log);
                }
                else if (evt.EventObject.Name == "InlineStocker" && evt.Event.Name == "B2X")
                {
                    string stkid = (string)fle[0];
                    Cassette cst = (Cassette)fle[1];

                    log = new CassetteLog(evt.Time, cst, CassetteState.DeliverStarted, stkid);
                    addCassetteLog(cst.ID, log);
                }
                else if (evt.EventObject.Name == "InlineStocker" && _DeliverStartEventList.Contains( evt.Event.Name))
                {
                    string stkid = (string)fle[0];
                    string eqpid = (string)fle[1];
                    Cassette cst = (Cassette)fle[2];

                    log = new CassetteLog(evt.Time, cst, CassetteState.DeliverStarted, stkid + "." + eqpid);
                    addCassetteLog(cst.ID, log);
                }
                else if (evt.EventObject.Name == "InlineStocker" && evt.Event.Name == "CU")
                {
                    string stkid = (string)fle[0];
                    Cassette cst = (Cassette)fle[1];
                    if (cst.PP == PickupPointType.E)
                        return;
                    log = new CassetteLog(evt.Time, cst, CassetteState.DeliverEnded, stkid);
                    addCassetteLog(cst.ID, log);
                }
                else if (evt.EventObject.Name == "InlineStocker" && evt.Event.Name == "X2B")
                {
                    string stkid = (string)fle[0];
                    Cassette cst = (Cassette)fle[1];

                    log = new CassetteLog(evt.Time, cst, CassetteState.ArrivedOnSB, stkid);
                    addCassetteLog(cst.ID, log);
                }
            }
        }

        private void collectProductTATonFabIn(double time, Cassette cst)
        {
            double[] times = new double[] { time, 0 };
            _ProdTATData.Add(cst.ID, times);
        }

        private void collectProductTATonFabOut(double time, Cassette cst)
        {
            if (_Data.ContainsKey(cst.ID))
            {
                double[] times = _ProdTATData[cst.ID];
                times[1] = time;

                if (_ProdTATStats.ContainsKey(cst.J))
                {
                    SampleStatistics stat = _ProdTATStats[cst.J];
                    stat.Add(time, times[1] - times[0]); //seconds
                    _ProdTATStats[cst.J] = stat;
                }
                else
                {
                    SampleStatistics stat = new SampleStatistics("Product TAT: " + cst.J);
                    stat.Add(time, times[1] - times[0]); //seconds
                    _ProdTATStats.Add(cst.J, stat);
                }
            }
        }

        public void enQueue(string key)
        {
            if (_ProdStepWipData.ContainsKey(key))
            {
                _ProdStepWipData[key] = _ProdStepWipData[key] + 1;
            }
            else
            {
                _ProdStepWipData.Add(key, 1);
            }
        }

        private void deQueue(string key)
        {
            if (_ProdStepWipData.ContainsKey(key))
            {
                _ProdStepWipData[key] = _ProdStepWipData[key] - 1;
            }
        }

        private void addProdStepOut(string key, double time)
        {
            if (_ProdStepOutData.ContainsKey(key))
            {
                TimeBucketTallyStatistics stat = _ProdStepOutData[key];
                stat.Add(time);
                _ProdStepOutData[key] = stat;
            }
            else
            {
                TimeBucketTallyStatistics stat = new TimeBucketTallyStatistics(key+".Tally", _TimeBucket);
                stat.Add(time);
                _ProdStepOutData.Add(key, stat);
            }
        }

        private void addProdStepWip(string key, double time, int val)
        {
            if (_TBProdStepWipData.ContainsKey(key))
            {
                TimeBucketDependentStatistics stat = _TBProdStepWipData[key];
                stat.Add(time, val);
                
                _TBProdStepWipData[key] = stat;
            }
            else
            {
                TimeBucketDependentStatistics stat = 
                    new TimeBucketDependentStatistics(key + ".WIP", _TimeBucket);
                stat.Add(time, val);
                _TBProdStepWipData.Add(key, stat);
            }
        }

        //product 별 shift 별 average TAT - 3/20 김현식
        private void addProdTBTAT(string key, double time, double val)
        {
            if (_ProdTBTATStats.ContainsKey(key))
            {
                AverageInTimeBucketStatistics stat = _ProdTBTATStats[key];
                stat.Add(time, val);

                _ProdTBTATStats[key] = stat;
            }
            else
            {
                AverageInTimeBucketStatistics stat = new AverageInTimeBucketStatistics(key, _TimeBucket);
                stat.Add(time, val);

                _ProdTBTATStats.Add(key, stat);
            }

            AverageInTimeBucketStatistics statTotal = _ProdTBTATStats["Total"];
            statTotal.Add(time, val);

            _ProdTBTATStats["Total"] = statTotal;                       
        }

        private void addProdStepTAT(string key, double time, double stepTAT)
        {
            if (_ProdStepTATData.ContainsKey(key))
            {
                SampleStatistics stat = _ProdStepTATData[key];
                stat.Add(time, stepTAT);
                _ProdStepTATData[key] = stat;
            }
            else
            {
                SampleStatistics stat = new SampleStatistics("ProductStepTAT");
                stat.Add(time, stepTAT);
                _ProdStepTATData.Add(key, stat);
            }
        }

        public void addCassetteLog(int cid, CassetteLog log)
        {
            if (_Data.ContainsKey(cid))
            {
                CassetteHistory history = _Data[cid];
                history.Add(log);
                _Data[cid] = history;
            }
            else
            {
                CassetteHistory history = new CassetteHistory(cid);
                history.Add(log);
                _Data.Add(cid, history);
            }
        }

        public override void Finalize(double eosTime)
        {
            foreach (string key in _ProdStepTATData.Keys)
            {
                SampleStatistics stat = _ProdStepTATData[key];
                stat.Finalize(eosTime);
            }

            foreach (string productid in _ProdTATStats.Keys)
            {
                SampleStatistics stat = _ProdTATStats[productid];
                stat.Finalize(eosTime);
            }
        }

        public TimeBucketTallyStatistics GetStepOut(string productid, string stepid)
        {
            TimeBucketTallyStatistics rslt = null;
            string key = string.Format("{0}.{1}", productid, stepid);
            if (_ProdStepOutData.ContainsKey(key))
                rslt = _ProdStepOutData[key];

            return rslt;
        }

        public TimeBucketDependentStatistics GetStepWIP(string productid, string stepid)
        {
            TimeBucketDependentStatistics rslt = null;
            string key = string.Format("{0}.{1}", productid, stepid);
            if (_TBProdStepWipData.ContainsKey(key))
                rslt = _TBProdStepWipData[key];

            return rslt;
        }

        public SampleStatistics GetStepTAT(string productid, string stepid)
        {
            SampleStatistics rslt = null;
            string key = string.Format("{0}.{1}", productid, stepid);
            if (_ProdStepTATData.ContainsKey(key))
                rslt = _ProdStepTATData[key];

            return rslt;
        }

        public override void Dispose()
        {
            Dispose(true);
        }

        private bool IsDisposed;
        protected virtual void Dispose(bool isDisposing)
        {
            if (IsDisposed) return;
            if (isDisposing)
            {
                // Dispose all Managed Resources
                this.Clear();
            }
            IsDisposed = true;
            GC.SuppressFinalize(this);
        } 

        #endregion
    }
}
