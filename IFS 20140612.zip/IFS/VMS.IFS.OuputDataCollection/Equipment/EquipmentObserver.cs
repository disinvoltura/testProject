﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.Models;

namespace VMS.IFS.OuputDataCollection
{
    /// <summary>
    /// Observer the processing history of equipments
    /// </summary>
    public class EquipmentObserver : FactoryEventObserver
    {
        #region Member Variables
        //Key: EQP ID
        private Dictionary<string, EquipmentHistory> _Data;
        //Key: EQP ID
        private Dictionary<string, TimeBucketTallyStatistics> _EQPOutData;

        //Time Units per a shift (in hours)
        private int _TimeBucket;
        #endregion

        #region Properties
        public IEnumerable<string> Equipments
        {
            get { return _Data.Keys; }
        }

        public EquipmentHistory this[string eqpid]
        {
            get
            {
                EquipmentHistory rslt = null;
                if (_Data.ContainsKey(eqpid))
                    rslt = _Data[eqpid];

                return rslt;
            }
        }
        #endregion

        #region Constructors
        public EquipmentObserver(Factory factory, Dictionary<string, object> runOptions)
            : base("Equipment Observer", factory)
        {
            _TimeBucket = (int)runOptions[SimulationArguments.UnitTime]; 

            _Data = new Dictionary<string, EquipmentHistory>();
            _EQPOutData = new Dictionary<string, TimeBucketTallyStatistics>();
        }
        #endregion

        #region Methods
        public override void Clear()
        {
            string[] eqps = _Data.Keys.ToArray<string>();
            for (int i = eqps.Length - 1; i > 0; i--)
            {
                _Data[eqps[i]].Dispose();
                _Data.Remove(eqps[i]);
            }
            //foreach (string key in _Data.Keys)
            //    _Data[key].Clear();
            //_Data.Clear();

            eqps = _EQPOutData.Keys.ToArray<string>();
            for (int i = eqps.Length - 1; i > 0; i--)
            {
                _EQPOutData[eqps[i]].Dispose();
                _EQPOutData.Remove(eqps[i]);
            }
            //foreach (string key in _EQPOutData.Keys)
            //    _EQPOutData[key].Clear();
            //_EQPOutData.Clear();

        }

        //public override void Update(ObservedEvent e)
        public override void Update(EventObservedEvent evt)
        {
            //EventObservedEvent evt = (EventObservedEvent)e;

            EquipmentLog log = null;
            string eqpid = string.Empty;
            if (evt.EventObject.Name == "UniInlineCell" || 
                evt.EventObject.Name == "BiInlineCell" ||
                evt.EventObject.Name == "Oven")
            {
                if (evt.Event.Name.Equals("CD"))
                {
                    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                    eqpid = fle.EQPID;

                    int ipc = 0;
                    if (evt.EventObject.Name == "UniInlineCell")
                        ipc = Factory.UniInlineCell.IPC[eqpid].Count;
                    else if (evt.EventObject.Name == "BiInlineCell")
                        ipc = Factory.BiInlineCell.IPC[eqpid].Count;
                    else
                        ipc = Factory.Oven.IPC[eqpid].Count;

                    if (ipc == 0)
                        log = new EquipmentLog(fle.Time, EquipmentState.Idle, fle.Cassette.ID);

                    AddTimebucketTally(evt.Time, eqpid);
                }
                else if (evt.Event.Name.Equals("FGL"))
                {
                    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                    eqpid = fle.EQPID;
                    log = new EquipmentLog(fle.Time, EquipmentState.Busy, fle.Cassette.ID);
                }
                else if (evt.Event.Name.Equals("SS"))
                {
                    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                    eqpid = fle.EQPID;
                    log = new EquipmentLog(fle.Time, EquipmentState.Setup, fle.Cassette.ID);
                }
            }
            else if (evt.EventObject.Name == "Chamber")
            {
                if (evt.Event.Name.Equals("CD"))
                {
                    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                    eqpid = fle.EQPID;

                    int ipc = 0;
                    ipc = Factory.Chamber.IPC[eqpid].Count;
                    
                    if (ipc == 0)
                        log = new EquipmentLog(fle.Time, EquipmentState.Idle, fle.Cassette.ID);

                    AddTimebucketTally(evt.Time, eqpid);
                }
                else if (evt.Event.Name.Equals("GP"))
                {
                    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                    eqpid = fle.EQPID;
                    log = new EquipmentLog(fle.Time, EquipmentState.Busy, fle.Glass.CID);
                }
                else if (evt.Event.Name.Equals("SS"))
                {
                    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                    eqpid = fle.EQPID;
                    log = new EquipmentLog(fle.Time, EquipmentState.Setup, fle.Glass.CID);
                }
            }
            else
            {
                System.Diagnostics.Trace.WriteLine("error.");

            }

            if (string.IsNullOrEmpty(eqpid))
                return;

            if (log != null)
                AddEquipmentLog(eqpid, log);
        }

        private void AddEquipmentLog(string eqpid, EquipmentLog log)
        {
            if (_Data.ContainsKey(eqpid))
            {
                EquipmentHistory history = _Data[eqpid];
                history.Add(log);
                _Data[eqpid] = history;
            }
            else
            {
                EquipmentHistory history = new EquipmentHistory(eqpid);
                history.Add(log);
                _Data.Add(eqpid, history);
            }
        }

        private void AddTimebucketTally(double time, string eqpid)
        {
            if (_EQPOutData.ContainsKey(eqpid))
            {
                TimeBucketTallyStatistics stat = _EQPOutData[eqpid];
                stat.Add(time);
                _EQPOutData[eqpid] = stat;
            }
            else
            {
                TimeBucketTallyStatistics stat = new TimeBucketTallyStatistics(eqpid + ".TimeBucketOutput", _TimeBucket);
                stat.Add(time);
                _EQPOutData.Add(eqpid, stat);
            }
        }

        public override void Finalize(double eosTime)
        {
            foreach (string eqpid in _Data.Keys)
            {
                EquipmentHistory history = _Data[eqpid];
                history.Finalize(eosTime);
            }
        }

        public TimeBucketTallyStatistics GetTimeBucketOutData(string eqpid)
        {
            TimeBucketTallyStatistics rslt = null;
            if (_EQPOutData.ContainsKey(eqpid))
            {
                rslt = _EQPOutData[eqpid];
            }

            return rslt;
        }

        public EquipmentHistory GetEQPHistoryData(string eqpid)
        {
            EquipmentHistory rslt = null;
            if (_Data.ContainsKey(eqpid))
            {
                rslt = _Data[eqpid];
            }

            return rslt;
        }

        public override void Dispose()
        {
            Dispose(true);
        }

        private bool IsDisposed;
        protected virtual void Dispose(bool isDisposing)
        {
            if (IsDisposed) return;
            if (isDisposing)
            {
                // Dispose all Managed Resources
                this.Clear();
            }
            IsDisposed = true;
            GC.SuppressFinalize(this);
        } 

        #endregion
    }
}
