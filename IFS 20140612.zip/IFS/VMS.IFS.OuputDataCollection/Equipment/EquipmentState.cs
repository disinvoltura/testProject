﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.OuputDataCollection
{
    public enum EquipmentState
    {
        Idle, Busy, Setup
    };
}
