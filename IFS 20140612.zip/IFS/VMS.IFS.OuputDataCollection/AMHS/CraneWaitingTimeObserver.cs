﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.Models;

namespace VMS.IFS.OuputDataCollection
{
    public class CraneWaitingTimeObserver : FactoryEventObserver
    {
        #region Member Variables

        //Raw Data
        //Key: Cassette ID, Value: Move event's Time (at eqp ports)
        private Dictionary<int, double> _MoveTimes;

        //Key: STKID.CONVID, Value: C2SI event's Time
        private Dictionary<string, double> _C2SITimes;

        //Key: stocker id, value: sample stat of waiting time
        private Dictionary<string, SampleStatistics> _Stats;

        //Time Units per a shift (in hours)
        private int _ShiftTime;
        #endregion

        #region Properties

        /// <summary>
        /// Waiting Time for Crane Delivery
        /// </summary>
        public Dictionary<string, SampleStatistics> WaitingTime
        {
            get { return _Stats; }
        }

        /// <summary>
        /// Stocker IDs
        /// </summary>
        public List<string> Keys
        {
            get { return _Stats.Keys.ToList<string>(); }
        }

        public SampleStatistics this[string key]
        {
            get { return _Stats[key]; }
        }

        #endregion

        #region Constructors
        public CraneWaitingTimeObserver(Factory factory, Dictionary<string, object> runOptions)
            : base("DeliveryWaitingTimeObserver", factory)
        {
            _ShiftTime = (int)runOptions[SimulationArguments.UnitTime];

            _MoveTimes = new Dictionary<int, double>();
            _C2SITimes = new Dictionary<string, double>();
            _Stats = new Dictionary<string, SampleStatistics>();
        }

        #endregion

        #region Methods
        public override void Clear()
        {
            _MoveTimes.Clear();
            _C2SITimes.Clear();

            foreach (string key in _Stats.Keys)
                _Stats[key].Clear();
            _Stats.Clear();

        }

        //public override void Update(ObservedEvent e)
        public override void Update(EventObservedEvent evt)
        {
            //EventObservedEvent evt = (EventObservedEvent)e;

            if (evt.Event.Name == "Move" || evt.Event.Name == "MEC")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                Cassette cst = (Cassette)fle[2];

                if (_MoveTimes.ContainsKey(cst.ID))
                {
                    _MoveTimes[cst.ID] = fle.Time;
                }
                else
                {
                    _MoveTimes.Add(cst.ID, fle.Time);
                }
            }
            else if (evt.Event.Name == "PU2X" || evt.Event.Name == "PV2X" || evt.Event.Name == "PC2X" || evt.Event.Name == "PO2X" || evt.Event.Name == "PI2X")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                Cassette cst = (Cassette)fle[2];
                string stkid = (string)fle[0];
                if (_MoveTimes.ContainsKey(cst.ID))
                {
                    string key = stkid;
                    double val = fle.Time - _MoveTimes[cst.ID];
                    
                    if (_Stats.ContainsKey(key))
                    {
                        _Stats[key].Add(fle.Time, val);
                    }
                    else
                    {
                        SampleStatistics stat = new SampleStatistics("CraneWaitingTime");
                        stat.Add(fle.Time, val);
                        _Stats.Add(key, stat);
                    }

                }
            }
            else if (evt.Event.Name == "C2SI")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                string stkid = (string)fle[0];
                string convid = (string)fle[1];

                string key = string.Format("{0}.{1}", stkid, convid);

                if (_C2SITimes.ContainsKey(key))
                {
                    _C2SITimes[key] = fle.Time;
                }
                else
                {
                    _C2SITimes.Add(key, fle.Time);
                }
            }
            else if (evt.Event.Name == "SI2X")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                string stkid = (string)fle[0];
                string convid = (string)fle[1];
                string key = string.Format("{0}.{1}", stkid, convid);
                if (_C2SITimes.ContainsKey(key))
                {
                    double val = fle.Time - _C2SITimes[key];

                    if (_Stats.ContainsKey(stkid))
                    {
                        _Stats[stkid].Add(fle.Time, val);
                    }
                    else
                    {
                        SampleStatistics stat = new SampleStatistics("CraneWaitingTime");
                        stat.Add(fle.Time, val);
                        _Stats.Add(stkid, stat);
                    }

                }
            }
            else if (evt.Event.Name == "CFO")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                Cassette cst = (Cassette)fle[0];

                _MoveTimes.Remove(cst.ID);
            }
        }

        public void Initialize()
        {
        }

        public override void Finalize(double eosTime)
        {
            foreach (string key in _Stats.Keys)
            {
                SampleStatistics stat = _Stats[key];
                stat.Finalize(eosTime);
            }
        }

        public override void Dispose()
        {
            Dispose(true);
        }

        private bool IsDisposed;
        protected virtual void Dispose(bool isDisposing)
        {
            if (IsDisposed) return;
            if (isDisposing)
            {
                // Dispose all Managed Resources
                this.Clear();
            }
            IsDisposed = true;
            GC.SuppressFinalize(this);
        } 

        #endregion
    }
}
