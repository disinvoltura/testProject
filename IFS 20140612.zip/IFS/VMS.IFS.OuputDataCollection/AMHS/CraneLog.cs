﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.OuputDataCollection
{
    public enum CraneState
    {
        Idle, Retrieval, Delivery
    };

    public class CraneLog : IComparable<CraneLog>
    {
        //CraneLog: Time, {Retrieval, Deliver}, From, To, Cassette
        #region Member Variables
        private double _Time;
        private CraneState _State;
        private string _From;
        private string _To;
        private string _CstInfo;
        private int _CID;

        #endregion

        #region Properties
        public double Time { get { return _Time; } }
        public CraneState State { get { return _State; } }
        public string From { get { return _From; } }
        public string To { get { return _To; } }
        public string Cassette { get { return _CstInfo; } }
        public int CassetteID { get { return _CID; } }
    
        #endregion

        #region Constructors
        public CraneLog(double time, CraneState state)
        {
            _Time = time;
            _State = state;
        }

        public CraneLog(double time, CraneState state, string from, string to)
        {
            _Time = time;
            _State = state;
            _From = from;
            _To = to;
        }

        public CraneLog(double time, CraneState state, string from, string to, Cassette cst)
        {
            _Time = time;
            _State = state;
            _From = from;
            _To = to;
            _CID = cst.ID;
            _CstInfo = cst.ToString();
        }

        public CraneLog(double time, CraneState state, int wip, int si, int x, int rx, int dr)
        {
            _Time = time;
            _State = state;
            _CstInfo = "(WIP, SI, X, RX, DR) = (" + wip + "," + si + "," + x + "," + rx + "," + dr + ")";
        }
        #endregion

        #region Methods
        public int CompareTo(CraneLog other)
        {
            return this.Time.CompareTo(other.Time);
        }

        #endregion
    }
}
