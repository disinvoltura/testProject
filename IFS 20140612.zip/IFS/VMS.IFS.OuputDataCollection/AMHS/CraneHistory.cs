﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.OuputDataCollection
{
    public class CraneHistory: IDisposable
    {
        #region Member Variables
        private string _STKID;
        private CraneLog _Current;
        private List<CraneLog> _Logs;
        private double _IdleTimes;
        private double _RetrievalTimes;
        private double _DeliveryTimes;
        private double _EOSTime;

        private int _RetrievalNo;
        private int _DeliveryNo;

        #endregion

        #region Properties
        public string StockerID
        {
            get { return _STKID; }
        }

        public CraneLog Current
        {
            get { return _Current; }
        }

        public IEnumerable<CraneLog> Logs
        {
            get { return _Logs; }
        }

        public double Idle
        {
            get
            {
                return Math.Round(_IdleTimes / _EOSTime * 100, 2);
            }
        }

        public double Retrieval
        {
            get
            {
                return Math.Round(_RetrievalTimes / _EOSTime * 100, 2);
            }
        }

        public double Delivery
        {
            get
            {
                return Math.Round(_DeliveryTimes / _EOSTime * 100, 2);
            }
        }

        /// <summary>
        /// Number of retrieval made by a crane
        /// </summary>
        public int RetrievalCount
        {
            get { return _RetrievalNo; }
        }

        /// <summary>
        /// Number of delivery made by a crane
        /// </summary>
        public int DeliveryCount
        {
            get { return _DeliveryNo; }
        }

        #endregion

        #region Constructors
        /// <summary>
        /// Manages the history of a crane
        /// </summary>
        /// <param name="eqpid">Stocker ID</param>
        public CraneHistory(string stkid) //추후 Crane ID 반영
        {
            _STKID = stkid;
            _Logs = new List<CraneLog>();

            _IdleTimes = 0;
            _RetrievalTimes = 0;
            _DeliveryTimes = 0;
            _RetrievalNo = 0;
            _DeliveryNo = 0;
            _Current = new CraneLog(0, CraneState.Idle);
        }

        #endregion

        #region Methods
        public void Clear()
        {
            _Logs.Clear();
        }
        private CraneState _LastState = CraneState.Idle;
        private double _LastTime = 0;
        public void Add(CraneLog log)
        {
            if (_Current != null)
            {
                //Utilization
                if (_Current.State == CraneState.Idle)
                {
                    _IdleTimes += log.Time - _Current.Time;
                }
                else if (_Current.State == CraneState.Retrieval)
                {
                    _RetrievalTimes += log.Time - _Current.Time;
                    _RetrievalNo++;
                }
                else if (_Current.State == CraneState.Delivery)
                {
                    _DeliveryTimes += log.Time - _Current.Time;
                    _DeliveryNo++;
                }
            }

            _Logs.Add(log);
            _Current = log;
            _LastState = log.State;
            _LastTime = log.Time;
        }

        public void Add(double time, CraneState state)
        {
            CraneLog log = new CraneLog(time, state);
            this.Add(log);
        }

        public void Add(double time, CraneState state, string from, string to, Cassette cst)
        {
            CraneLog log = new CraneLog(time, state, from, to, cst);
            this.Add(log);
        }

        /// <summary>
        /// Compute the utilization of a crane with a given simulation time
        /// </summary>
        /// <param name="eosTime"></param>
        public void Finalize(double eosTime)
        {
            _EOSTime = eosTime;
            if (_Current == null)
                return;

            if (_Current.State == CraneState.Idle)
            {
                _IdleTimes += _EOSTime - _LastTime;
            }
            else if (_Current.State == CraneState.Retrieval)
            {
                _RetrievalTimes += _EOSTime - _LastTime;
            }
            else if (_Current.State == CraneState.Delivery)
            {
                _DeliveryTimes += _EOSTime - _LastTime;
            }
        }

        public  void Dispose()
        {
            Dispose(true);
        }

        private bool IsDisposed;
        protected virtual void Dispose(bool isDisposing)
        {
            if (IsDisposed) return;
            if (isDisposing)
            {
                // Dispose all Managed Resources
                this.Clear();
            }
            IsDisposed = true;
            GC.SuppressFinalize(this);
        } 

        #endregion
    }
}
