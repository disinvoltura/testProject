﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.Models;

namespace VMS.IFS.OuputDataCollection
{
    public class CassetteMovingObserver : FactoryEventObserver
    {
        #region Member Variables

        //Raw Data
        //한 Cassette 이 현재 Step 의 설비에서 다음 Step 의 설비에 투입될까지의 시간 집계
        //Key: Cassette ID, Value: CD event's Time
        private Dictionary<int, double> _CDTimes;
        
        /// <summary>
        /// Cassette 별 이전 Processing Step ID
        /// </summary>
        private Dictionary<int, string> _Steps;

        //Key: product id.FromStep.ToStep, value: sample stat of moving time
        private Dictionary<string, SampleStatistics> _Stats;

        //Time Units per a shift (in hours)
        private int _ShiftTime;
        #endregion

        #region Properties
        public Dictionary<string, SampleStatistics> MovingTime
        {
            get { return _Stats; }
        }

        public List<string> Keys
        {
            get { return _Stats.Keys.ToList<string>(); }
        }

        public SampleStatistics this[string key]
        {
            get { return _Stats[key]; }
        }

        #endregion

        #region Constructors
        public CassetteMovingObserver(Factory factory, Dictionary<string, object> runOptions)
            : base ("CassetteMovingObserver", factory)
        {
            _ShiftTime = (int)runOptions[SimulationArguments.UnitTime];

            _CDTimes = new Dictionary<int, double>();
            _Steps = new Dictionary<int, string>();
            _Stats = new Dictionary<string, SampleStatistics>();
        }

        #endregion

        #region Methods
        public override void Clear()
        {
            _CDTimes.Clear();
            _Steps.Clear();
            foreach (string key in _Stats.Keys)
                _Stats[key].Clear();
            _Stats.Clear();
        }

        //public override void Update(ObservedEvent e)
        public override void Update(EventObservedEvent evt)
        {
            //EventObservedEvent evt = (EventObservedEvent)e;

            //evt.EventObject.Name == "Uniinline"
            if (evt.Event.Name == "CD")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                Cassette cst = fle.Cassette;

                if (_CDTimes.ContainsKey(cst.ID))
                {
                    _CDTimes[cst.ID] = fle.Time;
                }
                else
                {
                    _CDTimes.Add(cst.ID, fle.Time);
                }
            }
            else if (evt.Event.Name == "X2PU" || evt.Event.Name == "X2PC" || evt.Event.Name == "X2PV" || evt.Event.Name == "X2PI")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                Cassette cst = fle.Cassette;

                if (_Steps.ContainsKey(cst.ID))
                {
                    string key = string.Format("{0}.{1}.{2}", cst.J, _Steps[cst.ID], cst.P);
                    double val = fle.Time - _CDTimes[cst.ID];
                    if (_Stats.ContainsKey(key))
                    {
                        _Stats[key].Add(fle.Time, val);
                    }
                    else
                    {
                        SampleStatistics stat = new SampleStatistics("MovingTime");
                        stat.Add(fle.Time, val);
                        _Stats.Add(key, stat);
                    }

                    _Steps[cst.ID] = cst.P;
                }
                else
                {
                    _Steps.Add(cst.ID, cst.P);
                }

            }
            else if (evt.Event.Name == "CFO")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                Cassette cst = (Cassette)fle[0];

                _CDTimes.Remove(cst.ID);
                _Steps.Remove(cst.ID);
            }
        }

        public void Initialize()
        {
        }

        public override void Finalize(double eosTime)
        {
            foreach (string key in _Stats.Keys)
            {
                SampleStatistics stat = _Stats[key];
                stat.Finalize(eosTime);
            }
        }

        public override void Dispose()
        {
            Dispose(true);
        }

        private bool IsDisposed;
        protected virtual void Dispose(bool isDisposing)
        {
            if (IsDisposed) return;
            if (isDisposing)
            {
                // Dispose all Managed Resources
                this.Clear();
            }
            IsDisposed = true;
            GC.SuppressFinalize(this);
        } 

        #endregion
    }
}
