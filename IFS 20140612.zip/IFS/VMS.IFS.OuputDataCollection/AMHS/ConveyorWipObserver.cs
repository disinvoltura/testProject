﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.Models;

namespace VMS.IFS.OuputDataCollection
{
    /// <summary>
    /// Conveyor WIP 
    /// </summary>
    public class ConveyorWipObserver : FactoryEventObserver
    {
        #region Member Variables
        private Dictionary<string, TimeDependentStatistics> _Stat;
        private Dictionary<string, TimeBucketDependentStatistics> _ShiftWIPData;
        private Dictionary<string, int> _WIP;

        //Time Units per a shift (in hours)
        private int _ShiftTime;
        #endregion

        #region Properties
        public Dictionary<string, TimeDependentStatistics> FabWIP
        {
            get { return _Stat; }
        }

        public Dictionary<string, TimeBucketDependentStatistics> ShiftWIP
        {
            get { return _ShiftWIPData; }
        }
        #endregion

        #region Constructors
        public ConveyorWipObserver(Factory factory, Dictionary<string, object> runOptions)
            : base("ConveyorWipObserver", factory)
        {
            _ShiftTime = (int)runOptions[SimulationArguments.UnitTime];

            _Stat = new Dictionary<string, TimeDependentStatistics>();
            _ShiftWIPData = new Dictionary<string, TimeBucketDependentStatistics>();

            _WIP = new Dictionary<string,int>();
        }

        #endregion

        #region Methods
        public override void Clear()
        {
            foreach (string key in _Stat.Keys)
                _Stat[key].Clear();
            _Stat.Clear();

            foreach (string key in _ShiftWIPData.Keys)
                _ShiftWIPData[key].Clear();
            _ShiftWIPData.Clear();

            _WIP.Clear();
        }

        //public override void Update(ObservedEvent e)
        public override void Update(EventObservedEvent evt)
        {
            //EventObservedEvent evt = (EventObservedEvent)e;

            if (evt.EventObject.Name == "Conveyor" &&
                   evt.Event.Name == "SOC")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                IncreaseWIP(evt.Time, fle.EQPID);
            }
            else if (evt.EventObject.Name == "InlineStocker" &&
                   evt.Event.Name == "C2SI")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                DecreaseWIP(evt.Time, (string)fle[1]);
            }
        }

        private void IncreaseWIP(double time, string c)
        {
            if (_WIP.ContainsKey(c))
            {
                _WIP[c] = _WIP[c] + 1;
                _Stat[c].Add(time, _WIP[c]);
                _ShiftWIPData[c].Add(time, _WIP[c]);
            }
            else
            {
                int wip = 0;
                _WIP.Add(c, wip);

                TimeDependentStatistics stat =
                    new TimeDependentStatistics("StockerWIPObserver_" + c);
                stat.Add(0, wip);
                _Stat.Add(c, stat);

                TimeBucketDependentStatistics shiftWIP =
                    new TimeBucketDependentStatistics("StockerWIPObserver_" + c, _ShiftTime);
                shiftWIP.Add(0, wip);
                _ShiftWIPData.Add(c, shiftWIP);

                wip = 1;
                _WIP[c] = wip;
                _Stat[c].Add(time, wip);
                _ShiftWIPData[c].Add(time, wip);
            }
        }

        private void DecreaseWIP(double time, string c)
        {
            if (!_WIP.ContainsKey(c))
                return;

            _WIP[c] = _WIP[c] - 1;
            _Stat[c].Add(time, _WIP[c]);
            _ShiftWIPData[c].Add(time, _WIP[c]);
        }

        public void Initialize()
        {
        }

        public override void Finalize(double eosTime)
        {
            foreach (string c in _Stat.Keys)
            {
                _Stat[c].Add(eosTime, _WIP[c]);
                _ShiftWIPData[c].Add(eosTime, _WIP[c]);
            }
        }

        public override void Dispose()
        {
            Dispose(true);
        }

        private bool IsDisposed;
        protected virtual void Dispose(bool isDisposing)
        {
            if (IsDisposed) return;
            if (isDisposing)
            {
                // Dispose all Managed Resources
                this.Clear();
            }
            IsDisposed = true;
            GC.SuppressFinalize(this);
        } 

        #endregion
    }
}
