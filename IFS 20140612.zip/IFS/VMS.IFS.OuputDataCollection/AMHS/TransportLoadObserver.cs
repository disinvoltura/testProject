﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.Models;

namespace VMS.IFS.OuputDataCollection
{
    public class TransportLoadObserver : FactoryEventObserver
    {
        #region Member Variables
        //모든 집계는 반송 완료 시점을 기준으로 함
        //Raw Data
        //Key: Stocker ID, Value: 반송유형별 횟수
        private Dictionary<string, TimeBucketTallyStatistics> _SI2Port;
        private Dictionary<string, TimeBucketTallyStatistics> _SI2Buf;
        private Dictionary<string, TimeBucketTallyStatistics> _SI2SO;
        private Dictionary<string, TimeBucketTallyStatistics> _Buf2Port;
        private Dictionary<string, TimeBucketTallyStatistics> _Buf2SO;
        private Dictionary<string, TimeBucketTallyStatistics> _Port2Buf;
        private Dictionary<string, TimeBucketTallyStatistics> _Port2SO;
        private Dictionary<string, TimeBucketTallyStatistics> _Port2Port;
        private Dictionary<string, TimeBucketTallyStatistics> _EmptyCst;

        //Key: Stocker ID, Value: 반송횟수 
        private Dictionary<string, TimeBucketTallyStatistics> _Transport;

        //Key: Stocker Id, Value: Stocker 의 마지막 실행된 Event Name
        private Dictionary<string, string> _LastStockerEvent;

        //Time Units per a shift (in hours)
        private int _ShiftTime;
        #endregion

        #region Properties

        /// <summary>
        /// Stocker 별 SI 에서 설비 Port로의 반송 횟수
        /// </summary>
        public Dictionary<string, TimeBucketTallyStatistics> SI2Port { get { return _SI2Port; } }
        /// <summary>
        /// Stocker 별 SI 에서 Buffer 로의 반송 횟수
        /// </summary>
        public Dictionary<string, TimeBucketTallyStatistics> SI2Buf { get { return _SI2Buf; } }
        /// <summary>
        /// Stocker 별 SI 에서 SO로의 반송 횟수
        /// </summary>
        public Dictionary<string, TimeBucketTallyStatistics> SI2SO { get { return _SI2SO; } }
        /// <summary>
        /// Stocker 별 Buffer 에서 설비 Port로의 반송 횟수
        /// </summary>
        public Dictionary<string, TimeBucketTallyStatistics> Buf2Port { get { return _Buf2Port; } }
        /// <summary>
        /// Stocker 별 Buffer 에서 SO로의 반송 횟수
        /// </summary>
        public Dictionary<string, TimeBucketTallyStatistics> Buf2SO { get { return _Buf2SO; } }
        /// <summary>
        /// Stocker 별 설비 Port 에서 Buffer 로의 반송 횟수
        /// </summary>
        public Dictionary<string, TimeBucketTallyStatistics> Port2Buf { get { return _Port2Buf; } }
        /// <summary>
        /// Stocker 별 설비 Port 에서 SO 로의 반송 횟수
        /// </summary>
        public Dictionary<string, TimeBucketTallyStatistics> Port2SO { get { return _Port2SO; } }
        /// <summary>
        /// Stocker 별 Empty Cassette 반송 횟수 (Supply to PO, Retract from PI)
        /// </summary>
        public Dictionary<string, TimeBucketTallyStatistics> EmptyCassette { get { return _EmptyCst; } }
        public Dictionary<string, TimeBucketTallyStatistics> Port2Port { get { return _Port2SO; } }
        /// <summary>
        /// Stocker 별 반송 횟수 
        /// </summary>
        public Dictionary<string, TimeBucketTallyStatistics> Transport { get { return _Transport; } }

        #endregion

        #region Constructors
        public TransportLoadObserver(Factory factory, Dictionary<string, object> runOptions)
            : base("TransportLoadObserver", factory)
        {
            _ShiftTime = (int)runOptions[SimulationArguments.UnitTime];

            _SI2Port = new Dictionary<string, TimeBucketTallyStatistics>();
            _SI2Buf = new Dictionary<string, TimeBucketTallyStatistics>();
            _SI2SO = new Dictionary<string, TimeBucketTallyStatistics>();
            _Buf2Port = new Dictionary<string, TimeBucketTallyStatistics>();
            _Buf2SO = new Dictionary<string, TimeBucketTallyStatistics>();
            _Port2Buf = new Dictionary<string, TimeBucketTallyStatistics>();
            _Port2SO = new Dictionary<string, TimeBucketTallyStatistics>();
            _Port2Port = new Dictionary<string, TimeBucketTallyStatistics>();
            _EmptyCst = new Dictionary<string, TimeBucketTallyStatistics>();
            _Transport = new Dictionary<string, TimeBucketTallyStatistics>();
            _LastStockerEvent = new Dictionary<string, string>();
        }

        #endregion

        #region Methods
        public override void Update(EventObservedEvent evt)
        //public override void Update(ObservedEvent e)
        {
            //EventObservedEvent evt = (EventObservedEvent)e;

            if (evt.Event.Name == "PV2Xr" || evt.Event.Name == "B2Xr" || 
                     evt.Event.Name == "PC2Xr" || evt.Event.Name == "SI2Xr" || evt.Event.Name == "E2POr" ||
                     evt.Event.Name == "PO2Xr" || evt.Event.Name == "PI2Xr" || evt.Event.Name == "PU2Xr") 
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                string stkid = (string)fle[0];                

                if (_LastStockerEvent.ContainsKey(stkid))
                {
                    _LastStockerEvent[stkid] = evt.Event.Name;
                }
                else
                {
                    _LastStockerEvent.Add(stkid, evt.Event.Name);
                }
            }
            else if (evt.Event.Name == "CU")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                string stkid = (string)fle[0];
                Cassette cst = (Cassette)fle[1];

                string lastEventName = _LastStockerEvent[stkid];

                if (lastEventName == "SI2Xr")
                {
                    //SI to Buffer
                    if (cst.DP == DropPointType.B)
                    {
                        if (_SI2Buf.ContainsKey(stkid))
                            _SI2Buf[stkid].Add(fle.Time);
                        else
                        {
                            TimeBucketTallyStatistics stat = new TimeBucketTallyStatistics("SI2Buf", _ShiftTime);
                            stat.Add(fle.Time);
                            _SI2Buf.Add(stkid, stat);
                        }
                    }
                    else if (cst.DP == DropPointType.PU || cst.DP == DropPointType.PC || cst.DP == DropPointType.PV || cst.DP == DropPointType.PI)
                    {
                        //SI to Port
                        if (_SI2Port.ContainsKey(stkid))
                            _SI2Port[stkid].Add(fle.Time);
                        else
                        {
                            TimeBucketTallyStatistics stat = new TimeBucketTallyStatistics("SI2Port", _ShiftTime);
                            stat.Add(fle.Time);
                            _SI2Port.Add(stkid, stat);
                        }
                    }
                    else if (cst.DP == DropPointType.SO)
                    {
                        //SI to SO
                        if (_SI2SO.ContainsKey(stkid))
                            _SI2SO[stkid].Add(fle.Time);
                        else
                        {
                            TimeBucketTallyStatistics stat = new TimeBucketTallyStatistics("SI2SO", _ShiftTime);
                            stat.Add(fle.Time);
                            _SI2SO.Add(stkid, stat);
                        }
                    }                 
                }else if (lastEventName == "B2Xr")
                {                    
                    if (cst.DP == DropPointType.PU || cst.DP == DropPointType.PC || cst.DP == DropPointType.PV || cst.DP == DropPointType.PI)
                    {
                        //Buffer to Port
                        if (_Buf2Port.ContainsKey(stkid))
                            _Buf2Port[stkid].Add(fle.Time);
                        else
                        {
                            TimeBucketTallyStatistics stat = new TimeBucketTallyStatistics("Buf2Port", _ShiftTime);
                            stat.Add(fle.Time);
                            _Buf2Port.Add(stkid, stat);
                        }
                    }
                    else if (cst.DP == DropPointType.SO)
                    {
                        //Buffer to SO
                        if (_Buf2SO.ContainsKey(stkid))
                            _Buf2SO[stkid].Add(fle.Time);
                        else
                        {
                            TimeBucketTallyStatistics stat = new TimeBucketTallyStatistics("Buf2SO", _ShiftTime);
                            stat.Add(fle.Time);
                            _Buf2SO.Add(stkid, stat);
                        }
                    }
                }
                else if (lastEventName == "PV2Xr" ||
                         lastEventName == "PC2Xr" ||
                         lastEventName == "PO2Xr" ||
                         lastEventName == "PU2Xr")
                {
                    //Port to Buffer
                    if (cst.DP == DropPointType.B)
                    {
                        if (_Port2Buf.ContainsKey(stkid))
                            _Port2Buf[stkid].Add(fle.Time);
                        else
                        {
                            TimeBucketTallyStatistics stat = new TimeBucketTallyStatistics("Port2Buf", _ShiftTime);
                            stat.Add(fle.Time);
                            _Port2Buf.Add(stkid, stat);
                        }
                    }
                    else if (cst.DP == DropPointType.SO)
                    { 
                        //Port to SO
                        if (_Port2SO.ContainsKey(stkid))
                            _Port2SO[stkid].Add(fle.Time);
                        else
                        {
                            TimeBucketTallyStatistics stat = new TimeBucketTallyStatistics("Port2SO", _ShiftTime);
                            stat.Add(fle.Time);
                            _Port2SO.Add(stkid, stat);
                        }
                    }
                    else if (cst.DP == DropPointType.PU ||
                             cst.DP == DropPointType.PC ||
                             cst.DP == DropPointType.PV ||
                             cst.DP == DropPointType.PI) 
                    {
                        //Port to Port
                        if (_Port2Port.ContainsKey(stkid))
                            _Port2Port[stkid].Add(fle.Time);
                        else
                        {
                            TimeBucketTallyStatistics stat = new TimeBucketTallyStatistics("Port2Port", _ShiftTime);
                            stat.Add(fle.Time);
                            _Port2Port.Add(stkid, stat);
                        }
                    }
                }
                else if (lastEventName == "PI2Xr" || lastEventName == "E2POr")
                {
                    //Empty Cassette (PI to Empty, Empty to PO)
                    if (_EmptyCst.ContainsKey(stkid))
                        _EmptyCst[stkid].Add(fle.Time);
                    else
                    {
                        TimeBucketTallyStatistics stat = new TimeBucketTallyStatistics("EmptyCassette", _ShiftTime);
                        stat.Add(fle.Time);
                        _EmptyCst.Add(stkid, stat);
                    }
                }

                if (_Transport.ContainsKey(stkid))
                {
                    _Transport[stkid].Add(fle.Time);
                }
                else
                {
                    TimeBucketTallyStatistics stat = new TimeBucketTallyStatistics("Transload", _ShiftTime);
                    stat.Add(fle.Time);
                    _Transport.Add(stkid, stat);
                }
            }
        }

        public void Initialize()
        {
        }

        public override void Finalize(double eosTime)
        {

        }

        public override void Clear()
        {
            foreach (string key in _SI2Port.Keys)
            {
                _SI2Port[key].Clear();
            }
            _SI2Port.Clear();

            foreach (string key in _SI2Buf.Keys)
            {
                _SI2Buf[key].Clear();
            }
            _SI2Buf.Clear();

            foreach (string key in _SI2SO.Keys)
            {
                _SI2SO[key].Clear();
            }
            _SI2SO.Clear();

            foreach (string key in _Buf2Port.Keys)
            {
                _Buf2Port[key].Clear();
            }
            _Buf2Port.Clear();

            foreach (string key in _Buf2SO.Keys)
            {
                _Buf2SO[key].Clear();
            }
            _Buf2SO.Clear();

            foreach (string key in _Port2Buf.Keys)
            {
                _Port2Buf[key].Clear();
            }
            _Port2Buf.Clear();

            foreach (string key in _Port2SO.Keys)
            {
                _Port2SO[key].Clear();
            }
            _Port2SO.Clear();
            
            foreach (string key in _Port2Port.Keys)
            {
                _Port2Port[key].Clear();
            }
            _Port2Port.Clear();

            foreach (string key in _EmptyCst.Keys)
            {
                _EmptyCst[key].Clear();
            }
            _EmptyCst.Clear();

            foreach (string key in _Transport.Keys)
            {
                _Transport[key].Clear();
            }
            _Transport.Clear();

            _LastStockerEvent.Clear();
        }

        public override void Dispose()
        {
            Dispose(true);
        }

        private bool IsDisposed;
        protected virtual void Dispose(bool isDisposing)
        {
            if (IsDisposed) return;
            if (isDisposing)
            {
                // Dispose all Managed Resources
                //_Observers.Clear();
                this.Clear();
            }
            IsDisposed = true;
            GC.SuppressFinalize(this);
        } 

        #endregion
    }
}
