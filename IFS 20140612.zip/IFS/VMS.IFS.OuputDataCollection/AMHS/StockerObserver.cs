﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.Models;

namespace VMS.IFS.OuputDataCollection
{
    /// <summary>
    /// Stocker Observer
    /// </summary>
    public class StockerObserver : FactoryEventObserver
    {
        //TODO
        //1. Crane Utilization
        //2. 반송 정보 (CraneLog: Time, {Retrieval, Deliver}, From, To, Cassette)

        #region Member Variables
        //Key: STKID
        private Dictionary<string, CraneHistory> _Data;

        private List<string> _RetrievalEvents;
        private List<string> _DeliveryEvents;

        //Time Units per a shift (in hours)
        private int _ShiftTime;
        #endregion

        #region Properties
        public CraneHistory this[string stkid]
        {
            get { return _Data[stkid];}
        }

        public IEnumerable<string> Stockers
        {
            get { return _Data.Keys; }
        }

        #endregion

        #region Constructors
        public StockerObserver(Factory factory, Dictionary<string, object> runOptions)
            : base ("StockerObserver", factory)
        {
            _ShiftTime = (int)runOptions[SimulationArguments.UnitTime];

            _Data = new Dictionary<string, CraneHistory>();

            _RetrievalEvents = new List<string>() { "PV2Xr", "PC2Xr", "SI2Xr", "PO2Xr", "PI2Xr", "PU2Xr" };
            _DeliveryEvents = new List<string>() { "PV2X", "PC2X", "SI2X", "PO2X", "PI2X", "PU2X" };
        }

        #endregion

        #region Methods
        public override void Clear()
        {
            foreach (string key in _Data.Keys)
                _Data[key].Clear();
            _Data.Clear();
        }

        public override void Update(EventObservedEvent evt)
        //public override void Update(ObservedEvent e)
        {
            //EventObservedEvent evt = (EventObservedEvent)e;

            CraneLog log = null;
            string stkid = string.Empty;

            if (evt.EventObject.Name == "InlineStocker" &&
                   evt.Event.Name == "CI")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                stkid = (string)fle[0];
                

                //No. Cassttes in Buffer
                int wip = Factory.Stocker.WIP[stkid];
                //No. Cassettes in Stocker In-ports
                int si = 0;
                foreach(string convid in Factory.MasterData.Network.Nodes[stkid].InputEdges)
                {
                    if (Factory.Stocker.SI[stkid, convid] == 0)
                        si++;
                }
                //No. Depart-ready Cassettes in EQP Ports
                int dr = 0;
                int x = 0, rx = 0;//, ec = 0;
                NetworkNode stkNode = Factory.MasterData.Network.Nodes[stkid];
                foreach(string eqpid in stkNode.OutPortEQPs)
                {
                    ProcessingEquipment eqp = (ProcessingEquipment)Factory[eqpid];
                    if (eqp.Type == FactoryObjectType.Biinline)
                    {
                        BiInlineCell biline = (BiInlineCell)eqp;
                        dr += biline.PO[eqpid].DR;
                    }else{
                        dr += eqp.P[eqpid].DR;
                    }
                }

                foreach (string eqpid in stkNode.InPortEQPs)
                {
                    ProcessingEquipment eqp = (ProcessingEquipment)Factory[eqpid];
                    if (eqp.Type == FactoryObjectType.Biinline)
                    {
                        BiInlineCell biline = (BiInlineCell)eqp;
                        x += biline.P[eqpid].X;
                        rx += biline.P[eqpid].RX;
                        //ec += biline.P[eqpid].E;
                    }
                    else
                    {
                        dr += eqp.P[eqpid].DR;
                        x += eqp.P[eqpid].X;
                        rx += eqp.P[eqpid].RX;
                        //ec += eqp.P[eqpid].E;
                    }
                }

                log = new CraneLog(fle.Time, CraneState.Idle, wip, si, x, rx, dr);
            }
            else if (evt.EventObject.Name == "InlineStocker" &&
                  _RetrievalEvents.Contains(evt.Event.Name))
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                stkid = (string)fle[0];
                string to = (string)fle[1];
                Cassette cst = (Cassette)fle[2];
                log = new CraneLog(fle.Time, CraneState.Retrieval, "", to, cst);
            }
            else if (evt.EventObject.Name == "InlineStocker" &&
                  _DeliveryEvents.Contains(evt.Event.Name))
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                stkid = (string)fle[0];
                string from = (string)fle[1];
                Cassette cst = (Cassette)fle[2];
                string to = cst.A;
                log = new CraneLog(fle.Time, CraneState.Delivery, from, to, cst);
            }
            else if (evt.EventObject.Name == "InlineStocker" &&
                    evt.Event.Name == "B2Xr")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                stkid = (string)fle[0];
                Cassette cst = (Cassette)fle[1]; 
                string to = "Buffer";
                log = new CraneLog(fle.Time, CraneState.Retrieval, "", to, cst);
            }
            else if (evt.EventObject.Name == "InlineStocker" &&
                    evt.Event.Name == "B2X")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                stkid = (string)fle[0];
                Cassette cst = (Cassette)fle[1];
                string from = "Buffer";
                string to = cst.A;
                log = new CraneLog(fle.Time, CraneState.Delivery, from, to, cst);
            }

            if (string.IsNullOrEmpty(stkid) || log == null)
                return;

            AddCraneLog(stkid, log);
        }

        private void AddCraneLog(string stkid, CraneLog log)
        {
            if (_Data.ContainsKey(stkid))
            {
                CraneHistory history = _Data[stkid];
                history.Add(log);
                _Data[stkid] = history;
            }
            else
            {
                CraneHistory history = new CraneHistory(stkid);
                history.Add(log);
                _Data.Add(stkid, history);
            }
        }

        public void Initialize()
        {
            
        }

        public override void Finalize(double eosTime)
        {
            foreach (string stkid in _Data.Keys)
            {
                CraneHistory history = _Data[stkid];
                history.Finalize(eosTime);
            } 
        }

        public override void Dispose()
        {
            Dispose(true);
        }

        private bool IsDisposed;
        protected virtual void Dispose(bool isDisposing)
        {
            if (IsDisposed) return;
            if (isDisposing)
            {
                // Dispose all Managed Resources
                this.Clear();
            }
            IsDisposed = true;
            GC.SuppressFinalize(this);
        } 

        #endregion
    }
}
