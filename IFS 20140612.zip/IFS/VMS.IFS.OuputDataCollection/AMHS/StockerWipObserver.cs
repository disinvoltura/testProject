﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.Models;

namespace VMS.IFS.OuputDataCollection
{
    /// <summary>
    /// Stocker WIP = SI, SO, Buffer
    /// </summary>
    public class StockerWipObserver : FactoryEventObserver
    {
        #region Member Variables
        private Dictionary<string, TimeDependentStatistics> _Stat;
        private Dictionary<string, TimeBucketDependentStatistics> _ShiftWIPData;
        private Dictionary<string, int> _WIP;

        //Time Units per a shift (in hours)
        private int _ShiftTime;
        #endregion

        #region Properties
        public Dictionary<string, TimeDependentStatistics> FabWIP
        {
            get { return _Stat; }
        }

        public Dictionary<string, TimeBucketDependentStatistics> ShiftWIP
        {
            get { return _ShiftWIPData; }
        }
        #endregion

        #region Constructors
        public StockerWipObserver(Factory factory, Dictionary<string, object> runOptions)
            : base ("StockerWIPObserver", factory)
        {
            _ShiftTime = (int)runOptions[SimulationArguments.UnitTime];

            _Stat = new Dictionary<string, TimeDependentStatistics>();
            _ShiftWIPData = new Dictionary<string, TimeBucketDependentStatistics>();
                //new TimeBucketDependentStatistics("ShiftFabWIP", _ShiftTime);

            _WIP = new Dictionary<string,int>();
        }

        #endregion

        #region Methods
        public override void Update(EventObservedEvent evt)
        //public override void Update(ObservedEvent e)
        {
            //EventObservedEvent evt = (EventObservedEvent)e;
            
            //if (evt.EventObject.Name == "InlineStocker" &&
            //    evt.Event.Name == "X2B")
            //{
            //    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
            //    IncreaseWIP(evt.Time, fle.EQPID);
            //}
            //else if (evt.EventObject.Name == "InlineStocker" &&
            //         evt.Event.Name == "B2X" )
            //{
            //    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
            //    DecreaseWIP(evt.Time, fle.EQPID);
            //}
            if (evt.EventObject.Name == "InlineStocker" &&
                   evt.Event.Name == "C2SI")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                IncreaseWIP(evt.Time, fle.EQPID);
            }
            //else if (evt.EventObject.Name == "InlineStocker" &&
            //       evt.Event.Name == "SI2X")
            //{
            //    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
            //    DecreaseWIP(evt.Time, fle.EQPID);
            //}
            //else if (evt.EventObject.Name == "Conveyor" &&
            //       evt.Event.Name == "X2SO")
            //{
            //    FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
            //    IncreaseWIP(evt.Time, fle.Cassette.B);
            //}
            else if (evt.EventObject.Name == "Conveyor" &&
                   evt.Event.Name == "SOC")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                DecreaseWIP(evt.Time, fle.Cassette.B);
            }
            else if (evt.EventObject.Name == "BiInlineCell" &&
                  evt.Event.Name == "LGL")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                DecreaseWIP(evt.Time, fle.Cassette.B);
            }
            else if (evt.EventObject.Name == "BiInlineCell" &&
                  evt.Event.Name == "CD")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)evt.Event;
                IncreaseWIP(evt.Time, Factory.MasterData.EQPPort[fle.Cassette.C].OutStkID);
            }

        }

        private void IncreaseWIP(double time, string s)
        {
            if (_WIP.ContainsKey(s))
            {
                _WIP[s] = _WIP[s] + 1;
                _Stat[s].Add(time, _WIP[s]);
                _ShiftWIPData[s].Add(time, _WIP[s]);
            }
            else
            {
                _WIP.Add(s, 0);
                TimeDependentStatistics statZero =
                    new TimeDependentStatistics("StockerWIPObserver_" + s);
                statZero.Add(time, 0);
                _Stat.Add(s, statZero);

                TimeBucketDependentStatistics shiftWIPZero =
                    new TimeBucketDependentStatistics("StockerWIPObserver_" + s, _ShiftTime);
                shiftWIPZero.Add(time, 0);
                _ShiftWIPData.Add(s, shiftWIPZero);

                int wip = 1;
                _WIP[s] = wip;
                _Stat[s].Add(time, wip);
                _ShiftWIPData[s].Add(time, wip);

                //_WIP.Add(s, wip);

                //TimeDependentStatistics stat =
                //    new TimeDependentStatistics("StockerWIPObserver_" + s);
                //stat.Add(time, wip);
                //_Stat.Add(s, stat);

                //TimeBucketDependentStatistics shiftWIP =
                //    new TimeBucketDependentStatistics("StockerWIPObserver_" + s, _ShiftTime);
                //shiftWIP.Add(time, wip);
                //_ShiftWIPData.Add(s, shiftWIP);
            }
        }

        private void DecreaseWIP(double time, string s)
        {
            int wip = _WIP[s] - 1;
            _WIP[s] = wip;
            _Stat[s].Add(time, _WIP[s]);
            _ShiftWIPData[s].Add(time, _WIP[s]);
        }

        public void Initialize(Dictionary<string, int> wiplist)
        {
            foreach (string stkid in wiplist.Keys)
            {
                int wip = wiplist[stkid];
                _WIP.Add(stkid, wip);

                TimeDependentStatistics stat = 
                    new TimeDependentStatistics("StockerWIPObserver_"+ stkid);
                stat.Add(0, wip);
                _Stat.Add(stkid, stat);

                TimeBucketDependentStatistics shiftWIP =
                    new TimeBucketDependentStatistics("StockerWIPObserver_" + stkid, _ShiftTime);
                shiftWIP.Add(0, wip);
                _ShiftWIPData.Add(stkid, shiftWIP);
            }
        }

        public override void Finalize(double eosTime)
        {
            foreach (string stkid in _Stat.Keys)
            {
                _Stat[stkid].Add(eosTime, _WIP[stkid]);
                _ShiftWIPData[stkid].Add(eosTime, _WIP[stkid]);

                //System.Diagnostics.Debug.WriteLine("StockerWIPObser: " + stkid);
                //foreach (ValueChange vc in _Stat[stkid].ValueChanges)
                //{
                //    System.Diagnostics.Debug.WriteLine(vc.Time + "\t" + vc.Value);
                //}
            }            
        }

        public override void Clear()
        {
            foreach (string key in _Stat.Keys)
            {
                _Stat[key].Clear();
            }

            foreach (string key in _ShiftWIPData.Keys)
            {
                _ShiftWIPData[key].Clear();
            }

            _WIP.Clear();
            
        }

        public override void Dispose()
        {
            Dispose(true);
        }

        private bool IsDisposed;
        protected virtual void Dispose(bool isDisposing)
        {
            if (IsDisposed) return;
            if (isDisposing)
            {
                // Dispose all Managed Resources
                this.Clear();
            }
            IsDisposed = true;
            GC.SuppressFinalize(this);
        } 

        #endregion
    }
}
