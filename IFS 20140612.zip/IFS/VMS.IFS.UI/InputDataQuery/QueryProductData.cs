﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VMS.IFS.DataModel.InputData;
using Northwoods.Go;

namespace VMS.IFS.UI
{
    public partial class QueryProductData : Form
    {
        private InputDataSet _DS;
        private VMS.IFS.DataModel.SimulationData.BOPData _BOP;
        public QueryProductData(InputDataSet ids)
        {
            _DS = ids;
            InitializeComponent();

            loadData();
        }

        private void loadData()
        {
            cbProduct.Items.Clear();
            foreach (InputDataSet.ProductDataTableRow row in _DS.ProductDataTable.Rows)
            {
                cbProduct.Items.Add(row.PROD_ID);
            }

            cbLoadableSet.Items.Clear();
            List<string> versioNoList = makeLoadableSetVersionList();
            cbLoadableSet.Items.AddRange(versioNoList.ToArray());

            _BOP = new DataModel.SimulationData.BOPData();
            _BOP.Build(_DS, new Dictionary<string, object>());
        }

        private List<string> makeLoadableSetVersionList()
        {
            List<string> lstLoadableSet = new List<string>();

            foreach (DataRow dr in _DS.LoadableSetDataTable.Rows)
            {
                if (!lstLoadableSet.Contains(dr["VERSION_NO"].ToString()))
                {
                    lstLoadableSet.Add(dr["VERSION_NO"].ToString());
                }
            }

            return lstLoadableSet;
        }

        private void clearData()
        {
            txtGlsQty.Text = "";
            txtAvgYield.Text = "";
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbProduct.Text))
                return;

            clearData();

            string productid = cbProduct.Text;

            lblError.Text = "";
            
            //basic data
            InputDataSet.ProductDataTableRow[] rows1 =
                (InputDataSet.ProductDataTableRow[])_DS.ProductDataTable.Select("PROD_ID='" + productid+ "'");
            if (rows1 == null || rows1.Length == 0)
            {
                lblError.Text = "No such product data can be found.";
                return;
            }

            txtGlsQty.Text = rows1[0].GLASS_QTY.ToString();
            txtAvgYield.Text = rows1[0].AVG_YIELD.ToString();

            //process (bop) data
            showBOP(productid);

        }

        #region BOP Diagram
        //private PointF _StepPos;
        private void showBOP(string productid)
        {
            string firstStepID = _BOP.GetFirstStepID(productid);
            string curStepID = firstStepID;
            
            PointF stepPos = new PointF(40, 40);
            goView1.Document.Clear();

            //Dictionary<string , GoBasicNode> nodes = new Dictionary<string,GoBasicNode>();
            //nodes.Add(curStepID, stepNode);

            GoBasicNode stepNode = processStep(productid, curStepID, stepPos);
            
        }

        private GoBasicNode processStep(string productid, string stepid, PointF stepPos)
        {
            GoBasicNode stepNode = AddStep(stepid, stepPos);

            List<VMS.IFS.DataModel.SimulationData.NextStep> nextStepList = _BOP.GetNextStepList(productid, stepid);

            float x = stepPos.X + 100;
            float y = stepPos.Y;
            foreach (VMS.IFS.DataModel.SimulationData.NextStep nextStep in nextStepList)
            {
                PointF nextStepPos = new PointF(x, y);
                GoBasicNode nextNode = processStep(productid, nextStep.StepID, nextStepPos);

                goView1.StartTransaction();

                Transition t = new Transition();
                t.FromPort = stepNode.Port;
                t.ToPort = nextNode.Port;
                t.Label = nextStep.Yield.ToString();
                goView1.Document.Add(t);

                goView1.FinishTransaction("added transition");
                y += 50;
            }

            return stepNode;
        }

        private GoBasicNode AddStep(string stepid, PointF pos)
        {
            goView1.StartTransaction();
            GoBasicNode stepNode = BOPDocument.NewNode(stepid);
            stepNode.Location = pos;// e.DocPoint;
            
            goView1.Document.Add(stepNode);

            goView1.FinishTransaction("added step node");

            return stepNode;
        }

        #endregion

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void txtInPort_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbLoadableSet.Text))
                return;

            if (string.IsNullOrEmpty(cbProduct.Text))
                return;

            string productid = cbProduct.Text;
            string versionNo = cbLoadableSet.Text;

            string firstStepID = _BOP.GetFirstStepID(productid);
            string lastStepID = _BOP.GetLastStepID(productid);
            string curStepID = firstStepID;
            double tat = 0;
            while (curStepID != lastStepID)
            {
                tat += calculateProcessingTimeAtStep(versionNo, productid, curStepID);

                curStepID = _BOP.Query(productid, curStepID);
            }

            tat = Math.Round(tat / 60,0);
            txtTAT.Text = tat.ToString();
        }

        /// <summary>
        /// 한 Cassette를 처리하는데 소요되는 시간 계산 (가장 빨리 처리할 수 있는 설비)
        /// </summary>
        /// <param name="productid"></param>
        /// <param name="stepid"></param>
        /// <returns></returns>
        private double calculateProcessingTimeAtStep(string versionNo, string productid, string stepid)
        {
            double pt = double.MaxValue;

            List<string> loadableEQPs = getLoadableEQPs(versionNo, productid, stepid);
            foreach (string eqpid in loadableEQPs)
            {
                double nextPT = calculateProcessingAtEQP(eqpid, productid, stepid);

                if (nextPT < pt)
                    pt = nextPT;
            }

            if (pt == double.MaxValue)
                return 0;
            else
                return pt;
        }

        private double calculateProcessingAtEQP(string eqpid, string productid, string stepid)
        {
            InputDataSet.ProcessingTimeDataTableRow[] rows =
                (InputDataSet.ProcessingTimeDataTableRow[])
                _DS.ProcessingTimeDataTable.Select("PROD_ID='"+productid+"' AND STEP_ID='"+stepid+"' AND EQP_ID='"+eqpid+"'");

            double rslt = 0;

            if (rows == null || rows.Length == 0)
                return rslt;

            InputDataSet.EquipmentDataTableRow[] rows2 =
                (InputDataSet.EquipmentDataTableRow[])
                _DS.EquipmentDataTable.Select("EQP_ID='" + eqpid + "'");

            if (rows2 == null || rows.Length == 0)
                return rslt;

            int glsQty = int.Parse(txtGlsQty.Text);
            int tactTime = int.Parse(rows[0].TACT_TIME);
            int flowTime = int.Parse(rows[0].FLOW_TIME);
            int num = int.Parse(rows2[0].NUM);

            string eqpType = rows2[0].EQP_TYPE.ToLower();
            if (eqpType == "u")
            {
                rslt = tactTime * glsQty + flowTime;
            }
            else if (eqpType == "c")
            {
                rslt = (tactTime + flowTime) * (glsQty / num + (glsQty%num>0 ? 1 : 0));
            }
            else if (eqpType == "v")
            {
                rslt = tactTime * glsQty * 2 + flowTime;
            }
            else if (eqpType == "b")
            {
                rslt = tactTime * + flowTime + tactTime * glsQty;
            }

            return rslt;
        }


        private List<string> getLoadableEQPs(string versionNo, string productid, string stepid)
        {
            InputDataSet.LoadableSetDataTableRow[] rows =
                (InputDataSet.LoadableSetDataTableRow[])
                _DS.LoadableSetDataTable.Select("VERSION_NO='" + versionNo + "' AND PROD_ID='" + productid + "' AND STEP_ID='" + stepid + "'");

            List<string> rslt = new List<string>();
            foreach (InputDataSet.LoadableSetDataTableRow row in rows)
                rslt.Add(row.EQP_ID);

            return rslt;
        }
    }
}
