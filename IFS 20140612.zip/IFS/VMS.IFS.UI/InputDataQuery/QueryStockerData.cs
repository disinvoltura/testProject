﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VMS.IFS.DataModel.InputData;

namespace VMS.IFS.UI
{
    public partial class QueryStockerData : Form
    {
        private InputDataSet _DS;
        public QueryStockerData(InputDataSet ids)
        {
            _DS = ids;
            InitializeComponent();

            loadData();
        }

        private void loadData()
        {
            cbSTK.Items.Clear();
            foreach (InputDataSet.InlineStockerDataTableRow row in _DS.InlineStockerDataTable.Rows)
            {
                cbSTK.Items.Add(row.STK_ID);
            }
        }

        private void clearData()
        {
            lvEQP.Items.Clear();
            lvCNV.Items.Clear();

            txtType.Text = "";
            txtDT.Text = "";
            txtRT.Text = "";
            txtCapacity.Text = "";
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbSTK.Text))
                return;

            clearData();

            string stkid = cbSTK.Text;

            lblError.Text = "";
            //basic data
            InputDataSet.InlineStockerDataTableRow[] rows1 =
                (InputDataSet.InlineStockerDataTableRow[])_DS.InlineStockerDataTable.Select("STK_ID='" + stkid + "'");
            if (rows1 == null || rows1.Length == 0)
            {
                lblError.Text = "No such stocker data can be found.";
                return;
            }
            string stkType = rows1[0].STK_TYPE.ToLower();
            if (stkType == "s")
                txtType.Text = "Single crane";
            else
                txtType.Text = "Doual crane";

            if (string.IsNullOrEmpty(rows1[0].STK_BUFFER))
                txtCapacity.Text = "-";
            else
                txtCapacity.Text = rows1[0].STK_BUFFER;

            if (string.IsNullOrEmpty(rows1[0].RETRIEVAL_TIME))
                txtRT.Text = "-";
            else
                txtRT.Text = rows1[0].RETRIEVAL_TIME;

            if (string.IsNullOrEmpty(rows1[0].DELIVERY_TIME))
                txtDT.Text = "-";
            else
                txtDT.Text = rows1[0].DELIVERY_TIME;

            //equipment data
            InputDataSet.EQP_PortDataTableRow[] rows2 =
                (InputDataSet.EQP_PortDataTableRow[])
                _DS.EQP_PortDataTable.Select("STK_ID = '" + stkid+ "'");

            if (rows2 != null && rows2.Length > 0)
            {
                //label5.Text = "Loadable Data (" + rows2.Length + ")";
                foreach (InputDataSet.EQP_PortDataTableRow row in rows2)
                {
                    ListViewItem item = new ListViewItem(row.EQP_ID);
                    item.SubItems.Add(row.PORT_TYPE);
                    item.SubItems.Add(row.PORT_CAPA);
                    lvEQP.Items.Add(item);
                }
            }
            else
            {
                //label5.Text = "Loadable Data (0)";
            }
            
            lvEQP.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);

            //Conveyor data
            InputDataSet.ConveyorDataTableRow[] rows3 =
                (InputDataSet.ConveyorDataTableRow[])
                _DS.ConveyorDataTable.Select("FROM_STK = '" + stkid+ "' OR TO_STK='"+stkid+"'");

            if (rows3 == null || rows3.Length == 0)
                return;

            foreach (InputDataSet.ConveyorDataTableRow cRow in rows3)
            {
                ListViewItem item = new ListViewItem(cRow.CONV_ID);
                item.SubItems.Add(cRow.CONV_TYPE);
                item.SubItems.Add(cRow.FROM_STK);
                item.SubItems.Add(cRow.TO_STK);
                item.SubItems.Add(cRow.CONV_BUFFER);
                item.SubItems.Add(cRow.CONV_TIME);
                lvCNV.Items.Add(item);
            }
            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
