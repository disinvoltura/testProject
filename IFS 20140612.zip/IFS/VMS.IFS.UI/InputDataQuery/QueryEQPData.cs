﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VMS.IFS.DataModel.InputData;

namespace VMS.IFS.UI
{
    public partial class QueryEQPData : Form
    {
        private InputDataSet _DS;
        public QueryEQPData(InputDataSet ids)
        {
            _DS = ids;
            InitializeComponent();

            loadData();
        }

        private void loadData()
        {
            cbEQP.Items.Clear();
            foreach (InputDataSet.EquipmentDataTableRow row in _DS.EquipmentDataTable.Rows)
            {
                cbEQP.Items.Add(row.EQP_ID);
            }
        }

        private void clearData()
        {
            listView1.Items.Clear();
            txtType.Text = "";
            txtSetupTime.Text = "";
            txtInPort.Text = "";
            txtOutPort.Text = "";
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbEQP.Text))
                return;

            clearData();

            string eqpid = cbEQP.Text;

            lblError.Text = "";
            //basic data
            InputDataSet.EquipmentDataTableRow[] rows1 = 
                (InputDataSet.EquipmentDataTableRow[])_DS.EquipmentDataTable.Select("EQP_ID ='" + eqpid + "'");
            if (rows1 == null || rows1.Length == 0)
            {
                lblError.Text = "No such equipment data can be found.";
                return;
            }
            string eqpType = rows1[0].EQP_TYPE.ToLower();
            if (eqpType == "u")
                txtType.Text = "Uni-inline Cell";
            else if (eqpType == "c")
                txtType.Text = "Chamber-type Equipment";
            else if (eqpType == "v")
                txtType.Text = "Oven-type Equipment";
            else if (eqpType == "b")
                txtType.Text = "Bi-inline Cell";
            if (rows1[0].IsSETUP_TIMENull())
            //if (string.IsNullOrEmpty(rows1[0].SETUP_TIME))
                txtSetupTime.Text = "-";
            else
                txtSetupTime.Text = rows1[0].SETUP_TIME;

            //loadable data
            InputDataSet.ProcessingTimeDataTableRow[] rows2 =  
                (InputDataSet.ProcessingTimeDataTableRow[] )
                _DS.ProcessingTimeDataTable.Select("EQP_ID = '" + eqpid + "'");

            if (rows2 != null && rows2.Length > 0)
            {
                label5.Text = "Loadable Data (" + rows2.Length + ")";
                foreach (InputDataSet.ProcessingTimeDataTableRow row in rows2)
                {
                    ListViewItem item = new ListViewItem(row.PROD_ID);
                    item.SubItems.Add(row.STEP_ID);
                    item.SubItems.Add(row.TACT_TIME);
                    item.SubItems.Add(row.FLOW_TIME);
                    listView1.Items.Add(item);
                }
            }
            else
            {
                label5.Text = "Loadable Data (0)";
            }

            //stocker data
            InputDataSet.EQP_PortDataTableRow[] rows3 = 
                (InputDataSet.EQP_PortDataTableRow[])
                _DS.EQP_PortDataTable.Select("EQP_ID = '" + eqpid + "'");

            if (rows3 == null || rows3.Length == 0)
                return;

            if (eqpType == "b")
            {
                foreach (InputDataSet.EQP_PortDataTableRow row in rows3)
                {
                    if (row.PORT_TYPE.ToLower() == "i")
                        txtInPort.Text = row.STK_ID + " (" + row.PORT_CAPA + ")";
                    else if (row.PORT_TYPE.ToLower() == "o")
                        txtOutPort.Text = row.STK_ID + " (" + row.PORT_CAPA + ")";
                }
            }
            else
            {
                txtInPort.Text = rows3[0].STK_ID + " (" + rows3[0].PORT_CAPA + ")";
                txtOutPort.Text = rows3[0].STK_ID + " (" + rows3[0].PORT_CAPA + ")";
            }

            //Where Next STK
            txtWhereNext.Text = "";
            InputDataSet.WhereNextSTKDataTableRow[] rows4 =
                (InputDataSet.WhereNextSTKDataTableRow[])
                    _DS.WhereNextSTKDataTable.Select("EQP_ID='" + eqpid + "'");
            foreach (InputDataSet.WhereNextSTKDataTableRow row in rows4)
                txtWhereNext.Text += row.STK_ID + ";";
        }
    }
}
