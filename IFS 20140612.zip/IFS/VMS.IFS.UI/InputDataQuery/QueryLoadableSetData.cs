﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VMS.IFS.DataModel.InputData;

namespace VMS.IFS.UI
{
    public partial class QueryLoadableSetData: Form
    {
        private InputDataSet _DS;

        public QueryLoadableSetData(InputDataSet ids)
        {
            _DS = ids;
            InitializeComponent();

            loadData();
        }

        private void loadData()
        {
            //Version No
            cbVersionNo.Items.Clear();

            List<string> versioNoList = makeLoadableSetVersionList();
            cbVersionNo.Items.AddRange(versioNoList.ToArray());

        }

        private List<string> makeLoadableSetVersionList()
        {
            List<string> lstLoadableSet = new List<string>();

            foreach (DataRow dr in _DS.LoadableSetDataTable.Rows)
            {
                if (!lstLoadableSet.Contains(dr["VERSION_NO"].ToString()))
                {
                    lstLoadableSet.Add(dr["VERSION_NO"].ToString());
                }
            }

            return lstLoadableSet;
        }

        private List<string> makeProductIdList(string versionNo)
        {
            List<string> prodlist = new List<string>();
            InputDataSet.LoadableSetDataTableRow[] rows = 
                (InputDataSet.LoadableSetDataTableRow[]) 
                _DS.LoadableSetDataTable.Select("VERSION_NO='" + versionNo + "'");

            foreach (InputDataSet.LoadableSetDataTableRow dr in rows)
            {
                if (!prodlist.Contains(dr.PROD_ID))
                    prodlist.Add(dr.PROD_ID);
            }

            return prodlist;
        }

        private List<string> makeStepList(string versionNo, string prodID)
        {
            List<string> steplist = new List<string>();
            InputDataSet.LoadableSetDataTableRow[] rows =
                (InputDataSet.LoadableSetDataTableRow[])
                _DS.LoadableSetDataTable.Select("VERSION_NO='" + versionNo + "' AND PROD_ID='"+prodID+"'");

            foreach (InputDataSet.LoadableSetDataTableRow dr in rows)
            {
                if (!steplist.Contains(dr.STEP_ID))
                    steplist.Add(dr.STEP_ID);
            }

            return steplist;
        }

        private void clearData()
        {
            
        }

        private void drawHeaders(List<string> stepList, List<string> eqpList)
        {
            grid.Rows.Clear();

            grid.BorderStyle = BorderStyle.None;
            grid.Redim(1 + stepList.Count, 1 + eqpList.Count);
            //grid.EnableSort = true;
            //grid.CustomSort = false;
            grid.FixedRows = 1;
            grid.FixedColumns = 1;

            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            grid.Font = new Font("Calibe", 9);

            SourceGrid.Cells.ColumnHeader stepHeader =
                    new SourceGrid.Cells.ColumnHeader("Step ID");
            stepHeader.View = titleModel;
            grid[0, 0] = stepHeader;

            for (int i = 0; i < eqpList.Count; i++)
            {
                SourceGrid.Cells.ColumnHeader header =
                    new SourceGrid.Cells.ColumnHeader(eqpList[i]);

                header.View = titleModel;
                grid[0, 1 + i] = header;
            }

            grid.SelectionMode = SourceGrid.GridSelectionMode.Row;

            for(int i = 0; i <stepList.Count; i++)
            {
                SourceGrid.Cells.ColumnHeader header =
                    new SourceGrid.Cells.ColumnHeader(stepList[i]);

                header.View = titleModel;
                grid[1+i, 0] = header;
            }
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbVersionNo.Text) ||
                string.IsNullOrEmpty(cbProductID.Text))
                return;
            
            string versionNo = cbVersionNo.Text;
            string prodID = cbProductID.Text;

            clearData();

            List<string> stepList = new List<string>();
            List<string> eqpList = new List<string>();
            Dictionary<string, int> eqpColumns = new Dictionary<string, int>();

            foreach (string stepid in cbStep.CheckedItems)
            {
                stepList.Add(stepid);

                InputDataSet.ProcessingTimeDataTableRow[] rows =
                    (InputDataSet.ProcessingTimeDataTableRow[])
                    _DS.ProcessingTimeDataTable.Select("PROD_ID='" + prodID + "' AND STEP_ID = '" + stepid + "'");

                foreach (InputDataSet.ProcessingTimeDataTableRow row in rows)
                {
                    if (!eqpList.Contains(row.EQP_ID))
                    {
                        int index = eqpList.Count;
                        eqpList.Add(row.EQP_ID);
                        eqpColumns.Add(row.EQP_ID, index);
                    }
                }
            }

            drawHeaders(stepList, eqpList);

            for(int k = 0; k < stepList.Count; k++)
            {
                string stepid = stepList[k];
                InputDataSet.LoadableSetDataTableRow[] lsRows =
                    (InputDataSet.LoadableSetDataTableRow[])
                    _DS.LoadableSetDataTable.Select("VERSION_NO='" + versionNo + "' AND PROD_ID='" + prodID + "' AND STEP_ID = '" + stepid + "'");

                foreach (InputDataSet.LoadableSetDataTableRow row in lsRows)
                {
                    int index = eqpColumns[row.EQP_ID];

                    SourceGrid.Cells.ColumnHeader header =
                        new SourceGrid.Cells.ColumnHeader("O");

                    grid[1 + k, 1 + index] = header;
                }
            }

            grid.AutoSizeCells();
        }

        private void cbVersionNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbVersionNo.Text))
                return;

            cbProductID.Items.Clear();
            cbStep.Items.Clear();
            cbProductID.Text = "";
            cbStep.Text = "";
            string versionNo = cbVersionNo.Text;
            List<string> prodList = makeProductIdList(versionNo);
            if (prodList == null)
                return;

            cbProductID.Items.AddRange(prodList.ToArray());
        }

        private void cbProductID_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbVersionNo.Text))
                return;

            if (string.IsNullOrEmpty(cbProductID.Text))
                return;

            cbStep.Items.Clear();

            string versionNo = cbVersionNo.Text;
            string prodid = cbProductID.Text;
            List<string> steplist = makeStepList(versionNo, prodid);
            if (steplist== null)
                return;

            cbStep.Items.AddRange(steplist.ToArray());
        }
    }
}
