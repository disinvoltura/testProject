﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VMS.IFS.DataModel.InputData;
using VMS.IFS.DataModel.SimulationData;
using Northwoods.Go;
using Northwoods.Go.Layout;

namespace VMS.IFS.UI
{
    public partial class QueryNetworkData : Form
    {
        private InputDataSet _DS;
        private VMS.IFS.DataModel.SimulationData.RouteData _Route;

        public QueryNetworkData(InputDataSet ids)
        {
            _DS = ids;
            InitializeComponent();

            loadData();
        }

        private void loadData()
        {
            cbVersionNo.Items.Clear();

            List<string> versioNoList = makeMCSWeightVersionList();
            cbVersionNo.Items.AddRange(versioNoList.ToArray());

            cbFromSTK.Items.Clear();
            cbToSTK.Items.Clear();
            foreach (DataRow dr in _DS.InlineStockerDataTable.Rows)
            {
                string stkid = dr["STK_ID"].ToString();
                cbFromSTK.Items.Add(stkid);
                cbToSTK.Items.Add(stkid);
            }
        }

        private List<string> makeMCSWeightVersionList()
        {
            List<string> versionNoList = new List<string>();

            foreach (DataRow dr in _DS.MCSWeightSetDataTable.Rows)
            {
                if (!versionNoList.Contains(dr["VERSION_NO"].ToString()))
                {
                    versionNoList.Add(dr["VERSION_NO"].ToString());
                }
            }

            return versionNoList;
        }

        private void clearData()
        {
            goView1.Document.Clear();

            txtRoute.Text = "";
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbVersionNo.Text))
                return;

            clearData();

            string versionNo = cbVersionNo.Text;

            lblError.Text = "";

            _Route = new RouteData();

            Dictionary<string, object> runOptions = new Dictionary<string, object>();
            runOptions.Add(SimulationArguments.MCSWeightMode, true);

            _Route.Build(_DS, runOptions);

            drawNetwork(versionNo);
            
        }

        private void drawNetwork(string versionNo)
        {
            //Nodes
            Microsoft.Glee.GleeGraph oGleeGraph = new Microsoft.Glee.GleeGraph();
            Microsoft.Glee.Splines.ICurve oCurve =
               Microsoft.Glee.Splines.CurveFactory.CreateEllipse(
                   1, 1,
                   new Microsoft.Glee.Splines.Point(0, 0)
                   );

            PointF pos = new PointF(30, 30);
            Dictionary<string, GoBasicNode> nodes = new Dictionary<string, GoBasicNode>();
            Dictionary<string, Microsoft.Glee.Node> nodelist = new Dictionary<string, Microsoft.Glee.Node>();
            foreach (InputDataSet.InlineStockerDataTableRow stkRow in _DS.InlineStockerDataTable.Rows)
            {
                GoBasicNode node = AddNode(stkRow.STK_ID, pos);
                
                pos.X += 50;

                nodes.Add(stkRow.STK_ID, node);

                Microsoft.Glee.Node strNode1 = new Microsoft.Glee.Node(stkRow.STK_ID, oCurve);
                oGleeGraph.AddNode(strNode1);
                nodelist.Add(stkRow.STK_ID, strNode1);
            }

            //Arcs
            Dictionary<string, string> fromStklist = new Dictionary<string,string>();
            Dictionary<string, string> toStklist = new Dictionary<string,string>();
            foreach(InputDataSet.ConveyorDataTableRow convRow in _DS.ConveyorDataTable.Rows)
            {
                fromStklist.Add(convRow.CONV_ID, convRow.FROM_STK);
                toStklist.Add(convRow.CONV_ID, convRow.TO_STK);
            }
            
            InputDataSet.MCSWeightSetDataTableRow[] rows =
                (InputDataSet.MCSWeightSetDataTableRow[])
                _DS.MCSWeightSetDataTable.Select("VERSION_NO='" + versionNo + "'");
            foreach(InputDataSet.MCSWeightSetDataTableRow row in rows)
            {
                if (!fromStklist.ContainsKey(row.CONV_ID))
                    continue;
                if (!toStklist.ContainsKey(row.CONV_ID))
                    continue;
                
                string fromStk = fromStklist[row.CONV_ID];
                string toStk = toStklist[row.CONV_ID];

                GoBasicNode fromNode = nodes[fromStk];
                GoBasicNode toNode = nodes[toStk];

                goView1.StartTransaction();

                Transition t = new Transition();
                t.FromPort = fromNode.Port;//.GetPort(0);// Port;
                t.ToPort = toNode.Port;//.GetPort(0);//.Port;
                t.Label = row.CONV_ID + ": " + row.WEIGHT.ToString();
                goView1.Document.Add(t);

                goView1.FinishTransaction("added transition");

                Microsoft.Glee.Node oFromNode = nodelist[fromStk];
                Microsoft.Glee.Node oToNode = nodelist[toStk];
                Microsoft.Glee.Edge oGleeEdge1 =
                    new Microsoft.Glee.Edge(oFromNode, oToNode);
                oGleeEdge1.ArrowHeadAtTarget = true;
                //oGleeEdge1.Weight = int.Parse(row.WEIGHT);
                oGleeGraph.AddEdge(oGleeEdge1);
            }

            oGleeGraph.MinNodeHeight = 50;
            oGleeGraph.MinNodeWidth = 50;
            //oGleeGraph.Transformation.
            oGleeGraph.CalculateLayout();

            foreach (GoBasicNode node in nodes.Values)
            {
                Microsoft.Glee.Node oNode = nodelist[node.Text];
                node.Position = new PointF((float)oNode.Center.X, (float)oNode.Center.Y);
            }

            goView1.StartTransaction();
            goView1.Document.Bounds = goView1.Document.ComputeBounds();
            goView1.RescaleToFit();
            goView1.FinishTransaction("zoom to fit resizing document");

            //doLayout();
        }
        
        private GoBasicNode AddNode(string stkid, PointF pos)
        {
            goView1.StartTransaction();
            GoBasicNode stepNode = NetworkDocument.NewNode(stkid);
            stepNode.Location = pos;// e.DocPoint;

            goView1.Document.Add(stepNode);

            goView1.FinishTransaction("added a node");

            return stepNode;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbFromSTK.Text))
                return;

            if (string.IsNullOrEmpty(cbToSTK.Text))
                return;

            string fromSTKID = cbFromSTK.Text;
            string toSTKID = cbToSTK.Text;
            Route r = _Route.Query(fromSTKID, toSTKID);

            if (r != null)
                txtRoute.Text = r.ToString();
            else
                txtRoute.Text = "";
        }

        private void btnZoomIn_Click(object sender, EventArgs e)
        {
            goView1.DocScale = (float)(Math.Round(goView1.DocScale / 0.9f * 100) / 100);

        }

        private void btnZoomOut_Click(object sender, EventArgs e)
        {
            goView1.DocScale = (float)(Math.Round(goView1.DocScale * 0.9f * 100) / 100);
        }

        private void btnZoomToFit_Click(object sender, EventArgs e)
        {
            goView1.RescaleToFit();
        }
    }

    
}
