﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using Northwoods.Go;

namespace VMS.IFS.UI
{
    [Serializable]
    public class NetworkDocument : GoDocument
    {
        public NetworkDocument() { }
        
        public static GoBasicNode NewNode(string name)
        {
            GoBasicNode state = new GoBasicNode();
            state.LabelSpot = GoObject.Middle;
            state.Shape = new GoRoundedRectangle();
            state.Shape.FillShapeHighlight(Color.FromArgb(80, 180, 240), Color.FromArgb(255, 255, 255));
            state.Editable = false;
            state.Text = name;
            state.Label.Movable = false;
            state.Label.EditableWhenSelected = false;
            state.Label.Editable = false;
            //state.Label.Editor.Editable = false;
            //state.Label.Editor.Selectable = false;
            //state.Label.Editor.Visible = false;
            state.Label.Multiline = true;
            state.Port.IsValidDuplicateLinks = false;
            state.Port.IsValidSelfNode = false;
            state.Port.Visible = false;
            state.Port.Selectable = false;

            return state;
        }

        public virtual int NumLinksBetween(IGoPort a, IGoPort b)
        {
            int count = 0;
            foreach (IGoLink l in a.DestinationLinks)
            {
                if (l.ToPort == b)
                    count++;
            }
            return count;
        }
    }

    [Serializable]
    public class Arc : GoLabeledLink
    {
        private GoText cond;
        public string Label
        {
            set { cond.Text = value; }
            get { return cond.Text; }
        }

        public Arc()
        {
            this.Style = GoStrokeStyle.Bezier;
            this.ToArrow = true;
            this.RealLink.PenColor = Color.Black;
            this.RealLink.PenWidth = 2;
            cond = new GoText();
            cond.Selectable = false;
            cond.Editable = true;
            cond.EditableWhenSelected = true;
            cond.Multiline = true;
            cond.Text = "";
            this.MidLabel = cond;
        }

        public override GoLink CreateRealLink()
        {
            return new NetworkArc();
        }
    }

    [Serializable]
    public class NetworkArc : GoLink
    {
        public NetworkArc() { }

        // Whenever the user resizes a link interactively, don't automatically recalculate
        // the stroke all the time.
        public override void DoResize(GoView view, RectangleF origRect, PointF newPoint,
                                      int whichHandle, GoInputState evttype, SizeF min, SizeF max)
        {
            base.DoResize(view, origRect, newPoint, whichHandle, evttype, min, max);
            this.AdjustingStyle = GoLinkAdjustingStyle.Scale;
        }
    }
}
