﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Linq;
using OfficeOpenXml;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.Engine.ApplicationConnection;
using VMS.IFS.Simulation;

namespace VMS.IFS.UI
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        #region File Menu
        
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            doNew();       
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            handleOpenRequest();             
        }               

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            doSave();
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            doSaveAs();
        }

        private void doSaveAs()
        {
            if (ActiveMdiChild is InputEditor)
            {
                InputEditor ieForm = (InputEditor)this.ActiveMdiChild;
                ieForm.Save("SaveAs");
            }
            else if (ActiveMdiChild is OutputViewer)
            {
                OutputViewer form = (OutputViewer)this.ActiveMdiChild;
                form.Save("SaveAs");
            }         

        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ActiveMdiChild.Close();            
        }

        private void errorCheckToolStripMenuItem_Click(object sender, EventArgs e)
        {
            doCheckErrors();
        }

        private void doCheckErrors()
        {
            if (this.ActiveMdiChild is InputEditor)
            {
                InputEditor ieForm = (InputEditor)this.ActiveMdiChild;
                ieForm.CheckErrors();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
            this.Dispose();
        }

        #endregion                                                        

        #region Simulation Menu
        private void singleRunOptionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showRunOptions();
        }

        private void showRunOptions()
        {
            InputEditor ieForm = getCurrentNewInputEditor(); //changed by D. Kang

            if (ieForm == null) //added by D. Kang
                return;

            ieForm.CheckErrors();

            if (ieForm.HasErrors)
            {
                MessageBox.Show(this, "Please check errors in the input file.", "Error", MessageBoxButtons.OK);
                return;
            }
            else
            {                
                List<string> lstLoadableSet = ieForm.MakeLoadableSetVersionList();
                SingleRunOption roForm = null;
                if (ieForm.RunOptions != null)
                    roForm = new SingleRunOption(ieForm.InputData, lstLoadableSet, ieForm.RunOptions);
                else
                    roForm = new SingleRunOption(ieForm.InputData, lstLoadableSet);
                DialogResult rslt = roForm.ShowDialog();

                if (roForm.SimulationMode == 2)
                {
                    Dictionary<string, object> runOptions = roForm.RunOptions;
                    ieForm.RunOptions = runOptions;

                    tsBtn_Run.Enabled = true;
                    tsBtn_Stop.Enabled = true;
                    runToolStripMenuItem.Visible = true;
                    simulationRunWithAutoModToolStripMenuItem.Visible = true;
                }
                else if (roForm.SimulationMode == 0)
                {
                    Dictionary<string, object> runOptions = roForm.RunOptions;
                    ieForm.RunOptions = runOptions;

                    tsBtn_Run.Enabled = true;
                    tsBtn_Stop.Enabled = true;
                    runToolStripMenuItem.Visible = true;
                    simulationRunWithAutoModToolStripMenuItem.Visible = true;

                    doRun();
                }
                else if (roForm.SimulationMode == 1)
                {
                    Dictionary<string, object> runOptions = roForm.RunOptions;
                    ieForm.RunOptions = runOptions;

                    tsBtn_Run.Enabled = true;
                    tsBtn_Stop.Enabled = true;
                    runToolStripMenuItem.Visible = true;
                    simulationRunWithAutoModToolStripMenuItem.Visible = true;

                    doStartRunwithAutoMod();
                }
            }
        }

        private InputEditor getCurrentNewInputEditor()
        {
            InputEditor rslt = null;
            if (this.ActiveMdiChild != null && this.ActiveMdiChild is InputEditor)
                rslt = (InputEditor)this.ActiveMdiChild;

            return rslt;
        }

        #endregion       

        #region Event Handling

        private void Main_MdiChildActivate(object sender, EventArgs e)
        {
            if (ActiveMdiChild == null)
            {
                saveToolStripMenuItem.Visible = false;
                saveAsToolStripMenuItem.Visible = false;
                closeToolStripMenuItem.Visible = false;
                toolStripSeparator1.Visible = false;
               // errorCheckToolStripMenuItem.Visible = false;
                simulationToolStripMenuItem.Visible = false;
                windowToolStripMenuItem.Visible = false;
                inputDataToolStripMenuItem.Visible = false;

                toolStripSeparator.Visible = false;
                tsBtn_SingleRunOption.Visible = false;
                tsBtn_Run.Visible = false;
                tsBtn_Stop.Visible = false;
                
                saveToolStripButton.Visible = false;

            }
            else if (ActiveMdiChild is InputEditor)
            {
                saveToolStripMenuItem.Visible = true;
                saveAsToolStripMenuItem.Visible = true;
                closeToolStripMenuItem.Visible = true;
                toolStripSeparator1.Visible = true;
                //errorCheckToolStripMenuItem.Visible = true;
                simulationToolStripMenuItem.Visible = true;
                inputDataToolStripMenuItem.Visible = true;

                if (getCurrentNewInputEditor().RunOptions == null)
                {
                    runToolStripMenuItem.Visible = false;
                    simulationRunWithAutoModToolStripMenuItem.Visible = false;
                    tsBtn_Run.Enabled = false;
                    tsBtn_Stop.Enabled = false;
                }
                else
                {
                    runToolStripMenuItem.Visible = true;
                    simulationRunWithAutoModToolStripMenuItem.Visible = true;
                    tsBtn_Run.Enabled = true;
                    tsBtn_Stop.Enabled = true;
                }
                windowToolStripMenuItem.Visible = true;

                saveToolStripButton.Visible = true;
                tsBtn_SingleRunOption.Visible = true;
                tsBtn_Run.Visible = true;
                tsBtn_Stop.Visible = true;
            }
            else if (ActiveMdiChild is OutputViewer)
            {
                saveToolStripMenuItem.Visible = true;
                saveAsToolStripMenuItem.Visible = true;
                closeToolStripMenuItem.Visible = true;
                toolStripSeparator1.Visible = false;
                errorCheckToolStripMenuItem.Visible = false;
                simulationToolStripMenuItem.Visible = false;
                windowToolStripMenuItem.Visible = false;
                inputDataToolStripMenuItem.Visible = false;

                saveToolStripButton.Visible = true;
                tsBtn_SingleRunOption.Visible = false;
                tsBtn_Run.Visible = false;
                tsBtn_Stop.Visible = false;
            }
        }          

        #endregion

        private void tsBtn_Run_Click(object sender, EventArgs e)
        {
            doRun();
        }

        private void runToolStripMenuItem_Click(object sender, EventArgs e)
        {
            doRun();
        }

        private int _RunNo = 1;
        private void doRun()
        {
            InputEditor ieForm = getCurrentNewInputEditor(); //changed by D. Kang
            if (ieForm == null) //added by D. Kang
                return;

            if (ieForm.RunOptions == null)
                return;

            ieForm.Run();
        }

        private void doParallelRun(
            string id,
            VMS.IFS.DataModel.InputData.InputDataSet ids, 
            Dictionary<string, object> runOptions)
        {
            SimulationRunner runner = new SimulationRunner(id, ids, runOptions);
            runner.Run();
        }

        private void manageDispatchingRulesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DispatchingRuleManager dialog = new DispatchingRuleManager();

            DialogResult rslt = dialog.ShowDialog();
            if (rslt == System.Windows.Forms.DialogResult.OK)
            {

            }
        }
       
        private void floatToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            InputEditor curInputEditor = getCurrentNewInputEditor();
            if (curInputEditor != null)
            {
                curInputEditor.Float();
            }
        }

        private void resetLayoutToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            InputEditor curInputEditor = getCurrentNewInputEditor();
            if (curInputEditor != null)
            {
                curInputEditor.ResetLayout();
            }
        }

        #region Toolbar Event Handling Methods
        private void activeFileMenu()
        {
            saveAsToolStripMenuItem.Enabled = true;
        }
        
        private void deActiveFileMenu()
        {
            saveAsToolStripMenuItem.Enabled = false;
        }
        private void newToolStripButton_Click(object sender, EventArgs e)
        {
            doNew();
        }

        private void doNew()
        {
            activeFileMenu();

            InputEditor ieForm = new InputEditor("");
            ieForm.MdiParent = this;
            ieForm.Text += " - New Input File";
            ieForm.Show();
        }

        private void openToolStripButton_Click(object sender, EventArgs e)
        {
            activeFileMenu();

            handleOpenRequest();
        }
        
        private void handleOpenRequest()
        {
            string fileName = "";

            this.openFileDialog1.Filter = "Excel Files|*.xlsx;*.xls|All files|*.*";
            if (this.openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                fileName = openFileDialog1.FileName;
                
                SaveRecentFile(fileName);

                doOpen(fileName);
            }  
        }

        private void doOpen(string fileName)
        {
            foreach (Form form in this.MdiChildren)
            {
                if (form is InputEditor)
                {
                    InputEditor editor = (InputEditor)form;
                    if (editor._FileName.Equals(fileName))
                    {
                        editor.Activate();
                        return;
                    }
                }
            }

            InputEditor ieForm = new InputEditor(fileName);
            ieForm.MdiParent = this;
            ieForm.Text += " - " + Util.GetShortFileName(fileName);
            ieForm.WindowState = FormWindowState.Maximized;
            ieForm.FormClosed += new FormClosedEventHandler(ieForm_FormClosed);
            ieForm.Show();            
        }

        private void ieForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            InputEditor ieForm = (InputEditor)sender;
            try
            {
                ieForm.EnforceDispose();
                ieForm.Dispose();
            }catch(Exception ex){}
            
            GC.Collect();

        }
        
        private void saveToolStripButton_Click(object sender, EventArgs e)
        {
            doSave();
        }

        private void doSave()
        {
            if (ActiveMdiChild is InputEditor)
            {
                InputEditor ieForm = (InputEditor)this.ActiveMdiChild;
                ieForm.CheckErrors();
                ieForm.Save("Save");
            }
            else if (ActiveMdiChild is OutputViewer)
            {
                OutputViewer ovForm = (OutputViewer)this.ActiveMdiChild;
                ovForm.ExportToExcel("Save");
            }
        }
        #endregion

        private void contentsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void tutorialToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string docPath = Application.ExecutablePath;
            docPath = docPath.Substring(0, docPath.LastIndexOf("\\"));
            docPath += "\\Tutorial.pdf";
            try
            {
                System.Diagnostics.Process.Start(docPath);//("AcroRd32.exe", docPath);
            }
            catch (Exception ex)
            {
                MessageBox.Show("You need Acrobat Reader for reading the manual\n" + ex.Message);
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox a = new AboutBox();
            a.ShowDialog(this);
        }

        private void simulationRunWithAutoModToolStripMenuItem_Click(object sender, EventArgs e)
        {
            doStartRunwithAutoMod();
        }

        private Thread _Thread;
        private SimulationRunner _Runner;

        private void doStartRunwithAutoMod()
        {
            InputEditor ieForm = getCurrentNewInputEditor(); 
            if (ieForm == null) 
                return;

            if (ieForm.RunOptions == null)
                return;

            ieForm.RunWithApplication();
        }

        private void ApplicationConnector_ClientDisconnected()
        {
            _Runner.Stop();
            MessageBox.Show("Simulation run is aborted because of the application is disconnected.");
        }
        
        event SimulationEndedEventHandler SimulationEnded;
        private void doRunWithAutoMod()
        {
            try
            {
                _Runner.Run();

                Invoke(SimulationEnded);
            }
            catch (System.Net.Sockets.SocketException ex)
            {
                if (ex.ErrorCode == 10053)
                {
                    MessageBox.Show("The connection is aborted by the application.");
                }
                return;
            }
        }

        private void tsBtn_Stop_Click(object sender, EventArgs e)
        {
            if (_Thread != null)
            {
                try
                {
                    ApplicationConnector.Send_Msg("Simulation End!");
                    ApplicationConnector.Close();

                    _Thread.Abort();
                }
                catch (Exception ex)
                { }
            }

            tsBtn_Run.Enabled = true;
            tsBtn_Stop.Enabled = false;
        }

        #region recent files
        private Queue<string> _RecentFileList = new Queue<string>();
        private int _RecentFileNumber = 10;
        private void SaveRecentFile(string path)
        {
            //clear all recent list from menu
            recentFilesToolStripMenuItem.DropDownItems.Clear();
            LoadRecentList(); //load list from file
            if (!(_RecentFileList.Contains(path))) //prevent duplication on recent list
                _RecentFileList.Enqueue(path); //insert given path into list
            //keep list number not exceeded the given value
            while (_RecentFileList.Count > _RecentFileNumber)
            {
                _RecentFileList.Dequeue();
            }
            foreach (string item in _RecentFileList)
            {
                //create new menu for each item in list
                AddRecentFile(item);
            }
            //writing menu list to file
            //create file called "Recent.txt" located on app folder
            StreamWriter stringToWrite =
                new StreamWriter(System.Environment.CurrentDirectory + "\\Recent.txt");
            foreach (string item in _RecentFileList)
            {
                stringToWrite.WriteLine(item); //write list to stream
            }
            stringToWrite.Flush(); //write stream to file
            stringToWrite.Close(); //close the stream and reclaim memory
        }

        private void AddRecentFile(string item)
        {
            //create new menu for each item in list
            string shortText = Util.GetShortFileName(item);
            ToolStripMenuItem fileRecent = new ToolStripMenuItem
                         (shortText, null, RecentFile_click);
            fileRecent.Tag = item;
            //add the menu to "recent" menu
            recentFilesToolStripMenuItem.DropDownItems.Add(fileRecent);
        }

        private void LoadRecentList()
        {//try to load file. If file isn't found, do nothing
            _RecentFileList.Clear();
            try
            {
                //read file stream
                StreamReader listToRead =
              new StreamReader(System.Environment.CurrentDirectory + "\\Recent.txt");
                string line;
                while ((line = listToRead.ReadLine()) != null) //read each line until end of file
                    _RecentFileList.Enqueue(line); //insert to list
                listToRead.Close(); //close the stream
            }
            catch (Exception) { }
        }

        private void RecentFile_click(object sender, EventArgs e)
        {
            ToolStripMenuItem item = (ToolStripMenuItem)sender;
            string fileName = item.Tag.ToString();

            doOpen(fileName);
        }

        private void Main_Load(object sender, EventArgs e)
        {
            LoadRecentList(); 
            foreach (string item in _RecentFileList)
            {
                AddRecentFile(item);
            }
        }
        #endregion

        #region Output Report
        private void loadAnOutputReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hanleOpenOutputReportRequest();
        }

        private void hanleOpenOutputReportRequest()
        {
            string fileName = "";

            this.openFileDialog1.Filter = "XML Files|*.xml";
            if (this.openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                fileName = openFileDialog1.FileName;

                try
                {
                    doOpenOutputReport(fileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "The specified file is not valid for the output data.", "Error");
                }
            }
        }

        private void doOpenOutputReport(string fileName)
        {
            VMS.IFS.DataModel.OutputData.OutputDataSet ods = new DataModel.OutputData.OutputDataSet();
            ods.ReadXml(fileName, XmlReadMode.InferSchema);

            Dictionary<string, object> runOptions = new Dictionary<string, object>();
            foreach (VMS.IFS.DataModel.OutputData.OutputDataSet.RunOptionsRow row in ods.RunOptions.Rows)
            {
                runOptions.Add(row.Name, row.Value);
            }

            OutputViewer viewer = new OutputViewer(ods, runOptions);
            viewer.Build();
            viewer.Show();
        }

        #endregion

        private void equipmentDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InputEditor ieForm = getCurrentNewInputEditor(); 
            if (ieForm == null) 
                return;

            if (ieForm.InputData == null)
                return;

            QueryEQPData dialog = new QueryEQPData(ieForm.InputData);
            dialog.Show();
        }

        private void loadableSetDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InputEditor ieForm = getCurrentNewInputEditor();
            if (ieForm == null)
                return;

            if (ieForm.InputData == null)
                return;

            QueryLoadableSetData dialog = new QueryLoadableSetData(ieForm.InputData);
            dialog.Show();
        }

        private void productDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InputEditor ieForm = getCurrentNewInputEditor();
            if (ieForm == null)
                return;

            if (ieForm.InputData == null)
                return;

            QueryProductData dialog = new QueryProductData(ieForm.InputData);
            dialog.Show();
        }

        private void stockerDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InputEditor ieForm = getCurrentNewInputEditor();
            if (ieForm == null)
                return;

            if (ieForm.InputData == null)
                return;

            QueryStockerData dialog = new QueryStockerData(ieForm.InputData);
            dialog.Show();
        }

        private void networkDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InputEditor ieForm = getCurrentNewInputEditor();
            if (ieForm == null)
                return;

            if (ieForm.InputData == null)
                return;

            QueryNetworkData dialog = new QueryNetworkData(ieForm.InputData);
            dialog.Show();
        }
    }
}
