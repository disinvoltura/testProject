﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VMS.IFS.DataModel.DispatchingRuleData;

namespace VMS.IFS.UI
{
    public partial class DispatchingRuleFactorEditor : Form
    {
        #region Member Variables
        private FactorExpressionTypeMap _ExprTypeMap;
        private DRFactor _Factor;
        #endregion

        #region Properties
        public DRFactor Factor
        {
            get { return _Factor; }
        }
        #endregion

        #region Constructors
        public DispatchingRuleFactorEditor()
        {
            InitializeComponent();

            loadFactorExprTypeMap();
            showFactorExprTypeMap();
        }

        public DispatchingRuleFactorEditor(DRFactor f)
            : this()
        {
            txtName.Text = f.Name;
            txtDesc.Text = f.Description;
            txtExpr.Text = f.Expression;
        }

        #endregion

        #region Methods
        private void loadFactorExprTypeMap()
        {
            _ExprTypeMap = new FactorExpressionTypeMap();

            //Cassette
            string categoryCst = "Cassette-related Variables";
            _ExprTypeMap.Add(categoryCst, "Cassette.ID", "Cassette ID");
            _ExprTypeMap.Add(categoryCst, "Cassette.RBID", "Release Batch ID of a Cassette");
            _ExprTypeMap.Add(categoryCst, "Cassette.J", "Product ID of a Cassette");
            _ExprTypeMap.Add(categoryCst, "Cassette.P", "Processing Step ID of a Cassette");
            _ExprTypeMap.Add(categoryCst, "Cassette.N", "Processing Step ID of a Cassette");
            _ExprTypeMap.Add(categoryCst, "Cassette.C", "Equipment ID where the cassette stays");
            _ExprTypeMap.Add(categoryCst, "Cassette.D", "Equipment ID for the next Processing Step ID");
            _ExprTypeMap.Add(categoryCst, "Cassette.DueDate", "Due date to finish (in seconds)");
            _ExprTypeMap.Add(categoryCst, "Cassette.ReleaseDate", "Release date (in seconds)");
            _ExprTypeMap.Add(categoryCst, "Cassette.ArrivalDate", "Arrivla date and time to the queue of an equipment where the cassette stays (in seconds)");

            //Machine
            string categoryEQP = "Machine-related Variables";
            _ExprTypeMap.Add(categoryEQP, "Machine.ID", "Machine ID");
            _ExprTypeMap.Add(categoryEQP, "Machine.JT", "Product ID of Lastly Processed Cassette at the Machine");
            _ExprTypeMap.Add(categoryEQP, "Machine.Q", "Number of Cassettes at the Machine's Buffer");
            _ExprTypeMap.Add(categoryEQP, "Machine.M", "Number of Cassettes moving to the Machine");
            _ExprTypeMap.Add(categoryEQP, "Machine.N", "Number of Cassettes at the Input Port of the Machine");
            _ExprTypeMap.Add(categoryEQP, "Machine.NC", "Number of Processed Cassettes at the Machine");
            _ExprTypeMap.Add(categoryEQP, "Machine.SC", "Number of Occurrence of Setup at the Machine");

            //Functions
            string categoryFunc = "Time-related Functions";
            _ExprTypeMap.Add(categoryFunc, "PT", "Cassette, Machine", "Time for processing given cassette at the specified machine");
            _ExprTypeMap.Add(categoryFunc, "PTT", "Cassette, Machine", "Time to transport a given cassette to the specified machine");
            _ExprTypeMap.Add(categoryFunc, "RPT", "Cassette", "Time to finish the remaining process steps of a given cassette");

            string categoryETC = "Etc Variables";
            _ExprTypeMap.Add(categoryETC, "CLK", "Current Simulation Time");
        }

        private void showFactorExprTypeMap()
        {
            tvExprType.Nodes.Clear();

            foreach (string category in _ExprTypeMap.Categories)
            {
                TreeNode topNode = new TreeNode(category);

                IEnumerable<FactorExpressionTypeData> types = _ExprTypeMap[category];
                foreach (FactorExpressionTypeData exprType in types)
                {
                    TreeNode typeNode = new TreeNode(exprType.Name);
                    typeNode.ToolTipText = exprType.Description;
                    typeNode.Tag = exprType;

                    topNode.Nodes.Add(typeNode);
                }

                tvExprType.Nodes.Add(topNode);
            }
        }
        #endregion

        #region Event Handlers
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtName.Text) ||
                string.IsNullOrEmpty(txtExpr.Text))
                return;

            _Factor = new DRFactor(txtName.Text, txtDesc.Text, txtExpr.Text);

            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }
        #endregion

        #region Operator Event Handlers
        private void insertStringIntoExpr(string val)
        {
            int cursor = txtExpr.SelectionStart;
            txtExpr.Text = txtExpr.Text.Insert(cursor, val);
            txtExpr.Focus();
            txtExpr.SelectionStart = cursor + val.Length;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr("+");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr("-");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr("*");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr("/");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr("==");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr("<>");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr("<");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr(">");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr("<=");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            insertStringIntoExpr(">=");
        }
        #endregion

        private void tvExprType_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.Level == 0)
                return;

            if (e.Node.Tag != null)
            {
                FactorExpressionTypeData exprType = (FactorExpressionTypeData)e.Node.Tag;
                if (exprType.Type == FactorExpressionTypeKind.Property)
                    insertStringIntoExpr(exprType.Name);
                else if (exprType.Type == FactorExpressionTypeKind.Method)
                {
                    string sMethod = string.Format("{0}({1})", exprType.Name, exprType.Parameter);
                    insertStringIntoExpr(sMethod);
                }
            }
        }
    }

    
}
