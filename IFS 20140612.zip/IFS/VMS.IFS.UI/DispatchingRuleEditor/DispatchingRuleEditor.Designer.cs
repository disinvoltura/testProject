﻿namespace VMS.IFS.UI
{
    partial class DispatchingRuleEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DispatchingRuleEditor));
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtDesc = new System.Windows.Forms.TextBox();
            this.cbType = new System.Windows.Forms.ComboBox();
            this.gParameters = new SourceGrid.Grid();
            this.btnParamAdd = new System.Windows.Forms.Button();
            this.btnParamDelete = new System.Windows.Forms.Button();
            this.rbMinPriority = new System.Windows.Forms.RadioButton();
            this.rbMaxPriority = new System.Windows.Forms.RadioButton();
            this.gFactors = new SourceGrid.Grid();
            this.btnFactorDelete = new System.Windows.Forms.Button();
            this.btnFactorAdd = new System.Windows.Forms.Button();
            this.line1 = new DevAge.Windows.Forms.Line();
            this.txtPriorityFunc = new System.Windows.Forms.RichTextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnFactorEdit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnOK
            // 
            this.btnOK.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOK.Location = new System.Drawing.Point(513, 346);
            this.btnOK.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 32);
            this.btnOK.TabIndex = 0;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(607, 346);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 32);
            this.btnCancel.TabIndex = 0;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Type:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(17, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Description:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Weights:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(17, 274);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Selection Criteria:";
            this.label5.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(332, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(107, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "Available Factors:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(332, 182);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(214, 17);
            this.label7.TabIndex = 5;
            this.label7.Text = "Priority Function (Cassette, Machine)";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(76, 14);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(231, 23);
            this.txtName.TabIndex = 6;
            // 
            // txtDesc
            // 
            this.txtDesc.Location = new System.Drawing.Point(53, 101);
            this.txtDesc.Multiline = true;
            this.txtDesc.Name = "txtDesc";
            this.txtDesc.Size = new System.Drawing.Size(254, 47);
            this.txtDesc.TabIndex = 6;
            // 
            // cbType
            // 
            this.cbType.FormattingEnabled = true;
            this.cbType.Items.AddRange(new object[] {
            "Job Selection Rule",
            "Machine Selection Rule"});
            this.cbType.Location = new System.Drawing.Point(76, 48);
            this.cbType.Name = "cbType";
            this.cbType.Size = new System.Drawing.Size(231, 23);
            this.cbType.TabIndex = 7;
            this.cbType.Text = "Job Selection Rule";
            // 
            // gParameters
            // 
            this.gParameters.BackColor = System.Drawing.Color.White;
            this.gParameters.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gParameters.EnableSort = true;
            this.gParameters.Location = new System.Drawing.Point(53, 182);
            this.gParameters.Name = "gParameters";
            this.gParameters.OptimizeMode = SourceGrid.CellOptimizeMode.ForRows;
            this.gParameters.SelectionMode = SourceGrid.GridSelectionMode.Cell;
            this.gParameters.Size = new System.Drawing.Size(254, 136);
            this.gParameters.TabIndex = 8;
            this.gParameters.TabStop = true;
            this.gParameters.ToolTipText = "";
            // 
            // btnParamAdd
            // 
            this.btnParamAdd.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnParamAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnParamAdd.Image")));
            this.btnParamAdd.Location = new System.Drawing.Point(247, 154);
            this.btnParamAdd.Margin = new System.Windows.Forms.Padding(2);
            this.btnParamAdd.Name = "btnParamAdd";
            this.btnParamAdd.Size = new System.Drawing.Size(28, 24);
            this.btnParamAdd.TabIndex = 9;
            this.btnParamAdd.UseVisualStyleBackColor = true;
            this.btnParamAdd.Click += new System.EventHandler(this.btnParamAdd_Click);
            // 
            // btnParamDelete
            // 
            this.btnParamDelete.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnParamDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnParamDelete.Image")));
            this.btnParamDelete.Location = new System.Drawing.Point(279, 154);
            this.btnParamDelete.Margin = new System.Windows.Forms.Padding(2);
            this.btnParamDelete.Name = "btnParamDelete";
            this.btnParamDelete.Size = new System.Drawing.Size(28, 24);
            this.btnParamDelete.TabIndex = 9;
            this.btnParamDelete.Text = "−";
            this.btnParamDelete.UseVisualStyleBackColor = true;
            this.btnParamDelete.Click += new System.EventHandler(this.btnParamDelete_Click);
            // 
            // rbMinPriority
            // 
            this.rbMinPriority.AutoSize = true;
            this.rbMinPriority.Checked = true;
            this.rbMinPriority.Location = new System.Drawing.Point(136, 274);
            this.rbMinPriority.Name = "rbMinPriority";
            this.rbMinPriority.Size = new System.Drawing.Size(164, 19);
            this.rbMinPriority.TabIndex = 10;
            this.rbMinPriority.TabStop = true;
            this.rbMinPriority.Text = "Minimum-valued Priority";
            this.rbMinPriority.UseVisualStyleBackColor = true;
            this.rbMinPriority.Visible = false;
            // 
            // rbMaxPriority
            // 
            this.rbMaxPriority.AutoSize = true;
            this.rbMaxPriority.Location = new System.Drawing.Point(136, 299);
            this.rbMaxPriority.Name = "rbMaxPriority";
            this.rbMaxPriority.Size = new System.Drawing.Size(166, 19);
            this.rbMaxPriority.TabIndex = 11;
            this.rbMaxPriority.TabStop = true;
            this.rbMaxPriority.Text = "Maximum-valued Priority";
            this.rbMaxPriority.UseVisualStyleBackColor = true;
            this.rbMaxPriority.Visible = false;
            // 
            // gFactors
            // 
            this.gFactors.BackColor = System.Drawing.Color.White;
            this.gFactors.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gFactors.EnableSort = true;
            this.gFactors.Location = new System.Drawing.Point(357, 37);
            this.gFactors.Name = "gFactors";
            this.gFactors.OptimizeMode = SourceGrid.CellOptimizeMode.ForRows;
            this.gFactors.SelectionMode = SourceGrid.GridSelectionMode.Cell;
            this.gFactors.Size = new System.Drawing.Size(327, 99);
            this.gFactors.TabIndex = 9;
            this.gFactors.TabStop = true;
            this.gFactors.ToolTipText = "";
            // 
            // btnFactorDelete
            // 
            this.btnFactorDelete.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFactorDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnFactorDelete.Image")));
            this.btnFactorDelete.Location = new System.Drawing.Point(656, 8);
            this.btnFactorDelete.Margin = new System.Windows.Forms.Padding(2);
            this.btnFactorDelete.Name = "btnFactorDelete";
            this.btnFactorDelete.Size = new System.Drawing.Size(28, 24);
            this.btnFactorDelete.TabIndex = 13;
            this.btnFactorDelete.UseVisualStyleBackColor = true;
            this.btnFactorDelete.Click += new System.EventHandler(this.btnFactorDelete_Click);
            // 
            // btnFactorAdd
            // 
            this.btnFactorAdd.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFactorAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnFactorAdd.Image")));
            this.btnFactorAdd.Location = new System.Drawing.Point(593, 8);
            this.btnFactorAdd.Margin = new System.Windows.Forms.Padding(2);
            this.btnFactorAdd.Name = "btnFactorAdd";
            this.btnFactorAdd.Size = new System.Drawing.Size(28, 24);
            this.btnFactorAdd.TabIndex = 12;
            this.btnFactorAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnFactorAdd.UseVisualStyleBackColor = true;
            this.btnFactorAdd.Click += new System.EventHandler(this.btnFactorAdd_Click);
            // 
            // line1
            // 
            this.line1.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.line1.FirstColor = System.Drawing.SystemColors.ControlDark;
            this.line1.LineStyle = DevAge.Windows.Forms.LineStyle.Horizontal;
            this.line1.Location = new System.Drawing.Point(22, 337);
            this.line1.Name = "line1";
            this.line1.SecondColor = System.Drawing.SystemColors.ControlLightLight;
            this.line1.Size = new System.Drawing.Size(660, 2);
            this.line1.TabIndex = 15;
            this.line1.TabStop = false;
            // 
            // txtPriorityFunc
            // 
            this.txtPriorityFunc.Location = new System.Drawing.Point(357, 203);
            this.txtPriorityFunc.Name = "txtPriorityFunc";
            this.txtPriorityFunc.Size = new System.Drawing.Size(327, 115);
            this.txtPriorityFunc.TabIndex = 16;
            this.txtPriorityFunc.Text = "";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(654, 149);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(28, 23);
            this.button9.TabIndex = 36;
            this.button9.Text = ">=";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(622, 149);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(28, 23);
            this.button10.TabIndex = 35;
            this.button10.Text = "<=";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(589, 149);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(28, 23);
            this.button5.TabIndex = 34;
            this.button5.Text = ">";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(557, 149);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(28, 23);
            this.button6.TabIndex = 33;
            this.button6.Text = "<";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(525, 149);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(28, 23);
            this.button7.TabIndex = 32;
            this.button7.Text = "<>";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(493, 149);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(28, 23);
            this.button8.TabIndex = 31;
            this.button8.Text = "==";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(453, 149);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(28, 23);
            this.button4.TabIndex = 30;
            this.button4.Text = "/";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(421, 149);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(28, 23);
            this.button3.TabIndex = 29;
            this.button3.Text = "*";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(389, 149);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(28, 23);
            this.button2.TabIndex = 28;
            this.button2.Text = "−";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(357, 149);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(28, 23);
            this.button1.TabIndex = 27;
            this.button1.Text = "+";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnFactorEdit
            // 
            this.btnFactorEdit.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFactorEdit.Image = ((System.Drawing.Image)(resources.GetObject("btnFactorEdit.Image")));
            this.btnFactorEdit.Location = new System.Drawing.Point(625, 8);
            this.btnFactorEdit.Margin = new System.Windows.Forms.Padding(2);
            this.btnFactorEdit.Name = "btnFactorEdit";
            this.btnFactorEdit.Size = new System.Drawing.Size(28, 24);
            this.btnFactorEdit.TabIndex = 37;
            this.btnFactorEdit.UseVisualStyleBackColor = true;
            this.btnFactorEdit.Click += new System.EventHandler(this.btnFactorEdit_Click);
            // 
            // DispatchingRuleEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(701, 387);
            this.Controls.Add(this.btnFactorEdit);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtPriorityFunc);
            this.Controls.Add(this.line1);
            this.Controls.Add(this.btnFactorDelete);
            this.Controls.Add(this.btnFactorAdd);
            this.Controls.Add(this.gFactors);
            this.Controls.Add(this.rbMaxPriority);
            this.Controls.Add(this.rbMinPriority);
            this.Controls.Add(this.btnParamDelete);
            this.Controls.Add(this.btnParamAdd);
            this.Controls.Add(this.gParameters);
            this.Controls.Add(this.cbType);
            this.Controls.Add(this.txtDesc);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DispatchingRuleEditor";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Dispatching Rule Editor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtDesc;
        private System.Windows.Forms.ComboBox cbType;
        private SourceGrid.Grid gParameters;
        private System.Windows.Forms.Button btnParamAdd;
        private System.Windows.Forms.Button btnParamDelete;
        private System.Windows.Forms.RadioButton rbMinPriority;
        private System.Windows.Forms.RadioButton rbMaxPriority;
        private SourceGrid.Grid gFactors;
        private System.Windows.Forms.Button btnFactorDelete;
        private System.Windows.Forms.Button btnFactorAdd;
        private DevAge.Windows.Forms.Line line1;
        private System.Windows.Forms.RichTextBox txtPriorityFunc;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnFactorEdit;
    }
}