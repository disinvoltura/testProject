﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using VMS.IFS.DataModel.DispatchingRuleData;

namespace VMS.IFS.UI
{
    public partial class DispatchingRuleManager : Form
    {
        private Dictionary<string, DispatchingRuleDefinition> _DRList;
        private DispatchingRuleSet _DRDataSet;
        private string _FileName;
        private string _IFSDataPath;//path to the folder that stores the IFS data
        private int drid = 1;
        private int factorid = 1;
        private int parameterid = 1;

        public DispatchingRuleManager()
        {
            InitializeComponent();

            _IFSDataPath = System.Windows.Forms.Application.UserAppDataPath ;
            try
            {
                if (!Directory.Exists(_IFSDataPath))
                    Directory.CreateDirectory(_IFSDataPath);
            }
            catch (Exception ex)
            {
            }

            _FileName = _IFSDataPath + "\\DispatchingRuleSet.xml";
            loadDispatchingRuleSet();

            ShowDispatchingRuleSet();
        }

        private void loadDispatchingRuleSet()
        {
            _DRList = new Dictionary<string, DispatchingRuleDefinition>();    

            _DRDataSet = new DispatchingRuleSet();
            try
            {
                _DRDataSet.ReadXml(_FileName);
            }catch(Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
            }

            if (_DRDataSet == null)
                _DRDataSet = new DispatchingRuleSet();

            foreach (DispatchingRuleSet.DispatchingRuleRow row in _DRDataSet.DispatchingRule.Rows)
            {
                int drid = row.ID;
                if (drid == -1)
                    drid = 1;

                string drName = row.Name;
                DispatchingRuleType drType = (DispatchingRuleType)Enum.Parse(typeof(DispatchingRuleType), row.Type);

                DispatchingRuleDefinition dr = new DispatchingRuleDefinition(drName, drType);
                dr.Description = row.Description;
                dr.SelectionOrder = (SelectionCriteriaType)Enum.Parse(typeof(SelectionCriteriaType), row.SelectionOrder);
                dr.PriorityFunction = row.PriorityFunction;

                DataRow[] parameters = _DRDataSet.Parameter.Select("DRID=" + drid);
                foreach (DispatchingRuleSet.ParameterRow rowParam in parameters)
                {
                    string pName = rowParam.Name;
                    DRParameterType pType = (DRParameterType)Enum.Parse(typeof(DRParameterType), rowParam.Type);
                    string pDesc = rowParam.Description;

                    dr.AddParameter(pName, pType, pDesc);
                }

                DataRow[] factors = _DRDataSet.Factor.Select("DRID=" + drid);
                foreach (DispatchingRuleSet.FactorRow rowFactor in factors)
                {
                    string fName = rowFactor.Name;
                    string fDesc = rowFactor.Description;
                    string fExpr = rowFactor.Expression;

                    dr.AddFactor(fName, fDesc, fExpr);
                }

                _DRList.Add(dr.Name, dr);
            }
        }

        private void ShowDispatchingRuleSet()
        {
            lvDRSet.Items.Clear();

            foreach (string name in _DRList.Keys)
            {
                DispatchingRuleDefinition dr = _DRList[name];

                ListViewItem item = new ListViewItem(dr.Name);
                item.SubItems.Add(dr.Type.ToString());
                item.SubItems.Add(dr.Description);

                lvDRSet.Items.Add(item);
            }
        }

        private void saveDispatchingRuleSet()
        {
            drid = 1;
            factorid = 1;
            parameterid = 1;

            _DRDataSet = new DispatchingRuleSet();

            foreach (string name in _DRList.Keys)
            {
                DispatchingRuleDefinition dr = _DRList[name];

                saveDispatchingRule(dr);
            }

            try
            {
                _DRDataSet.WriteXml(_FileName);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
            }
        }

        private void saveDispatchingRule(DispatchingRuleDefinition dr)
        {
            DispatchingRuleSet.DispatchingRuleRow row = _DRDataSet.DispatchingRule.NewDispatchingRuleRow();
            row.ID = drid;
            row.Name = dr.Name;
            row.Description = dr.Description;
            row.Type = dr.Type.ToString();
            row.SelectionOrder = dr.SelectionOrder.ToString();
            row.PriorityFunction = dr.PriorityFunction;

            foreach (DRParameter p in dr.Parameters)
            {
                DispatchingRuleSet.ParameterRow rowParam = _DRDataSet.Parameter.NewParameterRow();
                rowParam.ID = parameterid++;
                rowParam.DRID = drid;
                rowParam.Name = p.Name;
                rowParam.Type = p.Type.ToString(); 
                rowParam.Description = p.Description;
                _DRDataSet.Parameter.Rows.Add(rowParam);
            }

            foreach (DRFactor f in dr.Factors)
            {
                DispatchingRuleSet.FactorRow rowFactor = _DRDataSet.Factor.NewFactorRow();
                rowFactor.ID = factorid++;
                rowFactor.DRID = drid;
                rowFactor.Name = f.Name;
                rowFactor.Description = f.Description;
                rowFactor.Expression = f.Expression;

                _DRDataSet.Factor.Rows.Add(rowFactor);                    
            }

            _DRDataSet.DispatchingRule.Rows.Add(row);
            drid++;
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            DispatchingRuleEditor dialog = new DispatchingRuleEditor();

            DialogResult rslt = dialog.ShowDialog();

            if (rslt == System.Windows.Forms.DialogResult.OK)
            {
                DispatchingRuleDefinition dr = dialog.DispatchingRule;

                if (!_DRList.ContainsKey(dr.Name))
                {
                    _DRList.Add(dr.Name, dr);

                    saveDispatchingRuleSet();
                    ShowDispatchingRuleSet();
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (lvDRSet.SelectedItems.Count == 0)
                return;

            ListViewItem item = lvDRSet.SelectedItems[0];
            string drName = item.Text;

            if (_DRList.ContainsKey(drName))
            {
                DispatchingRuleDefinition dr = _DRList[drName];

                DispatchingRuleEditor dialog = new DispatchingRuleEditor(dr);
                DialogResult rslt = dialog.ShowDialog();

                if (rslt == System.Windows.Forms.DialogResult.OK)
                {
                    _DRList.Remove(drName);
                    DispatchingRuleDefinition newDR = dialog.DispatchingRule;
                    _DRList.Add(newDR.Name, newDR);

                    saveDispatchingRuleSet();
                    ShowDispatchingRuleSet();
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (lvDRSet.SelectedItems.Count == 0)
                return;

            ListViewItem item = lvDRSet.SelectedItems[0];

            if (_DRList.ContainsKey(item.Text))
            {
                _DRList.Remove(item.Text);

                saveDispatchingRuleSet();
            }
        }

        private void btnCode_Click(object sender, EventArgs e)
        {
            if (lvDRSet.SelectedItems.Count == 0)
                return;

            ListViewItem item = lvDRSet.SelectedItems[0];
            string drName = item.Text;

            if (_DRList.ContainsKey(drName))
            {
                DispatchingRuleDefinition dr = _DRList[drName];

                CodeViewer dialog = new CodeViewer(dr);
                dialog.Show();
            }
        }
    }
}
