﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using VMS.IFS.DataModel.DispatchingRuleData;

namespace VMS.IFS.UI
{
    public partial class DispatchingRuleSelector : Form
    {
        #region Member Variables
        private Dictionary<string, DispatchingRuleDefinition> _DRList;
        private DispatchingRuleSet _DRDataSet;
        private string _FileName;
        private string _IFSDataPath;//path to the folder that stores the IFS data

        private DispatchingRuleDefinition _SelectedDispatchingRule;
        #endregion

        #region Properties
        public DispatchingRuleDefinition SelectedDispatchingRule
        {
            get { return _SelectedDispatchingRule; }
        }
        #endregion

        #region Constructors
        public DispatchingRuleSelector(DispatchingRuleType type)
        {
            InitializeComponent();

            _IFSDataPath = System.Windows.Forms.Application.UserAppDataPath ;
            try
            {
                if (!Directory.Exists(_IFSDataPath))
                    Directory.CreateDirectory(_IFSDataPath);
            }
            catch (Exception ex)
            {
            }

            _FileName = _IFSDataPath + "\\DispatchingRuleSet.xml";

            loadDispatchingRuleSet();

            ShowDispatchingRuleSet(type);
        }
        #endregion

        #region Load Methods
        private void loadDispatchingRuleSet()
        {
            _DRList = new Dictionary<string, DispatchingRuleDefinition>();    

            _DRDataSet = new DispatchingRuleSet();
            try
            {
                _DRDataSet.ReadXml(_FileName);
            }catch(Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
            }

            if (_DRDataSet == null)
                _DRDataSet = new DispatchingRuleSet();

            foreach (DispatchingRuleSet.DispatchingRuleRow row in _DRDataSet.DispatchingRule.Rows)
            {
                int drid = row.ID;
                if (drid == -1)
                    drid = 1;

                string drName = row.Name;
                DispatchingRuleType drType = (DispatchingRuleType)Enum.Parse(typeof(DispatchingRuleType), row.Type);

                DispatchingRuleDefinition dr = new DispatchingRuleDefinition(drName, drType);
                dr.Description = row.Description;
                dr.SelectionOrder = (SelectionCriteriaType)Enum.Parse(typeof(SelectionCriteriaType), row.SelectionOrder);
                dr.PriorityFunction = row.PriorityFunction;

                DataRow[] parameters = _DRDataSet.Parameter.Select("DRID=" + drid);
                foreach (DispatchingRuleSet.ParameterRow rowParam in parameters)
                {
                    string pName = rowParam.Name;
                    DRParameterType pType = (DRParameterType)Enum.Parse(typeof(DRParameterType), rowParam.Type);
                    string pDesc = rowParam.Description;

                    dr.AddParameter(pName, pType, pDesc);
                }

                DataRow[] factors = _DRDataSet.Factor.Select("DRID=" + drid);
                foreach (DispatchingRuleSet.FactorRow rowFactor in factors)
                {
                    string fName = rowFactor.Name;
                    string fDesc = rowFactor.Description;
                    string fExpr = rowFactor.Expression;

                    dr.AddFactor(fName, fDesc, fExpr);
                }

                _DRList.Add(dr.Name, dr);
            }
        }

        private void ShowDispatchingRuleSet(DispatchingRuleType type)
        {
            lvDRSet.Items.Clear();

            foreach (string name in _DRList.Keys)
            {
                DispatchingRuleDefinition dr = _DRList[name];
                if (dr.Type == type)
                {
                    ListViewItem item = new ListViewItem(dr.Name);
                    item.SubItems.Add(dr.Type.ToString());
                    item.SubItems.Add(dr.Description);
                    item.Tag = dr;

                    lvDRSet.Items.Add(item);
                }
            }
        }
        #endregion

        #region Button Event Handlers
        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (lvDRSet.SelectedItems.Count == 0)
                return;

            ListViewItem item = lvDRSet.SelectedItems[0];

            _SelectedDispatchingRule = (DispatchingRuleDefinition)item.Tag;

            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }
        #endregion

    }
}
