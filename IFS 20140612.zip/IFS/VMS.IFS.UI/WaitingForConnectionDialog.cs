﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Threading;
using System.Text;
using System.Windows.Forms;
using VMS.IFS.Engine;
using VMS.IFS.Engine.ApplicationConnection;

namespace VMS.IFS.UI
{
    public partial class WaitingForConnectionDialog : Form
    {
        public WaitingForConnectionDialog()
        {
            InitializeComponent();

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }

        private void WaitingForConnectionDialog_Load(object sender, EventArgs e)
        {
            doLoad();
        }

        private void doLoad()
        {
            ApplicationConnector.ClientConnected += 
                new ClientConnectedEventHandler(ApplicationConnector_ClientConnected);

            Thread thread = new Thread(new ThreadStart(doStart));
            thread.Start();
            
        }

        private void doStart()
        {
            ApplicationConnector.Accept();
        }

        private void ApplicationConnector_ClientConnected()
        {
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }
    }
}
