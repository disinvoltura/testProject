﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using OfficeOpenXml;
using VMS.IFS.DataModel.InputData;
using WeifenLuo.WinFormsUI.Docking;
using VMS.Foundation.Logging;
using System.Threading;
using System.Threading.Tasks;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.DataModel.OutputData;
using VMS.IFS.Simulation;

namespace VMS.IFS.UI
{
    public partial class InputEditor : Form
    {
        #region Member Variables
        public InputDataSet _InputData;
        public Dictionary<string, bool> _IsModified;
        private bool _IsNew;
        public string _FileName;        
        
        private Dictionary<string, TableEditor> _TableEditors;
        private ModelExplorer _ModelExplorer;
        private ErrorWindow _ErrorList;
        private OutputWindow _Output;
        private SimulationRunWindow _SimulationRuns;

        private string[] _SheetNames;
        private Dictionary<string, string> _SheetToTableMapping;
        public Dictionary<string, string> _TableToSheetMapping;
        public Dictionary<string, object> RunOptions;

        private InputDataChecker _Checker;

        private bool _CatchEvent = false;
        private int _CntEvent = 1;
        #endregion

        #region Properties
        public bool HasErrors
        {
            get {
                DataRow[] rows = _Checker.Errors.Select("Type='Error'");
                if (rows != null)
                    return (rows.Length>0 ? true : false);
                else
                    return false;
            }
        }

        public bool IsNew
        {
            get { return _IsNew; }
        }

        public InputDataSet InputData
        {
            get { return _InputData; }
        }

        public TableEditor TableEditor(string name)
        {
            return _TableEditors[name];
        }

        #endregion

        #region Constructors
        public InputEditor(string fileName)
        {
            _FileName = fileName;

            InitializeComponent();

            initialize();

            if (_FileName == "")
                _IsNew = true;
            else
                _IsNew = false;

            open(); 
        }

        private void initialize()
        {
            //1. Sheet to Table, Table to Sheet Mapping
            _SheetNames = new string[] { "Equipment", "EQP_Port", "Product", "BOP", "Loadable Set", "Processing Time", "Fabout Plan", "Inline Stocker", "Conveyor", "MCS Weight Set", "WhereNextSTK" };
            _SheetToTableMapping = new Dictionary<string, string>();
            _TableToSheetMapping = new Dictionary<string, string>();
            _IsModified = new Dictionary<string, bool>();

            AddMappingRelation("Equipment", "EquipmentDataTable");
            AddMappingRelation("EQP_Port", "EQP_PortDataTable");
            AddMappingRelation("Product", "ProductDataTable");
            AddMappingRelation("BOP", "BOPDataTable");
            AddMappingRelation("Loadable Set", "LoadableSetDataTable");
            AddMappingRelation("Processing Time", "ProcessingTimeDataTable");
            AddMappingRelation("Fabout Plan", "FabOutPlanDataTable");
            AddMappingRelation("Inline Stocker", "InlineStockerDataTable");
            AddMappingRelation("Conveyor", "ConveyorDataTable");
            AddMappingRelation("MCS Weight Set", "MCSWeightSetDataTable");
            AddMappingRelation("WhereNextSTK", "WhereNextSTKDataTable");

            //2. Windows
            _TableEditors = new Dictionary<string, TableEditor>();
            _ModelExplorer = new ModelExplorer(this);
            _ModelExplorer.TableSelected += new InputDataTableSelectedEventHandler(OnModelExplorer_TableSelected);
            _ErrorList = new ErrorWindow(this);
            _Output = new OutputWindow(this);
            _SimulationRuns = new SimulationRunWindow(this);

            //3. Input Data Checker
            _Checker = new InputDataChecker();
        }

        private void AddMappingRelation(string sheetName, string tableName)
        {
            _SheetToTableMapping.Add(sheetName, tableName);
            _TableToSheetMapping.Add(tableName, sheetName);
            _IsModified.Add(sheetName, false);
        }
        #endregion

        #region Open and Save Operation Methods
        private void open()
        {
            _InputData = new InputDataSet();

            if (!string.IsNullOrEmpty(_FileName))
            {
                //treeView1.Nodes[0].Text = this.fileName;

                string conStr = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + _FileName + ";Extended Properties=" + '"' + "Excel 12.0;HDR=YES;" + '"';
                OleDbConnection excelConnection = new OleDbConnection(conStr);

                OleDbDataAdapter da = new OleDbDataAdapter();
                excelConnection.Open();

                foreach (string sheetName in _SheetNames)
                {
                    if (!_SheetToTableMapping.ContainsKey(sheetName))
                        continue;

                    OleDbCommand cmd = new OleDbCommand("SELECT * FROM [" + sheetName + "$]", excelConnection);

                    da.SelectCommand = cmd;

                    DataTable table = _InputData.Tables[_SheetToTableMapping[sheetName]];
                    try
                    {
                        da.Fill(table);
                    }
                    catch (OleDbException e)
                    {
                        
                    }

                    //if (sheetName.Equals("WIP"))
                    //{
                    //    BuildWipTable(_InputData);
                    //}

                    TableEditor tEditor = new TableEditor(this);
                    tEditor.LoadData(table.DefaultView);
                    tEditor.Text = sheetName;

                    dockPanel1.ActiveDocumentChanged += new EventHandler(dockPanel1_ActiveDocumentChanged);
                    
                    _TableEditors.Add(sheetName, tEditor);

                    _ModelExplorer.Add("InputData", sheetName);
                }

                excelConnection.Close();
                excelConnection.Dispose();

                //Save("Save");                
            }
            else
            {
                foreach (string sheetName in _SheetNames)
                {
                    if (!_SheetToTableMapping.ContainsKey(sheetName))
                        continue;

                    DataTable table = _InputData.Tables[_SheetToTableMapping[sheetName]];

                    TableEditor tEditor = new TableEditor(this);
                    tEditor.LoadData(table.DefaultView);
                    tEditor.Text = sheetName;

                    _TableEditors.Add(sheetName, tEditor);
                    _ModelExplorer.Add("InputData", sheetName);
                }
            }

            createLayout();

            //Check Erros
            doCheckErrors();

            _CatchEvent = true;
        }

        void dockPanel1_ActiveDocumentChanged(object sender, EventArgs e)
        {
            if (_CatchEvent)
            {
                if (_CntEvent < dockPanel1.DocumentsCount)
                {
                    _CntEvent++;
                }
                else if (_CntEvent == dockPanel1.DocumentsCount)
                {
                    if (dockPanel1.ActiveDocument == null)
                        return;

                    if (dockPanel1.ActiveDocument.ToString().Contains("Fabout") && _IsModified["Product"])
                    {
                        BuildFabOutTable(_InputData);

                        _TableEditors["Fabout Plan"].LoadData(_InputData.FabOutPlanDataTable.DefaultView);
                    }
                    //else if (dockPanel1.ActiveDocument.ToString().Contains("WIP") && _IsModified["Equipment"])
                    //{
                    //    BuildWipTable(_InputData);

                    //    _TableEditors["WIP"].LoadData(_InputData.WIPDataTable.DefaultView);
                    //}
                    _CntEvent = 1;
                }
            }
        }

        private void BuildWipTable(InputDataSet ids)
        {
            List<string> eqpInEQPSheet = new List<string>();
            List<string> eqpInWIPSheet = new List<string>();
            bool isFabOut = false;
            InputDataSet.WIPDataTableRow faboutRow = ids.WIPDataTable.NewWIPDataTableRow();

            foreach (InputDataSet.EquipmentDataTableRow dr in ids.EquipmentDataTable.Rows)
            {
                if (!eqpInEQPSheet.Contains(dr.EQP_ID))
                    eqpInEQPSheet.Add(dr.EQP_ID);
            }
            foreach (InputDataSet.WIPDataTableRow dr in ids.WIPDataTable.Rows)
            {
                if (dr.EQP_ID == "FabOut")
                {
                    isFabOut = true;
                    continue;
                }
                eqpInWIPSheet.Add(dr.EQP_ID);
            }

            foreach (string eqp in eqpInEQPSheet)
            {
                if (!eqpInWIPSheet.Contains(eqp))
                {
                    DataRow dr = ids.WIPDataTable.NewRow();
                    dr["EQP_ID"] = eqp;
                    ids.WIPDataTable.Rows.Add(dr);
                }
                eqpInWIPSheet.Remove(eqp);
            }
            foreach (string eqp in eqpInWIPSheet)
            {
                foreach (InputDataSet.WIPDataTableRow dr in ids.WIPDataTable.Rows)
                {
                    if (eqp == dr["EQP_ID"].ToString())
                    {
                        ids.WIPDataTable.RemoveWIPDataTableRow(dr);
                        break;
                    }
                }
            }

            if (!isFabOut)
            {
                DataRow dr = ids.WIPDataTable.NewRow();
                dr["EQP_ID"] = "FabOut";
                ids.WIPDataTable.Rows.Add(dr);
            }
            else
            {
                foreach (InputDataSet.WIPDataTableRow dr in ids.WIPDataTable.Rows)
                {
                    if (dr.EQP_ID == "FabOut")
                    {
                        for (int i = 0; i < ids.WIPDataTable.Columns.Count; i++)
                        {
                            faboutRow[i] = dr[i];
                        }
                        ids.WIPDataTable.RemoveWIPDataTableRow(dr);
                        break;
                    }
                }
                ids.WIPDataTable.Rows.Add(faboutRow);
            }
        }

        private void BuildFabOutTable(InputDataSet ids)
        {
            List<string> eqpInProductSheet = new List<string>();
            List<string> eqpInFabOutSheet = new List<string>();
            bool isDate = false;

            foreach (InputDataSet.ProductDataTableRow dr in ids.ProductDataTable.Rows)
            {
                if (!eqpInProductSheet.Contains(dr.PROD_ID))
                    eqpInProductSheet.Add(dr.PROD_ID);
            }
            foreach (DataColumn dc in ids.FabOutPlanDataTable.Columns)
            {
                if (dc.ColumnName == "DATE")
                {
                    isDate = true;
                    continue;
                }
                eqpInFabOutSheet.Add(dc.ColumnName);
            }

            if (!isDate)
            {
                ids.FabOutPlanDataTable.Columns.Add("DATE", typeof(string));
            }
            foreach (string pID in eqpInProductSheet)
            {
                if (!eqpInFabOutSheet.Contains(pID))
                {
                    ids.FabOutPlanDataTable.Columns.Add(pID, typeof(string));
                }
                eqpInFabOutSheet.Remove(pID);
            }
            foreach (string pID in eqpInFabOutSheet)
            {
                foreach (DataColumn dc in ids.FabOutPlanDataTable.Columns)
                {
                    if (pID == dc.ColumnName)
                    {
                        ids.FabOutPlanDataTable.Columns.Remove(pID);
                        break;
                    }
                }
            }
        }

        public void CheckErrors()
        {
            doCheckErrors();
        }

        private void doCheckErrors()
        {
            _Checker.Check(_InputData);
            _ErrorList.LoadData(_Checker.Errors.DefaultView);
            _ErrorList.Show();
        }

        public void Save(string type) //type이 "Save"이면 저장, "SaveAs"면 다른 이름으로 저장
        {
            if (type == "SaveAs" || _IsNew)
            {
                this.saveFileDialog1.Filter = "Excel Files|*.xls;*.xlsx|All files|*.*";
                if (this.saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    _FileName = saveFileDialog1.FileName;
                    _IsNew = false;
                }
            }

            if (_FileName != "")
            {
                FileInfo file = new FileInfo(_FileName);
                if (file.Exists)
                {
                    try
                    {
                        file.Delete();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("The specified file is used by other process. Check the file is closed.");
                        return;
                    }

                    file = new FileInfo(_FileName);
                }
                ExcelPackage package = new ExcelPackage(file);

                foreach (DataTable dt in _InputData.Tables)
                {
                    if (dt.TableName == "WIPDataTable")
                        continue;
                    ExcelWorksheet worksheet = 
                        package.Workbook.Worksheets.Add(_TableToSheetMapping[dt.TableName]);
                    if(dt.Columns.Count > 0)
                        worksheet.Cells.LoadFromDataTable(dt, true);
                }

                package.Save();                
            }
        }        
                
        #endregion

        #region Event Handling Methods
        private void NewInputEditor_FormClosing(object sender, FormClosingEventArgs e)
        {
            bool cancel = false;

            foreach (string key in _IsModified.Keys)
            {
                if (_IsModified[key])
                {
                    switch (MessageBox.Show(this, "Current input file is changed.\r\nSave changes?", "Save changes", MessageBoxButtons.YesNoCancel))
                    {
                        case DialogResult.Yes:
                            {
                                Save("Save");
                                return;
                            }
                        case DialogResult.No:
                            {
                                return;
                            }
                        case DialogResult.Cancel:
                            {
                                e.Cancel = true;
                                cancel = true;
                                break;
                            }
                    }
                }
                if (cancel)
                    break;
            }
        }

        public void OnModelExplorer_TableSelected(string name)
        {
            if (_TableEditors.ContainsKey(name))
            {
                if (name.Contains("Fab") && _IsModified["Product"])
                {                    
                    BuildFabOutTable(_InputData);

                    _TableEditors["Fabout Plan"].LoadData(_InputData.FabOutPlanDataTable.DefaultView);
                }
                else if (name.Contains("WIP") && _IsModified["Equipment"])
                {                   
                    BuildWipTable(_InputData);

                    _TableEditors["WIP"].LoadData(_InputData.WIPDataTable.DefaultView);
                }

                TableEditor editor = _TableEditors[name];
                editor.Show();
            }
        }
        #endregion

        #region Window Management Methods
        public void ResetLayout()
        {
            createLayout();

        }

        public void Float()
        {
            dockPanel1.ActiveContent.DockHandler.DockState = DockState.Float;
        }

        private void createLayout()
        {
            dockPanel1.Theme = new WeifenLuo.WinFormsUI.Docking.VS2012LightTheme(); ;

            _ModelExplorer.Show(dockPanel1, DockState.DockLeft);
            _ModelExplorer.DockHandler.CloseButtonVisible = false;
            _ModelExplorer.DockHandler.CloseButton = false;

            TableEditor firstEditor = _TableEditors[_SheetNames[0]];
            firstEditor.Show(dockPanel1, DockState.Document);
            firstEditor.DockHandler.CloseButtonVisible = false;
            firstEditor.DockHandler.CloseButton = false;

            _ErrorList.Show(dockPanel1, DockState.DockBottom);
            _ErrorList.DockHandler.CloseButtonVisible = false;
            _ErrorList.DockHandler.CloseButton = false;

            _Output.Show(dockPanel1, DockState.DockBottom);
            _Output.DockHandler.CloseButtonVisible = false;
            _Output.DockHandler.CloseButton = false;

            _SimulationRuns.Show(dockPanel1, DockState.DockBottom);
            _SimulationRuns.DockHandler.CloseButtonVisible = false;
            _SimulationRuns.DockHandler.CloseButton = false;

            for (int i = 1; i < _SheetNames.Length; i++)
            {
                string sheetName = _SheetNames[i];
                if (!_TableEditors.ContainsKey(sheetName))
                    continue;

                TableEditor editor = _TableEditors[sheetName];
                editor.Show(dockPanel1, DockState.Document);
                editor.DockHandler.CloseButtonVisible = false;
                editor.DockHandler.CloseButton = false;

            }
        }
        #endregion

        #region Simulation run
        
        private int _RunNo = 1;
        
        public void Run()
        {
            Logger logger = LogManager.GetLogger("SimulationCoordinator");

            logger.Info("Simulation Run is started.");

            Dictionary<string, object> runOptions = this.RunOptions;
            if (runOptions.ContainsKey(SimulationArguments.ConnectApplication))
                runOptions[SimulationArguments.ConnectApplication] = false;
            else
                runOptions.Add(SimulationArguments.ConnectApplication, false);

            if ((bool)runOptions[SimulationArguments.Logging])
            {
                this.ConnectAllLogHandlers();
            }
            else
            {
                this.ConnectGeneralLogHandler();
            }

            Dictionary<string, object> clonedRunOptions = new Dictionary<string, object>();
            foreach (string key in runOptions.Keys)
            {
                clonedRunOptions.Add(key, runOptions[key]);
            }

            string simRunID = "Simulation Run " + _RunNo++;
            DateTime startTime = DateTime.Now;
            SimulationProgress progressdialog = 
                new SimulationProgress(
                    simRunID, 
                    (InputDataSet)this.InputData.Copy(), 
                    clonedRunOptions);

            DialogResult rslt = progressdialog.ShowDialog(this);
            
            DateTime endTime = DateTime.Now;
            logger.Info("Simulation run is ended. I took " + endTime.Subtract(startTime).TotalSeconds +" seconds.");
            
            if (rslt == System.Windows.Forms.DialogResult.OK)
            {
                
                DialogResult mrslt = MessageBox.Show("Do you want to see the output report?", "Info", MessageBoxButtons.YesNo);

                if (mrslt != System.Windows.Forms.DialogResult.Yes)
                    progressdialog.OutputData.Dispose();

                GC.Collect();
                GC.WaitForFullGCComplete();

                if (mrslt == System.Windows.Forms.DialogResult.Yes)
                {
                    DateTime dt1 = DateTime.Now;
                    doShowOutputReport(simRunID, clonedRunOptions, progressdialog.OutputData, startTime, endTime);
                    DateTime dt2 = DateTime.Now;
                    //System.Diagnostics.Debug.WriteLine("[showOutput] It took " + dt2.Subtract(dt1).TotalSeconds + " seconds.");
                }
                else
                {
                    
                }
                progressdialog.Dispose();
                
            }
            else
            {
                if (progressdialog.OutputData != null)
                    progressdialog.OutputData.Dispose();
                progressdialog.Dispose();

            }
            
        }

        public void RunWithApplication()
        {
            Dictionary<string, object> runOptions = this.RunOptions;
            if (runOptions.ContainsKey(SimulationArguments.ConnectApplication))
                runOptions[SimulationArguments.ConnectApplication] = true;
            else
                runOptions.Add(SimulationArguments.ConnectApplication, true);

            if ((bool)runOptions[SimulationArguments.Logging])
            {
                this.ConnectAllLogHandlers();
            }

            Dictionary<string, object> clonedRunOptions = new Dictionary<string, object>();
            foreach (string key in runOptions.Keys)
            {
                clonedRunOptions.Add(key, runOptions[key]);
            }

            //Establish Server
            WaitingForConnectionDialog waitingDialog = new WaitingForConnectionDialog();
            DialogResult waitRslt = waitingDialog.ShowDialog(this);

            if (waitRslt == System.Windows.Forms.DialogResult.Cancel)
                return;

            string simRunID = "Simulation Run " + _RunNo++;
            DateTime startTime = DateTime.Now;
            using (InputDataSet ids = (InputDataSet)this.InputData.Copy())
            {
                SimulationProgressWithApplication progressdialog =
                    new SimulationProgressWithApplication(
                        simRunID,
                        ids,
                        clonedRunOptions);

                DialogResult rslt = progressdialog.ShowDialog(this);

                if (progressdialog.ShowResult)
                {
                    DateTime endTime = DateTime.Now;
                    DialogResult mrslt = MessageBox.Show("Do you want to see the output report?", "Info", MessageBoxButtons.YesNo);
                    if (mrslt == System.Windows.Forms.DialogResult.Yes)
                    {
                        DateTime dt1 = DateTime.Now;
                        doShowOutputReport(simRunID, clonedRunOptions, progressdialog.OutputData, startTime, endTime);
                        DateTime dt2 = DateTime.Now;
                        //System.Diagnostics.Debug.WriteLine("[showOutput] It took " + dt2.Subtract(dt1).TotalSeconds + " seconds.");
                    }
                    //_SimulationRuns.AddExperiment(
                    //    simRunID,
                    //    progressdialog.OutputData,
                    //    //(VMS.IFS.DataModel.OutputData.OutputDataSet)progressdialog.Runner.OutputData.Copy(),
                    //    clonedRunOptions, startTime, endTime);
                    //progressdialog.Dispose();
                }
                else
                {
                }
            }
        }

        private void doShowOutputReport(string id, Dictionary<string, object> runOptions, OutputDataSet ods, DateTime startTime, DateTime endTime)
        {
            OutputViewer viewer = new OutputViewer(ods, runOptions);

            using (OutputReportProgress progresDialog = new OutputReportProgress(viewer))
            {
                progresDialog.ShowDialog();
            }
            viewer.Show();

            _SimulationRuns.AddExperiment(
                    id,
                    viewer, startTime, endTime);
        }
        #endregion
        
        #region Methods
        public void DisconnectLogHandlers()
        {
            _Output.DisconnectLogHandlers();
        }

        public void ConnectAllLogHandlers()
        {
            _Output.ConnectAllLogHandlers();
        }

        public void ConnectGeneralLogHandler()
        {
            _Output.ConnectGeneralLogHandler();
        }

        public List<string> MakeLoadableSetVersionList()
        {
            List<string> lstLoadableSet = new List<string>();

            foreach (DataRow dr in _InputData.LoadableSetDataTable.Rows)
            {
                if (!lstLoadableSet.Contains(dr["VERSION_NO"].ToString()))
                {
                    lstLoadableSet.Add(dr["VERSION_NO"].ToString());
                }
            }

            return lstLoadableSet;
        }

        public void GoTo(string sheetName, int row, string columnName)
        {
            if (_TableEditors.ContainsKey(sheetName))
            {
                TableEditor editor = _TableEditors[sheetName];
                editor.Show();
                editor.GoTo(row, columnName);
            }
        }

        public void EnforceDispose()
        {
            _IsModified.Clear();

            string[] names = _TableEditors.Keys.ToArray<string>();
            for (int i = names.Length - 1; i > 0; i--)
            {
                _TableEditors[names[i]].Dispose();
                _TableEditors.Remove(names[i]);
            }

            _ModelExplorer.Dispose();
            _ErrorList.Dispose();
            _Output.Dispose();
            _SimulationRuns.EnforceDispose();
            _SimulationRuns.Dispose();

            _SheetToTableMapping.Clear();
            _TableToSheetMapping.Clear();
            RunOptions.Clear();

            this.InputData.Dispose();
        }
        #endregion

        public class InputEditorValueChangedEvent : SourceGrid.Cells.Controllers.ControllerBase
        {
            private InputEditor form;

            public InputEditorValueChangedEvent(InputEditor form)
            {
                this.form = form;
            }

            public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
            {
                base.OnValueChanging(sender, e);
            }

        }
    }
}
