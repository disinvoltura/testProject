﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace VMS.IFS.UI
{
    public delegate void ValueChangedEventHandler();

    public partial class TableEditor : DockContent 
    {
        public event ValueChangedEventHandler ValueChanged;

        private TableValueChangedEvent valueChangedController;
        private Dictionary<string, int> _ColumnNameToIndex;
        private InputEditor _Parent;

        public TableEditor(InputEditor parent)
        {
            _Parent = parent;

            InitializeComponent();
        }

        public void LoadData(DataView view)
        {
            _ColumnNameToIndex = new Dictionary<string, int>();
            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            if (view.Table.TableName.Equals("Equipment"))
            {
                SourceGrid.Cells.Editors.ComboBox eqpTypeCB = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
                string[] eqpTypes = new string[] { "U", "B", "V", "C" };
                eqpTypeCB.StandardValues = eqpTypes;
                eqpTypeCB.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;
                eqpTypeCB.Control.DropDownStyle = ComboBoxStyle.DropDownList;

                SourceGrid.Cells.Cell eqpTypeCell = new SourceGrid.Cells.Cell("", eqpTypeCB);
                eqpTypeCell.View = SourceGrid.Cells.Views.ComboBox.Default;
                eqpTypeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

                grid.Columns[1].DataCell = eqpTypeCell;
                
            }else if (view.Table.TableName.Equals("EQP_Port"))
            {
                SourceGrid.Cells.Editors.ComboBox portTypeCB = new SourceGrid.Cells.Editors.ComboBox(typeof(string));
                string[] portTypes = new string[] { "U", "I", "O", "V", "C" };
                portTypeCB.StandardValues = portTypes;
                portTypeCB.EditableMode = SourceGrid.EditableMode.Focus | SourceGrid.EditableMode.SingleClick | SourceGrid.EditableMode.AnyKey;
                portTypeCB.Control.DropDownStyle = ComboBoxStyle.DropDownList;

                SourceGrid.Cells.Cell portTypeCell = new SourceGrid.Cells.Cell("", portTypeCB);
                portTypeCell.View = SourceGrid.Cells.Views.ComboBox.Default;
                portTypeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;

                grid.Columns[1].DataCell = portTypeCell;
            }

            valueChangedController = new TableValueChangedEvent(this);

            grid.DataSource = new DevAge.ComponentModel.BoundDataView(view);
            grid.Controller.AddController(valueChangedController);
            grid.CreateColumns();

            for (int i = 0; i < grid.Columns.Count; i++)
            {
                grid.Columns[i].HeaderCell.View = titleModel;
                grid.Columns[i].MinimalWidth = (grid.Columns[i].PropertyName.Length + 5)* (int) grid.Font.Size;
                //grid.Columns[i].AutoSizeMode = SourceGrid.AutoSizeMode.

                _ColumnNameToIndex.Add(grid.Columns[i].PropertyName, i);
            }

            grid.MinimumHeight = 20;
            //grid.AutoStretchColumnsToFitWidth = true;
            grid.AutoSizeCells();            
        }

        public void GoTo(int row, string columnName)
        {
            if (_ColumnNameToIndex.ContainsKey(columnName))
            {
                //grid.Selection.ResetSelection(false);
                //grid.Selection.SelectCell(new SourceGrid.Position(row, _ColumnNameToIndex[columnName]),true);
                grid.Selection.FocusRow(row);

                //grid.ShowCell(new SourceGrid.Position(row, _ColumnNameToIndex[columnName]), true);
            }
        }

        public void ModifyUpdate()
        {
            _Parent._IsModified[this.Text] = true;
        }
    }

    public class TableValueChangedEvent : SourceGrid.Cells.Controllers.ControllerBase
    {
        TableEditor _ParentTE;

        public TableValueChangedEvent(TableEditor parent)
        {
            _ParentTE = parent;
        }

        public override void OnValueChanging(SourceGrid.CellContext sender, SourceGrid.ValueChangeEventArgs e)
        {
            base.OnValueChanging(sender, e);

            //form.isModified = true;
            _ParentTE.ModifyUpdate();
        }

    }
}
