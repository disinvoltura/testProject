﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;

namespace VMS.IFS.UI
{
    public class InputDataChecker
    {
        #region Member Variables
        public DataTable _DTError;
        #endregion

        #region Properties
        public DataTable Errors
        {
            get { return _DTError; }
        }
        #endregion

        #region Constructors
        public InputDataChecker()
        {
            initialize();
        }

        #endregion

        #region Methods
        private void initialize()
        {
            _DTError = new DataTable();
            _DTError.Columns.Add("Type");
            _DTError.Columns.Add("Description");
            _DTError.Columns.Add("Sheet");
            _DTError.Columns.Add("Row");
            _DTError.Columns.Add("Column");                        
        }
        #endregion

        #region Error Check Method

        public void Check(InputDataSet ids)
        {
            _DTError.Rows.Clear();

            Dictionary<string, string> dicEQPID_TYPE = new Dictionary<string, string>();
            Dictionary<string, List<string>> dicPID_BOP = new Dictionary<string, List<string>>();
            Dictionary<string, List<string>> dicPIDSID_EQP = new Dictionary<string, List<string>>();
            List<string> lstSTK = new List<string>();
            List<string> lstCNV = new List<string>();

            EquipmentCheck(ids.EquipmentDataTable, dicEQPID_TYPE);
            StockerCheck(ids.InlineStockerDataTable, lstSTK);
            ConveyorCheck(ids.ConveyorDataTable, lstCNV, lstSTK);
            EQPPortCheck(ids.EQP_PortDataTable, dicEQPID_TYPE, lstSTK);
            ProductCheck(ids.ProductDataTable, dicPID_BOP);
            BOPCheck(ids.BOPDataTable, dicPID_BOP);
            LoadableSetCheck(ids.LoadableSetDataTable, dicPID_BOP, dicEQPID_TYPE, dicPIDSID_EQP);
            ProcessingTimeCheck(ids.ProcessingTimeDataTable, dicPID_BOP, dicEQPID_TYPE, dicPIDSID_EQP);
            FaboutPlanCheck(ids.FabOutPlanDataTable, dicPID_BOP);
            //MovingTimeCheck(ids.MovingTimeDataTable, lstSTK);
            //WIPCheck(ids.WIPDataTable, dicPID_BOP, dicEQPID_TYPE);
            UniqueNameCheck(ids);
            RouteExistCheck(ids);

            EquipmentProcessingTime(ids.EquipmentDataTable, ids.ProcessingTimeDataTable);
        }

        private void EquipmentProcessingTime(InputDataSet.EquipmentDataTableDataTable dtEQP, InputDataSet.ProcessingTimeDataTableDataTable dtPT)
        {
            for (int i = 0; i < dtEQP.Rows.Count; i++)
            {
                InputDataSet.EquipmentDataTableRow eqpRow  = dtEQP[i];
                
                InputDataSet.ProcessingTimeDataTableRow[] rows = 
                    (InputDataSet.ProcessingTimeDataTableRow[])
                    dtPT.Select("EQP_ID='" + eqpRow.EQP_ID + "'");

                if (rows == null || rows.Length == 0)
                {
                    _DTError.Rows.Add(new string[] { "Warning", "No data is available for the processing times of an equipment <" + eqpRow.EQP_ID + ">", "Equipment", (i + 1).ToString(), "EQP_ID" });
                }
            }
        }

        private void EquipmentCheck(DataTable dtEQP, Dictionary<string, string> dicEQPID_TYPE)
        {
            string tab = "Equipment";

            List<string> listEQP_TYPE = new List<string>();
            listEQP_TYPE.Add("U");
            listEQP_TYPE.Add("B");
            listEQP_TYPE.Add("V");
            listEQP_TYPE.Add("C");

            for (int i = 0; i < dtEQP.Rows.Count; i++)
            {
                NullCheck(tab, dtEQP.Rows[i], i, new string[] { "EQP_ID", "EQP_TYPE", "NUM" });
                NotNegativeDoubleParsingCheck(tab, dtEQP.Rows[i], i, new string[] { "SETUP_TIME" });
                PositiveIntParsingCheck(tab, dtEQP.Rows[i], i, new string[] { "NUM" });
                SpecialCharacterCheck(tab, dtEQP.Rows[i], i, new string[] { "EQP_ID" });

                if (!dicEQPID_TYPE.ContainsKey(dtEQP.Rows[i]["EQP_ID"].ToString()) && dtEQP.Rows[i]["EQP_ID"].ToString() != "")
                {
                    dicEQPID_TYPE.Add(dtEQP.Rows[i]["EQP_ID"].ToString(), dtEQP.Rows[i]["EQP_TYPE"].ToString());
                }

                if (!listEQP_TYPE.Contains(dtEQP.Rows[i]["EQP_TYPE"].ToString()) && dtEQP.Rows[i]["EQP_TYPE"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { "Error", "Only use U (Uni-inline cell), B (Bi-inline cell), V (Oven type), or C (Chamber type)", tab, (i + 1).ToString(), "EQP_TYPE" });
                }

                if (!(dtEQP.Rows[i]["BOTTLENECK"].ToString() == "" || dtEQP.Rows[i]["BOTTLENECK"].ToString() == "BN"))
                {
                    _DTError.Rows.Add(new string[] { "Error", "Only use BN (Bottleneck EQP) or blank (Not bottleneck EQP)", tab, (i + 1).ToString(), "BOTTLENECK" });
                }
            }
        }

        private void StockerCheck(DataTable dtStocker, List<string> lstSTK)
        {
            string tab = "Inline Stocker";

            for (int i = 0; i < dtStocker.Rows.Count; i++)
            {
                NullCheck(tab, dtStocker.Rows[i], i, new string[] { "STK_ID", "STK_TYPE", "STK_BUFFER", "RETRIEVAL_TIME", "DELIVERY_TIME" });
                PositiveIntParsingCheck(tab, dtStocker.Rows[i], i, new string[] { "STK_BUFFER" });
                NotNegativeDoubleParsingCheck(tab, dtStocker.Rows[i], i, new string[] { "RETRIEVAL_TIME", "DELIVERY_TIME" });
                SpecialCharacterCheck(tab, dtStocker.Rows[i], i, new string[] { "STK_ID" });

                lstSTK.Add(dtStocker.Rows[i]["STK_ID"].ToString());
                
                if (dtStocker.Rows[i]["STK_TYPE"].ToString() != "S")
                {
                    _DTError.Rows.Add(new string[] { "Error", "Only use S (Single crane)", tab, (i + 1).ToString(), "STK_TYPE" });
                }
            }
        }

        private void ConveyorCheck(DataTable dtConveyor, List<string> lstCNV, List<string> lstSTK)
        {
            string tab = "Conveyor";

            for (int i = 0; i < dtConveyor.Rows.Count; i++)
            {
                NullCheck(tab, dtConveyor.Rows[i], i, new string[] { "CONV_ID", "CONV_TYPE", "FROM_STK", "TO_STK", "CONV_BUFFER", "CONV_TIME" });
                PositiveIntParsingCheck(tab, dtConveyor.Rows[i], i, new string[] { "CONV_BUFFER" });
                NotNegativeDoubleParsingCheck(tab, dtConveyor.Rows[i], i, new string[] { "CONV_TIME" });
                SpecialCharacterCheck(tab, dtConveyor.Rows[i], i, new string[] { "CONV_ID", "FROM_STK", "TO_STK" });

                lstCNV.Add(dtConveyor.Rows[i]["CONV_ID"].ToString());
                
                if (dtConveyor.Rows[i]["CONV_TYPE"].ToString() != "ACC")
                {
                    _DTError.Rows.Add(new string[] { "Error", "Only use ACC (accumulating conveyor)", tab, (i + 1).ToString(), "CONV_TYPE" });
                }

                if (!lstSTK.Contains(dtConveyor.Rows[i]["FROM_STK"].ToString()) && dtConveyor.Rows[i]["FROM_STK"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { "Error", "Not defined STK_ID in Inline Stocker sheet", tab, (i + 1).ToString(), "FROM_STK" });
                }
                if (!lstSTK.Contains(dtConveyor.Rows[i]["TO_STK"].ToString()) && dtConveyor.Rows[i]["TO_STK"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { "Error", "Not defined STK_ID in Inline Stocker sheet", tab, (i + 1).ToString(), "TO_STK" });
                }
            }
        }

        private void EQPPortCheck(DataTable dtEQPPort, Dictionary<string, string> dicEQPID_TYPE, List<string> lstSTK)
        {
            string tab = "EQP_Port";

            Dictionary<string, string> dicEQP_PORT = new Dictionary<string, string>();

            for (int i = 0; i < dtEQPPort.Rows.Count; i++)
            {
                NullCheck(tab, dtEQPPort.Rows[i], i, new string[] { "EQP_ID", "PORT_TYPE", "PORT_CAPA", "STK_ID" });
                PositiveIntParsingCheck(tab, dtEQPPort.Rows[i], i, new string[] { "PORT_CAPA" });
                SpecialCharacterCheck(tab, dtEQPPort.Rows[i], i, new string[] { "EQP_ID" });

                if (dicEQP_PORT.ContainsKey(dtEQPPort.Rows[i]["EQP_ID"].ToString()))
                {
                    dicEQP_PORT[dtEQPPort.Rows[i]["EQP_ID"].ToString()] += dtEQPPort.Rows[i]["PORT_TYPE"].ToString();
                }
                else
                {
                    dicEQP_PORT.Add(dtEQPPort.Rows[i]["EQP_ID"].ToString(), dtEQPPort.Rows[i]["PORT_TYPE"].ToString());
                }

                if (!lstSTK.Contains(dtEQPPort.Rows[i]["STK_ID"].ToString()) && dtEQPPort.Rows[i]["STK_ID"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { "Error", "Not defined STK_ID in Inline Stocker sheet", tab, (i + 1).ToString(), "STK_ID" });
                }

                if (!dicEQPID_TYPE.ContainsKey(dtEQPPort.Rows[i]["EQP_ID"].ToString()) && dtEQPPort.Rows[i]["EQP_ID"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { "Error", "Not defined EQP_ID in Equipment sheet", tab, (i + 1).ToString(), "EQP_ID" });
                }
                else if (dtEQPPort.Rows[i]["PORT_TYPE"].ToString() != "I" && dtEQPPort.Rows[i]["PORT_TYPE"].ToString() != "O" && dtEQPPort.Rows[i]["PORT_TYPE"].ToString() != "U" && dtEQPPort.Rows[i]["PORT_TYPE"].ToString() != "V" && dtEQPPort.Rows[i]["PORT_TYPE"].ToString() != "C")
                {
                    _DTError.Rows.Add(new string[] { "Error",  "Only use U(Uni-inline cell I/O port), I (Bi-inline cell In port), O (Bi-inline cell Out port), V (Oven type eqiupment I/O port), or C (Chamber type equipment I/O port)", tab, (i + 1).ToString(), "PORT_TYPE" });
                }
                else if (!dicEQPID_TYPE[dtEQPPort.Rows[i]["EQP_ID"].ToString()].Equals(dtEQPPort.Rows[i]["PORT_TYPE"].ToString()) && dtEQPPort.Rows[i]["PORT_TYPE"].ToString() != "")
                {
                    if (dicEQPID_TYPE[dtEQPPort.Rows[i]["EQP_ID"].ToString()] == "B" && (dtEQPPort.Rows[i]["PORT_TYPE"].ToString() != "I" && dtEQPPort.Rows[i]["PORT_TYPE"].ToString() != "O"))
                    {
                        _DTError.Rows.Add(new string[] { "Error", "Only use I (In-port) or O (Out-port) for bi-inline cells", tab, (i + 1).ToString(), "PORT_TYPE" });
                    }
                    else if (dicEQPID_TYPE[dtEQPPort.Rows[i]["EQP_ID"].ToString()] != "B" && (dicEQPID_TYPE[dtEQPPort.Rows[i]["EQP_ID"].ToString()] == "U" || dicEQPID_TYPE[dtEQPPort.Rows[i]["EQP_ID"].ToString()] == "V" || dicEQPID_TYPE[dtEQPPort.Rows[i]["EQP_ID"].ToString()] == "C"))
                    {
                        _DTError.Rows.Add(new string[] { "Error", "Different PORT_TYPE with Equipment sheet", tab, (i + 1).ToString(), "PORT_TYPE" });
                    }
                }
            }

            foreach (string key in dicEQPID_TYPE.Keys)
            {
                if (!dicEQP_PORT.ContainsKey(key))
                {
                    _DTError.Rows.Add(new string[] { "Error", key + " port is not defined", tab, "-", "-" });
                }
                else if (dicEQPID_TYPE[key] == "B")
                {
                    if (dicEQP_PORT[key] != "IO" && dicEQP_PORT[key] != "OI")
                    {
                        _DTError.Rows.Add(new string[] { "Error", key + " (bi-inline cell) needs to defined one in-port and one out-port", tab, "-", "-" });
                    }
                }
            }
        }

        private void ProductCheck(DataTable dtProduct, Dictionary<string, List<string>> dicPID_BOP)
        {
            string tab = "Product";

            for (int i = 0; i < dtProduct.Rows.Count; i++)
            {
                NullCheck(tab, dtProduct.Rows[i], i, new string[] { "PROD_ID", "GLASS_QTY", "AVG_YIELD" });
                PositiveIntParsingCheck(tab, dtProduct.Rows[i], i, new string[] { "GLASS_QTY" });
                ZeroOneDoubleParsingCheck(tab, dtProduct.Rows[i], i, new string[] { "AVG_YIELD" });
                SpecialCharacterCheck(tab, dtProduct.Rows[i], i, new string[] { "PROD_ID" });

                if (dicPID_BOP.ContainsKey(dtProduct.Rows[i]["PROD_ID"].ToString()))
                {
                    _DTError.Rows.Add(new string[] { "Error", "This product ID is already defined", tab, (i + 1).ToString(), "PROD_ID" });
                }
                else
                {
                    dicPID_BOP.Add(dtProduct.Rows[i]["PROD_ID"].ToString(), new List<string>());
                }
            }
        }

        private void BOPCheck(DataTable dtBOP, Dictionary<string, List<string>> dicPID_BOP)
        {
            string tab = "BOP";

            Dictionary<string, List<string>> dicPID_FROM = new Dictionary<string, List<string>>();
            Dictionary<string, List<string>> dicPID_TO = new Dictionary<string, List<string>>();
            Dictionary<string, double> ratio = new Dictionary<string, double>();

            for (int i = 0; i < dtBOP.Rows.Count; i++)
            {
                NullCheck(tab, dtBOP.Rows[i], i, new string[] { "PROD_ID", "FROM_STEP", "TO_STEP", "RATIO" });
                ZeroOneDoubleParsingCheck(tab, dtBOP.Rows[i], i, new string[] { "RATIO" });
                SpecialCharacterCheck(tab, dtBOP.Rows[i], i, new string[] { "PROD_ID", "FROM_STEP", "TO_STEP" });

                if (!dicPID_BOP.ContainsKey(dtBOP.Rows[i]["PROD_ID"].ToString()) && dtBOP.Rows[i]["PROD_ID"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { "Error", "Not defined PROD_ID in Product sheet", tab, (i + 1).ToString(), "PROD_ID" });
                    continue;
                }

                if (dicPID_FROM.ContainsKey(dtBOP.Rows[i]["PROD_ID"].ToString()) && dtBOP.Rows[i]["PROD_ID"].ToString() != "")
                {
                    if (!dicPID_FROM[dtBOP.Rows[i]["PROD_ID"].ToString()].Contains(dtBOP.Rows[i]["FROM_STEP"].ToString()))
                    {
                        dicPID_FROM[dtBOP.Rows[i]["PROD_ID"].ToString()].Add(dtBOP.Rows[i]["FROM_STEP"].ToString());
                    }
                    if (!dicPID_TO[dtBOP.Rows[i]["PROD_ID"].ToString()].Contains(dtBOP.Rows[i]["TO_STEP"].ToString()))
                    {
                        dicPID_TO[dtBOP.Rows[i]["PROD_ID"].ToString()].Add(dtBOP.Rows[i]["TO_STEP"].ToString());
                    }
                }
                else
                {
                    dicPID_FROM.Add(dtBOP.Rows[i]["PROD_ID"].ToString(), new List<string>());
                    dicPID_FROM[dtBOP.Rows[i]["PROD_ID"].ToString()].Add(dtBOP.Rows[i]["FROM_STEP"].ToString());
                    dicPID_TO.Add(dtBOP.Rows[i]["PROD_ID"].ToString(), new List<string>());
                    dicPID_TO[dtBOP.Rows[i]["PROD_ID"].ToString()].Add(dtBOP.Rows[i]["TO_STEP"].ToString());
                }

                string key = dtBOP.Rows[i]["PROD_ID"].ToString() + "&" + dtBOP.Rows[i]["FROM_STEP"].ToString();
                if (ratio.ContainsKey(key))
                {
                    ratio[key] += double.Parse(dtBOP.Rows[i]["RATIO"].ToString());
                }
                else
                {
                    ratio.Add(key, double.Parse(dtBOP.Rows[i]["RATIO"].ToString()));
                }

                //합이 1을 못 넘게 수정
                //double temp;
                //if (double.TryParse(dtBOP.Rows[i]["RATIO"].ToString(), out temp))
                //{
                //    if (temp > 1)
                //    {
                //        _DTError.Rows.Add(new string[] { "Error", "Cannot be over 1", tab, (i + 1).ToString(), "RATIO" });
                //    }
                //}
            }

            foreach (string key in dicPID_FROM.Keys)
            {
                List<string> fromCheckList = new List<string>();
                foreach (string step in dicPID_FROM[key])
                {
                    if (!dicPID_BOP[key].Contains(step))
                        dicPID_BOP[key].Add(step);

                    if (!dicPID_TO[key].Contains(step))
                    {
                        fromCheckList.Add(step);
                    }
                }
                if (fromCheckList.Count > 1 || fromCheckList.Count == 0)
                {
                    _DTError.Rows.Add(new string[] { "Error", "The first step of " + key + " is not clearly defined", tab, "-", "-" });
                }
            }
            foreach (string key in dicPID_TO.Keys)
            {
                List<string> toCheckList = new List<string>();
                foreach (string step in dicPID_TO[key])
                {
                    if (!dicPID_BOP[key].Contains(step))
                        dicPID_BOP[key].Add(step);

                    if (!dicPID_FROM[key].Contains(step))
                    {
                        toCheckList.Add(step);
                    }
                }
                if (toCheckList.Count == 0)
                {
                    _DTError.Rows.Add(new string[] { "Error", "The last step of " + key + " is not clearly defined", tab, "-", "-" });
                }
            }
            foreach (string key in dicPID_BOP.Keys)
            {
                if (dicPID_BOP[key].Count == 0)
                {
                    _DTError.Rows.Add(new string[] { "Error", "BOP of " + key + " is not defined", tab, "-", "-" });
                }
            }
            foreach (string key in ratio.Keys)
            {
                if (ratio[key] > 1 || ratio[key] < 0)
                {                    
                    _DTError.Rows.Add(new string[] { "Error", "Ratio must be on [0,1]", tab, "-", "-" });
                }
            }
        }

        private void LoadableSetCheck(DataTable dtLS, Dictionary<string, List<string>> dicPID_BOP, Dictionary<string, string> dicEQPID_TYPE, Dictionary<string, List<string>> dicPIDSID_EQP)
        {
            string tab = "Loadable Set";

            Dictionary<string, List<string>> dicVersion_PIDSTEPID = new Dictionary<string, List<string>>();

            for (int i = 0; i < dtLS.Rows.Count; i++)
            {
                NullCheck(tab, dtLS.Rows[i], i, new string[] { "VERSION_NO", "PROD_ID", "STEP_ID", "EQP_ID" });
                SpecialCharacterCheck(tab, dtLS.Rows[i], i, new string[] { "VERSION_NO", "PROD_ID", "STEP_ID", "EQP_ID" });

                if (dicVersion_PIDSTEPID.ContainsKey(dtLS.Rows[i]["VERSION_NO"].ToString()) && dtLS.Rows[i]["VERSION_NO"].ToString() != "")
                {
                    dicVersion_PIDSTEPID[dtLS.Rows[i]["VERSION_NO"].ToString()].Add(dtLS.Rows[i]["PROD_ID"].ToString() + "," + dtLS.Rows[i]["STEP_ID"].ToString());
                }
                else if (dtLS.Rows[i]["VERSION_NO"].ToString() != "")
                {
                    dicVersion_PIDSTEPID.Add(dtLS.Rows[i]["VERSION_NO"].ToString(), new List<string>());
                    dicVersion_PIDSTEPID[dtLS.Rows[i]["VERSION_NO"].ToString()].Add(dtLS.Rows[i]["PROD_ID"].ToString() + "," + dtLS.Rows[i]["STEP_ID"].ToString());
                }

                if (dicPIDSID_EQP.ContainsKey(dtLS.Rows[i]["PROD_ID"].ToString() + "," + dtLS.Rows[i]["STEP_ID"].ToString()) && dtLS.Rows[i]["PROD_ID"].ToString() != "" && dtLS.Rows[i]["STEP_ID"].ToString() != "")
                {
                    if (!dicPIDSID_EQP[dtLS.Rows[i]["PROD_ID"].ToString() + "," + dtLS.Rows[i]["STEP_ID"].ToString()].Contains(dtLS.Rows[i]["EQP_ID"].ToString()))
                    {
                        dicPIDSID_EQP[dtLS.Rows[i]["PROD_ID"].ToString() + "," + dtLS.Rows[i]["STEP_ID"].ToString()].Add(dtLS.Rows[i]["EQP_ID"].ToString());
                    }
                }
                else if (dtLS.Rows[i]["PROD_ID"].ToString() != "" && dtLS.Rows[i]["STEP_ID"].ToString() != "")
                {
                    dicPIDSID_EQP.Add(dtLS.Rows[i]["PROD_ID"].ToString() + "," + dtLS.Rows[i]["STEP_ID"].ToString(), new List<string>());
                    dicPIDSID_EQP[dtLS.Rows[i]["PROD_ID"].ToString() + "," + dtLS.Rows[i]["STEP_ID"].ToString()].Add(dtLS.Rows[i]["EQP_ID"].ToString());
                }

                if (!dicPID_BOP.ContainsKey(dtLS.Rows[i]["PROD_ID"].ToString()) && dtLS.Rows[i]["PROD_ID"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { "Error", "Not defined PROD_ID in Product sheet", tab, (i + 1).ToString(), "PROD_ID" });
                }
                else if (!dicPID_BOP[dtLS.Rows[i]["PROD_ID"].ToString()].Contains(dtLS.Rows[i]["STEP_ID"].ToString()) && dtLS.Rows[i]["STEP_ID"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { "Error", "Not defined STEP_ID in BOP sheet", tab, (i + 1).ToString(), "STEP_ID" });
                }

                if (!dicEQPID_TYPE.ContainsKey(dtLS.Rows[i]["EQP_ID"].ToString()) && dtLS.Rows[i]["EQP_ID"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { "Error", "Not defined EQP_ID in Equipment sheet", tab, (i + 1).ToString(), "EQP_ID" });
                }
            }

            foreach (string keyVer in dicVersion_PIDSTEPID.Keys)
            {
                foreach (string keyPID in dicPID_BOP.Keys)
                {
                    if (dicPID_BOP[keyPID].Count == 0)
                    {
                        _DTError.Rows.Add(new string[] { "Error", keyVer + " doesn't contain " + keyPID, tab, "-", "-" });
                    }
                    foreach (string valSID in dicPID_BOP[keyPID])
                    {
                        string temp = keyPID + "," + valSID;
                        if (!dicVersion_PIDSTEPID[keyVer].Contains(temp))
                        {
                            _DTError.Rows.Add(new string[] { "Error", keyVer + " doesn't contain {" + keyPID + ", " + valSID + "}", tab, "-", "-" });
                        }
                    }
                }
            }
        }

        private void ProcessingTimeCheck(DataTable dtPT, Dictionary<string, List<string>> dicPID_BOP, Dictionary<string, string> dicEQPID_TYPE, Dictionary<string, List<string>> dicPIDSID_EQP)
        {
            string tab = "Processing Time";

            Dictionary<string, List<string>> dicCompare = new Dictionary<string, List<string>>();

            for (int i = 0; i < dtPT.Rows.Count; i++)
            {
                NullCheck(tab, dtPT.Rows[i], i, new string[] { "PROD_ID", "STEP_ID", "EQP_ID", "TACT_TIME", "FLOW_TIME" });
                NotNegativeDoubleParsingCheck(tab, dtPT.Rows[i], i, new string[] { "TACT_TIME", "FLOW_TIME" });
                SpecialCharacterCheck(tab, dtPT.Rows[i], i, new string[] { "PROD_ID", "STEP_ID", "EQP_ID" });

                if (dtPT.Rows[i]["PROD_ID"].ToString() != "" && dtPT.Rows[i]["STEP_ID"].ToString() != "")
                {
                    string key = dtPT.Rows[i]["PROD_ID"].ToString() + "," + dtPT.Rows[i]["STEP_ID"].ToString();
                    if (dicCompare.ContainsKey(key))
                    {
                        if (!dicCompare[key].Contains(dtPT.Rows[i]["EQP_ID"].ToString()))
                        {
                            dicCompare[key].Add(dtPT.Rows[i]["EQP_ID"].ToString());
                        }
                    }
                    else
                    {
                        dicCompare.Add(key, new List<string>());
                        dicCompare[key].Add(dtPT.Rows[i]["EQP_ID"].ToString());
                    }
                }

                if (!dicPID_BOP.ContainsKey(dtPT.Rows[i]["PROD_ID"].ToString()) && dtPT.Rows[i]["PROD_ID"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { "Error", "Not defined PROD_ID in Product sheet", tab, (i + 1).ToString(), "PROD_ID" });
                }
                else
                {
                    if (!dicPID_BOP[dtPT.Rows[i]["PROD_ID"].ToString()].Contains(dtPT.Rows[i]["STEP_ID"].ToString()) && dtPT.Rows[i]["STEP_ID"].ToString() != "")
                    {
                        _DTError.Rows.Add(new string[] { "Error", "Not defined STEP_ID in BOP sheet", tab, (i + 1).ToString(), "STEP_ID" });
                    }

                    if (!dicEQPID_TYPE.ContainsKey(dtPT.Rows[i]["EQP_ID"].ToString()) && dtPT.Rows[i]["EQP_ID"].ToString() != "")
                    {
                        _DTError.Rows.Add(new string[] { "Error", "Not defined EQP_ID in Equipment sheet", tab, (i + 1).ToString(), "EQP_ID" });
                    }
                }
            }

            foreach (string key in dicPID_BOP.Keys)
            {
                if (dicPID_BOP[key].Count == 0)
                {
                    _DTError.Rows.Add(new string[] { "Error", "Processing time of " + key + " is not defined", tab, "-", "-" });
                }
            }

            foreach (string key in dicPIDSID_EQP.Keys)
            {
                string[] param = key.Split(',');
                string PID = param[0];
                string SID = param[1];

                if (!dicCompare.ContainsKey(key))
                {
                    _DTError.Rows.Add(new string[] { "Error", "Processing time of {" + PID + ", " + SID + "} is not defined", tab, "-", "-" });
                }
                else
                {
                    foreach (string valEQP in dicPIDSID_EQP[key])
                    {
                        if (!dicCompare[key].Contains(valEQP))
                        {
                            _DTError.Rows.Add(new string[] { "Error", "Processing time of {" + PID + ", " + SID + ", " + valEQP + "} is not defined", tab, "-", "-" });
                        }
                    }
                }
            }
        }

        private void FaboutPlanCheck(DataTable dtFP, Dictionary<string, List<string>> dicPID_BOP)
        {
            string tab = "Fabout Plan";

            List<string> columnList = new List<string>();
            List<string> woTimeColumnList = new List<string>();
            foreach (DataColumn dc in dtFP.Columns)
            {
                columnList.Add(dc.ColumnName);
                if (dc.ColumnName.ToUpper() != "DATE")
                    woTimeColumnList.Add(dc.ColumnName);
            }
            foreach (string pid in woTimeColumnList)
            {
                if (!dicPID_BOP.ContainsKey(pid))
                {
                    _DTError.Rows.Add(new string[] { "Error", pid + " is not defined in Product sheet", tab, "-", "-" });
                }
            }
            foreach (string pid in dicPID_BOP.Keys)
            {
                if (!woTimeColumnList.Contains(pid))
                {
                    _DTError.Rows.Add(new string[] { "Warning", pid + " is not defined to column in this sheet", tab, "-", "-" });
                }
            }

            List<string> dateList = new List<string>();
            for (int i = 0; i < dtFP.Rows.Count; i++)
            {
                NullCheck(tab, dtFP.Rows[i], i, columnList.ToArray());
                PositiveIntParsingCheck(tab, dtFP.Rows[i], i, woTimeColumnList.ToArray());

                if (dateList.Contains(dtFP.Rows[i]["DATE"].ToString()))
                {
                    _DTError.Rows.Add(new string[] { "Error", "This date already defined", tab, (i + 1).ToString(), "DATE" });
                }

                DateTime tempDate = new DateTime();
                if (dtFP.Rows[i]["DATE"].ToString().Length != 8)
                {
                    _DTError.Rows.Add(new string[] { "Error", "This value must be entered by yyyyMMdd type", tab, (i + 1).ToString(), "DATE" });
                }
                else if (!DateTime.TryParse(dtFP.Rows[i]["DATE"].ToString().Substring(0, 4) + "-" + dtFP.Rows[i]["DATE"].ToString().Substring(4, 2) + "-" + dtFP.Rows[i]["DATE"].ToString().Substring(6, 2), out tempDate) && dtFP.Rows[i]["DATE"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { "Error", "This value must be entered by yyyyMMdd type", tab, (i + 1).ToString(), "DATE" });
                }
                else
                {
                    dateList.Add(dtFP.Rows[i]["DATE"].ToString());
                }
            }
        }

        private void MCSCheck(DataTable dtMCS, List<string> lstCNV)
        {
            string tab = "MCS Weight Set";

            for (int i = 0; i < dtMCS.Rows.Count; i++)
            {
                NullCheck(tab, dtMCS.Rows[i], i, new string[] { "VERSION_NO", "CONV_ID", "WEIGHT" });
                NotNegativeDoubleParsingCheck(tab, dtMCS.Rows[i], i, new string[] { "WEIGHT" });
                SpecialCharacterCheck(tab, dtMCS.Rows[i], i, new string[] { "VERSION_NO" });

                if (!lstCNV.Contains(dtMCS.Rows[i]["CONV_ID"].ToString()) && dtMCS.Rows[i]["CONV_ID"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { "Error", "Not defined CONV_ID in Conveyor sheet", tab, (i + 1).ToString(), "CONV_ID" });
                }                
            }
        }

        private void WNSCheck(DataTable dtWNS, Dictionary<string, string> dicEQPID_TYPE, List<string> lstSTK)
        {
            string tab = "Where-Next Stocker";

            for (int i = 0; i < dtWNS.Rows.Count; i++)
            {
                NullCheck(tab, dtWNS.Rows[i], i, new string[] { "EQP_ID", "STK_ID" });

                if (!dicEQPID_TYPE.ContainsKey(dtWNS.Rows[i]["EQP_ID"].ToString()) && dtWNS.Rows[i]["EQP_ID"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { "Error", "Not defined EQP_ID in Equipment sheet", tab, (i + 1).ToString(), "EQP_ID" });
                }

                if (!lstSTK.Contains(dtWNS.Rows[i]["STK_ID"].ToString()) && dtWNS.Rows[i]["STK_ID"].ToString() != "")
                {
                    _DTError.Rows.Add(new string[] { "Error", "Not defined STK_ID in Inline Stocker sheet", tab, (i + 1).ToString(), "STK_ID" });
                }
            }
        }

        //private void MovingTimeCheck(DataTable dtMT, List<string> lstSTK)
        //{
        //    string tab = "Moving Time";

        //    List<string> lstSTKinMTtab = new List<string>();
        //    for (int i = 0; i < dtMT.Rows.Count; i++)
        //    {
        //        NullCheck(tab, dtMT.Rows[i], i, new string[] { "FROM_STK", "TO_STK", "MOVE_TIME" });
        //        NotNegativeDoubleParsingCheck(tab, dtMT.Rows[i], i, new string[] { "MOVE_TIME" });

        //        if (!lstSTK.Contains(dtMT.Rows[i]["FROM_STK"].ToString()) && dtMT.Rows[i]["FROM_STK"].ToString() != "")
        //        {
        //            _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "FROM_STK", "Not defined STK_ID in EQP_Port tab" });
        //        }

        //        if (!lstSTK.Contains(dtMT.Rows[i]["TO_STK"].ToString()) && dtMT.Rows[i]["TO_STK"].ToString() != "")
        //        {
        //            _DTError.Rows.Add(new string[] { tab, (i + 1).ToString(), "TO_STK", "Not defined STK_ID in EQP_Port tab" });
        //        }

        //        if (!lstSTKinMTtab.Contains(dtMT.Rows[i]["FROM_STK"].ToString()))
        //        {
        //            lstSTKinMTtab.Add(dtMT.Rows[i]["FROM_STK"].ToString());
        //        }
        //        if (!lstSTKinMTtab.Contains(dtMT.Rows[i]["TO_STK"].ToString()))
        //        {
        //            lstSTKinMTtab.Add(dtMT.Rows[i]["TO_STK"].ToString());
        //        }
        //    }

        //    foreach (string stk in lstSTK)
        //    {
        //        if (!lstSTKinMTtab.Contains(stk))
        //        {
        //            _DTError.Rows.Add(new string[] { tab, "-", "-", "Moving Time related to STK_ID - " + stk + " is not defined" });
        //        }
        //    }
        //}

        private void WIPCheck(DataTable dtWIP, Dictionary<string, List<string>> dicPID_BOP, Dictionary<string, string> dicEQPID_TYPE)
        {
            string tab = "WIP";

            List<string> eqpList = new List<string>();
            for (int i = 0; i < dtWIP.Rows.Count; i++)
            {
                string eqp = dtWIP.Rows[i]["EQP_ID"].ToString();
                if (!dicEQPID_TYPE.ContainsKey(eqp) && eqp != "FabOut")
                {
                    _DTError.Rows.Add(new string[] { "Error", "Not defined EQP_ID in Equipment sheet", tab, (i + 1).ToString(), "EQP_ID" });
                    continue;
                }
                else
                {
                    if (eqpList.Contains(eqp))
                    {
                        _DTError.Rows.Add(new string[] { "Error", "EQP_ID - " + eqp + " is already defined in this sheet", tab, (i + 1).ToString(), "EQP_ID" });
                    }
                    else
                    {
                        eqpList.Add(eqp);
                    }
                }

                if (eqp != "FabOut")
                {
                    string[] paramQ = dtWIP.Rows[i]["Q"].ToString().Split(new char[] { '(', ',', ')' });
                    if (paramQ.Length != 1 && paramQ.Length % 5 != 0)
                    {
                        _DTError.Rows.Add(new string[] { "Error", "Check the format for cassette in the Q -> format: (PROD_ID, STEP_ID, GLASS_QUANTITY)", tab, (i + 1).ToString(), "Q" });
                    }
                    else if (paramQ.Length == 1 && paramQ[0] != "")
                    {
                        _DTError.Rows.Add(new string[] { "Error", "Check the format for cassette in the Q -> format: (PROD_ID, STEP_ID, GLASS_QUANTITY)", tab, (i + 1).ToString(), "Q" });
                    }
                    else
                    {
                        for (int j = 1; j < paramQ.Length; j = j + 5)
                        {
                            string pID = paramQ[j];
                            string sID = paramQ[j + 1];
                            if (!dicPID_BOP.ContainsKey(pID))
                            {
                                int num = ((j - 1) / 5) + 1;
                                _DTError.Rows.Add(new string[] { "Error", "PROD_ID - " + pID + " (cassette #" + num + ") in the Q column is not defined in Product tab", tab, (i + 1).ToString(), "Q" });
                            }
                            else if (!dicPID_BOP[pID].Contains(sID))
                            {
                                int num = ((j - 2) / 5) + 1;
                                _DTError.Rows.Add(new string[] { "Error", "STEP_ID - " + sID + " (cassette #" + num + ") in the Q column is not defined in BOP tab", tab, (i + 1).ToString(), "Q" });
                            }
                            int qty = 0;
                            if (!int.TryParse(paramQ[j + 2], out qty) && paramQ[j + 2] != "")
                            {
                                int num = ((j - 3) / 5) + 1;
                                _DTError.Rows.Add(new string[] { "Error", "GLASS_QUANTITY of cassette #" + num + " in the Q column makes parsing error(int)", tab, (i + 1).ToString(), "Q" });
                            }
                        }
                    }

                    string[] paramB = dtWIP.Rows[i]["B"].ToString().Split(new char[] { '(', ',', ')' });
                    if (paramB.Length != 1 && paramB.Length % 5 != 0)
                    {
                        _DTError.Rows.Add(new string[] { "Error", "Check the format for cassette in the B -> format: (PROD_ID, STEP_ID, GLASS_QUANTITY)", tab, (i + 1).ToString(), "B" });
                    }
                    else
                    {
                        for (int j = 1; j < paramB.Length; j = j + 5)
                        {
                            string pID = paramB[j];
                            string sID = paramB[j + 1];
                            if (!dicPID_BOP.ContainsKey(pID))
                            {
                                int num = ((j - 1) / 5) + 1;
                                _DTError.Rows.Add(new string[] { "Error", "PROD_ID - " + pID + " (cassette #" + num + ") in the B column is not defined in Product tab", tab, (i + 1).ToString(), "B" });
                            }
                            else if (!dicPID_BOP[pID].Contains(sID))
                            {
                                int num = ((j - 2) / 5) + 1;
                                _DTError.Rows.Add(new string[] { "Error", "STEP_ID - " + sID + " (cassette #" + num + ") in the Q column is not defined in BOP tab", tab, (i + 1).ToString(), "B" });
                            }
                            int qty = 0;
                            if (!int.TryParse(paramB[j + 2], out qty) && paramB[j + 2] != "")
                            {
                                int num = ((j - 3) / 5) + 1;
                                _DTError.Rows.Add(new string[] { "Error", "GLASS_QUANTITY of cassette #" + num + " in the B column makes parsing error(int)", tab, (i + 1).ToString(), "B" });
                            }
                        }
                    }
                }
                else
                {
                    string[] paramFOQ = dtWIP.Rows[i]["Q"].ToString().Split(new char[] { '(', ',', ')' });
                    if (paramFOQ.Length != 1 && paramFOQ.Length % 4 != 0)
                    {
                        _DTError.Rows.Add(new string[] { "Error", "Check the format for cassette in the Q for Fab out -> format: (PROD_ID, GLASS_QUANTITY)", tab, (i + 1).ToString(), "Q" });
                    }
                    else if (paramFOQ.Length == 1 && paramFOQ[0] != "")
                    {
                        _DTError.Rows.Add(new string[] { "Error", "Check the format for cassette in the Q for Fab out -> format: (PROD_ID, GLASS_QUANTITY)", tab, (i + 1).ToString(), "Q" });
                    }
                    else
                    {
                        for (int j = 1; j < paramFOQ.Length; j = j + 4)
                        {
                            string pID = paramFOQ[j];
                            if (!dicPID_BOP.ContainsKey(pID))
                            {
                                int num = ((j - 1) / 4) + 1;
                                _DTError.Rows.Add(new string[] { "Error", "PROD_ID - " + pID + " (Fab out data #" + num + ") in the Q column for Fab out is not defined in Product tab", tab, (i + 1).ToString(), "Q" });
                            }
                            int qty = 0;
                            if (!int.TryParse(paramFOQ[j + 1], out qty) && paramFOQ[j + 1] != "")
                            {
                                int num = ((j - 2) / 4) + 1;
                                _DTError.Rows.Add(new string[] { "Error", "GLASS_QUANTITY of Fab out data #" + num + " in the Q column makes parsing error(int)", tab, (i + 1).ToString(), "Q" });
                            }
                        }
                    }

                    if (dtWIP.Rows[i]["B"].ToString() != "")
                    {
                        _DTError.Rows.Add(new string[] { "Error", "This field must be empty", tab, (i + 1).ToString(), "B" });
                    }
                }
            }

            List<string> definedEQPID = new List<string>();
            foreach (DataRow dr in dtWIP.Rows)
            {
                definedEQPID.Add(dr["EQP_ID"].ToString());
            }
            foreach (string key in dicEQPID_TYPE.Keys)
            {
                if (!definedEQPID.Contains(key))
                {
                    _DTError.Rows.Add(new string[] { "Error", "Initial WIP for EQP ID - " + key + " is not defined", tab, "-", "-" });
                }
            }
        }

        private void UniqueNameCheck(InputDataSet ids)
        {
            //Equipment
            Dictionary<string, string> dicNames = new Dictionary<string, string>();
            Dictionary<string, int> dicRows = new Dictionary<string, int>();
            for (int i = 0; i < ids.EquipmentDataTable.Count; i++)
            {
                string name = ids.EquipmentDataTable[i].EQP_ID;
                if (dicNames.ContainsKey(name))
                {
                    _DTError.Rows.Add(new string[] { "Error", "EQP_ID (" + name + ") must have a unique value through the model", "Equipment", (i + 1).ToString(), "EQP_ID" });
                }
                else
                {
                    dicNames.Add(name, "EQP");
                    dicRows.Add(name, i+1);
                }
            }

            //Inline Stocker
            for (int i = 0; i < ids.InlineStockerDataTable.Count; i++)
            {
                string name = ids.InlineStockerDataTable[i].STK_ID;
                if (dicNames.ContainsKey(name))
                {
                    if (dicNames[name] == "EQP")
                    {
                        _DTError.Rows.Add(new string[] { "Error", "STK_ID (" + name + ") must have a unique value through the model. However, the same value is found in the equipment", "Inline Stocker", (i + 1).ToString(), "STK_ID" });
                        _DTError.Rows.Add(new string[] { "Error", "EQP_ID(" + name + ") must have a unique value through the model. However, the same value is found in the inline stocker", "Equipment", dicRows[name].ToString(), "EQP_ID" });
                    }
                    else
                        _DTError.Rows.Add(new string[] { "Error", "STK_ID (" + name + ") must have a unique value through the model", "Inline Stocker", (i + 1).ToString(), "STK_ID" });
                }
                else
                {
                    dicNames.Add(name, "STK");
                    dicRows.Add(name, i+1);
                }
            }

            //Conveyor
            for (int i = 0; i < ids.ConveyorDataTable.Count; i++)
            {
                string name = ids.ConveyorDataTable[i].CONV_ID;
                if (dicNames.ContainsKey(name))
                {
                    if (dicNames[name] == "EQP")
                    {
                        _DTError.Rows.Add(new string[] { "Error", "CONV_ID (" + name + ") must have a unique value through the model. However, the same value is found in the equipment", "Conveyor", (i + 1).ToString(), "CONV_ID" });
                        _DTError.Rows.Add(new string[] { "Error", "EQP_ID (" + name + ") must have a unique value through the model. However, the same value is found in the conveyor", "Equipment", dicRows[name].ToString(), "EQP_ID" });
                    }
                    else if (dicNames[name] == "STK")
                    {
                        _DTError.Rows.Add(new string[] { "Error", "CONV_ID (" + name + ") must have a unique value through the model. However, the same value is found in the inline stocker", "Conveyor", (i + 1).ToString(), "CONV_ID" });
                        _DTError.Rows.Add(new string[] { "Error", "STK_ID (" + name + ") must have a unique value through the model. However, the same value is found in the conveyor", "Inline Stocker", dicRows[name].ToString(), "STK_ID" });
                    }
                    else
                        _DTError.Rows.Add(new string[] { "Error", "CONV_ID (" + name + ") must have a unique value through the model", "Conveyor", (i + 1).ToString(), "CONV_ID" });
                }
                else
                {
                    dicNames.Add(name, "CONV");
                    dicRows.Add(name, i + 1);
                }
            }
        }

        private void RouteExistCheck(InputDataSet ids)
        {
            VMS.IFS.DataModel.SimulationData.RouteData routeData = new DataModel.SimulationData.RouteData();
            Dictionary<string, object> args = new Dictionary<string, object>();
            args[VMS.IFS.DataModel.SimulationData.SimulationArguments.MCSWeightMode] = true;
            routeData.Build(ids, args);

            Dictionary<string, string> eqpOutSTK = new Dictionary<string,string>();
            Dictionary<string, string> eqpInSTK = new Dictionary<string,string>();
            for (int i = 0; i < ids.EQP_PortDataTable.Count; i++)
            {
                if (ids.EQP_PortDataTable[i].PORT_TYPE == "PI" || ids.EQP_PortDataTable[i].PORT_TYPE == "I")
                {
                    eqpInSTK.Add(ids.EQP_PortDataTable[i].EQP_ID, ids.EQP_PortDataTable[i].STK_ID);
                }
                else if (ids.EQP_PortDataTable[i].PORT_TYPE == "PO" || ids.EQP_PortDataTable[i].PORT_TYPE == "O")
                {
                    eqpOutSTK.Add(ids.EQP_PortDataTable[i].EQP_ID, ids.EQP_PortDataTable[i].STK_ID);
                }
                else
                {
                    eqpInSTK.Add(ids.EQP_PortDataTable[i].EQP_ID, ids.EQP_PortDataTable[i].STK_ID);
                    eqpOutSTK.Add(ids.EQP_PortDataTable[i].EQP_ID, ids.EQP_PortDataTable[i].STK_ID);
                }
            }

            for (int i = 0; i < ids.BOPDataTable.Count; i++)
            {
                string procID = ids.BOPDataTable[i].PROD_ID;
                string fromStepID = ids.BOPDataTable[i].FROM_STEP;
                string toStepID = ids.BOPDataTable[i].TO_STEP;

                List<string> fromEQPList = new List<string>();
                List<string> toEQPList = new List<string>();

                for (int j = 0; j < ids.LoadableSetDataTable.Count; j++)
                {
                    if (procID == ids.LoadableSetDataTable[j].PROD_ID)
                    {
                        if (fromStepID == ids.LoadableSetDataTable[j].STEP_ID)
                        {
                            fromEQPList.Add(ids.LoadableSetDataTable[j].EQP_ID);
                        }
                        else if (toStepID == ids.LoadableSetDataTable[j].STEP_ID)
                        {
                            toEQPList.Add(ids.LoadableSetDataTable[j].EQP_ID);
                        }
                    }
                }

                for (int j = 0; j < fromEQPList.Count; j++)
                {
                    string fromSTKID = "";
                    if (!eqpOutSTK.ContainsKey(fromEQPList[j]))
                        continue;
                    fromSTKID = eqpOutSTK[fromEQPList[j]];

                    for (int k = 0; k < toEQPList.Count; k++)
                    {
                        string toSTKID = "";
                        if (!eqpInSTK.ContainsKey(toEQPList[k]))
                            continue;
                        toSTKID = eqpInSTK[toEQPList[k]];

                        if (fromSTKID == toSTKID)
                            continue;

                        VMS.IFS.DataModel.SimulationData.Route route = null;
                        
                        route = routeData.Query(fromSTKID, toSTKID);

                        if (route == null)
                        {
                            _DTError.Rows.Add(new string[] { "Error", "There is no route from " + fromEQPList[j] + " to " + toEQPList[k], "-", "-", "-" });
                        }

                    }

                }
            }
        }

        /*
        private void RouteExistCheck(InputDataSet ids)
        {
            VMS.IFS.DataModel.SimulationData.RouteData routeData = new DataModel.SimulationData.RouteData();
            routeData.Build(ids, new Dictionary<string, object>());

            for (int i = 0; i < ids.BOPDataTable.Count; i++)
            {
                string procID = ids.BOPDataTable[i].PROD_ID;
                string fromStepID = ids.BOPDataTable[i].FROM_STEP;
                string toStepID = ids.BOPDataTable[i].TO_STEP;

                List<string> fromEQPList = new List<string>();
                List<string> toEQPList = new List<string>();

                for (int j = 0; j < ids.LoadableSetDataTable.Count; j++)
                {
                    if (procID == ids.LoadableSetDataTable[j].PROD_ID)
                    {
                        if (fromStepID == ids.LoadableSetDataTable[j].STEP_ID)
                        {
                            fromEQPList.Add(ids.LoadableSetDataTable[j].EQP_ID);
                        }
                        else if (toStepID == ids.LoadableSetDataTable[j].STEP_ID)
                        {
                            toEQPList.Add(ids.LoadableSetDataTable[j].EQP_ID);
                        }
                    }
                }

                for (int j = 0; j < fromEQPList.Count; j++)
                {
                    string fromSTKID = "";
                    for (int k = 0; k < toEQPList.Count; k++)
                    {
                        string toSTKID = "";

                        VMS.IFS.DataModel.SimulationData.Route route = null;

                        route = routeData.Query(fromSTKID, toSTKID);

                        if (route == null)
                        {
                            _DTError.Rows.Add(new string[] { "Route", 0, "", "There is no route from " });
                        }

                    }

                }
            }
        }*/

        #endregion

        #region Axiliary Functions
        private void SpecialCharacterCheck(string tab, DataRow dr, int i, string[] colName)
        {
            foreach (string col in colName)
            {
                if (dr[col].ToString().Contains('[') || dr[col].ToString().Contains(']') || dr[col].ToString().Contains('!') || dr[col].ToString().Contains('.')
                    || dr[col].ToString().Contains('(') || dr[col].ToString().Contains(')') || dr[col].ToString().Contains(','))
                {
                    _DTError.Rows.Add(new string[] { "Error", "The value contains special character cannot be used", tab, (i + 1).ToString(), col });
                }
            }
        }

        private void NullCheck(string tab, DataRow dr, int i, string[] colName)
        {
            foreach (string col in colName)
            {
                if (dr[col].ToString() == "")
                {
                    _DTError.Rows.Add(new string[] { "Error", "Null error", tab, (i + 1).ToString(), col });
                }
            }
        }

        private void PositiveIntParsingCheck(string tab, DataRow dr, int i, string[] colName)
        {
            foreach (string col in colName)
            {
                int temp;

                if (dr[col].ToString() != "")
                {
                    if (!int.TryParse(dr[col].ToString(), out temp))
                    {
                        _DTError.Rows.Add(new string[] { "Error", "Parsing error (int)", tab, (i + 1).ToString(), col });
                    }
                    else if (temp <= 0)
                    {
                        _DTError.Rows.Add(new string[] { "Error", "This value must be positive integer", tab, (i + 1).ToString(), col });
                    }
                }
            }
        }

        private void ZeroOneDoubleParsingCheck(string tab, DataRow dr, int i, string[] colName)
        {
            foreach (string col in colName)
            {
                double temp;

                if (dr[col].ToString() != "")
                {
                    if (!double.TryParse(dr[col].ToString(), out temp))
                    {
                        _DTError.Rows.Add(new string[] { "Error", "Parsing error (double)", tab, (i + 1).ToString(), col });
                    }
                    else if (temp <= 0 || temp > 1)
                    {
                        _DTError.Rows.Add(new string[] { "Error", "This value must be in (0, 1]", tab, (i + 1).ToString(), col });
                    }
                }
            }
        }

        private void NotNegativeDoubleParsingCheck(string tab, DataRow dr, int i, string[] colName)
        {
            foreach (string col in colName)
            {
                double temp;

                if (dr[col].ToString() != "")
                {
                    if (!double.TryParse(dr[col].ToString(), out temp))
                    {
                        _DTError.Rows.Add(new string[] { "Error", "Parsing error (double)", tab, (i + 1).ToString(), col });
                    }
                    else if (temp < 0)
                    {
                        _DTError.Rows.Add(new string[] { "Error", "This value must be greater than or equal to 0", tab, (i + 1).ToString(), col });
                    }
                }
            }
        }

        #endregion

    }
}
