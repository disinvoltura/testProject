﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using VMS.Foundation.Logging;

namespace VMS.IFS.UI
{
    public partial class OutputWindow : DockContent
    {
        private InputEditor _Parent;

        TextBoxLogHandler2 handler1; 
        TextBoxLogHandler2 handler2;
        TextBoxLogHandler2 handler3;
        TextBoxLogHandler2 handler4;
 
        public OutputWindow(InputEditor parent)
        {
            Form.CheckForIllegalCrossThreadCalls = false;
            _Parent = parent;
            InitializeComponent();
        }

        public void ConnectAllLogHandlers()
        {
            VMS.Foundation.Logging.SimpleFormatter formatter =
                new VMS.Foundation.Logging.SimpleFormatter();
            formatter.WriteLoggerInfo = false;

            formatter.WriteTimeStamp = false;
            Logger logger1 = LogManager.GetLogger("SimulationCoordinator");
            logger1.Level = LogLevel.Always;

            handler1 =
                new TextBoxLogHandler2(txtGeneral, formatter);
            logger1.AddHandler(handler1);

            Logger logger2 = LogManager.GetLogger("JobSelectionRule");
            logger2.Level = LogLevel.Always;

            handler2 =
                new TextBoxLogHandler2(txtJSR, formatter);
            logger2.AddHandler(handler2);

            Logger logger3 = LogManager.GetLogger("MachineSelectionRule");
            logger3.Level = LogLevel.Always;

            handler3 =
                new TextBoxLogHandler2(txtMSR, formatter);
            logger3.AddHandler(handler3);

            Logger logger4 = LogManager.GetLogger("Communication");
            logger4.Level = LogLevel.Always;

            handler4 =
                new TextBoxLogHandler2(txtCom, formatter);
            logger4.AddHandler(handler4);
            
            txtGeneral.Visible = true;
            txtJSR.Visible = false;
            txtMSR.Visible = false;
            txtCom.Visible = false;
        }

        public void ConnectGeneralLogHandler()
        {
            VMS.Foundation.Logging.SimpleFormatter formatter =
                new VMS.Foundation.Logging.SimpleFormatter();
            formatter.WriteLoggerInfo = false;

            formatter.WriteTimeStamp = false;
            Logger logger1 = LogManager.GetLogger("SimulationCoordinator");
            logger1.Level = LogLevel.Always;

            handler1 =
                new TextBoxLogHandler2(txtGeneral, formatter);
            logger1.AddHandler(handler1);

            txtGeneral.Visible = true;
            txtJSR.Visible = false;
            txtMSR.Visible = false;
            txtCom.Visible = false;
        }

        public void DisconnectLogHandlers()
        {
            Logger logger1 = LogManager.GetLogger("SimulationCoordinator");
            Logger logger2 = LogManager.GetLogger("JobSelectionRule");
            Logger logger3 = LogManager.GetLogger("MachineSelectionRule");
            Logger logger4 = LogManager.GetLogger("Communication");

            logger1.RemoveHandler(handler1);
            logger2.RemoveHandler(handler2);
            logger3.RemoveHandler(handler3);
            logger4.RemoveHandler(handler4);
        }

        private void cbOutputSources_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbOutputSources.SelectedIndex == 0)
            {
                txtGeneral.Visible = true;
                txtJSR.Visible = false;
                txtMSR.Visible = false;
                txtCom.Visible = false;
            }
            else if (cbOutputSources.SelectedIndex == 1)
            {
                txtGeneral.Visible = false;
                txtJSR.Visible = true;
                txtMSR.Visible = false;
                txtCom.Visible = false;
            }
            else if (cbOutputSources.SelectedIndex == 2)
            {
                txtGeneral.Visible = false;
                txtJSR.Visible = false;
                txtMSR.Visible = true;
                txtCom.Visible = false;
            }
            else if (cbOutputSources.SelectedIndex == 3)
            {
                txtGeneral.Visible = false;
                txtJSR.Visible = false;
                txtMSR.Visible = false;
                txtCom.Visible = true;
            }
        }

        public void Clear()
        {
            txtGeneral.Text = "";
            txtJSR.Text = "";
            txtMSR.Text = "";
            txtCom.Text = "";
        }
    }
}