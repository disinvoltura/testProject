﻿namespace VMS.IFS.UI
{
    partial class OutputWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtGeneral = new System.Windows.Forms.TextBox();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.txtMSR = new System.Windows.Forms.TextBox();
            this.txtJSR = new System.Windows.Forms.TextBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.cbOutputSources = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.txtCom = new System.Windows.Forms.TextBox();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtGeneral
            // 
            this.txtGeneral.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtGeneral.Location = new System.Drawing.Point(0, 0);
            this.txtGeneral.Multiline = true;
            this.txtGeneral.Name = "txtGeneral";
            this.txtGeneral.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtGeneral.Size = new System.Drawing.Size(750, 301);
            this.txtGeneral.TabIndex = 0;
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this.txtCom);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.txtMSR);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.txtJSR);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.txtGeneral);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(750, 301);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(750, 326);
            this.toolStripContainer1.TabIndex = 1;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip1);
            // 
            // txtMSR
            // 
            this.txtMSR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtMSR.Location = new System.Drawing.Point(0, 0);
            this.txtMSR.Multiline = true;
            this.txtMSR.Name = "txtMSR";
            this.txtMSR.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtMSR.Size = new System.Drawing.Size(750, 301);
            this.txtMSR.TabIndex = 2;
            // 
            // txtJSR
            // 
            this.txtJSR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtJSR.Location = new System.Drawing.Point(0, 0);
            this.txtJSR.Multiline = true;
            this.txtJSR.Name = "txtJSR";
            this.txtJSR.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtJSR.Size = new System.Drawing.Size(750, 301);
            this.txtJSR.TabIndex = 1;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.cbOutputSources,
            this.toolStripSeparator1});
            this.toolStrip1.Location = new System.Drawing.Point(3, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(255, 25);
            this.toolStrip1.TabIndex = 0;
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(114, 22);
            this.toolStripLabel1.Text = "Show output from: ";
            // 
            // cbOutputSources
            // 
            this.cbOutputSources.Items.AddRange(new object[] {
            "General",
            "Job Selection Rule",
            "Machine Selection Rule",
            "Communication"});
            this.cbOutputSources.Name = "cbOutputSources";
            this.cbOutputSources.Size = new System.Drawing.Size(121, 25);
            this.cbOutputSources.Text = "General";
            this.cbOutputSources.SelectedIndexChanged += new System.EventHandler(this.cbOutputSources_SelectedIndexChanged);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // txtCom
            // 
            this.txtCom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCom.Location = new System.Drawing.Point(0, 0);
            this.txtCom.Multiline = true;
            this.txtCom.Name = "txtCom";
            this.txtCom.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtCom.Size = new System.Drawing.Size(750, 301);
            this.txtCom.TabIndex = 3;
            // 
            // Output
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(750, 326);
            this.Controls.Add(this.toolStripContainer1);
            this.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Output";
            this.Text = "Output";
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.ContentPanel.PerformLayout();
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtGeneral;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripComboBox cbOutputSources;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.TextBox txtMSR;
        private System.Windows.Forms.TextBox txtJSR;
        private System.Windows.Forms.TextBox txtCom;
    }
}