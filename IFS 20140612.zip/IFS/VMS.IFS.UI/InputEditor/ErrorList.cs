﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace VMS.IFS.UI
{
    public partial class ErrorWindow : DockContent
    {
        private InputEditor _Parent;
        private RowSelectedEvent _RowSelectedController;

        public ErrorWindow(InputEditor parent)
        {
            _Parent = parent;
            InitializeComponent();

            _RowSelectedController = new RowSelectedEvent(_Parent);
            grid.Controller.AddController(_RowSelectedController);
        }

        public void LoadData(DataView view)
        {            
            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            grid.DataSource = new DevAge.ComponentModel.BoundDataView(view);
            //grid.Controller.AddController(valueChangedController);

            for (int i = 0; i < grid.Columns.Count; i++)
            {
                grid.Columns[i].HeaderCell.View = titleModel;
                grid.Columns[i].MinimalWidth = (grid.Columns[0].PropertyName.Length + 5) * (int)grid.Font.Size;
                //grid.Columns[i].AutoSizeMode = SourceGrid.AutoSizeMode.

                grid.Columns[i].DataCell.Editor.EditableMode = SourceGrid.EditableMode.None;
            }
            

            grid.MinimumHeight = 20;
            //grid.AutoStretchColumnsToFitWidth = true;
            grid.AutoSizeCells();
        }
    }

    public class RowSelectedEvent : SourceGrid.Cells.Controllers.ControllerBase
    {
        private InputEditor _Parent;
        public RowSelectedEvent(InputEditor parent)
        {
            _Parent = parent;
        }

        public override void OnDoubleClick(SourceGrid.CellContext sender, EventArgs e)
        {
            base.OnDoubleClick(sender, e);

            SourceGrid.DataGrid grid = (SourceGrid.DataGrid)sender.Grid;
            DataRowView drView = (DataRowView)grid.SelectedDataRows[0];

            string sheetName = drView[0].ToString();
            string sRow = drView[1].ToString();
            string sCol = drView[2].ToString();
            int row = 0;
            if (!int.TryParse(sRow, out row))
                row = 0;
            
            _Parent.GoTo(sheetName, row, sCol);            
        }
    }
}
