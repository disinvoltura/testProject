﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.UI
{
    public static class Util
    {
        public static string GetShortFileName(string fileName)
        {
            string shortFileName = fileName;

            int count = shortFileName.Count(f => f == '\\');
            if (count > 3)
            {
                shortFileName = fileName.Substring(0, fileName.IndexOf('\\') + 1);
                string tmp = fileName.Substring(0, fileName.LastIndexOf('\\'));
                shortFileName += "..." + tmp.Substring(tmp.LastIndexOf('\\')) + fileName.Substring(fileName.LastIndexOf('\\'));
            }

            return shortFileName;
        }
    }
}
