﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Threading.Tasks;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.DataModel.OutputData;
using VMS.IFS.Simulation;

namespace VMS.IFS.UI
{
    public partial class SimulationProgress : Form
    {
        //private SimulationRunner _Runner;
        private Task _RunTask;
        private Task _MonitorTask;
        private CancellationTokenSource _CancelSource;
        private SimulationRunner _Runner;
        private OutputDataSet _ODS;
        public OutputDataSet OutputData
        {
            get { return _ODS; }
        }

        public SimulationProgress(string id,
            VMS.IFS.DataModel.InputData.InputDataSet ids,
            Dictionary<string, object> runOptions)
        {
            InitializeComponent();

            doRun(id, ids, runOptions);
        }

        private void doRun(string id,
            VMS.IFS.DataModel.InputData.InputDataSet ids,
            Dictionary<string, object> runOptions)
        {
            _CancelSource = new CancellationTokenSource();

            CancellationToken token = _CancelSource.Token;
            
            _RunTask = Task.Factory.StartNew(() =>
            {
                doParallelRun(id, ids, runOptions);
            },token);

            double eosTime = (double)runOptions[SimulationArguments.EOSTime];

            _MonitorTask = Task.Factory.StartNew(() =>
            {
                while (true)
                {
                    Thread.Sleep(500);

                    double progress = _Runner.Factory.Clock / eosTime * 100;
                    progress = Math.Round(progress);
                    progressBar1.Value = (int)progress;

                    if (progress == 100)
                        break;
                }
            }, token);
        }

       //private AppDomain _AD;
        private void doParallelRun(
            string id,
            VMS.IFS.DataModel.InputData.InputDataSet ids,
            Dictionary<string, object> runOptions)
        {
            DateTime dt1 = DateTime.Now;
            _Runner = new SimulationRunner(id, ids, runOptions);
            _Runner.Run();
            _ODS = _Runner.OutputReportGenerator.Transduce();
            DateTime dt2 = DateTime.Now;
            //System.Diagnostics.Debug.WriteLine("Simulation Execution Time with transducing the output data: " + dt2.Subtract(dt1).TotalSeconds);
            _Runner.Dispose();
            
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }
        /*
        private void doParallelRun(
            string id,
            VMS.IFS.DataModel.InputData.InputDataSet ids,
            Dictionary<string, object> runOptions)
        {
            using (SimulationRunner runner = new SimulationRunner(id, ids, runOptions))
            {
                runner.Run();
                DateTime dt1 = DateTime.Now;
                _ODS = runner.OutputReportGenerator.Transduce();
                DateTime dt2 = DateTime.Now;
                System.Diagnostics.Debug.WriteLine("Time to Transduce the output data: " + dt2.Subtract(dt1).TotalSeconds);
                // runner.Dispose();
            }

            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }*/

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            _CancelSource.Cancel();
        }
    }
}
