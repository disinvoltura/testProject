﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Threading.Tasks;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.DataModel.OutputData;
using VMS.IFS.Engine.ApplicationConnection;
using VMS.IFS.Simulation;

namespace VMS.IFS.UI
{
    public partial class SimulationProgressWithApplication : Form
    {
        public bool ShowResult = true;
        private SimulationRunner _Runner;
        private Task _RunTask;
        private Task _MonitorTask;
        private CancellationTokenSource _CancelSource;

        public OutputDataSet _ODS;

        public OutputDataSet OutputData
        {
            get { return _ODS; }
        }
        //public SimulationRunner Runner
        //{
        //    get { return _Runner; }
        //}

        public SimulationProgressWithApplication(string id,
            VMS.IFS.DataModel.InputData.InputDataSet ids,
            Dictionary<string, object> runOptions)
        {
            InitializeComponent();

            doRun(id, ids, runOptions);
        }

        private void doRun(string id,
            VMS.IFS.DataModel.InputData.InputDataSet ids,
            Dictionary<string, object> runOptions)
        {          
            _CancelSource = new CancellationTokenSource();

            CancellationToken token = _CancelSource.Token;

            _RunTask = Task.Factory.StartNew(() =>
            {
                doParallelRun(id, ids, runOptions);
            },token);

            double eosTime = (double)runOptions[SimulationArguments.EOSTime];

            _MonitorTask = Task.Factory.StartNew(() =>
            {
                while (true)
                {
                    Thread.Sleep(500);

                    //double progress = _Runner.Factory.Clock / eosTime * 100;
                    //progress = Math.Round(progress);
                    //progressBar1.Value = (int)progress;

                    //if (progress == 100)
                    //    break;
                }
            }, token);
        }

        private void doParallelRun(
            string id,
            VMS.IFS.DataModel.InputData.InputDataSet ids,
            Dictionary<string, object> runOptions)
        {
            using (SimulationRunner runner = new SimulationRunner(id, ids, runOptions))
            {
                ApplicationConnector.ClientDisconnected += new ClientDisconnectedEventHandler(ApplicationConnector_ClientDisconnected);
                try
                {
                    runner.Run();

                    _ODS = runner.OutputReportGenerator.Transduce();

                    ApplicationConnector.Close();

                    this.DialogResult = System.Windows.Forms.DialogResult.OK;
                }
                catch (System.Net.Sockets.SocketException ex)
                {
                    if (ex.ErrorCode == 10053)
                    {
                        MessageBox.Show("The connection is aborted by the application.");
                    }
                    ShowResult = false;
                    this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
                }
                ApplicationConnector.ClientDisconnected -= new ClientDisconnectedEventHandler(ApplicationConnector_ClientDisconnected);

                this.Close();
            }
        }

        private void ApplicationConnector_ClientDisconnected()
        {
            //_Runner.Stop();
            ApplicationConnector.Close();

            _CancelSource.Cancel();

            MessageBox.Show("Simulation run is aborted because of the application is disconnected.");
            ShowResult = false;
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ApplicationConnector.Send_Msg("Simulation End!");
            ApplicationConnector.Close();
            
            _CancelSource.Cancel();
            
            ShowResult = false;
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }
    }
}
