﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.DataModel.InputData;
using VMS.IFS.DataModel.DispatchingRuleData;

namespace VMS.IFS.UI
{
    public partial class SingleRunOption : Form
    {
        #region Member Variables
        public InputDataSet ids;
        private double EOSTime;
        private bool isEOSTime;
        private string EOSTimeUnit;//Days, Hours, Minutes, Seconds
        private List<string> lstLoadableSet;
        private string selectedLoadableSet;
        private int shift;

        private bool IsWeightOnConveyTime;
        private string selectedWeightSet;
        private int vqCapa;

        private List<string> _StepList;
        private List<string> _MCSWeightSet;
        public int SimulationMode = -1; //0: Run, 1: AutoMod, 2: Save
        private DateTime firstFO;

        private int interReleaseTime; //in Seconds
        #endregion

        #region Properties
        public Dictionary<string, object> RunOptions
        {
            get
            {
                Dictionary<string, object> args = new Dictionary<string, object>();
                args.Add(SimulationArguments.RandomSeed, DateTime.Now.Second);
                args.Add(SimulationArguments.LoadableEQPVersionNo, selectedLoadableSet);

                if (isEOSTime)
                {
                    args.Add(SimulationArguments.EOSMode, "Time");
                    args.Add(SimulationArguments.EOSTime, this.EOSTime); //saved in seconds
                    args.Add(SimulationArguments.EOSTimeUnit, this.EOSTimeUnit);
                }
                else
                {
                    args.Add(SimulationArguments.EOSMode, "Event");
                    args.Add(SimulationArguments.EOSTime, double.MaxValue);                    
                }

                //Data Collection
                args.Add(SimulationArguments.StartTime, dateTimePicker1.Value);
                args.Add(SimulationArguments.UnitTime, this.shift);
                //args.Add(SimulationArguments.SaveWIPTime, this.saveWIPTime);

                //dispatching rule
                args.Add(SimulationArguments.JobSelectionRule, _JSR);
                if (_JSR != null && _JSR.Parameters.Count<DRParameter>() > 0)
                {
                    for (int i = 1; i < gJSRParams.Columns.Count; i++)
                    {
                        args.Add("JSR_" + gJSRParams[0, i].DisplayText, gJSRParams[1, i].DisplayText);
                    }
                }

                args.Add(SimulationArguments.MachineSelectionRule, _MSR);
                if (_MSR != null && _MSR.Parameters.Count<DRParameter>() > 0)
                {
                    for (int i = 1; i < gMSRParams.Columns.Count; i++)
                    {
                        args.Add("MSR_" + gMSRParams[0, i].DisplayText, gMSRParams[1, i].DisplayText);
                    }
                }

                args.Add(SimulationArguments.Logging, checkBox1.Checked);

                //Start Time
                args.Add(SimulationArguments.ReferenceDateTime, dateTimePicker1.Value);

                //Kanban
                args.Add(SimulationArguments.KanbanFabWIP, int.Parse(txtFWK.Text));
                if(string.IsNullOrEmpty(txtTSK.Text))
                    args.Add(SimulationArguments.KanbanStepWIP, 0);
                else
                    args.Add(SimulationArguments.KanbanStepWIP, int.Parse(txtTSK.Text));
                args.Add(SimulationArguments.KanbanStepID, cbSteps.Text);
                

                //Virtual Queue
                args.Add(SimulationArguments.VQCapacity, vqCapa);

                //MCS
                args.Add(SimulationArguments.MCSWeightMode, IsWeightOnConveyTime);
                if (!IsWeightOnConveyTime)
                args.Add(SimulationArguments.MCSWeightSet, selectedWeightSet);

                //Cassette Releasing
                args.Add(SimulationArguments.InterReleaseTime, interReleaseTime);

                return args;
            }
        }
        #endregion

        #region Constructor
        public SingleRunOption(InputDataSet ids, List<string> lstLoadableSet)
        {
            InitializeComponent();

            initializeRunButton();

            this.ids = ids;
            this.lstLoadableSet = new List<string>();
            this.lstLoadableSet = lstLoadableSet;
            this.firstFO = GetFirstFabOutDate();

            loadData();
        }

        private void initializeRunButton()
        {
            DevAge.Windows.Forms.SubButtonItem item1 = new DevAge.Windows.Forms.SubButtonItem("Run", new EventHandler(RunButtonClicked));
            DevAge.Windows.Forms.SubButtonItem item2 = new DevAge.Windows.Forms.SubButtonItem("Run with VIP", new EventHandler(RunWithAutoModButtonClicked));
            buttonMultiSelection1.ButtonsItems.Add(item1);
            buttonMultiSelection1.ButtonsItems.Add(item2);
        }

        public SingleRunOption(InputDataSet ids, List<string> lstLoadableSet, Dictionary<string, object> runOptions)
        {
            InitializeComponent();
            initializeRunButton();

            this.ids = ids;
            this.lstLoadableSet = new List<string>();
            this.lstLoadableSet = lstLoadableSet;
            this.firstFO = GetFirstFabOutDate();

            loadData();

            loadRunOptions(runOptions);
        }

        public DateTime GetFirstFabOutDate()
        {
            string year = ids.FabOutPlanDataTable.Rows[0][0].ToString().Substring(0, 4);
            string month = ids.FabOutPlanDataTable.Rows[0][0].ToString().Substring(4, 2);
            string day = ids.FabOutPlanDataTable.Rows[0][0].ToString().Substring(6, 2);

            DateTime rslt = new DateTime(int.Parse(year), int.Parse(month), int.Parse(day));

            foreach (DataRow dr in ids.FabOutPlanDataTable.Rows)
            {
                string year2 = dr[0].ToString().Substring(0, 4);
                string month2 = dr[0].ToString().Substring(4, 2);
                string day2 = dr[0].ToString().Substring(6, 2);

                DateTime temp = new DateTime(int.Parse(year2), int.Parse(month2), int.Parse(day2));

                if (temp < rslt)
                {
                    rslt = new DateTime(temp.Year, temp.Month, temp.Day);
                }
            }

            return rslt;
        }

        private void loadRunOptions(Dictionary<string, object> runOptions)
        {
            string eosMode = (string) runOptions[SimulationArguments.EOSMode];

            if (eosMode == "Time")
            {
                isEOSTime = true;
                rb_EOSTime.Checked = true;
                rb_End.Checked = false;

                double eosTimeInSecs = (double)runOptions[SimulationArguments.EOSTime];
                string eosTimeUnit = ((string)runOptions[SimulationArguments.EOSTimeUnit]).ToLower();
                double eosTime = 0;
                if (eosTimeUnit == "days")
                {
                    eosTime = eosTimeInSecs / 86400;
                }else if (eosTimeUnit == "hours")
                {
                    eosTime = eosTimeInSecs / 3600;
                }else if (eosTimeUnit == "minutes")
                {
                    eosTime = eosTimeInSecs / 60;
                }
                //Days, Hours, Minutes, Seconds

                tb_EOSTime.Text = eosTime.ToString();

                cbTimeUnit.SelectedItem = runOptions[SimulationArguments.EOSTimeUnit].ToString();
            }
            else
            {
                isEOSTime = false;
                rb_EOSTime.Checked = false;
                rb_End.Checked = true;
            }

            this.shift = (int)runOptions[SimulationArguments.UnitTime];
            tb_Shift.Text = shift.ToString();
            dateTimePicker1.Value = (DateTime)runOptions[SimulationArguments.StartTime];

            txtFWK.Text = runOptions[SimulationArguments.KanbanFabWIP].ToString();
            cbSteps.SelectedItem = (string)runOptions[SimulationArguments.KanbanStepID];
            cbSteps.Text = (string)runOptions[SimulationArguments.KanbanStepID];
            txtTSK.Text = runOptions[SimulationArguments.KanbanStepWIP].ToString();

            cb_LoadableSet.SelectedItem = (string)runOptions[SimulationArguments.LoadableEQPVersionNo];
            cb_LoadableSet.Text = (string)runOptions[SimulationArguments.LoadableEQPVersionNo];

            //dispatching rule
            _JSR = (DispatchingRuleDefinition) runOptions[SimulationArguments.JobSelectionRule];
            txtJSR.Text = _JSR.Name;
            showJSRWeight(_JSR, runOptions);

            _MSR = (DispatchingRuleDefinition)runOptions[SimulationArguments.MachineSelectionRule];
            txtMSR.Text = _MSR.Name;
            showMSRWeight(_MSR, runOptions);
            
            bool logging = (bool)runOptions[SimulationArguments.Logging];
            checkBox1.Checked = logging;

            IsWeightOnConveyTime = (bool)runOptions[SimulationArguments.MCSWeightMode];
            if (IsWeightOnConveyTime)
            {
                rb_WeightConv.Checked = true;
                rb_WeightUsers.Checked = false;
            }
            else
            {
                rb_WeightConv.Checked = false;
                rb_WeightUsers.Checked = true;

                cbWeightVersion.SelectedItem = (string) runOptions[SimulationArguments.MCSWeightSet];
                cbWeightVersion.Text = (string) runOptions[SimulationArguments.MCSWeightSet];
            }

            //inter release time
            interReleaseTime = (int)runOptions[SimulationArguments.InterReleaseTime] / 3600;
            txtInterReleaseTime.Text = interReleaseTime.ToString();
        }

        private void loadData()
        {
            foreach (string version in lstLoadableSet)
            {
                cb_LoadableSet.Items.Add(version);
            }

            _StepList = new List<string>();
            foreach (InputDataSet.BOPDataTableRow row in ids.BOPDataTable.Rows)
            {
                if (!_StepList.Contains(row.FROM_STEP))
                    _StepList.Add(row.FROM_STEP);

                if (!_StepList.Contains(row.TO_STEP))
                    _StepList.Add(row.TO_STEP);
            }

            foreach (string stepid in _StepList)
            {
                cbSteps.Items.Add(stepid);
            }

            //MCS Weight Set
            _MCSWeightSet = new List<string>();
            foreach (InputDataSet.MCSWeightSetDataTableRow row in ids.MCSWeightSetDataTable.Rows)
            {
                if (row.IsVERSION_NONull())
                    continue;

                if (!_MCSWeightSet.Contains(row.VERSION_NO))
                {
                    _MCSWeightSet.Add(row.VERSION_NO);
                    cbWeightVersion.Items.Add(row.VERSION_NO);
                }
            }
        }

        #endregion

        #region Event Handling

        private void rb_EOSTime_CheckedChanged(object sender, EventArgs e)
        {
            tb_EOSTime.Enabled = true;
            isEOSTime = true;
        }

        private void rb_End_CheckedChanged(object sender, EventArgs e)
        {
            tb_EOSTime.Enabled = false;
            isEOSTime = false;
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtInterReleaseTime.Text.ToString(), out interReleaseTime))
            {
                MessageBox.Show(this, "Please enter a valid value in a field of inter release time (int type).", "Error", MessageBoxButtons.OK);
                return;
            }

            if (rb_EOSTime.Checked)
            {
                if (!double.TryParse(tb_EOSTime.Text.ToString(), out EOSTime))
                {
                    MessageBox.Show(this, "Please enter number in EOS Time field (double type).", "Error", MessageBoxButtons.OK);
                    return;
                }

                isEOSTime = true;
                string timeUnit = cbTimeUnit.Text.ToLower();
                if (timeUnit == "days")
                {
                    EOSTime = EOSTime * 24 * 3600;
                }
                else if (timeUnit == "hours")
                {
                    EOSTime = EOSTime * 3600;
                }
                else if (timeUnit == "minutes")
                {
                    EOSTime = EOSTime * 60;
                }

                this.EOSTimeUnit = cbTimeUnit.Text;
            }
            else
            {
                isEOSTime = false;
            }

            if (dateTimePicker1.Value.Date > firstFO.Date)
            {
                MessageBox.Show(this, "Please select Start Time before first Fab out date in input data.", "Error", MessageBoxButtons.OK);
                return;
            }

            if (cb_LoadableSet.SelectedItem == null)
            {
                MessageBox.Show(this, "Please select Loadable Set.", "Error", MessageBoxButtons.OK);
                return;
            }

            selectedLoadableSet = cb_LoadableSet.SelectedItem.ToString();

            if (!int.TryParse(tb_Shift.Text.ToString(), out shift))
            {
                MessageBox.Show(this, "Please enter number in Unit Data Collection Time field (int type).", "Error", MessageBoxButtons.OK);
                return;
            }

            if (_JSR == null || _MSR == null)
            {
                MessageBox.Show(this, "Please select a job selection rule and a machine selection rule.", "Error", MessageBoxButtons.OK);
                return;
            }

            //Virtual Queue Capacity
            vqCapa = (int)txtVQCapa.Value;

            //MCS Weight
            if (rb_WeightConv.Checked)
            {
                IsWeightOnConveyTime = true;
            }
            else
            {
                IsWeightOnConveyTime = false;

                if (cbWeightVersion.SelectedItem == null)
                    return;

                selectedWeightSet = cbWeightVersion.SelectedItem.ToString();
            }

            //Inter-release time
            this.interReleaseTime = int.Parse(txtInterReleaseTime.Text) * 3600;

            // 시뮬레이션 실행 메소드 추가 필요
            this.SimulationMode = 2;
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }

        private void RunButtonClicked(object sender, EventArgs e)
        {
            handleRunRequest();
        }

        private void RunWithAutoModButtonClicked(object sender, EventArgs e)
        {
            handleRunWithAutoModRequest();
        }

        private void handleRunWithAutoModRequest()
        {
            if (doValidate())
            {
                // 시뮬레이션 실행 메소드 추가 필요
                this.SimulationMode = 1;
                this.DialogResult = System.Windows.Forms.DialogResult.None;
                this.Close();
            }
        }

        private void btn_Run_Click(object sender, EventArgs e)
        {
            handleRunRequest();
        }

        private bool doValidate()
        {
            if (!int.TryParse(txtInterReleaseTime.Text.ToString(), out interReleaseTime))
            {
                MessageBox.Show(this, "Please enter a valid value in a field of inter release time (int type).", "Error", MessageBoxButtons.OK);
                return false;
            }

            if (rb_EOSTime.Checked)
            {
                if (!double.TryParse(tb_EOSTime.Text.ToString(), out EOSTime))
                {
                    MessageBox.Show(this, "Please enter number in EOS Time field (double type).", "Error", MessageBoxButtons.OK);
                    return false;
                }

                isEOSTime = true;
                string timeUnit = cbTimeUnit.Text.ToLower();
                if (timeUnit == "days")
                {
                    EOSTime = EOSTime * 24 * 3600;
                }
                else if (timeUnit == "hours")
                {
                    EOSTime = EOSTime * 3600;
                }
                else if (timeUnit == "minutes")
                {
                    EOSTime = EOSTime * 60;
                }
                this.EOSTimeUnit = cbTimeUnit.Text;
            }
            else
            {
                isEOSTime = false;
            }

            if (dateTimePicker1.Value.Date > firstFO.Date)
            {
                MessageBox.Show(this, "Please select Start Time before first Fab out date in input data.", "Error", MessageBoxButtons.OK);
                return false;
            }

            if (cb_LoadableSet.SelectedItem == null)
            {
                MessageBox.Show(this, "Please select Loadable Set.", "Error", MessageBoxButtons.OK);
                return false;
            }

            selectedLoadableSet = cb_LoadableSet.SelectedItem.ToString();

            if (!int.TryParse(tb_Shift.Text.ToString(), out shift))
            {
                MessageBox.Show(this, "Please enter number in Unit Data Collection Time field (int type).", "Error", MessageBoxButtons.OK);
                return false;
            }

            if (_JSR == null || _MSR == null)
            {
                MessageBox.Show(this, "Please select a job selection rule and a machine selection rule.", "Error", MessageBoxButtons.OK);
                return false;
            }

            //Virtual Queue Capacity
            vqCapa = (int)txtVQCapa.Value;

            //MCS Weight
            if (rb_WeightConv.Checked)
            {
                IsWeightOnConveyTime = true;
            }
            else
            {
                IsWeightOnConveyTime = false;

                if (cbWeightVersion.SelectedItem == null)
                    return false;

                selectedWeightSet = cbWeightVersion.SelectedItem.ToString();
            }

            if (!string.IsNullOrEmpty(cbSteps.Text))
            {
                if (string.IsNullOrEmpty(txtTSK.Text))
                    return false;
            }

            //Inter-release time
            this.interReleaseTime = int.Parse(txtInterReleaseTime.Text) * 3600;

            return true;
        }

        private void handleRunRequest()
        {
            if (doValidate())
            {
                // 시뮬레이션 실행 메소드 추가 필요
                this.DialogResult = System.Windows.Forms.DialogResult.Abort;
                this.SimulationMode = 0;
                this.Close();
            }
        }
        
        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        #endregion                                

        #region Job Selection Rule Methods
        private DispatchingRuleDefinition _JSR;
        private DispatchingRuleDefinition _MSR;

        private void btnSelectJSR_Click(object sender, EventArgs e)
        {
            DispatchingRuleSelector dialog = new DispatchingRuleSelector(DispatchingRuleType.JobSelectionRule);
            DialogResult rslt = dialog.ShowDialog();

            if (rslt == System.Windows.Forms.DialogResult.OK)
            {
                _JSR = dialog.SelectedDispatchingRule;
                
                //Name
                txtJSR.Text = _JSR.Name;

                //Parameters
                showJSRWeight(_JSR, new Dictionary<string,object>());
            }
        }

        private void showJSRWeight(DispatchingRuleDefinition jsr, Dictionary<string, object> runOptions)
        {
            int pCount = jsr.Parameters.Count<DRParameter>();
            if (pCount > 0)
            {
                //Headers
                gJSRParams.Rows.Clear();
                gJSRParams.Columns.Clear();

                gJSRParams.Redim(2, pCount + 1);
                gJSRParams.FixedRows = 1;

                SourceGrid.Cells.Header l_00Header = new SourceGrid.Cells.Header(null);
                gJSRParams[0, 0] = l_00Header;
                gJSRParams[1, 0] = new SourceGrid.Cells.RowHeader(null);

                SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
                DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
                backHeader.BackColor = Color.Lavender;
                backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
                titleModel.Background = backHeader;
                titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

                int colCount = 1;
                foreach (DRParameter p in jsr.Parameters)
                {
                    SourceGrid.Cells.ColumnHeader header =
                         new SourceGrid.Cells.ColumnHeader(p.Name);

                    header.View = titleModel;
                    gJSRParams[0, colCount] = header;

                    string key = "JSR_" + p.Name;
                    string pValue = "1";
                    if (runOptions.ContainsKey(key))
                        pValue = runOptions[key].ToString();

                    SourceGrid.Cells.Cell pCell = new SourceGrid.Cells.Cell(pValue, typeof(string));
                    pCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
                    gJSRParams[1, colCount] = pCell;

                    colCount++;
                }
            }
        }
        #endregion

        #region Machine Selection Rule Methods
        private void btnSelectMSR_Click(object sender, EventArgs e)
        {
            DispatchingRuleSelector dialog = new DispatchingRuleSelector(DispatchingRuleType.MachineSelectionRule);
            DialogResult rslt = dialog.ShowDialog();

            if (rslt == System.Windows.Forms.DialogResult.OK)
            {
                _MSR = dialog.SelectedDispatchingRule;

                //Name
                txtMSR.Text = _MSR.Name;

                //Parameters
                showMSRWeight(_MSR, new Dictionary<string,object>());
            }
        }

        private void showMSRWeight(DispatchingRuleDefinition msr, Dictionary<string, object> runOptions)
        {
            int pCount = msr.Parameters.Count<DRParameter>();
            if (pCount > 0)
            {
                //Headers
                gMSRParams.Rows.Clear();
                gMSRParams.Columns.Clear();

                gMSRParams.Redim(2, pCount + 1);
                gMSRParams.FixedRows = 1;

                SourceGrid.Cells.Header l_00Header = new SourceGrid.Cells.Header(null);
                gMSRParams[0, 0] = l_00Header;
                gMSRParams[1, 0] = new SourceGrid.Cells.RowHeader(null);

                SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
                DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
                backHeader.BackColor = Color.Lavender;
                backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
                titleModel.Background = backHeader;
                titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

                int colCount = 1;
                foreach (DRParameter p in msr.Parameters)
                {
                    SourceGrid.Cells.ColumnHeader header =
                         new SourceGrid.Cells.ColumnHeader(p.Name);

                    header.View = titleModel;
                    gMSRParams[0, colCount] = header;

                    string key = "MSR_" + p.Name;
                    string pValue = "1";
                    if (runOptions.ContainsKey(key))
                        pValue = runOptions[key].ToString();

                    SourceGrid.Cells.Cell pCell = new SourceGrid.Cells.Cell(pValue, typeof(string));
                    pCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
                    gMSRParams[1, colCount] = pCell;

                    colCount++;
                }
            }
        }
        #endregion                
    }
}
