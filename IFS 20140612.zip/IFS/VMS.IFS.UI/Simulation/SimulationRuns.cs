﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using VMS.Foundation.Logging;
using System.Threading;
using System.Threading.Tasks;

namespace VMS.IFS.UI
{
    public partial class SimulationRunWindow : DockContent
    {
        private InputEditor _Parent;

        private Dictionary<string, OutputViewer> _ODS;
        
        private Dictionary<string, SourceGrid.Cells.Cell> _ProgressCells;

        public OutputViewer this[string name]
        {
            get
            {
                OutputViewer rslt = null;
                if (_ODS.ContainsKey(name))
                    rslt = _ODS[name];
                return rslt;

            }
        }

        public SimulationRunWindow(InputEditor parent)
        {
            Form.CheckForIllegalCrossThreadCalls = false;
            _Parent = parent;
            _ODS = new Dictionary<string, OutputViewer>();

            InitializeComponent();

            drawHeaders();

            _ProgressCells = new Dictionary<string, SourceGrid.Cells.Cell>();
        }

        private void drawHeaders()
        {
            //Name, Experiment Frame, Start Time, Finish Time, Progress, Output Report

            grid.Rows.Clear();

            grid.BorderStyle = BorderStyle.None;
            grid.Redim(1, 6);
            //grid.EnableSort = true;
            //grid.CustomSort = false;
            grid.FixedRows = 1;
            //grid.FixedColumns = 1;

            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            grid.Font = new Font("Calibe", 9);

            //grid.Columns[0].AutoSizeMode = SourceGrid.AutoSizeMode.None;
            //grid.Columns[0].Width = 25;
            //SourceGrid.Cells.RowHeader l_00Header = new SourceGrid.Cells.RowHeader(null);
            //grid[0, 0] = l_00Header;

            string[] columns = { "Name", "Run Options", "Start Time", "Finish Time", "Progress", "Output Report" };
            for (int i = 0; i < columns.Length; i++)
            {
                SourceGrid.Cells.ColumnHeader header =
                    new SourceGrid.Cells.ColumnHeader(columns[i]);

                header.View = titleModel;
                grid[0, i] = header;
            }

            grid.SelectionMode = SourceGrid.GridSelectionMode.Row;
        }

        public void AddExperiment(string id, OutputViewer viewer, DateTime startTime, DateTime endTime)
        {
            InsertMessage(id, viewer, startTime, endTime);
        }

        public void UpdateExperiment(string id, VMS.IFS.DataModel.OutputData.OutputDataSet outputData, DateTime endTime)
        {
            for (int i = 1; i < grid.Rows.Count; i++)
            {
                if (grid[i, 0].DisplayText == id)
                {
                    grid[i, 3].Value = endTime.ToString();
                    grid[i, 5].Tag = outputData;
                    break;
                }
            }
        }

        public void UpdateProgress(string id, double progress)
        {
            _ProgressCells[id].Value = progress + " %";
        }

        private void InsertMessage(string id)
        {
            int rowIndex = grid.RowsCount;
            grid.Rows.Insert(rowIndex);

            //string[] columns = { "Name", "Run Options", "Start Time", "Finish Time", "Progress", "Output Report" };

            //Name
            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(id, typeof(string));
            nameCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 0] = nameCell;
            //grid[rowIndex, 0].AddController(this.valueChangedController);

            //Run Options
            SourceGrid.Cells.Editors.TextBoxButton runOptionButton = new SourceGrid.Cells.Editors.TextBoxButton(typeof(string));
            //runOptionButton.SetEditValue("Run Options");
            SourceGrid.Cells.Cell runOptionsCell = new SourceGrid.Cells.Cell("View", runOptionButton);
            grid[rowIndex, 1] = runOptionsCell;
            //grid[rowIndex, 1].AddController(this.valueChangedController);

            SourceGrid.Cells.Cell startTimeCell = new SourceGrid.Cells.Cell(DateTime.Now.ToString(), typeof(string));
            startTimeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 2] = startTimeCell;

            SourceGrid.Cells.Cell finishTimeCell = new SourceGrid.Cells.Cell("", typeof(string));
            finishTimeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 3] = finishTimeCell;

            SourceGrid.Cells.Cell progressCell = new SourceGrid.Cells.Cell("0%", typeof(string));
            progressCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 4] = progressCell;

            SourceGrid.Cells.Editors.TextBoxButton outputButton = new SourceGrid.Cells.Editors.TextBoxButton(typeof(string));
            SourceGrid.Cells.Cell outputCell = new SourceGrid.Cells.Cell("View", outputButton);
            grid[rowIndex, 5] = outputCell;

            _ProgressCells.Add(id, progressCell);

            grid.AutoSizeCells();
        }

        private void InsertMessage(
            string id, 
            Dictionary<string, object> runOptions, 
            DateTime startTime)
        {
            int rowIndex = grid.RowsCount;
            grid.Rows.Insert(rowIndex);

            //string[] columns = { "Name", "Run Options", "Start Time", "Finish Time", "Progress", "Output Report" };

            //Name
            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(id, typeof(string));
            nameCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 0] = nameCell;
            //grid[rowIndex, 0].AddController(this.valueChangedController);

            //Run Options
            SourceGrid.Cells.Editors.TextBoxButton runOptionButton = new SourceGrid.Cells.Editors.TextBoxButton(typeof(string));
            //runOptionButton.SetEditValue("Run Options");
            SourceGrid.Cells.Cell runOptionsCell = new SourceGrid.Cells.Cell("View", runOptionButton);
            runOptionsCell.Tag = runOptions;
            runOptionsCell.AddController(new RunOptionViewCellClickController());
            grid[rowIndex, 1] = runOptionsCell;
            //grid[rowIndex, 1].AddController(this.valueChangedController);

            SourceGrid.Cells.Cell startTimeCell = new SourceGrid.Cells.Cell(startTime.ToString(), typeof(string));
            startTimeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 2] = startTimeCell;

            SourceGrid.Cells.Cell finishTimeCell = new SourceGrid.Cells.Cell("", typeof(string));
            finishTimeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 3] = finishTimeCell;

            SourceGrid.Cells.Cell progressCell = new SourceGrid.Cells.Cell("100%", typeof(string));
            progressCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 4] = progressCell;

            SourceGrid.Cells.Editors.TextBoxButton outputButton = new SourceGrid.Cells.Editors.TextBoxButton(typeof(string));
            SourceGrid.Cells.Cell outputCell = new SourceGrid.Cells.Cell("View", outputButton);
            //outputCell.Tag = outputData;
            outputCell.AddController(new OutputViewCellClickController(this));
            grid[rowIndex, 5] = outputCell;

            _ProgressCells.Add(id, progressCell);

            grid.AutoSizeCells();
        }

        private void InsertMessage(
            string id,
            OutputViewer viewer,
            DateTime startTime, DateTime endTime)
        {
            //viewer.RunOptions.Add("StartTime", startTime);
            viewer.RunOptions.Add("EndTime", endTime);

            int rowIndex = grid.RowsCount;
            grid.Rows.Insert(rowIndex);

            //string[] columns = { "Name", "Run Options", "Start Time", "Finish Time", "Progress", "Output Report" };

            //Name
            SourceGrid.Cells.Cell nameCell = new SourceGrid.Cells.Cell(id, typeof(string));
            nameCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 0] = nameCell;
            //grid[rowIndex, 0].AddController(this.valueChangedController);

            //Run Options
            SourceGrid.Cells.Editors.TextBoxButton runOptionButton = new SourceGrid.Cells.Editors.TextBoxButton(typeof(string));
            //runOptionButton.SetEditValue("Run Options");
            SourceGrid.Cells.Cell runOptionsCell = new SourceGrid.Cells.Cell("View", runOptionButton);
            runOptionsCell.Tag = viewer.RunOptions;
            runOptionsCell.AddController(new RunOptionViewCellClickController());
            grid[rowIndex, 1] = runOptionsCell;
            //grid[rowIndex, 1].AddController(this.valueChangedController);

            SourceGrid.Cells.Cell startTimeCell = new SourceGrid.Cells.Cell(startTime.ToString(), typeof(string));
            startTimeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 2] = startTimeCell;

            SourceGrid.Cells.Cell finishTimeCell = new SourceGrid.Cells.Cell(endTime.ToString(), typeof(string));
            finishTimeCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 3] = finishTimeCell;

            SourceGrid.Cells.Cell progressCell = new SourceGrid.Cells.Cell("100%", typeof(string));
            progressCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
            grid[rowIndex, 4] = progressCell;

            SourceGrid.Cells.Editors.TextBoxButton outputButton = new SourceGrid.Cells.Editors.TextBoxButton(typeof(string));
            SourceGrid.Cells.Cell outputCell = new SourceGrid.Cells.Cell("View", outputButton);
            //outputCell.Tag = viewer;
            outputCell.AddController(new OutputViewCellClickController(this));
            grid[rowIndex, 5] = outputCell;

            _ODS.Add(id, viewer);
            _ProgressCells.Add(id, progressCell);

            grid.AutoSizeCells();
        }

        public void EnforceDispose()
        {
            string[] names = _ODS.Keys.ToArray<string>();
            for (int i = names.Length - 1; i > 0; i--)
            {
                _ODS[names[i]].OutputData.Dispose();
                _ODS[names[i]].Dispose();
                _ODS.Remove(names[i]);
            }

            names = _ProgressCells.Keys.ToArray<string>();
            for (int i = names.Length - 1; i > 0; i--)
            {
                _ProgressCells.Remove(names[i]);
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            CompareOutputData dialog = new CompareOutputData(_ODS);
            dialog.Show();
        }
    }

    public class RunOptionViewCellClickController : SourceGrid.Cells.Controllers.ControllerBase
    {

        public RunOptionViewCellClickController()
        {
        }

        public override void OnClick(SourceGrid.CellContext sender, EventArgs e)
        {
            base.OnClick(sender, e);

            SourceGrid.Cells.Cell runOptionCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 1);

            Dictionary<string, object> runOptions = (Dictionary<string, object>)runOptionCell.Tag;
            SingleRunOptionViewer dialog = new SingleRunOptionViewer(runOptions);
            dialog.ShowDialog();
        }
    }

    public class OutputViewCellClickController : SourceGrid.Cells.Controllers.ControllerBase
    {
        private SimulationRunWindow _Parent;

        public OutputViewCellClickController(SimulationRunWindow parent)
        {
            _Parent = parent;
        }

        public override void OnClick(SourceGrid.CellContext sender, EventArgs e)
        {
            base.OnClick(sender, e);


            SourceGrid.Cells.Cell nameCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 0);
            OutputViewer viewer = _Parent[nameCell.DisplayText];
            if (viewer != null)
                viewer.Show();
                //SourceGrid.Cells.Cell runOptionCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 1);
                //SourceGrid.Cells.Cell outputCell = (SourceGrid.Cells.Cell)sender.Grid.GetCell(sender.Position.Row, 5);

            
                //NewOutputViewer viewer = (NewOutputViewer)runOptionCell.Tag;
                

                //Dictionary<string, object> runOptions = (Dictionary<string, object>)runOptionCell.Tag;
                //VMS.IFS.DataModel.OutputData.OutputDataSet outputData = (VMS.IFS.DataModel.OutputData.OutputDataSet)outputCell.Tag;

                //_Viewer = new NewOutputViewer(outputData, runOptions);
                //_Viewer.Build();

            //_Viewer.ShowDialog();
        }
    }
}