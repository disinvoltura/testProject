﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.DataModel.InputData;
using VMS.IFS.DataModel.DispatchingRuleData;

namespace VMS.IFS.UI
{
    public partial class SingleRunOptionViewer : Form
    {
        #region Member Variables
        public InputDataSet ids;
        private double EOSTime;
        private bool isEOSTime;
        private string EOSTimeUnit;//Days, Hours, Minutes, Seconds
        private List<string> lstLoadableSet;
        private string selectedLoadableSet;
        private int shift;
        private int saveWIPTime;

        private bool IsWeightOnConveyTime;
        private string selectedWeightSet;
        private int vqCapa;

        private List<string> _StepList;
        private List<string> _MCSWeightSet;

        private DateTime firstFO;

        private int interReleaseTime; //in Seconds
        #endregion

        #region Constructor
        public SingleRunOptionViewer(Dictionary<string, object> runOptions)
        {
            InitializeComponent();

            loadRunOptions(runOptions);
        }

        private void loadRunOptions(Dictionary<string, object> runOptions)
        {
            string eosMode = (string) runOptions[SimulationArguments.EOSMode];

            if (eosMode == "Time")
            {
                isEOSTime = true;
                rb_EOSTime.Checked = true;
                rb_End.Checked = false;

                double eosTimeInSecs = (double)runOptions[SimulationArguments.EOSTime];
                string eosTimeUnit = ((string)runOptions[SimulationArguments.EOSTimeUnit]).ToLower();
                double eosTime = 0;
                if (eosTimeUnit == "days")
                {
                    eosTime = eosTimeInSecs / 86400;
                }else if (eosTimeUnit == "hours")
                {
                    eosTime = eosTimeInSecs / 3600;
                }else if (eosTimeUnit == "minutes")
                {
                    eosTime = eosTimeInSecs / 60;
                }
                //Days, Hours, Minutes, Seconds

                tb_EOSTime.Text = eosTime.ToString();

                cbTimeUnit.SelectedItem = runOptions[SimulationArguments.EOSTimeUnit].ToString();
            }
            else
            {
                isEOSTime = false;
                rb_EOSTime.Checked = false;
                rb_End.Checked = true;
            }

            this.shift = (int)runOptions[SimulationArguments.UnitTime];
            tb_Shift.Text = shift.ToString();            

            dateTimePicker1.Value = (DateTime)runOptions[SimulationArguments.StartTime];

            txtFWK.Text = runOptions[SimulationArguments.KanbanFabWIP].ToString();
            cbSteps.SelectedItem = (string)runOptions[SimulationArguments.KanbanStepID];
            cbSteps.Text = (string)runOptions[SimulationArguments.KanbanStepID];
            txtTSK.Text = runOptions[SimulationArguments.KanbanStepWIP].ToString();

            cb_LoadableSet.SelectedItem = (string)runOptions[SimulationArguments.LoadableEQPVersionNo];
            cb_LoadableSet.Text = (string)runOptions[SimulationArguments.LoadableEQPVersionNo];

            //dispatching rule
            _JSR = (DispatchingRuleDefinition) runOptions[SimulationArguments.JobSelectionRule];
            txtJSR.Text = _JSR.Name;
            showJSRWeight(_JSR, runOptions);

            _MSR = (DispatchingRuleDefinition)runOptions[SimulationArguments.MachineSelectionRule];
            txtMSR.Text = _MSR.Name;
            showMSRWeight(_MSR, runOptions);
            
            //bool logging = (bool)runOptions[SimulationArguments.Logging];
            //checkBox1.Checked = logging;

            IsWeightOnConveyTime = (bool)runOptions[SimulationArguments.MCSWeightMode];
            if (IsWeightOnConveyTime)
            {
                rb_WeightConv.Checked = true;
                rb_WeightUsers.Checked = false;
            }
            else
            {
                rb_WeightConv.Checked = false;
                rb_WeightUsers.Checked = true;

                cbWeightVersion.SelectedItem = (string) runOptions[SimulationArguments.MCSWeightSet];
                cbWeightVersion.Text = (string) runOptions[SimulationArguments.MCSWeightSet];
            }

            //inter release time
            interReleaseTime = (int)runOptions[SimulationArguments.InterReleaseTime];
            txtInterReleaseTime.Text = interReleaseTime.ToString();

        }
        #endregion

        #region Event Handling
        private void btn_Run_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
        #endregion                                

        #region Job Selection Rule Methods
        private DispatchingRuleDefinition _JSR;
        private DispatchingRuleDefinition _MSR;

        //private void btnSelectJSR_Click(object sender, EventArgs e)
        //{
        //    DispatchingRuleSelector dialog = new DispatchingRuleSelector(DispatchingRuleType.JobSelectionRule);
        //    DialogResult rslt = dialog.ShowDialog();

        //    if (rslt == System.Windows.Forms.DialogResult.OK)
        //    {
        //        _JSR = dialog.SelectedDispatchingRule;
                
        //        //Name
        //        txtJSR.Text = _JSR.Name;

        //        //Parameters
        //        showJSRWeight(_JSR, new Dictionary<string,object>());
        //    }
        //}

        private void showJSRWeight(DispatchingRuleDefinition jsr, Dictionary<string, object> runOptions)
        {
            int pCount = jsr.Parameters.Count<DRParameter>();
            if (pCount > 0)
            {
                //Headers
                gJSRParams.Rows.Clear();
                gJSRParams.Columns.Clear();

                gJSRParams.Redim(2, pCount + 1);
                gJSRParams.FixedRows = 1;

                SourceGrid.Cells.Header l_00Header = new SourceGrid.Cells.Header(null);
                gJSRParams[0, 0] = l_00Header;
                gJSRParams[1, 0] = new SourceGrid.Cells.RowHeader(null);

                SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
                DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
                backHeader.BackColor = Color.Lavender;
                backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
                titleModel.Background = backHeader;
                titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

                int colCount = 1;
                foreach (DRParameter p in jsr.Parameters)
                {
                    SourceGrid.Cells.ColumnHeader header =
                         new SourceGrid.Cells.ColumnHeader(p.Name);

                    header.View = titleModel;
                    gJSRParams[0, colCount] = header;

                    string key = "JSR_" + p.Name;
                    string pValue = "1";
                    if (runOptions.ContainsKey(key))
                        pValue = runOptions[key].ToString();

                    SourceGrid.Cells.Cell pCell = new SourceGrid.Cells.Cell(pValue, typeof(string));
                    pCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
                    gJSRParams[1, colCount] = pCell;

                    colCount++;
                }
            }
        }
        #endregion

        #region Machine Selection Rule Methods
        //private void btnSelectMSR_Click(object sender, EventArgs e)
        //{
        //    DispatchingRuleSelector dialog = new DispatchingRuleSelector(DispatchingRuleType.MachineSelectionRule);
        //    DialogResult rslt = dialog.ShowDialog();

        //    if (rslt == System.Windows.Forms.DialogResult.OK)
        //    {
        //        _MSR = dialog.SelectedDispatchingRule;

        //        //Name
        //        txtMSR.Text = _MSR.Name;

        //        //Parameters
        //        showMSRWeight(_MSR, new Dictionary<string,object>());
        //    }
        //}

        private void showMSRWeight(DispatchingRuleDefinition msr, Dictionary<string, object> runOptions)
        {
            int pCount = msr.Parameters.Count<DRParameter>();
            if (pCount > 0)
            {
                //Headers
                gMSRParams.Rows.Clear();
                gMSRParams.Columns.Clear();

                gMSRParams.Redim(2, pCount + 1);
                gMSRParams.FixedRows = 1;

                SourceGrid.Cells.Header l_00Header = new SourceGrid.Cells.Header(null);
                gMSRParams[0, 0] = l_00Header;
                gMSRParams[1, 0] = new SourceGrid.Cells.RowHeader(null);

                SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
                DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
                backHeader.BackColor = Color.Lavender;
                backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
                titleModel.Background = backHeader;
                titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

                int colCount = 1;
                foreach (DRParameter p in msr.Parameters)
                {
                    SourceGrid.Cells.ColumnHeader header =
                         new SourceGrid.Cells.ColumnHeader(p.Name);

                    header.View = titleModel;
                    gMSRParams[0, colCount] = header;

                    string key = "MSR_" + p.Name;
                    string pValue = "1";
                    if (runOptions.ContainsKey(key))
                        pValue = runOptions[key].ToString();

                    SourceGrid.Cells.Cell pCell = new SourceGrid.Cells.Cell(pValue, typeof(string));
                    pCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
                    gMSRParams[1, colCount] = pCell;

                    colCount++;
                }
            }
        }
        #endregion                
    }
}
