﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Threading.Tasks;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.DataModel.OutputData;

namespace VMS.IFS.UI
{
    public partial class OutputReportProgress : Form
    {
        private int _Total = 19;
        private int _Count = 0;
        private OutputViewer _Viewer;
        public OutputViewer Viewer { get { return _Viewer; } }

        public OutputReportProgress(Dictionary<string, object> runOptions, OutputDataSet ods)
        {
            InitializeComponent();

            _Viewer = new OutputViewer(ods, runOptions);
            _Total = _Viewer.Count;
            _Viewer.Processed += new OutputReportProgressEventHandler(Progress);
        }

        public OutputReportProgress(OutputViewer viewer)
        {
            InitializeComponent();

            _Viewer = viewer;
            _Total = _Viewer.Count;
            _Viewer.Processed += new OutputReportProgressEventHandler(Progress);
        }

        public void Progress(string name)
        {
            lock (this)
            {
                _Count++;
                textBox1.AppendText(name + "\r\n");
                double progress = Math.Round(((double)_Count) / ((double)_Total) * 100.0);
                progressBar1.Value = (int)progress;
                
                //System.Diagnostics.Debug.WriteLine("[Progress] " + progress);

                Thread.Sleep(100);
                //System.Diagnostics.Debug.WriteLine(name + "\t" + GC.GetTotalMemory(true));

                if (_Count == _Total)
                {
                    Thread.Sleep(100);
                    this.Close();
                }
            }
        }

        private void OutputReportProgress_Shown(object sender, EventArgs e)
        {
            //System.Diagnostics.Debug.WriteLine("Memory"+ "\t" + GC.GetTotalMemory(true));
            _Viewer.Build();
        }

    }
}
