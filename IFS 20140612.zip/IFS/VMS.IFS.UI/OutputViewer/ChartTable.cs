﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace VMS.IFS.UI
{
    public partial class ChartTable : UserControl
    {
        #region Member Variable
        public DataTable dtShowTable;
        public DataTable dtShowChart;
        
        private string _ChartType;
        private List<string> _XList;
        private List<string> _YList;
        #endregion

        #region Constructor

        public ChartTable(DataTable dt, string chartType, List<string> xList, List<string> yList, bool makeChart)
        {
            InitializeComponent();
            
            dtShowChart = dt;
            dtShowTable = dt;            

            this._ChartType = chartType;
            this._XList = xList;
            this._YList = yList;

            OutputChartData chartData = new OutputChartData(this, dtShowChart, _ChartType, _XList, _YList);
            UserControl chartControl = chartData.BuildChart();

            if (makeChart)
            {
                if (_ChartType != "Gantt")
                {
                    chartControl.Parent = splitContainer1.Panel1;
                    chartControl.Dock = DockStyle.Fill;
                    chartControl.Show();
                                        
                    SOTable sot = new SOTable(dtShowTable);
                    sot.Parent = splitContainer1.Panel2;
                    sot.Dock = DockStyle.Fill;
                    sot.Show();
                }
                else
                {
                    chartControl.Parent = splitContainer1.Panel1;
                    chartControl.Dock = DockStyle.Fill;
                    chartControl.Show();

                    splitContainer1.Panel2Collapsed = true;
                }
            }
            else
            {
                splitContainer1.Panel1Collapsed = true;
                SOTable sot = new SOTable(dtShowTable);
                sot.Parent = splitContainer1.Panel2;
                sot.Dock = DockStyle.Fill;
                sot.Show();

            }
        }

        public ChartTable(DataTable dtChart, DataTable dtTable, string chartType, List<string> xList, List<string> yList)
        {
            InitializeComponent();

            DataTable chart = dtChart.Copy();
            dtShowChart = chart;
            DataTable table = dtTable.Copy();
            dtShowTable = table; 

            this._ChartType = chartType;
            this._XList = xList;
            this._YList = yList;

            OutputChartData chartData = new OutputChartData(this, dtShowChart, _ChartType, _XList, _YList);
            UserControl chartControl = chartData.BuildChart();

            chartControl.Parent = splitContainer1.Panel1;
            chartControl.Dock = DockStyle.Fill;
            chartControl.Show();

            SOTable sot = new SOTable(dtShowTable);
            sot.Parent = splitContainer1.Panel2;//.Controls.Add(sot);
            sot.Dock = DockStyle.Fill;
            sot.Show();
        }
        #endregion
              
    }
}
