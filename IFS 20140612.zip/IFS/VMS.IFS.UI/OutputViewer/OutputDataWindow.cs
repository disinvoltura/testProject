﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace VMS.IFS.UI
{
    public partial class OutputDataWindow : DockContent
    {
        private ChartTable ct;
        private OutputViewer _Parent;

        public OutputDataWindow(OutputViewer parent, string name, ChartTable ct)
        {
            _Parent = parent;

            InitializeComponent();

            this.Text = name;

            this.Controls.Add(ct);

            ct.Dock = DockStyle.Fill;
        }
    }
}
