﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.UI
{
    public class GanttChartData
    {
        #region Member Variables
        /// <summary>
        /// Key: Resource ID, Value: GanttChart Bars
        /// </summary>
        private  Dictionary<string, GanttChartResource> _Data;
        /// <summary>
        /// Key: Cateogry Name, Value: Color Name
        /// </summary>
        private Dictionary<string, string> _CategoryToColorData;

        /// <summary>
        /// Key: Resource ID.Category, Value: Total Time
        /// </summary>
        private Dictionary<string, double> _TimeData;

        private DateTime _MinTime;
        private DateTime _MaxTime;
        #endregion 

        #region Properties
        public DateTime MinimumTime
        {
            get { return _MinTime; }
        }

        public DateTime MaximumTime
        {
            get { return _MaxTime; }
        }

        public int Count
        {
            get { return _Data.Keys.Count; }
        }

        public IEnumerable<string> Resources
        {
            get { return _Data.Keys; }
        }

        public IEnumerable<string> Categories
        {
            get { return _CategoryToColorData.Keys; }
        }
        
        public GanttChartResource this[string resourceid]
        {
            get { return _Data[resourceid]; }
        }
        #endregion

        #region Constructors
        public GanttChartData()
        {
            _Data = new Dictionary<string, GanttChartResource>();
            _TimeData = new Dictionary<string, double>();
            _CategoryToColorData = new Dictionary<string, string>();

            _MinTime = DateTime.MaxValue;
            _MaxTime = DateTime.MinValue;
        }
        #endregion

        #region Methods
        public string GetColor(string categoryName)
        {
            if (_CategoryToColorData.ContainsKey(categoryName))
                return _CategoryToColorData[categoryName];
            else
                return "White";
        }

        public void AddCategory(string categoryName, string colorName)
        {
            if (_CategoryToColorData.ContainsKey(categoryName))
            {
                _CategoryToColorData[categoryName] = colorName;
            }
            else
            {
                _CategoryToColorData.Add(categoryName, colorName);
            }
        }

        public void RemoveCateogory(string categoryName)
        {
            if (_CategoryToColorData.ContainsKey(categoryName))
                _CategoryToColorData.Remove(categoryName);
        }

        public void AddResource(string resourceid)
        {
            if (!_Data.ContainsKey(resourceid))
            {
                GanttChartResource res = new GanttChartResource(resourceid);
                _Data.Add(resourceid, res);
            }
        }

        private void AccumulateTime(string resourceid, string category, double timeStay)
        {
            string key = string.Format("{0}.{1}", resourceid, category);
            if (!_TimeData.ContainsKey(key))
            {
                _TimeData.Add(key, timeStay);
            }
            else
            {
                double sum = _TimeData[key];
                sum += timeStay;
                _TimeData[key] = sum;
            }
        }

        public double GetTimeSpan(string resourceid, string category)
        {
            string key = string.Format("{0}.{1}", resourceid, category);

            double rslt = 0;
            if (_TimeData.ContainsKey(key))
                rslt = _TimeData[key];

            return rslt;
        }

        public void AddBar(string resourceid, DateTime start, DateTime end, string category, string text)
        {
            if (!_Data.ContainsKey(resourceid))
                AddResource(resourceid);

            GanttChartBar bar = new GanttChartBar();
            bar.StartTime = start;
            bar.EndTime = end;
            bar.Category = category;
            bar.Text = text;

            if (bar.StartTime < _MinTime)
                _MinTime = bar.StartTime;
            if (bar.EndTime > _MaxTime)
                _MaxTime = bar.EndTime;

            TimeSpan ts = end.Subtract(start);
            AccumulateTime(resourceid, category, ts.TotalSeconds);

            GanttChartResource res = _Data[resourceid];
            res.Add(bar);
            _Data[resourceid] = res;
        }

        public void AddBar(string resourceid, DateTime start, DateTime end, string category, string productid, string stepid)
        {
            GanttChartBar bar = new GanttChartBar();
            bar.StartTime = start;
            bar.EndTime = end;
            bar.Category = category;
            bar.ProductID = productid;
            bar.StepID = stepid;
            bar.Text = productid + "." + stepid;

            if (bar.StartTime < _MinTime)
                _MinTime = bar.StartTime;
            if (bar.EndTime > _MaxTime)
                _MaxTime = bar.EndTime;

            TimeSpan ts = end.Subtract(start);
            AccumulateTime(resourceid, category, ts.TotalSeconds);

            GanttChartResource res = _Data[resourceid];
            res.Add(bar);
            _Data[resourceid] = res;
        }
        #endregion
    }

    public class GanttChartResource
    {
        #region Member Variables
        private string _Name;
        private List<GanttChartBar> _Bars;
        #endregion

        #region Properties
        public string Name
        {
            get { return _Name; }
        }

        public List<GanttChartBar> Items
        {
            get { return _Bars; }
            set { _Bars = value; }
        }
        #endregion

        public GanttChartResource(string name)
        {
            _Name = name;
            _Bars = new List<GanttChartBar>();
        }

        public void Add(GanttChartBar bar)
        {
            bool inserted = false;
            for (int i = 0; i < _Bars.Count; i++)
            {
                if (bar.StartTime < _Bars[i].StartTime)
                {
                    _Bars.Insert(i, bar);
                    inserted = true;
                    break;
                }
            }
            if (!inserted)
                _Bars.Add(bar);
        }
    }

    public class GanttChartBar
    {
        private static int IDCounter = 1;

        public int ID;
        public DateTime StartTime;
        public DateTime EndTime;
        public string Category; //Run, Steup,....
        public string Text;

        public string ProductID;
        public string StepID;

        public GanttChartBar()
        {
            this.ID = GanttChartBar.IDCounter++;
        }
    }
}
