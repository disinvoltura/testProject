﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;

namespace VMS.IFS.UI
{
    public class OutputChartData
    {
        #region Member variables

        private ChartTable _CTParent;
        private DataTable _DT;
        private string _ChartType;
        private List<string> _XList;
        private List<string> _YList;        

        #endregion

        #region Constructors

        public OutputChartData(ChartTable ct, DataTable dt, string chartType, List<string> x, List<string> y)
        {
            _CTParent = ct;
            _DT = dt;
            _ChartType = chartType;
            _XList = x;
            _YList = y;           
        }

        #endregion

        #region Methods

        public UserControl BuildChart()
        {
            UserControl uc = new UserControl();
            
            if (_ChartType == "Line")
            {
                uc = new SOTimeSeriesChart(_DT);
            }
            else if (_ChartType == "Column")
            {
                uc = new SOAttributeChart(_DT, _XList, _YList);
            }
            else if (_ChartType == "StackedColumn")
            {
                uc = new SORatioChart(_DT, _XList);
            }
            else if (_ChartType == "Gantt")
            {
                GanttChartControl gc = new GanttChartControl(_DT);
                gc.DefaultWidth = 2;
                uc = gc;
            }

            return uc;
        }

        #endregion
    }
}
