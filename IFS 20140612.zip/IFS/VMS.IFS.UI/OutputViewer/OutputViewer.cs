﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using OfficeOpenXml;
using VMS.IFS.DataModel.OutputData;
using VMS.IFS.DataModel.DispatchingRuleData;
using WeifenLuo.WinFormsUI.Docking;

namespace VMS.IFS.UI
{
    public delegate void OutputReportProgressEventHandler (string name);

    public partial class OutputViewer : Form
    {
        #region Member Variables

        private string fileName;
        private Dictionary<string, string> tableTabMapping;
        private Dictionary<string, ChartTable> tabCTMapping;
        private bool isNew;

        OutputDataSet ods;
        Dictionary<string, object> _RunOptions;

        private Dictionary<string, OutputDataWindow> _DataWindows;
        private OutputExplorer _OutputExplorer;
        #endregion

        public int Count
        {
            get { return tableTabMapping.Count; }
        }
        public Dictionary<string, object> RunOptions
        {
            get { return _RunOptions; }
            set { _RunOptions = value; }
        }

        public OutputDataSet OutputData
        {
            get { return ods; }
        }

        public event OutputReportProgressEventHandler Processed;

        public OutputViewer(OutputDataSet ods, Dictionary<string, object> ro)
        {
            InitializeComponent();

            this.ods = ods;
            this._RunOptions = ro;

            tableTabMapping = new Dictionary<string, string>();
            tableTabMapping.Add("FabInOutDataTable", "Fab In/Out");
            tableTabMapping.Add("FabWIPDataTable", "Fab WIP");

            tableTabMapping.Add("ProductInOutDataTable", "Product In/Out");
            tableTabMapping.Add("ProductTATDataTable", "Product TAT - Total");            
            tableTabMapping.Add("ShiftProductTATDataTable", "Product TAT - Time Bucket");
            tableTabMapping.Add("ProductStepTATDataTable", "Product-Processing Step TAT");            
            
            tableTabMapping.Add("ProcessingStepWIPDataTable", "Processing Step WIP");
            tableTabMapping.Add("ProcessingStepOutputDataTable", "Processing Step Output");
            
            tableTabMapping.Add("EQPUtilizationDataTable", "EQP Utilization");
            tableTabMapping.Add("EQPOutputDataTable", "EQP Output");
            tableTabMapping.Add("EQPGanttChartDataTable", "EQP Gantt Chart");

            tableTabMapping.Add("STKUtilizationDataTable", "Inline Stocker Utilization");
            tableTabMapping.Add("StockerShiftTransportLoadDataTable", "Inline Stocker Transport Load");            
            tableTabMapping.Add("StockerWIPDataTable", "Inline Stocker WIP");            
            tableTabMapping.Add("ConveyorWIPDataTable", "Conveyor WIP");            
            tableTabMapping.Add("CassetteMovingTimeDataTable", "Cassette Moving Time");
            tableTabMapping.Add("STKCraneWaitingTimeDataTable", "Delivery Waiting Time");
            
            tableTabMapping.Add("FabOutPlanDataTable", "FabOut Plan");
            tableTabMapping.Add("ReleaseBatchDataTable", "Release Plan");            

            TreeNode topNode = new TreeNode("Simulation Output");
        }

        public void Build()
        {
            BuildChartTable();

            _DataWindows = new Dictionary<string, OutputDataWindow>();
            _OutputExplorer = new OutputExplorer(this);
            _OutputExplorer.TableSelected += new InputDataTableSelectedEventHandler(OnOutputDataSelected);

            foreach (string tableName in tableTabMapping.Keys)
            {
                string tabName = tableTabMapping[tableName];

                OutputDataWindow w = new OutputDataWindow(this, tabName, tabCTMapping[tabName]);

                _DataWindows.Add(tabName, w);
                _OutputExplorer.Add("OutputData", tabName);

            }

            createLayout();

            //treeView1.Nodes.Add(topNode);

            isNew = true;
        }

        private void createLayout()
        {
            dockPanel1.Theme = new WeifenLuo.WinFormsUI.Docking.VS2012LightTheme(); ;

            _OutputExplorer.Show(dockPanel1, DockState.DockLeft);
            _OutputExplorer.DockHandler.CloseButtonVisible = false;
            _OutputExplorer.DockHandler.CloseButton = false;

            List<string> tableNames = tableTabMapping.Keys.ToList<string>();
            string firtTabName = tableTabMapping[tableNames[0]];
            OutputDataWindow firstWindow = _DataWindows[firtTabName];
            firstWindow.Show(dockPanel1, DockState.Document);
            firstWindow.DockHandler.CloseButtonVisible = false;
            firstWindow.DockHandler.CloseButton = false;
            
            for (int i = 1 ; i < tableNames.Count; i++)
            {
                string tableName = tableNames[i];
                string tabName = tableTabMapping[tableName];
                if (!_DataWindows.ContainsKey(tabName))
                    continue;

                OutputDataWindow window = _DataWindows[tabName];
                window.Show(dockPanel1, DockState.Document);
                window.DockHandler.CloseButtonVisible = false;
                window.DockHandler.CloseButton = false;

            }
        }

        private void OnOutputDataSelected(string name)
        {
            if (_DataWindows.ContainsKey(name))
            {
                OutputDataWindow w = _DataWindows[name];
                w.Show();
            }
        }

        private void reportProgress(string name)
        {
            if (Processed != null && Processed.GetInvocationList().Length > 0)
                Processed(name);
        }

        private void BuildChartTable()
        {
            DateTime dt1, dt2;

            tabCTMapping = new Dictionary<string, ChartTable>();

            dt1 = DateTime.Now;
            ChartTable ctFIO = new ChartTable(ods.FabInOutDataTable, "Line", null, null, true);
            dt2 = DateTime.Now;
            //System.Diagnostics.Debug.WriteLine("[OutputViewer] FabInOut finished (" + dt2.Subtract(dt1).TotalSeconds + " s)");
            tabCTMapping.Add("Fab In/Out", ctFIO);
            reportProgress("Fab In/Out");

            ChartTable ctPIO = new ChartTable(ods.ProductInOutDataTable, "Line", null, null, true);
            tabCTMapping.Add("Product In/Out", ctPIO);
            reportProgress("Product In/Out");

            //product 별 shift 별 average TAT - 3/20 김현식
            ChartTable ctPSTAT = new ChartTable(ods.ShiftProductTATDataTable, "Line", null, null, true);
            tabCTMapping.Add("Product TAT - Time Bucket", ctPSTAT);
            reportProgress("Product TAT - Time Bucket");

            List<string> xPTAT = new List<string>();
            xPTAT.Add("Product ID");
            List<string> yPTAT = new List<string>();
            yPTAT.Add("Total TAT");
            ChartTable ctPTAT = new ChartTable(ods.ProductTATDataTable, "Column", xPTAT, yPTAT, true);
            tabCTMapping.Add("Product TAT - Total", ctPTAT);
            reportProgress("Product TAT - Total");

            List<string> xPStepTAT = new List<string>();
            xPStepTAT.Add("Product ID");
            ChartTable ctPStepTAT = new ChartTable(ods.StepTATChartDataTable, ods.ProductStepTATDataTable, "StackedColumn", xPStepTAT, null);
            tabCTMapping.Add("Product-Processing Step TAT", ctPStepTAT);
            reportProgress("Product-Processing Step TAT");

            ChartTable ctPStepWIP = new ChartTable(ods.ProcessingStepWIPDataTable, "Line", null, null, true);
            tabCTMapping.Add("Processing Step WIP", ctPStepWIP);
            reportProgress("Processing Step WIP");

            ChartTable ctPStepOut = new ChartTable(ods.ProcessingStepOutputDataTable, "Line", null, null, true);
            tabCTMapping.Add("Processing Step Output", ctPStepOut);
            reportProgress("Processing Step Output");

            List<string> xEQPUtil = new List<string>();
            xEQPUtil.Add("EQP ID");
            ChartTable ctEQPUtil = new ChartTable(ods.EQPUtilizationDataTable, "StackedColumn", xEQPUtil, null, true);
            tabCTMapping.Add("EQP Utilization", ctEQPUtil);
            reportProgress("EQP Utilization");

            ChartTable ctEQPOut = new ChartTable(ods.EQPOutputDataTable, "Line", null, null, true);
            tabCTMapping.Add("EQP Output", ctEQPOut);
            reportProgress("EQP Output");

            ChartTable ctFabWIP = new ChartTable(ods.FabWIPDataTable, "Line", null, null, true);
            tabCTMapping.Add("Fab WIP", ctFabWIP);
            reportProgress("Fab WIP");

            ChartTable ctRPlan = new ChartTable(ods.ReleaseBatchDataTable, "Column", new List<string>(), new List<string>(), false);
            tabCTMapping.Add("Release Plan", ctRPlan);
            reportProgress("Release Plan");

            ChartTable ctFOPlan = new ChartTable(ods.FabOutPlanDataTable, "Column", new List<string>(), new List<string>(), false);
            tabCTMapping.Add("FabOut Plan", ctFOPlan);
            reportProgress("FabOut Plan");

            ChartTable ctEQPGantt = new ChartTable(ods.EQPGanttChartDataTable, "Gantt", null, null, true);
            tabCTMapping.Add("EQP Gantt Chart", ctEQPGantt);
            reportProgress("EQP Gantt Chart");

            ChartTable ctStokcerWIP = new ChartTable(ods.StockerWIPDataTable, "Line", null, null, true);
            tabCTMapping.Add("Inline Stocker WIP", ctStokcerWIP);
            reportProgress("Inline Stocker WIP");

            ChartTable ctConveyorWIP = new ChartTable(ods.ConveyorWIPDataTable, "Line", null, null, true);
            tabCTMapping.Add("Conveyor WIP", ctConveyorWIP);
            reportProgress("Conveyor WIP");

            List<string> xSTKUtil = new List<string>();
            xSTKUtil.Add("STK_ID");
            ChartTable ctSTKUtil = new ChartTable(ods.STKUtilizationDataTable, "StackedColumn", xSTKUtil, null, true);
            tabCTMapping.Add("Inline Stocker Utilization", ctSTKUtil);
            reportProgress("Inline Stocker Utilization");

            List<string> xMovingTime = new List<string>();
            xMovingTime.Add("ProductID");
            xMovingTime.Add("FromStepID");
            xMovingTime.Add("ToStepID");
            List<string> yMovingTime = new List<string>();
            yMovingTime.Add("Average");
            ChartTable ctMovingTime = new ChartTable(ods.CassetteMovingTimeDataTable, "Column", xMovingTime, yMovingTime, true);
            tabCTMapping.Add("Cassette Moving Time", ctMovingTime);
            reportProgress("Cassette Moving Time");

            List<string> xCraneWaitingTime = new List<string>();
            xCraneWaitingTime.Add("STK_ID");
            List<string> yCraneWaitingTime = new List<string>();
            yCraneWaitingTime.Add("Average");
            ChartTable ctCraneWaitingTime = new ChartTable(ods.STKCraneWaitingTimeDataTable, "Column", xCraneWaitingTime, yCraneWaitingTime, true);
            tabCTMapping.Add("Delivery Waiting Time", ctCraneWaitingTime);
            reportProgress("Delivery Waiting Time");
   
            ChartTable ctShiftStokcerTransLoad = new ChartTable(ods.StockerShiftTransportLoadDataTable, "Line", null, null, true);
            tabCTMapping.Add("Inline Stocker Transport Load", ctShiftStokcerTransLoad);
            reportProgress("Inline Stocker Transport Load");
        }

        public void ExportToExcel(string type) //type이 "Save"이면 저장, "SaveAs"면 다른 이름으로 저장
        {
            if (type == "SaveAs" || isNew)
            {
                this.saveFileDialog1.Filter = "Excel Files|*.xls;*.xlsx|All files|*.*";
                if (this.saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    this.fileName = saveFileDialog1.FileName;
                    isNew = false;
                }
            }

            if (!String.IsNullOrEmpty(fileName))
            {
                FileInfo file = new FileInfo(this.fileName);
                if (file.Exists)
                {
                    file.Delete();
                    file = new FileInfo(this.fileName);
                }
                ExcelPackage package = new ExcelPackage(file);

                ExcelWorksheet ws = package.Workbook.Worksheets.Add("Run Option");
                ws.Cells[1, 1].Value = "EOS Mode";
                ws.Cells[1, 2].Value = _RunOptions["EOSMode"];
                if (_RunOptions["EOSMode"] == "Time")
                {
                    ws.Cells[2, 1].Value = "EOS Time";
                    ws.Cells[2, 2].Value = _RunOptions["EOSTime"];
                }
                ws.Cells[4, 1].Value = "Unit Data Collection Time";
                ws.Cells[4, 2].Value = _RunOptions["UnitTime"];

                ws.Cells[6, 1].Value = "Job Selection Rule";
                ws.Cells[7, 1].Value = _RunOptions["JSR"].ToString();
                //ws.Cells[7, 1].Value = ((DispatchingRuleDefinition)_RunOptions["JSR"]).Name;
                int i = 2;
                foreach (string key in _RunOptions.Keys)
                {
                    if (key.Contains("JSR_"))
                    {
                        ws.Cells[6, i].Value = key.Remove(0, 4);
                        ws.Cells[7, i].Value = _RunOptions[key];
                        i++;
                    }
                }

                ws.Cells[9, 1].Value = "Machine Selection Rule";
                ws.Cells[10, 1].Value = _RunOptions["MSR"].ToString();
                //ws.Cells[10, 1].Value = ((DispatchingRuleDefinition)_RunOptions["MSR"]).Name;
                int j = 2;
                foreach (string key in _RunOptions.Keys)
                {
                    if (key.Contains("MSR_"))
                    {
                        ws.Cells[9, i].Value = key.Remove(0, 4);
                        ws.Cells[10, i].Value = _RunOptions[key];
                        j++;
                    }
                }

                foreach (DataTable dt in ods.Tables)
                {
                    if (tableTabMapping.ContainsKey(dt.TableName))
                    {
                        ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(tableTabMapping[dt.TableName]);
                        worksheet.Cells.LoadFromDataTable(dt, true);
                    }
                }

                package.Save();
            }
        }

        public void Save(string type) //type이 "Save"이면 저장, "SaveAs"면 다른 이름으로 저장
        {
            if (type == "SaveAs" || isNew)
            {
                this.saveFileDialog1.Filter = "XML Files|*.xml";
                if (this.saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    this.fileName = saveFileDialog1.FileName;
                    isNew = false;
                }
            }

            if (fileName != "")
            {
                foreach (string key in _RunOptions.Keys)
                {
                    string value = _RunOptions[key].ToString();

                    OutputDataSet.RunOptionsRow row = ods.RunOptions.NewRunOptionsRow();
                    row.Name = key;
                    row.Value = value;
                    ods.RunOptions.Rows.Add(row);
                }

                ods.WriteXml(this.fileName, XmlWriteMode.IgnoreSchema);
            }
        }

        public void OpenRunOptions()
        {
            SingleRunOptionViewer dialog = new SingleRunOptionViewer(_RunOptions);
            dialog.ShowDialog();
        }

        private void NewOutputViewer_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }
    }
}
