﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace VMS.IFS.UI
{
    public partial class OutputExplorer : DockContent
    {
        private OutputViewer _Parent;
        private TreeNode _InputDataNode;

        public event InputDataTableSelectedEventHandler TableSelected;

        public OutputExplorer(OutputViewer parent)
        {
            _Parent = parent;
            InitializeComponent();

            initialize();
        }

        private void initialize()
        {
            _InputDataNode = new TreeNode("Output Data");
            _InputDataNode.ImageIndex = 0;
            _InputDataNode.ExpandAll();

            tvModel.Nodes.Clear();
            tvModel.Nodes.Add(_InputDataNode);

            TreeNode fabNode = new TreeNode("Fab");
            fabNode.ImageIndex = 1;
            fabNode.ExpandAll();
            _InputDataNode.Nodes.Add(fabNode);

            TreeNode productNode = new TreeNode("Product");
            productNode.ImageIndex = 1;
            productNode.ExpandAll();
            _InputDataNode.Nodes.Add(productNode);

            TreeNode stepNode = new TreeNode("Processing Step");
            stepNode.ImageIndex = 1;
            stepNode.ExpandAll();
            _InputDataNode.Nodes.Add(stepNode);

            TreeNode eqpNode = new TreeNode("Production EQP");
            eqpNode.ImageIndex = 1;
            eqpNode.ExpandAll();
            _InputDataNode.Nodes.Add(eqpNode);

            TreeNode amhsNode = new TreeNode("AMHS");
            amhsNode.ImageIndex = 1;
            amhsNode.ExpandAll();
            _InputDataNode.Nodes.Add(amhsNode);

            TreeNode planNode = new TreeNode("Plan");
            planNode.ImageIndex = 1;
            planNode.ExpandAll();
            _InputDataNode.Nodes.Add(planNode);

        }

        public void Add(string category, string item)
        {
            if (category.Equals("OutputData"))
            {
                TreeNode itemNode = new TreeNode(item);
                itemNode.ImageIndex = 2;
                if(item == "Fab In/Out" || item == "Fab WIP")
                    _InputDataNode.Nodes[0].Nodes.Add(itemNode);
                else if(item.Contains("Product") && !item.Contains("WIP") && !item.Contains("Output"))
                    _InputDataNode.Nodes[1].Nodes.Add(itemNode);
                else if(item.Contains("Processing Step"))
                    _InputDataNode.Nodes[2].Nodes.Add(itemNode);
                else if(item.Contains("EQP"))
                    _InputDataNode.Nodes[3].Nodes.Add(itemNode);
                else if(item.Contains("Stocker") || item.Contains("Conveyor") || item.Contains("Time"))
                    _InputDataNode.Nodes[4].Nodes.Add(itemNode);
                else if(item.Contains("Plan"))
                    _InputDataNode.Nodes[5].Nodes.Add(itemNode);
            }                
        }

        private void tvModel_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.Level == 2) //&& e.Node.Parent.Text.Equals("Output Data"))
            {
                if (TableSelected != null && TableSelected.GetInvocationList().Length > 0)
                    TableSelected(e.Node.Text);
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (this.ParentForm is OutputViewer)
            {
                OutputViewer viewer = (OutputViewer)this.ParentForm;
                viewer.Save("SaveAs");
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (this.ParentForm is OutputViewer)
            {
                OutputViewer viewer = (OutputViewer)this.ParentForm;
                viewer.ExportToExcel("SaveAs");
            }
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (this.ParentForm is OutputViewer)
            {
                OutputViewer viewer = (OutputViewer)this.ParentForm;
                viewer.OpenRunOptions();
            }
        }
    }
}
