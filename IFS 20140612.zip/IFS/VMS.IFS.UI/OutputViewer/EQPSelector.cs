﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VMS.IFS.UI
{
    public partial class EQPSelector : Form
    {
        public List<string> Selection
        {
            get
            {
                List<string> rslt = new List<string>();
                for(int i=0; i < checkedListBox1.CheckedItems.Count;i++)
                {
                    rslt.Add(checkedListBox1.CheckedItems[i].ToString());
                }

                return rslt;
            }
        }

        public EQPSelector(List<string> eqplist)
        {
            InitializeComponent();

            checkedListBox1.Items.AddRange(eqplist.ToArray<string>());
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (checkedListBox1.CheckedItems.Count == 0)
                return;

            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }
    }
}
