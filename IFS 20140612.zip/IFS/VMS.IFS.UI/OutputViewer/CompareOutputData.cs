﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using VMS.IFS.DataModel.OutputData;

namespace VMS.IFS.UI
{
    public partial class CompareOutputData : Form
    {
        private OutputDataSet _EmptyODS;
        private Dictionary<string, OutputViewer> _Outputs;
        public CompareOutputData(Dictionary<string, OutputViewer> ods)
        {
            _Outputs = ods;

            InitializeComponent();

            loadData();
        }

        private void loadData()
        {
            cbTable.Items.Clear();
            
            _EmptyODS = new OutputDataSet();
            foreach (DataTable tbl in _EmptyODS.Tables)
            {
                cbTable.Items.Add(tbl.TableName);
            }

            foreach (string key in _Outputs.Keys)
            {
                OutputViewer viewer = _Outputs[key];
                ListViewItem item = new ListViewItem(key);
                item.SubItems.Add(viewer.RunOptions["StartTime"].ToString());
                item.SubItems.Add(viewer.RunOptions["EndTime"].ToString());
                item.Tag = viewer;

                listView1.Items.Add(item);
            }
        }

        private void clearData()
        {
            chart.Series.Clear();

        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbTable.Text))
                return;

            if (string.IsNullOrEmpty(cbXAxis.Text))
                return;

            if (string.IsNullOrEmpty(cbYAxis.Text))
                return;

            clearData();

            string tableName = cbTable.Text;
            string xAxis = cbXAxis.Text;
            string yAxis = cbYAxis.Text;

            int chartType = 1; //1: bar chart, 2: line chart
            if (rbLineChart.Checked)
                chartType = 2;

            
            foreach (ListViewItem item in listView1.Items)
            {
                if (!item.Checked)
                    continue;

                OutputViewer viewer = (OutputViewer)item.Tag;
                OutputDataSet ods = viewer.OutputData;
                Series s = chart.Series.Add(item.Text);

                if (chartType == 1)
                    s.ChartType = SeriesChartType.Column;
                else
                {
                    s.ChartType = SeriesChartType.Line;
                    s.BorderWidth = 3;
                }
                
                foreach(DataRow row in ods.Tables[tableName].Rows)
                {
                    s.Points.AddXY(row[xAxis], row[yAxis]);
                }
            }

            chart.ChartAreas[0].AxisX.Name = xAxis;
            chart.ChartAreas[0].AxisY.Name = yAxis;
            
        }

        private void cbTable_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbTable.Text))
                return;

            string tableName = cbTable.Text;
            cbXAxis.Items.Clear();
            cbXAxis.Text = string.Empty;
            cbYAxis.Items.Clear();
            cbYAxis.Text = string.Empty;

            foreach (DataColumn col in _EmptyODS.Tables[tableName].Columns)
            {
                cbXAxis.Items.Add(col.ColumnName);
                cbYAxis.Items.Add(col.ColumnName);
            }
        }
    }
}
