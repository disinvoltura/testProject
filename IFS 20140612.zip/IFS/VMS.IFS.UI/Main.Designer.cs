﻿namespace VMS.IFS.UI
{
    partial class Main
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.recentFilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageDispatchingRulesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadAnOutputReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inputDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.errorCheckToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.equipmentDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadableSetDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stockerDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.networkDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.simulationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.singleRunOptionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.runToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.simulationRunWithAutoModToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.windowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.floatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetLayoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tutorialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panel1 = new System.Windows.Forms.Panel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.newToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.openToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.saveToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.tsBtn_SingleRunOption = new System.Windows.Forms.ToolStripButton();
            this.tsBtn_Run = new System.Windows.Forms.ToolStripButton();
            this.tsBtn_Stop = new System.Windows.Forms.ToolStripButton();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.inputDataToolStripMenuItem,
            this.simulationToolStripMenuItem,
            this.windowToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.MdiWindowListItem = this.windowToolStripMenuItem;
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(784, 27);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.saveAsToolStripMenuItem,
            this.closeToolStripMenuItem,
            this.toolStripSeparator1,
            this.recentFilesToolStripMenuItem,
            this.toolStripSeparator3,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 23);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("newToolStripMenuItem.Image")));
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(157, 24);
            this.newToolStripMenuItem.Text = "New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("openToolStripMenuItem.Image")));
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(157, 24);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("saveToolStripMenuItem.Image")));
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(157, 24);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Visible = false;
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(157, 24);
            this.saveAsToolStripMenuItem.Text = "Save As";
            this.saveAsToolStripMenuItem.Visible = false;
            this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.saveAsToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(157, 24);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Visible = false;
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(154, 6);
            this.toolStripSeparator1.Visible = false;
            // 
            // recentFilesToolStripMenuItem
            // 
            this.recentFilesToolStripMenuItem.Name = "recentFilesToolStripMenuItem";
            this.recentFilesToolStripMenuItem.Size = new System.Drawing.Size(157, 24);
            this.recentFilesToolStripMenuItem.Text = "Recent Files";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(154, 6);
            this.toolStripSeparator3.Visible = false;
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(157, 24);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.manageDispatchingRulesToolStripMenuItem,
            this.loadAnOutputReportToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(55, 23);
            this.toolsToolStripMenuItem.Text = "Tools";
            // 
            // manageDispatchingRulesToolStripMenuItem
            // 
            this.manageDispatchingRulesToolStripMenuItem.Name = "manageDispatchingRulesToolStripMenuItem";
            this.manageDispatchingRulesToolStripMenuItem.Size = new System.Drawing.Size(252, 24);
            this.manageDispatchingRulesToolStripMenuItem.Text = "Manage Dispatching Rules";
            this.manageDispatchingRulesToolStripMenuItem.Click += new System.EventHandler(this.manageDispatchingRulesToolStripMenuItem_Click);
            // 
            // loadAnOutputReportToolStripMenuItem
            // 
            this.loadAnOutputReportToolStripMenuItem.Name = "loadAnOutputReportToolStripMenuItem";
            this.loadAnOutputReportToolStripMenuItem.Size = new System.Drawing.Size(252, 24);
            this.loadAnOutputReportToolStripMenuItem.Text = "Load an Output Report";
            this.loadAnOutputReportToolStripMenuItem.Click += new System.EventHandler(this.loadAnOutputReportToolStripMenuItem_Click);
            // 
            // inputDataToolStripMenuItem
            // 
            this.inputDataToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.errorCheckToolStripMenuItem,
            this.toolStripSeparator4,
            this.equipmentDataToolStripMenuItem,
            this.loadableSetDataToolStripMenuItem,
            this.productDataToolStripMenuItem,
            this.stockerDataToolStripMenuItem,
            this.networkDataToolStripMenuItem});
            this.inputDataToolStripMenuItem.Name = "inputDataToolStripMenuItem";
            this.inputDataToolStripMenuItem.Size = new System.Drawing.Size(89, 23);
            this.inputDataToolStripMenuItem.Text = "&Input Data";
            this.inputDataToolStripMenuItem.Visible = false;
            // 
            // errorCheckToolStripMenuItem
            // 
            this.errorCheckToolStripMenuItem.Name = "errorCheckToolStripMenuItem";
            this.errorCheckToolStripMenuItem.Size = new System.Drawing.Size(199, 24);
            this.errorCheckToolStripMenuItem.Text = "Check Syntax Error";
            this.errorCheckToolStripMenuItem.Visible = false;
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(196, 6);
            this.toolStripSeparator4.Visible = false;
            // 
            // equipmentDataToolStripMenuItem
            // 
            this.equipmentDataToolStripMenuItem.Name = "equipmentDataToolStripMenuItem";
            this.equipmentDataToolStripMenuItem.Size = new System.Drawing.Size(199, 24);
            this.equipmentDataToolStripMenuItem.Text = "Equipment Data";
            this.equipmentDataToolStripMenuItem.Click += new System.EventHandler(this.equipmentDataToolStripMenuItem_Click);
            // 
            // loadableSetDataToolStripMenuItem
            // 
            this.loadableSetDataToolStripMenuItem.Name = "loadableSetDataToolStripMenuItem";
            this.loadableSetDataToolStripMenuItem.Size = new System.Drawing.Size(199, 24);
            this.loadableSetDataToolStripMenuItem.Text = "Loadable Set Data";
            this.loadableSetDataToolStripMenuItem.Click += new System.EventHandler(this.loadableSetDataToolStripMenuItem_Click);
            // 
            // productDataToolStripMenuItem
            // 
            this.productDataToolStripMenuItem.Name = "productDataToolStripMenuItem";
            this.productDataToolStripMenuItem.Size = new System.Drawing.Size(199, 24);
            this.productDataToolStripMenuItem.Text = "Product Data";
            this.productDataToolStripMenuItem.Click += new System.EventHandler(this.productDataToolStripMenuItem_Click);
            // 
            // stockerDataToolStripMenuItem
            // 
            this.stockerDataToolStripMenuItem.Name = "stockerDataToolStripMenuItem";
            this.stockerDataToolStripMenuItem.Size = new System.Drawing.Size(199, 24);
            this.stockerDataToolStripMenuItem.Text = "Inline Stocker Data";
            this.stockerDataToolStripMenuItem.Click += new System.EventHandler(this.stockerDataToolStripMenuItem_Click);
            // 
            // networkDataToolStripMenuItem
            // 
            this.networkDataToolStripMenuItem.Name = "networkDataToolStripMenuItem";
            this.networkDataToolStripMenuItem.Size = new System.Drawing.Size(199, 24);
            this.networkDataToolStripMenuItem.Text = "Network Data";
            this.networkDataToolStripMenuItem.Click += new System.EventHandler(this.networkDataToolStripMenuItem_Click);
            // 
            // simulationToolStripMenuItem
            // 
            this.simulationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.singleRunOptionToolStripMenuItem,
            this.runToolStripMenuItem,
            this.simulationRunWithAutoModToolStripMenuItem});
            this.simulationToolStripMenuItem.Name = "simulationToolStripMenuItem";
            this.simulationToolStripMenuItem.Size = new System.Drawing.Size(89, 23);
            this.simulationToolStripMenuItem.Text = "Simulation";
            this.simulationToolStripMenuItem.Visible = false;
            // 
            // singleRunOptionToolStripMenuItem
            // 
            this.singleRunOptionToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("singleRunOptionToolStripMenuItem.Image")));
            this.singleRunOptionToolStripMenuItem.Name = "singleRunOptionToolStripMenuItem";
            this.singleRunOptionToolStripMenuItem.Size = new System.Drawing.Size(232, 24);
            this.singleRunOptionToolStripMenuItem.Text = "Single Run Option";
            this.singleRunOptionToolStripMenuItem.Click += new System.EventHandler(this.singleRunOptionToolStripMenuItem_Click);
            // 
            // runToolStripMenuItem
            // 
            this.runToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("runToolStripMenuItem.Image")));
            this.runToolStripMenuItem.Name = "runToolStripMenuItem";
            this.runToolStripMenuItem.Size = new System.Drawing.Size(232, 24);
            this.runToolStripMenuItem.Text = "Simulation Run";
            this.runToolStripMenuItem.Click += new System.EventHandler(this.runToolStripMenuItem_Click);
            // 
            // simulationRunWithAutoModToolStripMenuItem
            // 
            this.simulationRunWithAutoModToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("simulationRunWithAutoModToolStripMenuItem.Image")));
            this.simulationRunWithAutoModToolStripMenuItem.Name = "simulationRunWithAutoModToolStripMenuItem";
            this.simulationRunWithAutoModToolStripMenuItem.Size = new System.Drawing.Size(232, 24);
            this.simulationRunWithAutoModToolStripMenuItem.Text = "Simulation Run with VIP";
            this.simulationRunWithAutoModToolStripMenuItem.Click += new System.EventHandler(this.simulationRunWithAutoModToolStripMenuItem_Click);
            // 
            // windowToolStripMenuItem
            // 
            this.windowToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.floatToolStripMenuItem,
            this.resetLayoutToolStripMenuItem});
            this.windowToolStripMenuItem.Name = "windowToolStripMenuItem";
            this.windowToolStripMenuItem.Size = new System.Drawing.Size(74, 23);
            this.windowToolStripMenuItem.Text = "Window";
            this.windowToolStripMenuItem.Visible = false;
            // 
            // floatToolStripMenuItem
            // 
            this.floatToolStripMenuItem.Name = "floatToolStripMenuItem";
            this.floatToolStripMenuItem.Size = new System.Drawing.Size(162, 24);
            this.floatToolStripMenuItem.Text = "Float";
            this.floatToolStripMenuItem.Click += new System.EventHandler(this.floatToolStripMenuItem_Click_1);
            // 
            // resetLayoutToolStripMenuItem
            // 
            this.resetLayoutToolStripMenuItem.Name = "resetLayoutToolStripMenuItem";
            this.resetLayoutToolStripMenuItem.Size = new System.Drawing.Size(162, 24);
            this.resetLayoutToolStripMenuItem.Text = "Reset Layout";
            this.resetLayoutToolStripMenuItem.Click += new System.EventHandler(this.resetLayoutToolStripMenuItem_Click_1);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tutorialToolStripMenuItem,
            this.toolStripSeparator2,
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(51, 23);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // tutorialToolStripMenuItem
            // 
            this.tutorialToolStripMenuItem.Name = "tutorialToolStripMenuItem";
            this.tutorialToolStripMenuItem.Size = new System.Drawing.Size(127, 24);
            this.tutorialToolStripMenuItem.Text = "Tutorial";
            this.tutorialToolStripMenuItem.Click += new System.EventHandler(this.tutorialToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(124, 6);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(127, 24);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.toolStrip1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(784, 30);
            this.panel1.TabIndex = 2;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStrip1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripButton,
            this.openToolStripButton,
            this.saveToolStripButton,
            this.toolStripSeparator,
            this.tsBtn_SingleRunOption,
            this.tsBtn_Run,
            this.tsBtn_Stop});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(784, 30);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // newToolStripButton
            // 
            this.newToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.newToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("newToolStripButton.Image")));
            this.newToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newToolStripButton.Name = "newToolStripButton";
            this.newToolStripButton.Size = new System.Drawing.Size(23, 27);
            this.newToolStripButton.Text = "&New";
            this.newToolStripButton.Click += new System.EventHandler(this.newToolStripButton_Click);
            // 
            // openToolStripButton
            // 
            this.openToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.openToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("openToolStripButton.Image")));
            this.openToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.openToolStripButton.Name = "openToolStripButton";
            this.openToolStripButton.Size = new System.Drawing.Size(23, 27);
            this.openToolStripButton.Text = "&Open";
            this.openToolStripButton.Click += new System.EventHandler(this.openToolStripButton_Click);
            // 
            // saveToolStripButton
            // 
            this.saveToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.saveToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("saveToolStripButton.Image")));
            this.saveToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveToolStripButton.Name = "saveToolStripButton";
            this.saveToolStripButton.Size = new System.Drawing.Size(23, 27);
            this.saveToolStripButton.Text = "&Save";
            this.saveToolStripButton.Visible = false;
            this.saveToolStripButton.Click += new System.EventHandler(this.saveToolStripButton_Click);
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(6, 30);
            // 
            // tsBtn_SingleRunOption
            // 
            this.tsBtn_SingleRunOption.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsBtn_SingleRunOption.Image = ((System.Drawing.Image)(resources.GetObject("tsBtn_SingleRunOption.Image")));
            this.tsBtn_SingleRunOption.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsBtn_SingleRunOption.Name = "tsBtn_SingleRunOption";
            this.tsBtn_SingleRunOption.Size = new System.Drawing.Size(23, 27);
            this.tsBtn_SingleRunOption.Text = "Single Run Option";
            this.tsBtn_SingleRunOption.Visible = false;
            this.tsBtn_SingleRunOption.Click += new System.EventHandler(this.singleRunOptionToolStripMenuItem_Click);
            // 
            // tsBtn_Run
            // 
            this.tsBtn_Run.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsBtn_Run.Enabled = false;
            this.tsBtn_Run.Image = ((System.Drawing.Image)(resources.GetObject("tsBtn_Run.Image")));
            this.tsBtn_Run.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsBtn_Run.Name = "tsBtn_Run";
            this.tsBtn_Run.Size = new System.Drawing.Size(23, 27);
            this.tsBtn_Run.Text = "Run";
            this.tsBtn_Run.Visible = false;
            this.tsBtn_Run.Click += new System.EventHandler(this.tsBtn_Run_Click);
            // 
            // tsBtn_Stop
            // 
            this.tsBtn_Stop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsBtn_Stop.Enabled = false;
            this.tsBtn_Stop.Image = ((System.Drawing.Image)(resources.GetObject("tsBtn_Stop.Image")));
            this.tsBtn_Stop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsBtn_Stop.Name = "tsBtn_Stop";
            this.tsBtn_Stop.Size = new System.Drawing.Size(23, 27);
            this.tsBtn_Stop.Text = "Stop";
            this.tsBtn_Stop.Visible = false;
            this.tsBtn_Stop.Click += new System.EventHandler(this.tsBtn_Stop_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 689);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Main";
            this.Text = "Integrated Fab Simulator";
            this.Load += new System.EventHandler(this.Main_Load);
            this.MdiChildActivate += new System.EventHandler(this.Main_MdiChildActivate);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem simulationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tutorialToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripMenuItem singleRunOptionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem runToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton tsBtn_SingleRunOption;
        private System.Windows.Forms.ToolStripButton tsBtn_Run;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageDispatchingRulesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem windowToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem floatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetLayoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton newToolStripButton;
        private System.Windows.Forms.ToolStripButton openToolStripButton;
        private System.Windows.Forms.ToolStripButton saveToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripButton tsBtn_Stop;
        private System.Windows.Forms.ToolStripMenuItem simulationRunWithAutoModToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recentFilesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inputDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem errorCheckToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem loadAnOutputReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem equipmentDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadableSetDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stockerDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem networkDataToolStripMenuItem;
    }
}

