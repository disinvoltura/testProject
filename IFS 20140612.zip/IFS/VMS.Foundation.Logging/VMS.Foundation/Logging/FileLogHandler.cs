﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Text;
using System.IO;

namespace VMS.Foundation.Logging
{
    public class FileLogHandler : LogHandler
    {
        private FileStream mFS;
        private StreamWriter mSW;
        private string mLogFileName;
        
        public FileLogHandler(LogFormatter fmt)
            : base(fmt)
        {
            DateTime now =DateTime.Now;
            mLogFileName = now.Year.ToString()+"."+now.Month+"."+now.Day+" " + now.Hour+"."+now.Minute+"."+now.Second+".log";
            mFS = new FileStream(mLogFileName, FileMode.Create);
            mSW = new StreamWriter(mFS, System.Text.Encoding.Default);
            mSW.BaseStream.Seek(0, SeekOrigin.Begin);

        }

        public FileLogHandler(string productName, LogFormatter fmt)
            : base(fmt)
        {
            string path = System.Reflection.Assembly.GetEntryAssembly().Location;
            if (path.Contains("exe"))
                path = path.Substring(0, path.LastIndexOf('\\'));
            path += "\\Logs";
            if (!System.IO.Directory.Exists(path))
            {
                DirectoryInfo info = null;
                try
                {
                    info = System.IO.Directory.CreateDirectory(path);
                }
                catch (Exception ex) { }

                if (info == null)
                {
                    path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                    path += "\\IFS";
                    try
                    {
                        info = System.IO.Directory.CreateDirectory(path);
                    }
                    catch (Exception ex) { }

                    if (info == null)
                        path = "";
                }
            }
            DateTime now = DateTime.Now;
            mLogFileName = productName + "_"+ now.Year.ToString() + "." + now.Month + "." + now.Day + " " + now.Hour + "." + now.Minute + "." + now.Second + ".log";
            if (!string.IsNullOrEmpty(path))
                mLogFileName = path + "\\" + mLogFileName;

            mFS = new FileStream(mLogFileName, FileMode.Create);
            mSW = new StreamWriter(mFS, System.Text.Encoding.Default);
            mSW.BaseStream.Seek(0, SeekOrigin.Begin);

            mSW.WriteLine("============================================================");
            mSW.WriteLine("Program Execution Log for " + productName);
            mSW.WriteLine("Started logging at " + now.Year.ToString() + "." + now.Month + "." + now.Day + " " + now.Hour + "." + now.Minute + "." + now.Second);
            mSW.WriteLine("============================================================");

        }

        protected override void DoPublish(LogRecord record)
        {
            Write(Formatter.Format(record));
        }

        protected virtual void Write(string text)
        {
            if (!text.EndsWith(Environment.NewLine))
                mSW.WriteLine(text);
            else
                mSW.Write(text);

            mSW.Flush();
        }

        protected void WriteFooter()
        {
            if (Formatter != null && mSW != null)
            {
                mSW.WriteLine(Formatter.GetFooter(this));
                mSW.Flush();
            }
        }

        protected virtual void ResetWriter()
        {
            WriteFooter();
            CloseWriter();
            
        }

        protected void CloseWriter()
        {
            if (mSW != null)
            {
                try
                {
                    mSW.Flush();
                    mSW.Close();
                }
                catch (Exception e)
                {
                    throw new InvalidOperationException("Could not close writer.", e);
                    // do need to invoke an error handler
                    // at this late stage
                }
            }
        }

        protected void WriteHeader()
        {
            if (Formatter != null && mSW != null)
            {
                mSW.WriteLine (Formatter.GetHeader(this));
            }
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            
            ResetWriter();

        }
    }
}
