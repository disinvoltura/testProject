﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VMS.Foundation.Logging
{
    public abstract class LogHandler : IDisposable
    {
        readonly static LogFormatter defaultFormatter = new SimpleFormatter();

        LogFormatter _formatter = null;
        LogFilter _filter = null;
        LogLevel _level = LogLevel.None;
        Encoding _encoding = Encoding.Default;
        string _name;

        // .ctor
        public LogHandler(LogFormatter formatter)
        {
            _formatter = formatter;
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        /// Return the <tt>LogFormatter</tt> for this <tt>LogHandler</tt>.
        public LogFormatter Formatter
        {
            get { return (_formatter == null) ? defaultFormatter : _formatter; }
            set { _formatter = value; }
        }
        /// Reuturn the current <tt>Filter</tt> for this <tt>LogHandler</tt>.
        public LogFilter Filter
        {
            get { return _filter; }
            set { _filter = value; }
        }
        /// <summary>
        /// The encoding to use for the file stream.
        /// </summary>
        public Encoding Encoding
        {
            get { return _encoding; }
            set { _encoding = value; }
        }
        /// log level specifying which message levels will be logged by this <tt>LogHandler</tt>. 
        public LogLevel Level
        {
            get { return _level; }
            set { _level = value; }
        }

        public virtual void Clear() {}

        public virtual void Initialize() {}

        public virtual bool IsLoggable(LogRecord record)
        {
            if (_level != LogLevel.None && _level < record.Level)
                return false;

            if (_filter != null)
                return _filter.IsLoggable(record);

            return true;
        }

        // Flush any buffered output.
        public virtual void Flush()
        {
        }

        // Publish a <tt>LogRecord</tt>.
        public virtual void Publish(LogRecord record)
        {
            if (!IsLoggable(record))
                return;

            DoPublish(record);
        }

        protected abstract void DoPublish(LogRecord record);

        /// implements IDisposable
        public void Dispose()
        {
            Dispose(true);
        }

        // Close the <tt>LogHandler</tt> and free all associated resources.
        public void Close()
        {
            Dispose();
        }

        // Close the <tt>LogHandler</tt> and free all associated resources.
        protected virtual void Dispose(bool disposing)
        {
        }
    }
}
