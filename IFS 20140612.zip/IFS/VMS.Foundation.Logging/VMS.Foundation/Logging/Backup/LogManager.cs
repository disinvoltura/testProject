﻿using System;
using System.Collections;
using System.Diagnostics;
using System.Threading;
using System.Configuration;

namespace VMS.Foundation.Logging
{
    public class LogManager
    {
        private static LogManager _instance;
        private static LogManager Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new LogManager();
                    _instance._Configure();
                }
                return _instance;
            }
        }

        private Hashtable _table;
        private Logger _root;

        private LogManager()
        {
            // Otherwise DomainUnload is fired
            AppDomain.CurrentDomain.DomainUnload += new EventHandler(_OnDomainUnload);
            _table = Hashtable.Synchronized(new Hashtable());
            _root = new RootLogger(LogLevel.Informational);
        }
        private void _OnDomainUnload(object sender, EventArgs e)
        {
            _Shutdown();
        }

        private void _Configure()
        {
            ConfigurationSettings.GetConfig("vms.foundation.logging");
        }

        private void _Shutdown()
        {
            lock (_table)
            {
                foreach (Object value in _table.Values)
                {
                    if (value is Logger)
                    {
                        ((Logger)value).Shutdown();
                    }
                    else if (value is ProvisionNode)
                    {
                        foreach (Logger l in (ProvisionNode)value)
                            l.Shutdown();
                    }
                }

                _table.Clear();
                _root.Shutdown();
            }
        }

        private void _UpdateParents(Logger logger)
        {
            string name = logger.Name;
            int length = name.Length;
            bool parentFound = false;

            // if name = "w.x.y.z", loop through "w.x.y", "w.x" and "w", but not "w.x.y.z" 
            for (int i = name.LastIndexOf('.', length - 1); i >= 0; i = name.LastIndexOf('.', i - 1))
            {
                string key = name.Substring(0, i);
                Object node = _table[key];
                // Create a provision node for a future parent.
                if (node == null)
                {
                    ProvisionNode pn = new ProvisionNode(logger);
                    _table[key] = pn;
                }
                else if (node is Logger)
                {
                    parentFound = true;
                    logger.SetParent((Logger)node);
                    break; // no need to update the ancestors of the closest ancestor
                }
                else
                {
                    System.Diagnostics.Debug.Assert(node is ProvisionNode);
                    ((ProvisionNode)node).Add(logger);
                }
            }

            // If we could not find any existing parents, then link with root.
            if (!parentFound)
            {
                logger.SetParent(_root);
            }
        }

        private void _UpdateChildren(ProvisionNode pn, Logger logger)
        {
            for (int i = 0; i < pn.Count; i++)
            {
                Logger childLogger = (Logger)pn[i];

                // Unless this child already points to a correct (lower) parent,
                // make log.Parent point to childLogger.Parent and childLogger.Parent to log.
                if (!childLogger.Parent.Name.StartsWith(logger.Name))
                {
                    logger.SetParent(childLogger.Parent);
                    childLogger.SetParent(logger);
                }
            }
        }

        private Logger _GetLogger(string name)
        {
            if (name == null || name.Length == 0)
                return _root;
            //throw new ArgumentNullException("name");

            Logger logger;
            lock (_table)
            {
                object node = _table[name];
                if (node == null)
                {
                    logger = new Logger(name);
                    _table[name] = logger;
                    _UpdateParents(logger);
                }
                else if (node is ProvisionNode)
                {
                    logger = new Logger(name);
                    _table[name] = logger;
                    _UpdateChildren((ProvisionNode)node, logger);
                    _UpdateParents(logger);
                }
                else
                {
                    logger = node as Logger;
                }
            }
            return logger;
        }

        private Logger _Exists(string name)
        {
            if (name == null)
                throw new ArgumentNullException("name");
            if (name.Length == 0)
                return _root;

            return _table[name] as Logger;
        }

        public static Logger Exists(string name)
        {
            return Instance._Exists(name);
        }

        /// <summary>
        /// Return a new logger instance named as the first parameter using
        /// the default factory.
        /// </summary>
        public static Logger GetLogger()
        {
            return Instance._GetLogger(string.Empty);
        }
        public static Logger GetLogger(string name)
        {
            return Instance._GetLogger(name);
        }

        public static Logger GetLogger(Type type)
        {
            return Instance._GetLogger(type.FullName);
        }

        #region logger helper
        public static void Error(string message)
        {
            Instance._root.Error(message);
        }
        public static void Error(string message, Exception exception)
        {
            Instance._root.Error(message, exception);
        }
        public static void Warning(string message)
        {
            Instance._root.Warning(message);
        }
        public static void Warning(string message, Exception exception)
        {
            Instance._root.Warning(message, exception);
        }
        public static void Info(string message)
        {
            Instance._root.Info(message);
        }
        public static void Debug(string message)
        {
            Instance._root.Debug(message);
        }

        public static void Error(string source, string message)
        {
            GetLogger(source).Error(message);
        }
        public static void Error(string source, string message, Exception exception)
        {
            GetLogger(source).Error(message, exception);
        }
        public static void Warning(string source, string message)
        {
            GetLogger(source).Warning(message);
        }
        public static void Warning(string source, string message, Exception exception)
        {
            GetLogger(source).Warning(message, exception);
        }
        public static void Info(string source, string message)
        {
            GetLogger(source).Info(message);
        }
        public static void Debug(string source, string message)
        {
            GetLogger(source).Debug(message);
        }
        #endregion logger helper

        /// <summary>
        /// Shutting down a hierarchy will <i>safely</i> close and remove
        /// all handlers in all loggers including the root logger.
        /// </summary>
        public static void Shutdown()
        {
            Instance._Shutdown();
            _instance = null;
        }

        #region RootLogger
        private class RootLogger : Logger
        {
            public RootLogger(LogLevel level)
                : base("")
            {
                this.Level = level;
            }
        }
        #endregion

        #region ProvisionNode
        private class ProvisionNode : ArrayList
        {
            public ProvisionNode(Logger logger) { this.Add(logger); }
        }
        #endregion
    }
}
