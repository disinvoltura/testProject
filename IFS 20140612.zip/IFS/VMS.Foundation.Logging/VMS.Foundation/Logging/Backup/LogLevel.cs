﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VMS.Foundation.Logging
{
    /// <summary>
    /// LogLevel: Enumeration of the logging levels for the system
    /// </summary>
    public enum LogLevel
    {
        /// <summary>
        /// No logging level.
        /// </summary>
        None = 0,
        /// <summary>
        /// Only log errors.
        /// </summary>
        Error = 1,
        /// <summary>
        /// Log warning levels.
        /// </summary>
        Warning = 2,
        /// <summary>
        /// Log informational events.
        /// </summary>
        Informational = 3,
        /// <summary>
        /// Log only debug events.
        /// </summary>
        Debug = 4,
        /// <summary>
        /// Always log.
        /// </summary>
        Always = 5,

    }
}
