﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.Engine
{
    public class LocalEvent: SimEvent
    {
        #region Member Variables
        private string _Source;
        //private EventObjectSimulator _Source;

        #endregion

        #region Properties
        public string ObjectName
        {
            get { return _Source; }
        }
        #endregion

        #region Constructors
        public LocalEvent(string source, string eventName, double time)
            : base (eventName, time)
        {
            _Source = source;           
        }

        public LocalEvent(string source, string eventName, double time, int priority)
            : base(eventName, time, priority)
        {
            _Source = source;
        }


        #endregion

        #region Methods
        public override bool Equals(object obj)
        {
            bool rslt = false;
            if (obj is LocalEvent)
            {
                LocalEvent target = (LocalEvent)obj;

                if (this.ID == target.ID && this.ObjectName== target.ObjectName && this.Name == target.Name && this.Time == target.Time)
                    rslt = true;
                //if (this.ID == target.ID && this.Source.Name == target.Source.Name && this.Name == target.Name && this.Time == target.Time)
            }
            return rslt;
        }

        public override int GetHashCode()
        {
            string hashstring = this.ID + "." + this.ObjectName + "." + this.Name + "." + this.Time;
            return hashstring.GetHashCode();
        }

        public override string ToString()
        {
            string value = string.Empty;
            value = string.Format("L({0}, {1}, {2}, {3})", this.ID, this.ObjectName, this.Name, this.Time);

            return value;
        }
        #endregion
    }
}
