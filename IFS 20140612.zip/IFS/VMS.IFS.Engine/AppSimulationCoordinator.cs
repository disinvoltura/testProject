﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.Foundation.Logging;
using VMS.IFS.Engine.ApplicationConnection;

namespace VMS.IFS.Engine
{    
    public class AppSimulationCoordinator: SimulationCoordinator
    {
        #region Member Variables
        //private ApplicationWriter _Writer;
        //private ApplicationReader _Reader;

        //Application 으로부터 기다리고 있는 Delay Message 의 수
        //private int _Delays = 0;
        //private int _totalOEs = 0;
        protected const string ReadMessage = "ReadMessage";
        #endregion

        #region Properties
        #endregion

        #region Constructors
        public AppSimulationCoordinator()
            : base()
        {
            //_Reader = ApplicationConnector.Reader;
            //_Writer = ApplicationConnector.Writer;
        }

        //public AppSimulationCoordinator(ApplicationReader r, ApplicationWriter w)
        //    : base()
        //{
        //    _Reader = r;
        //    _Writer = w;
        //}
        #endregion

        #region Methods
        public override bool Run()
        {
            _Logger.Debug("Coordinator runs");
            _Clock = 0;

            bool rslt = true;

            Execute_Initialize_Routine();

            while (!_EOS.StopCondition)
            {
                CoordinatorEvent nextEvent = RetrieveEvent();
                if (nextEvent == null)
                    break;//irregular abort.
                _Clock = nextEvent.Time;

                switch (nextEvent.Name)
                {
                    case ScheduleLE:
                        {
                            Execute_ScheduleLE_Routine(nextEvent.e, _Clock);
                            break;
                        }
                    case GetNextLE:
                        {
                            Execute_GetNextLE_Routine(_Clock);
                            break;
                        }
                    case ExecuteLE:
                        {
                            Execute_ExecuteLE_Routine(nextEvent.e, _Clock);
                            break;
                        }
                    case ReadMessage:
                        {
                            Execute_ReadMessage_Routine(_Clock);
                            break;
                        }

                    case Terminate:
                        {
                            Execute_Terminate_Routine(_Clock);
                            break;
                        }
                }
                _Logger.Debug("Coordinator Event is executed : " + nextEvent.ToString());
            }
            _Logger.Debug("Coordinator ends");

            return rslt;
        }

        public override void Dispose()
        {
            _LEL.Initialize();
            _FEL.Initialize();

            string[] objectNames = _ObjectList.Keys.ToArray<string>();
            for (int i = 0; i < objectNames.Length; i++)
            {
                _ObjectList[objectNames[i]].Dispose();
                _ObjectList.Remove(objectNames[i]);
            }
        }
        #endregion

        #region Event Routines
        protected override void Execute_Initialize_Routine()
        {
            //Initialize State Variables
            _SC = 1;
            _RSV = false;
            _Clock = 0;

            foreach (string name in _ObjectList.Keys)
            {
                EventObjectSimulator objectSimulator = _ObjectList[name];
                objectSimulator.Run();
            }

            //ScheduleEvent()
        }

        protected override void Execute_ScheduleLE_Routine(LocalEvent e, double now)
        {
            _LEL.ScheduleEvent(e);
            if (_SC == 1)
            {
                _SC = -1;
                _RSV = true;
            }
            else
            {
                _RSV = false;
            }

            if (_RSV)
                ScheduleEvent(GetNextLE, now);
        }

        protected override void Execute_GetNextLE_Routine(double now)
        {
            _SC = 0;
            LocalEvent e = _LEL.RetrieveEvent();
            if (e != null)
            {
                if (_EOS.CanSchedule(e))
                    ScheduleEvent(ExecuteLE, e.Time, e);
                else
                    ScheduleEvent(Terminate, now);

            }
            else
            {
                System.Diagnostics.Debug.WriteLine("No more LocalEvent to execute!!!");
            }
        }

        private double _LastReceivedTime;
        protected override void Execute_ExecuteLE_Routine(LocalEvent e, double now)
        {
            ExecuteLocalEvent(e);

            ScheduleEvent(ReadMessage, now);            
        }

        private System.Timers.Timer msgTimer;
        private string _LastTmsg;
        private void Execute_ReadMessage_Routine(double now)
        {
            string Tmsg = string.Empty;
            bool sendTmsg = true;
            if (_LEL.Count > 0)
            {   
                Tmsg = makeTimeAdvanceMessage(_LEL[0]);
            }
            else
                Tmsg = "Clock_Nothing";

            if (sendTmsg)
            {
                try
                {
                    Send_Msg(Tmsg);

                    
                    _LastTmsg = Tmsg;

                    ApplicationMessage msg = null;
                    //msgTimer = new System.Timers.Timer(500);
                    //msgTimer.Elapsed += new System.Timers.ElapsedEventHandler(msgTimer_Elapsed);
                    //msgTimer.AutoReset = false;
                    //msgTimer.Start();
                    while (msg == null) //수정 3/23 김현식
                    {
                        msg = Read_Msg();
                    }

                    //msgTimer.Stop();
                    if (msg.Type == ApplicationMessageType.Delay)
                        _LastReceivedTime = msg.EventTime;

                    if (msg.Type == ApplicationMessageType.Delay)
                    {
                        //_Delays--;
                        FireSchedulingArc(msg);
                    }
                }
                catch (Exception ex)
                {
                    _Logger.Error("Read_Msg() Error", ex);
                }
            }

            if (_LEL.Count > 0)
            {
                _SC = -1; _RSV = true;
            }
            else
            {
                _SC = 1; _RSV = false;
            }

            if (_RSV)
                ScheduleEvent(GetNextLE, now);
        }

        //void msgTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        //{
        //    Send_Msg(_LastTmsg);
        //}

        protected override void Execute_Terminate_Routine(double now)
        {
            //_Writer.WriteLine("Simulation End!");
            ApplicationConnector.Send_Msg("Simulation End!");
        }
        #endregion

        #region Communication Methods
        private string makeTimeAdvanceMessage(LocalEvent e)
        {
            string msg = string.Empty;
            msg = string.Format("Clock_Exist_{0}_{1}#{2}# #{3}# # ", e.Name, e.ID, e.ObjectName, e.Time);

            return msg;
        }

        private void Send_Msg(string msg)
        {
            try
            {
                ApplicationConnector.Send_Msg(msg);
            }
            catch (Exception ex)
            {
                throw new Exception("Error while sending a message", ex);
            }
        }

        private ApplicationMessage Read_Msg()
        {
            _Logger.Debug("Start to Read a Message");
            //string strLine = _Reader.ReadLine();
            string strLine = string.Empty;

            try
            {
                strLine = ApplicationConnector.Read_Msg();
            }
            catch (Exception ex)
            {
                _Logger.Error("Error while reading a message");
                if (!string.IsNullOrEmpty(strLine))
                    _Logger.Error(" - line: " + strLine);
                throw new Exception("Error while reading a message", ex);
            }

            //“Clock_Exist_uLGL_51#M1# #461.123155# # “
            //“Delay_Conveyor_SOC#CNV01#0#1404.036132# # “
            //“Clock_Exist_EOD_2#CNV00# #1440# # “

            _Logger.Debug("- Read_Msg: " + strLine);

            ApplicationMessage msg = new ApplicationMessage();

            if (strLine[0].Equals('D'))
            {
                //Delay-type message
                //Msg: Delay_<Action>_<EventName>#<ObjectID>#<CassetteID>#<EventTime>#<FromLoc>#<ToLoc>
                int cr = -1;
                msg.Type = ApplicationMessageType.Delay;

                string[] delayMsg = strLine.Split('#');
                string[] msgType = delayMsg[0].Split('_');
                if (!msgType[1].Equals("Conveyor"))
                {
                    //Retrieval or Delivery
                    msg.Action = msgType[1];

                    //Stocker's crane id
                    if (delayMsg[1].Split('_').Length == 1)
                        cr = 1;
                    else
                        cr = int.Parse(delayMsg[1].Split('_')[1]);

                    delayMsg[1] = delayMsg[1].Split('_')[0];
                }
                else
                {
                    msg.Action = "Conveyor";
                }

                msg.EventName = msgType[2];
                msg.ObjectID = delayMsg[1];
                msg.EventTime = double.Parse(delayMsg[3]);

                //From and To
                string[] from = delayMsg[4].Split('_');
                if (delayMsg[4].StartsWith("inport_"))
                {
                    msg.Source = from[1];
                }
                else if (delayMsg[4].StartsWith("outport_"))
                {
                    msg.Source = from[1];
                }
                else
                {
                    //conveyor name, eqp name, buffer (Stocker)
                    msg.Source = delayMsg[4];
                }

                string[] to = delayMsg[5].Split('_');
                if (delayMsg[5].StartsWith("inport_"))
                {
                    msg.Destination = to[1];
                }
                else if (delayMsg[5].StartsWith("outport_"))
                {
                    msg.Destination = to[1];
                }
                else
                {
                    //conveyor name, eqp name, buffer (Stocker)
                    msg.Destination = delayMsg[5];
                }
            }
            else if (strLine.StartsWith("No More"))
            {
                msg.Type = ApplicationMessageType.NoMoreEntity;
            }
            else if (strLine[0].Equals('C')) //수정 3/23 김현식
            {
                msg.Type = ApplicationMessageType.Clock;

                string[] delayMsg = strLine.Split('#');
                string[] msgType = delayMsg[0].Split('_');

                msg.Action = msgType[1];

                if (msg.Action.Equals("Exist"))
                {
                    msg.EventName = msgType[2];
                    msg.EventNo = int.Parse(msgType[3]);
                    msg.ObjectID = delayMsg[1];
                    msg.EventTime = double.Parse(delayMsg[3]);
                }
                //수정 3/23 김현식
                else if (msg.Action.Equals("Nothing"))
                    return null;
            }
            //수정 3/23 김현식
            else
            {
                return null;
            }

            return msg;
        }

        private void FireSchedulingArc(ApplicationMessage msg)
        {
            //ObjectID 가 class name 이 아니므로, 문제가 야기됨
            //Better IDea? This is not good way to implement....
            if (msg.Action == "Conveyor")
                _ObjectList["Conveyor"].FireSchedulingArc(msg);
            else
                _ObjectList["InlineStocker"].FireSchedulingArc(msg);
        }
        #endregion
    }

    public enum ApplicationMessageType { Clock, Delay, NoMoreEntity };
    //Clock: Exit, Nothing
    //Delay: conveyor, Retrieval, Delivery
    public class ApplicationMessage
    {
        public ApplicationMessageType Type;
        public string Action; //Exit and Nothing for Clock, Conveyor, Retrieval, Delivery for Delay
        public string EventName;
        public int EventNo; //Only applies for Clock_Exist
        public string ObjectID;
        public string CassetteID;// only applies for Delay-type message
        public double EventTime;
        public string Source;//Only apply for Delay-type message
        public string Destination; //only apply for Delay-type message
    }
}
