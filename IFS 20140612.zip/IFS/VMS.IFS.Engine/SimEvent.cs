﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.Engine
{
    public class SimEvent
    {
        #region Static Member Variables
        private static int _EventCount;
        #endregion

        #region Member Variables
        private int _ID;
        private string _Name;
        private double _Time;
        private int _Priority;
        private Dictionary<string, object> _Parameters;
        #endregion

        #region Properties
        public int ID
        {
            get { return _ID; }
        }
        public string Name
        {
            get { return _Name; }                
        }
        public double Time
        {
            get { return _Time; }
        }
        public Dictionary<string, object> Parameters
        {
            get { return _Parameters; }
        }

        /// <summary>
        /// Priority on the event (higher value has a higher priority over other events with the same event time
        /// </summary>
        public int Priority { get { return _Priority; } }

        #endregion

        #region Constructors
        public SimEvent(string name, double time)
        {
            _ID = ++SimEvent._EventCount;
            _Name = name;
            _Time = time;
            _Priority = 0;
            _Parameters = new Dictionary<string, object>();
        }

        public SimEvent(string name, double time, int priority)
            : this(name, time)
        {
            _Priority = priority;
        }
        #endregion

        #region Methods
        public override bool Equals(object obj)
        {
            bool rslt = false;
            if (obj is SimEvent)
            {
                SimEvent target = (SimEvent)obj;

                if (this.ID == target.ID && this.Name == target.Name && this.Time == target.Time)
                    rslt = true;
            }
            return rslt;
        }

        public override int GetHashCode()
        {
            string hashstring = this.ID + "." + this.Name + "." + this.Time;
            return hashstring.GetHashCode();
        }
        #endregion

    }
}
