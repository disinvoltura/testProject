﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.Engine
{
    public class CoordinatorEvent: SimEvent
    {
        #region Member Variables
        private LocalEvent _E;
        #endregion

        #region Properties
        public LocalEvent e
        {
            get { return _E; }
        }
        #endregion

        #region Constructors
        public CoordinatorEvent(string eventName, double time)
            : base(eventName, time)
        {
        }

        public CoordinatorEvent(string eventName, double time, LocalEvent e)
            : base (eventName, time)
        {
            _E = e;
        }
        #endregion

        #region Methods
        public override string ToString()
        {
            string value = string.Empty;
            
            if (_E == null)
                value = string.Format("C({0}, {1}, {2})", this.ID, this.Name, this.Time);
            else
                value = string.Format("C({0}, {1}, {2}, {3})", this.ID, this.Name, this.Time, _E.ToString());

            return value;
        }
        #endregion
    }
}
