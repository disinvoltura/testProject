﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Net.Sockets;
using System.Net;
using VMS.Foundation.Logging;

namespace VMS.IFS.Engine.ApplicationConnection
{
    public delegate void ClientConnectedEventHandler();
    public delegate void ClientDisconnectedEventHandler();
    public static class ApplicationConnector
    {
        #region Member Variables
        private static NetworkStream _Stream;
        private static int _Port = 5555;
        private static TcpListener _Listener = null;
        private static ApplicationWriter _Writer = null;
        private static ApplicationReader _Reader = null;
        private static Socket _Client;
        #endregion

        public static event ClientConnectedEventHandler ClientConnected;
        public static event ClientDisconnectedEventHandler ClientDisconnected;

        #region Properties
        public static int Port
        {
            get { return _Port; }
            set { _Port = value; }
        }

        public static ApplicationWriter Writer
        {
            get { return _Writer; }
        }

        public static ApplicationReader Reader
        {
            get { return _Reader; }
        }
        #endregion

        #region Methods
        public static void Accept()
        {
            _Listener = null;
            try
            {
                _Listener = new TcpListener(IPAddress.Any, _Port);
                _Listener.Start();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Error Message: " + ex.StackTrace);
            }

            try
            {
                _Client = _Listener.AcceptSocket();

                if (_Client.Connected)
                {
                    _Stream = new NetworkStream(_Client);
                    _Reader = ApplicationReaderFactory.GetInstance("automod", _Stream);
                    //_Reader = new AutomodReader(_Stream);
                    _Writer = ApplicationWriterFactory.GetInstance("automod", _Stream);
                    //_Writer = new AutomodWriter(_Stream);
                    string rMsg = _Reader.ReadLine();

                    ClientConnected();
                }
            }
            catch { }
        }

        public static void Send_Msg(string msg)
        {
            System.Diagnostics.Debug.WriteLine("[Send] " + msg);

            Logger logger = LogManager.GetLogger("Communication");
            logger.Log(LogLevel.Debug, "Send: " + msg);

            try
            {                
                _Writer.WriteLine(msg);
            }
            catch (Exception ex)
            {
                logger.Error("VIP is disconnected.");
                System.Diagnostics.Debug.WriteLine("[Send] VIP is disconnected.");

                if (ClientDisconnected != null && ClientDisconnected.GetInvocationList().Length > 0)
                    ClientDisconnected();
                //throw new Exception("Error while sending a message", ex);
            }
        }

        public static string Read_Msg()
        {
            string msg = string.Empty;

            try
            {
                msg = _Reader.ReadLine();
            }
            catch (Exception ex)
            {
                if (ClientDisconnected != null && ClientDisconnected.GetInvocationList().Length > 0)
                    ClientDisconnected();
                //throw new Exception("Error while reading a message", ex);
            }

            Logger logger = LogManager.GetLogger("Communication");
            logger.Log(LogLevel.Debug, "Receive: " + msg);

            System.Diagnostics.Debug.WriteLine("[Read] " +  msg);

            System.Threading.Thread.Sleep(50); //by D. Kang 2014/05/29


            return msg;
        }

        public static void Close()
        {
            _Client.Close();
            _Writer.Close();
            _Reader.Close();
            _Stream.Close();
            _Listener.Stop();
        }
        #endregion
    }
}
