﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace VMS.IFS.Engine.ApplicationConnection
{
    public class ApplicationReader: IDisposable
    {
        protected StreamReader _BaseReader = null;

        public ApplicationReader(Stream stream)
        {
            this._BaseReader = new StreamReader(stream);
        }

        public string ReadLine()
        {
            int l0, l1;
            l0 = _BaseReader.Read();
            l1 = _BaseReader.Read();

            int length = (l0 << 8) | l1;

            char[] buffer = new char[length];

            _BaseReader.Read(buffer, 0, length);

            return new String(buffer);
        }

        public void Close()
        {
            this.Dispose();
        }

        public void Dispose()
        {
            if (this._BaseReader != null)
                this._BaseReader.Dispose();
        }
    }

    public static class ApplicationReaderFactory
    {
        public static ApplicationReader GetInstance(string name, Stream stream)
        {
            ApplicationReader rslt = null;

            rslt = new ApplicationReader(stream);

            return rslt;
        }
    }
}
