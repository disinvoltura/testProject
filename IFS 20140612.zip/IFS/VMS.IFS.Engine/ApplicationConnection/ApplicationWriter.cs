﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace VMS.IFS.Engine.ApplicationConnection
{
    public class ApplicationWriter
    {
        protected StreamWriter _BaseWriter = null;
        
        public ApplicationWriter(Stream stream)
        {
            _BaseWriter = new StreamWriter(stream);
        }

        public void WriteLine(string line)
        {
            char[] length = new char[2];
            length[0] = (char)(line.Length >> 8);
            length[1] = (char)(line.Length & 0xff);

            _BaseWriter.Write(length);
            _BaseWriter.Write(line);
            _BaseWriter.Flush();
        }

        public void Close()
        {
            this.Dispose();
        }

        public void Dispose()
        {
            if (_BaseWriter != null)
                _BaseWriter.Dispose();
        }
    }

    public static class ApplicationWriterFactory
    {
        public static ApplicationWriter GetInstance(string name, Stream stream)
        {
            ApplicationWriter rslt = null;

            rslt = new ApplicationWriter(stream);

            return rslt;
        }
    }
}
