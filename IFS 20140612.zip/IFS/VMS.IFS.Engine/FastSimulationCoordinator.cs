﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.Foundation.Logging;

namespace VMS.IFS.Engine
{    
    public class FastSimulationCoordinator: SimulationCoordinator
    {
        #region Member Variables
        #endregion

        #region Properties
        #endregion

        #region Constructors
        public FastSimulationCoordinator()
            : base()
        {
            
        }
        #endregion

        #region Methods
        public override void Dispose()
        {
            _LEL.Initialize();
            _FEL.Initialize();

            string[] objectNames = _ObjectList.Keys.ToArray<string>();
            for (int i = 0; i < objectNames.Length; i++)
            {
                _ObjectList[objectNames[i]].Dispose();
                _ObjectList.Remove(objectNames[i]);
            }

        }
        #endregion

        #region Event Routines
        protected override void Execute_Initialize_Routine()
        {
            //Initialize State Variables
            _SC = 1;
            _RSV = false;
            _Clock = 0;

            foreach (string name in _ObjectList.Keys)
            {
                EventObjectSimulator objectSimulator = _ObjectList[name];
                objectSimulator.Run();
            }

            //ScheduleEvent()
        }

        protected override void Execute_ScheduleLE_Routine(LocalEvent e, double now)
        {
            _LEL.ScheduleEvent(e);
            if (_SC == 1)
            {
                _SC = -1;
                _RSV = true;
            }
            else
            {
                _RSV = false;
            }

            if (_RSV)
                ScheduleEvent(GetNextLE, now);
        }

        protected override void Execute_GetNextLE_Routine(double now)
        {
            _SC = 0;
            LocalEvent e = _LEL.RetrieveEvent();
            if (e != null)
            {
                if (_EOS.CanSchedule(e))
                    ScheduleEvent(ExecuteLE, e.Time, e);
                else
                    ScheduleEvent(Terminate, now);

            }
            else
            {
                System.Diagnostics.Debug.WriteLine("No more LocalEvent to execute!!!");
            }
        }

        protected override void Execute_ExecuteLE_Routine(LocalEvent e, double now)
        {
            ExecuteLocalEvent(e);
            if (_LEL.Count > 0)
            {
                _SC = -1; _RSV = true;
            }
            else
            {
                _SC = 1; _RSV = false;
            }
            if (_RSV)
                ScheduleEvent(GetNextLE, now);
        }

        protected override void Execute_Terminate_Routine(double now)
        {

        }
        #endregion


    }
}
