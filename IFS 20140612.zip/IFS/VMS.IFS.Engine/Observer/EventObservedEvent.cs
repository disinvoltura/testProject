﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.Engine
{
    public class EventObservedEvent: ObservedEvent
    {
        #region Member Variables
        private SimEvent _Event;
        #endregion

        #region Properties
        public SimEvent Event
        {
            get { return _Event; }
        }
        #endregion

        #region Constructors
        public EventObservedEvent(double time, EventObjectSimulator eventobject, SimEvent e)
            : base (time, eventobject)
        {
            _Event = e;
        }
        #endregion

        #region Methods

        #endregion
    }
}
