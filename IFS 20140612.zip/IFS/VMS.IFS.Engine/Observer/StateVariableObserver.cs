﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.Engine
{
    public abstract class StateVariableObserver: Observer
    {
        #region Member Variables

        #endregion

        #region Properties

        #endregion

        #region Constructors
        public StateVariableObserver(string name)
            : base(name)
        {
        }
        #endregion

        #region Methods
        public abstract void Update(StateVariableObservedEvent e);
        #endregion
    }
}
