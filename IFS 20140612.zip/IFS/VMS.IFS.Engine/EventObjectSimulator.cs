﻿using System;
using System.Collections.Generic;
using System.Text;
using VMS.IFS.Engine.ApplicationConnection;

namespace VMS.IFS.Engine
{
    public abstract class EventObjectSimulator : IDisposable
    {
        #region Member Variables
        private string _Name;
        protected SimulationCoordinator _SC;
        private Dictionary<string, EventObserver> _EventObservers;
        private Dictionary<string, StateVariableObserver> _StateVariableObservers;
        #endregion

        #region Properties
        //Name of Event Object Simulator
        public string Name
        {
            get { return _Name; }
        }

        /// <summary>
        /// Simulation Coordinator
        /// </summary>
        public SimulationCoordinator SC
        {
            get { return _SC; }
        }
        #endregion

        #region Constructors
        public EventObjectSimulator(string name, SimulationCoordinator sc)
        {
            _Name = name;
            _SC = sc;

            _EventObservers = new Dictionary<string, EventObserver>();
            _StateVariableObservers = new Dictionary<string, StateVariableObserver>();
        }

        #endregion

        #region Abstract Methods
        /// <summary>
        /// Schedule the start event of the event object
        /// </summary>
        public abstract void Run();

        /// <summary>
        /// Execute the event routine for a given local event
        /// </summary>
        /// <param name="e"></param>
        public abstract void ExecuteLocalEvent(LocalEvent e);

        /// <summary>
        /// Initialize the state variables of the event object
        /// </summary>
        public abstract void Initialize(Dictionary<string, object> args);

        public abstract void FireSchedulingArc(VMS.IFS.Engine.ApplicationMessage msg);
        #endregion

        #region Schedule Event Methods
        public void ScheduleLocalEvent(LocalEvent e)
        {
            _SC.ScheduleLocalEvent(e);
        }

        public void ScheduleLocalEvent(string eventName, double time)
        {
            LocalEvent e = new LocalEvent(this.Name, eventName, time);
            _SC.ScheduleLocalEvent(e);
        }

        public void ScheduleMirrorEvent(string objectid, string eventName, double time)
        {
            LocalEvent e = new LocalEvent(objectid, eventName, time);
            _SC.ScheduleLocalEvent(e);
        }
        #endregion

        #region Observer Methods
        
        public void RegisterObserver(Observer obs)
        {
            if (obs is EventObserver)
                RegisterEventObserver((EventObserver)obs);
            else if (obs is StateVariableObserver)
                AddStateVariableObserver((StateVariableObserver)obs);
        }

        public void RegisterEventObserver(EventObserver obs)
        {
            if (_EventObservers == null)
                _EventObservers = new Dictionary<string, EventObserver>();

            _EventObservers.Add(obs.Name, obs);
        }

        public void DeleteEventObserver(EventObserver obs)
        {
            _EventObservers.Remove(obs.Name);
        }

        public void NotifyEventObservers(EventObservedEvent e)
        {
            foreach (EventObserver obs in _EventObservers.Values)
            {
                obs.Update(e);
            }
        }

        public void AddStateVariableObserver(StateVariableObserver obs)
        {
            if (_StateVariableObservers == null)
                _StateVariableObservers = new Dictionary<string, StateVariableObserver>();

            _StateVariableObservers.Add(obs.Name, obs);
        }

        public void DeleteStateVariableObserver(StateVariableObserver obs)
        {
            _StateVariableObservers.Remove(obs.Name);
        }

        public void NotifyStateVariableObservers(StateVariableObservedEvent e)
        {
            foreach (StateVariableObserver obs in _StateVariableObservers.Values)
            {
                obs.Update(e);
            }
        }

        public void NotifyObservers(ObservedEvent e)
        {
            if (e is EventObservedEvent)
            {
                NotifyEventObservers((EventObservedEvent)e);
            }
            else if (e is StateVariableObservedEvent)
            {
                NotifyStateVariableObservers((StateVariableObservedEvent)e);
            }
        }

        public void DeleteObserver(Observer obs)
        {
            if (obs is EventObserver)
            {
                DeleteEventObserver((EventObserver)obs);
            }
            else if (obs is StateVariableObserver)
            {
                DeleteStateVariableObserver((StateVariableObserver)obs);
            }
        }
        #endregion

        #region Application Integration Methods
        protected void Send_Msg(string msg)
        {
            try
            {
                
                ApplicationConnector.Send_Msg(msg);
            }
            catch (Exception ex)
            {
                throw new Exception("Error while sending a message", ex);
            }
        }
        #endregion

        #region Methods
        public virtual void Dispose()
        {
            _EventObservers.Clear();
            _StateVariableObservers.Clear();
        }
        #endregion

    }
}
