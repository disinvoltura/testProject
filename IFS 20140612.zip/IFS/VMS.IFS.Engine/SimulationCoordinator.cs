﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.Foundation.Logging;

namespace VMS.IFS.Engine
{    
    public abstract class SimulationCoordinator: IDisposable
    {
        #region Member Variables
        /// <summary>
        /// Future Event List
        /// </summary>
        protected EventList<CoordinatorEvent> _FEL;
        /// <summary>
        /// Local Event List
        /// </summary>
        protected EventList<LocalEvent> _LEL;

        /// <summary>
        /// Container for Event Object Simulators, indexed by the name of each event object simulator
        /// </summary>
        protected Dictionary<string, EventObjectSimulator> _ObjectList;

        /// <summary>
        /// evaluate the end-of-simulation condition
        /// </summary>
        protected EndOfSimulation _EOS;

        /// <summary>
        /// Simulation Clock
        /// </summary>
        protected double _Clock;

        /// <summary>
        /// State Variable that represents the status of simulation coordinator
        /// 1 indicates the idle status of SC and 0 indicates the busy status of SC
        /// </summary>
        protected int _SC;
        /// <summary>
        /// State variable that represents the SC is reserved or not.
        /// </summary>
        protected bool _RSV;

        protected const string ScheduleLE = "ScheduleLE";
        protected const string GetNextLE = "GetNextLE";
        protected const string ExecuteLE = "ExecuteLE";
        protected const string Terminate = "Terminate";

        protected Logger _Logger;
        #endregion

        #region Properties
        public double Clock
        {
            get { return _Clock; }
        }
        #endregion

        #region Constructors
        public SimulationCoordinator()
        {
            _Logger = LogManager.GetLogger("SimulationCoordinator");
            _ObjectList = new Dictionary<string, EventObjectSimulator>();
            Initialize();
        }
        #endregion

        #region Methods
        public void AddEventObjectSimulator(EventObjectSimulator eo)
        {
            if (!_ObjectList.ContainsKey(eo.Name))
            {
                _ObjectList.Add(eo.Name, eo);
            }
            else
            {
                _Logger.Error("Event Object Simulator <" + eo.Name + "> is already registerd.");
            }
        }

        public void Initialize()
        {
            _FEL = new EventList<CoordinatorEvent>("FEL");
            _LEL = new EventList<LocalEvent>("LEL");
            _EOS = new EndOfSimulation(this);
        }

        public virtual bool Run()
        {
            _Logger.Debug("Coordinator runs");
            _Clock = 0;
            
            bool rslt = true;

            Execute_Initialize_Routine();

            while (!_EOS.StopCondition)
            {
                CoordinatorEvent nextEvent = RetrieveEvent();
                if (nextEvent == null)
                    break;//irregular abort.
                _Clock = nextEvent.Time;

                switch (nextEvent.Name)
                {
                    case ScheduleLE: {
                        Execute_ScheduleLE_Routine(nextEvent.e, _Clock);
                        break; }
                    case GetNextLE: {
                            Execute_GetNextLE_Routine(_Clock);
                            break; }
                    case ExecuteLE: {
                            Execute_ExecuteLE_Routine(nextEvent.e, _Clock);
                            break; }
                    case Terminate: {
                            Execute_Terminate_Routine(_Clock);
                            break; }
                }
                //_Logger.Debug("Coordinator Event is executed : " + nextEvent.ToString());
            }
            _Logger.Debug("Coordinator ends");

            //#if DEBUG
            //System.Diagnostics.Debug.WriteLine("Max Length of FEL: " + _FEL.Max);
            //System.Diagnostics.Debug.WriteLine("Max Length of LEL: " + _LEL.Max);
            //System.Diagnostics.Debug.WriteLine("Times for Scheduling FEL: " + _FEL.TimeCost);
            //System.Diagnostics.Debug.WriteLine("Times for Scheduling LEL: " + _LEL.TimeCost);
            //#endif

            rslt = !_EOS.IsAborted;

            return rslt;
        }

        public abstract void Dispose();
        #endregion

        #region Event Routines
        protected abstract void Execute_Initialize_Routine();        

        protected abstract void Execute_ScheduleLE_Routine(LocalEvent e, double now);        

        protected abstract void Execute_GetNextLE_Routine(double now);

        protected abstract void Execute_ExecuteLE_Routine(LocalEvent e, double now);

        protected abstract void Execute_Terminate_Routine(double now);
        #endregion

        #region CoordinatorEvent List Methods
        protected void CancelEvent(CoordinatorEvent e)
        {
            _FEL.CancelEvent(e);
        }

        protected void CancelEvent(string eventName)
        {
            _FEL.CancelEvent(eventName);
        }

        protected CoordinatorEvent RetrieveEvent()
        {
            CoordinatorEvent e= _FEL.RetrieveEvent();
            
            return e;
        }

        protected void ScheduleEvent(string eventName, double time)
        {
            _FEL.ScheduleEvent(new CoordinatorEvent(eventName, time));
        }

        protected void ScheduleEvent(string eventName, double time, LocalEvent e) 
        {
            _FEL.ScheduleEvent(new CoordinatorEvent(eventName, time, e));
        }

        #endregion

        #region LocalEvent List Methods

        protected void ExecuteLocalEvent(LocalEvent e)
        {
            if (!string.IsNullOrEmpty(e.ObjectName))
            {
                if (_ObjectList.ContainsKey(e.ObjectName))
                {
                    EventObjectSimulator objectSimulator = _ObjectList[e.ObjectName];
                    objectSimulator.ExecuteLocalEvent(e);
                    
                    objectSimulator.NotifyEventObservers(
                        new EventObservedEvent(this.Clock, _ObjectList[e.ObjectName], e));
                }
            }
        }

        public void ScheduleLocalEvent(LocalEvent e)
        {
            ScheduleEvent(ScheduleLE, this.Clock, e);
        }
        #endregion

        #region EOS methods
        /// <summary>
        /// Declare that the simulation ends when the simulation clock rearches the EOS time.
        /// </summary>
        /// <param name="eosTime">End-of-simulation Time</param>
        public void StopAtTime(double time)
        {
            _EOS.StopAtTime(time);
        }

        /// <summary>
        /// Declare that the simulation ends when an coordinator's event occurs a certain number of times.
        /// </summary>
        /// <param name="eventName">Name of an event that belongs to Coordinator</param>
        /// <param name="frequency">Number of the event occurrence</param>
        public void StopOnEvent(string eventName, int frequency)
        {
            _EOS.StopOnEvent(eventName, frequency);
        }

        /// <summary>
        /// Declare that the simulation ends when an object's event occurs a certain number of times.
        /// </summary>
        /// <param name="objectName">Name of an object</param>
        /// <param name="eventName">Name of an event</param>
        /// <param name="frequency">Number of the event occurrence</param>
        public void StopOnEvent(string objectName, string eventName, int frequency)
        {
            _EOS.StopOnEvent(objectName, eventName, frequency);
        }

        public void Abort()
        {
            _EOS.Abort();
            ApplicationConnection.ApplicationConnector.Close();
        }
        #endregion
    }
}
