﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.DataModel.InputData;
using VMS.IFS.DataModel;

namespace VMS.IFS.Models
{
    public delegate void SimulationEndedEventHandler();
    
    public class Factory: IDisposable
    {
        #region Member Variables
        private string _Name;
        private SimulationCoordinator _SC;
        //private Dictionary<string, EventObjectSimulator> _EQPs;
        private FabIn _FabIn;
        private FabOut _FabOut;
        private MasterData _MasterData;
        
        private RealTimeDispatcher _RTD;
        private MaterialControlSystem _MCS;

        private UniInlineCell _UniInlineCell;
        private BiInlineCell _BiInlineCell;
        private Oven _Oven;
        private Chamber _Chamber;

        private InlineStocker _Stocker;
        private Conveyor _Conveyor;

        private Dictionary<string, object> _SimArgs;
        #endregion

        #region Events
        public event SimulationEndedEventHandler SimulationEnded;
        #endregion

        #region Properties
        public double Clock
        {
            get { return _SC.Clock; }
        }

        public SimulationCoordinator SimulationCoordinator
        {
            get { return _SC; }
        }

        public MasterData MasterData
        {
            get { return _MasterData; }
        }

        public RealTimeDispatcher RTD
        {
            get { return _RTD; }
        }

        public MaterialControlSystem MCS
        {
            get { return _MCS; }
        }

        public UniInlineCell UniInlineCell
        {
            get { return _UniInlineCell; }
            set { _UniInlineCell = value; }
        }
        public BiInlineCell BiInlineCell
        {
            get { return _BiInlineCell; }
            set { _BiInlineCell = value; }
        }
        public Oven Oven
        {
            get { return _Oven; }
            set { _Oven = value; }
        }
        public Chamber Chamber
        {
            get { return _Chamber; }
            set { _Chamber = value; }
        }

        public FabIn FabIn
        {
            get { return _FabIn; }
            set { _FabIn = value; }
        }

        public FabOut FabOut
        {
            get { return _FabOut; }
            set { _FabOut = value; }
        }

        public InlineStocker Stocker
        {
            get { return _Stocker; }
            set { _Stocker = value; }
        }

        public Conveyor Conveyor
        {
            get { return _Conveyor; }
            set { _Conveyor = value; }
        }

        public FactoryObjectSimulator this[string eqpid]
        {
            get
            {
                FactoryObjectSimulator rslt = null;

                if (this.MasterData.EQP.Contains(eqpid))
                {
                    EquipmentSpecification eqp = this.MasterData.EQP[eqpid];
                    if (eqp.EQP_Type == EquipmentType.UniInlineCell)
                        rslt = _UniInlineCell;
                    else if (eqp.EQP_Type == EquipmentType.BiInlineCell)
                        rslt = _BiInlineCell;
                    else if (eqp.EQP_Type == EquipmentType.Chamber)
                        rslt = _Chamber;
                    else if (eqp.EQP_Type == EquipmentType.Oven)
                        rslt = _Oven;
                }
                else if (this.MasterData.Stocker.Contains(eqpid))
                    rslt = _Stocker;
                else if (this.MasterData.Conveyor.Contains(eqpid))
                    rslt = _Conveyor;
                return rslt;
            }
        }
        #endregion

        #region Constructors
        public Factory(string name)
        {
            _Name = name;            
            //_EQPs = new Dictionary<string, EventObjectSimulator>();
        }
        #endregion

        #region Methods
        public void Initialize(InputDataSet ds, Dictionary<string, object> args)
        {
            SimulationEntity.Initialize();

            //Simulation Argument 정의:
            _MasterData = new DataModel.SimulationData.MasterData();
            _MasterData.Initialize(ds, args);

            bool connectApplication = false;
            if (args.ContainsKey(SimulationArguments.ConnectApplication))
                connectApplication = (bool)args[SimulationArguments.ConnectApplication];

            if (connectApplication)
                _SC = new AppSimulationCoordinator();
            else
                _SC = new FastSimulationCoordinator();
            _SC.Initialize();

            double eosTime = (double)args[SimulationArguments.EOSTime];
            _SC.StopAtTime(eosTime);            

            //설비 시뮬레이터 생성
            _UniInlineCell = new UniInlineCell(this);
            _UniInlineCell.Initialize(args);
            
            _Oven = new Oven(this);
            _Oven.Initialize(args);
            
            if (connectApplication)
                _BiInlineCell = new ApplicationBiInlineCell(this);
            else
                _BiInlineCell = new BiInlineCell(this);
            _BiInlineCell.Initialize(args);

            _Chamber = new Chamber(this);
            _Chamber.Initialize(args);

            //FabIn, FabOut 생성
            _FabIn = new FabIn(this);
            _FabIn.Initialize(args);

            //double saveWIPTime = double.Parse(args[SimulationArguments.SaveWIPTime].ToString());
            _FabOut = new FabOut(this);//, saveWIPTime);
            _FabOut.Initialize(args);

            //Material Handling
            if (connectApplication)
            {
                _Stocker = new ApplicationInlineStocker(this);
                _Conveyor = new ApplicationConveyor(this);
            }
            else
            {
                _Stocker = new InlineStocker(this);
                _Conveyor = new Conveyor(this);
            }
            _Stocker.Initialize(args);
            _Conveyor.Initialize(args);

            //RTD
            _RTD = new RealTimeDispatcher(this);
            _RTD.Initialize(args);

            //MCS
            _MCS = new MaterialControlSystem(this);
            _MCS.Initialize(args);

            _SC.AddEventObjectSimulator(_UniInlineCell);
            _SC.AddEventObjectSimulator(_BiInlineCell);
            _SC.AddEventObjectSimulator(_Chamber);
            _SC.AddEventObjectSimulator(_Oven);
            _SC.AddEventObjectSimulator(_Stocker);
            _SC.AddEventObjectSimulator(_Conveyor);
            _SC.AddEventObjectSimulator(_FabIn);
            _SC.AddEventObjectSimulator(_FabOut);
        }

        public void Run()
        {
            if (_SC.Run())
            {                                
                if (SimulationEnded != null && SimulationEnded.GetInvocationList().Length > 0)
                        SimulationEnded();
            }
        }

        public void Stop()
        {
            _SC.Abort();
        }

        /*
        public MachineInfo GetMachine(string eqpid)
        {
            MachineInfo m = new MachineInfo(eqpid, this);

            return m;
        }
        */

        #endregion

        public void Dispose()
        {
            Dispose(true);
        }

        private bool IsDisposed;
        protected virtual void Dispose(bool isDisposing)
        {
            if (IsDisposed) return;
            if (isDisposing)
            {
                // Dispose all Managed Resources
                _SC.Dispose();

                
            }
            IsDisposed = true;
            GC.SuppressFinalize(this);
        } 

    }
}
