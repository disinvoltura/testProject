﻿using System;
using System.Collections.Generic;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    /// <summary>
    /// Single-crane Stocker
    /// </summary>
    public class ApplicationInlineStocker : InlineStocker
    {
        #region Member Variables
        private Dictionary<string, List<FactoryLocalEvent>> _MEL;
        private Dictionary<string, string> _SchedulingEvents;
        private Dictionary<string, string> _SchedulingEvents2;
        #endregion

        #region Properties
 
        
        #endregion

        #region Constructors
        public ApplicationInlineStocker(Factory factory)
            : base(factory)
        {
            _MEL = new Dictionary<string, List<FactoryLocalEvent>>();

            _SchedulingEvents = new Dictionary<string, string>();
            _SchedulingEvents2 = new Dictionary<string, string>();
        }
        #endregion

        #region Make Retrieval/Delivery Message Methods
        private string makeEmptyCassetteMessage(
            string eventName, double now, string b, int newCstID, int oldCstID)
        {
            //e.g. "Empty_Cst_LGL#M1#3_2#10# # “
            string msg = string.Empty;
            msg = string.Format("Empty_Cst_{0}#{1}#{2}_{3}#{4}# # ", eventName, b, newCstID, oldCstID, now);
            return msg;
        }

        private string makeRetrievalMessage(string eventName, double now, string s, string e, Cassette cst)
        {
            string toLoc = null;
            switch (cst.DP)
            {
                case DropPointType.B: { toLoc = "buffer"; break; }
                case DropPointType.SO: { toLoc = "outport_" + cst.A; break; }
                case DropPointType.E: { toLoc = "empty"; break; }   
                default: toLoc = cst.A; break;      //PU, PI, PC, PV
            }

            if (toLoc.Contains("FabOut"))
                toLoc = "buffer";

            string msg = string.Empty;
            msg = string.Format("Delay_Retrieval_{0}#{1}#{2}#{3}#{4}#{5}", eventName, s, cst.ID, now, e, toLoc);
            return msg;
        }

        private string makeDeliveryMessage(string eventName, double now, string s, string from, string to, Cassette cst)
        {
            string msg = string.Empty;
            msg = string.Format("Delay_Delivery_{0}#{1}#{2}#{3}#{4}#{5}", eventName, s, cst.ID, now, from, to);
            return msg;
        }

        private string makeDeliveryMessage(string eventName, double now, string s, string e, Cassette cst)
        {
            string msg = string.Empty;
            msg = string.Format("Delay_Delivery_{0}#{1}#{2}#{3}#{4}#", eventName, s, cst.ID, now, e);
            return msg;
        }

        private void Add2MEL(string eventName, double eventTime, string s, string e, Cassette cst)
        {
            FactoryLocalEvent evt = new FactoryLocalEvent("InlineStocker", eventName, eventTime);
            evt.AddParameter(s); evt.AddParameter(e); evt.AddParameter(cst);
            _MEL[s].Add(evt);
        }

        private void Add2MEL(string eventName, double eventTime, string s, Cassette cst)
        {
            FactoryLocalEvent evt = new FactoryLocalEvent("InlineStocker", eventName, eventTime);
            evt.AddParameter(s); evt.AddParameter(cst);
            _MEL[s].Add(evt);
        }

        private FactoryLocalEvent retrieveEvent(string s, string eventName)
        {
            FactoryLocalEvent rslt = null;

            foreach (FactoryLocalEvent evt in _MEL[s])
            {
                if (evt.Name.Equals(eventName))
                {
                    rslt = evt;
                    break;
                }
            }

            if (rslt != null)
                _MEL[s].Remove(rslt);

            return rslt;
        }
        #endregion

        #region Event Routines - Crane
        private void Execute_CU_Routine(double now, string s, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_CU_Routine(" + now + ", " + s + ", " + cst.ToString() + ")");

            cst.IsMoving = false;

            if (cst.DP == DropPointType.B)
            {
                ScheduleLocalEvent("X2B", now, s, cst);
            }
            else if (cst.DP == DropPointType.E)
            {
                //Just throw the empty cassette.
                //Do nothing
            }
            else if (cst.DP == DropPointType.PO)
            {
                string e = cst.A;
                ScheduleMirrorEvent(_DP2SimName[cst.DP], _DP2Event[cst.DP], now, e, cst);
            }
            else
            {
                string e = cst.A;
                cst.ShiftRoute();
                ScheduleMirrorEvent(_DP2SimName[cst.DP], _DP2Event[cst.DP], now, e, cst);
            }

            ScheduleLocalEvent("CI", now, s);
        }
      
        #endregion

        #region Event Routines - Uni-inline
        protected override void Execute_PU2Xr_Routine(double now, string s, string u, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_PU2Xr_Routine(" + now + ", " + s + ", " + u + ", " + cst.ToString() + ")");
            
            _CR[s] = 0;

            //Add to MEL
            Add2MEL("PU2Xr", now, s, u, cst);

            //Send Retrieval Message
            string Rmsg = makeRetrievalMessage("PU2Xr", now, s, u, cst);
            Send_Msg(Rmsg);

            //cd.DelayCount++;
        }

        protected override void Execute_PU2X_Routine(double now, string s, string u, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_PU2X_Routine(" + now + ", " + s + ", " + u + ", " + cst.ToString() + ")");

            Factory.UniInlineCell.P[u].ChangePortState(PortState.DR, PortState.X);

            cst.IsMoving = true;

            HandleNextCassette(now, u, FactoryObjectType.Uniinline);
            
            //Add to MEL
            Add2MEL("PU2X", now, s, u, cst);

            //Send Delivery Message
            string Dmsg = makeDeliveryMessage("PU2X", now, s, u, cst);
            Send_Msg(Dmsg);

            //cd.DelayCount++;
        }

        #endregion

        #region Event Routines - Bi-inline 
        /// <summary>
        /// Event Routine for MEC event
        /// </summary>
        /// <param name="now">Simulation Clock</param>
        /// <param name="s">STK ID</param>
        /// <param name="b">Bi-inline ID</param>
        /// <param name="cst">Cassette</param>
        protected override void Execute_MEC_Routine(double now, string s, string b, Cassette cst)
        {
            Cassette emptyCst = new Cassette("", "", 0, "");
            emptyCst.B = b;

            //Send Empty Cassette
            string Emsg = makeEmptyCassetteMessage("bLGL", now, b, emptyCst.ID, cst.ID);
            //string Emsg = makeEmptCassetteMessage("LGL", now, b, emptyCst.ID, cst.ID);
            Send_Msg(Emsg);

            bool RSV = RsvC(s, PickupPointType.PI, emptyCst);
            if (RSV)
                ScheduleLocalEvent("PI2Xr", now, s, b, emptyCst);
        }

        /// <summary>
        /// Event Routine for PO2Xr event
        /// </summary>
        /// <param name="now">Simulation Clock</param>
        /// <param name="s">STK ID</param>
        /// <param name="b">Bi-inline ID</param>
        /// <param name="cst">Cassette</param>
        protected override void Execute_PO2Xr_Routine(double now, string s, string b, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_PO2Xr_Routine(" + now + ", " + s + ", " + b + ", " + cst.ToString() + ")");

            _CR[s] = 0;

            //Add to MEL
            Add2MEL("PO2Xr", now, s, b, cst);

            //Send Retrieval Message
            string Rmsg = makeRetrievalMessage("PO2Xr", now, s, b, cst);
            Send_Msg(Rmsg);

            //cd.DelayCount++;
        }

        /// <summary>
        /// Event Routine for PO2X event
        /// </summary>
        /// <param name="now">Simulation Clock</param>
        /// <param name="s">STK ID</param>
        /// <param name="b">Bi-inline ID</param>
        /// <param name="cst">Cassette</param>
        protected override void Execute_PO2X_Routine(double now, string s, string b, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_PO2X_Routine(" + now + ", " + s + ", " + b + ", " + cst.ToString() + ")");

            Factory.BiInlineCell.PO[b].ChangePortState(PortState.DR, PortState.X);
            
            cst.IsMoving = true;

            RequestEmptyCassette(b, s);

            //Add to MEL
            Add2MEL("PO2X", now, s, b, cst);

            //Send Delivery Message
            string Dmsg = makeDeliveryMessage("PO2X", now, s, b, cst);
            Send_Msg(Dmsg);

            //cd.DelayCount++;
        }

        /// <summary>
        /// Event Routine for PI2Xr event
        /// </summary>
        /// <param name="now">Simulation Clock</param>
        /// <param name="s">STK ID</param>
        /// <param name="b">Bi-inline ID</param>
        /// <param name="cst">Cassette</param>
        protected override void Execute_PI2Xr_Routine(double now, string s, string b, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_PI2Xr_Routine(" + now + ", " + s + ", " + b + ", " + cst.ToString() + ")");

            _CR[s] = 0;

            //Add to MEL
            Add2MEL("PI2Xr", now, s, b, cst);

            //Send Retrieval Message
            string Rmsg = makeRetrievalMessage("PI2Xr", now, s, b, cst);
            Send_Msg(Rmsg);

            //cd.DelayCount++;
        }

        /// <summary>
        /// Event Routine for PI2X event
        /// </summary>
        /// <param name="now">Simulation Clock</param>
        /// <param name="s">STK ID</param>
        /// <param name="b">Bi-inline ID</param>
        /// <param name="cst">Cassette</param>
        protected override void Execute_PI2X_Routine(double now, string s, string b, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_PI2X_Routine(" + now + ", " + s + ", " + b + ", " + cst.ToString() + ")");

            Factory.BiInlineCell.P[b].ChangePortState(PortState.E, PortState.X);

            cst.IsMoving = true;

            //Added by D.  Kang at 2013.12.28
            HandleNextCassette(now, b, FactoryObjectType.Biinline);

            //Add to MEL
            Add2MEL("PI2X", now, s, b, cst);

            //Send Delivery Message
            string Dmsg = makeDeliveryMessage("PI2X", now, s, b, cst);
            Send_Msg(Dmsg);

            //cd.DelayCount++;
        }

        protected override void Execute_E2POr_Routine(double now, string s, Cassette cst)
        {
            _CR[s] = 0;

            //Add to MEL
            Add2MEL("E2POr", now, s, cst);

            //Send Retrieval Message
            string Rmsg = makeRetrievalMessage("E2POr", now, s, "empty", cst);
            Send_Msg(Rmsg);

            //cd.DelayCount++;
        }

        protected override void Execute_E2PO_Routine(double now, string s, Cassette cst)
        {
            cst.IsMoving = true;

            //Add to MEL
            Add2MEL("E2PO", now, s, cst);

            //Send Delivery Message
            string Dmsg = makeDeliveryMessage("E2PO", now, s, "empty", cst.A, cst);
            Send_Msg(Dmsg);

            //cd.DelayCount++;
        }
        #endregion

        #region Event Routines - Oven
        protected override void Execute_PV2Xr_Routine(double now, string s, string v, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_PV2Xr_Routine(" + now + ", " + s + ", " + v + ", " + cst.ToString() + ")");
            
            //State Change
            _CR[s] = 0;

            //Add to MEL
            Add2MEL("PV2Xr", now, s, v, cst);

            //Send Retrieval Message
            string Rmsg = makeRetrievalMessage("PV2Xr", now, s, v, cst);
            Send_Msg(Rmsg);
            
            //cd.DelayCount++;
        }


        protected override void Execute_PV2X_Routine(double now, string s, string v, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_PV2X_Routine(" + now + ", " + s + ", " + v + ", " + cst.ToString() + ")");

            Factory.Oven.P[v].ChangePortState(PortState.DR, PortState.X);

            cst.IsMoving = true;

            HandleNextCassette(now, v, FactoryObjectType.Oven);

            //Add to MEL
            Add2MEL("PV2X", now, s, v, cst);

            //Send Delivery Message
            string Dmsg = makeDeliveryMessage("PV2X", now, s, v, cst);
            Send_Msg(Dmsg);

            //cd.DelayCount++;
        }

        #endregion

        #region Event Routines - Chamber
        protected override void Execute_PC2Xr_Routine(double now, string s, string c, Cassette cst)
        {
           // System.Diagnostics.Debug.WriteLine("Execute_PC2Xr_Routine(" + now + ", " + s + ", " + c + ", " + cst.ToString() + ")");
            _CR[s] = 0;

            //Add to MEL
            Add2MEL("PC2Xr", now, s, c, cst);

            //Send Retrieval Message
            string Rmsg = makeRetrievalMessage("PC2Xr", now, s, c, cst);
            Send_Msg(Rmsg);

            //cd.DelayCount++;
        }

        protected override void Execute_PC2X_Routine(double now, string s, string c, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_PC2X_Routine(" + now + ", " + s + ", " + c + ", " + cst.ToString() + ")");

            Factory.Chamber.P[c].ChangePortState(PortState.DR, PortState.X);

            cst.IsMoving = true;

            HandleNextCassette(now, c, FactoryObjectType.Chamber);

            //Add to MEL
            Add2MEL("PC2X", now, s, c, cst);

            //Send Delivery Message
            string Dmsg = makeDeliveryMessage("PC2X", now, s, c, cst);
            Send_Msg(Dmsg);

            //cd.DelayCount++;
        }

        #endregion

        #region Event Routines - Stocker Buffer
        protected override void Execute_B2Xr_Routine(double now, string s, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_B2Xr_Routine(" + now + ", " + s + ", " + cst.ToString() + ")");

            _CR[s] = 0;

            //Add to MEL
            Add2MEL("B2Xr", now, s,  cst);

            //Send Retrieval Message
            string Rmsg = makeRetrievalMessage("B2Xr", now, s, "buffer", cst);
            Send_Msg(Rmsg);

            //cd.DelayCount++;
        }

        protected override void Execute_B2X_Routine(double now, string s, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_B2X_Routine(" + now + ", " + s + ", " + cst.ToString() + ")");

            _WIP[s]--;

            cst.IsMoving = true;

            //Add to MEL
            Add2MEL("B2X", now, s, cst);

            //Send Delivery Message
            string Dmsg = makeDeliveryMessage("B2X", now, s,"buffer", cst);
            Send_Msg(Dmsg);

            //cd.DelayCount++;
        }
        #endregion

        #region Event Routines - Conveyor
        protected override void Execute_SI2Xr_Routine(double now, string s, string y, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_SI2Xr_Routine(" + now + ", " + s + ", " + y + "," + cst.ToString() + ")");

            _CR[s] = 0;

            //Add to MEL
            Add2MEL("SI2Xr", now, s, y, cst);

            //Send Retrieval Message
            if (y.StartsWith("FabIn"))
                y = "CNV00";
            string Rmsg = makeRetrievalMessage("SI2Xr", now, s, "inport_" + y, cst);
            Send_Msg(Rmsg);

            //cd.DelayCount++;
        }

        protected override void Execute_SI2X_Routine(double now, string s, string y, Cassette cst)
        {
           // System.Diagnostics.Debug.WriteLine("Execute_SI2X_Routine(" + now + ", " + s + ", " + y + "," + cst.ToString() + ")");

            if (Factory.Conveyor.CQ[y].Count > 0)
            {
                _SI[s, y] = -1;
                ScheduleLocalEvent("C2SI", now, s, y);
            }else{
                _SI[s, y] = 1;
            }

            cst.IsMoving = true;

            //Add to MEL
            Add2MEL("SI2X", now, s, y, cst);

            //Send Delivery Message
            if (y.StartsWith("FabIn"))
                y = "CNV00";
            string Dmsg = makeDeliveryMessage("SI2X", now, s, "inport_" + y, cst);
            Send_Msg(Dmsg);

            //cd.DelayCount++;
        }
        #endregion

        #region Methods
        public override void Initialize(Dictionary<string, object> args)
        {
            base.Initialize(args);

            _MEL = new Dictionary<string, List<FactoryLocalEvent>>();
            foreach (string stkid in Factory.MasterData.Stocker.Keys)
            {
                _MEL.Add(stkid, new List<FactoryLocalEvent>());
            }

            _SchedulingEvents = new Dictionary<string, string>();
            _SchedulingEvents.Add("PV2Xr", "PV2X");
            _SchedulingEvents.Add("PC2Xr", "PC2X");
            _SchedulingEvents.Add("PO2Xr", "PO2X");
            _SchedulingEvents.Add("PI2Xr", "PI2X");
            _SchedulingEvents.Add("PU2Xr", "PU2X");
            _SchedulingEvents.Add("SI2Xr", "SI2X");
            _SchedulingEvents.Add("PV2X", "CU");
            _SchedulingEvents.Add("PC2X", "CU");
            _SchedulingEvents.Add("SI2X", "CU");
            _SchedulingEvents.Add("PO2X", "CU");
            _SchedulingEvents.Add("PI2X", "CU");
            _SchedulingEvents.Add("PU2X", "CU");

            _SchedulingEvents2 = new Dictionary<string, string>();
            _SchedulingEvents2.Add("B2Xr", "B2X");
            _SchedulingEvents2.Add("E2POr", "E2PO");
            _SchedulingEvents2.Add("B2X", "CU");
            _SchedulingEvents2.Add("E2PO", "CU");
        }

        public override void FireSchedulingArc(VMS.IFS.Engine.ApplicationMessage msg)
        {
            //msg.ObjectID: "InlineStocker_S01" 이므로 parsing 필요
            //string[] names = msg.ObjectID.Split('_');
            //string objectID = names[1];
            FactoryLocalEvent e = retrieveEvent(msg.ObjectID, msg.EventName);

            if (_SchedulingEvents.ContainsKey(msg.EventName))
            {
                string nextEventName = _SchedulingEvents[msg.EventName];
                if (nextEventName.Equals("CU"))
                    ScheduleLocalEvent(nextEventName, msg.EventTime, (string)e[0], (Cassette)e[2]);
                else
                    ScheduleLocalEvent(nextEventName, msg.EventTime, (string)e[0], (string)e[1], (Cassette)e[2], 100);
            }
            else if (_SchedulingEvents2.ContainsKey(msg.EventName))
            {
                string nextEventName = _SchedulingEvents2[msg.EventName];
                ScheduleLocalEvent(nextEventName, msg.EventTime, (string)e[0], (Cassette)e[1], 100);
            }
        }

        #endregion
    }
}
