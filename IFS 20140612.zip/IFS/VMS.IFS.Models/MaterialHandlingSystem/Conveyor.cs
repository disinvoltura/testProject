﻿using System;
using System.Collections.Generic;
using System.Text;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.DataModel;
using VMS.IFS.Engine.ApplicationConnection;

namespace VMS.IFS.Models
{
    public class Conveyor : AMHSEquipment
    {
        #region Member Variables
        /// <summary>
        /// Cassette Queue at the end of Accumulating Conveyor
        /// Key: Conveyor ID, Value: Cassette Collection
        /// </summary>
        protected Dictionary<string, CassetteCollection> _CQ;
        #endregion

        #region Properties
        public Dictionary<string, CassetteCollection> CQ
        {
            get { return _CQ; }
            set { _CQ = value; }
        }
        #endregion

        #region Constructors
        public Conveyor(Factory factory)
            : base("Conveyor", FactoryObjectType.Conveyor, factory)
        {
            _CQ = new Dictionary<string, CassetteCollection>();
        }
        #endregion

        #region Event Routines
        protected void Execute_X2SO_Routine(double now, string y, Cassette cst)
        {
            cst.UpdatePlace(y);
            cst.IsMoving = true;
            Factory.Stocker.SO[cst.B, y] = 0;

            while (cst.Route[0].ID != y)
            {
                cst.ShiftRoute();
            }

            //SOC event의 priority 추가 - 3/19 김현식
            //ScheduleLocalEvent("SOC", now, y, cst, 100);
            ScheduleLocalEvent("SOC", now, y, cst);
        }

        protected virtual void Execute_SOC_Routine(double now, string y, Cassette cst)
        {
            Factory.Stocker.SO[cst.B, y] = 1;

            if (cst.D == "FabOut")
            {
                Factory.Stocker.SO[cst.B, y] = 1;
                cst.ShiftRoute();
                ScheduleMirrorEvent("FabOut", "CFO", now, cst);
                ScheduleMirrorEvent("FabIn", "CFO", now, cst);
            }
            else
            {
                double tc = Factory.MasterData.ConveyTime[y];

                //SOC event에서 Mirror event로 CI(stocker) 호출 - 3/22 김현식
                if (Factory.Stocker.CR[cst.B] > 0)
                    ScheduleMirrorEvent("InlineStocker", "CI", now, cst.B);

                ScheduleLocalEvent("EOC", now + tc, y, cst);
            }
        }

        protected void Execute_EOC_Routine(double now, string y, Cassette cst)
        {
            _CQ[y].Enqueue(cst);

            string s = cst.A; //connected stocker
            bool RSV = RsvSI(s, y);

            cst.ShiftRoute();

            if (RSV)
                ScheduleMirrorEvent("InlineStocker", "C2SI", now, s, y);
        }

        /// <summary>
        /// Reserve Stocker In-port
        /// </summary>
        /// <param name="s">Stocker ID</param>
        /// <param name="y">Conveyor ID</param>
        /// <returns></returns>
        protected bool RsvSI(string s, string y)
        {
            bool rslt = false;
            if (Factory.Stocker.SI[s, y] > 0)
            {
                Factory.Stocker.SI[s, y] = -1;
                rslt = true;
            }
            return rslt;
        }

        #endregion

        #region Methods
        public override void Run()
        {
            //
        }

        //SOC event의 priority 추가 - 3/19 김현식
        //protected void ScheduleLocalEvent(
        //    string eventName, double time,
        //    string c, Cassette cst, int priority)
        //{
        //    FactoryLocalEvent e = new FactoryLocalEvent(this.Name, eventName, time, priority);

        //    e.AddParameter(c);
        //    e.AddParameter(cst);

        //    ScheduleLocalEvent(e);
        //}

        public override void ExecuteLocalEvent(Engine.LocalEvent e)
        {
            if (e.ObjectName == this.Name)
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)e;
                switch (e.Name)
                {
                    case "X2SO": { Execute_X2SO_Routine(fle.Time, fle.EQPID, fle.Cassette); break; }
                    case "SOC": { Execute_SOC_Routine(fle.Time, fle.EQPID, fle.Cassette); break; }
                    case "EOC": { Execute_EOC_Routine(fle.Time, fle.EQPID, fle.Cassette); break; }
                }
            }
        }

        public override void Initialize(Dictionary<string, object> args)
        {
            _CQ = new Dictionary<string, CassetteCollection>();

            foreach (string convid in Factory.MasterData.Conveyor.Keys)
            {
                ConveyorSpecification conveyor = Factory.MasterData.Conveyor[convid];

                _CQ.Add(convid, new CassetteCollection());
            }

            ////FabIn Conveyor
            ////ID: FabIn_<StkID>
            //foreach (string productid in Factory.MasterData.Product.Products)
            //{
            //    string firstStepID = Factory.MasterData.BOP.GetFirstStepID(productid);
            //    string [] loadableSet = Factory.MasterData.Loadable[productid, firstStepID];

            //    foreach (string eqpid in loadableSet)
            //    {
            //        string stkid = Factory.MasterData.EQPPort[eqpid].InStkID;

            //        string convid = "FabIn_" + stkid;
            //        _CQ.Add(convid, new CassetteCollection());
            //    }

            //    string lastStepID = Factory.MasterData.BOP.GetLastStepID(productid);
            //    loadableSet = Factory.MasterData.Loadable[productid, lastStepID];

            //    foreach (string eqpid in loadableSet)
            //    {
            //        string stkid = Factory.MasterData.EQPPort[eqpid].OutStkID;

            //        string convid = stkid + "_FabOut";
            //        _CQ.Add(convid, new CassetteCollection());
            //    }
            //}

            ////FabOut

        }

        public override void FireSchedulingArc(VMS.IFS.Engine.ApplicationMessage msg)
        {
            //TODO
        }
        #endregion
    }
}
