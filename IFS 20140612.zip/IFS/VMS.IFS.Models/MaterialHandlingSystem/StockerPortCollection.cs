﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public class StockerPortCollection
    {
        #region Member Variables
        //Key: stkid.convid, value: int (status of port)
        private Dictionary<string, int> _Ports;
        //Key: stkid.convid, value: Cassette (Cassete put on a port)
        private Dictionary<string, Cassette> _Cassettes;
        #endregion

        #region Properties
        public int this[string stkid, string convid]
        {
            get
            {
                string key = getKey(stkid, convid);
                if (_Ports.ContainsKey(key))
                    return _Ports[key];
                else
                    return 0;
            }
            set
            {
                string key = getKey(stkid, convid);
                if (_Ports.ContainsKey(key))
                {
                    _Ports[key] = value;
                    if (value == 0)
                        _Cassettes[key] = null;
                }
            }
        }
        #endregion

        #region Constructors
        public StockerPortCollection()
        {
            _Ports = new Dictionary<string, int>();
            _Cassettes = new Dictionary<string, Cassette>();
        }
        #endregion

        #region Methods
        private string getKey(string stkid, string convid)
        {
            return string.Format("{0}.{1}", stkid, convid);
        }

        public void Add(string stkid, string convid)
        {
            string key = getKey(stkid, convid);
            _Ports.Add(key, 1);
        }

        public bool Exist(string stkid, string convid)
        {
            string key = getKey(stkid, convid);
            return _Ports.ContainsKey(key);
        }

        public void SetCassette(string stkid, string convid, Cassette cst)
        {
            string key = getKey(stkid, convid);
            _Cassettes[key] = cst;
        }

        public Cassette GetCassette(string stkid, string convid)
        {
            string key = getKey(stkid, convid);
            return _Cassettes[key];
        }
        #endregion
    }
}
