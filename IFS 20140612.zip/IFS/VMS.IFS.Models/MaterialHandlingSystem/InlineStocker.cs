﻿using System;
using System.Collections.Generic;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    /// <summary>
    /// Single-crane Stocker
    /// </summary>
    public class InlineStocker : AMHSEquipment
    {
        #region Member Variables
        protected Dictionary<string, int> _CR;
        protected Dictionary<string, int> _WIP;
        protected Dictionary<string, CassetteCollection> _CRL;
        protected StockerPortCollection _SO;
        protected StockerPortCollection _SI;

        protected Dictionary<DropPointType, string> _DP2Event;
        protected Dictionary<DropPointType, string> _DP2SimName;

        #endregion

        #region Properties
        /// <summary>
        /// Stocker Out-port
        /// </summary>
        public StockerPortCollection SO
        {
            get {return _SO;}
            set{ _SO = value;}
        }

        /// <summary>
        /// Stocker In-port
        /// </summary>
        public StockerPortCollection SI
        {
            get {return _SI;}
            set { _SI = value;}
        }

        /// <summary>
        /// Crane
        /// </summary>
        public Dictionary<string, int> CR
        {
            get { return _CR; }
            set { _CR = value; }
        }

        public Dictionary<string, CassetteCollection> CRL
        {
            get { return _CRL; }
            set { _CRL = value; }
        }

        public Dictionary<string, int> WIP
        {
            get { return _WIP; }
            set { _WIP = value; }
        }
        #endregion

        #region Constructors
        public InlineStocker(Factory factory)
            : base ("InlineStocker", FactoryObjectType.Stocker, factory)
        {
            _DP2Event = new Dictionary<DropPointType, string>();
            _DP2Event.Add(DropPointType.PV, "X2PV");
            _DP2Event.Add(DropPointType.SO, "X2SO");
            _DP2Event.Add(DropPointType.PU, "X2PU");
            _DP2Event.Add(DropPointType.PC, "X2PC");
            _DP2Event.Add(DropPointType.PI, "X2PI");
            _DP2Event.Add(DropPointType.PO, "X2PO");

            _DP2SimName = new Dictionary<DropPointType, string>();
            _DP2SimName.Add(DropPointType.PV, "Oven");
            _DP2SimName.Add(DropPointType.SO, "Conveyor");
            _DP2SimName.Add(DropPointType.PU, "UniInlineCell");
            _DP2SimName.Add(DropPointType.PC, "Chamber");
            _DP2SimName.Add(DropPointType.PI, "BiInlineCell");
            _DP2SimName.Add(DropPointType.PO, "BiInlineCell");


        }
        #endregion

        #region Event Routines - Crane
        private void Execute_CU_Routine(double now, string s, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_CU_Routine(" + now + ", " + s + ", " + cst.ToString() + ")");

            cst.IsMoving = false;

            if (cst.DP == DropPointType.B)
            {
                ScheduleLocalEvent("X2B", now, s, cst);
            }
            else if (cst.DP == DropPointType.E)
            {
                //Just throw the empty cassette.
                //Do nothing
            }
            else if (cst.DP == DropPointType.PO)
            {
                string e = cst.A;
                ScheduleMirrorEvent(_DP2SimName[cst.DP], _DP2Event[cst.DP], now, e, cst);
            }
            else
            {
                
                string e = cst.A;

                cst.ShiftRoute();
                if (Factory[e] is ProcessingEquipment)
                {
                    ProcessingEquipment pe = (ProcessingEquipment)Factory[e];
                    pe.M[e] = pe.M[e] - 1;
                }

                ScheduleMirrorEvent(_DP2SimName[cst.DP], _DP2Event[cst.DP], now, e, cst);
            }

            ScheduleLocalEvent("CI", now, s);
        }

        protected void Execute_CI_Routine(double now, string s)
        {
           // System.Diagnostics.Debug.WriteLine("Execute_CI_Route(" + now + ", " + s + ")");

            _CR[s] = 1;

            Cassette cst = SelectCraneRequest(s);

            if (cst == null)
            {
                //System.Diagnostics.Debug.WriteLine("No cassette is selected for crane request at <" + s + ">.");
                //System.Diagnostics.Debug.WriteLine(" - # of CRL[" + s + "]=" + _CRL[s].Count);

                return;
            }

            //System.Diagnostics.Debug.WriteLine("A Cassette is selected for crane request (" + cst.ToString()+")");

            if (cst.PP == PickupPointType.B)
            {
                ScheduleLocalEvent("B2Xr", now, s, cst);
            }
            else if (cst.PP == PickupPointType.SI)
            {
                ScheduleLocalEvent("SI2Xr", now, s, cst.B, cst);
            }
            else if (cst.PP == PickupPointType.PV)
            {
                ScheduleLocalEvent("PV2Xr", now, s, cst.B, cst);
            }
            else if (cst.PP == PickupPointType.PU)
            {
                ScheduleLocalEvent("PU2Xr", now, s, cst.B, cst);
            }
            else if (cst.PP == PickupPointType.PC)
            {
                ScheduleLocalEvent("PC2Xr", now, s, cst.B, cst);
            }
            else if (cst.PP == PickupPointType.PO)
            {
                ScheduleLocalEvent("PO2Xr", now, s, cst.B, cst);
            }
            else if (cst.PP == PickupPointType.PI)
            {
                ScheduleLocalEvent("PI2Xr", now, s, cst.B, cst);
            }
            else if (cst.PP == PickupPointType.E)
            {
                //Empty Cassette to PO (Bi-inline)
                ScheduleLocalEvent("E2POr", now, s, cst);
            }
        }

        protected Cassette SelectCraneRequest(string s)
        {
            //System.Diagnostics.Debug.WriteLine("[" + s + "] SelectCraneRequest");

            Cassette rslt = null;

            rslt = MCS.SelectCraneRequest(s);

            return rslt;
        }      
        #endregion

        #region Event Routines - Uni-inline
        protected virtual void Execute_PU2Xr_Routine(double now, string s, string u, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_PU2Xr_Routine(" + now + ", " + s + ", " + u + ", " + cst.ToString() + ")");
            
            _CR[s] = 0;

            double tr = MasterData.RetrievalTime[s];
            ScheduleLocalEvent("PU2X", now + tr, s, u, cst);
        }

        protected virtual void Execute_PU2X_Routine(double now, string s, string u, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_PU2X_Routine(" + now + ", " + s + ", " + u + ", " + cst.ToString() + ")");

            Factory.UniInlineCell.P[u].ChangePortState(PortState.DR, PortState.X);

            cst.IsMoving = true;

            double td = MasterData.DeliveryTime[s];
            ScheduleLocalEvent("CU", now + td, s, cst);

            HandleNextCassette(now, u, FactoryObjectType.Uniinline);
            
            //Step Wip Kanban
            //if (Factory.MasterData.StepKanbanEqpList.Contains(u))
            //{
            //    ScheduleMirrorEvent("FabIn", "CA", now);
            //}
        }

        #endregion

        #region Event Routines - Bi-inline 
        /// <summary>
        /// Event Routine for PO2Xr event
        /// </summary>
        /// <param name="now">Simulation Clock</param>
        /// <param name="s">STK ID</param>
        /// <param name="b">Bi-inline ID</param>
        /// <param name="cst">Cassette</param>
        protected virtual void Execute_PO2Xr_Routine(double now, string s, string b, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_PO2Xr_Routine(" + now + ", " + s + ", " + b + ", " + cst.ToString() + ")");

            _CR[s] = 0;

            double tr = MasterData.RetrievalTime[s];
            ScheduleLocalEvent("PO2X", now + tr, s, b, cst);
        }

        /// <summary>
        /// Event Routine for PO2X event
        /// </summary>
        /// <param name="now">Simulation Clock</param>
        /// <param name="s">STK ID</param>
        /// <param name="b">Bi-inline ID</param>
        /// <param name="cst">Cassette</param>
        protected virtual void Execute_PO2X_Routine(double now, string s, string b, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_PO2X_Routine(" + now + ", " + s + ", " + b + ", " + cst.ToString() + ")");

            Factory.BiInlineCell.PO[b].ChangePortState(PortState.DR, PortState.X);
            
            cst.IsMoving = true;

            RequestEmptyCassette(b, s);

            double td = MasterData.DeliveryTime[s];
            ScheduleLocalEvent("CU", now + td, s, cst);

            //comment out by D. Kang at 2013.12.28
            //if (Factory.BiInlineCell.P[b].X > 0)
            //{
            //    HandleNextCassette(now, b, FactoryObjectType.Biinline);
            //}

            //Step Wip Kanban
            //if (Factory.MasterData.StepKanbanEqpList.Contains(b))
            //{
            //    ScheduleMirrorEvent("FabIn", "CA", now);
            //}
        }

        /// <summary>
        /// Event Routine for MEC event
        /// </summary>
        /// <param name="now">Simulation Clock</param>
        /// <param name="s">STK ID</param>
        /// <param name="b">Bi-inline ID</param>
        /// <param name="cst">Cassette</param>
        protected virtual void Execute_MEC_Routine(double now, string s, string b, Cassette cst)
        {
            Cassette emptyCst = new Cassette("", "", 0, "");
            emptyCst.B = b;

            bool RSV = RsvC(s, PickupPointType.PI, emptyCst);
            if (RSV)
                ScheduleLocalEvent("PI2Xr", now, s, b, emptyCst);
        }

        /// <summary>
        /// Event Routine for PI2Xr event
        /// </summary>
        /// <param name="now">Simulation Clock</param>
        /// <param name="s">STK ID</param>
        /// <param name="b">Bi-inline ID</param>
        /// <param name="cst">Cassette</param>
        protected virtual void Execute_PI2Xr_Routine(double now, string s, string b, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_PI2Xr_Routine(" + now + ", " + s + ", " + b + ", " + cst.ToString() + ")");

            _CR[s] = 0;

            double tr = MasterData.RetrievalTime[s];
            ScheduleLocalEvent("PI2X", now + tr, s, b, cst);
        }

        /// <summary>
        /// Event Routine for PI2X event
        /// </summary>
        /// <param name="now">Simulation Clock</param>
        /// <param name="s">STK ID</param>
        /// <param name="b">Bi-inline ID</param>
        /// <param name="cst">Cassette</param>
        protected virtual void Execute_PI2X_Routine(double now, string s, string b, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_PI2X_Routine(" + now + ", " + s + ", " + b + ", " + cst.ToString() + ")");

            Factory.BiInlineCell.P[b].ChangePortState(PortState.E, PortState.X);

            cst.IsMoving = true;

            double td = MasterData.DeliveryTime[s];
            ScheduleLocalEvent("CU", now + td, s, cst);

            //Added by D.  Kang at 2013.12.28
            HandleNextCassette(now, b, FactoryObjectType.Biinline);

        }

        protected virtual void Execute_E2POr_Routine(double now, string s, Cassette cst)
        {
            _CR[s] = 0;

            double tr = MasterData.RetrievalTime[s];
            ScheduleLocalEvent("E2PO", now + tr, s, cst);
        }

        protected virtual void Execute_E2PO_Routine(double now, string s, Cassette cst)
        {
            cst.IsMoving = true;

            double td = MasterData.DeliveryTime[s];
            ScheduleLocalEvent("CU", now + td, s, cst);
        }
        #endregion

        #region Event Routines - Oven
        protected virtual void Execute_PV2Xr_Routine(double now, string s, string v, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_PV2Xr_Routine(" + now + ", " + s + ", " + v + ", " + cst.ToString() + ")");

            _CR[s] = 0;

            double tr = MasterData.RetrievalTime[s];
            ScheduleLocalEvent("PV2X", now + tr, s, v, cst);
        }

        protected virtual void Execute_PV2X_Routine(double now, string s, string v, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_PV2X_Routine(" + now + ", " + s + ", " + v + ", " + cst.ToString() + ")");

            Factory.Oven.P[v].ChangePortState(PortState.DR, PortState.X);

            cst.IsMoving = true;

            double td = MasterData.DeliveryTime[s];
            ScheduleLocalEvent("CU", now + td, s, cst);

            HandleNextCassette(now, v, FactoryObjectType.Oven);

            //Step Wip Kanban
            //if (Factory.MasterData.StepKanbanEqpList.Contains(v))
            //{
            //    ScheduleMirrorEvent("FabIn", "CA", now);
            //}
        }

        /// <summary>
        /// Handle a next casssette if exist at an equipment (e).
        /// </summary>
        /// <param name="now">Simulation Clock</param>
        /// <param name="e">Equipment ID that needs a cassette to load</param>
        protected void HandleNextCassette(double now, string e, FactoryObjectType type)
        {
            //System.Diagnostics.Debug.WriteLine("HandleNextCassette(" + now, "," + e);

            Cassette nextCst = RTD.NextCassette(e);
            if (nextCst != null)
            {
                //Port 예약
                ProcessingEquipment eqp = (ProcessingEquipment)Factory[e];
                eqp.P[e].ChangePortState(PortState.X, PortState.RX);

                //Route 갱신
                nextCst.D = e;
                nextCst.Route = Factory.MCS.Route(nextCst);

                //Schedule CI event if any crane is idle at the stocker
                StockerSpecification stk = Factory.MasterData.Stocker.Query(nextCst.C);
                if (stk != null)
                {
                    string stkid = nextCst.C;
                    if (Factory.Stocker.CR[stkid] > 0)
                        Factory.Stocker.ScheduleMirrorEvent("InlineStocker", "CI", Factory.Clock, nextCst.C);
                }
                else
                {
                    string curEQP = nextCst.C;

                    if (nextCst.Route.Count > 1)
                    {
                        nextCst.A = nextCst.Route[1].ID;
                        nextCst.ShiftRoute();
                    }

                    string stkid = nextCst.A;

                    if (Factory.Stocker.CR[stkid] > 0)
                        Factory.Stocker.ScheduleMirrorEvent("InlineStocker", "CI", Factory.Clock, stkid);

                }
            }
        }
        #endregion

        #region Event Routines - Chamber
        protected virtual void Execute_PC2Xr_Routine(double now, string s, string c, Cassette cst)
        {
           // System.Diagnostics.Debug.WriteLine("Execute_PC2Xr_Routine(" + now + ", " + s + ", " + c + ", " + cst.ToString() + ")");
            _CR[s] = 0;

            double tr = MasterData.RetrievalTime[s];
            ScheduleLocalEvent("PC2X", now + tr, s, c, cst);
        }

        protected virtual void Execute_PC2X_Routine(double now, string s, string c, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_PC2X_Routine(" + now + ", " + s + ", " + c + ", " + cst.ToString() + ")");

            Factory.Chamber.P[c].ChangePortState(PortState.DR, PortState.X);

            cst.IsMoving = true;

            double td = MasterData.DeliveryTime[s];
            ScheduleLocalEvent("CU", now + td, s, cst);

            HandleNextCassette(now, c, FactoryObjectType.Chamber);

            //Step Wip Kanban
            //if (Factory.MasterData.StepKanbanEqpList.Contains(c))
            //{
            //    ScheduleMirrorEvent("FabIn", "CA", now);
            //}
        }

        #endregion

        #region Event Routines - Stocker Buffer
        protected virtual void Execute_B2Xr_Routine(double now, string s, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_B2Xr_Routine(" + now + ", " + s + ", " + cst.ToString() + ")");

            _CR[s] = 0;

            double tr = MasterData.RetrievalTime[s];
            ScheduleLocalEvent("B2X", now + tr, s, cst);
        }

        protected virtual void Execute_B2X_Routine(double now, string s, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_B2X_Routine(" + now + ", " + s + ", " + cst.ToString() + ")");

            _WIP[s]--;

            cst.IsMoving = true;

            double td = MasterData.DeliveryTime[s];
            ScheduleLocalEvent("CU", now + td, s, cst);
        }

        private void Execute_X2B_Routine(double now, string s, Cassette cst)
        {
           // System.Diagnostics.Debug.WriteLine("ExecExecute_X2B_Routineute_B2X_Routine(" + now + ", " + s + ", " + cst.ToString() + ")");
            cst.IsMoving = false;

            cst.PP = PickupPointType.B;
            _WIP[s]++;
            _CRL[s].Enqueue(cst);
        }
        #endregion

        #region Event Routines - Conveyor
        /// <summary>
        /// Event Route for C2SI event
        /// </summary>
        /// <param name="now">Simulation Clock</param>
        /// <param name="s">STK ID</param>
        /// <param name="y">CONV ID</param>
        private void Execute_C2SI_Routine(double now, string s, string y)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_C2SI_Routine(" + now + ", " + s + ", " + y + ")");

            Cassette cst = Factory.Conveyor.CQ[y].Dequeue();
            _SI[s, y] = 0;
            _SI.SetCassette(s, y, cst);//for data collection

            cst.UpdatePlace(s);

            bool RSV = RsvC(s, PickupPointType.SI, cst);

            if (RSV)
            {
                ScheduleLocalEvent("SI2Xr", now, s, y, cst);
            }

            //for debugging 3/22 김현식
            //if(cst.P == "T01000")
                //System.Diagnostics.Debug.WriteLine("C2SI:\t" + now + ", " + cst.ID + ", " + cst.ReleaseDate);
        }

        protected virtual void Execute_SI2Xr_Routine(double now, string s, string y, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_SI2Xr_Routine(" + now + ", " + s + ", " + y + "," + cst.ToString() + ")");

            _CR[s] = 0;

            double tr = MasterData.RetrievalTime[s];

            ScheduleLocalEvent("SI2X", now + tr, s, y, cst);
        }

        protected virtual void Execute_SI2X_Routine(double now, string s, string y, Cassette cst)
        {
           // System.Diagnostics.Debug.WriteLine("Execute_SI2X_Routine(" + now + ", " + s + ", " + y + "," + cst.ToString() + ")");

            bool C1 = false;
            if (Factory.Conveyor.CQ[y].Count > 0)
            {
                _SI[s, y] = -1;
                C1 = true;
            }else{
                _SI[s, y] = 1;
            }

            cst.IsMoving = true;

            if (C1)
                ScheduleLocalEvent("C2SI", now, s, y);

            double td = MasterData.DeliveryTime[s];
            ScheduleLocalEvent("CU", now + td, s, cst);
        }
        #endregion

        /// <summary>
        /// Event Routine for Move Event
        /// </summary>
        /// <param name="now">Simulation Clock</param>
        /// <param name="s">STK ID</param>
        /// <param name="e">EQP ID</param>
        /// <param name="cst">Cassette</param>
        protected virtual void Execute_Move_Routine(double now, string s, string e, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("Execute_Move_Routine(" + now + ", " + s + ", " + e + "," + cst.ToString() + ")");

            ProcessingEquipment PE = (ProcessingEquipment)Factory[e];
            cst.UpdatePlace(s);

            switch (PE.Type)
            {
                case FactoryObjectType.Uniinline:
                    {
                        Factory.UniInlineCell.P[e].ChangePortState(PortState.E, PortState.DR);
                        bool RSV = RsvC(s, PickupPointType.PU, cst);
                        if (RSV)
                            ScheduleLocalEvent("PU2Xr", now, s, e, cst);
                        break;
                    }
                case FactoryObjectType.Biinline:
                    {
                        Factory.BiInlineCell.PO[e].ChangePortState(PortState.F, PortState.DR);
                        bool RSV = RsvC(s, PickupPointType.PO, cst);
                        if (RSV)
                            ScheduleLocalEvent("PO2Xr", now, s, e, cst);
                        break;
                    }
                case FactoryObjectType.Oven:
                    {
                        Factory.Oven.P[e].ChangePortState(PortState.E, PortState.DR);
                        bool RSV = RsvC(s, PickupPointType.PV, cst);
                        if (RSV)
                            ScheduleLocalEvent("PV2Xr", now, s, e, cst);
                        break;
                    }
                case FactoryObjectType.Chamber:
                    {
                        Factory.Chamber.P[e].ChangePortState(PortState.E, PortState.DR);
                        bool RSV = RsvC(s, PickupPointType.PC, cst);
                        if (RSV)
                            ScheduleLocalEvent("PC2Xr", now, s, e, cst);
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
        }

        protected void RequestEmptyCassette(string b, string s)
        {
            Cassette emptyCst = 
                new Cassette("", "", 0, "");
            emptyCst.A = b;
            emptyCst.DP = DropPointType.PO;
            emptyCst.PP = PickupPointType.E;
            _CRL[s].Enqueue(emptyCst);
        }

        protected void ScheduleLocalEvent(
            string eventName, double time, 
            string s, string y, Cassette cst)
        {
            FactoryLocalEvent e = new FactoryLocalEvent(this.Name, eventName, time);

            e.AddParameter(s);
            e.AddParameter(y);
            e.AddParameter(cst);

            ScheduleLocalEvent(e);
        }

        protected void ScheduleLocalEvent(
            string eventName, double time,
            string s, string y, Cassette cst, int priority)
        {
            FactoryLocalEvent e = new FactoryLocalEvent(this.Name, eventName, time, priority);

            e.AddParameter(s);
            e.AddParameter(y);
            e.AddParameter(cst);

            ScheduleLocalEvent(e);
        }

        protected new void ScheduleLocalEvent(
            string eventName, double time,
            string s, Cassette cst)
        {
            FactoryLocalEvent e = new FactoryLocalEvent(this.Name, eventName, time);

            e.AddParameter(s);
            e.AddParameter(cst);

            ScheduleLocalEvent(e);
        }

        protected new void ScheduleLocalEvent(
            string eventName, double time,
            string s, Cassette cst, int priority)
        {
            FactoryLocalEvent e = new FactoryLocalEvent(this.Name, eventName, time, priority);

            e.AddParameter(s);
            e.AddParameter(cst);

            ScheduleLocalEvent(e);
        }

        protected void ScheduleLocalEvent(
            string eventName, double time,
            string s, string y)
        {
            FactoryLocalEvent e = new FactoryLocalEvent(this.Name, eventName, time);

            e.AddParameter(s);
            e.AddParameter(y);

            ScheduleLocalEvent(e);
        }

        /// <summary>
        /// Reserve a crane for transferring a cassette (cst) located at a place of which type is pptype at an inline stocker (s) 
        /// </summary>
        /// <param name="cst"></param>
        /// <param name="pptype"></param>
        /// <returns></returns>
        public bool RsvC(string s, PickupPointType pptype, Cassette cst)   
        {
            if (this._CR[s] == 1)
            {
                if (pptype == PickupPointType.PI) //null cst를 PI로부터 가져오는 경우: ePI2STK
                {
                    cst.DP = DropPointType.E;
                }
                else if (cst.Route.Count == 1) //이 stk가 목적지인 경우: CSTIN, EQP2EQP (예약 못함)
                {
                    cst.A = s;
                    cst.DP = DropPointType.B;
                }
                else if (cst.Route.Count == 2) //이 stk 내의 설비가 목적지인 경우
                {
                    string nextEQP = cst.Route[1].ID;
                    cst.A = nextEQP; //목적 설비명
                    switch (MasterData.EQP[nextEQP].EQP_Type)
                    {
                        case EquipmentType.UniInlineCell: { cst.DP = DropPointType.PU; break; }
                        case EquipmentType.BiInlineCell: { cst.DP = DropPointType.PI; break; }
                        case EquipmentType.Chamber: { cst.DP = DropPointType.PC; break; }
                        case EquipmentType.Oven: { cst.DP = DropPointType.PV; break; }
                    }
                }
                else //다른 stk가 목적지인 경우: CSTOUT, PASS
                {
                    string y = cst.Route[1].ID;
                    if (_SO[s, y] == 1)
                    {
                        _SO[s, y] = -1; //예약
                        cst.A = y; //cst.after = x[1] => 다음 conveyor id
                        cst.DP = DropPointType.SO;
                    }
                    else     //이 경우, SO가 blocking 되어 있으므로 진행할 수 없음
                    {
                        cst.PP = pptype;
                        _CRL[s].Enqueue(cst);
                        return false;
                    }
                }
                return true;
            }
            else
            {
                cst.PP = pptype;    //pickup point type 지정
                _CRL[s].Enqueue(cst);
                return false;
            }
        }

        #region Methods
        public override void Run()
        {
            foreach (string stkid in _CRL.Keys)
            {
                if (_CRL[stkid].Count > 0)
                    Execute_CI_Routine(0, stkid);
            }
        }
        public override void ExecuteLocalEvent(Engine.LocalEvent e)
        {
            if (e.ObjectName == this.Name)
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)e;
                if (e.Name == "Move")
                    Execute_Move_Routine(fle.Time, (string)fle[0], (string)fle[1], (Cassette)fle[2]);
                else if (e.Name == "MEC")
                    Execute_MEC_Routine(fle.Time, (string)fle[0], (string)fle[1], (Cassette)fle[2]);
                else if (e.Name == "C2SI")
                    Execute_C2SI_Routine(fle.Time, (string)fle[0], (string)fle[1]);
                else if (e.Name == "PV2Xr")
                    Execute_PV2Xr_Routine(fle.Time, (string)fle[0], (string)fle[1], (Cassette)fle[2]);
                else if (e.Name == "B2Xr")
                    Execute_B2Xr_Routine(fle.Time, (string)fle[0], (Cassette)fle[1]);
                else if (e.Name == "PC2Xr")
                    Execute_PC2Xr_Routine(fle.Time, (string)fle[0], (string)fle[1], (Cassette)fle[2]);
                else if (e.Name == "SI2Xr")
                    Execute_SI2Xr_Routine(fle.Time, (string)fle[0], (string)fle[1], (Cassette)fle[2]);
                else if (e.Name == "PO2Xr")
                    Execute_PO2Xr_Routine(fle.Time, (string)fle[0], (string)fle[1], (Cassette)fle[2]);
                else if (e.Name == "PI2Xr")
                    Execute_PI2Xr_Routine(fle.Time, (string)fle[0], (string)fle[1], (Cassette)fle[2]);
                else if (e.Name == "PU2Xr")
                    Execute_PU2Xr_Routine(fle.Time, (string)fle[0], (string)fle[1], (Cassette)fle[2]);
                else if (e.Name == "PV2X")
                    Execute_PV2X_Routine(fle.Time, (string)fle[0], (string)fle[1], (Cassette)fle[2]);
                else if (e.Name == "B2X")
                    Execute_B2X_Routine(fle.Time, (string)fle[0], (Cassette)fle[1]);
                else if (e.Name == "PC2X")
                    Execute_PC2X_Routine(fle.Time, (string)fle[0], (string)fle[1], (Cassette)fle[2]);
                else if (e.Name == "SI2X")
                    Execute_SI2X_Routine(fle.Time, (string)fle[0], (string)fle[1], (Cassette)fle[2]);
                else if (e.Name == "PO2X")
                    Execute_PO2X_Routine(fle.Time, (string)fle[0], (string)fle[1], (Cassette)fle[2]);
                else if (e.Name == "PI2X")
                    Execute_PI2X_Routine(fle.Time, (string)fle[0], (string)fle[1], (Cassette)fle[2]);
                else if (e.Name == "PU2X")
                    Execute_PU2X_Routine(fle.Time, (string)fle[0], (string)fle[1], (Cassette)fle[2]);
                else if (e.Name == "CU")
                    Execute_CU_Routine(fle.Time, (string)fle[0], (Cassette)fle[1]);
                else if (e.Name == "CI")
                    Execute_CI_Routine(fle.Time, (string)fle[0]);
                else if (e.Name == "X2B")
                    Execute_X2B_Routine(fle.Time, (string)fle[0], (Cassette)fle[1]);
                else if (e.Name == "E2POr")
                    Execute_E2POr_Routine(fle.Time, (string)fle[0], (Cassette)fle[1]);
                else if (e.Name == "E2PO")
                    Execute_E2PO_Routine(fle.Time, (string)fle[0], (Cassette)fle[1]);
            }
        }

        public override void Initialize(Dictionary<string, object> args)
        {
            _CR = new Dictionary<string, int>();
            _WIP = new Dictionary<string, int>();
            _CRL = new Dictionary<string, CassetteCollection>();
            _SO = new StockerPortCollection();
            _SI = new StockerPortCollection();

            foreach(string stkid in Factory.MasterData.Stocker.Keys)
            {
                if (stkid == "FabIn" || stkid == "FabOut")
                    continue;

                StockerSpecification stk = Factory.MasterData.Stocker[stkid];

                if (stk.Type == StockerType.Single)
                    _CR.Add(stkid, 1);
                else
                    _CR.Add(stkid, 2);

                //TODO: WIP 반영
                _WIP.Add(stkid, 0);
                _CRL.Add(stkid, new CassetteCollection());
                
                NetworkNode node = Factory.MasterData.Network.Nodes[stkid];
                foreach(string inConvID in node.InputEdges)
                {
                    _SI.Add(stkid, inConvID);
                }

                foreach(string outConvID in node.OutputEdges)
                {
                    _SO.Add(stkid, outConvID);
                }

                //bi-inline output port's empty cassette placement
                foreach (string eqpid in node.OutPortEQPs)
                {
                    if (Factory.MasterData.EQP[eqpid].EQP_Type == EquipmentType.BiInlineCell)
                    {
                        for(int k = 0 ; k < Factory.MasterData.EQPPort[eqpid].Out;k++)
                            RequestEmptyCassette(eqpid, stkid);
                    }
                }
            }
        }

        public override void FireSchedulingArc(VMS.IFS.Engine.ApplicationMessage msg)
        {
            //TODO
        }
        #endregion
    }

    
}
