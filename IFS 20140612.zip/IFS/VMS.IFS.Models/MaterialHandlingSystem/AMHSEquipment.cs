﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.Models
{
    public abstract class AMHSEquipment : FactoryObjectSimulator
    {
        #region Member Variables
        #endregion

        #region Properties
        #endregion

        #region Constructors
        public AMHSEquipment(string name, FactoryObjectType type, Factory factory)
            : base(name, type, factory)
        {
        }

        #endregion

        #region Methods
       
        #endregion
    }

    /*
    public abstract class ApplicationAMHSEquipment : FactoryObjectSimulator
    {
        #region Member Variables
        #endregion

        #region Properties
        #endregion

        #region Constructors
        public ApplicationAMHSEquipment(string name, FactoryObjectType type, Factory factory)
            : base(name, type, factory)
        {
        }

        #endregion

        #region Methods
        
        #endregion
    }*/
}
