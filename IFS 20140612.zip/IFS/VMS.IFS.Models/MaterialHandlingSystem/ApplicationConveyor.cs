﻿using System;
using System.Collections.Generic;
using System.Text;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.DataModel;
using VMS.IFS.Engine.ApplicationConnection;

namespace VMS.IFS.Models
{
    public class ApplicationConveyor : Conveyor
    {
        #region Member Variables
        private Dictionary<string, List<FactoryLocalEvent>> _MEL;
        #endregion

        #region Properties
        #endregion

        #region Constructors
        public ApplicationConveyor(Factory factory)
            : base(factory)
        {
            _MEL = new Dictionary<string, List<FactoryLocalEvent>>();
        }
        #endregion

        #region Event Routines
        protected override void Execute_SOC_Routine(double now, string y, Cassette cst)
        {
            Factory.Stocker.SO[cst.B, y] = 1;

            if (cst.D == "FabOut")
            {
                Factory.Stocker.SO[cst.B, y] = 1;
                cst.ShiftRoute();
                ScheduleMirrorEvent("FabOut", "CFO", now, cst);
                ScheduleMirrorEvent("FabIn", "CFO", now, cst);
            }
            else if (y.StartsWith("FabIn"))
            {
                double tc = Factory.MasterData.ConveyTime[y];
                ScheduleLocalEvent("EOC", now + tc, y, cst);
            }else
            {
                FactoryLocalEvent e = new FactoryLocalEvent("Conveyor", "SOC", now, y, cst);
                _MEL[y].Add(e);

                string cMsg = makeConveyMessage(y, cst, now);
                Send_Msg(cMsg);
            }
        }

        private string makeConveyMessage(string y, Cassette cst, double now)
        {
            string msg = string.Empty;
            //"Delay_Conveyor_SOC#" + cn + "#" + cst.CN + "#" + clock + "# #";
            msg = string.Format("Delay_Conveyor_SOC#{0}#{1}#{2}# #", y, cst.ID, now);
            return msg;
        }
        #endregion

        #region Methods
        public override void Initialize(Dictionary<string, object> args)
        {
            base.Initialize(args);

            _MEL = new Dictionary<string, List<FactoryLocalEvent>>();
            foreach (string convid in Factory.MasterData.Conveyor.Keys)
            {
                _MEL.Add(convid, new List<FactoryLocalEvent>());
            }
        }

        public override void FireSchedulingArc(VMS.IFS.Engine.ApplicationMessage msg)
        {
            FactoryLocalEvent e = _MEL[msg.ObjectID][0];
            _MEL[msg.ObjectID].RemoveAt(0);
            FactoryLocalEvent ne = new FactoryLocalEvent(e.ObjectName, "EOC", msg.EventTime, e.EQPID, e.Cassette);
            ScheduleLocalEvent(ne);          
        }
        #endregion
    }
}
