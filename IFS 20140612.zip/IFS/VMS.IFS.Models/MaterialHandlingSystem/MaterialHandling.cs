﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public class MaterialHandling : FactoryObjectSimulator
    {
        #region Member Variables
        private bool _RsvP;

        private Dictionary<string, CassetteCollection> _M; // key: target EQP ID, value: moving cassettes

        #endregion

        #region Properties

        public Dictionary<string, CassetteCollection> M
        {
            get { return _M; }
        }

        #endregion

        #region Constructors
        public MaterialHandling(Factory factory)
            : base("MaterialHandling", factory)
        {
            _M = new Dictionary<string, CassetteCollection>();
            foreach (string eqpid in factory.MasterData.EQP.Equipments)
            {
                _M.Add(eqpid, new CassetteCollection());
            }
        }
        #endregion

        #region Event Routines
        private void Execute_Move_Routine(double now, string s, Cassette cst)
        {
            if (string.IsNullOrEmpty(cst.D))
            {
                ScheduleMirrorEvent("FabOut", "CFO", now, string.Empty, cst);
                ScheduleMirrorEvent("FabIn", "CFO", now, string.Empty, cst);
            }
            else
            {
                string fromStkID = getFromStkID(s);
                string toStkID = getToStkID(cst.D);
                
                double td = MasterData.MoveTime[fromStkID, toStkID];
                Factory[cst.D].M[cst.D]++;
                _M[cst.D].Enqueue(cst);

                ScheduleLocalEvent("CA", now + td, cst.D, cst);
            }
        }

        private string getFromStkID(string eqp)
        {
            string fromStkID = string.Empty;
            EquipmentSpecification eqpSpec = Factory.MasterData.EQP[eqp];
            if (eqpSpec == null)
                return string.Empty;

            EquipmentType fromEQPType = eqpSpec.EQP_Type;
            if (fromEQPType == EquipmentType.UniInlineCell ||
                    fromEQPType == EquipmentType.Chamber ||
                    fromEQPType == EquipmentType.Oven)
                fromStkID = Factory.MasterData.EQPPort[eqp].INOUTSTKID;
            else if (fromEQPType == EquipmentType.BiInlineCell)
                fromStkID = Factory.MasterData.EQPPort[eqp].OUTSTKID;

            return fromStkID;
        }

        private string getToStkID(string eqp)
        {
            string toStkID = string.Empty;
            
            EquipmentSpecification eqpSpec = Factory.MasterData.EQP[eqp];
            if (eqpSpec == null)
                return string.Empty;
            EquipmentType toEQPType = eqpSpec.EQP_Type;

            if (toEQPType == EquipmentType.UniInlineCell ||
                    toEQPType == EquipmentType.Chamber ||
                    toEQPType == EquipmentType.Oven)
                toStkID = Factory.MasterData.EQPPort[eqp].INOUTSTKID;
            else if (toEQPType == EquipmentType.BiInlineCell)
                toStkID = Factory.MasterData.EQPPort[eqp].OUTSTKID;

            return toStkID;
        }

        private void Execute_CA_Routine(double now, string d, Cassette cst)
        {
            _RsvP = false;
            cst.ArrivalDate = now;
            cst.C = d;

            _M[d].Dequeue(cst.ID);

            EquipmentType eqpType = MasterData.EQP[d].EQP_Type;
            if (eqpType == EquipmentType.UniInlineCell)
            {
                Factory.UniInlineCell.Q[d].Enqueue(cst);
                Factory.UniInlineCell.M[d]--;
                if (Factory.UniInlineCell.P[d].X > 0)
                {
                    Factory.UniInlineCell.P[d].ChangePortState(PortState.X, PortState.RX);
                    _RsvP = true;

                    ScheduleMirrorEvent("UniInlineCell", "uCL", now, d);
                }
            }
            else if (eqpType == EquipmentType.BiInlineCell)
            {
                Factory.BiInlineCell.Q[d].Enqueue(cst);
                Factory.BiInlineCell.M[d]--;
                if (Factory.BiInlineCell.P[d].X > 0)
                {
                    Factory.BiInlineCell.P[d].ChangePortState(PortState.X, PortState.RX);
                    _RsvP = true;

                    ScheduleMirrorEvent("BiInlineCell", "bCL", now, d);
                }

            }
            else if (eqpType == EquipmentType.Oven)
            {
                Factory.Oven.Q[d].Enqueue(cst);
                Factory.Oven.M[d]--;
                if (Factory.Oven.P[d].X > 0)
                {
                    Factory.Oven.P[d].ChangePortState(PortState.X, PortState.RX);
                    _RsvP = true;

                    ScheduleMirrorEvent("Oven", "vCL", now, d);
                }
            }
            else if (eqpType == EquipmentType.Chamber)
            {
                Factory.Chamber.Q[d].Enqueue(cst);
                Factory.Chamber.M[d]--;
                if (Factory.Chamber.P[d].X > 0)
                {
                    Factory.Chamber.P[d].ChangePortState(PortState.X, PortState.RX);
                    _RsvP = true;

                    ScheduleMirrorEvent("Chamber", "cCL", now, d);
                }
            }

            if (Factory.MasterData.StepKanbanEqpList.Contains(d))
            {
                ScheduleMirrorEvent("FabIn", "CA", now);
            }
        }
        #endregion

        #region Methods
        public override void Run()
        {
        }

        public override void ExecuteLocalEvent(Engine.LocalEvent e)
        {
            if (e.ObjectName == "MaterialHandling")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)e;
                if (e.Name == "Move")
                {
                    Execute_Move_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "CA")
                {
                    Execute_CA_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
            }
        }

        public override void Initialize(Dictionary<string, object> args)
        {
            _RsvP = false;

            

        }

        #endregion
    }
}
