﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public enum FactoryObjectType { 
        Uniinline, Biinline, Chamber, Oven, Conveyor, Stocker, FabIn, FabOut };

    public abstract class FactoryObjectSimulator : EventObjectSimulator
    {
        #region Member Variables
        private Factory _Factory;
        protected FactoryObjectType _Type;
        #endregion

        #region Properties
        public Factory Factory
        {
            get { return _Factory; }
        }

        public MasterData MasterData
        {
            get { return _Factory.MasterData; }
        }

        public RealTimeDispatcher RTD
        {
            get { return _Factory.RTD; }
        }

        public MaterialControlSystem MCS
        {
            get { return _Factory.MCS; }
        }

        public FactoryObjectType Type
        {
            get { return _Type; }
        }
        #endregion

        #region Constructors
        public FactoryObjectSimulator(string name, FactoryObjectType type, Factory factory)
            : base(name, factory.SimulationCoordinator)
        {
            _Factory = factory;
            _Type = type;
        }
        #endregion

        #region Methods
        //public abstract void Execute_Move_Routine(double time, string eqpid, Cassette cst);
        public void ScheduleLocalEvent(FactoryLocalEvent e)
        {
            _SC.ScheduleLocalEvent(e);
        }

        public void ScheduleLocalEvent(string eventName, double time, string eqpid)
        {
            FactoryLocalEvent e = new FactoryLocalEvent(this.Name, eventName, time, eqpid);
            _SC.ScheduleLocalEvent(e);
        }

        public void ScheduleLocalEvent(string eventName, double time, string eqpid, Cassette cst)
        {
            FactoryLocalEvent e = new FactoryLocalEvent(this.Name, eventName, time, eqpid, cst);
            _SC.ScheduleLocalEvent(e);
        }

        public void ScheduleLocalEvent(string eventName, double time, string eqpid, Glass gls)
        {
            FactoryLocalEvent e = new FactoryLocalEvent(this.Name, eventName, time, eqpid, gls);
            _SC.ScheduleLocalEvent(e);
        }

        public void ScheduleMirrorEvent(string objectid, string eventName, double time, string eqpid, Cassette cst)
        {
            FactoryLocalEvent e = new FactoryLocalEvent(objectid, eventName, time, eqpid, cst);
            _SC.ScheduleLocalEvent(e);
        }

        public void ScheduleMirrorEvent(string objectid, string eventName, double time, string eqpid1, string eqpid2, Cassette cst)
        {
            FactoryLocalEvent e = new FactoryLocalEvent(objectid, eventName, time);
            e.AddParameter(eqpid1);
            e.AddParameter(eqpid2);
            e.AddParameter(cst);
            _SC.ScheduleLocalEvent(e);
        }

        public void ScheduleMirrorEvent(string objectid, string eventName, double time, Cassette cst)
        {
            FactoryLocalEvent e = new FactoryLocalEvent(objectid, eventName, time);
            e.AddParameter(cst);
            _SC.ScheduleLocalEvent(e);
        }

        public void ScheduleMirrorEvent(string objectid, string eventName, double time, string eqpid)
        {
            FactoryLocalEvent e = new FactoryLocalEvent(objectid, eventName, time, eqpid);
            _SC.ScheduleLocalEvent(e);
        }

        public void ScheduleMirrorEvent(string objectid, string eventName, double time, string s, string y)
        {
            FactoryLocalEvent e = new FactoryLocalEvent(objectid, eventName, time);
            e.AddParameter(s);
            e.AddParameter(y);
            _SC.ScheduleLocalEvent(e);
        }
        #endregion
    }

    
}
