﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public abstract class SelectCraneRequestCriterion
    {
        #region Member Variables
        private Factory _Factory;
        #endregion

        #region Properties
        public Factory Factory { get { return _Factory; } }
        #endregion

        #region Constructors
        public SelectCraneRequestCriterion(Factory factory)
        {
            _Factory = factory;
        }
        #endregion

        #region Methods
        public abstract bool Evaluate(Cassette cst, string s);
        #endregion
    }

}
