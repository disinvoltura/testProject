﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    class CassetteAtStockerInPortCriteria : SelectCraneRequestCriterion
    {
        public CassetteAtStockerInPortCriteria(Factory factory)
            : base(factory)
        { }

        public override bool Evaluate(Cassette cst, string s)
        {
            bool rslt = false;

            if (cst.PP == PickupPointType.SI)
            {
                //conveyor로부터 들어온 cst
                // 1) 이 stocker buffer에 들어가는 경우
                // 2) 이 stocker에 설비가 물려있는 경우
                // 3) 다른 stocker로 넘어가야하는 경우
                if (cst.Route.Count == 1)
                {
                    cst.DP = DropPointType.B;
                    cst.A = s;
                    rslt = true;
                }
                else if (cst.Route.Count == 2)
                {
                    string eqpid = cst.Route[1].ID;
                    cst.A = eqpid;

                    FactoryObjectSimulator eqp = Factory[eqpid];
                    if (eqp.Type == FactoryObjectType.Uniinline)
                        cst.DP = DropPointType.PU;
                    else if (eqp.Type == FactoryObjectType.Biinline)
                        cst.DP = DropPointType.PI;
                    else if (eqp.Type == FactoryObjectType.Chamber)
                        cst.DP = DropPointType.PC;
                    else if (eqp.Type == FactoryObjectType.Oven)
                        cst.DP = DropPointType.PV;

                    rslt = true;
                }
                else
                {
                    string y = cst.Route[1].ID;
                    
                    cst.DP = DropPointType.SO;
                    cst.A = y;
                    rslt = true;

                    //commented out by D. Kang <2014.03.07>
                    //string y = cst.Route[1].ID;
                    //if (Factory.Stocker.SO[s, y] == 1)
                    //{
                    //    Factory.Stocker.SO[s, y] = -1;
                    //    cst.DP = DropPointType.SO;
                    //    cst.A = y;
                    //    rslt = true;
                    //}
                }
            }

            return rslt;
        }
    }
}
