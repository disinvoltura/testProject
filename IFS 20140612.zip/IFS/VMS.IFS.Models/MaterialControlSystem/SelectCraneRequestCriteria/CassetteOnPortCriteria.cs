﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public class CassetteOnPortCriteria : SelectCraneRequestCriterion
    {
        public CassetteOnPortCriteria(Factory factory)
            : base(factory)
        { }

        public override bool Evaluate(Cassette cst, string s)
        {
            bool rslt = false;

            if (cst.PP == PickupPointType.PC ||
                cst.PP == PickupPointType.PO ||
                cst.PP == PickupPointType.PU ||
                cst.PP == PickupPointType.PV)
            {
                //설비 port 위에 있던 cst
                if (cst.Route.Count == 0)
                {
                    //다른 port를 예약 못하고 대기 중인 cst
                    string destin = Factory.RTD.NextEQP(cst);

                    if (destin.Equals(""))
                    {
                        string destinstk = Factory.RTD.SelectNextSTK(cst.B);
                        if (!destinstk.Equals(""))
                        {
                            cst.Route = Factory.MCS.Route(cst.C, destinstk);
                            if (cst.Route.Count == 1)
                            {
                                cst.A = cst.Route[0].ID;
                            }
                            else
                            {
                                cst.A = cst.Route[1].ID;
                            }
                        }
                    }
                    else if (!destin.Equals(cst.C))  //다른 설비가 예약된 경우
                    {
                        ProcessingEquipment eqp = (ProcessingEquipment)Factory[destin];
                        eqp.P[destin].ChangePortState(PortState.X, PortState.RX);

                        cst.Route = Factory.MCS.Route(cst.C, destin);
                        cst.A = cst.Route[1].ID;

                        FactoryObjectSimulator nextEQP = Factory[cst.A];
                        if (nextEQP.Type == FactoryObjectType.Uniinline)
                            cst.DP = DropPointType.PU;
                        else if (nextEQP.Type == FactoryObjectType.Biinline)
                            cst.DP = DropPointType.PI;
                        else if (nextEQP.Type == FactoryObjectType.Chamber)
                            cst.DP = DropPointType.PC;
                        else if (nextEQP.Type == FactoryObjectType.Oven)
                            cst.DP = DropPointType.PV;
                        else if (nextEQP.Type == FactoryObjectType.Conveyor)
                            cst.DP = DropPointType.SO;

                        rslt = true;
                    }
                }
                else if (cst.Route.Count == 1)
                {
                    //stocker shelf로 이동해야 하는데 crane이 없어서 대기 중인 cst
                    cst.DP = DropPointType.B;
                    rslt = true;
                }
                else
                {
                    //port는 예약 했는데 crane이 없어서 대기 중인 cst
                    cst.A = cst.Route[1].ID;

                    FactoryObjectSimulator eqp = Factory[cst.A];

                    if (eqp.Type == FactoryObjectType.Uniinline)
                        cst.DP = DropPointType.PU;
                    else if (eqp.Type == FactoryObjectType.Biinline)
                        cst.DP = DropPointType.PI;
                    else if (eqp.Type == FactoryObjectType.Chamber)
                        cst.DP = DropPointType.PC;
                    else if (eqp.Type == FactoryObjectType.Oven)
                        cst.DP = DropPointType.PV;
                    else if (eqp.Type == FactoryObjectType.Conveyor)
                    {
                        //cst.DP = DropPointType.SO;
                        if (Factory.Stocker.SO[s, cst.A] == 1)
                        {
                            cst.DP = DropPointType.SO;
                        }
                        else
                            return false;
                    }

                    rslt = true;
                }
            }
            return rslt;
        }
    }
}
