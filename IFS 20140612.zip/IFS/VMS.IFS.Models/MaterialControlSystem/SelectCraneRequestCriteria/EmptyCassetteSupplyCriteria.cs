﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public class EmptyCassetteSupplyCriteria : SelectCraneRequestCriterion
    {
        public EmptyCassetteSupplyCriteria(Factory factory)
            : base(factory)
        { }

        public override bool Evaluate(Cassette cst, string s)
        {
            bool rslt = false;

            if (cst.PP == PickupPointType.E)
            {
                //Supply an empty casset to out-port of a bi-inline processing equipment
                if (Factory.BiInlineCell.PO[cst.A].X > 0)
                {
                    Factory.BiInlineCell.PO[cst.A].ChangePortState(PortState.X, PortState.RX);
                    rslt = true;
                }
            }

            return rslt;
        }
    }

}
