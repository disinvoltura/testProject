﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public class CassetteAtBufferCriteria : SelectCraneRequestCriterion
    {
        public CassetteAtBufferCriteria(Factory factory)
            : base(factory)
        { }

        public override bool Evaluate(Cassette cst, string s)
        {
            bool rslt = false;

            if (cst.PP == PickupPointType.B)
            {
                if (cst.Route.Count == 1)
                {

                }
                else
                {
                    //2. 설비로부터 선택된 cst
                    cst.A = cst.Route[1].ID;

                    FactoryObjectSimulator eqp = Factory[cst.A];
                    if (eqp.Type == FactoryObjectType.Uniinline)
                        cst.DP = DropPointType.PU;
                    else if (eqp.Type == FactoryObjectType.Biinline)
                        cst.DP = DropPointType.PI;
                    else if (eqp.Type == FactoryObjectType.Chamber)
                        cst.DP = DropPointType.PC;
                    else if (eqp.Type == FactoryObjectType.Oven)
                        cst.DP = DropPointType.PV;
                    else if (eqp.Type == FactoryObjectType.Conveyor)
                    {
                        if (Factory.Stocker.SO[s, cst.A] == 1)
                        {
                            cst.DP = DropPointType.SO;
                        }
                        else
                            return false;
                    }

                    rslt = true;
                }
            }
            return rslt;
        }
    }

}
