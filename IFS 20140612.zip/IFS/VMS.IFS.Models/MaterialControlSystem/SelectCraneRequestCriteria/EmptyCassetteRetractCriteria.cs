﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public class EmptyCassetteRetractCriteria : SelectCraneRequestCriterion
    {
        public EmptyCassetteRetractCriteria(Factory factory)
            : base(factory)
        { }

        public override bool Evaluate(Cassette cst, string s)
        {
            bool rslt = false;

            if (cst.PP == PickupPointType.PI)
            {
                cst.DP = DropPointType.E;
                rslt = true;
            }

            return rslt;
        }
    }

}
