﻿using System;
using System.Collections.Generic;
using System.Text;
using VMS.Foundation.Logging;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.DataModel;

namespace VMS.IFS.Models
{
    public class MaterialControlSystem
    {
        #region Member Variables
        private Factory _Factory;
        protected Logger _Logger;

        private List<SelectCraneRequestCriterion> _CriteriaList;
        #endregion

        #region Properties
        public Factory Factory
        {
            get { return _Factory; }
        }
        #endregion 

        #region Constructors
        public MaterialControlSystem(Factory factory)
        {
            _Factory = factory;

            _Logger = LogManager.GetLogger("MaterialControlSystem");
        }
        #endregion

        #region Methods
        public void Initialize(Dictionary<string, object> args)
        {
            _CriteriaList = new List<SelectCraneRequestCriterion>();
            _CriteriaList.Add(new EmptyCassetteSupplyCriteria(Factory));
            _CriteriaList.Add(new EmptyCassetteRetractCriteria(Factory));
            _CriteriaList.Add(new CassetteAtStockerInPortCriteria(Factory));
            _CriteriaList.Add(new CassetteAtBufferCriteria(Factory));
            _CriteriaList.Add(new CassetteOnPortCriteria(Factory));
        }

        public Route Route(Cassette cst)
        {
            Route rslt = null;

            string fromEqpID = "";
            string fromStkID = "";
            string toStkID = "";
            string toEqpID = "";

            if (Factory.MasterData.Stocker.Contains(cst.C))
            {
                fromStkID = cst.C;
            }
            else
            {
                fromEqpID = cst.C;
                fromStkID = Factory.MasterData.EQPPort[cst.C].OutStkID;
                //fromStkID = Factory.MasterData.EQPPort[cst.C].InStkID; //modified at 2014.03.11
            }

            if (Factory.MasterData.Stocker.Contains(cst.D))
            {
                toStkID = cst.D;
            }
            else
            {
                toEqpID = cst.D;
                toStkID = Factory.MasterData.EQPPort[cst.D].InStkID; //modified at 2014.03.11
                //toStkID = Factory.MasterData.EQPPort[cst.D].OutStkID; //modified at 2014.03.11
            }

            if (!string.IsNullOrEmpty(fromEqpID) &&
                !string.IsNullOrEmpty(toStkID) &&
                fromEqpID == toEqpID)
            {
                rslt = new Route(fromStkID, toStkID);
                rslt.WayPoints.Add(new RouteWayPoint(fromEqpID, RouteWayPointType.Equipment));
                return rslt;
            }

            if (fromStkID == toStkID)
            {
                rslt = new Route(fromStkID, toStkID);
                rslt.WayPoints.Add(new RouteWayPoint(fromStkID, RouteWayPointType.Stocker));
            }
            else
            {
                rslt = Factory.MasterData.Route[fromStkID, toStkID];
            }

            if (rslt == null)
            {
                _Logger.Error("No route exists from <" + cst.C + "> to <" + cst.D + ">");

            }
            else
            {
                if (!string.IsNullOrEmpty(fromEqpID))
                    rslt.Insert(0, fromEqpID, RouteWayPointType.Equipment);
                if (!string.IsNullOrEmpty(toEqpID))
                    rslt.Add(toEqpID, RouteWayPointType.Equipment);
            }
            return rslt;
        }

        public Route Route(string fromSTKID, string toSTKID)
        {
            Route rslt = null;

            rslt = Factory.MasterData.Route[fromSTKID, toSTKID];
            if (rslt == null)
                _Logger.Error("No route exists from <" + fromSTKID + "> to <" + toSTKID + ">");

            return rslt;
        }

        public Cassette SelectCraneRequest(string s)
        {
            Cassette rslt = null;

            List<Cassette> cstlist = Factory.Stocker.CRL[s].Cassettes;

            foreach (SelectCraneRequestCriterion critera in _CriteriaList)
            {
                for (int i = 0; i < cstlist.Count; i++)
                {
                    Cassette cst = cstlist[i];
                    if (critera.Evaluate(cst, s))
                    {
                        Factory.Stocker.CR[s] = -1;
                        Factory.Stocker.CRL[s].Remove(cst);// (i);
                        rslt = cst;
                        break;
                    }
                }

                if (rslt != null)
                    break;
            }

            return rslt;
        }

        /*
        public Cassette SelectCraneRequest(string s)
        {
            Cassette rslt = null;

            List<Cassette> cstlist = Factory.Stocker.CRL[s].Cassettes;
            for (int i = 0; i < cstlist.Count; i++)
            {
                Cassette cst = cstlist[i];
                //System.Diagnostics.Debug.WriteLine("<" + i + "> " + cst.ToString());
                foreach (SelectCraneRequestCriterion critera in _CriteriaList)
                {
                    if (critera.Evaluate(cst, s))
                    {
                        Factory.Stocker.CR[s] = -1;
                        Factory.Stocker.CRL[s].Remove(cst);// (i);
                        rslt = cst;
                        break;
                    }
                }

                if (rslt != null)
                    break;
            }

            return rslt;
        }*/
        #endregion
    }
}
