﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public class BiInlineCell : ProcessingEquipment
    {
        #region Member Variables
        /// <summary>
        /// Ouput Ports
        /// </summary>
        protected Dictionary<string, Port> _PO;
        /// <summary>
        /// Status of track-in robot at a bi-inline cell
        /// </summary>
        protected Dictionary<string, int> _RI;
        /// <summary>
        /// Status of track-out robot at a bi-inline cell
        /// </summary>
        protected Dictionary<string, int> _RO;
        /// <summary>
        /// List of cassettes on the input queue of the bi-inline cell
        /// </summary>
        protected Dictionary<string, CassetteCollection> _IQ;

        /// <summary>
        /// List of cassettes on the output queue of the bi-inline cell
        /// </summary>
        protected Dictionary<string, CassetteCollection> _OQ;

        /// <summary>
        /// List of empty cassettes on the output port
        /// </summary>
        protected Dictionary<string, CassetteCollection> _EQ;//added at 2014/03/11

        #endregion

        #region Properties
        /// <summary>
        /// Internal Input Queue
        /// </summary>
        public Dictionary<string, CassetteCollection> IQ
        {
            get { return _IQ; }
        }

        /// <summary>
        /// Internal Output Queue
        /// </summary>
        public Dictionary<string, CassetteCollection> OQ
        {
            get { return _OQ; }
        }

        /// <summary>
        /// Out-ports
        /// </summary>
        public Dictionary<string, Port> PO
        {
            get { return _PO; }
        }

        public Dictionary<string, CassetteCollection> EQ
        {
            get { return _EQ; }
            set { _EQ = value; }
            
        }
        #endregion

        #region Constructors
        public BiInlineCell(Factory factory)
            : base("BiInlineCell", FactoryObjectType.Biinline, factory)
        {
            //_Q = new Dictionary<string, CassetteCollection>();
            _P = new Dictionary<string, Port>();
            _PO = new Dictionary<string, Port>();
            _RI = new Dictionary<string, int>();
            _RO = new Dictionary<string, int>();
            _IQ = new Dictionary<string, CassetteCollection>();
            _OQ = new Dictionary<string, CassetteCollection>();
            _EQ = new Dictionary<string, CassetteCollection>(); //added at 2014/03/11
            _M = new Dictionary<string, int>();
        }
        #endregion

        #region Event Routines
        protected void Execute_X2PI_Routine(double now, string b, Cassette cst)
        {
            cst.UpdatePlace(b);

            _IQ[b].Enqueue(cst);
            _P[b].ChangePortState(PortState.RX, PortState.F);
            bool C1 = RsvRI(b);            
            if (C1)
                ScheduleLocalEvent("TrackIn", now, b);

            if (Factory.MasterData.StepKanbanStepList.Contains(cst.P))
                ScheduleMirrorEvent("FabIn", "CL", now);
        }

        protected void Execute_TrackIn_Routine(double now, string b)
        {
            _RI[b] = 0;
            Cassette cst = _IQ[b].Dequeue();
            _InProcessingCassettes[b].Enqueue(cst);
            
            if (cst.J == _JT[b])
                ScheduleLocalEvent("FGL", now, b, cst);
            else
                ScheduleLocalEvent("SS", now, b, cst);
        }

        protected void Execute_SS_Routine(double now, string b, Cassette cst)
        {
            _SC[b]++;

            ScheduleLocalEvent("FGL", now + MasterData.SetupTime[b], b, cst);
        }

        protected void Execute_FGL_Routine(double now, string b, Cassette cst)
        {
            double t1 = cst.N * MasterData.TactTime[cst.J, cst.P, b];
            ScheduleLocalEvent("LGL", now + t1, b, cst);

            double t2 = MasterData.TactTime[cst.J, cst.P, b] + MasterData.FlowTime[cst.J, cst.P, b];
            ScheduleLocalEvent("FGP", now + t2, b, cst);
        }

        protected virtual void Execute_LGL_Routine(double now, string b, Cassette cst)
        {
            _RI[b] = 1;
            _P[b].ChangePortState(PortState.F, PortState.E);
            _JT[b] = cst.J;

            bool C5 = false;
            if (_IQ[b].Count > 0)
            { 
                _RI[b] = -1; 
                C5 = true; 
            } 

            //Schedule Next Event              
            if (C5)
                ScheduleLocalEvent("TrackIn", now, b);

            ScheduleMirrorEvent("InlineStocker", "MEC", now, cst.B, b, cst);
        }

        protected void Execute_FGP_Routine(double now, string b, Cassette cst)
        {
            _OQ[b].Enqueue(cst);
            bool C2 = RsvRO(b);
            
            //if (C2)
                //ScheduleLocalEvent("FGU", now, b);

            if (_PO[b].E > 0 && C2)
                ScheduleLocalEvent("FGU", now, b);
        }

        protected void Execute_FGU_Routine(double now, string b)
        {
            _RO[b] = 0;
            Cassette cst = _OQ[b].Dequeue();

            double t1 = cst.N * MasterData.TactTime[cst.J, cst.P, b];
            ScheduleLocalEvent("CD", now + t1, b, cst);

            
        }

        protected virtual void Execute_CD_Routine(double now, string b, Cassette cst)
        {
            _InProcessingCassettes[b].Dequeue(cst.ID);
            _NPC[b]++;

            _RO[b] = 1; 
            _PO[b].ChangePortState(PortState.E, PortState.F);
            
            //By D. Kang 2014/05/28
            Cassette emptyCst = Factory.BiInlineCell.EQ[b].Dequeue();
            if (emptyCst == null)
                System.Diagnostics.Debug.WriteLine("ERRORR!!!!!! in BilineCell.CD");
            bool C3 = false;
            if (_PO[b].E > 0)
            {
                if (_OQ[b].Count > 0) { 
                    _RO[b] = -1; C3 = true; 
                }
            }

            cst.P = RTD.NextStep(cst);
            cst.D = RTD.NextEQP(cst);
            cst.Route = MCS.Route(cst);

            if (cst.Route.Count > 1) //not necessary, just for safety
            {
                cst.A = cst.Route[1].ID;
                cst.ShiftRoute();
                //Schedule Next Event
                ScheduleMirrorEvent("InlineStocker", "Move", now, cst.A, b, cst);
            }

            if (C3)
                ScheduleLocalEvent("FGU", now, b);

            if (Factory.MasterData.StepKanbanStepList.Contains(cst.P))
                ScheduleMirrorEvent("FabIn", "CA", now);

            //System.Diagnostics.Debug.WriteLine("[Bi.CD] Cassette " + cst.ID + " is at CD event at " + now);
        }

        /// <summary>
        /// X2PO event routine
        /// </summary>
        /// <param name="now">Simulation Clock</param>
        /// <param name="b">ID of a bi-inline equipment</param>
        /// <param name="cst">Empty Cassette</param>
        protected void Execute_X2PO_Routine(double now, string b, Cassette cst)
        {
            System.Diagnostics.Debug.WriteLine("Execute_X2PO_Routine(" + now + ", " + b + ", " + cst.ToString() + ")");

            _PO[b].ChangePortState(PortState.RX, PortState.E);
            _EQ[b].Enqueue(cst);
            System.Diagnostics.Debug.WriteLine("EQ[b]:" + _EQ[b].ToString());

            bool C4 = false;
            if (_PO[b].E == 1)
            {
                if (_OQ[b].Count > 0)
                {
                    C4 = true;
                    _RO[b] = -1;
                }
                else
                {
                    C4 = false;
                }
            }

            if (C4)
                ScheduleLocalEvent("FGU", now, b);
        }

        protected bool RsvRI(string b)
        {
            if (_RI[b] == 1)
            {
                _RI[b] = -1; return true;
            }

            return false;
        }

        protected bool RsvRO(string b)
        {
            if (_RO[b] == 1)
            {
                _RO[b] = -1; return true;
            }

            return false;
        }
        #endregion

        #region Methods
        public override void Run()
        {
            foreach (string eqpid in Factory.MasterData.EQP.BilineCells)
            {
                if (_IQ[eqpid].Count > 0)
                {
                    ScheduleLocalEvent("TrackIn", 0, eqpid);
                }

                //int rx = _P[eqpid].RX;
                //while (rx > 0)
                //{
                //    ScheduleLocalEvent("bCL", 0, eqpid);
                //    rx--;
                //} 
            }
        }

        public override void ExecuteLocalEvent(Engine.LocalEvent e)
        {
            if (e.ObjectName == this.Name)
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)e;
                if (e.Name == "X2PI")
                {
                    Execute_X2PI_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "TrackIn")
                {
                    Execute_TrackIn_Routine(fle.Time, fle.EQPID);
                }
                else if (e.Name == "FGL")
                {
                    Execute_FGL_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "FGP")
                {
                    Execute_FGP_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "SS")
                {
                    Execute_SS_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "LGL")
                {
                    Execute_LGL_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "FGU")
                {
                    Execute_FGU_Routine(fle.Time, fle.EQPID);
                }
                else if (e.Name == "X2PO")
                {
                    Execute_X2PO_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "CD")
                {
                    Execute_CD_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
            }
        }

        public override void Initialize(Dictionary<string, object> args)
        {
            //_Q = new Dictionary<string, CassetteCollection>();
            _M = new Dictionary<string, int>();
            _P = new Dictionary<string, Port>();
            _PO = new Dictionary<string, Port>();
            _IQ = new Dictionary<string, CassetteCollection>();
            _OQ = new Dictionary<string, CassetteCollection>();
            _EQ = new Dictionary<string, CassetteCollection>();//added at 2014/03/11
            _RI = new Dictionary<string, int>();
            _RO = new Dictionary<string, int>();
            _JT = new Dictionary<string, string>();
            //_StepKanbanEqpList = new Dictionary<string, bool>();
            _InProcessingCassettes = new Dictionary<string, CassetteCollection>();
            _NPC = new Dictionary<string, int>();
            _SC = new Dictionary<string, int>();

            foreach (string eqpid in Factory.MasterData.EQP.BilineCells)
            {
                //Port
                Port inPorts = new Port(PortState.X, Factory.MasterData.EQPPort[eqpid].In);
                _P.Add(eqpid, inPorts);

                Port outPorts = new Port(PortState.X, Factory.MasterData.EQPPort[eqpid].Out);
                _PO.Add(eqpid, outPorts);

                //Port Queue
                _IQ.Add(eqpid, new CassetteCollection());
                _OQ.Add(eqpid, new CassetteCollection());
                _EQ.Add(eqpid, new CassetteCollection()); //added at 2014/03/11
                if (MasterData.WIP.hasBWIP(eqpid))
                {
                    foreach (Cassette cst in MasterData.WIP[eqpid, "B"])
                    {
                        _IQ[eqpid].Enqueue(cst);
                        _P[eqpid].ChangePortState(PortState.X, PortState.F);
                    }
                }
                
                //Track-in Robot
                _RI.Add(eqpid, 1);
                _RO.Add(eqpid, 1);

                //Virtual Queue
                int vqCapa = (int)args[SimulationArguments.VQCapacity];
                _VQ.Add(eqpid, new CassetteCollection(vqCapa));

                //Loadable Cassette List
                _LCL.Add(eqpid, new CassetteCollection());
                                
                //Job Type for last proceessed cassette
                _JT.Add(eqpid, string.Empty);

                //Number of cassettes moving to the equipment
                _M.Add(eqpid, 0);

                //Number of in-processing cassettes
                _InProcessingCassettes.Add(eqpid, new CassetteCollection());
                
                _NPC.Add(eqpid, 0);
                _SC.Add(eqpid, 0);

            }

        }

        public override void FireSchedulingArc(VMS.IFS.Engine.ApplicationMessage msg)
        {
            //Do Nothing
        }
        #endregion
    }
}
