﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public class UniInlineCell : ProcessingEquipment
    {
        #region Member Variables
        /// <summary>
        /// Key: EQP ID, value: CassetteCollection (B[u])
        /// </summary>
        private Dictionary<string, CassetteCollection> _B;

        /// <summary>
        /// Status of Track-in Robot where the key is EQP ID and the value is status of the track-in robot at the EQP
        /// </summary>
        private Dictionary<string, int> _R;
        #endregion

        #region Properties
        /// <summary>
        /// List of Cassettes on the port
        /// </summary>
        public Dictionary<string, CassetteCollection> B
        {
            get { return _B; }
        }
        #endregion

        #region Constructors
        public UniInlineCell(Factory factory)
            : base ("UniInlineCell", FactoryObjectType.Uniinline, factory)
        {
            //_Q = new Dictionary<string, CassetteCollection>();
            _M = new Dictionary<string, int>();
            _B = new Dictionary<string, CassetteCollection>();
            _R = new Dictionary<string, int>();
            _JT = new Dictionary<string, string>();
        }
        #endregion

        #region Event Routines
        private void Execute_X2PU_Routine(double now, string u, Cassette cst)
        {
            cst.UpdatePlace(u);
            
            _B[u].Enqueue(cst);            
            
            _P[u].ChangePortState(PortState.RX, PortState.F);
            bool RSV = RsvR(u);

            if (RSV)
                ScheduleLocalEvent("TrackIn", now, u);

            if (Factory.MasterData.StepKanbanStepList.Contains(cst.P))
                ScheduleMirrorEvent("FabIn", "CL", now);
        }

        private bool RsvR(string u)
        {
            bool RsvR = false;
            if (_R[u] == 1)
            {
                _R[u] = -1;
                RsvR = true;
            }

            return RsvR;
        }

        private void Execute_TrackIn_Routine(double now, string u)
        {
            Cassette cst = _B[u].Dequeue();
            _InProcessingCassettes[u].Enqueue(cst);
            _R[u] = 0;            

            if (cst.J == _JT[u])
                ScheduleLocalEvent("FGL", now, u, cst);
            else
                ScheduleLocalEvent("SS", now, u, cst);
        }

        private void Execute_FGL_Routine(double now, string u, Cassette cst)
        {            
            double t1 = cst.N * MasterData.TactTime[cst.J, cst.P, u];
            ScheduleLocalEvent("LGL", now + t1, u, cst);
        }

        private void Execute_SS_Routine(double now, string u, Cassette cst)
        {
            _SC[u]++;
            ScheduleLocalEvent("FGL", now + MasterData.SetupTime[u], u, cst);
        }
        
        private void Execute_LGL_Routine(double now, string u, Cassette cst)
        {
            _R[u] = 1;
            _P[u].ChangePortState(PortState.F, PortState.E);
            _JT[u] = cst.J;

            bool RsvR = false;
            if (_B[u].Count > 0)
            {
                _R[u] = -1;
                RsvR = true;
            }
            
            if (RsvR)
                ScheduleLocalEvent("TrackIn", now, u);

            ScheduleLocalEvent("CD", now + MasterData.FlowTime[cst.J, cst.P, u], u, cst);
        }

        private void Execute_CD_Routine(double now, string u, Cassette cst)
        {
            _InProcessingCassettes[u].Dequeue(cst.ID);
            _NPC[u]++;

            cst.P = RTD.NextStep(cst);
            cst.D = RTD.NextEQP(cst);
            cst.Route = MCS.Route(cst);

            if (cst.Route.Count > 1) //not necessary, just for safety
            {
                cst.A = cst.Route[1].ID;
                cst.ShiftRoute();

                //ScheduleLocalEvent("Move", now, u, cst);
                ScheduleMirrorEvent("InlineStocker", "Move", now, cst.A, u, cst);
            }
            else
            {
                System.Diagnostics.Debug.WriteLine("Error at CD event of Uni-inline Equipment[" + u + "]:" + cst.ToString());
            }

            if (Factory.MasterData.StepKanbanStepList.Contains(cst.P))
                ScheduleMirrorEvent("FabIn", "CA", now);
        }

        private void Execute_Move_Routine(double now, string eqpid, Cassette cst)
        {
            ScheduleMirrorEvent("InlineStocker", "Move", now, eqpid, cst);
        }

        #endregion

        #region Methods
        public override void FireSchedulingArc(VMS.IFS.Engine.ApplicationMessage msg)
        {
            //Do Nothing
        }

        public override void Run()
        {
            foreach (string eqpid in Factory.MasterData.EQP.UnilineCells)
            {
                if (_B[eqpid].Count > 0)
                {
                    ScheduleLocalEvent("TrackIn", 0, eqpid);
                }
      
            }
        }

        public override void ExecuteLocalEvent(Engine.LocalEvent e)
        {
            if (e.ObjectName == this.Name)
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)e;
                if (e.Name == "X2PU")
                {
                    Execute_X2PU_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "TrackIn")
                {
                    Execute_TrackIn_Routine(fle.Time, fle.EQPID);
                }
                else if (e.Name == "FGL")
                {
                    Execute_FGL_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "SS")
                {
                    Execute_SS_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "LGL")
                {
                    Execute_LGL_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "CD")
                {
                    Execute_CD_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "Move")
                {
                    Execute_Move_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
            }
        }

        public override void Initialize(Dictionary<string, object> args)
        {
            _P = new Dictionary<string, Port>();
            _B = new Dictionary<string,CassetteCollection>();
            _R = new Dictionary<string,int>();
            //_Q = new Dictionary<string,CassetteCollection>();
            _M = new Dictionary<string, int>();
            _JT = new Dictionary<string, string>();
            //_StepKanbanEqpList = new Dictionary<string, bool>();
            _VQ = new Dictionary<string, CassetteCollection>();
            _LCL = new Dictionary<string, CassetteCollection>();
            _InProcessingCassettes = new Dictionary<string, CassetteCollection>();
            _NPC = new Dictionary<string, int>();
            _SC = new Dictionary<string, int>();

            foreach (string eqpid in Factory.MasterData.EQP.UnilineCells)
            {
                //Port
                Port p = new Port(Factory.MasterData.EQPPort[eqpid].InOut);
                _P.Add(eqpid, p);

                //Port Queue
                _B.Add(eqpid, new CassetteCollection());
                if (MasterData.WIP.hasBWIP(eqpid))
                {
                    foreach (Cassette cst in MasterData.WIP[eqpid, "B"])
                    {
                        _B[eqpid].Enqueue(cst);
                        _P[eqpid].ChangePortState(PortState.X, PortState.F);
                    }
                }
                
                //Track-in Robot
                _R.Add(eqpid, 1);

                //Virtual Queue
                int vqCapa = (int)args[SimulationArguments.VQCapacity];
                _VQ.Add(eqpid, new CassetteCollection(vqCapa));

                //Loadable Cassette List
                _LCL.Add(eqpid, new CassetteCollection());
                
                //Job Type for last proceessed cassette
                _JT.Add(eqpid, string.Empty);

                //Number of cassettes moving to the equipment
                _M.Add(eqpid, 0);
                
                //Number of in-processing cassettes
                _InProcessingCassettes.Add(eqpid, new CassetteCollection());

                _NPC.Add(eqpid, 0);
                _SC.Add(eqpid, 0);
            }
        }
        #endregion
    }
}
