﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.Engine;

namespace VMS.IFS.Models
{
    public class FabOut : FactoryObjectSimulator
    {
        #region Member Variables
        private Dictionary<int, Cassette> _FOQ;

        //public double saveWIPTime;

        #endregion

        #region Properties
        /// <summary>
        /// List of Fab-out Cassettes
        /// </summary>
        public IEnumerable<Cassette> FabOutCassettes
        {
            get { return _FOQ.Values; }
        }
        #endregion

        #region Constructors
        public FabOut(Factory factory)//, double save)
            : base("FabOut", FactoryObjectType.FabOut, factory) 
        {
            _FOQ = new Dictionary<int, Cassette>();

            //saveWIPTime = save;
        }
        #endregion

        #region Methods

        private void Execute_CFO_Routine(double now, Cassette cst)
        {
            //System.Diagnostics.Debug.WriteLine("A Cassette is out from the FAB (" + cst.ToString() + ")");

            _FOQ.Add(cst.ID, cst);            
        }

        
        public override void Run()
        {
            //if (saveWIPTime >= 0)
            //{
            //    ScheduleLocalEvent("SaveWIP", saveWIPTime);
            //}
        }

        public override void ExecuteLocalEvent(LocalEvent e)
        {
            if (e.Name == "CFO" && e.ObjectName == "FabOut")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)e;
                Execute_CFO_Routine(fle.Time, (Cassette)fle[0]);
            }
        }

        public override void Initialize(Dictionary<string, object> args)
        {
            _FOQ = new Dictionary<int, Cassette>();            
        }

        public override void FireSchedulingArc(VMS.IFS.Engine.ApplicationMessage msg)
        {
            //Do Nothing
        }
        #endregion
    }
}
