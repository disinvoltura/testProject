﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public class FabIn : FactoryObjectSimulator
    {
        #region Member Variables
        /// <summary>
        /// Release Controller for Push-type Cassette Releasings
        /// </summary>
        private ReleaseController _RC;

        /// <summary>
        /// List of Released Cassettes
        /// </summary>
        private List<Cassette> _ReleasedCassettes;
                
        /// <summary>
        /// Number of Available Kanbans for Fab WIP (cassette)
        /// </summary>
        private int _FWK;

        /// <summary>
        /// Number of Scheduled Kanbans for Fab WIP (cassette)
        /// </summary>
        private int _IFWK;

        /// <summary>
        /// Number of Available Kanbans for Target Step WIP (cassette)
        /// </summary>
        private int _TWK;

        /// <summary>
        /// Number of Scheduled Kanbans for Target Step WIP (cassette)
        /// </summary>
        private int _ITWK;

        /// <summary>
        /// Time to Next Gate Open (Inter Release Time)
        /// </summary>
        private int _TG;

        private bool _KanbanBlocked;
        private bool _GateOpened;

        #endregion

        public int FabWIPKanban
        {
            get { return _FWK; }
        }

        public int StepWIPKanban
        {
            get { return _TWK; }
        }

        #region Properties
        public List<Cassette> ReleaseCassettes
        {
            get { return _ReleasedCassettes; }
        }      
        #endregion

        #region Constructors
        public FabIn(Factory factory)
            : base("FabIn", FactoryObjectType.FabIn, factory)
        {
            _ReleasedCassettes = new List<Cassette>();

            _KanbanBlocked = false;
            //_TSW = 0;
            _FWK = int.MaxValue;
            _TWK = int.MaxValue;
        }
        #endregion

        #region Methods
        private void Execute_GO_Routine(double now)
        {
            updateBlockedState();

            if (_TG != 0 && _TG != int.MaxValue)
                ScheduleLocalEvent("GO", now + _TG);

            if (!_KanbanBlocked)
                ScheduleLocalEvent("CFI", now);
        }

        private void updateBlockedState()
        {
            if (_FWK > 0 && _TWK > 0)
            {
                _KanbanBlocked = false;
            }
            else
                _KanbanBlocked = true;
        }

        private void Execute_CFI_Routine(double now)
        {
            Cassette nextCst = _RC.NextCassette();
            if (nextCst != null)
            {
                _ReleasedCassettes.Add(nextCst);
                if (_FWK>0)
                    _FWK--;
                //System.Diagnostics.Trace.WriteLine("[FabIn@" + now + "] " + nextCst.ToString());

                nextCst.ReleaseDate = now;
                nextCst.C = "FabIn";
                nextCst.D = Factory.RTD.NextEQP(nextCst);
                nextCst.Route = MCS.Route(nextCst);
                nextCst.A = nextCst.Route[1].ID;
                string convid = nextCst.A;
                nextCst.ShiftRoute();
                nextCst.UpdatePlace(convid);

                //for debugging 3/22 김현식
                //System.Diagnostics.Debug.WriteLine("FabIn:\t" + now + "\t" + nextCst.ID + "\t" + nextCst.D);

                //ScheduleMirrorEvent("Conveyor", "EOC", now, convid, nextCst);
                ScheduleLocalEvent("Move", now, convid, nextCst);

                if (Factory.MasterData.StepKanbanStepList.Contains(nextCst.P))
                {
                    if (_TWK > 0)
                        _TWK--;
                }
            }

            updateBlockedState();

            if (!_KanbanBlocked)
                ScheduleLocalEvent("CFI", now);
        }

        private void Execute_CFO_Routine(double now, Cassette cst)
        {
            if (_FWK < _IFWK)
            {
                _FWK++;

                updateBlockedState();

                //updateTSW();
                //if (_FWK == 1 && _TWK > 0)
                //    _KanbanBlocked = false;
                //else
                //    _KanbanBlocked = true;

                if (!_KanbanBlocked && _GateOpened)
                    ScheduleLocalEvent("CFI", now);
            }
        }

        private void Execute_CA_Routine(double now)
        {
            //if (_TWK > 0)
                _TWK--;
            
            updateBlockedState();
        }

        private void Execute_CL_Routine(double now)
        {
            if (_TWK < _ITWK)
            {
                _TWK++;

                updateBlockedState();

                //if (_TWK == 1 && _FWK > 0)
                //{
                //    _KanbanBlocked = false;
                //}
                //else
                //{
                //    _KanbanBlocked = true;
                //}

                if (!_KanbanBlocked && _GateOpened)
                    ScheduleLocalEvent("CFI", now);
            }
        }

        private void Execute_Move_Routine(double now, string eqpid, Cassette cst)
        {
            cst.IsMoving = true;
            ScheduleMirrorEvent("Conveyor", "EOC", now, eqpid, cst);
        }
        
        public override void Initialize(Dictionary<string, object> args)
        {
            //Inter-release time (in seconds)
            _TG = (int)args[SimulationArguments.InterReleaseTime];
            if (_TG == int.MaxValue || _TG == 0)
                _GateOpened = true;
            else
                _GateOpened = false;

            //Kanban for Fab WIP
            _FWK = (int)args[SimulationArguments.KanbanFabWIP];
            _IFWK = _FWK;
            //Kanban for Step WIP
            _TWK = (int)args[SimulationArguments.KanbanStepWIP];
            _ITWK = _TWK;

            

            _RC = new ReleaseController(this.Factory);
            _RC.Initialize(args);
        }

        public override void Run()
        {
            /////////////////////////////
            //TODO: FabOut 에서 WIP 차감
            /////////////////////////////

            ScheduleLocalEvent("GO", 0);
        }

        public override void ExecuteLocalEvent(Engine.LocalEvent e)
        {
            if (e.ObjectName == "FabIn" && e.Name == "CFI" )
            {
                Execute_CFI_Routine(e.Time);
            }
            else if (e.ObjectName == "FabIn" && e.Name == "GO")
            {
                Execute_GO_Routine(e.Time);
            }
            else if (e.ObjectName == "FabIn" && e.Name == "Move")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)e;
                Execute_Move_Routine(fle.Time, fle.EQPID, fle.Cassette);
            }
            else if (e.ObjectName == "FabIn" && e.Name == "CFO")
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)e;
                Cassette cst = (Cassette)fle[0];
                Execute_CFO_Routine(e.Time, cst);
            }
            else if (e.ObjectName == "FabIn" && e.Name == "CL") //When a cassette arrives at the input port (X2PU, X2PC, X2PV, X2PI)
            {
                Execute_CL_Routine(e.Time);
            }
            else if (e.ObjectName == "FabIn" && e.Name == "CA") //When a cassette leaves the output port (PV2X, PC2X, PO2X, PU2X)
            {
                Execute_CA_Routine(e.Time);
            }
        }

        public override void FireSchedulingArc(VMS.IFS.Engine.ApplicationMessage msg)
        {
            //Do Nothing
        }
        #endregion

    }    
}
