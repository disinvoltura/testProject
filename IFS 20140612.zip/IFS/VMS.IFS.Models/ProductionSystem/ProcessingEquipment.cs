﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public abstract class ProcessingEquipment: FactoryObjectSimulator
    {
        #region Member Variables
        
        /// <summary>
        /// Number of Cassettes moving to an equipment (key: eqp id, value: number of cassettes moving to eqp id)
        /// </summary>
        protected Dictionary<string, int> _M;

        /// <summary>
        /// Lastly processed job's type
        /// </summary>
        protected Dictionary<string, string> _JT;

        /// <summary>
        /// In-ports
        /// </summary>
        protected Dictionary<string, Port> _P;

        /// <summary>
        /// Virtual Queue
        /// </summary>
        protected Dictionary<string, CassetteCollection> _VQ;

        /// <summary>
        /// Loadable Cassette List
        /// </summary>
        protected Dictionary<string, CassetteCollection> _LCL;

        /// <summary>
        /// Step Kanban Eqp LIst
        /// Key: EQP ID, value: true when it's for Step Kanban
        /// </summary>
        //protected Dictionary<string, bool> _StepKanbanEqpList;

        /// <summary>
        /// List of Cassettes which are under the processing in an equipment
        /// </summary>
        protected Dictionary<string, CassetteCollection> _InProcessingCassettes;

        /// <summary>
        /// Number of Processed Cassettes by the processing equipment
        /// </summary>
        protected Dictionary<string, int> _NPC;

        /// <summary>
        /// Number of Occurrence of Setup at the processing equipment
        /// </summary>
        protected Dictionary<string, int> _SC;

        #endregion

        #region Properties
        /// <summary>
        /// Number of Cassettes moving to an equipment 
        /// where key is the equipment id and value is number of cassettes
        /// </summary>
        public Dictionary<string, int> M
        {
            get { return _M; }
            set { _M = value; }
        }

        /// <summary>
        /// Lastly processed job's type for each equipment
        /// </summary>
        public Dictionary<string, string> JT
        {
            get { return _JT; }
            set { _JT = value; }
        }

        /// <summary>
        /// Ports of an Equipment
        /// </summary>
        public Dictionary<string, Port> P
        {
            get { return _P; }
            set { _P = value; }
        }

        /// <summary>
        /// Cassette Queue of an equipment
        /// </summary>
        public Dictionary<string, CassetteCollection> VirtualQueue
        {
            get { return _VQ; }
            set { _VQ = value; }
        }

        /// <summary>
        /// List of Cassettes that has not been designated to a equipment (kind of shared queue) 
        /// </summary>
        public Dictionary<string, CassetteCollection> LoadableCassetteList
        {
            get { return _LCL; }
            set { _LCL = value; }
        }

        /// <summary>
        /// List of Cassettes which are under the processing in an equipment
        /// </summary>
        public Dictionary<string, CassetteCollection> IPC
        {
            get { return _InProcessingCassettes; }
            set { _InProcessingCassettes = value; }
        }

        /// <summary>
        /// Number of Processed Cassettes by the Processing Equipment
        /// </summary>
        public Dictionary<string, int> NPC
        {
            get { return _NPC; }
        }

        /// <summary>
        /// Number of Setup Occurrences
        /// </summary>
        public Dictionary<string, int> SC
        {
            get { return _SC; }
        }
        #endregion

        #region Constructors
        public ProcessingEquipment(string name, FactoryObjectType type, Factory factory)
            : base(name, type, factory)
        {
            //_Q = new Dictionary<string, CassetteCollection>();
            _JT = new Dictionary<string, string>();
            _P = new Dictionary<string, Port>();
            _M = new Dictionary<string, int>();
            _VQ = new Dictionary<string, CassetteCollection>();
            _LCL = new Dictionary<string, CassetteCollection>();
            //_StepKanbanEqpList = new Dictionary<string, bool>();
            _InProcessingCassettes = new Dictionary<string, CassetteCollection>();
            _NPC = new Dictionary<string, int>();
            _SC = new Dictionary<string, int>();
        }
        #endregion

        #region Methods

        #endregion
    }
}
