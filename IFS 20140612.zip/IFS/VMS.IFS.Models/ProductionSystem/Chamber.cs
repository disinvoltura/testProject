﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{   
    public class Chamber : ProcessingEquipment
    {
        #region Member Variables
        /// <summary>
        /// Key: EQP ID, value: CassetteCollection (B[c])
        /// </summary>
        private Dictionary<string, CassetteCollection> _B;

        /// <summary>
        /// Number of idle processing chambers in a chamber-type equipment.
        /// Key is EQP ID and value is number of idle processing chambers
        /// </summary>
        private Dictionary<string, int> _CH;

        /// <summary>
        /// List of glasses at the input buffer of a chmaber-type equipment 
        /// </summary>
        private Dictionary<string, GlassCollection> _IQ;

        /// <summary>
        /// List of glasses at the output buffer of a chamber-type equipment
        /// </summary>
        private Dictionary<string, GlassCollection> _OQ;
        #endregion

        #region Properties
        public Dictionary<string, CassetteCollection> B
        {
            get { return _B; }
        }

        #endregion

        #region Constructors
        public Chamber(Factory factory)
            : base("Chamber", FactoryObjectType.Chamber, factory)
        {
            //_Q = new Dictionary<string, CassetteCollection>();
            _M = new Dictionary<string, int>();
            _B = new Dictionary<string, CassetteCollection>();
            _CH = new Dictionary<string, int>();
            _IQ = new Dictionary<string, GlassCollection>();
            _OQ = new Dictionary<string, GlassCollection>();
            _JT = new Dictionary<string, string>();
        }
        #endregion

        #region Event Routines
        private void Execute_X2PC_Routine(double now, string c, Cassette cst)
        {
            cst.UpdatePlace(c);

            _B[c].Enqueue(cst);
            loadGlasses(cst, c);
            _P[c].ChangePortState(PortState.RX, PortState.F);

            if (_CH[c] > 0)
            {
                _InProcessingCassettes[c].Enqueue(cst);
                ScheduleLocalEvent("GI", now, c);
            }

            if (Factory.MasterData.StepKanbanStepList.Contains(cst.P))
                ScheduleMirrorEvent("FabIn", "CL", now);
        }

        private void Execute_GI_Routine(double now, string c)
        {
            if (_IQ[c].Count == 0)
                return;
            Glass gls = _IQ[c].Dequeue();
            _CH[c]--;

            if (_IQ[c].Count % gls.N == 0)
            {
                _P[c].ChangePortState(PortState.F, PortState.E);
            }

            if (_CH[c] > 0 && _IQ[c].Count > 0)
                ScheduleLocalEvent("GI", now, c);

            if (gls.J == _JT[c])
                ScheduleLocalEvent("GP", now, c, gls);
            else
                ScheduleLocalEvent("SS", now, c, gls);
        }

        private void Execute_SS_Routine(double now, string c, Glass gls)
        {
            _SC[c]++;
            ScheduleLocalEvent("GP", now + MasterData.SetupTime[c], c, gls);
        }

        private void Execute_GP_Routine(double now, string c, Glass gls)
        {
            double t1 = MasterData.TactTime[gls.J, gls.P, c] +
                        MasterData.FlowTime[gls.J, gls.P, c];
            ScheduleLocalEvent("GO", now + t1, c, gls);
        }

        private void Execute_GO_Routine(double now, string c, Glass gls)
        {
            _CH[c]++;
            _OQ[c].Enqueue(gls);
            _JT[c] = gls.J;

            if (_OQ[c].Count >= gls.N)
            {
                Cassette cst = _B[c].Dequeue(gls.CID);

                bool C1 = unloadGlasses(cst, c);
                if (C1)
                    ScheduleLocalEvent("CD", now, c, cst);
            }

            if (_IQ[c].Count > 0)
                ScheduleLocalEvent("GI", now, c);
        }

        private void Execute_CD_Routine(double now, string c, Cassette cst)
        {
            _InProcessingCassettes[c].Dequeue(cst.ID);
            _NPC[c]++;

            cst.P = RTD.NextStep(cst);
            cst.D = RTD.NextEQP(cst);
            cst.Route = MCS.Route(cst);

            if (cst.Route.Count > 1)
            {
                cst.A = cst.Route[1].ID;
                cst.ShiftRoute();

                ScheduleMirrorEvent("InlineStocker", "Move", now, cst.A, c, cst);
            }

            if (Factory.MasterData.StepKanbanStepList.Contains(cst.P))
                ScheduleMirrorEvent("FabIn", "CA", now);
        }

        private void loadGlasses(Cassette cst, string c)
        {
            for (int i = 0; i < cst.N; i++)
            {
                Glass gls = new Glass(cst.ID, cst.J, cst.P, cst.N);
                _IQ[c].Enqueue(gls);
            }
        }

        private bool unloadGlasses(Cassette cst, string c)
        {
            List<Glass> sameIDG = new List<Glass>();
            foreach (Glass gls in _OQ[c].Glasses)
            {
                if (gls.CID == cst.ID)
                    sameIDG.Add(gls);
            }

            if (sameIDG.Count == cst.N)
            {
                foreach (Glass gls in sameIDG)
                    _OQ[c].Remove(gls);

                return true;
            }

            return false;
        }

        #endregion

        #region Methods
        public override void Run()
        {
            foreach (string eqpid in Factory.MasterData.EQP.Chambers)
            {
                if (_B[eqpid].Count > 0)
                {
                    ScheduleLocalEvent("GI", 0, eqpid);
                }

            }
        }

        public override void ExecuteLocalEvent(Engine.LocalEvent e)
        {
            if (e.ObjectName == this.Name)
            {
                FactoryLocalEvent fle = (FactoryLocalEvent)e;
                if (e.Name == "X2PC")
                {
                    Execute_X2PC_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
                else if (e.Name == "GI")
                {
                    Execute_GI_Routine(fle.Time, fle.EQPID);
                }
                else if (e.Name == "GP")
                {
                    Execute_GP_Routine(fle.Time, fle.EQPID, fle.Glass);
                }
                else if (e.Name == "SS")
                {
                    Execute_SS_Routine(fle.Time, fle.EQPID, fle.Glass);
                }
                else if (e.Name == "GO")
                {
                    Execute_GO_Routine(fle.Time, fle.EQPID, fle.Glass);
                }
                else if (e.Name == "CD")
                {
                    Execute_CD_Routine(fle.Time, fle.EQPID, fle.Cassette);
                }
            }
        }

        public override void Initialize(Dictionary<string, object> args)
        {
            //_Q = new Dictionary<string,CassetteCollection>();
            _M = new Dictionary<string, int>();
            _B = new Dictionary<string,CassetteCollection>();
            _P = new Dictionary<string,Port>();
            _CH = new Dictionary<string,int>();
            _IQ = new Dictionary<string,GlassCollection>();
            _OQ = new Dictionary<string,GlassCollection>();
            _JT = new Dictionary<string,string>();
            //_StepKanbanEqpList = new Dictionary<string, bool>();
            _InProcessingCassettes = new Dictionary<string, CassetteCollection>();
            _NPC = new Dictionary<string, int>();
            _SC = new Dictionary<string, int>();

            foreach (string eqpid in Factory.MasterData.EQP.Chambers)
            {
                //Port
                Port p = new Port(Factory.MasterData.EQPPort[eqpid].InOut);
                _P.Add(eqpid, p);

                //Port Queue
                _B.Add(eqpid, new CassetteCollection());
                _IQ.Add(eqpid, new GlassCollection());
                _OQ.Add(eqpid, new GlassCollection());
                if (MasterData.WIP.hasBWIP(eqpid))
                {
                    foreach (Cassette cst in MasterData.WIP[eqpid, "B"])
                    {
                        _B[eqpid].Enqueue(cst);
                        loadGlasses(cst, eqpid);
                        _P[eqpid].ChangePortState(PortState.X, PortState.F);
                    }
                }
                
                //Processing Chambers
                _CH.Add(eqpid, Factory.MasterData.EQP[eqpid].EQP_Num);

                //Virtual Queue
                int vqCapa = (int)args[SimulationArguments.VQCapacity];
                _VQ.Add(eqpid, new CassetteCollection(vqCapa));

                //Loadable Cassette List
                _LCL.Add(eqpid, new CassetteCollection());                

                //Job Type for last proceessed cassette
                _JT.Add(eqpid, string.Empty);

                //Number of cassettes moving to the equipment
                _M.Add(eqpid, 0);

                //Number of in-processing cassettes
                _InProcessingCassettes.Add(eqpid, new CassetteCollection());

                _NPC.Add(eqpid, 0);
                _SC.Add(eqpid, 0);
            }
        }

        public override void FireSchedulingArc(VMS.IFS.Engine.ApplicationMessage msg)
        {
            //Do Nothing
        }
        #endregion
    }
}
