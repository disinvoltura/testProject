﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public class ApplicationBiInlineCell : BiInlineCell 
    {
        #region Member Variables
      
        #endregion

        #region Properties
       

        #endregion

        #region Constructors
        public ApplicationBiInlineCell(Factory factory)
            : base(factory)
        {
            
        }
        #endregion

        #region Event Routines
        private string makeEmptyCassetteMessage(
            string eventName, double now, string b, int newCstID, int oldCstID)
        {
            //e.g. "Empty_Cst_LGL#M1#3_2#10# # “
            string msg = string.Empty;
            msg = string.Format("Empty_Cst_{0}#{1}#{2}_{3}#{4}# # ", eventName, b, newCstID, oldCstID, now);
            return msg;
        }

        protected override void Execute_CD_Routine(double now, string b, Cassette cst)
        {
            System.Diagnostics.Debug.WriteLine("Execute_CD_Routine(" + now + ", " + b + ", " + cst.ToString() + ")");

            _InProcessingCassettes[b].Dequeue(cst.ID);
            _NPC[b]++;

            _RO[b] = 1;
            _PO[b].ChangePortState(PortState.E, PortState.F);

            Cassette emptyCst = _EQ[b].Dequeue();
            string Emsg = makeEmptyCassetteMessage("bCDR", now, b, emptyCst.ID, cst.ID);
            //string Emsg = makeEmptCassetteMessage("CD", now, e, emptyCst.ID, cst.ID);
            Send_Msg(Emsg);

            bool C3 = false;
            if (_PO[b].E > 0)
            {
                if (_OQ[b].Count > 0)
                {
                    _RO[b] = -1; C3 = true;
                }
            }

            cst.P = RTD.NextStep(cst);
            cst.D = RTD.NextEQP(cst);
            cst.Route = MCS.Route(cst);

            if (cst.Route.Count > 1) //not necessary, just for safety
            {
                cst.A = cst.Route[1].ID;
                cst.ShiftRoute();
                //Schedule Next Event
                ScheduleMirrorEvent("InlineStocker", "Move", now, cst.A, b, cst);
            }

            if (C3)
                ScheduleLocalEvent("FGU", now, b);

            if (Factory.MasterData.StepKanbanStepList.Contains(cst.P))
                ScheduleMirrorEvent("FabIn", "CA", now);

            //System.Diagnostics.Debug.WriteLine("[Bi.CD] Cassette " + cst.ID + " is at CD event at " + now);
        }
        #endregion

        #region Methods
        
        #endregion
    }
}
