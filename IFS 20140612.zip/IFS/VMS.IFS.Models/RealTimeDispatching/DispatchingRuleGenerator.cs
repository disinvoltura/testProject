﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.DispatchingRuleData;

namespace VMS.IFS.Models
{
    public abstract class DispatchingRuleGenerator
    {
        public abstract string Code
        {
            get;
        }

        public abstract bool generateCode(DispatchingRuleDefinition drDef);

        public abstract DispatchingRule GetInstance(Dictionary<string, object> args);

    }
}
