﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.SimulationData;
using VMS.IFS.Models;

namespace VMS.IFS.Models
{
    public class MachineInfo
    {
        #region Member Variables
        private string _EQPID;
        private string _JT;
        private int _Q;
        private int _M;
        private int _N;
        private int _PC;
        private string _EQPType; //U, B, C, V
        private Factory _Factory;

        private int _NC;
        private int _SC;
        #endregion

        #region Properties
        public string ID {
            get { return _EQPID; }
        }

        /// <summary>
        /// job type of lastly processed cassette
        /// </summary>
        public string JT {
            get { return _JT; }
        }

        /// <summary>
        /// Number of cassettes at the machine's queue
        /// </summary>
        public int Q {
            get { return _Q; }
        }

        /// <summary>
        /// Number of cassettes moving to the machine
        /// </summary>
        public int M {
            get { return _M; }
        }

        /// <summary>
        /// Number of cassettes at the input port
        /// </summary>
        public int N {
            get { return _N; }
        }

        /// <summary>
        /// Number of constituent equipments 
        /// (e.g. number of processing chambers)
        /// </summary>
        public int PC
        {
            get { return _PC; }
        }

        /// <summary>
        /// Type of Processing Equipment
        /// </summary>
        public string Type
        {
            get { return _EQPType; }                
        }

        /// <summary>
        /// Number of Processed Cassettes by the machine
        /// </summary>
        public int NC
        {
            get { return _NC; }
        }

        /// <summary>
        /// Number of Occurence of Setup at the machine
        /// </summary>
        public int SC
        {
            get { return _SC; }
        }

        #endregion

        #region Constructors
        public MachineInfo(string eqpid, Factory factory)
        {
            _EQPID = eqpid;
            _Factory = factory;

            initialize();
        }
        #endregion

        #region Methods
        private void initialize()
        {
            EquipmentSpecification eqpSpec = _Factory.MasterData.EQP[_EQPID];
            EquipmentType eqpType = eqpSpec.EQP_Type;
            if (eqpType == EquipmentType.UniInlineCell)
            {
                UniInlineCell u = _Factory.UniInlineCell;
                //JT, Q, M, N
                _Q = u.VirtualQueue[_EQPID].Count + u.LoadableCassetteList[_EQPID].Count;
                _M = u.M[_EQPID];
                //_N = u.P[_EQPID].E + u.P[_EQPID].F;
                _N = u.P[_EQPID].F;
                _JT = u.JT[_EQPID];
                _EQPType = "U";
                _PC = eqpSpec.EQP_Num;
                _NC = u.NPC[_EQPID];
            }
            else if (eqpType == EquipmentType.BiInlineCell)
            {
                BiInlineCell b = _Factory.BiInlineCell;
                //JT, Q, M, N
                _Q = b.VirtualQueue[_EQPID].Count + b.LoadableCassetteList[_EQPID].Count;
                _M = b.M[_EQPID];
                _N = b.P[_EQPID].F;
                _JT = b.JT[_EQPID];
                _EQPType = "B";
                _PC = eqpSpec.EQP_Num;
                _NC = b.NPC[_EQPID];
            }
            else if (eqpType == EquipmentType.Chamber)
            {
                Chamber c = _Factory.Chamber;
                //JT, Q, M, N
                _Q = c.VirtualQueue[_EQPID].Count + c.LoadableCassetteList[_EQPID].Count;
                _M = c.M[_EQPID];
                _N = c.P[_EQPID].F;
                _JT = c.JT[_EQPID];
                _EQPType = "C";
                _PC = eqpSpec.EQP_Num;
                _NC = c.NPC[_EQPID];
            }
            else if (eqpType == EquipmentType.Oven)
            {
                Oven v = _Factory.Oven;
                //JT, Q, M, N
                _Q = v.VirtualQueue[_EQPID].Count + v.LoadableCassetteList[_EQPID].Count;
                _M = v.M[_EQPID];
                _N = v.P[_EQPID].F;
                _JT = v.JT[_EQPID];
                _EQPType = "V";
                _PC = eqpSpec.EQP_Num;
                _NC = v.NPC[_EQPID];
            }

            
        }
        #endregion
    }
}
