﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public abstract class JobSelectionRule : DispatchingRule
    {
        public JobSelectionRule(string name, Factory factory)
            : base(name, factory)
        {

        }
        public abstract Cassette NextCassette(string eqpid, CassetteCollection cstlist);
    }
}
