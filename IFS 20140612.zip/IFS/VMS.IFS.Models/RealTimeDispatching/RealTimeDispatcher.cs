﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel;
using VMS.IFS.DataModel.DispatchingRuleData;
using VMS.IFS.DataModel.SimulationData;
using VMS.Foundation.Logging;

namespace VMS.IFS.Models
{
    public class RealTimeDispatcher
    {
        #region Member Variables
        private Factory _Factory;
        private JobSelectionRule _JSR;
        private MachineSelectionRule _MSR;

        private Logger _LoggerMSR;
        private Logger _LoggerJSR;
        private bool _Loggable;
        #endregion

        #region Properties
        public Factory Factory
        {
            get { return _Factory; }
        }

        public JobSelectionRule JSR
        {
            get { return _JSR; }
            set { _JSR = value; }
        }

        public MachineSelectionRule MSR
        {
            get { return _MSR; }
            set { _MSR = value; }
        }
        #endregion

        #region Constructors
        public RealTimeDispatcher(Factory factory)
        {
            _Factory = factory;

            _LoggerJSR = LogManager.GetLogger("JobSelectionRule");
            _LoggerMSR = LogManager.GetLogger("MachineSelectionRule");
        }
        #endregion

        #region Methods
        public void Initialize(Dictionary<string, object> args)
        {
            //Job Selection Rule
            JobSelectionRuleGenerator jsrGen = new JobSelectionRuleGenerator(_Factory);
            _JSR = (JobSelectionRule)jsrGen.GetInstance(args);

            //Machine Selection Rule
            MachineSelectionRuleGenerator msrGen = new MachineSelectionRuleGenerator(_Factory);
            _MSR = (MachineSelectionRule)msrGen.GetInstance(args);

            _Loggable = (bool)args[SimulationArguments.Logging];

        }

        public string NextStep(Cassette cst)
        {
            string lastStepID = _Factory.MasterData.BOP.GetLastStepID(cst.J);
            if (cst.P == lastStepID)
            {
                return "FabOut";
            }
            
            string nextStepID = _Factory.MasterData.BOP[cst.J, cst.P];
            return nextStepID;
        }

        /// <summary>
        /// Machine Selection 
        /// </summary>
        /// <param name="cst"></param>
        /// <returns></returns>
        public string NextEQP(Cassette cst)
        {
            if (_Loggable)
                _LoggerMSR.Debug("NextEQP (" + cst.ID + ", " + cst.J + ", " + cst.P + ", " + cst.D+")");

            string rslt = string.Empty;

            if (cst.P == "FabOut")
                return "FabOut";

            string eqpid = _MSR.NextEQP(cst);

            ProcessingEquipment eqp = (ProcessingEquipment)Factory[eqpid];
            if (eqp.P[eqpid].X > 0)
            {
                eqp.P[eqpid].ChangePortState(PortState.X, PortState.RX);
                eqp.M[eqpid] = eqp.M[eqpid] + 1;//Moving to the EQP
                rslt = eqpid;
            }
            else
            {
                if (eqp.VirtualQueue[eqpid].IsFull())
                {
                    enQueueLoadableCassette(cst);

                    FactoryObjectSimulator curEQP = Factory[cst.C];
                    if (cst.C == "FabIn")
                    {
                        rslt = getLoadableStocker(cst);
                    }else if (curEQP.Type == FactoryObjectType.Stocker)
                        rslt = cst.C;
                    else {
                        string stkid = searchWhereNextStk(cst);
                        if (string.IsNullOrEmpty(stkid))
                            rslt = cst.C;
                        else
                            rslt = stkid;
                    }
                }
                else
                {
                    eqp.VirtualQueue[eqpid].Enqueue(cst);

                    string stkid = Factory.MasterData.EQPPort[eqpid].InStkID;
                    rslt = stkid;
                }
            }

            if (_Loggable)
            {
                _LoggerMSR.Debug("=> JSR: EQPID = " + eqpid);
                _LoggerMSR.Debug("=> Destination = " + rslt);
            }

            return rslt;
        }

        /// <summary>
        /// En-queue a cassette to the loadable cassette queues of loadable machines
        /// </summary>
        /// <param name="cst">Cassette</param>
        private void enQueueLoadableCassette(Cassette cst)
        {
            string[] loadableEqpList = Factory.MasterData.Loadable[cst.J, cst.P];
            foreach (string loadableEqpID in loadableEqpList)
            {
                ProcessingEquipment loadableEqp = (ProcessingEquipment)Factory[loadableEqpID];
                loadableEqp.LoadableCassetteList[loadableEqpID].Enqueue(cst);
            }
        }

        /// <summary>
        /// Returns an inline stocker id where the loadable machines are located for a given cassette (cst)
        /// </summary>
        /// <param name="cst"></param>
        /// <returns></returns>
        private string getLoadableStocker(Cassette cst)
        {
            string rslt = "";
            string[] loadableEqpList = Factory.MasterData.Loadable[cst.J, cst.P];
            foreach (string loadableEqpID in loadableEqpList)
            {
                rslt = Factory.MasterData.EQPPort[loadableEqpID].InStkID;
                break;
            }

            return rslt;
        }
        
        /// <summary>
        /// De-queue a cassette from the loadable casseete queues of its loadable machines
        /// </summary>
        /// <param name="cst"></param>
        private void deQueueLoadableCassette(Cassette cst)
        {
            string[] loadableEqpList = Factory.MasterData.Loadable[cst.J, cst.P];
            foreach (string loadableEqpID in loadableEqpList)
            {
                ProcessingEquipment loadableEqp = (ProcessingEquipment)Factory[loadableEqpID];
                loadableEqp.LoadableCassetteList[loadableEqpID].Dequeue(cst.ID);
            }
        }

        /// <summary>
        /// Search a stocker where the cassette has to be moved.
        /// The stocker whose WIP level is less than its buffer capacity is selected.
        /// </summary>
        /// <param name="cst">Cassette</param>
        /// <returns></returns>
        private string searchWhereNextStk(Cassette cst)
        {
            string rslt = string.Empty;
            List<string> nextStkList = Factory.MasterData.WhereNextSTK[cst.C];
            foreach (string stkid in nextStkList)
            {
                int wip = Factory.Stocker.WIP[stkid];
                int capa = Factory.MasterData.Stocker[stkid].BufferCapacity;
                if (wip < capa)
                {
                    rslt = stkid;
                    break;
                }
            }
            if (string.IsNullOrEmpty(rslt))
            {
                rslt = nextStkList[0];//TODO
            }

            return rslt;
        }

        /// <summary>
        /// Job Selection
        /// </summary>
        /// <param name="eqpid"></param>
        /// <returns></returns>
        public Cassette NextCassette(string eqpid)
        {
            Cassette nextCst = null;

            ProcessingEquipment eqp = (ProcessingEquipment)Factory[eqpid];
            
            if (eqp.VirtualQueue[eqpid].Count > 0)
            {
                //Virtual Queue 에서 이동 중이지 않는 Cassette 들 중에서 선택
                //- Job Selection Rule 내에서 적용됨 
                //- JobSelectionRuleGenerator 내에서 cassette.IsMoving 인 경우 필터링
                nextCst = NextCassetteFromCassettes(eqpid, eqp.VirtualQueue[eqpid]);
                if (nextCst != null)
                {
                    eqp.VirtualQueue[eqpid].Dequeue(nextCst.ID);

                    //added by D. Kang 2014/03/23
                    if (eqp.LoadableCassetteList[eqpid].Count > 0)
                    {
                        Cassette cst = eqp.LoadableCassetteList[eqpid].Peek();
                        deQueueLoadableCassette(cst);
                        eqp.VirtualQueue[eqpid].Enqueue(cst);
                    }

                    
                    
                }
            }

            if (nextCst == null && eqp.LoadableCassetteList[eqpid].Count > 0)
            {
                nextCst = NextCassetteFromCassettes(eqpid, eqp.LoadableCassetteList[eqpid]);
                if (nextCst != null)
                {
                    deQueueLoadableCassette(nextCst);
                }
            }

            //added by D. Kang 2014/03/28
            if (nextCst != null)
            {
                ProcessingEquipment pe = (ProcessingEquipment)Factory[eqpid];
                pe.M[eqpid] = pe.M[eqpid] + 1;
            }
            return nextCst;
        }


        /// <summary>
        /// 명시된 CassetteCollection (cstlist) 에 소속된 Cassette 들 중에서 명시된 설비 (eqpid)에서 처리할 cassette 를 Job Selection Rule 을 사용하여 선정하여 반환한다
        /// </summary>
        /// <param name="eqpid">Equipment ID</param>
        /// <param name="cstlist">Cassettes</param>
        /// <returns></returns>
        private Cassette NextCassetteFromCassettes(string eqpid, CassetteCollection cstlist)
        {
            Cassette nextCassette = null;

            if (_Loggable)
            {
                _LoggerJSR.Debug("NextCassette (" + eqpid + ")");
                _LoggerJSR.Debug("- Candidate Cassettes: ");

                int count = 1;
                foreach (Cassette cst in cstlist.Cassettes)
                {
                    _LoggerJSR.Debug("  [" + count + "] " + cst.ID + "," + cst.J + "," + cst.P + ")");
                    count++;
                }
            }
           
            nextCassette = _JSR.NextCassette(eqpid, cstlist);

            if (_Loggable)
            {
                if (nextCassette != null)
                    _LoggerJSR.Debug("- next cassette: " + nextCassette.ID);
                else
                    _LoggerJSR.Debug("- next cassette: none");
            }

            

            return nextCassette;
        }

        /// <summary>
        /// returns a stocker id where the cassette will be moved (WhereNextSTK)
        /// </summary>
        /// <param name="eqpid"></param>
        /// <returns></returns>
        public string SelectNextSTK(string eqpid)
        {
            List<string> stklist = 
                Factory.MasterData.WhereNextSTK[eqpid];

            string rslt = "";
            foreach (string stkid in stklist)
            {
                int wip = Factory.Stocker.WIP[stkid];
                int capa = Factory.MasterData.Stocker[stkid].BufferCapacity;
                
                if (wip < capa)
                {
                    rslt = stkid;
                    break;
                }
            }
            return rslt;
        }

        #endregion
    }
}
