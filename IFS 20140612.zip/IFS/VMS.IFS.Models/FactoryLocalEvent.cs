﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.Engine;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.Models
{
    public class FactoryLocalEvent : LocalEvent
    {
        #region Member Variables
        private List<object> _Parameters;
        //private string _EQPID;
        //private Cassette _CST;
        //private Glass _GLS;
        #endregion 

        #region Properties
        public object this[int idx]
        {
            get
            {
                object rslt = null;
                if (_Parameters != null && idx < _Parameters.Count)
                {
                    rslt = _Parameters[idx];
                }
                return rslt;
            }
        }
        public string EQPID
        {
            get
            {
                return (string)_Parameters[0];
            }
        }

        public Cassette Cassette
        {
            get { return (Cassette)_Parameters[1]; }
        }

        public Glass Glass
        {
            get { return (Glass)_Parameters[1]; }
        }
        #endregion

        #region Constructors
        public FactoryLocalEvent(string objectName, string eventName, double eventTime)
            : base(objectName, eventName, eventTime)
        {
            _Parameters = new List<object>();
            //_EQPID = eqpid;
        }

        public FactoryLocalEvent(string objectName, string eventName, double eventTime, int priority)
            : base(objectName, eventName, eventTime, priority)
        {
            _Parameters = new List<object>();
        }

        public FactoryLocalEvent(string objectName, string eventName, double eventTime, string eqpid)
            : base(objectName, eventName, eventTime)
        {
            _Parameters = new List<object>();
            _Parameters.Add(eqpid);
            //_EQPID = eqpid;
        }

        public FactoryLocalEvent(string objectName, string eventName, double eventTime, string eqpid, Cassette cst)
            : base(objectName, eventName, eventTime)
        {
            _Parameters = new List<object>();
            _Parameters.Add(eqpid);
            _Parameters.Add(cst);
            //_EQPID = eqpid;
            //_CST = cst;
        }

        public FactoryLocalEvent(string objectName, string eventName, double eventTime, string eqpid, Glass gls)
            : base(objectName, eventName, eventTime)
        {
            _Parameters = new List<object>();
            _Parameters.Add(eqpid);
            _Parameters.Add(gls);
            //_EQPID = eqpid;
            //_GLS = gls;
        }
        #endregion

        #region Methods
        public void AddParameter(object parameter)
        {
            _Parameters.Add(parameter);
        }
        #endregion
    }

    /*
    public class FactoryLocalEvent : LocalEvent
    {
        #region Member Variables
        private string _EQPID;
        private Cassette _CST;
        private Glass _GLS;
        #endregion

        #region Properties
        public string EQPID
        {
            get
            {
                return _EQPID;
            }
        }

        public Cassette Cassette
        {
            get { return _CST; }
        }

        public Glass Glass
        {
            get { return _GLS; }
        }
        #endregion

        #region Constructors
        public FactoryLocalEvent(string objectName, string eventName, double eventTime, string eqpid)
            : base(objectName, eventName, eventTime)
        {
            _EQPID = eqpid;
        }

        public FactoryLocalEvent(string objectName, string eventName, double eventTime, string eqpid, Cassette cst)
            : base(objectName, eventName, eventTime)
        {
            _EQPID = eqpid;
            _CST = cst;
        }

        public FactoryLocalEvent(string objectName, string eventName, double eventTime, string eqpid, Glass gls)
            : base(objectName, eventName, eventTime)
        {
            _EQPID = eqpid;
            _GLS = gls;
        }
        #endregion
    }*/
}

