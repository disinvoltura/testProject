﻿namespace VMS.IFS.DataModel.InputData {
    
    
    public partial class InputDataSet {
        partial class EquipmentDataTableDataTable
        {
        }
    }
}
