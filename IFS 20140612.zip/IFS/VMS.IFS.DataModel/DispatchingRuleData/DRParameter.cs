﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.DataModel.DispatchingRuleData
{
    public enum DRParameterType { Integer, Double, Float, String };
    public class DRParameter
    {
        #region Member Variables
        private string _Name;
        private DRParameterType _Type;
        private string _Desc;

        #endregion

        #region Properties
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        public DRParameterType Type
        {
            get { return _Type; }
            set { _Type = value; }
        }
        public string Description
        {
            get { return _Desc; }
            set { _Desc = value; }
        }
        #endregion

        #region Constructors
        public DRParameter(string name, DRParameterType type, string desc)
        {
            _Name = name;
            _Type = type;
            _Desc = desc;
        }
        #endregion

        #region Methods

        #endregion
    }

}
