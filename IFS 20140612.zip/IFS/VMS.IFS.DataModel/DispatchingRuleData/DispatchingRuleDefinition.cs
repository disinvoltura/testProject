﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.DataModel.DispatchingRuleData
{
    public enum DispatchingRuleType { JobSelectionRule, MachineSelectionRule};
    public enum SelectionCriteriaType { Minimum, Maximum };
    public class DispatchingRuleDefinition
    {
        #region Member Variables
        private string _Name;
        private DispatchingRuleType _Type;
        private string _Desc;
        private Dictionary<string, DRParameter> _Parameters;
        private Dictionary<string, DRFactor> _Factors;
        private string _PriorityFunction;
        private SelectionCriteriaType _SelectionOrder;
        #endregion

        #region Properties
        public string Name
        {
            get { return _Name; }
            set { _Name = value;}
        }

        public DispatchingRuleType Type
        {
            get { return _Type; }
            set { _Type = value; }
        }

        public string Description
        {
            get { return _Desc; }
            set { _Desc = value; }
        }

        public IEnumerable<DRParameter> Parameters
        {
            get { return _Parameters.Values; }
        }

        public IEnumerable<DRFactor> Factors
        {
            get { return _Factors.Values; }
        }

        public string PriorityFunction
        {
            get { return _PriorityFunction; }
            set { _PriorityFunction = value; }
        }

        public SelectionCriteriaType SelectionOrder
        {
            get { return _SelectionOrder; }
            set { _SelectionOrder = value; }
        }

        #endregion

        #region Constructors
        public DispatchingRuleDefinition(string name, DispatchingRuleType type)
        {
            _Name = name;
            _Type = type;
            _Parameters = new Dictionary<string, DRParameter>();
            _Factors = new Dictionary<string, DRFactor>();
        }
        #endregion

        #region Methods
        public void AddParameter(string name, DRParameterType type, string desc)
        {
            DRParameter p = new DRParameter(name, type, desc);
        
            if (!_Parameters.ContainsKey(name))   
                _Parameters.Add(name, p);
        }

        public void AddFactor(string name, string desc, string expr)
        {
            DRFactor f = new DRFactor(name, desc, expr);
            
            if (!_Factors.ContainsKey(name))
                _Factors.Add(name, f);
        }

        public void RemoveParameter(string name)
        {
            if (_Parameters.ContainsKey(name))
                _Parameters.Remove(name);
        }

        public void RemoveFactor(string name)
        {
            if (_Factors.ContainsKey(name))
                _Factors.Remove(name);
        }

        public override string ToString()
        {
            return _Name;
        }
        #endregion
    }   
}
