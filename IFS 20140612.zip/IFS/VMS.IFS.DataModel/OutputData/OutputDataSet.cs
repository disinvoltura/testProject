﻿namespace VMS.IFS.DataModel.OutputData {
    
    
    public partial class OutputDataSet {
        partial class STKUtilizationDataTableDataTable
        {
}
    
        partial class ReleaseBatchDataTableDataTable
        {
        }
    
        partial class DueDateSatisfactionDataTableDataTable
        {
        }

        partial class ProductTATDataTableDataTable
        {
        }
    }
}
