﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.DataModel.SimulationData
{
    public class MasterData
    {
        #region Member Variables
        private Dictionary<string, MasterDataObject> _DataObjects;
        private DateTime _ReferenceStartDate;
        #endregion

        #region Properties
        public DateTime ReferenceStartDate
        {
            get { return _ReferenceStartDate; }
        }
        public LoadableEQPData Loadable
        {
            get { return (LoadableEQPData)_DataObjects["Loadable"]; }
        }
        public FlowTimeData FlowTime
        {
            get { return (FlowTimeData)_DataObjects["FlowTime"]; }
        }
        public RetrievalTimeData RetrievalTime
        {
            get { return (RetrievalTimeData)_DataObjects["RetrievalTime"]; }
        }
        public DeliveryTimeData DeliveryTime
        {
            get { return (DeliveryTimeData)_DataObjects["DeliveryTime"]; }
        }
        public ConveyTimeData ConveyTime
        {
            get { return (ConveyTimeData)_DataObjects["ConveyTime"]; }
        }
        public TactTimeData TactTime
        {
            get { return (TactTimeData)_DataObjects["TactTime"]; }
        }
        public SetupTimeData SetupTime
        {
            get { return (SetupTimeData)_DataObjects["SetupTime"]; }
        }
        public EquipmentData EQP
        {
            get { return (EquipmentData)_DataObjects["EQP"]; }
        }
        public ProductData Product
        {
            get { return (ProductData)_DataObjects["Product"]; }
        }
        public BOPData BOP
        {
            get { return (BOPData)_DataObjects["BOP"]; }
        }
        public ReleaseBatchData ReleaseBatch
        {
            get { return (ReleaseBatchData)_DataObjects["ReleaseBatch"]; }
        }
        public EQPPortData EQPPort
        {
            get { return (EQPPortData)_DataObjects["EQPPort"]; }
        }
        public WIPData WIP
        {
            get { return (WIPData)_DataObjects["WIP"]; }
        }
        public FabOutPlanData FabOutPlan
        {
            get { return (FabOutPlanData)_DataObjects["FabOutPlan"]; }
        }
        public RouteData Route
        {
            get { return (RouteData)_DataObjects["Route"]; }
        }
        public ConveyorData Conveyor
        {
            get { return (ConveyorData)_DataObjects["Conveyor"]; }
        }
        public StockerData Stocker
        {
            get { return (StockerData)_DataObjects["Stocker"]; }
        }
        public NetworkData Network
        {
            get { return (NetworkData)_DataObjects["Network"]; }
        }
        public WhereNextStockerData WhereNextSTK
        {
            get { return (WhereNextStockerData)_DataObjects["WhereNextSTK"]; }
        }
        #endregion

        #region Constructors
        public MasterData()
        {
            _DataObjects = new Dictionary<string, MasterDataObject>();

            LoadableEQPData loadable = new LoadableEQPData();
            FlowTimeData flowTime = new FlowTimeData();
            SetupTimeData setupTime = new SetupTimeData();
            RetrievalTimeData retrievalTime = new RetrievalTimeData();
            DeliveryTimeData deliveryTime = new DeliveryTimeData();
            ConveyTimeData conveyTime = new ConveyTimeData();
            TactTimeData tactTime = new TactTimeData();
            EquipmentData eqp = new EquipmentData();
            ProductData product = new ProductData();
            BOPData bop = new BOPData();
            ReleaseBatchData rb = new ReleaseBatchData();
            EQPPortData port = new EQPPortData();
            WIPData wip = new WIPData();
            FabOutPlanData fabOutPlan = new FabOutPlanData();
            NetworkData network = new NetworkData();
            ConveyorData conveyor = new ConveyorData();
            StockerData stocker = new StockerData();
            WhereNextStockerData whereNextSTK = new WhereNextStockerData();
            RouteData route = new RouteData();

            _DataObjects.Add("Loadable", loadable);
            _DataObjects.Add("FlowTime", flowTime);
            _DataObjects.Add("SetupTime", setupTime);
            _DataObjects.Add("RetrievalTime", retrievalTime);
            _DataObjects.Add("DeliveryTime", deliveryTime);
            _DataObjects.Add("ConveyTime", conveyTime);
            _DataObjects.Add("TactTime", tactTime);
            _DataObjects.Add("EQP", eqp);
            _DataObjects.Add("Product", product);
            _DataObjects.Add("BOP", bop);
            _DataObjects.Add("ReleaseBatch", rb);
            _DataObjects.Add("EQPPort", port);
            _DataObjects.Add("WIP", wip);
            _DataObjects.Add("FabOutPlan", fabOutPlan);
            _DataObjects.Add("Route", route);
            _DataObjects.Add("Network", network);
            _DataObjects.Add("Conveyor", conveyor);
            _DataObjects.Add("Stocker", stocker);
            _DataObjects.Add("WhereNextSTK", whereNextSTK);
        }
        #endregion

        private List<string> _StepKanbanStepList;

        public List<string> StepKanbanStepList
        {
            get { return _StepKanbanStepList; }
        }

        public void Initialize(InputData.InputDataSet ds, Dictionary<string, object> args)
        {
            _ReferenceStartDate = (DateTime) args[SimulationArguments.ReferenceDateTime];

            List<string> AMHSDataList = new List<string>() { "Route", "Network", "Conveyor", "Stocker", "WhereNextSTK", "ConveyTime", "RetrievalTime", "DeliveryTime" };

            foreach (string key in _DataObjects.Keys)
            {
                if (AMHSDataList.Contains(key))
                    continue;

                MasterDataObject obj = _DataObjects[key];
                obj.Build(ds, args);
            }

            addFabInFabOutEqps(ds);

            foreach (string key in AMHSDataList)
            {
                MasterDataObject obj = _DataObjects[key];
                obj.Build(ds, args);
            }

            _StepKanbanStepList = new List<string>() { args[SimulationArguments.KanbanStepID].ToString() };
        }

        private void addFabInFabOutEqps(InputData.InputDataSet ds)
        {
            System.Data.DataRow[] rows = ds.InlineStockerDataTable.Select("STK_ID = 'FabIn'");

            if (rows == null || rows.Length == 0)
            {
                //FabIn Stocker
                InputData.InputDataSet.InlineStockerDataTableRow rowFabInStk =
                            ds.InlineStockerDataTable.NewInlineStockerDataTableRow();

                rowFabInStk.STK_ID = "FabIn";
                rowFabInStk.STK_TYPE = "FabIn";
                rowFabInStk.STK_BUFFER = "0";
                rowFabInStk.RETRIEVAL_TIME = "0";
                rowFabInStk.DELIVERY_TIME = "0";
                ds.InlineStockerDataTable.Rows.Add(rowFabInStk);

                //FabOut Stocker
                InputData.InputDataSet.InlineStockerDataTableRow rowFabOutStk =
                            ds.InlineStockerDataTable.NewInlineStockerDataTableRow();

                rowFabOutStk.STK_ID = "FabOut";
                rowFabOutStk.STK_TYPE = "FabOut";
                rowFabOutStk.STK_BUFFER = "0";
                rowFabOutStk.RETRIEVAL_TIME = "0";
                rowFabOutStk.DELIVERY_TIME = "0";
                ds.InlineStockerDataTable.Rows.Add(rowFabOutStk);

                //Conveyors
                List<string> fabInConveyors = new List<string>();
                List<string> fabOutconveyors = new List<string>();
                foreach (string productid in Product.Products)
                {
                    string firstStepID = BOP.GetFirstStepID(productid);
                    string[] loadableSet = Loadable[productid, firstStepID];

                    foreach (string eqpid in loadableSet)
                    {
                        string stkid = EQPPort[eqpid].InStkID;

                        string convid = "FabIn_" + stkid;
                        if (fabInConveyors.Contains(convid))
                            continue;

                        fabInConveyors.Add(convid);

                        InputData.InputDataSet.ConveyorDataTableRow rowConv =
                            ds.ConveyorDataTable.NewConveyorDataTableRow();

                        rowConv.CONV_ID = convid;
                        rowConv.CONV_TYPE = "ACC";
                        rowConv.FROM_STK = "FabIn";
                        rowConv.TO_STK = stkid;
                        rowConv.CONV_BUFFER = "1000000";//infinite
                        rowConv.CONV_TIME = "0";//infinite
                        ds.ConveyorDataTable.Rows.Add(rowConv);
                    }

                    string lastStepID = BOP.GetLastStepID(productid);
                    loadableSet = Loadable[productid, lastStepID];

                    foreach (string eqpid in loadableSet)
                    {
                        string stkid = EQPPort[eqpid].OutStkID;

                        string convid = stkid + "_FabOut";
                        if (fabOutconveyors.Contains(convid))
                            continue;

                        fabOutconveyors.Add(convid);

                        InputData.InputDataSet.ConveyorDataTableRow rowConv =
                            ds.ConveyorDataTable.NewConveyorDataTableRow();

                        rowConv.CONV_ID = convid;
                        rowConv.CONV_TYPE = "ACC";
                        rowConv.FROM_STK = stkid;
                        rowConv.TO_STK = "FabOut";
                        rowConv.CONV_BUFFER = "1000000";//infinite
                        rowConv.CONV_TIME = "0";//infinite
                        ds.ConveyorDataTable.Rows.Add(rowConv);
                    }
                }
            }
        }

        public void Clear()
        {
            foreach (string key in _DataObjects.Keys)
            {
                MasterDataObject mdo = _DataObjects[key];

                mdo.Clear();
            }
        }
    }
}
