﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.Foundation.Logging;

namespace VMS.IFS.DataModel.SimulationData
{
    public class SetupTimeData : MasterDataObject
    {
        #region Member Variables
        /// <summary>
        /// the key of Data is EQPID and value is setup time 
        /// </summary>
        private Dictionary<string, double> _Data;
        private Logger _Logger;
        #endregion

        #region Properties
        public double this[string eqpid]
        {
            get { return this.Query(eqpid); }
        }
        #endregion

        #region Constructors
        public SetupTimeData()
        {
            _Data = new Dictionary<string, double>();

            _Logger = LogManager.GetLogger("SimulationData");
        }
        #endregion

        #region Methods
        public override void Clear()
        {
            _Data.Clear();
        }

        public double Query(string eqpid)
        {
            double rslt = double.MinValue;
            if (_Data.ContainsKey(eqpid))
                rslt = _Data[eqpid];
            else
            {
                rslt = 0;
                //ERROR
                _Logger.Error("Cannot find any setup time data for " + eqpid);
            }
            return rslt;
        }

        public override void Build(InputDataSet ds, Dictionary<string, object> args)
        {
            _Logger.Info("Start of Building SetupTime Data");

            for (int i = 0; i < ds.EquipmentDataTable.Count; i++)
            {
                InputDataSet.EquipmentDataTableRow row = ds.EquipmentDataTable[i];

                if (row.IsEQP_IDNull() || row.IsSETUP_TIMENull())
                {
                    _Logger.Error("Invalid SetupTime Data Entry: at least one of fields is null at a row " + i);
                    continue;
                }

                if (!_Data.ContainsKey(row.EQP_ID))
                {
                    double rslt = 0;
                    double.TryParse(row.SETUP_TIME, out rslt);
                    _Data.Add(row.EQP_ID, rslt);
                }
            }

            _Logger.Info("End of Building SetupTime Data");
        }
        #endregion

    }
}
