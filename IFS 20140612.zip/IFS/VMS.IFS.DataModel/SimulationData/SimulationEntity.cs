﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.DataModel.SimulationData
{
    public class SimulationEntity
    {
        #region Member Variables
        private static int _Count;

        private int _ID;
        #endregion

        #region Properties
        public int ID
        {
            get { return _ID; }
        }
        #endregion

        #region Constructors
        public SimulationEntity()
        {
            _ID = ++_Count;
        }
        #endregion

        #region Methods
        public override bool Equals(object obj)
        {
            bool rslt = false;

            if (obj is SimulationEntity)
            {
                SimulationEntity target = (SimulationEntity)obj;

                if (target.ID == this.ID)
                    rslt = true;                    
            }

            return rslt;
        }

        public static void Initialize()
        {
            _Count = 0;
        }
        #endregion
    }
}
