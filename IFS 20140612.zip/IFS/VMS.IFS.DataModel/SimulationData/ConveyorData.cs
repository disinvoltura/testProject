﻿using System;
using System.Collections.Generic;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.Foundation.Logging;

namespace VMS.IFS.DataModel.SimulationData
{
    public class ConveyorData : MasterDataObject
    {
        #region Member Variables
        private Dictionary<string, ConveyorSpecification> _Data;
        private Logger _Logger;
        #endregion

        #region Properties
        /// <summary>
        /// ID List of Conveyors
        /// </summary>
        public IEnumerable<string> Keys
        {
            get { return _Data.Keys; }
        }

        /// <summary>
        /// Returns a conveyor specification whose id is same as a given conveyor id (convid)
        /// </summary>
        /// <param name="convid"></param>
        /// <returns></returns>
        public ConveyorSpecification this[string convid]
        {
            get
            {
                return Query(convid);
            }
        }
        #endregion

        #region Constructors
        public ConveyorData()
        {
            _Data = new Dictionary<string, ConveyorSpecification>();

            _Logger = LogManager.GetLogger("SimulationData");
        }
        #endregion

        #region Methods
        public override void Clear()
        {
            _Data.Clear();
        }

        /// <summary>
        /// Returns a conveyor specification whose id is same as a given conveyor id (convid)
        /// </summary>
        /// <param name="convid"></param>
        /// <returns></returns>
        public ConveyorSpecification Query(string convid)
        {
            ConveyorSpecification rslt = null;
            if (_Data.ContainsKey(convid))
                rslt = _Data[convid];

            return rslt;
        }

        /// <summary>
        /// Determines whether the conveyor specification of a given id (convid) exists in the data
        /// </summary>
        /// <param name="convid"></param>
        /// <returns></returns>
        public bool Contains(string convid)
        {
            return _Data.ContainsKey(convid);
        }

        public override void Build(InputData.InputDataSet ds, Dictionary<string, object> args)
        {
            _Logger.Info("Start of Building Conveyor Data");

            for (int i = 0; i < ds.ConveyorDataTable.Count; i++)
            {
                InputDataSet.ConveyorDataTableRow row = ds.ConveyorDataTable[i];

                if (row.IsCONV_IDNull() || row.IsCONV_TYPENull() || row.IsFROM_STKNull() || row.IsTO_STKNull() || row.IsCONV_BUFFERNull() || row.IsCONV_TIMENull())
                {
                    _Logger.Warning("Invalid Conveyor Data Entry: null at a row " + i);
                    continue;
                }

                ConveyorSpecification conv = new ConveyorSpecification();
                conv.ConveyorID = row.CONV_ID;
                conv.Type = row.CONV_TYPE.ToLower().Equals("acc") ? ConveyorType.Accumulating : ConveyorType.LinearMotoVehicle;
                conv.FromSTKID = row.FROM_STK;
                conv.ToSTKID = row.TO_STK;
                if (!double.TryParse(row.CONV_TIME, out conv.ConveyTime))
                    conv.ConveyTime = 0;
                if (!int.TryParse(row.CONV_BUFFER, out conv.BufferCapacity))
                    conv.BufferCapacity = int.MaxValue;

                _Data.Add(row.CONV_ID, conv);
            }
            _Logger.Info("End of Building Conveyor Data");
        }
        #endregion
    }

    public enum ConveyorType { Accumulating, LinearMotoVehicle};

    public class ConveyorSpecification
    {
        public string ConveyorID;
        public ConveyorType Type;
        public string FromSTKID;
        public string ToSTKID;
        public double ConveyTime;
        public int BufferCapacity;
    }
}
