﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.Foundation.Logging;


namespace VMS.IFS.DataModel.SimulationData
{
    public class WIPData : MasterDataObject
    {
        #region Member Variables

        private Dictionary<string, List<Cassette>> _QWIPData;
        private Dictionary<string, List<Cassette>> _BWIPData;
        private List<Cassette> _FOData;

        #endregion        

        #region Properties
        public Dictionary<string, List<Cassette>> QueueWIP
        {
            get { return _QWIPData; }
        }

        public Dictionary<string, List<Cassette>> BufferWIP
        {
            get { return _BWIPData; }
        }

        public List<Cassette> FabOutWIP
        {
            get { return _FOData; }
        }

        public List<Cassette> this[string eqpid, string queuename]
        {
            get
            {
                if (queuename == "Q")
                {
                    if (_QWIPData.ContainsKey(eqpid))
                    {
                        return _QWIPData[eqpid];
                    }
                    else
                    {
                        return new List<Cassette>();
                    }
                }
                else if (queuename == "B")
                {
                    if (_BWIPData.ContainsKey(eqpid))
                    {
                        return _BWIPData[eqpid];
                    }
                    else
                    {
                        return new List<Cassette>();
                    }                    
                }
                else
                {
                    return new List<Cassette>();
                }
            }
        }

        #endregion

        #region Constructor

        public WIPData()
        {
            _QWIPData = new Dictionary<string, List<Cassette>>();
            _BWIPData = new Dictionary<string, List<Cassette>>();
            _FOData = new List<Cassette>();
        }

        #endregion

        #region Method

        public override void Build(InputDataSet ds, Dictionary<string, object> args)
        {
            foreach (InputDataSet.WIPDataTableRow dr in ds.WIPDataTable.Rows)
            {
                string eqpID = dr.EQP_ID;
                _QWIPData.Add(eqpID, new List<Cassette>());
                _BWIPData.Add(eqpID, new List<Cassette>());

                if (eqpID != "FabOut")
                {
                    string[] cstQs = dr.Q.Split(',', '(', ')');

                    string pIDQ = "";
                    string sIDQ = "";
                    int qtyQ = -1;
                    foreach (string str in cstQs)
                    {
                        if (str == "")
                            continue;
                        else
                        {
                            if (pIDQ == "")
                            {
                                pIDQ = str;
                            }
                            else if (sIDQ == "")
                            {
                                sIDQ = str;
                            }
                            else if (qtyQ == -1)
                            {
                                qtyQ = int.Parse(str);
                                _QWIPData[eqpID].Add(new Cassette(pIDQ, sIDQ, qtyQ, eqpID));
                                pIDQ = "";
                                sIDQ = "";
                                qtyQ = -1;
                            }
                        }
                    }

                    string[] cstBs = dr.B.Split(',', '(', ')');

                    string pIDB = "";
                    string sIDB = "";
                    int qtyB = -1;
                    foreach (string str in cstBs)
                    {
                        if (str == "")
                            continue;
                        else
                        {
                            if (pIDB == "")
                            {
                                pIDB = str;
                            }
                            else if (sIDB == "")
                            {
                                sIDB = str;
                            }
                            else if (qtyB == -1)
                            {
                                qtyB = int.Parse(str);
                                _BWIPData[eqpID].Add(new Cassette(pIDB, sIDB, qtyB, eqpID));
                                pIDB = "";
                                sIDB = "";
                                qtyB = -1;
                            }
                        }
                    }
                }
                else
                {
                    string[] cstFOs = dr.Q.Split(',', '(', ')');

                    string pIDFO = "";
                    int qtyFO = -1;
                    foreach (string str in cstFOs)
                    {
                        if (str == "")
                            continue;
                        else
                        {
                            if (pIDFO == "")
                            {
                                pIDFO = str;
                            }
                            else if (qtyFO == -1)
                            {
                                qtyFO = int.Parse(str);
                                _FOData.Add(new Cassette(pIDFO, "", qtyFO, ""));
                                pIDFO = "";
                                qtyFO = -1;
                            }
                        }
                    }
                }
            }
        }

        public bool hasQWIP(string eqpid)
        {
            if (_QWIPData.ContainsKey(eqpid))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool hasBWIP(string eqpid)
        {
            if (_BWIPData.ContainsKey(eqpid))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //public void Clear()
        //{
        //    _QWIPData = new Dictionary<string, List<Cassette>>();
        //    _BWIPData = new Dictionary<string, List<Cassette>>();
        //    _FOData = new List<Cassette>();
        //}

        public void Save(Dictionary<string, List<Cassette>> Q, Dictionary<string, List<Cassette>> B, List<Cassette> FO)
        {
            foreach (string key in Q.Keys)
            {
                _QWIPData.Add(key, new List<Cassette>());
                foreach (Cassette cst in Q[key])
                {
                    Cassette input = new Cassette(cst.J, cst.P, cst.N, key);
                    _QWIPData[key].Add(input);
                }
            }
            foreach (string key in B.Keys)
            {
                _BWIPData.Add(key, new List<Cassette>());
                foreach (Cassette cst in B[key])
                {
                    Cassette input = new Cassette(cst.J, cst.P, cst.N, key);
                    _BWIPData[key].Add(input);
                }
            }
            foreach (Cassette cst in FO)
            {
                Cassette input = new Cassette(cst.J, "", cst.N, "FabOut");
                _FOData.Add(input);
            }
        }

        public override void Clear()
        {
            foreach (string key in _QWIPData.Keys)
            {
                _QWIPData[key].Clear();
            }
            _QWIPData.Clear();

            foreach (string key in _BWIPData.Keys)
            {
                _BWIPData[key].Clear();
            }
            _BWIPData.Clear();

            _FOData.Clear();

            _QWIPData = new Dictionary<string, List<Cassette>>();
            _BWIPData = new Dictionary<string, List<Cassette>>();
            _FOData = new List<Cassette>();
        }
        #endregion
    }
}
