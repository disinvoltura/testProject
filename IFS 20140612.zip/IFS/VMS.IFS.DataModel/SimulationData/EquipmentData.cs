﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.Foundation.Logging;

namespace VMS.IFS.DataModel.SimulationData
{
    public enum EquipmentType{UniInlineCell, BiInlineCell, Chamber, Oven};

    public class EquipmentSpecification
    {
        public string EQP_ID;
        public EquipmentType EQP_Type;
        public int EQP_Num;
    }

    public class EquipmentData : MasterDataObject
    {
        #region Member Variables
        //Equipment Specification for each equipment (key: eqp id, value: EquipmentSpecification
        private Dictionary<string, EquipmentSpecification> _Data;
        
        /// <summary>
        /// 설비 유형: u, b, c, v
        /// </summary>
        private List<string> _ValidTypes;

        /// <summary>
        /// 설비 유형 별 설비 목록
        /// </summary>
        private Dictionary<EquipmentType, List<string>> _TypeEQPList;
        private Logger _Logger;
        #endregion

        #region Properties
        /// <summary>
        /// ID List of Equipments
        /// </summary>
        public IEnumerable<string> Keys
        {
            get { return _Data.Keys.ToArray(); }
        }

        public EquipmentSpecification this[string eqpid]
        {
            get { return _Data[eqpid]; }
        }

        /// <summary>
        /// ID List of Equipments whose type is uni-inline cell
        /// </summary>
        public IEnumerable<string> UnilineCells
        {
            get
            {
                List<string> rslt = new List<string>();
                if (_TypeEQPList.ContainsKey(EquipmentType.UniInlineCell))
                    rslt = _TypeEQPList[EquipmentType.UniInlineCell];
                return rslt;
            }
        }

        /// <summary>
        /// EQP ID List of Equipments whose type is bi-inline cell
        /// </summary>
        public IEnumerable<string> BilineCells
        {
            get
            {
                List<string> rslt = new List<string>();
                if (_TypeEQPList.ContainsKey(EquipmentType.BiInlineCell))
                    rslt = _TypeEQPList[EquipmentType.BiInlineCell];
                return rslt;
            }
        }

        /// <summary>
        /// EQP ID List of Equipments whose type is chamber
        /// </summary>
        public IEnumerable<string> Chambers
        {
            get
            {
                List<string> rslt = new List<string>();
                if (_TypeEQPList.ContainsKey(EquipmentType.Chamber))
                    rslt = _TypeEQPList[EquipmentType.Chamber];
                return rslt;
            }
        }

        /// <summary>
        /// EQP ID List of Equipments whose type is oven
        /// </summary>
        public IEnumerable<string> Ovens
        {
            get
            {
                List<string> rslt = new List<string>();
                if (_TypeEQPList.ContainsKey(EquipmentType.Oven))
                    rslt = _TypeEQPList[EquipmentType.Oven];
                return rslt;
            }
        }

        #endregion

        #region Constructors
        public EquipmentData()
        {
            _Data = new Dictionary<string, EquipmentSpecification>();
            _ValidTypes = new List<string>();
            _ValidTypes.AddRange(new string[]{"u", "b", "c", "v"});
            _TypeEQPList = new Dictionary<EquipmentType, List<string>>();

            _Logger = LogManager.GetLogger("SimulationData");
        }
        #endregion

        #region Methods
        public EquipmentSpecification Query(string eqpid)
        {
            if (_Data.ContainsKey(eqpid))
                return _Data[eqpid];
            else
                return null;
        }
        
        public bool Contains(string eqpid)
        {
            return _Data.ContainsKey(eqpid);
        }

        public override void Clear()
        {
            _Data.Clear();
            _TypeEQPList.Clear();
        } 

        public override void Build(InputDataSet ds, Dictionary<string, object> args)
        {
            _Logger.Info("Start of Building Equipment Data");

            for(int i = 0; i < ds.EquipmentDataTable.Rows.Count; i++){
                InputDataSet.EquipmentDataTableRow row  = ds.EquipmentDataTable[i];
             
                if (string.IsNullOrEmpty(row.EQP_TYPE) || string.IsNullOrEmpty(row.EQP_ID) || row.IsNUMNull())
                {
                    if (string.IsNullOrEmpty(row.EQP_TYPE))
                        _Logger.Warning("Invalid Equipment Data Entry: EQP_TYPE is null at a row " + i);
                    if (string.IsNullOrEmpty(row.EQP_ID))
                        _Logger.Warning("Invalid Equipment Data Entry: EQP_TYPE is null at a row " + i);
                    if (string.IsNullOrEmpty(row.NUM))
                        _Logger.Warning("Invalid Equipment Data Entry: NUM is null at a row " + i);

                    continue;
                }
                
                string eqpType = row.EQP_TYPE.ToLower();
                if (!_ValidTypes.Contains(eqpType))
                {
                    _Logger.Warning("Invalid Equipment Data Entry: EQP_TYPE is not valid at a row " + i);
                    continue;
                }

                EquipmentType type = EquipmentType.UniInlineCell;
                switch (eqpType)
                {
                    case "u": 
                        {
                            type = EquipmentType.UniInlineCell;
                            break;
                        }
                    case "b":
                        {
                            type = EquipmentType.BiInlineCell;
                            break;
                        }
                    case "c":
                        {
                            type = EquipmentType.Chamber;
                            break;
                        }
                    case "v":
                        {
                            type = EquipmentType.Oven;
                            break;
                        }
                }
                
                EquipmentSpecification es = new EquipmentSpecification();
                es.EQP_ID = row.EQP_ID;
                es.EQP_Type = type;
                es.EQP_Num = int.Parse(row.NUM);
                
                _Data.Add(row.EQP_ID, es);

                if (_TypeEQPList.ContainsKey(type))
                {
                    List<string> eqplist = _TypeEQPList[type];
                    eqplist.Add(row.EQP_ID);
                    _TypeEQPList[type] = eqplist;

                }else{
                    List<string> eqplist=  new List<string>();
                    eqplist.Add(row.EQP_ID);
                    _TypeEQPList.Add(type, eqplist);
                }

                //_NumData.Add(row.EQP_ID, int.Parse(row.NUM));
            }

            _Logger.Info("End of Building Equipment Data");
        }

        #endregion
    }
}
