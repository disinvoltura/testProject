﻿using System;
using System.Collections.Generic;
using System.Linq;
using VMS.IFS.DataModel.InputData;
using VMS.Foundation.Logging;

namespace VMS.IFS.DataModel.SimulationData
{
    public class DeliveryTimeData : MasterDataObject
    {
        #region Member Variables
        /// <summary>
        /// the key of Data is STK_ID and value is delivery time of a crane at the stocker.
        /// </summary>
        private Dictionary<string, double> _Data;
        private Logger _Logger;
        #endregion

        #region Properties
        public double this[string STKID]
        {
            get
            {
                return this.Query(STKID);
            }
        }
        #endregion

        #region Constructors
        public DeliveryTimeData()
        {
            _Data = new Dictionary<string, double>();

            _Logger = LogManager.GetLogger("SimulationData");
        }
        #endregion

        #region Methods
        public double Query(string STKID)
        {
            double rslt = double.MinValue;

            string key = STKID;
            if (_Data.ContainsKey(key))
                rslt = _Data[key];
            else
            {
                rslt = 0;
                //ERROR
                _Logger.Error("Cannot find any delivery-time data for " + key);
            }
            return rslt;
        }

        #endregion

        public override void Clear()
        {
            _Data.Clear();
        }

        public override void Build(InputDataSet ds, Dictionary<string, object> args)
        {
            _Logger.Info("Start of Building DelivertyTime Data");

            for (int i = 0; i < ds.InlineStockerDataTable.Count; i++)
            {
                InputDataSet.InlineStockerDataTableRow row = ds.InlineStockerDataTable[i];

                if (row.IsSTK_IDNull() || row.IsDELIVERY_TIMENull())
                {
                    _Logger.Error("Invalid DelivertyTime Data Entry: at least one of fields is null at a row " + i);
                    continue;
                }

                string key = row.STK_ID;
                if (!_Data.ContainsKey(key))
                {
                    _Data.Add(key, double.Parse(row.DELIVERY_TIME));
                }
            }
            _Logger.Info("End of Building DelivertyTime Data");
        }
    }
}
