﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.Foundation.Logging;

namespace VMS.IFS.DataModel.SimulationData
{
    public class BOPData: MasterDataObject
    {
        #region Member Variables
        //Key: ProductID.StepID
        private Dictionary<string, List<NextStep>> _Data;
        //Key: ProductID.StepID, Value: First Last Step ID
        private Dictionary<string, string> _FirstStepData;
        //Key: ProductID.StepID, Value: Last Step ID
        private Dictionary<string, string> _LastStepData;
        //Key: ProductID, Value: List of Step IDs
        private StepCollection _ProductStepData;

        private Logger _Logger;
        private Random _R;
        #endregion

        #region Properties
        /// <summary>
        /// Returns the next processing step of a given product-id and processing step
        /// </summary>
        /// <param name="productid"></param>
        /// <param name="stepid"></param>
        /// <returns></returns>
        public string this[string productid, string stepid]
        {
            get { return this.Query(productid, stepid); }
        }

        /// <summary>
        /// Processing Step List of each Product ID
        /// </summary>
        public StepCollection ProductSteps
        {
            get { return _ProductStepData; }
        }

        #endregion

        #region Constructors
        public BOPData()
        {
            _Data = new Dictionary<string, List<NextStep>>();
            _FirstStepData = new Dictionary<string, string>();
            _LastStepData = new Dictionary<string, string>();
            _ProductStepData = new StepCollection();

            _Logger = LogManager.GetLogger("SimulationData");
            _R = new Random();
        }
        #endregion

        #region Methods
        public override void Clear()
        {
            foreach (string key in _Data.Keys)
            {
                _Data[key].Clear();
            }
            _Data.Clear();
            _FirstStepData.Clear();
            _LastStepData.Clear();
            _ProductStepData = new StepCollection();
        } 

        public string Query(string productid, string stepid)
        {
            string rslt = string.Empty;

            string key = string.Format("{0}.{1}", productid, stepid);
            if (_Data.ContainsKey(key))
            {
                List<NextStep> nextSteps = _Data[key];

                if (nextSteps.Count > 1)
                {
                    double r = _R.NextDouble();
                    double yield = 0;
                    for (int i = 0; i < nextSteps.Count; i++)
                    {
                        yield += nextSteps[i].Yield;
                        if (r <= yield)
                        {
                            rslt = nextSteps[i].StepID;
                            break;
                        }
                    }
                }
                else if (nextSteps.Count == 1)
                {
                    rslt = nextSteps[0].StepID;
                }
                else
                {
                    //Error
                    _Logger.Error("Cannot find any next step for " + key);
                }
            }

            return rslt;
        }

        public override void Build(InputDataSet ds, Dictionary<string, object> args)
        {
            _Logger.Info("Start of Building BOP Data");

            if (args.ContainsKey(SimulationArguments.RandomSeed))
            {
                int seed = int.Parse(args[SimulationArguments.RandomSeed].ToString());
                _R = new Random(seed);
            }

            Dictionary<string, List<string>> fromStepList = new Dictionary<string, List<string>>();
            Dictionary<string, List<string>> toStepList = new Dictionary<string, List<string>>();

            for (int i = 0; i < ds.BOPDataTable.Count; i++)
            {
                InputDataSet.BOPDataTableRow row = ds.BOPDataTable[i];

                if (row.IsPROD_IDNull() || row.IsFROM_STEPNull() || row.IsTO_STEPNull() || row.IsRATIONull())
                {
                    _Logger.Error("Invalid BOP Data Entry: at least one of fields is null at a row " + i);
                    continue;
                }

                string key = string.Format("{0}.{1}", row.PROD_ID, row.FROM_STEP);
                if (_Data.ContainsKey(key))
                {
                    List<NextStep> steps = _Data[key];
                    steps.Add(new NextStep(row.TO_STEP, double.Parse(row.RATIO)));
                    _Data[key] = steps;
                }
                else
                {
                    List<NextStep> steps = new List<NextStep>();
                    steps.Add(new NextStep(row.TO_STEP, double.Parse(row.RATIO)));
                    _Data.Add(key, steps);
                }

                //From Step List 와 To Step List 에서 교집합은 삭제
                if (fromStepList.ContainsKey(row.PROD_ID))
                {
                    List<string> fromStep = fromStepList[row.PROD_ID];
                    if (!fromStep.Contains(row.FROM_STEP))
                    {
                        fromStep.Add(row.FROM_STEP);
                        fromStepList[row.PROD_ID] = fromStep;
                    }

                    List<string> toStep = toStepList[row.PROD_ID];
                    if (!toStep.Contains(row.TO_STEP))
                    {
                        toStep.Add(row.TO_STEP);
                        toStepList[row.PROD_ID] = toStep;
                    }
                }
                else
                {
                    List<string> fromStep = new List<string>();
                    fromStep.Add(row.FROM_STEP);
                    fromStepList.Add(row.PROD_ID, fromStep);

                    List<string> toStep = new List<string>();
                    toStep.Add(row.TO_STEP);
                    toStepList.Add(row.PROD_ID, toStep);
                }

                //Product-Step
                _ProductStepData.Add(row.PROD_ID, row.FROM_STEP);
                _ProductStepData.Add(row.PROD_ID, row.TO_STEP);
            }

            //First and Last Step
            foreach (string productid in fromStepList.Keys)
            {
                List<string> fromStep = fromStepList[productid];
                List<string> toStep = toStepList[productid];
                List<string> FirstSteps = fromStep.Except<string>(toStep).ToList<string>();
                List<string> LastSteps = toStep.Except<string>(fromStep).ToList<string>();

                _FirstStepData.Add(productid, FirstSteps[0]);
                _LastStepData.Add(productid, LastSteps[0]);
               
            }

            _Logger.Info("End of Building BOLP Data");
        }

        private LinkedList<string> n;
        //private LinkedListNode<string> n;


        /// <summary>
        /// return the first processing step id of a BOP whose product id is given.   
        /// </summary>
        /// <param name="productid">Product ID</param>
        /// <returns>First Processing StepID</returns>
        public string GetFirstStepID(string productid)
        {
            string firstStepID = string.Empty;
            if (_FirstStepData.ContainsKey(productid))
                firstStepID = _FirstStepData[productid];

            return firstStepID;
        }

        /// <summary>
        /// return the last processing step id of a BOP whose product id is given.   
        /// </summary>
        /// <param name="productid">Product ID</param>
        /// <returns>Last Processing StepID</returns>
        public string GetLastStepID(string productid)
        {
            string lastStepID = string.Empty;
            if (_LastStepData.ContainsKey(productid))
                lastStepID = _LastStepData[productid];

            return lastStepID;
        }

        public List<NextStep> GetNextStepList(string productid, string stepid)
        {
            List<NextStep> nextSteps  = new List<NextStep>();
            string key = string.Format("{0}.{1}", productid, stepid);
            if (_Data.ContainsKey(key))
            {
                nextSteps = _Data[key];
            }

            return nextSteps;
        }
        #endregion
    }

    /// <summary>
    /// 제품 별 공정 목록 제공
    /// </summary>
    public class StepCollection
    {
        /// <summary>
        /// Key: Product ID, Value: List of Processing Steps
        /// </summary>
        private Dictionary<string, List<string>> _ProdSteps;

        /// <summary>
        /// Returns the list of processing steps of a product
        /// </summary>
        /// <param name="productid"></param>
        /// <returns></returns>
        public IEnumerable<string> this[string productid]
        {
            get{
                return _ProdSteps[productid];
            }
        }

        public StepCollection ()
        {
            _ProdSteps = new Dictionary<string,List<string>>();
        }

        public void Add(string productid, string stepid)
        {
            if (!_ProdSteps.ContainsKey(productid))
            {
                List<string> steps = new List<string>();
                steps.Add(stepid);

                _ProdSteps.Add(productid, steps);
            }else{
                List<string> steps = _ProdSteps[productid];
                if (!steps.Contains(stepid))
                    steps.Add(stepid);

                _ProdSteps[productid] = steps;
            }
        }
    }
}
