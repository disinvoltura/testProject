﻿using System;
using System.Collections.Generic;
using System.Text;
using VMS.IFS.DataModel.SimulationData;

namespace VMS.IFS.DataModel.SimulationData
{
    public enum DropPointType {
        /// <summary>
        /// Stocker Buffer
        /// </summary>
        B,
        /// <summary>
        /// Empty Cassette
        /// </summary>
        E, 
        /// <summary>
        /// Uni-inline Port
        /// </summary>
        PU, 
        /// <summary>
        /// Bi-inline In-port
        /// </summary>
        PI, 
        /// <summary>
        /// Bi-inline Out-port
        /// </summary>
        PO, 
        /// <summary>
        /// Oven Port
        /// </summary>
        PV, 
        /// <summary>
        /// Chamber Port
        /// </summary>
        PC, 
        /// <summary>
        /// Stocker Out-port
        /// </summary>
        SO };
    public enum PickupPointType {
        /// <summary>
        /// Stocker Buffer
        /// </summary>
        B,
        /// <summary>
        /// Empty Cassette
        /// </summary>
        E, 
        /// <summary>
        /// Uni-line Port
        /// </summary>
        PU, 
        /// <summary>
        /// Bi-inline In-port
        /// </summary>
        PI, 
        /// <summary>
        /// Bi-inline Out-port
        /// </summary>
        PO, 
        /// <summary>
        /// Oven Port
        /// </summary>
        PV, 
        /// <summary>
        /// Chamber Port
        /// </summary>
        PC, 
        /// <summary>
        /// Stocker In-port
        /// </summary>
        SI };

    public class Cassette: SimulationEntity
    {
        #region Member Variables
        /// <summary>
        /// Product ID
        /// </summary>
        private string _J = string.Empty;
        /// <summary>
        /// Processing Step
        /// </summary>
        private string _P = string.Empty;
        /// <summary>
        /// Previous Processing Step
        /// </summary>
        private string _BP = string.Empty;
        /// <summary>
        /// Number of Glasses
        /// </summary>
        private int _N;
        /// <summary>
        /// After Equipment ID (ID of the equipment where the cassette is scheduled to enter after the current equipment)
        /// </summary>
        private string _A = string.Empty;
        /// <summary>
        /// Before Equipment ID (ID of the equipment where the cassette stayed before entering this equipment)
        /// </summary>
        private string _B = string.Empty;
        /// <summary>
        /// Current Equipment ID
        /// </summary>
        private string _C = string.Empty;
        /// <summary>
        /// Next Equipment ID
        /// </summary>
        private string _D = string.Empty;

        private DropPointType _DP;
        private PickupPointType _PP;

        private Route _R;

        private string _RBID = string.Empty;

        private double _DoubleDueDate;
        private double _ReleaseDate;
        private double _ArrivalDate;
        private DateTime _DueDate;

        /// <summary>
        /// true when the cassette is on moving status
        /// </summary>
        private bool _IsMoving;

        #endregion

        #region Properties
        /// <summary>
        /// Product ID (or job type) of a cassette
        /// </summary>
        public string J { get { return _J; } }
        /// <summary>
        /// Processing Step ID which the cassette will undergo
        /// </summary>
        public string P { get { return _P; } set { _P = value; } }
        /// <summary>
        /// Previous Processing Step ID which the cassette will undergo
        /// </summary>
        public string BP { get { return _BP; } set { _BP = value; } }
        /// <summary>
        /// Number of glasses in the cassette
        /// </summary>
        public int N { get { return _N; } }

        /// <summary>
        /// After Equipment ID
        /// </summary>
        public string A { get { return _A; } set { _A = value; } }
        /// <summary>
        /// Before Equipment ID
        /// </summary>
        public string B { get { return _B; } set { _B = value; } }
        /// <summary>
        /// Equipment ID where the cassette stays 
        /// </summary>
        public string C { get { return _C; } set { _C = value; } }
        /// <summary>
        /// Equipment ID, which is a destination of the cassette 
        /// </summary>
        public string D { get { return _D; } set { _D = value; } }
        /// <summary>
        /// Drop Point
        /// </summary>
        public DropPointType DP { get { return _DP; } set { _DP = value; } }
        /// <summary>
        /// Pickup Point
        /// </summary>
        public PickupPointType PP { get { return _PP; } set { _PP = value; } }

        /// <summary>
        /// ID of a release batch where the cassette belongs
        /// </summary>
        public string RBID { get { return _RBID; } }

        public Route Route { get { return _R; } set { _R = value; } }

        public DateTime DateTimeDueDate
        {
            get { return _DueDate; }
            set { _DueDate = value; }
        }

        public double DueDate
        {
            get { return _DoubleDueDate; }
            set { _DoubleDueDate = value; }
        }

        public double ReleaseDate
        {
            get { return _ReleaseDate; }
            set { _ReleaseDate = value; }
        }
        
        /// <summary>
        /// Time when a cassette arrives at the queue of next equipment
        /// </summary>
        public double ArrivalDate
        {
            get { return _ArrivalDate; }
            set { _ArrivalDate = value; }
        }

        /// <summary>
        /// True when the cassette is on moving through AMHS
        /// </summary>
        public bool IsMoving
        {
            get { return _IsMoving; }
            set { _IsMoving = value; }
        }

        #endregion

        #region Constructors
        /// <summary>
        /// Cassette Constructor
        /// </summary>
        /// <param name="rbid">Release Batch ID</param>
        /// <param name="j">Product ID (or job type) of a cassette</param>
        /// <param name="p">Processing Step ID</param>
        /// <param name="n">Number of glasses in the cassette</param>
        /// <param name="d">Equipment ID, which is a destination of the cassette</param>
        public Cassette(string rbid, string j, string p, int n, string d)
            : base()
        {
            _RBID = rbid;
            _J = j;
            _P = p;
            _N = n;
            _D = d;
            
            _IsMoving = false;
        }

        /// <summary>
        /// Cassette Constructor
        /// </summary>
        /// <param name="j">Product ID (or job type) of a cassette</param>
        /// <param name="p">Processing Step ID</param>
        /// <param name="n">Number of glasses in the cassette</param>
        /// <param name="c">Equipment ID where the cassette stays</param>
        public Cassette(string j, string p, int n, string c)
            : base()
        {            
            _J = j;
            _P = p;
            _N = n;
            _C = c;
            

            _IsMoving = false;
        }
        #endregion

        #region Methods
        /// <summary>
        /// The route of the cassette is updated by removing the first way point
        /// </summary>
        public void ShiftRoute()
        {
            _R.Shift();
        }

        /// <summary>
        /// The current location of the cassette is now updated with relevant location data
        /// </summary>
        public void UpdatePlace(string place)
        {
            _B = _C; _C = place; 
            if (_R.Count > 1)
                _A = _R[1].ID;
        }

        public override string ToString()
        {
            string rslt = string.Empty;
            if (_R == null)
                rslt = string.Format("Cassette({0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10}, {11})", this.ID, _RBID, _J, _P, _N, _A, _B, _C, _D, _ReleaseDate, _DoubleDueDate, string.Empty);
            else
                rslt = string.Format("Cassette({0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10}, {11})", this.ID, _RBID, _J, _P, _N, _A, _B, _C, _D, _ReleaseDate, _DoubleDueDate, _R.ToString());
            return rslt;
        }
        #endregion
    }

    public class CopyOfCassette : SimulationEntity
    {
        #region Member Variables
        /// <summary>
        /// Product ID
        /// </summary>
        private string _J = string.Empty;
        /// <summary>
        /// Processing Step
        /// </summary>
        private string _P = string.Empty;
        /// <summary>
        /// Previous Processing Step
        /// </summary>
        private string _BP = string.Empty;
        /// <summary>
        /// Number of Glasses
        /// </summary>
        private int _N;
        /// <summary>
        /// After Equipment ID 
        /// </summary>
        private string _A = string.Empty;
        /// <summary>
        /// Before Equipment ID
        /// </summary>
        private string _B = string.Empty;
        /// <summary>
        /// Current Equipment ID
        /// </summary>
        private string _C = string.Empty;
        /// <summary>
        /// Next Equipment ID
        /// </summary>
        private string _D = string.Empty;

        private DropPointType _DP;
        private PickupPointType _PP;

        private Route _R;

        private string _RBID = string.Empty;

        private double _DoubleDueDate;
        private double _ReleaseDate;
        private double _ArrivalDate;
        private DateTime _DueDate;

        /// <summary>
        /// true when the cassette is on moving status
        /// </summary>
        private bool _IsMoving;

        #endregion

        #region Properties
        /// <summary>
        /// Product ID (or job type) of a cassette
        /// </summary>
        public string J { get { return _J; } }
        /// <summary>
        /// Processing Step ID which the cassette will undergo
        /// </summary>
        public string P { get { return _P; } set { _P = value; } }
        /// <summary>
        /// Previous Processing Step ID which the cassette will undergo
        /// </summary>
        public string BP { get { return _BP; } set { _BP = value; } }
        /// <summary>
        /// Number of glasses in the cassette
        /// </summary>
        public int N { get { return _N; } }

        /// <summary>
        /// After Equipment ID
        /// </summary>
        public string A { get { return _A; } set { _A = value; } }
        /// <summary>
        /// Before Equipment ID
        /// </summary>
        public string B { get { return _B; } set { _B = value; } }
        /// <summary>
        /// Equipment ID where the cassette stays 
        /// </summary>
        public string C { get { return _C; } set { _C = value; } }
        /// <summary>
        /// Equipment ID, which is a destination of the cassette 
        /// </summary>
        public string D { get { return _D; } set { _D = value; } }
        /// <summary>
        /// Drop Point
        /// </summary>
        public DropPointType DP { get { return _DP; } set { _DP = value; } }
        /// <summary>
        /// Pickup Point
        /// </summary>
        public PickupPointType PP { get { return _PP; } set { _PP = value; } }

        /// <summary>
        /// ID of a release batch where the cassette belongs
        /// </summary>
        public string RBID { get { return _RBID; } }

        public Route Route { get { return _R; } set { _R = value; } }

        public DateTime DateTimeDueDate
        {
            get { return _DueDate; }
            set { _DueDate = value; }
        }

        public double DueDate
        {
            get { return _DoubleDueDate; }
            set { _DoubleDueDate = value; }
        }

        public double ReleaseDate
        {
            get { return _ReleaseDate; }
            set { _ReleaseDate = value; }
        }

        /// <summary>
        /// Time when a cassette arrives at the queue of next equipment
        /// </summary>
        public double ArrivalDate
        {
            get { return _ArrivalDate; }
            set { _ArrivalDate = value; }
        }

        /// <summary>
        /// True when the cassette is on moving through AMHS
        /// </summary>
        public bool IsMoving
        {
            get { return _IsMoving; }
            set { _IsMoving = value; }
        }

        #endregion

        #region Constructors
        /// <summary>
        /// CopyOfCassette Constructor
        /// </summary>
        /// <param name="rbid">Release Batch ID</param>
        /// <param name="j">Product ID (or job type) of a cassette</param>
        /// <param name="p">Processing Step ID</param>
        /// <param name="n">Number of glasses in the cassette</param>
        /// <param name="d">Equipment ID, which is a destination of the cassette</param>
        public CopyOfCassette(string rbid, string j, string p, int n, string d)
            : base()
        {
            _RBID = rbid;
            _J = j;
            _P = p;
            _N = n;
            _D = d;

            _IsMoving = false;
        }

        /// <summary>
        /// CopyOfCassette Constructor
        /// </summary>
        /// <param name="j">Product ID (or job type) of a cassette</param>
        /// <param name="p">Processing Step ID</param>
        /// <param name="n">Number of glasses in the cassette</param>
        /// <param name="c">Equipment ID where the cassette stays</param>
        public CopyOfCassette(string j, string p, int n, string c)
            : base()
        {
            _J = j;
            _P = p;
            _N = n;
            _C = c;


            _IsMoving = false;
        }
        #endregion

        #region Methods
        public void ShiftRoute()
        {
            _R.Shift();
        }

        public void UpdatePlace(string place)
        {
            _B = _C; _C = place;
            if (_R.Count > 1)
                _A = _R[1].ID;
        }

        public override string ToString()
        {
            string rslt = string.Empty;
            if (_R == null)
                rslt = string.Format("CopyOfCassette({0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10}, {11})", this.ID, _RBID, _J, _P, _N, _A, _B, _C, _D, _ReleaseDate, _DoubleDueDate, string.Empty);
            else
                rslt = string.Format("CopyOfCassette({0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10}, {11})", this.ID, _RBID, _J, _P, _N, _A, _B, _C, _D, _ReleaseDate, _DoubleDueDate, _R.ToString());
            return rslt;
        }
        #endregion
    }
}
