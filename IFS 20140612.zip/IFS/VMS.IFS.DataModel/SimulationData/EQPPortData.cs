﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.Foundation.Logging;

namespace VMS.IFS.DataModel.SimulationData
{
    public struct EQPPort
    {
        public string EQPID;
        /// <summary>
        /// Port Capacity for Uni-line, Oven, and Chamber-type equipments
        /// </summary>
        public int InOut;
        /// <summary>
        /// In-port Capacity for Bi-inline-type equipment
        /// </summary>
        public int In;
        /// <summary>
        /// Out-port Capacity for Bi-inline-type equipment
        /// </summary>
        public int Out;
        /// <summary>
        /// Stocker ID where the In/Out-ports are located (for U, C, V-type equipments)
        /// </summary>
        public string InOutStkID;
        /// <summary>
        /// Stocker ID where the In-ports are located (for B-type equipments). 
        /// In case of U, C, V-type equipments, by default, it has same value with INOUTSTKID
        /// </summary>
        public string InStkID;
        /// <summary>
        /// Stocker ID where the Out-ports are located (for B-type equipments)
        /// In case of U, C, V-type equipments, by default, it has same value with INOUTSTKID
        /// </summary>
        public string OutStkID;
    }

    public class EQPPortData : MasterDataObject
    {
        #region Member Variables
        /// <summary>
        /// Key: EQPID, Value: number of Port
        /// </summary>
        private Dictionary<string, EQPPort> _Data;
        private Logger _Logger;
        #endregion

        #region Properties
        public EQPPort this[string eqpid]
        {
            get { return _Data[eqpid]; }
        }
        #endregion

        #region Constructors
        public EQPPortData()
        {
            _Data = new Dictionary<string, EQPPort>();

            _Logger = LogManager.GetLogger("SimulationData");
        }
        #endregion

        #region Methods
        public EQPPort Query(string eqpid)
        {
            EQPPort rslt = new EQPPort();
            if (_Data.ContainsKey(eqpid))
                rslt = _Data[eqpid];

            return rslt;
        }
        
        public override void Clear()
        {
            _Data.Clear();
        }

        public override void Build(InputDataSet ds, Dictionary<string, object> args)
        {
            _Logger.Info("Start of Building EQPORT Data");

            for(int i = 0; i < ds.EQP_PortDataTable.Rows.Count; i++){
                InputDataSet.EQP_PortDataTableRow row = ds.EQP_PortDataTable[i];

                if (row.IsEQP_IDNull() || row.IsPORT_CAPANull() || row.IsPORT_TYPENull()) //|| row.IsSTK_IDNull()
                {
                    _Logger.Warning("Invalid EQP_PORT Data Entry is found at a row " + i);
                    continue;
                }

                if (_Data.ContainsKey(row.EQP_ID))
                {
                    EQPPort port = _Data[row.EQP_ID];
                    string portType = row.PORT_TYPE.ToLower();
                    if (portType == "u" || portType == "c" || portType == "v")
                    {
                        port.InOut = int.Parse(row.PORT_CAPA);
                        port.InOutStkID = row.STK_ID;
                        port.InStkID = row.STK_ID;
                        port.OutStkID = row.STK_ID;
                    }
                    else if (portType == "i")
                    {
                        port.In = int.Parse(row.PORT_CAPA);
                        port.InStkID = row.STK_ID;
                    }
                    else if (portType == "o")
                    {
                        port.Out = int.Parse(row.PORT_CAPA);
                        port.OutStkID = row.STK_ID;
                    }
                    _Data[row.EQP_ID] = port;
                }
                else
                {
                    EQPPort port = new EQPPort();
                    port.EQPID = row.EQP_ID;
                    
                    string portType = row.PORT_TYPE.ToLower();
                    if (portType == "u" || portType == "c" || portType == "v")
                    {
                        port.InOut = int.Parse(row.PORT_CAPA);
                        port.InOutStkID = row.STK_ID;
                        port.InStkID = row.STK_ID;
                        port.OutStkID = row.STK_ID;
                    }
                    else if (portType == "i")
                    {
                        port.In = int.Parse(row.PORT_CAPA);
                        port.InStkID = row.STK_ID;
                    }
                    else if (portType == "o")
                    {
                        port.Out = int.Parse(row.PORT_CAPA);
                        port.OutStkID = row.STK_ID;
                    }
                    _Data.Add(row.EQP_ID, port);
                }             
            }

            _Logger.Info("End of Building EQPORT Data");
        }

        #endregion

    }
}
