﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.Foundation.Logging;
using System.Globalization;

namespace VMS.IFS.DataModel.SimulationData
{
    public class FabOutPlanData: MasterDataObject
    {
        #region Member Variables
        //Date, Product ID, Quantity
        //private Dictionary<string, List<FabOutPlan>> _Data;
        private Dictionary<DateTime, List<FabOutPlan>> _Data;
        private DateTime _FirstFabOutDate;
        private DateTime _LastFabOutDate;
        private Logger _Logger;
        
        #endregion 

        #region Properties
        public Dictionary<DateTime, List<FabOutPlan>> Data
        {
            get { return _Data; }
        }
        public DateTime FirstFabOutDate
        {
            get { return _FirstFabOutDate; }
        }

        public DateTime LastFabOutDate
        {
            get { return _LastFabOutDate; }
        }
        #endregion

        #region Constructors
        public FabOutPlanData()
        {
            _Data = new Dictionary<DateTime,List<FabOutPlan>>();

            _Logger = LogManager.GetLogger("SimulationData");

            _FirstFabOutDate = DateTime.MaxValue;
            _LastFabOutDate = DateTime.MinValue;
        }
        #endregion

        #region Methods
        public override void Clear()
        {
            _Data.Clear();
        }

        public List<FabOutPlan> Query(DateTime date)
        {
            List<FabOutPlan> rslt = new List<FabOutPlan>();

            if (_Data.ContainsKey(date))
            {
                rslt = _Data[date];
            }

            return rslt;
        }

        public override void Build(InputDataSet ds, Dictionary<string, object> args)
        {
            _Logger.Info("Start of Building FabOutPlan Data");

            for (int i = 0; i < ds.FabOutPlanDataTable.Count; i++)
            {
                InputDataSet.FabOutPlanDataTableRow row = ds.FabOutPlanDataTable[i];

                CultureInfo provider = CultureInfo.InvariantCulture;
                string format = "yyyyMMdd";
                DateTime date = DateTime.ParseExact(row[0].ToString(), format, provider);

                List<FabOutPlan> plans = new List<FabOutPlan>();
                for(int j = 1 ; j < ds.FabOutPlanDataTable.Columns.Count; j++)
                {
                    string prodid = ds.FabOutPlanDataTable.Columns[j].ColumnName;
                    int quantity = int.Parse(row[prodid].ToString());
                    FabOutPlan p = new FabOutPlan(date, prodid, quantity);

                    plans.Add(p);
                }

                _Data.Add(date, plans);

                if (date < _FirstFabOutDate)
                    _FirstFabOutDate = date;
                if (date > _LastFabOutDate)
                    _LastFabOutDate = date;
            }

            _Logger.Info("End of Building FabOutPlan Data");
        }
        #endregion
    }

    public class FabOutPlanComparer : IComparer<FabOutPlan>
    {
        public int Compare(FabOutPlan x, FabOutPlan y)
        {
            return y.RemainedQuantity.CompareTo(x.RemainedQuantity);
        }
    }

    public class FabOutPlan
    {
        private DateTime _Date;
        private string _ProductID;
        private int _TargetQuantity;
        private int _RemainedQuantity;

        public DateTime Date
        {
            get { return _Date;}
        }

        public string ProductID
        {
            get {return _ProductID;}
        }

        public int TargetQuantity
        {
            get {return _TargetQuantity;}
        }

        public int RemainedQuantity
        {
            get {return _RemainedQuantity;}
            set { _RemainedQuantity = value; }
        }

        public FabOutPlan(DateTime date, string productid, int quantity)
        {
            _Date = date;
            _ProductID = productid;
            _TargetQuantity = quantity;
            _RemainedQuantity = quantity;
        }
    }
}
