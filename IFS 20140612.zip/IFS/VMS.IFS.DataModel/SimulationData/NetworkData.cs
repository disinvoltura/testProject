﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.Foundation.Logging;

namespace VMS.IFS.DataModel.SimulationData
{
    public class NetworkData: MasterDataObject
    {
        #region Member Variables
        private NetworkNodeList _Nodes;
        private NetworkEdgeList _Edges;
        private Logger _Logger;
        #endregion

        #region Properties
        public NetworkNodeList Nodes { get { return _Nodes; } set { _Nodes = value; } }
        public NetworkEdgeList Edges { get { return _Edges; } set { _Edges = value; } }
        #endregion

        #region Constructors
        public NetworkData()
        {
            _Nodes = new NetworkNodeList();
            _Edges = new NetworkEdgeList();

            _Logger = LogManager.GetLogger("SimulationData");
        }
        #endregion

        #region Methods
        public override void Clear()
        {
        }

        public override void Build(InputDataSet ds, Dictionary<string, object> args)
        {
            _Logger.Info("Start of Building Network Data");
            
            for (int i = 0; i < ds.InlineStockerDataTable.Count; i++)
            {
                InputDataSet.InlineStockerDataTableRow row = ds.InlineStockerDataTable[i];

                NetworkNode node = new NetworkNode(row.STK_ID);
                _Nodes.Add(node);
            }

            Dictionary<string, double> weightSet = new Dictionary<string, double>();
            bool IsWeightConveyTime = (bool)args[SimulationArguments.MCSWeightMode];
            if (IsWeightConveyTime)
            {
                //Use Convey Time to Weight
                foreach (InputDataSet.ConveyorDataTableRow row in ds.ConveyorDataTable.Rows)
                {
                    weightSet.Add(row.CONV_ID, double.Parse(row.CONV_TIME));
                }
            }
            else
            {
                string versionNo = (string)args[SimulationArguments.MCSWeightSet];
                InputDataSet.MCSWeightSetDataTableRow[] weightSetRows = (InputDataSet.MCSWeightSetDataTableRow[])
                    ds.MCSWeightSetDataTable.Select("VERSION_NO = '" + versionNo + "'");
                for (int i = 0; i < weightSetRows.Length; i++)
                {
                    weightSet.Add(weightSetRows[i].CONV_ID, double.Parse(weightSetRows[i].WEIGHT));
                }

                foreach (InputDataSet.ConveyorDataTableRow row in ds.ConveyorDataTable.Rows)
                {
                    if (row.CONV_ID.Contains("FabIn") || row.CONV_ID.Contains("FabOut"))
                        weightSet.Add(row.CONV_ID, double.Parse(row.CONV_TIME));
                }
            }
            

            for (int i = 0 ; i< ds.ConveyorDataTable.Count; i++)
            {
                InputDataSet.ConveyorDataTableRow row = ds.ConveyorDataTable[i];

                NetworkEdge edge = new NetworkEdge(row.CONV_ID, row.FROM_STK, row.TO_STK, weightSet[row.CONV_ID]);
                _Edges.Add(edge);

                NetworkNode fromNode = _Nodes[row.FROM_STK];
                NetworkNode toNode = _Nodes[row.TO_STK];

                fromNode.AddOutputEdge(row.CONV_ID);
                fromNode.AddOutputNode(row.TO_STK);

                toNode.AddInputEdge(row.CONV_ID);
                toNode.AddInputNode(row.FROM_STK);

                _Nodes[row.FROM_STK] = fromNode;
                _Nodes[row.TO_STK] = toNode;
            }

            for (int i = 0; i < ds.EQP_PortDataTable.Count; i++)
            {
                InputDataSet.EQP_PortDataTableRow row = ds.EQP_PortDataTable[i];

                string portType = row.PORT_TYPE.ToLower();
                if (portType == "pi" || portType == "i")
                {
                    _Nodes[row.STK_ID].AddInPortEQP(row.EQP_ID);
                }
                else if (portType == "po" || portType == "o")
                {
                    _Nodes[row.STK_ID].AddOutPortEQP(row.EQP_ID);
                }
                else
                {
                    _Nodes[row.STK_ID].AddInPortEQP(row.EQP_ID);
                    _Nodes[row.STK_ID].AddOutPortEQP(row.EQP_ID);
                }
            }
            _Logger.Info("End of Building Network Data");
        }

        private string getKey(string fromSTK, string toSTK)
        {
            return string.Format("{0}.{1}", fromSTK, toSTK);
        }
        #endregion
    }

    public class NetworkNodeList
    {
        private Dictionary<string, NetworkNode> _Nodes;

        public NetworkNode this [string nodeName]
        {
            get
            {
                NetworkNode rslt = null;
                if (_Nodes.ContainsKey(nodeName))
                {
                    rslt = _Nodes[nodeName];
                }
                return rslt;
            }
            set
            {
                if (_Nodes.ContainsKey(nodeName))
                {
                    _Nodes[nodeName] = value;
                }
                else
                {
                    _Nodes.Add(nodeName, value);
                }
            }
        }

        public NetworkNodeList()
        {
            _Nodes = new Dictionary<string, NetworkNode>();
        }

        public void Add(string name)
        {
            _Nodes.Add(name, new NetworkNode(name));
        }

        public void Add(NetworkNode node)
        {
            _Nodes.Add(node.Name, node);
        }
    }

    public class NetworkEdgeList
    {
        private Dictionary<string, NetworkEdge> _Edges;

        public NetworkEdge this[string edgeName]
        {
            get
            {
                NetworkEdge rslt = null;
                if (_Edges.ContainsKey(edgeName))
                {
                    rslt = _Edges[edgeName];
                }
                return rslt;
            }
            set
            {
                if (_Edges.ContainsKey(edgeName))
                {
                    _Edges[edgeName] = value;
                }
                else
                {
                    _Edges.Add(edgeName, value);
                }
            }
        }

        public NetworkEdgeList()
        {
            _Edges = new Dictionary<string, NetworkEdge>();
        }

        public void Add(NetworkEdge edge)
        {
            _Edges.Add(edge.Name, edge);
        }
    }

    public class NetworkNode
    {
        #region Member Variables
        private string _Name;
        private List<string> _InputEdges;
        private List<string> _OutputEdges;
        private List<string> _InputNodes;
        private List<string> _OutputNodes;

        private List<string> _InPortEQPs;
        private List<string> _OutPortEQPs;
        #endregion

        #region Properties
        /// <summary>
        /// Node Name
        /// </summary>
        public string Name { get { return _Name; } }
        /// <summary>
        /// Node 로 들어오면 Edges (Conveyors)
        /// </summary>
        public List<string> InputEdges { get { return _InputEdges; } }
        /// <summary>
        /// Node 에서 나가는 Edges (Conveyors)
        /// </summary>
        public List<string> OutputEdges { get { return _OutputEdges; } }
        /// <summary>
        /// 들어오는 Edges에 연결된 Nodes
        /// </summary>
        public List<string> InputNodes { get { return _InputNodes; } }
        /// <summary>
        /// 나가는 Edges 에 연결된 Nodes
        /// </summary>
        public List<string> OutputNodes { get { return _OutputNodes; } }
        /// <summary>
        /// Input Port 가 연결된 설비들
        /// </summary>
        public List<string> InPortEQPs { get { return _InPortEQPs; } }
        /// <summary>
        /// Output Port 가 연결된 설비들
        /// </summary>
        public List<string> OutPortEQPs { get { return _OutPortEQPs; } }
        #endregion

        #region Constructors
        public NetworkNode()
        {
            _InputNodes = new List<string>();
            _OutputNodes = new List<string>();
            _InputEdges = new List<string>();
            _OutputEdges = new List<string>();

            _InPortEQPs = new List<string>();
            _OutPortEQPs = new List<string>();
        }

        public NetworkNode(string name)
            : this()
        {
            _Name = name;
        }
        #endregion

        #region Methods
        public void AddInputEdge(string name)
        {
            _InputEdges.Add(name);
        }

        public void AddInputNode(string name)
        {
            _InputNodes.Add(name);
        }

        public void AddOutputEdge(string name)
        {
            _OutputEdges.Add(name);
        }

        public void AddOutputNode(string name)
        {
            _OutputNodes.Add(name);
        }

        public void AddInPortEQP(string name)
        {
            _InPortEQPs.Add(name);
        }

        public void AddOutPortEQP(string name)
        {
            _OutPortEQPs.Add(name);
        }
        #endregion
    }

    public class NetworkEdge
    {
        #region Member Variables
        private string _Name;
        private string _FromNode;
        private string _ToNode;
        private double _Weight;
        #endregion

        #region Properties
        public string Name { get { return _Name; } }
        public string FromNode { get { return _FromNode; } }
        public string ToNode { get { return _ToNode; } }
        public double Weight { get { return _Weight;} }
        #endregion

        public NetworkEdge(string name, string fromNodeName, string toNodeName, double Weight)
        {
            _Name = name;
            _FromNode = fromNodeName;
            _ToNode  = toNodeName;
            _Weight = Weight;
        }
    }


}
