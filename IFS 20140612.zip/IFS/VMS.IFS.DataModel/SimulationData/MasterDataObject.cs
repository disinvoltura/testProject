﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;

namespace VMS.IFS.DataModel.SimulationData
{
    public abstract class MasterDataObject
    {
        public abstract void Build(InputDataSet ds, Dictionary<string, object> args);

        public abstract void Clear();
    }
}
