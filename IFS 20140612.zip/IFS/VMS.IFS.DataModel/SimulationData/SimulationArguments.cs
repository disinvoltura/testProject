﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.DataModel.SimulationData
{
    public class SimulationArguments
    {
        public static readonly string RandomSeed = "RandomSeed";
        public static readonly string LoadableEQPVersionNo = "LoadableEQPVersionNo";
        public static readonly string EOSMode = "EOSMode";//Time, Event
        public static readonly string EOSTime = "EOSTime";
        public static readonly string EOSTimeUnit = "Hours"; //Days, Hours, Minutes, Seconds, 
        public static readonly string EOSEventName = "EOSEventName";
        public static readonly string EOSEventCount = "EOSEventCount";
        public static readonly string UnitTime = "UnitTime";
        public static readonly string SaveWIPTime = "SaveWIPTime";
        public static readonly string JobSelectionRule = "JSR";
        public static readonly string MachineSelectionRule = "MSR";
        public static readonly string Logging = "Logging";//boolean
        public static readonly string ReferenceDateTime = "RefDateTime";
        public static readonly string KanbanFabWIP = "FabWIPKanban";
        public static readonly string KanbanStepWIP = "StepWIPKanban";
        public static readonly string KanbanStepID = "StepIDKanban";
        public static readonly string MCSWeightMode = "MCSWeightMode"; //Time, Weight (Convey Time vs. User-defined Weight)
        public static readonly string MCSWeightSet = "MCSWeightSet";
        public static readonly string StartTime = "StartTime";
        public static readonly string ConnectApplication = "ConnectApplication";//boolean
        public static readonly string InterReleaseTime = "InterReleaseTime";

        /// <summary>
        /// Capacity of Virtual Queue
        /// </summary>
        public static readonly string VQCapacity = "VQCapacity";
    }
}
