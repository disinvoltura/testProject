﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.DataModel.SimulationData
{ 
    public class CassetteCollection
    {
        #region Member Variables
        private List<Cassette> _Cassettes;
        /// <summary>
        /// Capacity of Cassette Queue.
        /// If the cassette queue has infinite capacity, by default this is set to zero.
        /// </summary>
        private int _Capacity;
        #endregion

        #region Properties
        public List<Cassette> Cassettes
        {
            get { return _Cassettes; }
        }

        /// <summary>
        /// Number of Cassettes
        /// </summary>
        public int Count
        {
            get { return _Cassettes.Count; }
        }

        /// <summary>
        /// Capacity of Cassette Queue.
        /// If the cassette queue has infinite capacity, by default this is set to zero.
        /// </summary>
        public int Capacity
        {
            get { return _Capacity; }
        }
        #endregion

        #region Constructors
        public CassetteCollection()
        {
            _Cassettes = new List<Cassette>();
        }

        public CassetteCollection(int capacity)
        {
            _Cassettes = new List<Cassette>(capacity);
            _Capacity = capacity;
        }

        #endregion

        #region Methods
        public void Clear()
        {
            _Cassettes.Clear();
        }

        public void Enqueue(Cassette cst)
        {
            _Cassettes.Add(cst);
        }

        public Cassette Dequeue()
        {
            Cassette  rslt = null;

            if (_Cassettes.Count > 0)
            {
                rslt = _Cassettes[0];
                _Cassettes.RemoveAt(0);
            }

            return rslt;
        }

        public Cassette Dequeue(int cassetteid)
        {
            int idx = -1;
            Cassette rslt = null;
            for (int i = 0; i < _Cassettes.Count; i++)
            {
                if (_Cassettes[i].ID == cassetteid)
                {
                    idx = i;
                    rslt = _Cassettes[i];
                    break;
                }
            }

            if (idx >= 0)
                _Cassettes.RemoveAt(idx);

            return rslt;
        }

        public Cassette Peek()
        {
            Cassette  rslt = null;

            if (_Cassettes.Count > 0)
            {
                rslt = _Cassettes[0];
            }

            return rslt;
        }

        /// <summary>
        /// Remove a given cassette from the collection
        /// </summary>
        /// <param name="cst"></param>
        public void Remove(Cassette cst)
        {
            _Cassettes.Remove(cst);
        }       
        
        public void Remove(int cassetteid)
        {
            int idx = -1;
            for (int i = 0; i < _Cassettes.Count; i++)
            {
                if (_Cassettes[i].ID == cassetteid)
                {
                    idx = i;
                    break;
                }
            }

            if (idx >= 0)
                _Cassettes.RemoveAt(idx);

        }

        public void RemoveAt(int idx)
        {
            _Cassettes.RemoveAt(idx);
        }

        public bool IsFull()
        {
            bool rslt = false;

            if (_Capacity > 0)
                rslt = _Cassettes.Count >= _Capacity;

            return rslt;
        }
        /*
        /// <summary>
        /// Remove a casseet whose cassette id matches a given value
        /// </summary>
        /// <param name="cassetteID">ID of a cassette to be removed</param>
        public void Remove(int cassetteID)
        {
            if (_Cassettes.ContainsKey(cassetteID))
                _Cassettes.Remove(cassetteID);
        }
         * */
        #endregion
    }

    public class CopyOfCassetteCollection
    {
        #region Member Variables
        private List<Cassette> _Cassettes;
        /// <summary>
        /// Capacity of Cassette Queue.
        /// If the cassette queue has infinite capacity, by default this is set to zero.
        /// </summary>
        private int _Capacity;
        #endregion

        #region Properties
        public List<Cassette> Cassettes
        {
            get { return _Cassettes; }
        }

        /// <summary>
        /// Number of Cassettes
        /// </summary>
        public int Count
        {
            get { return _Cassettes.Count; }
        }

        /// <summary>
        /// Capacity of Cassette Queue.
        /// If the cassette queue has infinite capacity, by default this is set to zero.
        /// </summary>
        public int Capacity
        {
            get { return _Capacity; }
        }
        #endregion

        #region Constructors
        public CopyOfCassetteCollection()
        {
            _Cassettes = new List<Cassette>();
        }

        public CopyOfCassetteCollection(int capacity)
        {
            _Cassettes = new List<Cassette>(capacity);
            _Capacity = capacity;
        }

        #endregion

        #region Methods
        public void Clear()
        {
            _Cassettes.Clear();
        }

        public void Enqueue(Cassette cst)
        {
            _Cassettes.Add(cst);
        }

        public Cassette Dequeue()
        {
            Cassette rslt = null;

            if (_Cassettes.Count > 0)
            {
                rslt = _Cassettes[0];
                _Cassettes.RemoveAt(0);
            }

            return rslt;
        }

        public Cassette Dequeue(int cassetteid)
        {
            int idx = -1;
            Cassette rslt = null;
            for (int i = 0; i < _Cassettes.Count; i++)
            {
                if (_Cassettes[i].ID == cassetteid)
                {
                    idx = i;
                    rslt = _Cassettes[i];
                    break;
                }
            }

            if (idx >= 0)
                _Cassettes.RemoveAt(idx);

            return rslt;
        }

        public Cassette Peek()
        {
            Cassette rslt = null;

            if (_Cassettes.Count > 0)
            {
                rslt = _Cassettes[0];
            }

            return rslt;
        }

        /// <summary>
        /// Remove a given cassette from the collection
        /// </summary>
        /// <param name="cst"></param>
        public void Remove(Cassette cst)
        {
            _Cassettes.Remove(cst);
        }

        public void Remove(int cassetteid)
        {
            int idx = -1;
            for (int i = 0; i < _Cassettes.Count; i++)
            {
                if (_Cassettes[i].ID == cassetteid)
                {
                    idx = i;
                    break;
                }
            }

            if (idx >= 0)
                _Cassettes.RemoveAt(idx);

        }

        public void RemoveAt(int idx)
        {
            _Cassettes.RemoveAt(idx);
        }

        public bool IsFull()
        {
            bool rslt = false;

            if (_Capacity > 0)
                rslt = _Cassettes.Count >= _Capacity;

            return rslt;
        }
        /*
        /// <summary>
        /// Remove a casseet whose cassette id matches a given value
        /// </summary>
        /// <param name="cassetteID">ID of a cassette to be removed</param>
        public void Remove(int cassetteID)
        {
            if (_Cassettes.ContainsKey(cassetteID))
                _Cassettes.Remove(cassetteID);
        }
         * */
        #endregion
    }
}
