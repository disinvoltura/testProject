﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.Foundation.Logging;

namespace VMS.IFS.DataModel.SimulationData
{
    public class TactTimeData : MasterDataObject
    {
        #region Member Variables
        /// <summary>
        /// the key of Data is ProductID.StepID.EQPID and value is tact time 
        /// </summary>
        private Dictionary<string, double> _Data;
        private Logger _Logger;
        #endregion

        #region Properties
        public double this[string productid, string stepid, string eqpid]
        {
            get { return this.Query(productid, stepid, eqpid); }
        }
        #endregion

        #region Constructors
        public TactTimeData()
        {
            _Data = new Dictionary<string, double>();

            _Logger = LogManager.GetLogger("SimulationData");
        }
        #endregion

        #region Methods
        public override void Clear()
        {
            _Data.Clear();
        }
        
        public double Query(string productid, string stepid, string eqpid)
        {
            double rslt = double.MinValue;
            string key = string.Format("{0}.{1}.{2}", productid, stepid, eqpid);
            if (_Data.ContainsKey(key))
                rslt = _Data[key];
            else
            {
                rslt = 0;
                //ERROR
                _Logger.Error("Cannot find any tact time data for " + key);
            }
            return rslt;
        }

        public override void Build(InputDataSet ds, Dictionary<string, object> args)
        {
            _Logger.Info("Start of Building TactTime Data");

            for (int i = 0; i < ds.ProcessingTimeDataTable.Count; i++)
            {
                InputDataSet.ProcessingTimeDataTableRow row = ds.ProcessingTimeDataTable[i];

                if (row.IsEQP_IDNull() || row.IsFLOW_TIMENull() || row.IsPROD_IDNull() || row.IsSTEP_IDNull())
                {
                    _Logger.Error("Invalid TactTime Data Entry: at least one of fields is null at a row " + i);
                    continue;
                }

                string key = string.Format("{0}.{1}.{2}", row.PROD_ID, row.STEP_ID, row.EQP_ID);
                if (!_Data.ContainsKey(key))
                {
                    _Data.Add(key, double.Parse(row.TACT_TIME));
                }
            }

            _Logger.Info("End of Building TactTime Data");
        }
        #endregion

    }
}
