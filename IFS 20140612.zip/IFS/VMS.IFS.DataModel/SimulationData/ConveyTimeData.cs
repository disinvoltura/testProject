﻿using System;
using System.Collections.Generic;
using System.Linq;
using VMS.IFS.DataModel.InputData;
using VMS.Foundation.Logging;

namespace VMS.IFS.DataModel.SimulationData
{
    public class ConveyTimeData : MasterDataObject
    {
        #region Member Variables
        /// <summary>
        /// the key of Data is CONV_ID and value is the conveying time of a cassette on the conveyor
        /// </summary>
        private Dictionary<string, double> _Data;
        private Logger _Logger;
        #endregion

        #region Properties
        public double this[string CONVID]
        {
            get
            {
                return this.Query(CONVID);
            }
        }
        #endregion

        #region Constructors
        public ConveyTimeData()
        {
            _Data = new Dictionary<string, double>();

            _Logger = LogManager.GetLogger("SimulationData");
        }
        #endregion

        #region Methods
        public override void Clear()
        {
            _Data.Clear();
        }

        public double Query(string CONVID)
        {
            double rslt = double.MinValue;

            string key = CONVID;
            if (_Data.ContainsKey(key))
                rslt = _Data[key];
            else
            {
                rslt = 0;
                //ERROR
                _Logger.Error("Cannot find any convey-time data for " + key);
            }
            return rslt;
        }

        #endregion

        public override void Build(InputDataSet ds, Dictionary<string, object> args)
        {
            _Logger.Info("Start of Building ConveyTime Data");

            for (int i = 0; i < ds.ConveyorDataTable.Count; i++)
            {
                InputDataSet.ConveyorDataTableRow row = ds.ConveyorDataTable[i];

                if (row.IsCONV_IDNull() || row.IsCONV_TIMENull())
                {
                    _Logger.Error("Invalid ConveyTime Data Entry: at least one of fields is null at a row " + i);
                    continue;
                }

                string key = row.CONV_ID;
                if (!_Data.ContainsKey(key))
                {
                    _Data.Add(key, double.Parse(row.CONV_TIME));
                }
            }
            _Logger.Info("End of Building ConveyTime Data");
        }
    }
}
