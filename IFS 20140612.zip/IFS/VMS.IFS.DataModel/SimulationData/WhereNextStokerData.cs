﻿using System;
using System.Collections.Generic;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.Foundation.Logging;

namespace VMS.IFS.DataModel.SimulationData
{
    public class WhereNextStockerData : MasterDataObject
    {
        #region Member Variables
        //Key: EQPID, Value: List<string> - list of stocker IDs
        private Dictionary<string, List<string>> _Data;
        private Logger _Logger;
        #endregion

        #region Properties
        /// <summary>
        /// Where-Next Stocker List
        /// </summary>
        /// <param name="eqpid"></param>
        /// <returns></returns>
        public List<string> this[string eqpid]
        {
            get
            {
                return Query(eqpid);
            }
        }
        #endregion

        #region Constructors
        public WhereNextStockerData()
        {
            _Data = new Dictionary<string, List<string>>();

            _Logger = LogManager.GetLogger("SimulationData");
        }
        #endregion

        #region Methods
        public override void Clear()
        {
            foreach (string key in _Data.Keys)
                _Data[key].Clear();
            _Data.Clear();
        }

        public List<string> Query(string eqpid)
        {
            List<string> rslt = new List<string>();
            if (_Data.ContainsKey(eqpid))
                rslt = _Data[eqpid];

            return rslt;
        }

        public override void Build(InputData.InputDataSet ds, Dictionary<string, object> args)
        {
            _Logger.Info("Start of Building WhereNextSTK Data");

            for (int i = 0; i < ds.WhereNextSTKDataTable.Count; i++)
            {
                InputDataSet.WhereNextSTKDataTableRow row = ds.WhereNextSTKDataTable[i];

                if (row.IsEQP_IDNull() || row.IsSTK_IDNull())
                {
                    _Logger.Warning("Invalid WhereNextSTK Data Entry: null at a row " + i);
                    continue;
                }

                if (_Data.ContainsKey(row.EQP_ID))
                {
                    List<string> stklist = _Data[row.EQP_ID];
                    stklist.Add(row.STK_ID);
                    _Data[row.EQP_ID] = stklist;
                }
                else
                {
                    List<string> stklist = new List<string>();
                    stklist.Add(row.STK_ID);
                    _Data.Add(row.EQP_ID, stklist);
                }
            }
            _Logger.Info("End of Building WhereNextSTK Data");
        }
        #endregion
    }
}
