﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.IFS.DataModel.SimulationData
{
    public class GlassCollection
    {
        #region Member Variables
        private List<Glass> _Glasses;

        #endregion

        #region Properties
        public IEnumerable<Glass> Glasses
        {
            get { return _Glasses; }
        }

        public int Count
        {
            get { return _Glasses.Count; }
        }
        #endregion

        #region Constructors
        public GlassCollection()
        {
            _Glasses = new List<Glass>();
        }
        #endregion

        #region Methods
        public void Clear()
        {
            _Glasses.Clear();
        }

        public void Enqueue(Glass gls)
        {
            _Glasses.Add(gls);
        }

        public Glass Dequeue()
        {
            Glass rslt = null;

            if (_Glasses.Count > 0)
            {
                rslt = _Glasses[0];
                _Glasses.RemoveAt(0);
            }

            return rslt;
        }

        public Glass Peek()
        {
            Glass rslt = null;

            if (_Glasses.Count > 0)
            {
                rslt = _Glasses[0];
            }

            return rslt;
        }

        /// <summary>
        /// Remove a given glass from the collection
        /// </summary>
        /// <param name="gls">Glass </param>
        public void Remove(Glass gls)
        {
            _Glasses.Remove(gls);
        }
        #endregion
    }
}
