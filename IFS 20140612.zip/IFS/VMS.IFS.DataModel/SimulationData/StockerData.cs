﻿using System;
using System.Collections.Generic;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.Foundation.Logging;

namespace VMS.IFS.DataModel.SimulationData
{
    public class StockerData : MasterDataObject
    {
        #region Member Variables
        private Dictionary<string, StockerSpecification> _Data;
        private Logger _Logger;
        #endregion

        #region Properties
        /// <summary>
        /// ID List of Stockers
        /// </summary>
        public IEnumerable<string> Keys
        {
            get { return _Data.Keys; }
        }

        public StockerSpecification this[string stkid]
        {
            get
            {
                return Query(stkid);
            }
        }
        #endregion

        #region Constructors
        public StockerData()
        {
            _Data = new Dictionary<string, StockerSpecification>();

            _Logger = LogManager.GetLogger("SimulationData");
        }
        #endregion

        #region Methods
        public override void Clear()
        {
            _Data.Clear();
        }

        public StockerSpecification Query(string stkid)
        {
            StockerSpecification rslt = null;
            if (_Data.ContainsKey(stkid))
                rslt = _Data[stkid];

            return rslt;
        }

        public bool Contains(string stkid)
        {
            return _Data.ContainsKey(stkid);
        }

        public override void Build(InputData.InputDataSet ds, Dictionary<string, object> args)
        {
            _Logger.Info("Start of Building Stocker Data");

            for (int i = 0; i < ds.InlineStockerDataTable.Count; i++)
            {
                InputDataSet.InlineStockerDataTableRow row = ds.InlineStockerDataTable[i];

                if (row.IsSTK_IDNull() || row.IsSTK_TYPENull() || row.IsSTK_BUFFERNull() || row.IsRETRIEVAL_TIMENull() || row.IsDELIVERY_TIMENull())
                {
                    _Logger.Warning("Invalid Stocker Data Entry: null at a row " + i);
                    continue;
                }

                StockerSpecification stk = new StockerSpecification();
                stk.StockerID = row.STK_ID;
                stk.Type = row.STK_TYPE.ToLower().Equals("s") ? StockerType.Single : StockerType.Dual;
                if (!double.TryParse(row.RETRIEVAL_TIME, out stk.RetrievalTime))
                    stk.RetrievalTime= 0;
                if (!double.TryParse(row.DELIVERY_TIME, out stk.DeliveryTime))
                    stk.DeliveryTime = 0;
                if (!int.TryParse(row.STK_BUFFER, out stk.BufferCapacity))
                    stk.BufferCapacity = int.MaxValue;

                _Data.Add(row.STK_ID, stk);
            }
            _Logger.Info("End of Building Stocker Data");
        }
        #endregion
    }

    public enum StockerType { Single, Dual};

    public class StockerSpecification
    {
        public string StockerID;
        public StockerType Type;
        public double RetrievalTime;
        public double DeliveryTime;
        public int BufferCapacity;
    }
}
