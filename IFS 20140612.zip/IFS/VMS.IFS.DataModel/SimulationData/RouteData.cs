﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.IFS.DataModel.InputData;
using VMS.Foundation.Logging;

namespace VMS.IFS.DataModel.SimulationData
{
    public class RouteData: MasterDataObject
    {
        #region Member Variables
        /// <summary>
        /// Stocker 간의 Route 데이터 (Key: STKID.STKID)
        /// </summary>
        private Dictionary<string, Route> _Data;
        private Logger _Logger;
        
        #endregion

        #region Properties
        public Route this[string FromSTKID, string ToSTKID]
        {
            get { return this.Query(FromSTKID, ToSTKID); }
        }
        #endregion

        #region Constructors
        public RouteData()
        {
            _Data = new Dictionary<string, Route>();
            _Logger = LogManager.GetLogger("SimulationData");
        }
        #endregion

        #region Methods
        public override void Clear()
        {
            _Data.Clear();
        }

        public Route Query(string FromSTKID, string ToSTKID)
        {
            Route rslt = null;

            string key = string.Format("{0}.{1}", FromSTKID, ToSTKID);
            if (_Data.ContainsKey(key))
            {
                rslt = _Data[key].Clone();
            }

            return rslt;
        }

        private List<string> _STKList;
        //key: STKID, value: List of neighbor STKs
        private Dictionary<string, List<string>> _NeighborSTKList;
        //key: STKID, value: List of outgoing conveyors
        private Dictionary<string, List<string>> _OutConyorList;
        //Key: ConvID, value: ToSTKID
        private Dictionary<string, string> _ConvToSTKList;
        //Key: STKID_STKID, value: List of conveyoys 
        private Dictionary<string, List<string>> _InterSTKConvList;
        //Key: ConvID, value: Weight
        private Dictionary<string, double> _ConvWeightList;
        //Key: ConvID, Value: Convey Time
        private Dictionary<string, double> _ConveyTimes;
        //Key: STK ID, value: retrieval time + delivery time
        private Dictionary<string, double> _StockerTimes;

        public override void Build(InputDataSet ds, Dictionary<string, object> args)
        {
            _Logger.Info("Start of Building Route Data");

            //Find Shortest Route for all pairs of stockers
            _STKList = new List<string>();
            _NeighborSTKList = new Dictionary<string, List<string>>();
            _OutConyorList = new Dictionary<string,List<string>>();
            _ConvToSTKList = new Dictionary<string,string>();
            _InterSTKConvList = new Dictionary<string,List<string>>();
            _ConvWeightList = new Dictionary<string,double>();
            _ConveyTimes = new Dictionary<string, double>();
            _StockerTimes = new Dictionary<string, double>();

            for (int i = 0; i < ds.InlineStockerDataTable.Count; i++)
            {
                InputDataSet.InlineStockerDataTableRow row = ds.InlineStockerDataTable[i];

                _STKList.Add(row.STK_ID);
                _NeighborSTKList.Add(row.STK_ID, new List<string>());
                _OutConyorList.Add(row.STK_ID, new List<string>());
                double time = double.Parse(row.RETRIEVAL_TIME) + double.Parse(row.DELIVERY_TIME);
                _StockerTimes.Add(row.STK_ID, time);
            }

            for (int i = 0 ; i< ds.ConveyorDataTable.Count; i++)
            {
                InputDataSet.ConveyorDataTableRow row = ds.ConveyorDataTable[i];

                List<string> neighbors = _NeighborSTKList[row.FROM_STK];
                if (!neighbors.Contains(row.TO_STK))
                    neighbors.Add(row.TO_STK);
                _NeighborSTKList[row.FROM_STK] = neighbors;

                List<string> outConveyors = _OutConyorList[row.FROM_STK];
                if (!outConveyors.Contains(row.CONV_ID))
                    outConveyors.Add(row.CONV_ID);
                _OutConyorList[row.FROM_STK] = outConveyors;

                _ConvToSTKList.Add(row.CONV_ID, row.TO_STK);

                string key = string.Format("{0}_{1}", row.FROM_STK, row.TO_STK);
                if (_InterSTKConvList.ContainsKey(key)){
                    List<string> clist = _InterSTKConvList[key];
                    clist.Add(row.CONV_ID);
                    _InterSTKConvList[key] = clist;
                }else{
                    _InterSTKConvList.Add(key, new List<string>() { row.CONV_ID });
                }

                _ConveyTimes.Add(row.CONV_ID, double.Parse(row.CONV_TIME));
            }

            //MCSWeight
            bool IsWeightConveyTime = (bool)args[SimulationArguments.MCSWeightMode];

            if (IsWeightConveyTime)
            {
                //Use Convey Time to Weight
                foreach (InputDataSet.ConveyorDataTableRow row in ds.ConveyorDataTable.Rows)
                {
                    _ConvWeightList.Add(row.CONV_ID, double.Parse(row.CONV_TIME));
                }
            }
            else
            {
                string versionNo = (string)args[SimulationArguments.MCSWeightSet];
                InputDataSet.MCSWeightSetDataTableRow[] weightSet = (InputDataSet.MCSWeightSetDataTableRow[])
                    ds.MCSWeightSetDataTable.Select("VERSION_NO ='" + versionNo + "'");
                for (int i = 0; i < weightSet.Length; i++)
                {
                    _ConvWeightList.Add(weightSet[i].CONV_ID, double.Parse(weightSet[i].WEIGHT));
                }

                foreach (InputDataSet.ConveyorDataTableRow row in ds.ConveyorDataTable.Rows)
                {
                    if (row.CONV_ID.Contains("FabIn") || row.CONV_ID.Contains("FabOut"))
                        _ConvWeightList.Add(row.CONV_ID, double.Parse(row.CONV_TIME));
                }
            }

            //Find shortest path for all stockers
            for(int i = 0 ; i < _STKList.Count; i++)
            {
                string fromSTK = _STKList[i];

                for (int j = 0; j < _STKList.Count; j++)
                {
                    if (i == j)
                        continue;

                    string toSTK = _STKList[j];

                    Route r = Dijkstra(fromSTK, toSTK);

                    string key = getKey(fromSTK, toSTK);
                    _Data.Add(key, r);
                }
            }

            _Logger.Info("End of Building Route Data");
        }

        private string getKey(string fromSTK, string toSTK)
        {
            return string.Format("{0}.{1}", fromSTK, toSTK);
        }
        #endregion

        #region Finding Routes Methods
        private Route Dijkstra(string fromSTK, string toSTK)
        {
            Route route = new Route(fromSTK, toSTK);

            //List<string> path = new List<string>();

            //Dijkstra's Shortest Path Algorithm 사용
            Dictionary<string, double> dist = new Dictionary<string, double>();
            Dictionary<string, string> prevSTK = new Dictionary<string, string>();
            Dictionary<string, string> prevCONV = new Dictionary<string, string>();
            List<string> STKNode = new List<string>();

            foreach (string stk in _STKList)
            {
                dist.Add(stk, double.MaxValue); //모든 stk의 distance를 maximum으로
                prevSTK.Add(stk, null);         //모든 stk의 previous stk는 null로
                prevCONV.Add(stk, null);        //모든 stk의 previous conv는 null로
                STKNode.Add(stk);               //검사할 stk list
            }
            dist[fromSTK] = 0;                   //현재 stk와의 거리=0

            while (STKNode.Count > 0)
            {
                string u = getShortestDist(dist, STKNode);  //dist 값이 가장 작은 stk = u
                if (dist[u] == double.MaxValue) break;
                STKNode.Remove(u);          //검사 list에서 u 제거
                if (u.Equals(toSTK)) break;    //u가 target STK이면 중지

                List<string> neighborSTK =_NeighborSTKList[u];   //u의 이웃 stk들의 list
                List<string> neighborCONV = _OutConyorList[u];     //u에서 나가는 conv list

                foreach (string conv in neighborCONV)
                {
                    double alt = 0.0;
                    alt = dist[u] + Distance(u, conv);
                    string v = _ConvToSTKList[conv];
                    if (alt < dist[v])
                    {
                        dist[v] = alt;
                        prevSTK[v] = u;
                        prevCONV[v] = conv;
                    }
                }
            }

            string w = toSTK;
            while (prevSTK[w] != null)
            {
                route.Insert(0, w, RouteWayPointType.Stocker, _StockerTimes[w]);
                route.Insert(0,prevCONV[w], RouteWayPointType.Conveyor, _ConveyTimes[prevCONV[w]]); 
                w = prevSTK[w];
            }
            route.Insert(0, fromSTK, RouteWayPointType.Stocker, _StockerTimes[w]);
            route.Cost = dist[toSTK];
            return route;
        }

        public double Distance(string FromSTK, string CONV)
        {
            double dist;
            dist = _ConvWeightList[CONV];
            return dist;
        }
        
        public string getShortestDist(Dictionary<string, double> dist, List<string> STKNode)
        {
            //dist 값이 가장 작은 stk 반환
            string shortestSTK = STKNode[0];
            double shortestD = dist[shortestSTK];

            foreach (string stk in STKNode)
            {
                if (dist[stk] < shortestD)
                {
                    shortestSTK = stk;
                    shortestD = dist[stk];
                }
            }
            return shortestSTK;
        }

        
        #endregion
    }

    public class Route
    {
        #region Member Variables
        private string _FromSTKID;
        private string _ToSTKID;
        private List<RouteWayPoint> _WayPoints;
        private double _Cost;
        private double _Time; //Planned Time (considering only the conveying time)
        #endregion

        #region Properties
        public string FromSTKID { get { return _FromSTKID; } }
        public string ToSTKID { get { return _ToSTKID; } }
        public List<RouteWayPoint> WayPoints { get { return _WayPoints; } }
        public double Cost { get { return _Cost; } set { _Cost = value; } }
        /// <summary>
        /// Planned Transport Time
        /// </summary>
        public double Time { get { return _Time; } set { _Time = value; } }

        public int Count { get { return _WayPoints.Count; }}

        public RouteWayPoint this[int idx] { get { return _WayPoints[idx]; } }

        #endregion

        public Route Clone()
        {
            Route rslt = new Route(this.FromSTKID, this.ToSTKID);

            foreach (RouteWayPoint wp in _WayPoints)
            {
                RouteWayPoint newWP = new RouteWayPoint(wp.ID, wp.Type, wp.Weight);
                rslt.Add(newWP);
            }

            rslt.Cost = _Cost;
            rslt.Time = _Time;

            return rslt;
        }

        #region Constructors
        public Route(string fromSTKID, string toSTKID)
        {
            _FromSTKID = fromSTKID;
            _ToSTKID = toSTKID;
            _Time = 0;
            _WayPoints = new List<RouteWayPoint>();
        }

        public Route(string fromSTKID, string toSTKID, List<RouteWayPoint> waypoints, double cost)
        {
            _FromSTKID = fromSTKID;
            _ToSTKID = toSTKID;
            _WayPoints = waypoints;
            _Cost = cost;
        }
        #endregion

        #region Methods
        public void Add(string id, RouteWayPointType type)
        {
            RouteWayPoint wp = new RouteWayPoint(id, type);
            _WayPoints.Add(wp);
        }

        public void Add(RouteWayPoint wp)
        {
            _WayPoints.Add(wp);
        }

        public void Insert(int idx, string id, RouteWayPointType type)
        {
            RouteWayPoint wp = new RouteWayPoint(id, type);
            _WayPoints.Insert(idx, wp);
        }

        public void Insert(int idx, string id, RouteWayPointType type, double movingTime)
        {
            RouteWayPoint wp = new RouteWayPoint(id, type);
            _WayPoints.Insert(idx, wp);

            _Time += movingTime;
        }

        public void Shift()
        {
            _WayPoints.RemoveAt(0);
        }

        public override string ToString()
        {
            string rslt = _FromSTKID + "->" + _ToSTKID + "(" + _Cost + "):";

            for (int i = 0; i < _WayPoints.Count; i++)
            {
                rslt += _WayPoints[i].ToString();
                if (i < _WayPoints.Count - 1)
                    rslt += ", ";
            }
            return rslt;
        }
        #endregion
    }

    public enum RouteWayPointType { Equipment, Stocker, Conveyor};

    public class RouteWayPoint
    {
        #region Member Variables
        private string _ID; //STKID or CONVID
        private RouteWayPointType _Type;
        private double _Weight;
        #endregion

        #region Properties
        /// <summary>
        /// ID of WayPoint (either Stocker ID or Conveyor ID)
        /// </summary>
        public string ID { get { return _ID; } }
        public RouteWayPointType Type { get { return _Type; } }
        /// <summary>
        /// Weight on the way point
        /// </summary>
        public double Weight { get { return _Weight; } }
        #endregion

        #region Constructors
        public RouteWayPoint(string id, RouteWayPointType type)
        {
            _ID = id;
            _Type = type;
        }

        public RouteWayPoint(string id, RouteWayPointType type, double weight)
        {
            _ID = id;
            _Type = type;
            _Weight = weight;
        }
        #endregion

        #region Methods
        public override string ToString()
        {
            return string.Format("{0}<{1}>", this.ID, this.Type);
        }
        #endregion
    }
}
