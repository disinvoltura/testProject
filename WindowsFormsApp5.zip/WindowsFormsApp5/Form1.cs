﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OfficeOpenXml;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        #region Member Variables
        private Dictionary<string, SourceGrid.Cells.Views.Cell> _BGModels;
        private Dictionary<string, SourceGrid.Cells.Controllers.ToolTipText> _TCControllers;
        private int _DefaultWidth = 2;
        private int _DefaultHeight = 15;
        private DataTable _dtGanttChart;
        private List<string> _EQPList;
        private List<string> _SelectionList;
        #endregion

        public Form1()
        {
            InitializeComponent();

          
        }

        public void LoadGanttChartData(GanttChartData data, bool showIdle, bool showDaySeparator)
        {
            doShowGanttChart(data, showIdle, showDaySeparator);
        }

        private void doShowGanttChart(GanttChartData data, bool showIdle, bool showDaySeparator)
        {
            doInitialize(data);

            grid.Rows.Clear();
            grid.Columns.Clear();

            grid.AllowOverlappingCells = true;

            //Calculate columsn and rows
            int rows = data.Count + 3;//date, hours, minutes

            //resource column + total minutes  + header columns
            //int cols = (int)data.MaximumTime.Subtract(data.MinimumTime).TotalMinutes + 2;
            int cols = (int)data.MaximumTime.Subtract(data.MinimumTime).TotalMinutes;
            if (cols % 60 > 0)
                cols += (60 - (cols % 60));
            cols += 6;//3
            if (cols < 0)
                return;

            //Resource Columns.
            grid.DefaultWidth = _DefaultWidth;
            grid.DefaultHeight = _DefaultHeight;
            grid.Redim(rows, cols);
            grid.FixedRows = 3;
            grid.FixedColumns = 5;

            //Headers
            drawHeaders(data, showDaySeparator);

            //Data Rows
            SourceGrid.Cells.Views.Cell headerModel = new SourceGrid.Cells.Views.Cell();
            DevAge.Drawing.VisualElements.BackgroundSolid backgroundHeader =
                new DevAge.Drawing.VisualElements.BackgroundSolid();
            backgroundHeader.BackColor = Color.Lavender;
            headerModel.Background = backgroundHeader;
            headerModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            int rowIndex = 3;
            
            double totalTime = data.MaximumTime.Subtract(data.MinimumTime).TotalSeconds;
            //double totalTime = 2*24*60*60;
            foreach (string resourceid in data.Resources)
            {
                GanttChartResource res = data[resourceid];

                SourceGrid.Cells.RowHeader l_00Header = new SourceGrid.Cells.RowHeader(null);
                grid[rowIndex, 0] = l_00Header;
                grid.Rows[rowIndex].Height = 35;

                SourceGrid.Cells.Cell eqpidCell = new SourceGrid.Cells.Cell(resourceid, typeof(string));
                eqpidCell.View = headerModel;
                eqpidCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
                eqpidCell.RowSpan = 1;
                grid[rowIndex, 1] = eqpidCell;

                //utilization
                double runTime = data.GetTimeSpan(resourceid, "Run");
                double setupTime = data.GetTimeSpan(resourceid, "Setup");
                double idleTime = totalTime - runTime - setupTime;
                runTime = Math.Round(runTime / totalTime * 100, 2);
                setupTime = Math.Round(setupTime / totalTime * 100, 2);
                idleTime = Math.Round(idleTime / totalTime * 100, 2);

                SourceGrid.Cells.Cell runCell = new SourceGrid.Cells.Cell(runTime, typeof(string));
                runCell.View = headerModel;
                runCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
                grid[rowIndex, 2] = runCell;

                SourceGrid.Cells.Cell setupCell = new SourceGrid.Cells.Cell(setupTime, typeof(string));
                setupCell.View = headerModel;
                setupCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
                grid[rowIndex, 3] = setupCell;

                SourceGrid.Cells.Cell idleCell = new SourceGrid.Cells.Cell(idleTime, typeof(string));
                idleCell.View = headerModel;
                idleCell.View.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleLeft;
                grid[rowIndex, 4] = idleCell;

                int lastColIndex = 5;
                for (int i = 0; i < res.Items.Count; i++)
                {
                    GanttChartBar bar = res.Items[i];
                    if (bar.StartTime == bar.EndTime)
                        continue;

                    int colIndex = (int)bar.StartTime.Subtract(data.MinimumTime).TotalMinutes + 5;
                    int width = (int)bar.EndTime.Subtract(bar.StartTime).TotalMinutes;

                    if (showIdle)
                    {
                        int idleCols = colIndex - lastColIndex;
                        if (idleCols > 0)
                        {
                            InsertIdleCell(rowIndex, lastColIndex, idleCols);
                        }
                    }
                    if (width > 0)
                    {
                        string tooltip = string.Format("Start: {0} \r\n End: {1}", bar.StartTime.ToString("yyyy-MM-dd HH:mm"), bar.EndTime.ToString("yyyy-MM-dd HH:mm"));
                        //string tooltip = string.Format("{0}: {1} ~ {2}", bar.Category, bar.StartTime.ToString("yyyy-MM-dd HH:mm"), bar.EndTime.ToString("yyyy-MM-dd HH:mm"));
                        InsertBarCell(rowIndex, colIndex, width, bar.Category, bar.Text, tooltip);
                    }
                    lastColIndex = colIndex + width;

                }
                if (showIdle)
                {
                    if (lastColIndex < cols)
                    {
                        InsertIdleCell(rowIndex, lastColIndex, cols - lastColIndex);
                    }
                }
                rowIndex++;
            }
            grid.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            //grid.AutoSizeCells();
            grid.Columns.AutoSizeColumn(1);
            grid.SelectionMode = SourceGrid.GridSelectionMode.Cell;

        }

        private void doInitialize(GanttChartData data)
        {
            _BGModels = new Dictionary<string, SourceGrid.Cells.Views.Cell>();
            _TCControllers = new Dictionary<string, SourceGrid.Cells.Controllers.ToolTipText>();
            foreach (string categoryName in data.Categories)
            {
                SourceGrid.Cells.Views.Cell barModel = new SourceGrid.Cells.Views.Cell();
                DevAge.Drawing.VisualElements.BackgroundSolid backgroundSetup =
                    new DevAge.Drawing.VisualElements.BackgroundSolid();
                backgroundSetup.BackColor = Color.FromName(data.GetColor(categoryName));
                barModel.Background = backgroundSetup;
                barModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

                _BGModels.Add(categoryName, barModel);

                //tooltip
                SourceGrid.Cells.Controllers.ToolTipText toolTipController =
                    new SourceGrid.Cells.Controllers.ToolTipText();
                toolTipController.ToolTipTitle = categoryName;
                toolTipController.ToolTipIcon = ToolTipIcon.Info;
                toolTipController.IsBalloon = true;
                _TCControllers.Add(categoryName, toolTipController);
            }

            SourceGrid.Cells.Controllers.ToolTipText idleToolTipController =
                    new SourceGrid.Cells.Controllers.ToolTipText();
            idleToolTipController.ToolTipTitle = "Idle";
            idleToolTipController.ToolTipIcon = ToolTipIcon.Info;
            idleToolTipController.IsBalloon = false;

            _TCControllers.Add("Idle", idleToolTipController);
        }

        private void InsertBarCell(int row, int colStart, int width, string category, string text, string tooltip)
        {
            SourceGrid.Cells.Cell barCell = new SourceGrid.Cells.Cell(text, typeof(string));
            barCell.View = _BGModels[category];
            barCell.ColumnSpan = width;
            barCell.Editor.EnableEdit = false;
            grid[row, colStart] = barCell;
            barCell.ToolTipText = tooltip;
            //barCell.AddController(SourceGrid.Cells.Controllers.ToolTipText.Default);
            //barCell.Model.AddModel(MyToolTipModel.Default);

            if (_TCControllers.ContainsKey(category))
                barCell.AddController(_TCControllers[category]);
        }

        private class MyToolTipModel : SourceGrid.Cells.Models.IToolTipText
        {
            public static readonly MyToolTipModel Default = new MyToolTipModel();

            public string GetToolTipText(SourceGrid.CellContext cellContext)
            {
                SourceGrid.DataGrid grid = (SourceGrid.DataGrid)cellContext.Grid;
                DataRowView row = (DataRowView)grid.Rows.IndexToDataSourceRow(cellContext.Position.Row);
                if (row != null)
                {
                    if (bool.Equals(row["Selected"], true))
                        return "Row " + cellContext.Position.Row.ToString() + " is selected";
                    else
                        return "Row " + cellContext.Position.Row.ToString() + " is NOT selected";
                }
                else
                    return string.Empty;
            }
        }

        private void InsertIdleCell(int row, int colStart, int width)
        {
            SourceGrid.Cells.Cell idlebarCell = new SourceGrid.Cells.Cell("", typeof(string));
            idlebarCell.ColumnSpan = width;
            grid[row, colStart] = idlebarCell;

            idlebarCell.ToolTipText = "Idle Time: " + width + " minutes";
            //idlebarCell.AddController(SourceGrid.Cells.Controllers.ToolTipText.Default);
            //idlebarCell.Model.AddModel(MyToolTipModel.Default);

            if (_TCControllers.ContainsKey("Idle"))
                idlebarCell.AddController(_TCControllers["Idle"]);
        }

        private void InsertBarrierCell(int row, int colStart, int width)
        {
            SourceGrid.Cells.Views.Cell headerModel = new SourceGrid.Cells.Views.Cell();
            DevAge.Drawing.VisualElements.BackgroundSolid backgroundHeader =
                new DevAge.Drawing.VisualElements.BackgroundSolid();
            backgroundHeader.BackColor = Color.HotPink;
            headerModel.Background = backgroundHeader;
            headerModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            SourceGrid.Cells.Cell barrierbarCell = new SourceGrid.Cells.Cell("", typeof(string));
            barrierbarCell.View = headerModel;
            barrierbarCell.ColumnSpan = width;
            grid[row, colStart] = barrierbarCell;

            //idlebarCell.ToolTipText = "Idle Time: " + width + " minutes";
            ////idlebarCell.AddController(SourceGrid.Cells.Controllers.ToolTipText.Default);
            ////idlebarCell.Model.AddModel(MyToolTipModel.Default);

            //if (_TCControllers.ContainsKey("Idle"))
            //    idlebarCell.AddController(_TCControllers["Idle"]);
        }

        private void drawHeaders(GanttChartData data, bool showDaySeparator)
        {
            DateTime now1 = DateTime.Now;
            int timeCols = (int)data.MaximumTime.Subtract(data.MinimumTime).TotalMinutes;
            if (timeCols % 60 > 0)
                timeCols += (60 - (timeCols % 60));

            SourceGrid.Cells.Views.ColumnHeader titleModel = new SourceGrid.Cells.Views.ColumnHeader();
            DevAge.Drawing.VisualElements.ColumnHeader backHeader = new DevAge.Drawing.VisualElements.ColumnHeader();
            backHeader.BackColor = Color.Lavender;
            backHeader.BackgroundColorStyle = DevAge.Drawing.BackgroundColorStyle.Solid;
            titleModel.Background = backHeader;
            titleModel.TextAlignment = DevAge.Drawing.ContentAlignment.MiddleCenter;

            grid.Font = new Font("Calibe", 9);
            grid.EnableSort = false;

            grid.Columns[0].AutoSizeMode = SourceGrid.AutoSizeMode.None;
            grid.Columns[0].Width = 20;
            SourceGrid.Cells.RowHeader l_00Header = new SourceGrid.Cells.RowHeader(null);
            grid[0, 0] = l_00Header;
            grid[1, 0] = new SourceGrid.Cells.RowHeader(null); ;

            //DateTime after1 = DateTime.Now;
            //System.Diagnostics.Trace.WriteLine("drawheader:1 took " + after1.Subtract(now1).TotalSeconds + " seconds.");

            //DateTime now2 = DateTime.Now;
            string[] columns = { "EQP ID" };
            for (int i = 0; i < columns.Length; i++)
            {
                SourceGrid.Cells.ColumnHeader header =
                    new SourceGrid.Cells.ColumnHeader(columns[i]);

                header.View = titleModel;
                header.RowSpan = 2;
                grid[0, 1 + i] = header;
            }

            //Utilization
            SourceGrid.Cells.ColumnHeader utilHeader =
                    new SourceGrid.Cells.ColumnHeader("Utilization (%)");
            utilHeader.View = titleModel;
            utilHeader.ColumnSpan = 3;
            grid[0, 2] = utilHeader;

            SourceGrid.Cells.ColumnHeader runHeader =
                    new SourceGrid.Cells.ColumnHeader("Run");
            runHeader.View = titleModel;
            grid[1, 2] = runHeader;

            SourceGrid.Cells.ColumnHeader setupHeader =
                    new SourceGrid.Cells.ColumnHeader("Setup");
            setupHeader.View = titleModel;
            grid[1, 3] = setupHeader;

            SourceGrid.Cells.ColumnHeader idleHeader =
                    new SourceGrid.Cells.ColumnHeader("Idle");
            idleHeader.View = titleModel;
            grid[1, 4] = idleHeader;

            grid.Columns[1].Width = 100;
            grid.Columns[2].Width = 40;
            grid.Columns[3].Width = 40;
            grid.Columns[4].Width = 40;

            //DateTime after2 = DateTime.Now;
            //System.Diagnostics.Trace.WriteLine("drawheader:2 took " + after2.Subtract(now2).TotalSeconds + " seconds.");

            //DateTime now3 = DateTime.Now;

            for (int i = 0; i <= timeCols; i++)
            {
                DateTime curTime = data.MinimumTime.AddMinutes(i);

                if (curTime.Hour == 0
                    && curTime.Minute == 0)
                {
                    SourceGrid.Cells.ColumnHeader header1 =
                        new SourceGrid.Cells.ColumnHeader(curTime.ToString("yyyy-MM-dd"));
                    header1.View = titleModel;

                    if ((timeCols - i) < 1440)
                        header1.ColumnSpan = timeCols - i + 1;
                    else
                        header1.ColumnSpan = 1440;

                    grid[0, 5 + i] = header1;
                }
                else if (i == 0)
                {
                    SourceGrid.Cells.ColumnHeader header1 =
                        new SourceGrid.Cells.ColumnHeader(curTime.ToString("yyyy-MM-dd"));
                    //header1.View = titleModel;
                    int remainingMinutes = 1440 - (int)data.MinimumTime.TimeOfDay.TotalMinutes;
                    int minutesToEnd = (int)data.MaximumTime.Subtract(curTime).TotalMinutes;
                    header1.ColumnSpan = Math.Min(remainingMinutes, minutesToEnd);
                    //header1.ColumnSpan = ((int)curTime.TimeOfDay.TotalMinutes- (int)data.MinimumTime.TimeOfDay.TotalMinutes);
                    //header1.ColumnSpan = 1440 - (int)curTime.TimeOfDay.TotalMinutes;
                    grid[0, 5 + i] = header1;
                }

                if (curTime.Minute == 0)
                {
                    int hour = i / 60 + 1;// 1;
                    SourceGrid.Cells.ColumnHeader header1 =
                        new SourceGrid.Cells.ColumnHeader(curTime.ToString("HH"));
                    header1.View = titleModel;

                    if ((timeCols - i) < 60)
                        header1.ColumnSpan = timeCols - i + 1;
                    else
                        header1.ColumnSpan = 60;

                    grid[1, 5 + i] = header1;
                }else if (i == 0)
                {
                    int hour = i / 60 + 1;// 1;
                    SourceGrid.Cells.ColumnHeader header1 =
                        new SourceGrid.Cells.ColumnHeader(curTime.ToString("HH"));
                    header1.View = titleModel;

                    int remainingMinutes = 60 - (int)data.MinimumTime.Minute;
                    header1.ColumnSpan = remainingMinutes;

                    grid[1, 5 + i] = header1;
                }

                if (curTime.Minute == 59 && showDaySeparator)
                {
                    for (int k = 3; k < grid.Rows.Count; k++)
                    {
                        InsertBarrierCell(k, 5 + i, 1);
                    }
                }

                SourceGrid.Cells.ColumnHeader header2 =
                    new SourceGrid.Cells.ColumnHeader("");

                header2.View = titleModel;
                grid[2, 5 + i] = header2;

                grid.Columns[5 + i].MinimalWidth = 1;
            }

            //DateTime after3 = DateTime.Now;
            //System.Diagnostics.Trace.WriteLine("drawheader:3 took " + after3.Subtract(now3).TotalSeconds + " seconds.");

            grid.Rows[2].Height = 0;
            grid.SelectionMode = SourceGrid.GridSelectionMode.Row;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime startTime = DateTime.Now.AddHours(1);
            DateTime endTime = DateTime.Now.AddHours(2);
            GanttChartData gcData = new GanttChartData();

            gcData.AddResource("Lot000001");
            gcData.AddResource("Lot000002");
            gcData.AddResource("Lot000003");
            gcData.AddResource("Lot000004");
            gcData.AddCategory("Run", "Gold");
            gcData.AddCategory("Setup", "Red");

            gcData.AddBar("Lot000001",
                       DateTime.Parse("2019-06-22 13:00:00"),
                       DateTime.Parse("2019-06-22 13:30:00"),
                       "Run", 
                       "Process Step 0001");

            gcData.AddBar("Lot000001",
                      DateTime.Parse("2019-06-22 14:00:00"),
                      DateTime.Parse("2019-06-22 14:30:00"),
                      "Run",
                      "Process Step 0002");

            gcData.AddBar("Lot000001",
                      DateTime.Parse("2019-06-22 15:00:00"),
                      DateTime.Parse("2019-06-22 15:30:00"),
                      "Run",
                      "Process Step 0003");

            gcData.AddBar("Lot000001",
                      DateTime.Parse("2019-06-22 16:00:00"),
                      DateTime.Parse("2019-06-22 16:30:00"),
                      "Run",
                      "Process Step 0004");

            gcData.AddBar("Lot000001",
                      DateTime.Parse("2019-06-22 17:00:00"),
                      DateTime.Parse("2019-06-22 17:30:00"),
                      "Run",
                      "Process Step 0005");

            gcData.AddBar("Lot000002",
                       startTime.AddHours(2),
                       endTime.AddHours(2),
                       "Run",
                       "L84DAAA001",
                       "Process Step 0001");

            gcData.AddBar("Lot000003",
                       DateTime.Parse("2019-06-22 13:00:00"),
                       DateTime.Parse("2019-06-22 13:30:00"),
                       "Run",
                       "Process Step 0001");

            gcData.AddBar("Lot000003",
                      DateTime.Parse("2019-06-22 14:00:00"),
                      DateTime.Parse("2019-06-22 14:30:00"),
                      "Run",
                      "Process Step 0002");

            gcData.AddBar("Lot000003",
                      DateTime.Parse("2019-06-22 15:00:00"),
                      DateTime.Parse("2019-06-22 15:30:00"),
                      "Run",
                      "Process Step 0003");

            gcData.AddBar("Lot000003",
                      DateTime.Parse("2019-06-22 16:00:00"),
                      DateTime.Parse("2019-06-22 16:30:00"),
                      "Run",
                      "Process Step 0004");

            gcData.AddBar("Lot000003",
                      DateTime.Parse("2019-06-22 17:00:00"),
                      DateTime.Parse("2019-06-22 17:30:00"),
                      "Run",
                      "Process Step 0005");

            gcData.AddBar("Lot000004",
                       startTime.AddHours(12),
                       endTime.AddHours(12),
                       "Run",
                       "L84DAAA001",
                       "Process Step 0001");

            this.LoadGanttChartData(gcData, true, false);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                //Open the workbook (or create it if it doesn't exist)
                var fi = new FileInfo(dialog.FileName);

                GanttChartData gcData = new GanttChartData();

               
                gcData.AddCategory("Run", "Gold");
                gcData.AddCategory("Setup", "Red");

                using (var p = new ExcelPackage(fi))
                {
                    //Get the Worksheet created in the previous codesample. 
                    var ws = p.Workbook.Worksheets["Sheet1"];

                    int row = 1;
                    do
                    {
                        row++;
                        if (string.IsNullOrEmpty(ws.Cells[row, 1].Text) ||
                            string.IsNullOrEmpty(ws.Cells[row, 2].Text) ||
                            string.IsNullOrEmpty(ws.Cells[row, 3].Text)
                            )
                            break;

                        string lotid = ws.Cells[row, 1].Value.ToString();
                        string eqpid = ws.Cells[row, 2].Value.ToString();
                        string stepName = ws.Cells[row, 3].Value.ToString();

                        DateTime arrivalTime = (DateTime)ws.Cells[row, 4].Value;
                        DateTime trackInTime = (DateTime)ws.Cells[row, 5].Value;
                        DateTime startTime = (DateTime)ws.Cells[row, 6].Value;
                        DateTime endTime = (DateTime)ws.Cells[row, 7].Value;
                        DateTime trackOutTime = (DateTime)ws.Cells[row, 8].Value;

                        //if (!DateTime.TryParse((string)ws.Cells[row, 4].Value, out arrivalTime))
                        //    continue;
                        //if (!DateTime.TryParse((string)ws.Cells[row, 5].Value, out trackInTime))
                        //    continue;
                        //if (!DateTime.TryParse((string)ws.Cells[row, 6].Value, out startTime))
                        //    continue;
                        //if (!DateTime.TryParse((string)ws.Cells[row, 7].Value, out endTime))
                        //    continue;
                        //if (!DateTime.TryParse((string)ws.Cells[row, 8].Value, out trackOutTime))
                        //    continue;

                        gcData.AddBar(lotid,
                                   trackInTime,
                                   trackOutTime,
                                   "Run",
                                   stepName);

                    } while (true);
                    p.Dispose();
                }

                this.LoadGanttChartData(gcData, true, false);
            }
        }
    }
}
